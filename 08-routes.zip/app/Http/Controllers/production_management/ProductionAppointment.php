<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use App\Mail\EAPLMail;
use App\Models\BranchModel;
use App\Models\EmailTemplateModel;
use App\Models\LeadAppointmentModel;
use App\Models\LeadModel;
use App\Models\SmsTemplateModel;
use App\Models\StaffModel;
use App\Models\WhatsappApiConfigureModel;
use App\Models\StaffpointsModel;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class ProductionAppointment extends Controller
{
    protected $client;
    protected $accessToken;
    protected $businessId;
    protected $baseUrl;
    protected $phoneNumberId;
    public function __construct()
    {
        // $whatsappConfig      = WhatsappApiConfigureModel::where('sno', 3)->first();
        // $this->phoneNumberId = $whatsappConfig->phonenumber_id; // Set your access token in the environment file
        // $this->accessToken   = $whatsappConfig->access_tokken;  // Set your access token in the environment file
        // $this->baseUrl       = 'https://graph.facebook.com/v17.0';
        // $this->businessId    = $whatsappConfig->waba_id;
    }


    public function index(Request $request)
    {
        $page         = $request->input('page', 1);
        $perpage      = (int) $request->input('sorting_filter', 25);
        $offset       = ($page - 1) * $perpage;
        $branch_id    = $request->user()->branch_id ?? 1;
        $currentMonth = date('m');
        $currentYear = date('Y');
        $user_id    = $request->user()->user_id ?? 16;

        $lead_status_fill = $request->lead_status_fill ?? '';
        $staff_fill       = $request->staff_fill ?? '';
        $date_filter      = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->from_date_fillter_textbox ?? '';
        $to_date_filter   = $request->to_date_fillter_textbox ?? '';
        $lead_fill        = $request->lead_fill ?? '';
        $fin_yr_fill      = $request->fin_yr_fill ?? '';

        $lead_ap_list = LeadAppointmentModel::select(
            'et_lead_appointment.sno',
            'et_lead_appointment.department_id',
            'et_lead_appointment.convo_message',
            'et_lead_appointment.lead_id as ld_name_id',
            'et_lead_appointment.appointment_date',
            'et_lead_appointment.appointment_category',
            'et_lead_appointment.appointment_status',
            'et_lead_appointment.re_appointment_date',
            'et_lead_appointment.appointment_reason',
            'et_lead_appointment.appt_desc',
            'et_lead_appointment.staff_id',
            'et_lead_appointment.pc_id',
            'et_lead.lead_name',
            'et_lead.lead_email_id',
            'et_lead.lead_gender',
            'et_lead.lead_id',
            'et_lead.lead_mobile',
            'et_lead.status as lead_status',
            'pc.staff_name as pc_name',
            'staff.staff_name as staffs_name',
            'et_appointment_category.appointment_category as app_cat_name'
        )
            ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
            ->leftJoin('et_staff as pc', 'et_lead_appointment.pc_id', '=', 'pc.sno')
            ->leftJoin('et_staff as staff', 'et_lead_appointment.staff_id', '=', 'staff.sno')
            ->leftJoin('et_appointment_category', 'et_appointment_category.sno', '=', 'et_lead_appointment.appointment_category')
            ->where('et_lead_appointment.status', '!=', "2")
            // ->whereNotIn('et_lead.status', [2, 4])
            ->where('et_lead_appointment.branch_id', $branch_id)
            ->where('et_lead_appointment.department_id', 2)
            ->orderBy('et_lead_appointment.sno', 'desc');


        // if ($date_filter == "today") {
        //     $todayDate = date("Y-m-d");
        //     $lead_ap_list->whereDate('et_lead_appointment.created_at', $todayDate);
        // } elseif ($date_filter == "week") {
        //     $today = date('l');
        //     if ($today == "Sunday") {
        //         $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        //         $weekToDate   = date('Y-m-d', strtotime("saturday 1 week"));
        //     } else {
        //         $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        //         $weekToDate   = date('Y-m-d', strtotime("saturday 0 week"));
        //     }
        //     $lead_ap_list->whereBetween('et_lead_appointment.created_at', [$weekFromDate, $weekToDate]);
        // } elseif ($date_filter == "monthly") {
        //     $firstDayOfMonth = date('Y-m-01');
        //     $lastDayOfMonth  = date('Y-m-t');
        //     $lead_ap_list->whereBetween('et_lead_appointment.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        // } elseif ($date_filter == "custom_date") {
        //     if ($from_date_filter && $to_date_filter) {
        //         $fromDate = date('Y-m-d', strtotime($from_date_filter));
        //         $toDate   = date('Y-m-d', strtotime($to_date_filter));
        //         $lead_ap_list->whereBetween('et_lead_appointment.created_at', [$fromDate, $toDate]);
        //     } elseif ($from_date_filter) {
        //         $fromDate = date('Y-m-d', strtotime($from_date_filter));
        //         $lead_ap_list->where('et_lead_appointment.created_at', '>=', $fromDate);
        //     } elseif ($to_date_filter) {
        //         $toDate = date('Y-m-d', strtotime($to_date_filter));
        //         $lead_ap_list->where('et_lead_appointment.created_at', '<=', $toDate);
        //     }
        // }
        
        // $selectedMonthsText = '';
        // if ($fin_yr_fill != '') {
        //     $helper            = new \App\Helpers\Helpers();
        //     $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

        //     if ($selected_fin_year) {
        //         $monthsArray = json_decode($selected_fin_year->financial_month, true);

        //         if (is_array($monthsArray) && ! empty($monthsArray)) {
        //             // Map the months numbers to their names
        //             $months = [
        //                 1 => 'January',
        //                 2 => 'February',
        //                 3 => 'March',
        //                 4      => 'April',
        //                 5    => 'May',
        //                 6       => 'June',
        //                 7 => 'July',
        //                 8    => 'August',
        //                 9   => 'September',
        //                 10 => 'October',
        //                 11 => 'November',
        //                 12 => 'December',
        //             ];

        //             // Collect the selected month names
        //             $selectedMonths = [];
        //             foreach ($monthsArray as $month) {
        //                 if (isset($months[$month])) {
        //                     $selectedMonths[] = $months[$month];
        //                 }
        //             }

        //             // Prepare the selected months text for the view
        //             $selectedMonthsText = implode(', ', $selectedMonths);
        //         }
        //     }
        // }

        if ($staff_fill != '') {
            $lead_ap_list->where('et_lead_appointment.staff_id', $staff_fill);
        }

        if ($lead_status_fill != '') {
            $lead_ap_list->where('et_lead_appointment.appointment_status', $lead_status_fill);
        }
        if ($lead_fill != '') {
            $lead_ap_list->where(function ($query) use ($lead_fill) {
                $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        $user = auth()->user();
        if ($user->role_id == 15) {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $lead_ap_list = $lead_ap_list->where('et_lead_appointment.pc_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $lead_ap_list = $lead_ap_list;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        } else {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $lead_ap_list = $lead_ap_list->where('et_lead_appointment.staff_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $lead_ap_list = $lead_ap_list;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        }



        // if ($user->role_id == 15) {
        //     $lead_ap_list->where('et_lead_appointment.pc_id', $user->sno ?? $user->user_id);
        // } else {
        //     $lead_ap_list->where('et_lead_appointment.staff_id', $user->sno ?? $user->user_id);
        // }

        $lead_ap_list = $lead_ap_list->paginate($perpage);


        foreach ($lead_ap_list as $singleAppointment) {
            $end_status = 0;
            if ($singleAppointment->appointment_status == 1) {
                $appointmentDate = \Carbon\Carbon::parse($singleAppointment->appointment_date);
                $currentDateTime = \Carbon\Carbon::now();
                $end_status = $appointmentDate <= $currentDateTime ? 1 : 0;
            }

            $singleAppointment->end_status = $end_status;
        }
        // return date('Y-m-d H:i:s');
        // return \Carbon\Carbon::now();
        $pageConfigs  = ['myLayout' => 'default'];



        $staff_filter_list = StaffModel::where('status', 0)->where('branch_id', $branch_id)->where('department_id', 1)->orderBy('nick_name', 'ASC')->get();

        $completedCounts = LeadAppointmentModel::where('et_lead_appointment.appointment_status', "2")->where('et_lead_appointment.branch_id', $branch_id);
        if ($user->role_id == 15) {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $completedCounts = $completedCounts->where('et_lead_appointment.pc_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $completedCounts = $completedCounts;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        } else {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $completedCounts = $completedCounts->where('et_lead_appointment.staff_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $completedCounts = $completedCounts;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        }

        $completedCounts = $completedCounts->count();
        $cancelledCounts = LeadAppointmentModel::where('et_lead_appointment.appointment_status', "3")->where('et_lead_appointment.branch_id', $branch_id);
        if ($user->role_id == 15) {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $cancelledCounts = $cancelledCounts->where('et_lead_appointment.pc_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $cancelledCounts = $cancelledCounts;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        } else {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $cancelledCounts = $cancelledCounts->where('et_lead_appointment.staff_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $cancelledCounts = $cancelledCounts;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        }

        $cancelledCounts = $cancelledCounts->count();
        $pendingCounts   = LeadAppointmentModel::where('et_lead_appointment.appointment_status', "1")->where('et_lead_appointment.branch_id', $branch_id)->where('et_lead_appointment.appointment_date', '<=', \Carbon\Carbon::now());
        if ($user->role_id == 15) {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $pendingCounts = $pendingCounts->where('et_lead_appointment.pc_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $pendingCounts = $pendingCounts;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        } else {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $pendingCounts = $pendingCounts->where('et_lead_appointment.staff_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $pendingCounts = $pendingCounts;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        }

        $pendingCounts = $pendingCounts->count();
        $TotalCounts   = LeadAppointmentModel::where('et_lead_appointment.branch_id', $branch_id);

        if ($user->role_id == 15) {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $TotalCounts = $TotalCounts->where('et_lead_appointment.pc_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $TotalCounts = $TotalCounts;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        } else {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $TotalCounts = $TotalCounts->where('et_lead_appointment.staff_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $TotalCounts = $TotalCounts;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        }

        $TotalCounts = $TotalCounts->count();



        $completedCountsMonth = LeadAppointmentModel::where('et_lead_appointment.appointment_status', "2")->where('et_lead_appointment.branch_id', $branch_id)->whereMonth('et_lead_appointment.appointment_date', $currentMonth);
        if ($user->role_id == 15) {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $completedCountsMonth = $completedCountsMonth->where('et_lead_appointment.pc_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $completedCountsMonth = $completedCountsMonth;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        } else {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $completedCountsMonth = $completedCountsMonth->where('et_lead_appointment.staff_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $completedCountsMonth = $completedCountsMonth;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        }


        $completedCountsMonth = $completedCountsMonth->count();
        $cancelledCountsMonth = LeadAppointmentModel::where('et_lead_appointment.appointment_status', "3")->where('et_lead_appointment.branch_id', $branch_id)->whereMonth('et_lead_appointment.appointment_date', $currentMonth);
        if ($user->role_id == 15) {

            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $cancelledCountsMonth = $cancelledCountsMonth->where('et_lead_appointment.pc_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $cancelledCountsMonth = $cancelledCountsMonth;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        } else {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $cancelledCountsMonth = $cancelledCountsMonth->where('et_lead_appointment.staff_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $cancelledCountsMonth = $cancelledCountsMonth;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        }


        $cancelledCountsMonth = $cancelledCountsMonth->count();
        $pendingCountsMonth   = LeadAppointmentModel::where('et_lead_appointment.appointment_status', "1")->where('et_lead_appointment.branch_id', $branch_id)->whereMonth('et_lead_appointment.appointment_date', $currentMonth)->where('et_lead_appointment.appointment_date', '<=', \Carbon\Carbon::now());
        if ($user->role_id == 15) {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $pendingCountsMonth = $pendingCountsMonth->where('et_lead_appointment.pc_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $pendingCountsMonth = $pendingCountsMonth;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        } else {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $pendingCountsMonth = $pendingCountsMonth->where('et_lead_appointment.staff_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $pendingCountsMonth = $pendingCountsMonth;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        }


        $pendingCountsMonth = $pendingCountsMonth->count();

        $TotalCountsMonth   = LeadAppointmentModel::where('et_lead_appointment.branch_id', $branch_id)->whereMonth('et_lead_appointment.appointment_date', $currentMonth);
        if ($user->role_id == 15) {
            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $TotalCountsMonth = $TotalCountsMonth->where('et_lead_appointment.pc_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $TotalCountsMonth = $TotalCountsMonth;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        } else {

            if (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'view_self_cus')) {
                // User can only view their own data
                $TotalCountsMonth = $TotalCountsMonth->where('et_lead_appointment.staff_id', $user_id);
                // return "view_self_cus";
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Appointment', 'global_cus')) {
                // User can view all data
                $TotalCountsMonth = $TotalCountsMonth;
                // return "global_cus";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        }


        $TotalCountsMonth = $TotalCountsMonth->count();

        $successAppointmentRate = $TotalCounts > 0 ? ($completedCounts / $TotalCounts) * 100 : 0;
        $failAppointmentRate = $TotalCounts > 0 ? ($cancelledCounts / $TotalCounts) * 100 : 0;

        // month
        $successAppointmentRateMonth = $TotalCountsMonth > 0 ? ($completedCountsMonth / $TotalCountsMonth) * 100 : 0;
        $failAppointmentRateMonth = $TotalCountsMonth > 0 ? ($cancelledCountsMonth / $TotalCountsMonth) * 100 : 0;

        // return $lead_ap_list;


        // if($user->role_id == 15 || $user->role_id == 1){
        return view('content.production_management.production_appointment.production_appointment', [
            'perpage'           => $perpage,
            'lead_ap_list'      => $lead_ap_list,
            'pageConfigs'       => $pageConfigs,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'lead_status_fill'  => $lead_status_fill,
            'date_filter'       => $date_filter,
            'staff_fill'        => $staff_fill,
            'lead_fill'         => $lead_fill,
            'fin_yr_fill'       => $fin_yr_fill,
            'staff_filter_list' => $staff_filter_list,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,
        ])->with('filter_on', false);
        // } else {
        //     return view('content.production_management.production_appointment.production_appointment_staff', [
        //         'perpage'           => $perpage,
        //         'lead_ap_list'      => $lead_ap_list,
        //         'pageConfigs'       => $pageConfigs,
        //         'cancelledCounts'   => $cancelledCounts,
        //         'completedCounts'   => $completedCounts,
        //         'pendingCounts'     => $pendingCounts,
        //         'lead_status_fill'  => $lead_status_fill,
        //         'date_filter'       => $date_filter,
        //         'staff_fill'        => $staff_fill,
        //         'lead_fill'         => $lead_fill,
        //         'fin_yr_fill'       => $fin_yr_fill,
        //         'staff_filter_list' => $staff_filter_list,
        //         'successAppointmentRate' => $successAppointmentRate,
        //         'failAppointmentRate' => $failAppointmentRate,
        //         'successAppointmentRateMonth' => $successAppointmentRateMonth,
        //         'failAppointmentRateMonth' => $failAppointmentRateMonth,
        //         'cancelledCountsMonth'   => $cancelledCountsMonth,
        //         'completedCountsMonth'   => $completedCountsMonth,
        //         'pendingCountsMonth'     => $pendingCountsMonth,
        //         'TotalCountsMonth'     => $TotalCountsMonth,
        //         'TotalCounts'     => $TotalCounts,
        //         'currentMonth'     => $currentMonth,
        //         'currentYear'     => $currentYear,
        //     ])->with('filter_on', false);
        // }
    }



    //Add Appointment
    public function Add(Request $request)
    {
        // return $request;
        $branch_id = $request->user()->branch_id ?? 1;
        $validator = Validator::make($request->all(), [
            'lead_id_add' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $lead_id = $request->lead_id_add;
            $appointment_category = $request->appt_catg_add;
            $appointment_date = date('Y-m-d H:i:s', strtotime($request->ld_appt_dt_add));
            $appointment_reason = $request->appt_reason_add;
            $dept_id = $request->assg_dept_add;
            $staff_id = $request->assg_staff_add;
            $user_id = $request->user()->user_id ?? 1;

            $lead_appt_chk = LeadAppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$lead_appt_chk) {

                $year = substr(date('y'), -2);
                $lead_appointment_id = 'LDAP-0001/' . $year;
            } else {

                $data = $lead_appt_chk->lead_appointment_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);

                $next_number = (int) $result + 1;
                $request = sprintf('LDAP-%04d', $next_number);

                $year = substr(date('y'), -2);
                $lead_appointment_id = $request . '/' . $year;
            }

            $add_ld_appt = new LeadAppointmentModel();
            $add_ld_appt->lead_appointment_id = $lead_appointment_id;
            $add_ld_appt->lead_id = $lead_id;
            $add_ld_appt->appointment_category = $appointment_category;
            $add_ld_appt->appointment_date = $appointment_date;
            $add_ld_appt->appointment_reason = $appointment_reason;
            $add_ld_appt->department_id = $dept_id;

            // Save PC id if it is production.
            if ($dept_id == 2) {
                $add_ld_appt->pc_id = $staff_id;
            } else {
                $add_ld_appt->staff_id = $staff_id;
            }

            $add_ld_appt->branch_id = $branch_id;
            $add_ld_appt->created_by = $user_id;
            $add_ld_appt->updated_by = $user_id;

            $add_ld_appt->save();

            if ($add_ld_appt) {
                if ($appointment_category == 'Walk-in') {

                    //****************** */ Update Staff Sales Person Points
                    // Define point category:
                    // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
                    $helper = new \App\Helpers\Helpers();
                    $pointsData = $helper->get_points_by_id(14);
                    $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
                    $reason = $pointsData ? $pointsData->points_name : 'Walk-IN'; // Default reason to an empty string
                    // Save new points for the staff
                    $newPoints = new StaffpointsModel();
                    $newPoints->branch_id = $branch_id;
                    $newPoints->staff_id  = $user_id;
                    $newPoints->points_by = $add_ld_appt->sno;
                    $newPoints->points_id = 14;
                    $newPoints->points = $point;
                    $newPoints->reason = $reason;
                    $newPoints->save();

                    // Update staff's available points
                    $staff_points = StaffModel::where('sno', $user_id)->first();
                    if ($staff_points) {
                        $staff_points->avaiable_points += $point; // Increment the available points
                        $staff_points->save();
                    }
                }
            }
            $branch_data = BranchModel::select('et_branch.*', 'et_cities.name as city_name', 'et_states.name as state_name')->where('et_branch.sno', $branch_id)->leftJoin('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
                ->leftJoin('et_states', 'et_states.id', '=', 'et_branch.state_id')->first();
            $branch_name = " ";
            if ($branch_data->branch_type == 1) {
                $branch_name = $branch_data->branch_name;
            } elseif ($branch_data->branch_type == 2) {
                $branch_name = $branch_data->franchise_name;
            }

            $address = ($branch_data->door_no ? $branch_data->door_no . ", " : "")
                . ($branch_data->area_street ? $branch_data->area_street . ", " : "")
                . ($branch_data->city_name ? $branch_data->city_name . ", " : "")
                . ($branch_data->state_name ? $branch_data->state_name : "")
                . ($branch_data->pincode ? " - " . $branch_data->pincode : "");
            // // appointment sms
            //  if ($add_ld_appt) {
            //     $branch_data     = BranchModel::where('sno', $branch_id)->first();
            //     $lead_data       = LeadModel::where('sno', $lead_id)->where('status', '!=', 2)->first();
            //     $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '002_AppointmentSchedule')->first();
            //     $authkey         = $result_sms ? $result_sms->authkey : '';
            //     $sender_id       = $result_sms ? $result_sms->sender_id : '';
            //     $template_id     = $result_sms ? $result_sms->template_id : '';
            //     $country_code    = $result_sms ? $result_sms->country_code : '';
            //     $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
            //     $mobile_number   = $country_code . $lead_data->lead_mobile;
            //     $cre_mobile      = $branch_data->cre_mobile ?? '7558184348';

            //     $formattedDate = Carbon::parse($appointment_date)->format('d M Y'); // e.g., 11 Jan 2025
            //     $formattedTime = Carbon::parse($appointment_date)->format('h:i A');

            //     // Replace placeholders with actual values
            //     $replacement_values = [$lead_data->lead_name, $formattedDate, $formattedTime, $cre_mobile];
            //     $message_content    = preg_replace_callback(
            //         '/\{#var#\}/',
            //         function () use (&$replacement_values) {
            //             return array_shift($replacement_values);
            //         },
            //         $message_content
            //     );

            //     $route    = "default";
            //     $postData = [
            //         'authkey' => $authkey,
            //         'mobiles' => $mobile_number,
            //         'message' => $message_content,
            //         'sender'  => $sender_id,
            //         'route'   => $route,
            //     ];

            //     // API URL
            //     $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

            //     // Initialize the resource
            //     $ch = curl_init();
            //     curl_setopt_array($ch, [
            //         CURLOPT_URL            => $url,
            //         CURLOPT_RETURNTRANSFER => true,
            //         CURLOPT_POST           => true,
            //         CURLOPT_POSTFIELDS     => $postData,
            //         CURLOPT_SSL_VERIFYHOST => 0,
            //         CURLOPT_SSL_VERIFYPEER => 0,
            //     ]);

            //     // Get response
            //     $response = curl_exec($ch);
            //     // return $response;
            //     $err = curl_error($ch);
            //     curl_close($ch);
            // }
            // // appointment email
            // $lead_data = LeadModel::where('sno', $lead_id)->where('status', '!=', 2)->first();
            // if ($add_ld_appt && $lead_data->lead_email_id) {
            //     $email_template_id = 5; // appointment template
            //     $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

            //     // Format the start and end date into a readable format (e.g., 22 May 2024)
            //     $formattedDate = Carbon::parse($appointment_date)->format('d M Y'); // e.g., 11 Jan 2025
            //     $formattedTime = Carbon::parse($appointment_date)->format('h:i A'); // e.g., 03:30 PM

            //     $content = $emailTemplate->email_subject;
            //     $content = str_replace('#name', $lead_data->lead_name, $content);
            //     $content = str_replace('#date', $formattedDate, $content);
            //     $content = str_replace('#time', $formattedTime, $content);
            //     $content = str_replace('#location', $address, $content);
            //     $branchNo = $branch_data->mobile;
            //     $branchemail = $branch_data->mail;
            //     $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
            //     $instaLink = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
            //     $content = str_replace('#salesNo', $branch_data->sales_mobile ?? 'Branch Mobile', $content);
            //     $content = str_replace('#BranchName', $branch_name ?? 'Branch Name', $content);

            //     $mailData = [
            //         'url' => 'Eapl.com',
            //         'subject' => $emailTemplate->email_name,
            //         'content' => $content,
            //         'branchNo' => $branchNo,
            //         'branchemail' => $branchemail, // Use the message content from the request
            //         'fbLink' => $fbLink, // Use the message content from the request
            //         'instaLink' => $instaLink, // Use the message content from the request
            //         'salesMobile' => $branch_data->sales_mobile,
            //     ];

            //     $to_address = $lead_data->lead_email_id;
            //     $from_address = 'elysiumacademy@elysium.community';
            //     $from_name = 'Elysium Academy®';
            //     Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
            // }


            // if ($add_ld_appt) {
            //     $templateName  = "elysium_academy_appoint_message";
            //     $lead_data     = LeadModel::where('sno', $lead_id)->where('status', '!=', 2)->first();
            //     $formattedDate = Carbon::parse($appointment_date)->format('d M Y'); // e.g., 11 Jan 2025
            //     $formattedTime = Carbon::parse($appointment_date)->format('h:i A');

            //     $hasHeader  = false; // Example flag: set based on template
            //     $hasBody    = false; // Example flag: set based on template
            //     $hasFooter  = false; // Example flag: set based on template
            //     $hasButton  = false;
            //     $components = [];
            //     $couponCode = " ";
            //     date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
            //     $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
            //                                               // $currentHour = date('H'); // Get current hour in 24-hour format
            //     if ($currentHour >= 5 && $currentHour < 12) {
            //         $greeting = 'Good Morning';
            //     } elseif ($currentHour >= 12 && $currentHour < 18) {
            //         $greeting = 'Good Afternoon';
            //     } else {
            //         $greeting = 'Good Evening';
            //     }

            //     if ($templateName == 'elysium_academy_appoint_message') {
            //         $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Appointment_Header.jpg';
            //         $couponCode  = 'NOOFFER';
            //         $buttonIndex = 1;
            //         $bodyText    = [
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $greeting,
            //                 'parameter_name' => 'greet_msg',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $lead_data->lead_name,
            //                 'parameter_name' => 'customer_name',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $formattedDate,
            //                 'parameter_name' => 'app_date',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $formattedTime,
            //                 'parameter_name' => 'app_time',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $address ?? '227, IInd Floor, B Block, Elysium Campus, Church Rd, Anna Nagar, Madurai 625020',
            //                 'parameter_name' => 'app_location',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $branch_data->cre_mobile ?? '7708053111',
            //                 'parameter_name' => 'contact1_no',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $branch_name,
            //                 'parameter_name' => 'branch_name',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $branch_data->cre_mobile ?? '7708053111',
            //                 'parameter_name' => 'contact_no',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
            //                 'parameter_name' => 'contact_email',
            //             ],
            //         ];
            //         $hasHeader = true;
            //         $hasBody   = true;
            //         $hasButton = true;
            //     }

            //     // Add Header if required
            //     if ($hasHeader) {
            //         $components[] = [
            //             'type'       => 'header',
            //             'parameters' => [
            //                 [
            //                     'type'  => 'image',
            //                     'image' => [
            //                         'link' => $headerImage, // Dynamically set header image
            //                     ],
            //                 ],
            //             ],
            //         ];
            //     }

            //     // Add Body if required
            //     if ($hasBody) {
            //         $components[] = [
            //             'type'       => 'body',
            //             'parameters' => $bodyText,
            //         ];
            //     }

            //     // Add Footer if required
            //     if ($hasFooter) {
            //         $components[] = [
            //             'type'       => 'footer',
            //             'parameters' => [
            //                 [
            //                     'type'           => 'text',
            //                     'text'           => 'This is the footer text.',
            //                     'parameter_name' => 'footer_text',
            //                 ],
            //             ],
            //         ];
            //     }

            //     // Add Button if required
            //     if ($hasButton) {
            //         $components[] = [
            //             'type'       => 'button',
            //             'sub_type'   => 'copy_code',
            //             'index'      => $buttonIndex,
            //             'parameters' => [
            //                 [
            //                     'type'        => 'coupon_code',
            //                     'coupon_code' => $couponCode,
            //                 ],
            //             ],
            //         ];

            //     }

            //     $dynamicParameters         = $templateParameters[$templateName] ?? [];
            //     $WhatsAppBusinessAccountId = $this->businessId;
            //     $accessToken               = $this->accessToken;
            //     $fromPhoneNumberId         = $this->phoneNumberId;

            //     $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

            //     $to           = $lead_data->lead_mobile;
            //     $languageCode = 'en_US';

            //     if (strpos($to, '+91') !== 0) {
            //         $to = '+91' . $to;
            //     }

            //     $message = 'test~message';
            //     if (empty($components)) {
            //         $payload = [
            //             'messaging_product' => 'whatsapp',
            //             'to'                => $to,
            //             'type'              => 'template',
            //             'template'          => [
            //                 'name'     => $templateName,
            //                 'language' => [
            //                     'code' => $languageCode,
            //                 ],
            //             ],
            //         ];
            //     } else {
            //         $payload = [
            //             'messaging_product' => 'whatsapp',
            //             'to'                => $to,
            //             'type'              => 'template',
            //             'template'          => [
            //                 'name'       => $templateName,
            //                 'language'   => [
            //                     'code' => $languageCode,
            //                 ],
            //                 'components' => $components,
            //             ],
            //         ];
            //     }

            //     $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
            // }

            if ($add_ld_appt) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Lead Appointment added Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Lead Appointment!',
                ]);
            }

            return redirect('manage_appointment');
        }
    }

    // update Appointment
    public function Update(Request $request)
    {
        // return $request;

        $validator = Validator::make($request->all(), [
            'lead_id_edit' => 'required|max:255',
            'ld_appt_id_edit' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $lead_id = $request->lead_id_edit;
            $appointment_category = $request->appt_category_edit;
            $appointment_date = date('Y-m-d H:i:s', strtotime($request->ld_appt_dt_edit));
            $appointment_reason = $request->reason_msg_edit;
            $dept_id = $request->assg_dept_edit;
            $staff_id = $request->assgn_staff_edit;
            $appt_id = $request->ld_appt_id_edit;

            $user_id = $request->user()->user_id ?? 1;
            $upd_ld_appt = LeadAppointmentModel::where('sno', $appt_id)->first();

            // $chk = LeadAppointmentModel::where('lead_id', $lead_id)->where('branch_id', self::$branch_id)->where('sno', '!=', $appt_id)->where('status', '!=', 2)->first();

            // if ($chk) {
            //     session()->flash('toastr', [
            //         'type' => 'error',
            //         'message' => 'Already Lead Appointment is exist!',
            //     ]);
            //     return redirect()->back();
            // } else {

            $upd_ld_appt->lead_id = $lead_id;
            $upd_ld_appt->appointment_category = $appointment_category;
            $upd_ld_appt->appointment_date = $appointment_date;
            $upd_ld_appt->appointment_reason = $appointment_reason;
            $upd_ld_appt->department_id = $dept_id;
            $upd_ld_appt->staff_id = $staff_id;
            $upd_ld_appt->created_by = $user_id;
            $upd_ld_appt->updated_by = $user_id;
            $upd_ld_appt->update();

            if ($upd_ld_appt) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Lead Appointment Update Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the Lead Appointment!',
                ]);
            }
            // }
        }
        return redirect()->back();
    }

    //appointment completed
    public function updateCompleteAppointment(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'conversation_msg_scr' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $convo_message_score = $request->conversation_msg_scr;
            $lead_type = $request->lead_type_cmplt;
            $convo_message = $request->conversion_message;
            $appointment_status = 2;
            $appt_id = $request->lead_id_complete;
            $user_id = $request->user()->user_id ?? 1;
            $upd_ld_appt = LeadAppointmentModel::where('sno', $appt_id)->first();

            $upd_ld_appt->convo_message_score = $convo_message_score;
            $upd_ld_appt->lead_type = $lead_type;
            $upd_ld_appt->convo_message = $convo_message;
            $upd_ld_appt->appointment_status = $appointment_status;
            // $upd_ld_appt->re_appointment_date = null;
            $upd_ld_appt->status_reason_message = null;
            $upd_ld_appt->created_by = $user_id;
            $upd_ld_appt->updated_by = $user_id;
            $upd_ld_appt->update();

            if ($upd_ld_appt) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Appointment Status Update Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the Appointment Status',
                ]);
            }
        }
        return redirect()->back();
    }
    //appointment cancelled
    public function updateCancelAppointment(Request $request)
    {

        // return $request;

        $validator = Validator::make($request->all(), [
            'cancel_reason_msg' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $appt_id = $request->lead_id_cancel;
            $status_reason_message = $request->cancel_reason_msg;
            $appointment_status = 3;
            $user_id = $request->user()->user_id ?? 1;
            $upd_ld_appt = LeadAppointmentModel::where('sno', $appt_id)->first();

            $upd_ld_appt->status_reason_message = $status_reason_message;
            $upd_ld_appt->appointment_status = $appointment_status;
            // $upd_ld_appt->re_appointment_date = null;
            $upd_ld_appt->created_by = $user_id;
            $upd_ld_appt->updated_by = $user_id;
            $upd_ld_appt->update();

            if ($upd_ld_appt) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Appointment Status Update Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the Appointment Status',
                ]);
            }
        }
        return redirect()->back();
    }

    //appointment Re-appointment
    public function updateReAppointment(Request $request)
    {

        // return $request;

        $validator = Validator::make($request->all(), [
            're_appt_reason_msg' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $appt_id = $request->lead_id_re_appt;
            $re_appointment_date = date('Y-m-d H:i:s', strtotime($request->re_appt_date));
            $status_reason_message = $request->re_appt_reason_msg;
            $appointment_status = 4;
            $user_id = $request->user()->user_id ?? 1;
            $upd_ld_appt = LeadAppointmentModel::where('sno', $appt_id)->first();

            $upd_ld_appt->re_appointment_date = $re_appointment_date;
            $upd_ld_appt->status_reason_message = $status_reason_message;
            $upd_ld_appt->appointment_status = $appointment_status;
            $upd_ld_appt->created_by = $user_id;
            $upd_ld_appt->updated_by = $user_id;
            $upd_ld_appt->update();

            if ($upd_ld_appt) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Appointment Status Update Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the Appointment Status',
                ]);
            }
        }
        return redirect()->back();
    }

    public function autocomplete_lead(Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $search = $request->get('term');

        // Use a closure to properly group the orWhere condition
        $results = LeadModel::where(function ($query) use ($search) {
            $query->where('lead_name', 'LIKE', '%' . $search . '%')
                ->orWhere('lead_mobile', 'LIKE', '%' . $search . '%')
                ->orWhere('lead_email_id', 'LIKE', '%' . $search . '%')
                ->orWhere('lead_id', 'LIKE', '%' . $search . '%');
        })
            ->where('status', 0)
            ->get();

        return response()->json($results);
    }

    public function SalesStaffList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $dept_id = 1;
        $staff     = StaffModel::select('et_staff.*', 'et_job_position.job_position_name as position_name')->where('et_staff.status', 0)->where('et_staff.department_id', $dept_id)->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role");
        // ->where('branch_id', $branch_id)
        if ($branch_id != 0) {
            $staff->where('et_staff.branch_id', $branch_id);
        }
        $staff = $staff->orderBy('et_staff.staff_name', 'asc')
            ->distinct() // Ensure unique rows
            ->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $staff,
        ], 200);
    }
    public function DeptStaffList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $dept_id = $request->input('dept_id');
        $staff     = StaffModel::select('et_staff.*', 'et_job_position.job_position_name as position_name')->where('et_staff.status', 0)->where('et_staff.department_id', $dept_id)->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role");
        // ->where('branch_id', $branch_id)
        if ($branch_id != 0) {
            $staff->where('et_staff.branch_id', $branch_id);
        }
        $staff = $staff->orderBy('et_staff.staff_name', 'asc')
            ->distinct() // Ensure unique rows
            ->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $staff,
        ], 200);
    }
    // whatsapp config
    private function sendRequestToWhatsApp($url, $token, $data)
    {
        try {
            $client   = new \GuzzleHttp\Client();
            $response = $client->post($url, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json',
                ],
                'json'    => $data,
            ]);

            return [
                'status' => $response->getStatusCode(),
                'data'   => json_decode($response->getBody()->getContents(), true),
            ];
        } catch (\Exception $e) {
            return [
                'status' => 400,
                'error'  => $e->getMessage(),
            ];
        }
    }

    public function AssignStaffAppointment(Request $request)
    {
        $id = $request->assign_requirement_id;
        $user_id = $request->user()->user_id ?? 1;

        $updated = DB::table('et_lead_appointment')
            ->where('sno', $id)
            ->update([
                'staff_id'   => $request->assign_staff_id,
                'updated_by' => $user_id
            ]);

        if ($updated) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Staff Updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could Not Update!'
            ]);
        }

        return redirect()->back();
    }
}
