<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManageTaskModel;
use App\Models\ManageTaskChecklistModel;
use App\Models\ReworkReasonModel;
use App\Models\StaffModel;
use App\Models\TaskLogModel;
use Carbon\Carbon;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;

class ManageProduction extends Controller
{
  public function index(Request $request)
  {
    $entity_id   = $request->user()->entity_id;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $search_fill = $request->search_fill ?? '';
    $cat_fill = $request->cat_fill ?? '';
    $product_fill = $request->product_fill ?? '';
    $status_fill = $request->status_fill ?? '';
    $filter_on = $request->filter_on ?? '';
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;


    // Fetch all tasks with joins
    $allTasks = ManageTaskModel::select(
      'et_task.*',
      'et_customer.cus_name',
      'et_customer.cus_mobile',
      'et_customer.cus_email_id',
      'et_customer.country_code',
      'et_customer.customer_id AS cus_id',
      'et_product.duration',
      'et_product.duration_in',
      'et_product_category.product_category_name',
      'et_product_category.jouranal_check',
      'et_product_task.task_name as product_task_name',
      DB::raw("CASE 
            WHEN et_customer_services.product_package = 1 THEN et_product.product_name
            WHEN et_customer_services.product_package = 2 THEN et_package.package_name
            ELSE NULL
        END as product_name")
    )
      ->where('et_task.branch_id', $branch_id)
      ->where('et_task.status', '!=', 2)
      ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
      ->leftJoin('et_customer_services', 'et_task.service_id', 'et_customer_services.sno')
      ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
      ->leftJoin('et_product', function ($join) {
        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
          ->where('et_customer_services.product_package', '=', 1);
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->orderBy('et_task.sno', 'desc');

    if (auth()->user()->hasPermissionradio('Production Management', 'Manage Production', 'view_self_production')) {
      // User can only view their own data
      $allTasks = $allTasks->whereRaw('JSON_CONTAINS(et_task.assign_staffs, ?)', [json_encode((string)$user_id)]);
    } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Production', 'global_production')) {
      // User can view all data — no extra filter needed
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }

    $allTasks = $allTasks->get();



    $list_page = [];

    $today = Carbon::today()->toDateString();
    $userTasksByDate = [];

    // Group tasks by date and only include ones assigned to this user
    foreach ($allTasks as $task) {
      $assignStaffArray = json_decode($task->assign_staffs, true) ?? [];

      // Skip tasks not assigned to current user
      if (!in_array((string)$user_id, $assignStaffArray)) {
        continue;
      }

      $taskDate = Carbon::parse($task->start_date_time)->toDateString();
      $userTasksByDate[$taskDate][] = $task;
    }

    // Sort by date ascending
    ksort($userTasksByDate);

    // Determine the first date where at least one task is NOT completed
    $selectedDate = null;
    foreach ($userTasksByDate as $date => $tasksOnDate) {
      $allCompleted = true;
      foreach ($tasksOnDate as $task) {
        if ($task->status != 3) {
          $allCompleted = false;
          break;
        }
      }

      if (!$allCompleted) {
        $selectedDate = $date;
        break;
      }
    }

    // If all tasks are completed (very rare), show nothing or fallback to today
    if (!$selectedDate && isset($userTasksByDate[$today])) {
      $selectedDate = $today;
    }

    // Build the list page based on selectedDate
    $list_page = [];

    if ($selectedDate && isset($userTasksByDate[$selectedDate])) {
      foreach ($userTasksByDate[$selectedDate] as $task) {
        $staff_details = StaffModel::select('et_staff.nick_name', 'et_staff.staff_image', 'et_staff.staff_name', 'et_staff.gender', 'et_job_position.job_position_name')
          ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
          ->where('et_staff.status', 0)
          ->where('et_staff.sno', $user_id)
          ->first();

        $list_page[] = [
          'sno'                   => $task->sno,
          'branch_id'             => $task->branch_id,
          'service_id'            => $task->service_id,
          'task_id'               => $task->task_id,
          'task_name'             => $task->task_name,
          'working_hours'         => $task->working_hours,
          'start_date_time'       => $task->start_date_time,
          'end_date_time'         => $task->end_date_time,
          'usage_hours'           => $task->usage_hours,
          'task_completed_date_time' => $task->task_completed_date_time,
          'task_completed_by'     => $task->task_completed_by,
          'per_hour_cost'         => $task->per_hour_cost,
          'billable'              => $task->billable,
          'assign_staff_id'       => $user_id,
          'staff_name'            => $staff_details->staff_name,
          'nick_name'             => $staff_details->nick_name,
          'staff_image'           => $staff_details->staff_image,
          'gender'                => $staff_details->gender,
          'task_check_list_ids'   => $task->task_check_list_ids,
          'task_desc'             => $task->task_desc,
          'created_by'            => $task->created_by,
          'created_at'            => $task->created_at,
          'updated_by'            => $task->updated_by,
          'updated_at'            => $task->updated_at,
          'status'                => $task->status,
          'cus_name'              => $task->cus_name,
          'cus_mobile'            => $task->cus_mobile,
          'cus_email_id'          => $task->cus_email_id,
          'country_code'          => $task->country_code,
          'cus_id'                => $task->cus_id,
          'product_name'          => $task->product_name,
          'duration'              => $task->duration,
          'duration_in'           => $task->duration_in,
          'product_category_name' => $task->product_category_name,
          'jouranal_check'        => $task->jouranal_check,
          'product_task_name'     => $task->product_task_name
        ];
      }
    }


    // Manual Pagination
    $collection = collect($list_page);
    $currentPageItems = $collection->slice($offset, $perpage)->values();

    $paginatedList = new LengthAwarePaginator(
      $currentPageItems,
      $collection->count(),
      $perpage,
      $page,
      ['path' => request()->url(), 'query' => request()->query()]
    );

    $Product_cat_list  = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name', 'ASC')->get();
    $Product_list      = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name', 'ASC')->get();
    $staff_list        = DB::table('et_staff')->where('status', 0)->where('sno', '>', 1)->where('branch_id', $branch_id)->orderBy('staff_name', 'ASC')->get();


    return view('content.production_management.manage_production.list', [
      'ListTable' => $paginatedList,
      'perpage' => $perpage,
      'search_fill' => $search_fill,
      'cat_fill' => $cat_fill,
      'product_fill' => $product_fill,
      'status_fill' => $status_fill,
      'filter_on' => $filter_on,
      'Product_cat_list' => $Product_cat_list,
      'Product_ist' => $Product_list,
      'Staff_list' => $staff_list
    ]);
  }
  public function index_ajax(Request $request)
  {
    $entity_id   = $request->user()->entity_id;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $search_fill = $request->search_fill ?? '';
    $cat_fill = $request->cat_fill ?? '';
    $product_fill = $request->product_fill ?? '';
    $status_fill = $request->status_fill ?? '';
    $filter_on = $request->filter_on ?? '';
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;


    // Fetch all tasks with joins
    $allTasks = ManageTaskModel::select(
      'et_task.*',
      'et_customer.cus_name',
      'et_customer.cus_mobile',
      'et_customer.cus_email_id',
      'et_customer.country_code',
      'et_customer.customer_id AS cus_id',
      'et_product.duration',
      'et_product.duration_in',
      'et_product_category.product_category_name',
      'et_product_category.jouranal_check',
      'et_product_task.task_name as product_task_name',
      DB::raw("CASE 
            WHEN et_customer_services.product_package = 1 THEN et_product.product_name
            WHEN et_customer_services.product_package = 2 THEN et_package.package_name
            ELSE NULL
        END as product_name")
    )
      ->where('et_task.branch_id', $branch_id)
      ->where('et_task.status', '!=', 2)
      ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
      ->leftJoin('et_customer_services', 'et_task.service_id', 'et_customer_services.sno')
      ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
      ->leftJoin('et_product', function ($join) {
        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
          ->where('et_customer_services.product_package', '=', 1);
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->orderBy('et_task.sno', 'desc');

    if (auth()->user()->hasPermissionradio('Production Management', 'Manage Production', 'view_self_production')) {
      // User can only view their own data
      $allTasks = $allTasks->whereRaw('JSON_CONTAINS(et_task.assign_staffs, ?)', [json_encode((string)$user_id)]);
    } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Production', 'global_production')) {
      // User can view all data — no extra filter needed
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }

    $allTasks = $allTasks->get();



    $today = Carbon::today()->toDateString();
    $userTasksByDate = [];

    // Group tasks by date and only include ones assigned to this user
    foreach ($allTasks as $task) {
      $assignStaffArray = json_decode($task->assign_staffs, true) ?? [];

      // Skip tasks not assigned to current user
      if (!in_array((string)$user_id, $assignStaffArray)) {
        continue;
      }

      $taskDate = Carbon::parse($task->start_date_time)->toDateString();
      $userTasksByDate[$taskDate][] = $task;
    }

    // Sort by date ascending
    ksort($userTasksByDate);

    // Determine the first date where at least one task is NOT completed
    $selectedDate = null;
    foreach ($userTasksByDate as $date => $tasksOnDate) {
      $allCompleted = true;
      foreach ($tasksOnDate as $task) {
        if ($task->status != 3) {
          $allCompleted = false;
          break;
        }
      }

      if (!$allCompleted) {
        $selectedDate = $date;
        break;
      }
    }

    // If all tasks are completed (very rare), show nothing or fallback to today
    if (!$selectedDate && isset($userTasksByDate[$today])) {
      $selectedDate = $today;
    }

    // Build the list page based on selectedDate
    $list_page = [];

    if ($selectedDate && isset($userTasksByDate[$selectedDate])) {
      foreach ($userTasksByDate[$selectedDate] as $task) {
        $staff_details = StaffModel::select('et_staff.nick_name', 'et_staff.staff_image', 'et_staff.staff_name', 'et_staff.gender', 'et_job_position.job_position_name')
          ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
          ->where('et_staff.status', 0)
          ->where('et_staff.sno', $user_id)
          ->first();

        $list_page[] = [
          'sno'                   => $task->sno,
          'branch_id'             => $task->branch_id,
          'service_id'            => $task->service_id,
          'task_id'               => $task->task_id,
          'task_name'             => $task->task_name,
          'working_hours'         => $task->working_hours,
          'start_date_time'       => $task->start_date_time,
          'end_date_time'         => $task->end_date_time,
          'usage_hours'           => $task->usage_hours,
          'task_completed_date_time' => $task->task_completed_date_time,
          'task_completed_by'     => $task->task_completed_by,
          'per_hour_cost'         => $task->per_hour_cost,
          'billable'              => $task->billable,
          'assign_staff_id'       => $user_id,
          'staff_name'            => $staff_details->staff_name,
          'nick_name'             => $staff_details->nick_name,
          'staff_image'           => $staff_details->staff_image,
          'gender'                => $staff_details->gender,
          'task_check_list_ids'   => $task->task_check_list_ids,
          'task_desc'             => $task->task_desc,
          'created_by'            => $task->created_by,
          'created_at'            => $task->created_at,
          'updated_by'            => $task->updated_by,
          'updated_at'            => $task->updated_at,
          'status'                => $task->status,
          'cus_name'              => $task->cus_name,
          'cus_mobile'            => $task->cus_mobile,
          'cus_email_id'          => $task->cus_email_id,
          'country_code'          => $task->country_code,
          'cus_id'                => $task->cus_id,
          'product_name'          => $task->product_name,
          'duration'              => $task->duration,
          'duration_in'           => $task->duration_in,
          'product_category_name' => $task->product_category_name,
          'jouranal_check'        => $task->jouranal_check,
          'product_task_name'     => $task->product_task_name
        ];
      }
    }


    // Manual Pagination
    $collection = collect($list_page);
    $currentPageItems = $collection->slice($offset, $perpage)->values();

    $paginatedList = new LengthAwarePaginator(
      $currentPageItems,
      $collection->count(),
      $perpage,
      $page,
      ['path' => request()->url(), 'query' => request()->query()]
    );

    $Product_cat_list  = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name', 'ASC')->get();
    $Product_list      = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name', 'ASC')->get();
    $staff_list        = DB::table('et_staff')->where('status', 0)->where('sno', '>', 1)->where('branch_id', $branch_id)->orderBy('staff_name', 'ASC')->get();


    // At the end of index_ajax method

    $html = view('content.production_management.manage_production.list_ajax', [
      'ListTable' => $paginatedList,
      'perpage' => $perpage,
      'search_fill' => $search_fill,
      'cat_fill' => $cat_fill,
      'product_fill' => $product_fill,
      'status_fill' => $status_fill,
      'filter_on' => $filter_on,
      'Product_cat_list' => $Product_cat_list,
      'Product_list' => $Product_list,  // fixed typo here ('Product_ist' -> 'Product_list')
      'Staff_list' => $staff_list
    ])->render();

    return response()->json([
      'data' => $html
    ]);
  }
  
  
  public function Task_view($id)
  {
    $helper =  new \App\Helpers\Helpers();
    $task_data =  ManageTaskModel::select(
      'et_task.*',
      'et_staff.staff_name AS created_staff_name',
      'et_customer.cus_name',
      'et_customer.cus_mobile',
      'et_customer.cus_email_id',
      'et_customer.country_code',
      'et_customer.customer_id AS cus_id',
      'et_product_category.product_category_name',
      'et_product_category.product_category_name',
      'et_product_category.jouranal_check',
      'et_customer_services.proposal_id',
      'et_product_task.task_name as product_task_name',
      DB::raw("CASE 
            WHEN et_customer_services.product_package = 1 THEN et_product.product_name
            WHEN et_customer_services.product_package = 2 THEN et_package.package_name
            ELSE NULL
        END as product_name")
    )
      ->where('et_task.status', '!=', 2)
      ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
      ->leftJoin('et_customer_services', 'et_task.service_id', 'et_customer_services.sno')
      ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
      ->leftJoin('et_product', function ($join) {
        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
          ->where('et_customer_services.product_package', '=', 1);
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->leftJoin('et_staff', 'et_task.created_by', 'et_staff.sno')
      ->where('et_task.sno', $id)->first();
    $start_date_time = $task_data->start_date_time ? date("d-M-Y h:i A", strtotime($task_data->start_date_time)) : '-';
    $end_date_time = $task_data->end_date_time ? date("d-M-Y h:i A", strtotime($task_data->end_date_time)) : '-';
    $check_list = json_decode($task_data->task_check_list_ids, true);
    $check_list_count = is_array($check_list) ? count($check_list) : 0;
    $completed_count  = $helper->completed_task_details($id) ?? 0;
    $balance_count    = $check_list_count - $completed_count;
    $html = '';

    if ($task_data) {
      $productList = DB::table('et_customer_services')
            ->select(
                'et_customer_services.*',
                'et_product_category.product_category_name',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as product_name")
            )
            ->where('et_customer_services.proposal_id', $task_data->proposal_id)
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
            ->orderBy('et_customer_services.sno', 'desc')
            ->where('et_customer_services.sno', $task_data->service_id)
            ->get();  // <-- collection of products

      // For each product, decode variant_variable_ids and fetch related details
      foreach ($productList as $product) {

        $variant_variable_data = json_decode($product->variant_variable_ids ?? '[]', true);

        if (!empty($variant_variable_data)) {
          foreach ($variant_variable_data as $cart_item) {
            $variant_name = $helper->get_variant_data_by_id($cart_item['variant_id'])->product_variant_name ?? 'N/A';
            $variable_name = $helper->get_variable_data_by_id($cart_item['variable_id'])->variable_name ?? 'N/A';
          }
        }
      }
        
        // Assign back to task_data
        $task_data->product_list = $productList;
      

      $html .= '
        <div class="row mb-4">
                    <div class="col-lg-12 text-black fs-5 mb-1 fw-semibold">
                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task">' . htmlspecialchars($task_data->product_task_name ?? '-') . '</span>
                    </div>
                    <div class="col-lg-12">
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <div class="bg-gray-200i border-gray-300i rounded px-1 mb-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assigned Start Date">
                                <label class="me-1"><i class="mdi mdi-timer-play-outline text-dark fs-5"></i></label>
                                <label class="fw-semibold fs-7" style="color: #107a64;">' . htmlspecialchars($start_date_time ?? '-') . '</label>
                            </div>
                            <div class="bg-gray-200i border-gray-300i rounded px-1 mb-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assigned End Date">
                                <label class="me-1"><i class="mdi mdi-timer-remove-outline text-dark fs-5"></i></label>
                                <label class="text-danger fw-semibold fs-7">' . htmlspecialchars($end_date_time ?? '-') . '</label>
                            </div>
                            <div class="d-flex align-items-center bg-gray-200i border-gray-300i rounded px-1 mb-3">
                                <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Created By"><i class="mdi mdi-pen text-dark fs-5"></i></label>
                                <label class="text-info fw-semibold fs-7 text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($task_data->created_staff_name ?? '-') . '">' . htmlspecialchars($task_data->created_staff_name ?? '-') . '</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">' . htmlspecialchars($task_data->cus_name ?? '-') . ' <span class="fs-7 text-primary">( ' . htmlspecialchars($task_data->cus_id ?? '-') . ' )</span></label>
                </div>
                  <div class="row mb-4 ">
                      <label class="col-3 text-dark fs-6 fw-semibold">Services</label>
                      <label class="col-1 text-black fs-6 fw-bold">:</label>
                      <label class="col-8 text-black fs-6 fw-semibold">' . htmlspecialchars($task_data->product_name ?? '-') . '</label>
                  </div>
                  <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Variant</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">' . htmlspecialchars($variant_name ?? '-') . '</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Variable</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">' . htmlspecialchars($variable_name ?? '-') . '</label>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black fs-7 fw-semibold">&emsp;&emsp; ' . htmlspecialchars($task_data->task_desc ?? '-') . '.</label>
                </div>';

      if ($task_data->rework_check > 0) {
        $html .= '<div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Rework</label>
                    <div class="col-12 text-danger text-justify fs-7 fw-semibold" style="text-align: justify;">&emsp;&emsp; ' . htmlspecialchars($task_data->rework_reason ?? ' - ') . '</div>
                </div>';
      }
      $html .= '  
                <div class="row mb-8">
                  <div class="col-lg-9 mb-1">
                        <div class="text-dark fs-6 fw-semibold mb-3">Assigned To <span class="text-black fw-bold">&</span> Logged Details</div>
                        <div class="d-flex align-items-center avatar-group gap-3 flex-wrap mb-1">';

      $staff_list = json_decode($task_data->assign_staffs, true);
      $staff_count = is_array($staff_list) ? count($staff_list) : 0;
      $grandTotalSeconds = 0;
      foreach ($staff_list as $staff_id) {

        $staff_details = $helper->staff_details($staff_id);
        $staff_name_main = $staff_details->staff_name ?? "-";
        $staff_image_main = $staff_details->staff_image ?? "";
        $job_position_name = $staff_details->job_position_name ?? "-";
        $gender_main = $staff_details->gender ?? 0;

        if ($staff_image_main && file_exists(public_path('staff_images/' . $staff_image_main))) {
          // Use single or double quotes properly; asset() is Blade helper, here you should generate URL or path properly
          $img_main = '<img src="' . asset('staff_images/' . $staff_image_main) . '" class="rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="' . $staff_name_main . '">';
        } else {
          $img_main = $helper->name_image(strtoupper(substr($staff_name_main, 0, 1)), $gender_main);
        }

        $html .= '    
                <div class="mb-1">
                    <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         ' . $img_main . '
                    </div>
                    <div class="dropdown-menu w-lg-400px w-sm-100" style="box-shadow: 0px 5px 15px -3px rgba(0, 0, 0, 0.2), 0px 8px 15px 1px rgba(0, 0, 0, 0.14), 0px 3px 15px 2px rgba(0, 0, 0, 0.12) !important;">
                        <div class="text-black text-center fw-semibold fs-8 px-3 py-2"><u>' . $staff_name_main . ' - Logged Details</u></div>
                        <div class="px-2 border-bottom">
                            <div class="row">
                                <div class="col-5 pe-0">
                                    <div class="text-black fw-semibold fs-9">Start Time</div>
                                </div>
                                <div class="col-5 pe-0">
                                    <div class="text-black fw-semibold fs-9">End Time</div>
                                </div>
                                <div class="col-2 pe-0 ps-0 text-center">
                                    <div class="text-black fw-semibold fs-9">Hours</div>
                                </div>
                            </div>
                        </div>
                        <div class="scroll-y max-h-200px px-3 py-lg-2 py-1">';
        $task_log = DB::table('et_task_log')->where('task_id', $id)->where('staff_id', $staff_id)->where('status', 1)->get();
        $totalSeconds = 0;
        foreach ($task_log as $log) {

          if (!empty($log->duration)) {
            list($h, $m, $s) = explode(':', $log->duration);
            $grandTotalSeconds += ($h * 3600) + ($m * 60) + $s;
          }
          $start_date = isset($log->start_time) ? date('d-M-Y', strtotime($log->start_time)) : '-';
          $end_date = isset($log->end_time) ? date('d-M-Y', strtotime($log->end_time)) : '-';
          $start_time = isset($log->start_time) ? date('H:i:s A', strtotime($log->start_time)) : '';
          $end_time = isset($log->end_time) ? date('H:i:s A', strtotime($log->end_time)) : '';
          // Convert duration from HH:MM:SS to readable format
          $duration = '-';
          if (!empty($log->duration)) {

            // Parse duration (HH:MM:SS) into seconds
            if (!empty($log->duration)) {
              list($hours, $minutes, $seconds) = explode(':', $log->duration);
              $totalSeconds += ($hours * 3600) + ($minutes * 60) + $seconds;
            }
            list($hours, $minutes, $seconds) = explode(':', $log->duration);
            $hours = (int)$hours;
            $minutes = (int)$minutes;
            $seconds = (int)$seconds;

            if ($hours > 0) {
              $duration = $hours . ' hr' . ($hours > 1 ? 's' : '');
              if ($minutes > 0) {
                $duration .= ' ' . $minutes . ' min' . ($minutes > 1 ? 's' : '');
              }
            } elseif ($minutes > 0) {
              $duration = $minutes . ' min' . ($minutes > 1 ? 's' : '');
              if ($seconds > 0) {
                $duration .= ' ' . $seconds . ' sec' . ($seconds > 1 ? 's' : '');
              }
            } else {
              $duration = $seconds . ' sec' . ($seconds > 1 ? 's' : '');
            }
          }

          $html .= '
                              <div class="row bg-hov mb-2">
                                <div class="col-5">
                                    <div class="text-dark fw-semibold fs-9">' . htmlspecialchars($start_date) . ' <br> ' . htmlspecialchars($start_time) . '</div>
                                </div>
                                <div class="col-5">
                                    <div class="text-danger fw-semibold fs-9">' . htmlspecialchars($end_date) . '  <br> ' . htmlspecialchars($end_time) . '</div>
                                </div>
                                <div class="col-2 text-center">
                                    <div class="text-info fw-semibold fs-9">' . htmlspecialchars($duration) . '</div>
                                </div>
                              </div>';
        }
        // After the loop, convert total seconds back to H:M:S and human readable format
        $totalHours = floor($totalSeconds / 3600);
        $totalMinutes = floor(($totalSeconds % 3600) / 60);
        $totalSecs = $totalSeconds % 60;

        $totalDuration = '';
        if ($totalHours > 0) {
          $totalDuration = $totalHours . ' hr' . ($totalHours > 1 ? 's' : '');
          if ($totalMinutes > 0) {
            $totalDuration .= ' ' . $totalMinutes . ' min' . ($totalMinutes > 1 ? 's' : '');
          }
        } elseif ($totalMinutes > 0) {
          $totalDuration = $totalMinutes . ' min' . ($totalMinutes > 1 ? 's' : '');
          if ($totalSecs > 0) {
            $totalDuration .= ' ' . $totalSecs . ' sec' . ($totalSecs > 1 ? 's' : '');
          }
        } else {
          if ($totalSecs > 0) {
            $totalDuration = $totalSecs . ' sec' . ($totalSecs > 1 ? 's' : '');
          }
        }
        $completed_date = '-';
        if ($staff_id == $task_data->task_completed_by) {
          $completed_date =  isset($task_data->task_completed_date_time) ? date('d-M-Y H:i A', strtotime($task_data->task_completed_date_time)) : '-';
        }

        $html .= '  </div>
                        <div class="row px-3 pt-1 pb-2">
                            <div class="col-8">
                                <div class="text-black fw-semibold fs-9">Completed Date & Time</div>
                                <div class="d-block text-dark fw-bold fs-9">
                                  ' . htmlspecialchars($completed_date) . '
                                </div>
                            </div>
                            <div class="col-4 text-center">
                                <div class="text-black fw-semibold fs-9">Total Hours</div>
                                <div class="text-info fw-bold fs-9">' . htmlspecialchars($totalDuration) . '</div>
                            </div>
                        </div>
                    </div>
                </div>';
      }

      $hours = floor($grandTotalSeconds / 3600);
      $minutes = floor(($grandTotalSeconds % 3600) / 60);
      $seconds = $grandTotalSeconds % 60;

      $grandTotalDuration = '';
      if ($hours > 0) {
        $grandTotalDuration = $hours . ' hr' . ($hours > 1 ? 's' : '');
        if ($minutes > 0) {
          $grandTotalDuration .= ' ' . $minutes . ' min' . ($minutes > 1 ? 's' : '');
        }
      } elseif ($minutes > 0) {
        $grandTotalDuration = $minutes . ' min' . ($minutes > 1 ? 's' : '');
        if ($seconds > 0) {
          $grandTotalDuration .= ' ' . $seconds . ' sec' . ($seconds > 1 ? 's' : '');
        }
      } else {
        if ($seconds > 0) {
          $grandTotalDuration = $seconds . ' sec' . ($seconds > 1 ? 's' : '');
        }
      }
      $html .= ' </div>
                    </div>
                    <div class="col-lg-3 mb-1 text-center">
                        <lable class="text-black fs-7 fw-semibold">Total Usage Hours</lable>
                        <div class="text-primary border border-gray-400i rounded-pill fs-7 fw-bold mb-1">
                            <span>' . htmlspecialchars($grandTotalDuration ?? '-') . '</span>
                        </div>
                    </div>
                </div>

                <div class="px-3">
                    <div class="row">
                        <div class="col-lg-9 mb-1 text-black fs-6 fw-semibold">
                            <label class="text-black fs-6 fw-semibold me-1">Checklist</label>
                            <label class="badge bg-secondary fs-7 fw-semibold py-2 rounded me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Checklist">' . htmlspecialchars($check_list_count ?? '0') . '</label>
                            <label class="text-black fs-7 fw-semibold px-2 py-1 rounded me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed Checklist" style="border:1px solid #08a34f;">' . htmlspecialchars($completed_count ?? '0') . '</label>
                            <label class="badge bg-danger text-white fs-7 fw-semibold py-2 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pending Checklist" style="background-color: #ff4d49eb;">' . htmlspecialchars($balance_count ?? '0') . '</label>
                        </div>
                        <div class="col-lg-3 mb-1 text-black fs-6 fw-semibold">Percentage</div>
                    </div>
                </div>
                <hr class="mt-1 mb-2"> <div class="scroll-y max-h-300px px-3 py-2">';

      $task_check_list_details = ManageTaskChecklistModel::where('task_id', $id)
        ->where('status', 0)
        ->get();

      foreach ($task_check_list_details as $task_cl) {
        $task_check_list_data = DB::table('et_task_checklist')
          ->where('sno', $task_cl->task_check_list_id)
          ->first();

        $staff_details = $helper->staff_details($task_cl->completed_staff_id);
        $staff_image  = $staff_details->staff_image ?? '';
        $staff_name   = $staff_details->staff_name ?? '';
        $gender       = $staff_details->gender ?? '';

        if ($staff_image && file_exists(public_path('staff_images/' . $staff_image))) {
          // Use single or double quotes properly; asset() is Blade helper, here you should generate URL or path properly
          $img = '<img src="' . asset('staff_images/' . $staff_image) . '" alt="Staff" class="rounded-circle">';
        } else {
          $img = $helper->name_image(strtoupper(substr($staff_name, 0, 1)), $gender);
        }

        if ($task_cl->completed_percentage > 0) {
          $html .= '
                <div class="row mb-1 pt-1 rounded" style="border:1px solid #08a34f;">
                    <div class="col-lg-9 d-flex align-items-center mb-1">
                        <label class="text-black fs-7 fw-semibold me-2">
                            <i class="mdi mdi-text-box-check-outline text-dark fs-4"></i>
                        </label>
                        <label class="text-black fs-7 fw-semibold text-wrap">' . htmlspecialchars($task_check_list_data->task_checklist ?? '-') . '</label>
                    </div>
                    <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                        <label class="text-black fs-7 fw-semibold">' . htmlspecialchars($task_cl->completed_percentage ?? '-') . '%</label>
                        <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle mb-1" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="' . htmlspecialchars($staff_name) . '">
                            ' . $img . '
                        </div>
                    </div>
                </div>';
        } else {
          $html .= '
            <div class="row mb-1 pt-1 rounded" style="background-color: #ff4d49eb;">
                <div class="col-lg-9 d-flex align-items-center mb-1">
                    <label class="text-white fs-7 fw-semibold me-2">
                        <i class="mdi mdi-text-box-remove-outline text-white fs-4"></i>
                    </label>
                    <label class="text-white fs-7 fw-semibold text-wrap">' . htmlspecialchars($task_check_list_data->task_checklist ?? 'Develop Thesis Outline') . '</label>
                </div>
                <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                    <label class="text-white fs-7 fw-semibold">' . htmlspecialchars($task_cl->completed_percentage ?? '0') . '%</label>
                    <!-- No staff image displayed here when not complete -->
                </div>
            </div>';
        }
      }
      $html .= '</div>';

      $uploadedFiles = [];
      if (!empty($task_data->attachments)) {
        $uploadedFiles = json_decode($task_data->attachments, true);
        if (!is_array($uploadedFiles)) {
          $uploadedFiles = [];
        }
      }

      $responseData = $task_data->toArray();
      $responseData['uploaded_files'] = $uploadedFiles;



      return response([
        'status' => 200,
        'message' => 'Product fetched successfully',
        'error_msg' => null,
        'responseData' => $responseData,
        'data' => [
          'html' => $html,
          'product_list' => $task_data->product_list,

        ]
      ], 200);
    }
  }

  public function Task_complete_view($id, Request $request)
  {
    $user_id = $request->user()->user_id;
    $helper =  new \App\Helpers\Helpers();
    $task_data =  ManageTaskModel::select(
      'et_task.*',
      'et_staff.staff_name AS created_staff_name',
      'et_customer.cus_name',
      'et_customer.cus_mobile',
      'et_customer.cus_email_id',
      'et_customer.country_code',
      'et_customer.customer_id AS cus_id',
      'et_product_category.product_category_name',
      'et_customer_services.proposal_id',
      'et_rework_history.rework_staff_id',
      'et_product_task.task_name as task_name',
      'et_rework_history.rework_percentage',
      DB::raw("CASE 
            WHEN et_customer_services.product_package = 1 THEN et_product.product_name
            WHEN et_customer_services.product_package = 2 THEN et_package.package_name
            ELSE NULL
        END as product_name")
    )
      ->where('et_task.status', '!=', 2)
      ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
      ->leftJoin('et_customer_services', 'et_task.service_id', 'et_customer_services.sno')
      ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
      ->leftJoin('et_product', function ($join) {
        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
          ->where('et_customer_services.product_package', '=', 1);
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->leftJoin('et_rework_history', 'et_rework_history.task_id', 'et_task.sno')
      ->leftJoin('et_staff', 'et_task.created_by', 'et_staff.sno')
      ->where('et_task.sno', $id)->first();
    $start_date_time = $task_data->start_date_time ? date("d-M-Y h:i A", strtotime($task_data->start_date_time)) : '-';
    $end_date_time = $task_data->end_date_time ? date("d-M-Y h:i A", strtotime($task_data->end_date_time)) : '-';
    $check_list = json_decode($task_data->task_check_list_ids, true);
    $check_list_count = is_array($check_list) ? count($check_list) : 0;
    $completed_count  = $helper->completed_task_details($id) ?? 0;
    $balance_count    = $check_list_count - $completed_count;
    $html = '';
    // <span class="ms-2" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Timer Running" data-bs-original-title="Timer Running">
    //     <img src="' . asset('/assets/phdizone_images/header/timer_g1.gif') . '" alt="Timer Running" class="w-45px h-45px mt-n3 text-black fw-bold" id="task_cplt_timer_icn" style="display: inline;">
    // </span>

    if ($task_data) {
        // Fetch all products matching the criteria (collection of products)
        $productList = DB::table('et_customer_services')
            ->select(
                'et_customer_services.*',
                'et_product_category.product_category_name',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as product_name")
            )
            ->where('et_customer_services.proposal_id', $task_data->proposal_id)
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
            ->orderBy('et_customer_services.sno', 'desc')
            ->where('et_customer_services.sno', $task_data->service_id)
            ->get();  // <-- collection of products

      // For each product, decode variant_variable_ids and fetch related details
      
        foreach ($productList as $product) {
        
            $variant_variable_data = json_decode($product->variant_variable_ids ?? '[]', true);
          
            if (!empty($variant_variable_data)) {
              foreach ($variant_variable_data as $cart_item) {
                $variant_name = $helper->get_variant_data_by_id($cart_item['variant_id'])->product_variant_name ?? 'N/A';
                $variable_name = $helper->get_variable_data_by_id($cart_item['variable_id'])->variable_name ?? 'N/A';
              }
            }

        }
        
        // Assign back to task_data
        $task_data->product_list = $productList;



      $html .= '
        <div class="row mb-4">
                  <input type="hidden" name="task_sno" id="task_sno_complete" value="' . $id . '">
                    <div class="col-lg-12 text-black fs-5 mb-1 fw-semibold">
                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task">' . htmlspecialchars($task_data->task_name ?? '-') . '</span>
                        
                    </div>
                    <div class="col-lg-12">
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <div class="bg-gray-200i border-gray-300i rounded px-1 mb-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assigned Start Date">
                                <label class="me-1"><i class="mdi mdi-timer-play-outline text-dark fs-5"></i></label>
                                <label class="fw-semibold fs-7" style="color: #107a64;">' . htmlspecialchars($start_date_time ?? '-') . '</label>
                            </div>
                            <div class="bg-gray-200i border-gray-300i rounded px-1 mb-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assigned End Date">
                                <label class="me-1"><i class="mdi mdi-timer-remove-outline text-dark fs-5"></i></label>
                                <label class="text-danger fw-semibold fs-7">' . htmlspecialchars($end_date_time ?? '-') . '</label>
                            </div>
                            <div class="d-flex align-items-center bg-gray-200i border-gray-300i rounded px-1 mb-3">
                                <label class="me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Created By"><i class="mdi mdi-pen text-dark fs-5"></i></label>
                                <label class="text-info fw-semibold fs-7 text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($task_data->created_staff_name ?? '-') . '">' . htmlspecialchars($task_data->created_staff_name ?? '-') . '</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Services</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">' . htmlspecialchars($task_data->product_name ?? '-') . '</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Variant</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">' . htmlspecialchars($variant_name ?? '-') . '</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Variable</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">' . htmlspecialchars($variable_name ?? '-') . '</label>
                </div>
                
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">' . htmlspecialchars($task_data->cus_name ?? '-') . ' <span class="fs-7 text-primary">( ' . htmlspecialchars($task_data->cus_id ?? '-') . ' )</span></label>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black fs-7 fw-semibold">&emsp;&emsp; ' . htmlspecialchars($task_data->task_desc ?? '-') . '.</label>
                </div>';
      $html .= '  
                <div class="row mb-8">
                  <div class="col-lg-9 mb-1">
                        <div class="text-dark fs-6 fw-semibold mb-3">Assigned To <span class="text-black fw-bold">&</span> Logged Details</div>
                        <div class="d-flex align-items-center avatar-group gap-3 flex-wrap mb-1">';

      $staff_list = json_decode($task_data->assign_staffs, true);
      $staff_count = is_array($staff_list) ? count($staff_list) : 0;

      foreach ($staff_list as $staff_id) {

        $staff_details = $helper->staff_details($staff_id);
        $staff_name_main = $staff_details->staff_name ?? "-";
        $staff_image_main = $staff_details->staff_image ?? "";
        $job_position_name = $staff_details->job_position_name ?? "-";
        $gender_main = $staff_details->gender ?? 0;

        if ($staff_image_main && file_exists(public_path('staff_images/' . $staff_image_main))) {
          // Use single or double quotes properly; asset() is Blade helper, here you should generate URL or path properly
          $img_main = '<img src="' . asset('staff_images/' . $staff_image_main) . '" class="rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="' . $staff_name_main . '">';
        } else {
          $img_main = $helper->name_image(strtoupper(substr($staff_name_main, 0, 1)), $gender_main);
        }

        $html .= '    
                <div class="mb-1">
                    <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         ' . $img_main . '
                    </div>
                </div>';
      }
      $task_usage_hours = $helper->task_usage_hours($id);
      $html .= ' </div>
                    </div>
                    <div class="col-lg-3 mb-1 text-center">
                        <lable class="text-black fs-7 fw-semibold">Total Usage Hours</lable>
                        <div class="text-primary border border-gray-400i rounded-pill fs-7 fw-bold mb-1">
                            <span>' . htmlspecialchars($task_usage_hours ?? '-') . '</span><span class="fs-7 fw-semibold">&nbsp;Hrs</span>
                        </div>
                    </div>
                </div>

                <div class="px-3">
                    <div class="row">
                        <div class="col-lg-9 mb-1 text-black fs-6 fw-semibold">
                            <label class="text-black fs-6 fw-semibold me-1">Checklist</label>
                            <label class="badge bg-secondary fs-7 fw-semibold py-2 rounded me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Checklist">' . htmlspecialchars($check_list_count ?? '0') . '</label>
                            <label class="text-black fs-7 fw-semibold px-2 py-1 rounded me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed Checklist" style="border:1px solid #08a34f;">' . htmlspecialchars($completed_count ?? '0') . '</label>
                            <label class="badge bg-danger text-white fs-7 fw-semibold py-2 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pending Checklist" style="background-color: #ff4d49eb;">' . htmlspecialchars($balance_count ?? '0') . '</label>
                        </div>
                        <div class="col-lg-3 mb-1 text-black fs-6 fw-semibold">Percentage</div>
                    </div>
                </div>
                <hr class="mt-1 mb-2"> ';

      // return $task_data;

      if (!empty($task_data->rework_check) && $task_data->rework_check > 0) {

        $rework_tasks = ReworkReasonModel::where('task_id', $id)
          ->where('status', 0)
          ->get();

        foreach ($rework_tasks as $rework_task) {
          $staff_details = $helper->staff_details($rework_task->rework_staff_id);
          $staff_image  = $staff_details->staff_image ?? '';
          $staff_name   = $staff_details->staff_name ?? '';
          $gender       = $staff_details->gender ?? '';

          if ($staff_image && file_exists(public_path('staff_images/' . $staff_image))) {
            $img = '<img src="' . asset('staff_images/' . $staff_image) . '" alt="Staff" class="rounded-circle">';
          } else {
            $img = $helper->name_image(strtoupper(substr($staff_name, 0, 1)), $gender);
          }

          $selected_percentage = $rework_task->rework_percentage ?? 0;
          $completed_by_other_user = $user_id != $rework_task->rework_staff_id && $rework_task->rework_staff_id > 0;

          if ($selected_percentage >= 100) {
            $is_checked = 'checked disabled';
            $is_disabled = 'disabled';
          } else if ($completed_by_other_user) {
            $is_checked = 'checked disabled';
            $is_disabled = 'disabled';
          } else if ($selected_percentage > 0 && $selected_percentage < 100) {
            $is_checked = 'checked';
            $is_disabled = '';
          } else {
            $is_checked = '';
            $is_disabled = '';
          }

          if ($is_disabled) {
            $name_id = '';
            $name_id_chk = '';
          } else {
            $name_id = 'id="task_pecentage' . $rework_task->sno . '" name="task_pecentage[' . $rework_task->sno . ']"';
            $name_id_chk = 'id="task_chk' . $rework_task->sno . '" name="task_chk[]"  onclick="checkAllTaskChkBox()"';
          }

          $html .= '
    <div class="row mb-1">
        <div class="col-lg-9 mb-1">
            <div class="form-check form-check-inline">
                <input class="form-check-input task_chk_box" type="checkbox" 
                  id="task_chk' . $rework_task->sno . '" 
                  name="rework_chk[]" 
                  onclick="checkAllTaskChkBox()" 
                  value="' . $rework_task->sno . '" 
                  ' . $is_checked . '>
                <label class="text-danger fs-7 fw-semibold" style="text-align: justify;">' . htmlspecialchars($rework_task->rework_reason ?? 'Rework Task') . '</label>
            </div>
        </div>
        <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
            <div class="me-2 min-w-100px max-w-100px">
                <select class="select3 form-select task_perct_dbox" ' . $name_id . ' ' . $is_disabled . ' onchange="checkAllTaskChkBox()" name="task_pecentage[' . $rework_task->sno . ']">
                    <option value="">Select</option>';

          for ($i = 1; $i <= 20; $i++) {
            $value = $i * 5;
            $selected = ($value == $selected_percentage) ? ' selected' : '';
            if ($value >= $selected_percentage) {
              $html .= '<option value="' . $value . '"' . $selected . '>' . $value . '%</option>';
            }
          }

          $html .= '
                </select>
            </div>';

          if ($rework_task->rework_staff_id > 0) {
            $html .= '<div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="' . htmlspecialchars($staff_name) . '">' . $img . '</div>';
          }

          $html .= '
        </div>
    </div>';
        }
      } else {
        // Default checklist logic
        $task_check_list_details = ManageTaskChecklistModel::where('task_id', $id)
          ->where('status', 0)
          ->get();

        foreach ($task_check_list_details as $task_cl) {
          $task_check_list_data = DB::table('et_task_checklist')
            ->where('sno', $task_cl->task_check_list_id)
            ->first();

          $staff_details = $helper->staff_details($task_cl->completed_staff_id);
          $staff_image  = $staff_details->staff_image ?? '';
          $staff_name   = $staff_details->staff_name ?? '';
          $gender       = $staff_details->gender ?? '';

          if ($staff_image && file_exists(public_path('staff_images/' . $staff_image))) {
            $img = '<img src="' . asset('staff_images/' . $staff_image) . '" alt="Staff" class="rounded-circle">';
          } else {
            $img = $helper->name_image(strtoupper(substr($staff_name, 0, 1)), $gender);
          }

          $selected_percentage = $task_cl->completed_percentage ?? 0;
          $completed_by_other_user = $user_id != $task_cl->completed_staff_id && $task_cl->completed_staff_id > 0;

          if ($selected_percentage >= 100) {
            $is_checked = 'checked disabled';
            $is_disabled = 'disabled';
          } else if ($completed_by_other_user) {
            $is_checked = 'checked disabled';
            $is_disabled = 'disabled';
          } else if ($selected_percentage > 0 && $selected_percentage < 100) {
            $is_checked = 'checked';
            $is_disabled = '';
          } else {
            $is_checked = '';
            $is_disabled = '';
          }

          if ($is_disabled) {
            $name_id = '';
            $name_id_chk = '';
          } else {
            $name_id = 'id="task_pecentage' . $task_cl->sno . '" name="task_pecentage[' . $task_cl->sno . ']"';
            $name_id_chk = 'id="task_chk' . $task_cl->sno . '" name="task_chk[]"  onclick="checkAllTaskChkBox()"';
          }

          $html .= '
          <div class="row mb-1">
              <div class="col-lg-9 mb-1">
                  <div class="form-check form-check-inline">
                      <input class="form-check-input task_chk_box" type="checkbox" ' . $name_id_chk . ' ' . $is_checked . ' value="' . $task_cl->sno . '" >
                      <label class="text-black fs-7 fw-semibold">' . htmlspecialchars($task_check_list_data->task_checklist ?? '-') . '</label>
                  </div>
              </div>
              <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                  <div class="me-2 min-w-100px max-w-100px">
                      <select class="select3 form-select task_perct_dbox" ' . $name_id . ' ' . $is_disabled . ' onchange="checkAllTaskChkBox()">
                          <option value="">Select</option>';
          for ($i = 1; $i <= 20; $i++) {
            $value = $i * 5;
            $selected = ($value == $selected_percentage) ? ' selected' : '';
            if ($value >= $selected_percentage) {
              $html .= '<option value="' . $value . '"' . $selected . '>' . $value . '%</option>';
            }
          }
          $html .= '
                    </select>
                </div>';
          if ($task_cl->completed_staff_id > 0) {
            $html .= '<div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="' . htmlspecialchars($staff_name) . '">' . $img . '</div>';
          } 
          $html .= '
            </div>
        </div>';
        }
      }

      return response([
        'status' => 200,
        'message' => 'Product fetched successfully',
        'error_msg' => null,
        'data' => [
          'html' => $html
        ]
      ], 200);
    }
  }


  public function Update_task(Request $request)
  {
    $user = $request->user();
    $task_sno = $request->task_sno;
    $task_chk = $request->task_chk ?? [];
    $rework_chk = $request->rework_chk ?? [];
    $task_completedhidden = $request->task_completedhidden ?? 0;
    $updateSuccess = false;

    // return $rework_chk;

    $task = ManageTaskModel::where('sno', $task_sno)->first();
    if (!$task) {
      session()->flash('toastr', ['type' => 'error', 'message' => 'Task not found!']);
      return redirect()->back();
    }

    // Update rework checklist items
    if (!empty($rework_chk)) {
      foreach ($rework_chk as $rev_chk) {
        $reworkTask = ReworkReasonModel::where('sno', $rev_chk)->first();
        if ($reworkTask) {
          // Use the correct key here based on your input name
          $reworkPercentage = intval($request->task_pecentage[$rev_chk] ?? 0);
          if ($reworkPercentage > 0) {
            $reworkTask->rework_percentage = $reworkPercentage;
            $reworkTask->rework_staff_id = $user->user_id;
            $reworkTask->updated_by = $user->user_id;
            $reworkTask->save();
            $updateSuccess = true;
          }
        }
      }
    }

    // Update normal checklist items
    if (!empty($task_chk)) {
      foreach ($task_chk as $task_ch) {
        $checklistItem = ManageTaskChecklistModel::where('sno', $task_ch)->first();
        if ($checklistItem) {
          $checklistItem->updated_by = $user->user_id;
          $checklistItem->completed_staff_id = $user->user_id;
          $checklistItem->completed_percentage = $request->task_pecentage[$task_ch] ?? 0;
          $checklistItem->save();
          $updateSuccess = true;
        }
      }
    }

    // Update task status if completed
    if ($task_completedhidden) {
      $task->status = 3; // Completed
      $task->task_completed_date_time = now();
      $task->task_completed_by = $user->user_id;
      $task->save();
      $updateSuccess = true;
    }

    // Handle attachments
    $uploadedFilesJson = $request->uploaded_files ?? '[]';
    $uploadedFilesArray = json_decode($uploadedFilesJson, true);
    $existingAttachments = json_decode($task->attachments ?? '[]', true);

    if (!is_array($existingAttachments)) {
      $existingAttachments = [];
    }
    if (!is_array($uploadedFilesArray)) {
      $uploadedFilesArray = [];
    }

    $mergedAttachments = array_merge($existingAttachments, $uploadedFilesArray);
    $task->attachments = json_encode($mergedAttachments);
    $task->save();

    if ($updateSuccess) {
      session()->flash('toastr', ['type' => 'success', 'message' => 'Task Updated Successfully!']);
    } else {
      session()->flash('toastr', ['type' => 'error', 'message' => 'Could not update the Task!']);
    }

    return redirect()->back();
  }


  // Start task timer: insert a new row with start_time
  public function start(Request $request)
  {
    $request->validate([
      'task_id' => 'required|integer',
      'staff_id' => 'required|integer',
    ]);

    $taskLog = TaskLogModel::where('staff_id', $request->staff_id)
      ->where('status', 0)
      ->latest('sno')
      ->first();

    if ($taskLog) {
      return response()->json([
        'status' => false,
        'message' => 'A timer is already running for another task.'
      ], 409); // HTTP 409 Conflict
    }

    $update_main = ManageTaskModel::where('sno', $request->task_id)->where('status', 0)->first();
    if ($update_main) {
      $update_main->status = 1;
      $update_main->save();
    }


    $branch_id = $request->user()->branch_id;
    $taskLog = new TaskLogModel();
    $taskLog->task_id   = $request->task_id;
    $taskLog->staff_id  = $request->staff_id;
    $taskLog->branch_id = $branch_id;
    $taskLog->start_time = now();
    $taskLog->created_by = $request->staff_id;
    $taskLog->updated_by = $request->staff_id;
    $taskLog->status = 0;
    $taskLog->save();

    return response()->json(['message' => 'Task timer started', 'id' => $taskLog->sno]);
  }

  // Stop task timer: update end_time and duration on last started row for this task & staff
  public function stop(Request $request)
  {
    $request->validate([
      'task_id' => 'required|integer',
      'staff_id' => 'required|integer',
    ]);


    $taskLog = TaskLogModel::where('task_id', $request->task_id)
      ->where('staff_id', $request->staff_id)
      ->orderBy('sno', 'desc')
      ->first();

    if (!$taskLog) {
      return response()->json(['message' => 'No started task log found'], 404);
    }

    $taskLog->end_time = now();

    // Calculate duration = end_time - start_time (as time)
    $durationSeconds = strtotime($taskLog->end_time) - strtotime($taskLog->start_time);
    $hours = floor($durationSeconds / 3600);
    $minutes = floor(($durationSeconds % 3600) / 60);
    $seconds = $durationSeconds % 60;
    $taskLog->duration = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);

    $taskLog->status = 1;
    $taskLog->updated_by = $request->staff_id;
    $taskLog->save();

    return response()->json(['message' => 'Task timer stopped', 'duration' => $taskLog->duration, 'log_id' => $taskLog->sno]);
  }

  public function runningTaskLog(Request $request)
  {
    $staffId = auth()->user()->user_id;

    $runningLog = DB::table('et_task_log')
      ->where('staff_id', $staffId)
      ->where('status', 0)
      ->orderByDesc('sno')
      ->first();

    if (!$runningLog) {
      return response()->json(['running' => false], 200);
    }

    $startTime = Carbon::parse($runningLog->start_time);
    $now = Carbon::now();
    $diffInSeconds = $now->diffInSeconds($startTime);

    return response()->json([
      'running' => true,
      'task_id' => $runningLog->task_id,
      'elapsed_seconds' => $diffInSeconds,
      'start_time' => $startTime->toDateTimeString()
    ]);
  }
  public function taskFiles(Request $request)
  {
    $request->validate([
      'file_upload.*' => 'required|file|max:10240',
      'folder_name' => 'required|string'
    ]);

    $folderName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $request->folder_name); // Sanitize folder
    $uploadPath = public_path('task_files/' . $folderName);

    if (!file_exists($uploadPath)) {
      mkdir($uploadPath, 0777, true);
    }

    $uploaded = [];

    foreach ($request->file('file_upload') as $file) {
      $timestamp = now()->format('Ymd_His');
      $extension = $file->getClientOriginalExtension();
      $fileName = $timestamp . '_' . uniqid() . '.' . $extension;

      $file->move($uploadPath, $fileName);
      $uploaded[] = $fileName;
    }

    return response()->json([
      'success' => true,
      'files' => $uploaded
    ]);
  }

  public function deleteUploadedFile(Request $request)
  {
    $request->validate([
      'file_name' => 'required|string',
      'folder_name' => 'required|string'
    ]);

    $folderName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $request->folder_name);
    $filePath = public_path("task_files/{$folderName}/" . $request->file_name);

    if (file_exists($filePath)) {
      unlink($filePath);
      return response()->json(['success' => true]);
    } else {
      return response()->json(['success' => false, 'message' => 'File not found']);
    }
  }
}
