<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TaskCalendar extends Controller
{
    public function index(Request $request) {

        $date = $request->get('date', today()->format('Y-m-d'));
        $month = $request->get('month', today()->month);
        $year = $request->get('year', today()->year);
        $view = $request->get('view', 'daily');

        return view('content.production_management.task_calendar.list', [
            'date' => $date,
            'month' => $month,
            'year' => $year,
            'view' => $view
        ]);
    }

    public function getDailyTasks(Request $request)
    {
        $date = $request->get('date', today()->format('Y-m-d'));
        $user_id = $request->user()->user_id;
        $tasks = DB::table('et_daily_tasks')->whereDate('et_daily_tasks.task_date', $date)
            ->leftJoin('et_task', 'et_task.sno', '=', 'et_daily_tasks.task_id')
            ->leftJoin('et_staff as staff', 'staff.sno', '=', 'et_daily_tasks.staff_id')
            ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_daily_tasks.created_by')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'staff.position_role')
            ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_task.service_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->select(
                'et_product_task.task_name',
                'et_daily_tasks.status',
                'et_daily_tasks.task_date',
                'et_product.product_name as service_name',
                'et_daily_tasks.task_hours',
                                'et_daily_tasks.sno',
                'et_daily_tasks.staff_id',
                'et_daily_tasks.max_page_or_per',
                'et_customer.cus_name as customer_name',
                'et_customer.customer_id',
                'et_customer.customer_id',
                'et_customer_services.created_at',
                'et_customer_services.sno',
                'et_task.task_id',
                'et_task.task_category',
                'staff.staff_name as staff_name',
                'staff.staff_image as staff_image',
                'pc.staff_name as pc_name',
                'et_job_position.job_position_name'
            )
            ->where('et_daily_tasks.status', '!=', 2)
            ->orderBy('et_daily_tasks.task_date');

            if (auth()->user()->hasPermissionradio('Production Management', 'Task Calendar', 'view_self_manage_task')) {
            
                $tasks = $tasks->where('et_daily_tasks.staff_id', $user_id);
                
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Task Calendar', 'global_manage_task')) {
                // User can view all data — no extra filter needed
                $tasks = $tasks;
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
           
        $tasks = $tasks->get();

        foreach($tasks as $task) {
            $serviceYear = date('Y', strtotime($task->created_at));
            $id = str_pad($task->sno, 5, '0', STR_PAD_LEFT);
            $task->service_id = "SR-{$id}/{$serviceYear}";
        }


        return response()->json([
            'tasks' => $tasks,
            'date' => Carbon::parse($date)->format('F j, Y'),
            'day' => Carbon::parse($date)->format('l'),
            'stats' => [
                'total_tasks' => $tasks->count(),
                'total_hours' => $tasks->sum('task_hours'),
                'pending' => $tasks->where('status', 0)->count(),
                'completed' => $tasks->where('status', 1)->count(),
            ]
        ]);
    }

    public function getMonthlyTasks(Request $request)
    {
        $month = $request->get('month', today()->month);
        $year = $request->get('year', today()->year);
        $user_id = $request->user()->user_id;

        // Get tasks for the month
        $tasks = DB::table('et_daily_tasks')->whereMonth('task_date', $month)
            ->whereYear('task_date', $year)
            ->orderBy('task_date');

            if (auth()->user()->hasPermissionradio('Production Management', 'Task Calendar', 'view_self_manage_task')) {
            
                $tasks = $tasks->where('et_daily_tasks.staff_id', $user_id);
                
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Task Calendar', 'global_manage_task')) {
                // User can view all data — no extra filter needed
                $tasks = $tasks;
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
            
        $tasks = $tasks->get();

        // Group by date
        $groupedTasks = $tasks->groupBy(function($task) {
            return Carbon::parse($task->task_date)->format('Y-m-d');
        });

        // Generate calendar structure
        $startDate = Carbon::create($year, $month, 1);
        $endDate = $startDate->copy()->endOfMonth();
        
        $calendar = [];
        $current = $startDate->copy();
        
        while ($current <= $endDate) {
            $dateStr = $current->format('Y-m-d');
            $calendar[$dateStr] = [
                'date' => $dateStr,
                'formatted_date' => $current->format('j'),
                'day_name' => $current->format('D'),
                'is_today' => $current->isToday(),
                'is_weekend' => $current->isWeekend(),
                'tasks' => $groupedTasks->get($dateStr, []),
                'task_count' => $groupedTasks->has($dateStr) ? $groupedTasks->get($dateStr)->count() : 0,
                'total_hours' => $groupedTasks->has($dateStr) ? $groupedTasks->get($dateStr)->sum('task_hours') : 0
            ];
            $current->addDay();
        }

        return response()->json([
            'calendar' => $calendar,
            'month_year' => $startDate->format('F Y'),
            'stats' => [
                'total_tasks' => $tasks->count(),
                'total_days_with_tasks' => $groupedTasks->count(),
                'total_hours' => $tasks->sum('task_hours')
            ]
        ]);
    }

    public function getDateNavigation(Request $request)
    {
        $currentDate = Carbon::parse($request->get('date', today()));
        
        return response()->json([
            'yesterday' => $currentDate->copy()->subDay()->format('Y-m-d'),
            'today' => today()->format('Y-m-d'),
            'tomorrow' => $currentDate->copy()->addDay()->format('Y-m-d'),
            'day_after_tomorrow' => $currentDate->copy()->addDays(2)->format('Y-m-d'),
            'current_date' => $currentDate->format('Y-m-d'),
            'formatted_current_date' => $currentDate->format('F j, Y')
        ]);
    }
}
