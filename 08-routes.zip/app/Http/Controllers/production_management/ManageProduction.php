<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use App\Models\DailyTaskModel;
use Illuminate\Http\Request;
use App\Models\ManageTaskModel;
use App\Models\ManageTaskChecklistModel;
use App\Models\ReworkReasonModel;
use App\Models\StaffModel;
use App\Models\TaskDescriptionModel;
use App\Models\TaskLogModel;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;
use Exception;
use Google\Service\CloudSourceRepositories\Repo;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Http;

class ManageProduction extends Controller
{
  public function index(Request $request)
  {

    $user_id = $request->user()->user_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $today = date('Y-m-d');

    $lists = DB::table('et_daily_tasks')
      ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_daily_tasks.staff_id')
      ->leftJoin('et_task', 'et_task.sno', '=', 'et_daily_tasks.task_id')
      ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
      ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_daily_tasks.service_id')
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
      ->leftJoin('et_work_order', 'et_work_order.proposal_id', '=', 'et_customer_services.proposal_id')
      ->leftJoin('et_product', function ($join) {
        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
          ->where('et_customer_services.product_package', '=', 1);
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->select(
        'et_daily_tasks.*',
        'et_staff.staff_image',
        'et_staff.staff_name',
        'et_staff.gender',
        'et_staff.nick_name',
        'et_product_task.task_name',
        'et_task.pages_percentage',
        'et_task.task_category',
        'et_customer.cus_name',
        'et_customer.customer_id',
        'et_work_order.development_date',
        DB::raw("CASE
          WHEN et_customer_services.product_package = 1 THEN et_product.product_name
          WHEN et_customer_services.product_package = 2 THEN et_package.package_name
          ELSE NULL
        END as product_name")
      )
    //   ->whereDate('et_daily_tasks.task_date' , '<=' , $today)
      ->where('et_daily_tasks.status', '!=', 2)
      ->orderBy('et_daily_tasks.task_date', 'asc');

    // if (auth()->user()->hasPermissionradio('Production Management', 'Manage Production', 'view_self_production')) {
    //   // User can only view their own data
    //   $lists = $lists->where('et_daily_tasks.staff_id', $user_id);
    // } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Production', 'global_production')) {
    //   // User can view all data — no extra filter needed
    // } else {
    //   // No permission
    //   abort(403, 'Unauthorized');
    // }

    $lists = $lists->get();

    return view('content.production_management.manage_production.list', [
      'lists' => $lists
    ]);
  }


  public function Task_view($id)
  {
    $helper = new \App\Helpers\Helpers();

    // Validate ID
    if (!$id || !is_numeric($id)) {
      return response([
        'status' => 400,
        'message' => 'Invalid task ID',
        'error_msg' => 'Task ID is required and must be numeric',
        'responseData' => [],
        'data' => ['html' => '']
      ], 400);
    }

    try {

      $dailyTask = DB::table('et_daily_tasks')
        ->where('sno', $id)
        ->where('status', '!=', 2)
        ->first();

      if ($dailyTask->is_journal == 1) {
        $task_data = DB::table('et_daily_tasks')
          ->select(
            'et_daily_tasks.*',
            'et_manage_journal.paper_name as product_task_name',
            'et_manage_journal.journal_id as task_inc_no',
            'et_manage_journal.service_id',
            'et_staff.staff_name as created_staff_name',
            'et_customer.cus_name',
            'et_customer.customer_id as cus_id',
            'et_product_category.product_category_name',
            'et_customer_services.proposal_id',
            DB::raw("CASE
              WHEN et_customer_services.product_package = 1 THEN et_product.product_name
              WHEN et_customer_services.product_package = 2 THEN et_package.package_name
              ELSE NULL
            END as product_name")
          )
          ->leftJoin('et_journal_revision', 'et_journal_revision.sno', '=', 'et_daily_tasks.task_id')
          ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_journal_revision.journal_id')
          ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_revision.customer_id')
          ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_revision.service_id')
          ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_journal_revision.pc_id')
          ->leftJoin('et_product', function ($join) {
            $join->on('et_product.sno', '=', 'et_customer_services.product_id')
              ->where('et_customer_services.product_package', '=', 1);
          })
          ->leftJoin('et_package', function ($join) {
            $join->on('et_package.sno', '=', 'et_customer_services.package_id')
              ->where('et_customer_services.product_package', '=', 2);
          })
          ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
          ->where('et_daily_tasks.sno', $id)
          ->where('et_daily_tasks.status', '!=', 2)
          ->first();
      } else {
        $task_data = DB::table('et_daily_tasks')->select(
          'et_daily_tasks.*',
          'et_daily_tasks.task_hours as task_daily_hours',
          'et_task.service_id',
          'et_task.task_id as task_inc_no',
          'et_task.task_check_list_ids',
          'et_task.working_hours',
          'et_task.task_desc',
          'et_staff.staff_name AS created_staff_name',
          'et_customer.cus_name',
          'et_customer.cus_mobile',
          'et_customer.customer_id AS cus_id',
          'et_product_category.product_category_name',
          'et_product_category.jouranal_check',
          'et_customer_services.proposal_id',
          'et_product_task.task_name as product_task_name',
          DB::raw("CASE
              WHEN et_customer_services.product_package = 1 THEN et_product.product_name
              WHEN et_customer_services.product_package = 2 THEN et_package.package_name
              ELSE NULL
            END as product_name")
        )
          ->leftJoin('et_task', 'et_task.sno', '=', 'et_daily_tasks.task_id')
          ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
          ->leftJoin('et_customer_services', 'et_task.service_id', 'et_customer_services.sno')
          ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
          ->leftJoin('et_product', function ($join) {
            $join->on('et_product.sno', '=', 'et_customer_services.product_id')
              ->where('et_customer_services.product_package', '=', 1);
          })
          ->leftJoin('et_package', function ($join) {
            $join->on('et_package.sno', '=', 'et_customer_services.package_id')
              ->where('et_customer_services.product_package', '=', 2);
          })
          ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
          ->leftJoin('et_staff', 'et_task.created_by', 'et_staff.sno')
          ->where('et_daily_tasks.sno', $id)
          ->first();
      }

      // Fetch task data


      // Check if task exists
      if (!$task_data) {
        return response([
          'status' => 404,
          'message' => 'Task not found',
          'error_msg' => 'No task found with the provided ID',
          'responseData' => [],
          'data' => ['html' => '']
        ], 404);
      }

      // Process checklist data
      $check_list = json_decode($task_data->task_check_list_ids ?? '[]', true);
      $check_list_count = $task_data->max_page_or_per;
      $completed_count  = $task_data->min_page_or_per;
      $balance_count = $check_list_count - $completed_count;

      $html = '';
      $variant_name = '-';
      $variable_name = '-';

      // Fetch product list
      $productList = DB::table('et_customer_services')
        ->select(
          'et_customer_services.*',
          'et_product_category.product_category_name'
        )
        ->where('et_customer_services.proposal_id', $task_data->proposal_id)
        ->leftJoin('et_product', function ($join) {
          $join->on('et_product.sno', '=', 'et_customer_services.product_id')
            ->where('et_customer_services.product_package', '=', 1);
        })
        ->leftJoin('et_package', function ($join) {
          $join->on('et_package.sno', '=', 'et_customer_services.package_id')
            ->where('et_customer_services.product_package', '=', 2);
        })
        ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->orderBy('et_customer_services.sno', 'desc')
        ->where('et_customer_services.sno', $task_data->service_id)
        ->get();

      // Process variant and variable data
      foreach ($productList as $product) {
        $variant_variable_data = json_decode($product->variant_variable_ids ?? '[]', true);
        if (!empty($variant_variable_data) && is_array($variant_variable_data)) {
          foreach ($variant_variable_data as $cart_item) {
            $variant_name = $helper->get_variant_data_by_id($cart_item['variant_id'])->product_variant_name ?? 'N/A';
            $variable_name = $helper->get_variable_data_by_id($cart_item['variable_id'])->variable_name ?? 'N/A';
            break;
          }
        }
      }

      $task_data->product_list = $productList;

      // Calculate time data
      $grandTotalSeconds = 0;
      $staff_details = $helper->staff_details($task_data->staff_id);
      $staff_name_main = $staff_details->staff_name ?? "-";
      $nick_name_main = $staff_details->nick_name ?? "-";
      $staff_image_main = $staff_details->staff_image ?? "";
      $job_position_name = $staff_details->job_position_name ?? "-";
      $gender_main = $staff_details->gender ?? 0;

      $task_log = DB::table('et_task_log')
        ->where('task_id', $id)
        ->where('staff_id', $task_data->staff_id)
        ->where('status', 1)
        ->get();

      $totalSeconds = 0;
      foreach ($task_log as $log) {
        if (!empty($log->duration)) {
          list($h, $m, $s) = explode(':', $log->duration);
          $totalSeconds += ($h * 3600) + ($m * 60) + $s;
          $grandTotalSeconds += ($h * 3600) + ($m * 60) + $s;
        }
      }

      // Calculate durations
      $totalHours = floor($totalSeconds / 3600);
      $totalMinutes = floor(($totalSeconds % 3600) / 60);
      $totalDuration = $totalHours > 0 ? $totalHours . 'h ' . $totalMinutes . 'm' : $totalMinutes . 'm';

      $grandTotalHours = floor($grandTotalSeconds / 3600);
      $grandTotalMinutes = floor(($grandTotalSeconds % 3600) / 60);
      $grandTotalDuration = $grandTotalHours > 0 ? $grandTotalHours . 'h ' . $grandTotalMinutes . 'm' : $grandTotalMinutes . 'm';

      $completed_date = '-';
      if ($task_data->staff_id == $task_data->task_completed_by) {
        $completed_date = isset($task_data->task_completed_date_time) ? date('d M Y, H:i A', strtotime($task_data->task_completed_date_time)) : '-';
      }

      // Fetch and display checklists
      $checklists = json_decode($task_data->task_check_list_ids ?? '[]', true);
      $checkLists = [];
      $ver_check = json_decode($task_data->checked_checklist ?? '[]', true);

      // Build Modern HTML UI
      $html .= '
        <div class="task-view-container">
            <!-- Header Section -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="task-header bg-gradient-primary text-white rounded-3 p-4 shadow-sm">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h2 class="mb-1 fw-bold fs-2" style="color: #ffeca9 ">
                                    ' . htmlspecialchars($task_data->product_task_name ?? 'Untitled Task') . '
                                </h2>
                                <p class="mb-0 opacity-75">
                                    <i class="mdi mdi-account-outline me-1"></i>
                                    Created by ' . htmlspecialchars($task_data->created_staff_name ?? '-') . '
                                </p>
                            </div>
                            <div class="task-badge">
                                <span class="badge bg-white text-primary fs-6 px-3 py-2">
                                    # ' . htmlspecialchars($task_data->task_inc_no) . '
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content Grid -->
            <div class="row">
                <!-- Left Column - Task Details -->
                <div class="col-lg-8">
                    <!-- Customer & Service Info Card -->
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header bg-transparent border-0 py-3">
                            <h5 class="card-title mb-0 text-dark">
                                <i class="mdi mdi-information-outline text-primary me-2"></i>
                                Task Details
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="detail-item">
                                        <label class="text-muted small fw-semibold mb-1">
                                            <i class="mdi mdi-account-circle-outline me-1"></i>
                                            Customer
                                        </label>
                                        <div class="fw-bold text-dark fs-6">
                                            ' . htmlspecialchars($task_data->cus_name ?? '-') . '
                                            <small class="text-primary ms-1">(' . htmlspecialchars($task_data->cus_id ?? '-') . ')</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="detail-item">
                                        <label class="text-muted small fw-semibold mb-1">
                                            <i class="mdi mdi-cog-outline me-1"></i>
                                            Service
                                        </label>
                                        <div class="fw-bold text-dark fs-6">
                                            ' . htmlspecialchars($task_data->product_name ?? '-') . '
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="detail-item">
                                        <label class="text-muted small fw-semibold mb-1">
                                            <i class="mdi mdi-dropbox me-1"></i>
                                            Product Category
                                        </label>
                                        <div class="fw-bold text-dark fs-6">
                                            ' . htmlspecialchars($task_data->product_category_name ?? '-') . '
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="detail-item">
                                        <label class="text-muted small fw-semibold mb-1">
                                            <i class="mdi mdi-package-variant me-1"></i>
                                            Variant
                                        </label>
                                        <div class="fw-bold text-dark fs-6">
                                            ' . htmlspecialchars($variant_name) . '
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="detail-item">
                                        <label class="text-muted small fw-semibold mb-1">
                                            <i class="mdi mdi-tune-vertical me-1"></i>
                                            Variable
                                        </label>
                                        <div class="fw-bold text-dark fs-6">
                                            ' . htmlspecialchars($variable_name) . '
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="detail-item">
                                        <label class="text-muted small fw-semibold mb-2">
                                            <i class="mdi mdi-text-long me-1"></i>
                                            Description
                                        </label>
                                        <div class="task-description bg-light rounded-2 p-3">
                                            <p class="mb-0 text-dark fs-6">
                                                ' . htmlspecialchars($task_data->task_desc ?? 'No description provided.') . '
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Checklist & Progress in Same Row -->
                    <div class="row">
                    <!-- Progress Summary -->
                        <div class="col-lg-6">
                            <div class="card border-0 shadow-sm h-100">
                                <div class="card-header bg-transparent border-0 py-3">
                                    <h5 class="card-title mb-0 text-dark">
                                        <i class="mdi mdi-chart-pie text-warning me-2"></i>
                                        Progress Summary
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="progress-summary text-center">
                                        <div class="progress mb-4" style="height: 12px;">
                                            <div class="progress-bar bg-success" role="progressbar"
                                                style="width: ' . ($check_list_count > 0 ? ($completed_count / $check_list_count) * 100 : 0) . '%"
                                                aria-valuenow="' . ($check_list_count > 0 ? ($completed_count / $check_list_count) * 100 : 0) . '"
                                                aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>

                                        <div class="row g-3 mb-4">
                                            <div class="col-4">
                                                <div class="stat-item">
                                                    <div class="fw-bold fs-3 text-primary">' . $check_list_count . '</div>
                                                    <small class="text-muted">Total</small>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="stat-item">
                                                    <div class="fw-bold fs-3 text-success">' . $completed_count . '</div>
                                                    <small class="text-muted">Done</small>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="stat-item">
                                                    <div class="fw-bold fs-3 text-warning">' . $balance_count . '</div>
                                                    <small class="text-muted">Pending</small>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="completion-rate">
                                            <div class="fw-bold text-dark mb-2">Completion Rate</div>
                                            <div class="display-4 text-primary fw-bold">
                                                ' . ($check_list_count > 0 ? round(($completed_count / $check_list_count) * 100, 1) : 0) . '%
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          </div>';
                        if(count($ver_check) > 0){
                          $hide = 'inline-block';
                        }else{
                          $hide = 'none';
                        }
                        $html .= '<!-- Task Checklist -->
                        <div class="col-lg-6" style="display: '.$hide.';">
                            <div class="card border-0 shadow-sm h-100">
                                <div class="card-header bg-transparent border-0 py-3">
                                    <h5 class="card-title mb-0 text-dark">
                                        <i class="mdi mdi-format-list-checks text-success me-2"></i>
                                        Task Checklist
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="checklist-container" style="max-height: 200px; overflow-y: auto;">';



      if (is_array($checklists) && !empty($checklists)) {
        foreach ($checklists as $index => $check) {
          $task_check = DB::table('et_task_checklist')
            ->where('sno', $check)
            ->select('task_checklist', 'sno')
            ->first();

          $checkExists = in_array($check, $ver_check) ? true : false;

          if ($task_check) {
            $checkLists[] = $task_check;

            if($checkExists){
              $tick_class = 'success';
            }else{
              $tick_class = 'danger';
            }

            $html .= '
                      <div class="bg-'.$tick_class.' mb-2 rounded " >
                          <label class="form-check-label text-white fw-semibold fs-6 ms-2">
                                ' . ($index + 1) . '. ' . htmlspecialchars($task_check->task_checklist) . '
                          </label>
                      </div>';
          }
        }
      } else {
        $html .= '
                                        <div class="text-center py-4">
                                            <i class="mdi mdi-clipboard-text-outline text-muted fs-1"></i>
                                            <p class="text-muted mt-2 mb-0">No checklists available for this task</p>
                                        </div>';
      }

      $html .= '
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>

                <!-- Right Column - Staff & Time Spent -->
                <div class="col-lg-4">
                    <!-- Combined Staff Assignment & Time Spent Card -->
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0 py-3">
                            <h5 class="card-title mb-0 text-dark">
                                <i class="mdi mdi-account-clock text-info me-2"></i>
                                Staff & Time Tracking
                            </h5>
                        </div>
                        <div class="card-body mb-5">
                            <!-- Staff Profile Section -->
                            <div class="staff-section text-center mb-4 pb-3 border-bottom">
                                <div class="staff-profile">';

      if ($staff_image_main && file_exists(public_path('staff_images/' . $staff_image_main))) {
        $img_main = '<img src="' . asset('staff_images/' . $staff_image_main) . '" class="staff-avatar rounded-circle shadow" data-bs-toggle="tooltip" title="' . $staff_name_main . '">';
      } else {
        $img_main = '<div class="staff-avatar-placeholder rounded-circle bg-primary text-white d-flex align-items-center justify-content-center shadow">
                            <span class="fw-bold fs-5">' . strtoupper(substr($staff_name_main, 0, 1)) . '</span>
                        </div>';
      }

      $html .= '
                                    ' . $img_main . '
                                    <h6 class="mt-3 mb-1 fw-bold text-dark">' . htmlspecialchars($staff_name_main) . '</h6>
                                    <p class="text-muted small mb-2">' . htmlspecialchars($nick_name_main) . '</p>
                                    <span class="badge bg-info bg-opacity-10 text-info">' . htmlspecialchars($job_position_name) . '</span>
                                </div>
                            </div>';

                            if($dailyTask->is_journal != 1) {
                              $html .= '<!-- Total Time Spent Section -->
                            <div class="time-spent-section text-center mb-4">
                                <div class="total-hours">
                                    <div class="text-muted small mb-2">Allocated Hours</div>
                                    <div class="display-5 text-primary fw-bold mb-3">' . htmlspecialchars(!empty($task_data->task_daily_hours)
          ? $task_data->task_daily_hours . ' ' . ($task_data->task_daily_hours == 1 ? 'hr' : 'hrs')
          : '0m') . '</div>
                                </div>
                            </div>';
                            }

                          $html .= '
                            <!-- Time Logs Section -->
                            <div class="time-logs-section">
                                <button class="btn btn-outline-primary btn-sm w-100 mb-3" type="button" data-bs-toggle="collapse" data-bs-target="#timeLogs">
                                    <i class="mdi mdi-clock-outline me-1"></i>
                                    View Detailed Time Logs
                                </button>

                                <div class="collapse" id="timeLogs">
                                    <div class="time-logs-container mb-5 mt-6" style="max-height: 200px; overflow-y: auto;">';

      foreach ($task_log as $log) {
        $start_date = isset($log->start_time) ? date('d M Y', strtotime($log->start_time)) : '-';
        $start_time = isset($log->start_time) ? date('H:i A', strtotime($log->start_time)) : '';
        $end_time = isset($log->end_time) ? date('H:i A', strtotime($log->end_time)) : '';

        $duration = '-';
        if (!empty($log->duration)) {
          list($hours, $minutes, $seconds) = explode(':', $log->duration);
          $hours = (int)$hours;
          $minutes = (int)$minutes;

          if ($hours > 0) {
            $duration = $hours . 'h ' . $minutes . 'm';
          } else {
            $duration = $minutes . 'm';
          }
        }

        $html .= '
                                        <div class="log-item border-bottom pb-2 mb-2">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <small class="text-muted">' . $start_date . '</small>
                                                    <div class="fw-semibold small">' . $start_time . ' - ' . $end_time . '</div>
                                                </div>
                                                <span class="badge bg-primary bg-opacity-10 text-white">' . $duration . '</span>
                                            </div>
                                        </div>';
      }

      $html .= '

                                    </div>
                                      <div class="time-details bg-light rounded-3 p-3 mt-5">
                                        <div class="row text-center">
                                          <div class="col-6 border-end">
                                              <small class="text-muted d-block">Completed On</small>
                                              <div class="fw-bold text-dark small">' . htmlspecialchars($completed_date) . '</div>
                                          </div>
                                          <div class="col-6">
                                              <small class="text-muted d-block">Session Time</small>
                                              <div class="fw-bold text-primary small">' . htmlspecialchars($totalDuration) . '</div>
                                          </div>
                                        </div>
                                      </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <style>

        .task-view-container {
            font-family: \'Inter\', sans-serif;
        }
        .task-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .staff-avatar {
            width: 80px;
            height: 80px;
            border: 3px solid #fff;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .staff-avatar-placeholder {
            width: 80px;
            height: 80px;
            margin: 0 auto;
            font-size: 1.5rem;
        }
        .checklist-item {
            transition: all 0.3s ease;
            border-radius: 8px;
        }
        .checklist-item:hover {
            background-color: #f8f9fa;
            transform: translateX(5px);
        }
        .form-check-input:checked {
            background-color: #198754;
            border-color: #198754;
        }
        .detail-item {
            padding: 8px 0;
        }
        .task-description {
            border-left: 4px solid #667eea;
        }
        .log-item {
            transition: all 0.2s ease;
        }
        .log-item:hover {
            background-color: #f8f9fa;
            border-radius: 6px;
            padding-left: 8px;
            padding-right: 8px;
        }
        .stat-item {
            padding: 10px;
        }
        .progress {
            border-radius: 10px;
        }
        .progress-bar {
            border-radius: 10px;
        }
        .card {
            border-radius: 12px;
        }
        .time-details {
            border: 1px solid #e9ecef;
        }
        </style>';

      // Prepare response data
      $uploadedFiles = [];
      $responseData = (array)$task_data;
      $responseData['uploaded_files'] = $uploadedFiles;

      return response([
        'status' => 200,
        'message' => 'Task fetched successfully',
        'error_msg' => null,
        'responseData' => $responseData,
        'data' => [
          'html' => $html,
          'product_list' => $task_data->product_list,
        ]
      ], 200);
    } catch (\Exception $e) {
      return response([
        'status' => 500,
        'message' => 'Internal server error',
        'error_msg' => 'An error occurred while fetching task details' . $e->getMessage(),
        'responseData' => [],
        'data' => ['html' => '']
      ], 500);
    }
  }

  public function Update_task(Request $request)
  {
    $user = $request->user();
    $task_sno = $request->task_sno;
    $task_chk = $request->task_chk ?? [];
    $rework_chk = $request->rework_chk ?? [];
    $task_completedhidden = $request->task_completedhidden ?? 0;
    $updateSuccess = false;


    $task = ManageTaskModel::where('sno', $task_sno)
      ->where('status', 0)
      ->first();

    if (!$task) {
      session()->flash('toastr', ['type' => 'error', 'message' => 'Task not found!']);
      return redirect()->back();
    }

    // Update rework checklist items
    if (!empty($rework_chk)) {
      foreach ($rework_chk as $rev_chk) {
        $reworkTask = ReworkReasonModel::where('sno', $rev_chk)->first();
        if ($reworkTask) {
          $reworkPercentage = intval($request->task_pecentage[$rev_chk] ?? 0);
          if ($reworkPercentage > 0) {
            $reworkTask->rework_percentage = $reworkPercentage;
            $reworkTask->rework_staff_id = $user->user_id;
            $reworkTask->updated_by = $user->user_id;
            $reworkTask->save();
            $updateSuccess = true;
          }
        }
      }
    }

    // Update normal checklist items with task_type and id
    if (!empty($task_chk)) {
      foreach ($task_chk as $sno) {

        $checklistItem = ManageTaskChecklistModel::where('sno', $sno)
          ->where('task_id', $task_sno)
          ->first();

        if ($checklistItem) {
          $checklistItem->updated_by = $user->user_id;
          $checklistItem->completed_staff_id = $user->user_id;
          $completedPercentage = intval($request->task_pecentage[$sno] ?? 0);
          $checklistItem->completed_percentage = $completedPercentage;
          $checklistItem->save();
          $updateSuccess = true;
        }
      }
    }

    // return $checklistItem;

    // ! Update task status if completed
    if ($task_completedhidden) {
      $task->status = 3;
      $task->task_completed_date_time = now();
      $task->task_completed_by = $user->user_id;
      $task->save();
      $updateSuccess = true;
    }

    // ! DropZone Handling
    $uploadedFilesJson = $request->uploaded_files ?? '[]';
    $uploadedFilesArray = json_decode($uploadedFilesJson, true);
    $existingAttachments = json_decode($task->attachments ?? '[]', true);

    if (!is_array($existingAttachments)) {
      $existingAttachments = [];
    }
    if (!is_array($uploadedFilesArray)) {
      $uploadedFilesArray = [];
    }

    $mergedAttachments = array_merge($existingAttachments, $uploadedFilesArray);
    $task->attachments = json_encode($mergedAttachments);
    $task->save();
    $updateSuccess = true;

    if ($updateSuccess) {
      session()->flash('toastr', ['type' => 'success', 'message' => 'Task Updated Successfully!']);
    } else {
      session()->flash('toastr', ['type' => 'error', 'message' => 'Could not update the Task!']);
    }

    return redirect()->back();
  }

  // Start task timer: insert a new row with start_time
  public function start(Request $request)
  {
    $request->validate([
      'task_id' => 'required|integer',
      'staff_id' => 'required|integer',
    ]);

    $taskLog = TaskLogModel::where('staff_id', $request->staff_id)
      ->where('status', 0)
      ->latest('sno')
      ->first();

    if ($taskLog) {
      return response()->json([
        'status' => false,
        'message' => 'A timer is already running for another task.'
      ], 409); // HTTP 409 Conflict
    }

    $update_main = DailyTaskModel::where('sno', $request->task_id)->where('status', 0)->first();
    if ($update_main) {
      $update_main->status = 1;
      $update_main->save();
    }

    $isJournal = $request->is_journal;
    $isRequest = $request->is_request;

    if($isJournal == 1 && $update_main) {
      DB::table('et_journal_revision')
        ->where('sno', $update_main->task_id)
        ->where('status', 4)
        ->update([
          'status' => 5
        ]);
    }

    if ($isRequest == 1 && $update_main) {
      DB::table('et_task_request')
        ->where('sno', $update_main->task_id)
        ->where('status', 4)
        ->update([
          'status' => 5
        ]);
    }


    $branch_id = $request->user()->branch_id;
    $taskLog = new TaskLogModel();
    $taskLog->task_id   = $request->task_id;
    $taskLog->staff_id  = $request->staff_id;
    $taskLog->branch_id = $branch_id;
    $taskLog->start_time = now();
    $taskLog->created_by = $request->staff_id;
    $taskLog->updated_by = $request->staff_id;
    $taskLog->status = 0;
    $taskLog->save();

    return response()->json(['message' => 'Task timer started', 'id' => $taskLog->sno]);
  }

  // Stop task timer: update end_time and duration on last started row for this task & staff
  public function stop(Request $request)
  {
    $request->validate([
      'task_id' => 'required|integer',
      'staff_id' => 'required|integer',
    ]);


    $taskLog = TaskLogModel::where('task_id', $request->task_id)
      ->where('staff_id', $request->staff_id)
      ->orderBy('sno', 'desc')
      ->first();

    if (!$taskLog) {
      return response()->json(['message' => 'No started task log found'], 404);
    }

    $taskLog->end_time = now();

    // Calculate duration = end_time - start_time (as time)
    $durationSeconds = strtotime($taskLog->end_time) - strtotime($taskLog->start_time);
    $hours = floor($durationSeconds / 3600);
    $minutes = floor(($durationSeconds % 3600) / 60);
    $seconds = $durationSeconds % 60;
    $taskLog->duration = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);

    $taskLog->status = 1;
    $taskLog->updated_by = $request->staff_id;
    $taskLog->save();

    return response()->json(['message' => 'Task timer stopped', 'duration' => $taskLog->duration, 'log_id' => $taskLog->sno]);
  }

  public function runningTaskLog(Request $request)
  {
    $staffId = auth()->user()->user_id;

    $runningLog = DB::table('et_task_log')
      ->where('staff_id', $staffId)
      ->where('status', 0)
      ->orderByDesc('sno')
      ->first();

    if (!$runningLog) {
      return response()->json(['running' => false], 200);
    }

    $startTime = Carbon::parse($runningLog->start_time);
    $now = Carbon::now();
    $diffInSeconds = $now->diffInSeconds($startTime);

    return response()->json([
      'running' => true,
      'task_id' => $runningLog->task_id,
      'elapsed_seconds' => $diffInSeconds,
      'start_time' => $startTime->toDateTimeString()
    ]);
  }
  public function taskFiles(Request $request)
  {
    $request->validate([
      'file_upload.*' => 'required|file|max:10240',
      'folder_name' => 'required|string'
    ]);

    $folderName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $request->folder_name); // Sanitize folder
    $uploadPath = public_path('task_files/' . $folderName);

    if (!file_exists($uploadPath)) {
      mkdir($uploadPath, 0777, true);
    }

    $uploaded = [];

    foreach ($request->file('file_upload') as $file) {
      $timestamp = now()->format('Ymd_His');
      $extension = $file->getClientOriginalExtension();
      $fileName = $timestamp . '_' . uniqid() . '.' . $extension;

      $file->move($uploadPath, $fileName);
      $uploaded[] = $fileName;
    }

    return response()->json([
      'success' => true,
      'files' => $uploaded
    ]);
  }

  public function deleteUploadedFile(Request $request)
  {
    $request->validate([
      'file_name' => 'required|string',
      'folder_name' => 'required|string'
    ]);

    $folderName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $request->folder_name);
    $filePath = public_path("task_files/{$folderName}/" . $request->file_name);

    if (file_exists($filePath)) {
      unlink($filePath);
      return response()->json(['success' => true]);
    } else {
      return response()->json(['success' => false, 'message' => 'File not found']);
    }
  }

  public function complete_task_data_fetch($id)
  {
    $helper =  new \App\Helpers\Helpers();
    $data = DB::table('et_daily_tasks')
      ->select(
        'et_daily_tasks.*',
        'et_daily_tasks.task_hours as daily_task_hours',
        'et_customer.cus_name',
        'et_customer.customer_id as cus_id',
        'et_customer.cus_mobile',
        'pc_staff.staff_name as pc_name',
        'pro_staff.staff_name as pro_staff_name',
        'pro_staff.nick_name as pro_nick_name',
        'pro_staff.staff_image as staff_image',
        'et_product_category.product_category_name',
        'et_customer_services.variant_variable_ids',
        'et_product_task.task_name',
        'et_task.pages_percentage',
        'et_task.working_hours',
        'et_task.task_category',
        'et_task.task_desc',
        'et_job_position.job_position_name',
        'et_task.task_id as tsk_id',
        DB::raw("CASE
          WHEN et_customer_services.product_package = 1 THEN et_product.product_name
          WHEN et_customer_services.product_package = 2 THEN et_package.package_name
          ELSE NULL
        END as product_name"),
      )
      ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_daily_tasks.service_id')
      ->leftJoin('et_staff as pc_staff', 'pc_staff.sno', '=', 'et_daily_tasks.created_by')
      ->leftJoin('et_staff as pro_staff', 'pro_staff.sno', '=', 'et_daily_tasks.staff_id')
      ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'pro_staff.position_role')
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
      ->leftJoin('et_product', function ($join) {
        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
          ->where('et_customer_services.product_package', '=', 1);
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->leftJoin('et_task', 'et_task.sno', 'et_daily_tasks.task_id')
      ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
      ->where('et_daily_tasks.sno', $id)
      ->first();

    $variant_name = null;
    $variable_name = null;

    $variant_variable_data = json_decode($data->variant_variable_ids ?? '[]', true);
    if (!empty($variant_variable_data) && is_array($variant_variable_data)) {
      foreach ($variant_variable_data as $cart_item) {
        $variant_name = $helper->get_variant_data_by_id($cart_item['variant_id'])->product_variant_name ?? 'N/A';
        $variable_name = $helper->get_variable_data_by_id($cart_item['variable_id'])->variable_name ?? 'N/A';
        break;
      }
    }

    // attach to your data object
    $data->variant_name = $variant_name;
    $data->variable_name = $variable_name;

    $staff_image_main = $data->staff_image;
    if ($staff_image_main && file_exists(public_path('staff_images/' . $staff_image_main))) {
      $img_main = '<img src="' . asset('staff_images/' . $staff_image_main) . '" class="staff-avatar rounded-circle shadow" data-bs-toggle="tooltip" title="' . $data->pro_staff_name . '">';
    } else {
      $img_main = '<div class="staff-avatar-placeholder rounded-circle bg-primary text-white d-flex align-items-center justify-content-center shadow">
                            <span class="fw-bold fs-5">' . strtoupper(substr($data->pro_staff_name, 0, 1)) . '</span>
                        </div>';
    }

    $task_log = DB::table('et_task_log')
      ->where('task_id', $id)
      ->where('staff_id', $data->staff_id)
      ->where('status', 1)
      ->get();

    $totalSeconds = 0;
    $grandTotalSeconds = 0;
    foreach ($task_log as $log) {
      if (!empty($log->duration)) {
        list($h, $m, $s) = explode(':', $log->duration);
        $totalSeconds += ($h * 3600) + ($m * 60) + $s;
        $grandTotalSeconds += ($h * 3600) + ($m * 60) + $s;
      }
    }

    // Calculate durations
    $totalHours = floor($totalSeconds / 3600);
    $totalMinutes = floor(($totalSeconds % 3600) / 60);
    $totalDuration = $totalHours > 0 ? $totalHours . 'h ' . $totalMinutes . 'm' : $totalMinutes . 'm';

    $grandTotalHours = floor($grandTotalSeconds / 3600);
    $grandTotalMinutes = floor(($grandTotalSeconds % 3600) / 60);
    $grandTotalDuration = $grandTotalHours > 0 ? $grandTotalHours . 'h ' . $grandTotalMinutes . 'm' : $grandTotalMinutes . 'm';
    $grandTotalDuration = $data->working_hours > 1
        ? $data->working_hours . ' hrs'
        : $data->working_hours . ' hr';


    $completed_date = '-';
    if ($data->staff_id == $data->task_completed_by) {
      $completed_date = isset($data->task_completed_date_time) ? date('d M Y, H:i A', strtotime($data->task_completed_date_time)) : '-';
    }


    $html = '';
    foreach ($task_log as $log) {
      $start_date = isset($log->start_time) ? date('d M Y', strtotime($log->start_time)) : '-';
      $start_time = isset($log->start_time) ? date('H:i A', strtotime($log->start_time)) : '';
      $end_time = isset($log->end_time) ? date('H:i A', strtotime($log->end_time)) : '';

      $duration = '-';
      if (!empty($log->duration)) {
        list($hours, $minutes, $seconds) = explode(':', $log->duration);
        $hours = (int)$hours;
        $minutes = (int)$minutes;

        if ($hours > 0) {
          $duration = $hours . 'h ' . $minutes . 'm';
        } else {
          $duration = $minutes . 'm';
        }
      }

      $html .= '
                <div class="log-item border-bottom pb-2 mb-2">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <small class="text-muted">' . $start_date . '</small>
                            <div class="fw-semibold small">' . $start_time . ' - ' . $end_time . '</div>
                        </div>
                        <span class="badge bg-primary bg-opacity-10 text-white">' . $duration . '</span>
                    </div>
                </div>';
    }

    $html .= '

  </div>
    <div class="time-details bg-light rounded-3 p-3 mt-5">
      <div class="row text-center">
        <div class="col-6 border-end">
          <small class="text-muted d-block">Completed On</small>
          <div class="fw-bold text-dark small">' . htmlspecialchars($completed_date) . '</div>
          </div>
        <div class="col-6">
        <small class="text-muted d-block">Session Time</small>
        <div class="fw-bold text-primary small">' . htmlspecialchars($totalDuration) . '</div>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
      </div>
    </div>
  </div>';


    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $data,
      'image' => $img_main,
      'html' => $html,
      'total_time' => $grandTotalDuration
    ], 200);
  }

  public function update_task_status($id, Request $request)
  {
    $min_pages_or_per = $request->num_pages;
    $max_pages_or_per = $request->max_pages;
    $status = $request->status;
    $check_list = $request->input('checklist_ids', []);
    $user_id = $request->user()->user_id;
    $taskDescription = $request->task_desc;
    $is_journal = $request->is_journal ?? '';

    $updateTask = DailyTaskModel::where('sno', $id)->where('status', '!=', 2)->first();
    $updateTask->min_page_or_per = $min_pages_or_per;
    $updateTask->max_page_or_per = $max_pages_or_per;

    if ($min_pages_or_per == $max_pages_or_per) {
      $updateTask->checked_checklist = json_encode($check_list);
      $updateTask->task_completed_by = $user_id;
      $updateTask->task_completed_date_time = now();
      $updateTask->status = $status;
    }
    $updateTask->updated_by = $user_id;

    $updateTask->update();

    if ($min_pages_or_per == $max_pages_or_per && $is_journal == 0) {
      DB::table('et_journal_revision')
        ->where('sno', $updateTask->task_id)
        ->where('status', '!=', 2)
        ->update([
          'status' => 6,
          'updated_by' => $user_id
        ]);
    } else if ($min_pages_or_per == $max_pages_or_per && $is_journal == 1) {
      DB::table('et_task_request')
        ->where('sno', $updateTask->task_id)
        ->where('status', '!=', 2)
        ->update([
          'status' => 6,
          'updated_by' => $user_id
        ]);
    }

    if($updateTask) {
      $description = new TaskDescriptionModel();
      $description->task_id = $id;
      $description->staff_id = $user_id;
      $description->page_or_per = $min_pages_or_per;
      $description->description = $taskDescription;
      $description->created_by = $user_id;
      $description->updated_by = $user_id;
      $description->save();
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => null
    ], 200);
  }

  public function fetch_production_checklist($id)
  {
    $task = DB::table('et_task')
      ->where('et_task.sno', $id)
      ->select('task_check_list_ids')
      ->first();

    if (!$task) {
      // No task found with that id and status=0
      return response([
        'status' => 404,
        'message' => 'Task not found or inactive',
        'error_msg' => 'No task matching given ID and status.',
        'data' => [],
      ], 404);
    }

    $checklists = json_decode($task->task_check_list_ids, true);

    if (empty($checklists) || !is_array($checklists)) {
      return response([
        'status' => 200,
        'message' => 'No checklist items found',
        'error_msg' => null,
        'data' => [],
      ]);
    }

    $data = [];
    foreach ($checklists as $check) {
      $task_check = DB::table('et_task_checklist')
        ->where('sno', $check)
        ->select('task_checklist', 'sno')
        ->first();

      if ($task_check) {
        $data[] = $task_check;
      }
    }

    return response([
      'status' => 200,
      'message' => 'Data fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ]);
  }

  public function fetch_task_log($id, $staff_id)
  {
    // return $staff_id;
    $data = DB::table('et_task_log')
      ->where('task_id', $id)
      ->where('staff_id', $staff_id)
      ->where('status', 1)
      ->get();

    if ($data) {
      $taskname = DB::table('et_daily_tasks')
        ->select(
          'et_product_task.task_name'
        )
        ->leftJoin('et_task', 'et_task.sno', 'et_daily_tasks.task_id')
        ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
        ->where('et_daily_tasks.sno', $id)
        ->first();
    }

    return response([
      'status' => 200,
      'message' => 'Data fetched successfully',
      'error_msg' => null,
      'data' => $data,
      'task_name' => $taskname
    ]);
  }
   public function rework_details($id, $staffId)
  {
    $datas = DB::table('et_rework')
      ->select(
        'et_rework.*',
        'et_product_task.task_name'
      )
      ->leftJoin('et_daily_tasks', 'et_daily_tasks.sno', '=', 'et_rework.task_id')
      ->leftJoin('et_task', 'et_task.sno', '=', 'et_daily_tasks.task_id')
      ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
      ->where('et_rework.task_id', $id)
      ->where('et_rework.rework_staff_id', $staffId)
      ->where('et_rework.status', 0)
      ->orderBy('et_rework.sno', 'asc')
      ->get();

    // Check if data is empty
    if ($datas->isEmpty()) {
      $html = '<div class="alert alert-info text-center">No rework details found.</div>';
    } else {
      $html = '<div class="table-responsive shadow-sm">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 mb-0">
                        <thead>
                            <tr class="text-start align-middle fw-bold fs-6 bg-primary text-white">
                                <th class="min-w-50px px-3 py-2">Sno</th>
                                <th class="min-w-125px px-3 py-2">Allocated Pages</th>
                                <th class="min-w-80px px-3 py-2">Completed Pages</th>
                                <th class="min-w-80px px-3 py-2">Rework Reason</th>
                                <th class="min-w-80px px-3 py-2">Rework Assigned Date</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-700 fw-semibold fs-7" id="task_log_tr_data">';

      foreach ($datas as $i => $data) {
        $formattedDate = Carbon::parse($data->created_at)->format('d-M-Y h:i A');
        $html .= '<tr>
                        <td class="px-3 py-2">' . ($i + 1) . '</td>
                        <td class="px-3 py-2">
                            <span class="badge bg-info text-white fs-6 fw-semibold mb-2">' . htmlspecialchars($data->max_page_or_per) . '</span>
                        </td>
                        <td class="px-3 py-2">
                            <span class="badge bg-success text-white fs-6 fw-semibold mb-2">' . htmlspecialchars($data->min_page_or_per) . '</span>
                        </td>
                        <td class="px-3 py-2">
                            <span class="text-black fs-6 fw-semibold mb-2">' . htmlspecialchars($data->rework_reason) . '</span>
                        </td>
                        <td class="px-3 py-2">
                            <span class="badge bg-warning text-black fs-6 fw-semibold mb-2">' . $formattedDate . '</span>
                        </td>
                    </tr>';
      }

      $html .= '</tbody>
                </table>
            </div>';
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $html,
      'task_name' => $datas[0]->task_name ?? null,
    ], 200);
  }

  public function journalTaskDataFetch($id, $status) {
    if ($status == 0) {
      $data = DB::table('et_daily_tasks')
        ->leftJoin('et_journal_revision', 'et_journal_revision.sno', '=', 'et_daily_tasks.task_id')
        ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_journal_revision.journal_id')
        ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_revision.service_id')
        ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
        ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
        ->leftJoin('et_staff as jc', 'jc.sno', 'et_customer_services.jc_staff')
        ->leftJoin('et_staff as jtl', 'jtl.sno', 'et_customer_services.jc_id')
        ->where('et_daily_tasks.is_journal', 1)
        ->where('et_daily_tasks.sno', $id)
        ->where('et_daily_tasks.status', '!=', 2)
        ->select(
          'et_manage_journal.paper_name',
          'et_manage_journal.journal_id',
          'et_product.product_name',
          'jc.staff_name as jc_name',
          'jtl.staff_name as jtl_name',
          'et_journal_revision.comments',
          'et_customer_services.created_at',
          'et_customer_services.sno as service_sno',
          'et_daily_tasks.max_page_or_per',
          'et_daily_tasks.min_page_or_per'
        )
        ->first();

      $year = date('Y', strtotime($data->created_at));
      $id = str_pad($data->service_sno, 5, '0', STR_PAD_LEFT);
      $data->formatted_service_id = "SR-{$id}/{$year}";
    } elseif ($status == 1) {
      $data = DB::table('et_daily_tasks')
        ->leftJoin('et_task_request', 'et_task_request.sno', '=', 'et_daily_tasks.task_id')
        ->leftJoin('et_journal_request', 'et_journal_request.sno', '=', 'et_task_request.request_id')
        ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_task_request.journal_id')
        ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
        ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
        ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
        ->leftJoin('et_staff as jc', 'jc.sno', 'et_customer_services.jc_staff')
        ->leftJoin('et_staff as jtl', 'jtl.sno', 'et_customer_services.jc_id')
        ->where('et_daily_tasks.is_request', 1)
        ->where('et_daily_tasks.sno', $id)
        ->where('et_daily_tasks.status', '!=', 2)
        ->select(
          'et_manage_journal.paper_name',
          'et_manage_journal.journal_id',
          'et_product.product_name',
          'jc.staff_name as jc_name',
          'jtl.staff_name as jtl_name',
          'et_journal_request.request_name as comments',
          'et_customer_services.created_at',
          'et_customer_services.sno as service_sno',
          'et_daily_tasks.max_page_or_per',
          'et_daily_tasks.min_page_or_per'
        )
        ->first();

      $year = date('Y', strtotime($data->created_at));
      $id = str_pad($data->service_sno, 5, '0', STR_PAD_LEFT);
      $data->formatted_service_id = "SR-{$id}/{$year}";
    }


    if($data) {
      return response([
        'status' => 200,
        'message' => 'Data Fetched Successfully !',
        'data' => $data
      ], 200);
    }
  }

  public function uploadProductionJournal(Request $request) {
    try {
      $user_id = $request->user()->user_id;

      DB::beginTransaction();

      if ($request->journal_status == 0) {
        $updateTask = DailyTaskModel::where('status', '!=', 2)
          ->where('is_journal', 1)
          ->where('sno', $request->task_id)
          ->first();
      } elseif ($request->journal_status == 1) {
        $updateTask = DailyTaskModel::where('status', '!=', 2)
          ->where('is_request', 1)
          ->where('sno', $request->task_id)
          ->first();
      }

      if($updateTask) {
        $updateTask->status = 4;
        $updateTask->updated_by = $user_id;
        $updateTask->save();
      }

      if ($request->journal_status == 0) {
        $revision = DB::table('et_journal_revision')
          ->where('status', '!=', 2)
          ->where('sno', $updateTask->task_id)
          ->first();

        $driveDetails = DB::table('et_manage_journal')
          ->where('et_manage_journal.sno', $revision->journal_id)
          ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
          ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
          ->select(
            'et_customer.customer_id',
            'et_customer_services.created_at',
            'et_customer_services.sno',
            'et_manage_journal.journal_id',
            'et_manage_journal.status',
          )
          ->first();

          $year = date('Y', strtotime($driveDetails->created_at));
          $id = str_pad($driveDetails->sno, 5, '0', STR_PAD_LEFT);
          $driveDetails->service_id = "SR-{$id}/{$year}";

          $status = '';

          switch ($driveDetails->status) {
            case 0:
              $status = 'Submitted';
              break;
            case 1:
              $status = 'With Editor';
              break;
            case 3:
              $status = 'Under Reviewer';
              break;
            case 4:
              $status = 'Revision';
              break;
            case 5:
              $status = 'Accepted';
              break;
            case 6:
              $status = 'Rejected';
              break;
            case 7:
              $status = 'E-Proofing';
              break;
            case 8:
              $status = 'Published';
              break;
            default:
              $status = 'Undefined';
              break;
          }

          if ($request->filled('uploaded_files')) {
            $accessToken = $this->token();
            $files = json_decode($request->uploaded_files, true);

            $rootFolderId = config('services.google_drive.folder_id');

            // ! Customer Folder
            $customerFolderName = $driveDetails->customer_id;
            $customerFolderId = $this->findDriveFolder($customerFolderName, $rootFolderId, $accessToken)
              ?? $this->createDriveFolder($customerFolderName, $rootFolderId, $accessToken);

            // ! Service Folder
            $serviceFolderName = $driveDetails->service_id;
            $serviceFolderId = $this->findDriveFolder($serviceFolderName, $customerFolderId, $accessToken)
              ?? $this->createDriveFolder($serviceFolderName, $customerFolderId, $accessToken);

            // ! Journal Folder
            $journalFolderName = $driveDetails->journal_id;
            $journalFolderId = $this->findDriveFolder($journalFolderName, $serviceFolderId, $accessToken)
              ?? $this->createDriveFolder($journalFolderName, $serviceFolderId, $accessToken);

            // ! Status Folder
            $statusFolderName = "Status_{$status}";
            $statusFolderId = $this->findDriveFolder($statusFolderName, $journalFolderId, $accessToken)
              ?? $this->createDriveFolder($statusFolderName, $journalFolderId, $accessToken);

            $driveDocuments = [];

            foreach ($files as $file) {

              $localPath = public_path($file['path']);

              if (!file_exists($localPath)) {
                continue;
              }

              $driveFile = $this->uploadFileToDrive(
                $localPath,
                $file['original_name'],
                $statusFolderId,
                $accessToken
              );

              $this->makeFilePublic($statusFolderId, $accessToken);
              $folderLink = "https://drive.google.com/drive/folders/{$statusFolderId}";

              $driveFileId = null;

              if (is_array($driveFile) && isset($driveFile['id'])) {
                $driveFileId = $driveFile['id'];
              } else {
                throw new Exception('Google Drive upload failed for file: ' . $file['original_name']);
              }

              $driveDocuments[] = [
                'original_name' => $file['original_name'],
                'drive_file_id' => $driveFileId,
                'status' => "Submitted",
                'folderLink' => $folderLink ?? null,
                'productionStaff' => 1
              ];


              unlink($localPath);
            }

            DB::table('et_journal_revision')
              ->where('status', 6)
              ->where('sno', $updateTask->task_id)
              ->update([
                'status' => 7,
                'updated_by' => $user_id,
                'staff_documents' => json_encode($driveDocuments)
              ]);

            // Cleanup user temp folder
            File::deleteDirectory(public_path("{$user_id}/temp"));
          }
      } elseif ($request->journal_status == 1) {
        $revision = DB::table('et_task_request')
          ->where('status', '!=', 2)
          ->where('sno', $updateTask->task_id)
          ->first();

        $driveDetails = DB::table('et_manage_journal')
          ->where('et_manage_journal.sno', $revision->journal_id)
          ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
          ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
          ->select(
            'et_customer.customer_id',
            'et_customer_services.created_at',
            'et_customer_services.sno',
            'et_manage_journal.journal_id',
            'et_manage_journal.status',
          )
          ->first();

        $year = date('Y', strtotime($driveDetails->created_at));
        $id = str_pad($driveDetails->sno, 5, '0', STR_PAD_LEFT);
        $driveDetails->service_id = "SR-{$id}/{$year}";

        $status = 'Task Request';

        if ($request->filled('uploaded_files')) {
          $accessToken = $this->token();
          $files = json_decode($request->uploaded_files, true);

          $rootFolderId = config('services.google_drive.folder_id');

          // ! Customer Folder
          $customerFolderName = $driveDetails->customer_id;
          $customerFolderId = $this->findDriveFolder($customerFolderName, $rootFolderId, $accessToken)
            ?? $this->createDriveFolder($customerFolderName, $rootFolderId, $accessToken);

          // ! Service Folder
          $serviceFolderName = $driveDetails->service_id;
          $serviceFolderId = $this->findDriveFolder($serviceFolderName, $customerFolderId, $accessToken)
            ?? $this->createDriveFolder($serviceFolderName, $customerFolderId, $accessToken);

          // ! Journal Folder
          $journalFolderName = $driveDetails->journal_id;
          $journalFolderId = $this->findDriveFolder($journalFolderName, $serviceFolderId, $accessToken)
            ?? $this->createDriveFolder($journalFolderName, $serviceFolderId, $accessToken);

          // ! Status Folder
          $statusFolderName = "Status_{$status}";
          $statusFolderId = $this->findDriveFolder($statusFolderName, $journalFolderId, $accessToken)
            ?? $this->createDriveFolder($statusFolderName, $journalFolderId, $accessToken);

          $driveDocuments = [];

          foreach ($files as $file) {

            $localPath = public_path($file['path']);

            if (!file_exists($localPath)) {
              continue;
            }

            $driveFile = $this->uploadFileToDrive(
              $localPath,
              $file['original_name'],
              $statusFolderId,
              $accessToken
            );

            $this->makeFilePublic($statusFolderId, $accessToken);
            $folderLink = "https://drive.google.com/drive/folders/{$statusFolderId}";

            $driveFileId = null;

            if (is_array($driveFile) && isset($driveFile['id'])) {
              $driveFileId = $driveFile['id'];
            } else {
              throw new Exception('Google Drive upload failed for file: ' . $file['original_name']);
            }

            $driveDocuments[] = [
              'original_name' => $file['original_name'],
              'drive_file_id' => $driveFileId,
              'status' => "Task Request",
              'folderLink' => $folderLink ?? null,
              'productionStaff' => 1
            ];


            unlink($localPath);
          }

          DB::table('et_task_request')
            ->where('status', 6)
            ->where('sno', $updateTask->task_id)
            ->update([
              'status' => 7,
              'updated_by' => $user_id,
              'staff_documents' => json_encode($driveDocuments)
            ]);

          // Cleanup user temp folder
          File::deleteDirectory(public_path("{$user_id}/temp"));
        }
      }


      DB::commit();

      return response([
        'status' => 200,
        'message' => 'Journal Documents Upload Successfully',
        'data' => null
      ], 200);
    } catch (ValidationException $e) {
      DB::rollBack();

      return response([
        'status' => 422,
        'message' => 'Validation Failed',
        'error_msg' => $e->getMessage(),
        'data' => null
      ], 422);
    } catch (Exception $e) {
      DB::rollBack();

      return response([
        'status' => 500,
        'message' => 'Failed to submit journal.',
        'error_msg' => $e->getMessage(),
        'data' => null
      ], 500);
    }
  }

  private function token()
  {
    $client_id = \Config('services.google_drive.client_id');
    $client_secret = \Config('services.google_drive.client_secret');
    $refresh_token = \Config('services.google_drive.refresh_token');
    $google_response = Http::post('https://oauth2.googleapis.com/token', [
      'client_id' => $client_id,
      'client_secret' => $client_secret,
      'refresh_token' => $refresh_token,
      'grant_type' => 'refresh_token',
    ]);

    $access_token = json_decode((string)$google_response->getBody(), true)['access_token'];
    return $access_token;
  }

  // ! Create Folder If Not Exists
  private function createDriveFolder($name, $parentId, $accessToken)
  {
    $response = Http::withToken($accessToken)
      ->post('https://www.googleapis.com/drive/v3/files', [
        'name' => $name,
        'mimeType' => 'application/vnd.google-apps.folder',
        'parents' => $parentId ? [$parentId] : [],
      ]);

    return $response->json()['id'];
  }

  // ! Find Folder By Name
  private function findDriveFolder($name, $parentId, $accessToken)
  {
    $query = "name='{$name}' and mimeType='application/vnd.google-apps.folder' and trashed=false";

    if ($parentId) {
      $query .= " and '{$parentId}' in parents";
    }

    $response = Http::withToken($accessToken)
      ->get('https://www.googleapis.com/drive/v3/files', [
        'q' => $query,
        'fields' => 'files(id, name)',
      ]);

    return $response->json()['files'][0]['id'] ?? null;
  }

  // ! Upload To Drive
  private function uploadFileToDrive($filePath, $fileName, $parentId, $accessToken)
  {
    $response = Http::withToken($accessToken)
      ->attach(
        'metadata',
        json_encode([
          'name' => $fileName,
          'parents' => [$parentId],
        ]),
        'metadata.json'
      )
      ->attach(
        'file',
        fopen($filePath, 'r'),
        $fileName
      )
      ->post('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart');

    return $response->json();
  }

  // ! Give Permission
  private function makeFilePublic($fileId, $accessToken)
  {
    Http::withToken($accessToken)
      ->post("https://www.googleapis.com/drive/v3/files/{$fileId}/permissions", [
        'role' => 'reader',
        'type' => 'anyone',
      ]);
  }
}
