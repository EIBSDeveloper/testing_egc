<?php

namespace App\Http\Controllers\customer_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\CustomerModel;
use App\Models\ReviewLinkModel;
use App\Models\ManageReviewModel;
use Illuminate\Support\Facades\Validator;

class ManageReview extends Controller
{
    public function index(Request $request){

        $branch_id = $request->user()->branch_id;

        $customers = CustomerModel::where('branch_id', $branch_id)->where('status', '!=', 2)->get();
        $reviews = ReviewLinkModel::where('status', '!=', 2)->get();

        $records = ManageReviewModel::where('et_manage_review.status', '!=', 2)
        ->select(
            'et_manage_review.*',
            'et_customer.cus_name',
            'et_customer.customer_id'
        )
        ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_review.customer_id')
        ->where('et_manage_review.branch_id', $branch_id)->get();

        $star_5 = ManageReviewModel::where('status', '=', 0)->where('ratings', 5)->count();
        $star_4 = ManageReviewModel::where('status', '=', 0)->where('ratings', 4)->count();
        $star_3 = ManageReviewModel::where('status', '=', 0)->where('ratings', 3)->count();
        $star_2 = ManageReviewModel::where('status', '=', 0)->where('ratings', 2)->count();
        $star_1 = ManageReviewModel::where('status', '=', 0)->where('ratings', 1)->count();

        $total_reviews = $star_1 + $star_2 + $star_3 + $star_4 + $star_5;


        return view('content.customer_management.manage_review', compact('customers', 'reviews', 'records', 'star_5', 'star_4', 'star_3', 'star_2', 'star_1', 'total_reviews'));
    }

    public function Create(Request $request){

        $validator = Validator::make($request->all(), [
            'google_review' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 422,
                'message' => 'Incorret Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 422);
        }

        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;


        $CREATE = new ManageReviewModel();
        $CREATE->branch_id = $branch_id;
        $CREATE->customer_id = $request->customer_id;
        $CREATE->ratings = $request->rating_value;
        $CREATE->review = $request->google_review;
        $CREATE->review_image = $request->review_image ?? 0;

        // Review Links
        $selected_links = $request->input('review_links');

        if(!empty($selected_links)){
            $links_array = array_map(function ($link_id) {
                return ['link' => $link_id];
            }, $selected_links);

            $linksJson = json_encode($links_array);
        } else {
            $linksJson = json_encode([]);
        }

        $CREATE->review_list = $linksJson;
        $CREATE->created_by = $user_id;
        $CREATE->updated_by = $user_id;
        $CREATE->save();

        if ($CREATE) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Review Added Successfully'
            ]);
            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Review Creation Failed'
            ]);
            return redirect()->back();
        }
    }

    public function Edit($id = ''){
        $data = ManageReviewModel::where('status', '!=', 2)->where('sno', $id)->first();

        if($data){
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 404,
                'message' => 'Data Fetch Unsuccess!',
                'error_msg' => null,
                'data' => null
            ], 404);
        }
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'upd_gogle_review' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 422,
                'message' => 'Incorret Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 422);
        }

        $sno = $request->edit_id;
        $user_id = $request->user()->user_id;


        $UPDATE = ManageReviewModel::where('sno', $sno)->where('status', '!=', 2)->first();
        $UPDATE->customer_id = $request->upd_customer_id;
        $UPDATE->ratings = $request->upd_student_ratings_hidden;
        $UPDATE->review = $request->upd_gogle_review;
        $UPDATE->review_image = isset($request['review_image_update']) ? 1 : 0;

        // Review Links
        $selected_links = $request->input('links');

        if (!empty($selected_links)) {
            $links_array = array_map(function ($link_id) {
                return ['link' => $link_id];
            }, $selected_links);

            $linksJson = json_encode($links_array);
        } else {
            $linksJson = json_encode([]);
        }

        $UPDATE->review_list = $linksJson;
        $UPDATE->updated_by = $user_id;
        $UPDATE->update();

        if ($UPDATE) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Review Updated Successfully'
            ]);
            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Review Updation Failed'
            ]);
            return redirect()->back();
        }
    }
}