<?php

namespace App\Http\Controllers\customer_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\ProposalModel;
use App\Models\PreProposalModel;
use App\Models\ManageProductVariableModel;
use App\Models\ManageProductVaiantModel;
use App\Models\TempProposalModel;
use App\Models\ProductModel;
use Illuminate\Support\Facades\Validator;
use App\Mail\ETPLMail;
use App\Models\EmailTemplateModel;
use App\Models\BranchModel;
use App\Models\LeadModel;
use App\Models\CustomerModel;
use App\Models\StaffModel;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;

class ManageInvoice extends Controller
{
  public function index(Request $request)
  {
     $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $user_id   = $request->user()->user_id ;
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
       $startTime = microtime(true);
      $search_fill           = $request->search_fill ?? '';

        $transaction = DB::table('et_transaction')
            ->select(
              'et_transaction.invoice_id',
              'et_payment.pay_slot_id as slot_id',
              'et_transaction.transaction_date',
              'et_customer.cus_name',
              'et_customer.sno as cus_id',
              'et_customer.customer_id',
              'et_customer.cus_mobile',
              'et_customer.cus_email_id',
              'et_proposal.nda_old_customer_check',
              'et_proposal.nda_temp_link',
              'et_proposal.nda_signed',
              'et_proposal.sno as proposal_id',
              'et_proposal_pay_slot.paidAmount',
              'et_manage_nda.nda_id',
              'et_proposal_pay_slot.total_amount'
              )
            ->join('et_customer','et_customer.sno','=','et_transaction.customer_id')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal','et_proposal.sno','=','et_payment.proposal_id')
            ->leftJoin('et_manage_nda','et_proposal.sno','=','et_manage_nda.proposal_id')
            ->join('et_proposal_pay_slot','et_proposal_pay_slot.sno','=','et_payment.pay_slot_id')
            ->where('et_transaction.customer_type', 0)
            ->where('et_transaction.status', 0);
            if ($search_fill != '') {
              $transaction->where(function ($query) use ($search_fill) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                  ->orWhere('et_transaction.invoice_id', 'LIKE', "%{$search_fill}%")
                  ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                  ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
              });
            }
       $transaction=$transaction->orderBy('et_transaction.sno', 'desc')
            ->paginate($perpage);
            
        foreach($transaction as $pay){
            $sloData=DB::table('et_proposal_pay_slot')
                     ->where('sno','!=',$pay->slot_id)
                     ->where('proposal_sno',$pay->proposal_id)
                     ->where('status',0)
                     ->get();
            $previousPaid=$sloData->sum('paidAmount');
            $pay->previousPaidAmount=$previousPaid;
        }


    return view('content.customer_management.manage_invoice.invoice_list',[
        'transaction'=>$transaction,
        'perpage'=>$perpage,
        'search_fill'=>$search_fill,

    ]);
  }
  
    public function SendNDAMessage(Request $request)
    {
      // Validate the incoming request data
      $validator = Validator::make($request->all(), [
        'proposal_id' => 'required', 
        'email'    => 'boolean',
        'sms'     => 'boolean',
        'whatsapp' => 'boolean'
      ]);
      // If validation fails, return a response with errors
      if ($validator->fails()) {
        return response([
          'status'    => 401,
          'message'   => 'Incorrect format input fields',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      }
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
      $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

      $branch_name = " ";
      if ($branchData->branch_type == 1) {
        $branch_name = $branchData->branch_name;
      } elseif ($branchData->branch_type == 2) {
        $branch_name = $branchData->franchise_name;
      }

      $proposal_id  = $request->proposal_id;
      $customer_id  = $request->customer_id;
      $old_customer_check  = $request->old_customer_check;

      $proposalData=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
      $customerData=DB::table('et_customer')->where('et_customer.sno',$customer_id)->first();
      // Extract the validated data
      $lead_id=$proposalData->lead_id ?? 0;
      $email     = $request->email;
      $sms      = $request->sms;
      $whatsapp = $request->whatsapp;
      $message  = $request->message;
      $user_id  = $request->user()->user_id;


      // return $request;
      // Find the lead based on lead_id
      $lead = LeadModel::where('sno', $lead_id)
        ->first();

      // If the lead is not found, return an error response
      if (!$lead) {
        return response([
          'status'    => 404,
          'message'   => 'Lead not found',
          'error_msg' => 'The lead with the given ID does not exist',
          'data'      => null,
        ], 200);
      }
      
      $customer=CustomerModel::where('lead_id', $lead_id)
        ->first();

      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($proposal_id, 'encrypt');

      $description =$request->description ?? 'Your New Proposal is Generated , We Send Link Below .';
      $Link ='https://erp.elysiumtechnologies.com/manage_nda/nda_message/'.$encrypted_values;
      
      $lead_email=$customer->cus_email_id ?? $lead->lead_email_id;
   
      $lead_mobile =$customer->cus_mobile ?? $lead->lead_mobile;
      $lead_name=$customer->cus_name ?? $lead->lead_name;
      $inter_call=$customer->country_code ?? $lead->inter_calls;
     
       if($old_customer_check == 1){
          //   For Old Customer
        DB::table('et_proposal')
                ->where('sno', $proposal_id)
                ->update([
                    'nda_temp_link' => $Link,
                    'nda_old_customer_check'=>$old_customer_check,
                    ]);
      }else{
             if(!$proposalData->nda_temp_link){
                 $channelId = 6;
                 $shortUrlData = $this->shortenUrl($Link,$channelId);
                 $shortUrl = $shortUrlData['shorturl'];
                 $urlId =$shortUrlData['id'];
                  if($shortUrl){
                        DB::table('et_proposal')
                        ->where('sno', $proposal_id)
                        ->update(['nda_temp_link' => $shortUrl]);
                        
                          DB::table('et_chotta_links')->insert([
                                  'branch_id' => $branch_id,
                                  'chotta_link_id' => $urlId,
                                  'chotta_short_link' => $shortUrl,
                                  'large_encrypt_link' => $Link,
                                  'link_type' => 'NDA Send',
                                  'proposal_id' => $proposal_id,
                                  'created_by' => $user_id,
                                  'updated_by' => $user_id,
                              ]);
                        
                  }
              }
            
              $proposalUrl=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
              
              $shortsendUrl = $proposalUrl->nda_temp_link ;
              
              $proposal_key = basename($shortsendUrl);
            
           
              $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
        
              $cre = StaffModel::where('sno', $proposalData->created_by)->orderBy('sno', 'desc')->first();
            //   Send email if email flag is set to true
              if ($email == 1) {
                    $emailTemplate_id =5; // proposal send Template Id
                    $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
        
                // Gender condition
                $genderPrefix = 'Mr/Ms'; // Default value
                if ($lead->lead_gender == 1) {
                  $genderPrefix = 'Mr';
                } elseif ($lead->lead_gender == 2) {
                  $genderPrefix = 'Ms';
                }
                
                
               
                
                $content = $emailTemplate->email_subject;
        
                $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
        
                $content = str_replace('#customer_name', $lead_name, $content);
                $content = str_replace('#proposal_id', $proposalData->proposal_id ?? 'PRO-00001/06/2025', $content);
                $content = str_replace('#link', $shortsendUrl, $content);
                $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                $content = str_replace('#CREname', $cre->nick_name ?? "Alex", $content);
                $content = str_replace('#customer_care_no',  $branch->cre_mobile ?? '9003400111', $content);
                $branchNo = $branch->mobile;
                $branchemail = $branch->mail;
                $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                $url= 'phdizone.com';
        
                $mailData = [
                      'url'         => $url,
                      'subject'     => $dynamicSubject,
                      'content'     => $content,
                      'branchNo'    => $branchNo,
                      'branchemail' => $branchemail, // Use the message content from the request
                      'fbLink'      => $fbLink,      // Use the message content from the request
                      'instaLink'   => $instaLink,   // Use the message content from the request
                      'salesMobile' => $branch_data->sales_mobile??'9003400111',
                  ];
        
                $to_address = $lead_email;
                $from_address = 'elysiumtechnology@elysium.community';
                $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
        
        
                Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
             }
             
              if ($whatsapp == 1) {
                  
                   
                        // $templateName  = "hello_world";
                        $templateName  = "proposal_phdizone";
        
                        $hasHeader  = false; // Example flag: set based on template
                        $hasBody    = false; // Example flag: set based on template
                        $hasFooter  = false; // Example flag: set based on template
                        $hasButton  = false;
                        $components = [];
                        $couponCode = " ";
                        date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                        $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                  // $currentHour = date('H'); // Get current hour in 24-hour format
                        if ($currentHour >= 5 && $currentHour < 12) {
                            $greeting = 'Good Morning';
                        } elseif ($currentHour >= 12 && $currentHour < 18) {
                            $greeting = 'Good Afternoon';
                        } else {
                            $greeting = 'Good Evening';
                        }
        
                        if ($templateName == 'proposal_phdizone') {
                            $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/OnBoard.jpg';
                            $couponCode  = 'NOOFFER';
                            $buttonIndex = 1;
                            $bodyText    = [
                                [
                                    'type'           => 'text',
                                    'text'           => $lead_name,
                                    'parameter_name' => 'customer_name',
                                ],
                                [
                                    'type'           => 'text',
                                    'text'           => $proposalData->proposal_id,
                                    'parameter_name' => 'proposal_id',
                                ],
                                [
                                    'type'           => 'text',
                                    'text'           => $proposal_key,
                                    'parameter_name' => 'proposal_key',
                                ],
                                [
                                    'type'           => 'text',
                                    'text'           => $branch->cre_mobile ?? '9003400111',
                                    'parameter_name' => 'customercare_number',
                                ],
                            ];
                            $hasHeader = true;
                            $hasBody   = true;
                            $hasButton = true;
                        }
        
                        // Add Header if required
                        if ($hasHeader) {
                            $components[] = [
                                'type'       => 'header',
                                'parameters' => [
                                    [
                                        'type'  => 'image',
                                        'image' => [
                                            'link' => $headerImage, // Dynamically set header image
                                        ],
                                    ],
                                ],
                            ];
                        }
        
                        // Add Body if required
                        if ($hasBody) {
                            $components[] = [
                                'type'       => 'body',
                                'parameters' => $bodyText,
                            ];
                        }
        
                        // Add Footer if required
                        if ($hasButton) {
                            $components[] = [
                                'type'       => 'button',
                                'sub_type'   => 'url',
                                'index'      => 0,
                                'parameters' => [
                                    [
                                        'type' => 'text',
                                        'text' => $proposal_key,
                                    ],
                                ],
                            ];
                        }
                        
                        
                        $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$entity_id)->orderBy('sno', 'desc')->first();
                        $dynamicParameters         = $templateParameters[$templateName] ?? [];
                        $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                        $accessToken               = $whatsappApi->access_tokken ?? '';
                        $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
        
                        $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
        
                        $countryCode  = $inter_call ? ($inter_call == 0 ? '+91' : '+' . $inter_call) : '+91';
                        $to           = $lead_mobile;
                        $languageCode = 'en';
            
                        if (strpos($to, $countryCode) !== 0) {
                            $to = $countryCode . $to;
                        }
        
                        $message = 'test~message';
                        if (empty($components)) {
                            $payload = [
                                'messaging_product' => 'whatsapp',
                                'to'                => $to,
                                'type'              => 'template',
                                'template'          => [
                                    'name'     => $templateName,
                                    'language' => [
                                        'code' => $languageCode,
                                    ],
                                ],
                            ];
                        } else {
                            $payload = [
                                'messaging_product' => 'whatsapp',
                                'to'                => $to,
                                'type'              => 'template',
                                'template'          => [
                                    'name'       => $templateName,
                                    'language'   => [
                                        'code' => $languageCode,
                                    ],
                                    'components' => $components,
                                ],
                            ];
                        }
        
                        $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                     if ($response['status'] == 200) {}
                     else{
                         return response([
                              'status' => 404,
                              'message' => 'Failed to send message',
                              'error_msg' => $response['error'],
                            ], 400);
                        }
                    
              }
            
             DB::table('et_proposal')
                        ->where('sno', $proposal_id)
                        ->update(['nda_send_status' => 1]);
      }
     $nda_check = DB::table('et_manage_nda')->where('proposal_id', $proposal_id)->first();
      if (!$nda_check) {
            $year = date('Y');
            $month = date('m');
            
            // Get the last NDA record
            $category_check = DB::table('et_manage_nda')->orderBy('sno', 'desc')->first();
            
            
            if (!$category_check) {
                $next_number = 1;
            } else {
                $last_nda_id = $category_check->nda_id;
            
                $parts = explode('/', $last_nda_id);
                $last_number = isset($parts[4]) ? (int) $parts[4] : 0;
                $next_number = $last_number + 1;
            }
            
            $nda_id = sprintf("GC/IZONE/%s/%s/%05d", $year, $month, $next_number);
            
             DB::table('et_manage_nda')->insert([
                                      'nda_id' =>$nda_id,
                                      'nda_link' =>$old_customer_check == 1 ? $Link :$shortsendUrl ,
                                      'nda_date' => date('Y-m-d'),
                                      'customer_id' => $customer_id,
                                      'proposal_id' => $proposal_id,
                                      'branch_id' => $branch_id,
                                      'status' => 0,
                                      'created_by' => $user_id,
                                      'updated_by' => $user_id,
                                  ]);
      }
    
      // If the operation was successful, return a success response
      return response([
        'status'    => 200,
        'message'   => "Message sent successfully",
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  public function NDASendView($id,Request $request){
      
      $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    
     DB::table('et_proposal')
                        ->where('sno', $id)
                        ->update(['nda_send_status' => 2]);
                        
    $edit = DB::table('et_proposal')->where('et_proposal.status', '!=', 2)
      ->select(
        'et_proposal.*',
        'et_customer.cus_name',
        'et_customer.cus_email_id',
        'et_branch.branch_name',
        'et_branch.door_no as branch_door',
        'et_branch.area_street',
        'et_branch.country_id',
        'et_branch.state_id',
        'et_branch.city_id',
        'et_branch.pincode',
        'branch_country.id',
        'customer_country.id',
        'branch_state.id',
        'customer_state.id',
        'branch_city.id',
        'customer_city.id',
        'et_customer.cus_gender',
        'et_customer.state',
        'et_customer.country',
        'et_customer.city',
        'branch_country.name as branch_country_name',
        'customer_country.name as customer_country_name',
        'branch_state.name as branch_state_name',
        'customer_state.name as customer_state_name',
        'branch_city.name as branch_city_name',
        'customer_city.name as customer_city_name',
        'et_customer.door_no',
        'et_customer.address',
        'et_staff.sno',
        'et_staff.nick_name',
        'et_staff.staff_name'
      )
      ->Join('et_customer_services', 'et_customer_services.proposal_id', '=', 'et_proposal.sno')
      ->Join('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
      ->Join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_proposal.branch_id')
      ->leftJoin('et_countries as branch_country', 'branch_country.id', '=', 'et_branch.country_id')
      ->leftJoin('et_countries as customer_country', 'customer_country.id', '=', 'et_customer.country')
      ->leftJoin('et_states', 'et_states.id', '=', 'et_branch.state_id')
      ->leftJoin('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
      ->leftJoin('et_states as branch_state', 'branch_state.id', '=', 'et_branch.state_id')
      ->leftJoin('et_states as customer_state', 'customer_state.id', '=', 'et_customer.state')
      ->leftJoin('et_cities as branch_city', 'branch_city.id', '=', 'et_branch.city_id')
      ->leftJoin('et_cities as customer_city', 'customer_city.id', '=', 'et_customer.city')
      ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
      ->where('et_proposal.sno', $decryptedValue)->first();
      
      $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $edit->branch_id)
            ->first();
      
      
       $ndaData = DB::table('et_manage_nda')->where('proposal_id', $decryptedValue)->first();
       $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();
       return view('content.customer_management.manage_nda.nda_add', [
           'edit'=>$edit,
           'nda'=>$ndaData,
           'terms'=>$terms,
           
           ]);
      
  }
   public function manage_invoice_print($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $slot_id_decrpt =$decryptedValue;
   
    
     $slotData = DB::table('et_proposal_pay_slot')
                    ->where('sno', $slot_id_decrpt)
                    ->where('status', 0)
                    ->first();
     
    $slotProp = DB::table('et_proposal_pay_slot')
                    ->where('proposal_sno', $slotData->proposal_sno)
                    ->where('status', 0)
                    ->get();
    $paidAmount=$slotProp->sum('paidAmount');
    $balance_amount =   $slotData->total_amount  > 0 ? $slotData->total_amount -$paidAmount : 0;
    $slotData->due_amount =$balance_amount;
    
     $prps_id =$slotData->proposal_sno;

      $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.nick_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol','et_payment.invoice_id','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id')
                 ->where('et_proposal.sno',$prps_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();

           $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $proposal->branch_id)
            ->first();

        

          $proposal->door_no =$branch_data->door_no ;
          $proposal->area_street = $branch_data->area_street ;
          $proposal->city_name =  $branch_data->city_name ;
          $proposal->state_name =  $branch_data->state_name ;
          $proposal->country_name =  $branch_data->country_name ;
          $proposal->pincode =  $branch_data->pincode ;
          $proposal->branch_mail =  $branch_data->mail ;
          $proposal->branch_mobile =  $branch_data->mobile ;
          $proposal->gst_no =  $branch_data->gst_no ?? "-" ;


           $lead_data = DB::table('et_lead')
            ->select(
                'et_lead.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
            ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
            ->where('et_lead.sno', $proposal->lead_id)
            ->first();

          $proposal->lead_name =$lead_data->lead_name ?? '';
          $proposal->lead_door_no =$lead_data->door_no ?? '';
          $proposal->lead_address = $lead_data->address ?? '';
          $proposal->lead_city_name =  $lead_data->city_name ?? '' ;
          $proposal->lead_state_name =  $lead_data->state_name ?? '' ;
          $proposal->lead_country_name =  $lead_data->country_name ?? '' ;
          $proposal->lead_pincode =  $lead_data->pincode ?? '';
          $proposal->lead_mail =  $lead_data->lead_email_id ?? '' ;
          $proposal->lead_mobile =  $lead_data->lead_mobile ??'' ;

            
      if($proposal->discount_id >0){
        $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$proposal->discount_id)->first();

        $proposal->discount_value=$discount->coupon_value ;
        $proposal->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
      }

      // return $proposal;
      $proposal->products=[];
      $packages='';
    
    if($proposal->product_package == 1){

       $proposalProduct = DB::table('et_proposal_product_cart')
                          ->select('et_proposal_product_cart.*','et_product.product_name','et_product_category.product_category_name')
                          ->where('et_proposal_product_cart.status',0)
                          ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
                          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
                          ->where('et_proposal_product_cart.proposal_id',$proposal->proposal_id)
                          ->get();
       
         $groupedProducts = [];
            $allSlotIds = [];
            foreach ($proposalProduct as $product) {
                $product_id = $product->product_id;
                $cart_id = $product->cart_id;
            
                // Shared data fetched once per product_id
                if (!isset($groupedProducts[$product_id])) {
                    $product_data = ProductModel::select('et_product.*')
                        ->where('et_product.sno', $product_id)->first();
            
                    $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
                    $tools_ids = is_array($tools_ids) ? $tools_ids : [];
            
                    $tools = DB::table('et_product_tools')
                        ->whereIn('sno', $tools_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('product_tools_name')
                        ->toArray();
            
                    $base_product = clone $product; // Copy to modify
                    $base_product->tools_name = $tools;
                    $base_product->product_name = $product->product_name;
                    $base_product->product_category_name = $product->product_category_name;
                    $base_product->cart_variants = [];
                    $base_product->cart_slots = [];
                    $base_product->total_amount_cart = 0;
                    $base_product->product_amount = 0;
            
                    $groupedProducts[$product_id] = $base_product;
                }
            
                // Compute variant data per cart
                $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
                $variable_amount = 0;
                $variant_names = [];
                $product_variant_name = '';
                $variable_name = '';
            
                foreach ($variant_variable_ids as $pair) {
                    $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
                    $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
            
                    if ($variant_id) {
                        $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
                        $product_variant_name = $get_variant->product_variant_name ?? '';
                    }
            
                    if ($variable_id) {
                        $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
                        if ($get_variables) {
                            $variable_name = $get_variables->variable_name;
                            $variable_amount += $get_variables->variable_amount;
                        }
                    }
            
                    if ($product_variant_name && $variable_name) {
                        $variant_names[] = "{$product_variant_name} - {$variable_name}";
                    } elseif ($product_variant_name) {
                        $variant_names[] = $product_variant_name;
                    }
                }
            
                $cart_total = $variable_amount + $product_data->base_price;
                $groupedProducts[$product_id]->total_amount_cart += $cart_total;
            
                // Add cart-specific variant names
                $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
                $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;

            
                // Fetch slots for this cart
                $slots = DB::table('et_proposal_pay_slot')
                    ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
                    ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                    ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->get();
                $slotCount=count($slots);
                
                foreach ($slots as $slot) {
                    $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
                    if (!in_array($cart_id, $slot_cart_ids)) {
                        continue;
                    }
            
                    $groupedProducts[$product_id]->product_amount += $slot->slot_amount;
            
                    $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
                    $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);
            
                    $deliverable_items = $deliverables_map[$cart_id] ?? [];
                    $slot_notes_items = $slot_notes_map[$cart_id] ?? [];
            
                    $deliverable_ids = [];
                    foreach ($deliverable_items as $d) {
                        if (($d['status'] ?? '0') == '0') {
                            $deliverable_ids[] = $d['value'];
                        }
                    }
            
                    $slot_notes_ids = [];
                    foreach ($slot_notes_items as $s) {
                        if (($s['status'] ?? '0') == '0') {
                            $slot_notes_ids[] = $s['value'];
                        }
                    }
            
                    $deliverables = DB::table('et_product_delivarables')
                        ->whereIn('sno', $deliverable_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('delivarable_name');
            
                    $slot_notes = DB::table('et_slot_notes')
                        ->whereIn('sno', $slot_notes_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('slot_notes_name');
            
                    // Assign deliverables and notes for this cart
                    $slot->deliverables = $deliverables;
                    $slot->slot_notes = $slot_notes;
            
                     if (!isset($groupedProducts[$product_id]->cart_slots)) {
                            $groupedProducts[$product_id]->cart_slots = [];
                        }
                        
                        // Find if the slot already exists in the array
                        $existingIndex = null;
                        foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
                            if ($existingSlot['sno'] === $slot->sno) {
                                $existingIndex = $index;
                                break;
                            }
                        }
                        
                        if ($existingIndex === null) {
                            // Add new slot entry
                            $groupedProducts[$product_id]->cart_slots[] = [
                                'sno' => $slot->sno,
                                'propo_pay_slot_id' => $slot->propo_pay_slot_id,
                                'branch_id' => $slot->branch_id,
                                'lead_id' => $slot->lead_id,
                                'proposal_id' => $slot->proposal_id,
                                'proposal_sno' => $slot->proposal_sno,
                                'product_cart_id' => $slot->product_cart_id,
                                'package_id' => $slot->package_id,
                                'slot_id' => $slot->slot_id,
                                'slot_amount' => $slot->slot_amount,
                                'payable_amount' => $slot->payable_amount,
                                'paidAmount' => $slot->paidAmount,
                                'gst_amount' => $slot->gst_amount,
                                'balance_amount' => $slot->balance_amount,
                                'total_amount' => $slot->total_amount,
                                'slot_description' => $slot->slot_description,
                                'created_by' => $slot->created_by,
                                'created_at' => $slot->created_at,
                                'updated_by' => $slot->updated_by,
                                'updated_at' => $slot->updated_at,
                                'status' => $slot->status,
                                'due_date' => $slot->due_date,
                                'link_status' => $slot->link_status,
                                'paid_status' => $slot->paid_status,
                                'invoice_id' => $slot->invoice_id,
                                'temp_send_link' => $slot->temp_send_link,
                                'old_customer_check' => $slot->old_customer_check,
                                'send_status' => $slot->send_status,
                                'receipt_temp_link' => $slot->receipt_temp_link,
                                'receipt_send_status' => $slot->receipt_send_status,
                                'payment_slot_name' => $slot->payment_slot_name,
                                'start_deliver_work' => $slot->start_deliver_work,
                                'deliverables' => [
                                    (string)$cart_id => $deliverables->toArray()
                                ],
                                'slot_notes' => [
                                    (string)$cart_id => $slot_notes->toArray()
                                ]
                            ];
                        } else {
                            // Slot already exists — just append deliverables and slot_notes for this cart
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
                        }


                }
                
            //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

            }
            
            // Set the grouped products
            $proposal->products = array_values($groupedProducts);
            $proposal->slotCount=$slotCount;
       
    }else{

      $package_data = DB::table('et_package')
                ->select('et_package.*')
                ->where('et_package.status',0)
                ->where('et_package.sno', $proposal->package_id)
                ->first();

          
        $package_product_name = DB::table('et_package_product')
          ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
          ->where('et_package_product.status', 0)
          ->where('et_package_product.package_id', $proposal->package_id)
          ->pluck('et_product.product_name');
         $package_data->product_name = $package_product_name ;

        $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                        ->where('et_proposal_pay_slot.package_id',$proposal->package_id)
                        ->where('et_proposal_pay_slot.status',0)
                        ->get();
            $productSlot_amount =0 ;
              foreach($slots as $slot){
              $productSlot_amount += $slot->slot_amount;
                  $deliverables_ids=$slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
                  $slot_notes_ids=$slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
                  $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('delivarable_name');
                  $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
                  $slot->deliverables =$deliverables;
                  $slot->slot_notes =$slot_notes;
              }
              $package_data->slots=$slots;
              
               $package_data->package_amount= $productSlot_amount ;

         $packages=$package_data;

    }

    // return  $packages;

     $proposalAddonProduct = DB::table('et_proposal_addon_product')
                          ->select('et_manage_addon.addon_name','et_proposal_addon_product.*','et_addon_variable.addon_variablename')
                          ->where('et_proposal_addon_product.status',0)
                          ->join('et_manage_addon','et_manage_addon.sno','=','et_proposal_addon_product.add_on_id')
                          ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_proposal_addon_product.addon_variant_id')
                          ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                          ->where('et_proposal_addon_product.proposal_id',$proposal->proposal_id)
                          ->get();

          $freeAddonProduct = DB::table('et_proposal_addon_product')
            ->select(
                'et_manage_addon.addon_name',
                'et_proposal_addon_product.*',
                'et_addon_variable.addon_variablename'
            )
            ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
            ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
            ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
            ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_addon_product.status', 0)
            ->where('et_proposal_addon_product.free_paid', 0)
            ->get();

            $paidAddonProduct = DB::table('et_proposal_addon_product')
                ->select(
                    'et_manage_addon.addon_name',
                    'et_proposal_addon_product.*',
                    'et_addon_variable.addon_variablename'
                )
                ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
                ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
                ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
                ->where('et_proposal_addon_product.status', 0)
                ->where('et_proposal_addon_product.free_paid', 1)
                ->get();
                  
                $proposal->freeAddonProducts = $freeAddonProduct;
                $proposal->paidAddonProducts = $paidAddonProduct;
     $proposal->productAddon =$proposalAddonProduct;
   
  
      $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();

    

    
    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();

    $proposal_terms =[];
    if($terms){
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature= $terms->signature;


    // return $proposal;

    return view('content.customer_management.manage_invoice.invoice_print',[
      'lead' =>$lead,
      'paySlots' =>$slotData,
      'proposal' =>$proposal,
      'branch_data' =>$branch_data,
      'proposal_note' =>$proposal_note,
      'proposal_terms' =>$proposal_terms,
      'signature' =>$signature,
      'packages' =>$packages,
    ]);
  }
  
  public function shortenUrl($longUrl,$channelId)
        {
            $response = Http::withToken('aFLQFlykraqpANsi')
                ->post('https://chotta.link/api/url/add', [
                    'url' => $longUrl
                ]);
        
            if ($response->successful() && isset($response['shorturl'])) {
                
                $shortUrl = $response['shorturl'];
                $urlId =$response['id'];
                
                $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

                $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);
        
                if ($assignResponse->successful()) {
                    return $response; // success
                }
            }
            
        
            return null;
        }
        
        private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }
  
   public function SendReceiptMessage(Request $request)
    {
      // Validate the incoming request data
      $validator = Validator::make($request->all(), [
        'proposal_id' => 'required', 
        'email'    => 'boolean',
        'sms'     => 'boolean',
        'whatsapp' => 'boolean'
      ]);
      // If validation fails, return a response with errors
      if ($validator->fails()) {
        return response([
          'status'    => 401,
          'message'   => 'Incorrect format input fields',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      }
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
      $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

      $branch_name = " ";
      if ($branchData->branch_type == 1) {
        $branch_name = $branchData->branch_name;
      } elseif ($branchData->branch_type == 2) {
        $branch_name = $branchData->franchise_name;
      }

      $proposal_id  = $request->proposal_id;
      $customer_id  = $request->customer_id;
      $old_customer_check  = $request->old_customer_check;

      $proposalData=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
      $customerData=DB::table('et_customer')->where('et_customer.sno',$customer_id)->first();
      // Extract the validated data
      $lead_id=$proposalData->lead_id ?? 0;
      $email     = $request->email;
      $sms      = $request->sms;
      $whatsapp = $request->whatsapp;
      $message  = $request->message;
      $user_id  = $request->user()->user_id;


      // return $request;
      // Find the lead based on lead_id
      $lead = LeadModel::where('sno', $lead_id)
        ->first();

      // If the lead is not found, return an error response
      if (!$lead) {
        return response([
          'status'    => 404,
          'message'   => 'Lead not found',
          'error_msg' => 'The lead with the given ID does not exist',
          'data'      => null,
        ], 200);
      }
      
      

      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($proposal_id, 'encrypt');

      $Link ='https://erp.elysiumtechnologies.com/manage_invoice/invoice_print/'.$encrypted_values;
      
     
        // Receipt Communication 
                 $encrypted_values_receipt = $helper->encrypt_decrypt($slots->sno, 'encrypt');
                  $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                  $slot=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
                   
                  $Link_receipt ='https://erp.elysiumtechnologies.com/manage_invoice/invoice_print/'.$encrypted_values_receipt;
                         if(!$slots->receipt_temp_link){
                        $channelId_receipt = 7;
                         $shortUrlData_receipt = $this->shortenUrl($ReceiptLink,$channelId_receipt);
                         $shortUrl_receipt = $shortUrlData_receipt['shorturl'];
                         $urlId_receipt =$shortUrlData_receipt['id'];
                         if($shortUrl_receipt){
                             DB::table('et_proposal_pay_slot')
                                ->where('sno', $slot->sno)
                                ->update(['receipt_temp_link' => $shortUrl_receipt]);
                                
                                  DB::table('et_chotta_links')->insert([
                                      'branch_id' => $proposal->branch_id,
                                      'chotta_link_id' => $urlId_receipt,
                                      'chotta_short_link' => $shortUrl_receipt,
                                      'large_encrypt_link' => $Link_receipt,
                                      'link_type' => 'Receipt Send',
                                      'slot_id' =>$slot->sno,
                                      'created_by' => $proposal->created_by,
                                      'updated_by' => $proposal->created_by,
                                  ]);
                         }
                    }
                    
                          $slotUrl_receipt=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
                          $shortsendUrl_receipt = $slotUrl_receipt->receipt_temp_link ;
                          $slot_url_key_receipt = basename($shortsendUrl_receipt);
                          
                         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                         $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                         
                         $paidAmount=$paymentData->paid_amount;
                         
                          $slotAmount = $proposalData->currency_symbol . number_format($paidAmount, 2, '.', ',');
                        
                      if ($lead->lead_email_id) {
                            $emailTemplate_id =7; // proposal send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }
                        
                        
                       
                        
                        $content = $emailTemplate->email_subject;
                
                        $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                
                        $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead->lead_name, $content);
                        $content = str_replace('#reciept_number', $paymentData->payment_id ?? '', $content);
                        $content = str_replace('#payment_date', date('d-M-Y'), $content);
                        $content = str_replace('#link', $shortsendUrl_receipt, $content);
                        $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                        $content = str_replace('#payment', $slotAmount ?? '', $content);
                        $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                        $content = str_replace('#cre_number',  $branch->cre_mobile ?? '9003400111', $content);
                        $branchNo = $branch->mobile;
                        $branchemail = $branch->mail;
                        $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $url= 'phdizone.com';
                
                        $mailData = [
                              'url'         => $url,
                              'subject'     => $dynamicSubject,
                              'content'     => $content,
                              'branchNo'    => $branchNo,
                              'branchemail' => $branchemail, // Use the message content from the request
                              'fbLink'      => $fbLink,      // Use the message content from the request
                              'instaLink'   => $instaLink,   // Use the message content from the request
                              'salesMobile' => $branch_data->cre_mobile ?? '9003400111',
                          ];
                
                        $to_address = $lead->lead_email_id;
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                
                        Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                     }
                     
                      if ($lead->lead_mobile) {
                          
                           
                                // $templateName  = "hello_world";
                                $templateName  = "payment_recept_phdizone";
                
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
                
                                if ($templateName == 'payment_recept_phdizone') {
                                    $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $lead->lead_name ?? '',
                                            'parameter_name' => 'customer_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $paymentData->payment_id ?? '',
                                            'parameter_name' => 'recept_number',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => date('d-M-Y'),
                                            'parameter_name' => 'payment_date',
                                        ],
                                         [
                                            'type'           => 'text',
                                            'text'           => $slotAmount ?? '',
                                            'parameter_name' => 'payment',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposal->service_title ?? '',
                                            'parameter_name' => 'service_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slot_url_key_receipt,
                                            'parameter_name' => 'link_key',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $branch->cre_mobile ?? '9003400111',
                                            'parameter_name' => 'cre_number',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                    $hasButton = true;
                                }
                
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
                
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
                
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => $slot_url_key_receipt,
                                            ],
                                        ],
                                    ];
                                }
                                
                                
                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead->lead_mobile;
                                $languageCode = 'en';
                    
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
                
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
                
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                            
                      }
                    
                     DB::table('et_proposal_pay_slot')
                        ->where('sno', $slots->sno)
                        ->update(['receipt_send_status' => 1]);
    
      // If the operation was successful, return a success response
      return response([
        'status'    => 200,
        'message'   => "Message sent successfully",
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  
  public function manage_invoice_add()
  {
    return view('content.customer_management.manage_invoice.invoice_add_direct');
  }
  public function quote_to_invoice()
  {
    return view('content.customer_management.manage_invoice.invoice_add_quote');
  }
  public function balance_amount_invoice()
  {
    return view('content.customer_management.manage_invoice.invoice_add_balance');
  }
  public function manage_invoice_payment_add()
  {
    return view('content.customer_management.manage_invoice.invoice_add_payment');
  }
  public function manage_invoice_edit()
  {
    return view('content.customer_management.manage_invoice.invoice_edit');
  }
  public function manage_invoice_view()
  {
    return view('content.customer_management.manage_invoice.invoice_view');
  }
 
}
