<?php

namespace App\Http\Controllers\customer_management\customer_drop_refund;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\CustomerModel;
use App\Models\DropRefundModel;
use App\Models\GeneralSettingsModel;
use App\Models\ManageCoursesModel;
use App\Models\RefundChecklistModel;
use App\Models\TrainingModel;
use App\Models\User;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;


class ManageCustomerDrop extends Controller
{


  public function Index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $search_fill = $request->input('search_fill');
    $offset = ($page - 1) * $perpage;
    $helper =  new \App\Helpers\Helpers();
    $customers = DropRefundModel::select(
      'et_drop_refund.*',
      'et_customer.cus_name',
      'et_customer.cus_pic',
      'et_customer.customer_id as cus_customer_id',
      'et_customer.sno AS cus_sno',
      'et_customer.cus_gender',
      'et_customer.cus_dob',
      'et_customer.cus_mobile',
      'et_customer.cus_alternate_mobile',
      'et_customer.cus_email_id',
      // 'et_staff.staff_name',
      'created_staff.staff_name AS created_staff_name',
      'bh_staff.staff_name AS bh_staff_name',
      'et_lead.registered_date',
      'lead_staff.staff_name AS sales_satff'

    )
      ->leftJoin('et_customer', 'et_drop_refund.customer_id', '=', 'et_customer.sno')
      ->leftJoin('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
      ->leftJoin('et_staff AS lead_staff', 'et_lead.created_by', '=', 'lead_staff.sno')
      ->leftJoin('et_staff AS created_staff', 'et_drop_refund.created_by', '=', 'created_staff.sno')
      ->leftJoin('et_staff AS bh_staff', 'et_drop_refund.bh_id', '=', 'bh_staff.sno')
      ->leftJoin('et_branch', 'et_customer.branch_id', '=', 'et_branch.sno')
      ->where('et_drop_refund.type', 0)
      ->where('et_drop_refund.status', 0)
      // ->where('et_drop_refund.branch_id', $branch_id)
      ->orderBy('et_drop_refund.sno', 'desc');

    if ($search_fill) {
      $customers->where(function ($customer) use ($search_fill) {
        $customer->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
      });
    }



    $customers = $customers->paginate($perpage);


    foreach ($customers as $cus) {
      // Get all the results from the helper function
      $customer_data = $helper->customer_total_paid_bal_percentage($cus->customer_id);

      // Accessing all the required values and rounding them
      $cus->paid_amount = round($customer_data['paid_amount'] ?? 0, 2);         // Rounded to 2 decimal places
      $cus->payable_amount = round($customer_data['payable_amount'] ?? 0, 2);   // Rounded to 2 decimal places
      $cus->balance_amount = round($customer_data['balance_amount'] ?? 0, 2);   // Rounded to 2 decimal places
      $cus->balance_percentage = round($customer_data['balance_percentage'] ?? 0, 2); // Rounded to 2 decimal places
      $cus->paid_percentage = round($customer_data['paid_percentage'] ?? 0, 2); // Rounded to 2 decimal places


      $cus_services = $cus->service_ids ? json_decode($cus->service_ids, true) : [];



      $proposal = DB::table('et_customer_services')
        ->select(
          'et_customer_services.*',
          'et_product.product_name',
          'et_proposal.proposal_id AS proposal_ids',
        )
        ->where('et_customer_services.customer_id', $cus->customer_id)
        ->when(!empty($cus_services), function ($query) use ($cus_services) {
          $query->whereIn('et_customer_services.sno', $cus_services);
        })
        ->leftJoin('et_proposal', 'et_customer_services.proposal_id', 'et_proposal.sno')
        ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
        ->get();

      $variant_name = null;
      $variable_name = null;
      foreach ($proposal as $pro) {

        $variant_variable_data = json_decode($pro->variant_variable_ids ?? '[]', true);
        if (!empty($variant_variable_data) && is_array($variant_variable_data)) {
          foreach ($variant_variable_data as $cart_item) {
            $variant_name = $helper->get_variant_data_by_id($cart_item['variant_id'])->product_variant_name ?? 'N/A';
            $variable_name = $helper->get_variable_data_by_id($cart_item['variable_id'])->variable_name ?? 'N/A';
            break;
          }
        }

        $pro->variant_name = $variant_name;
        $pro->variable_name = $variable_name;
      }

      $cus->proposal_details = $proposal;
    }



    // return $customers;
    return view('content.customer_management.customer_drop_refund.customer_drop_list', [
      'customers' => $customers,
      'perpage' => $perpage,
      'search_fill' => $search_fill,

    ])->with('filter_on', false);
  }

  public function customer_drop_status_change(Request $request)
  {
    // Fetch request data
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    // Fetch old training details
    $drop_details = DropRefundModel::where('sno', $request->sts_change_id)->first();

    if ($drop_details) {
      // Update the training details
      $drop_details->update([
        'bh_status'        => $request->sts_change_type,
        'bh_reject_reason' => $request->bhreject_reason,
        'bh_status_date'   => now(),
        'bh_id'            => $user_id
      ]);

      if ($request->sts_change_type == 2) {
        $training_details = TrainingModel::where('sno', $drop_details->training_id)->first();
        $training_details->update([
          'status'           => 0,
          'drop_check'       => 0,
          'refund_amount'    => 0,
          'refund_date_drp'  => null,
          'drop_reason'      => null,
          'updated_by'       => $user_id
        ]);
        // Flash success message based on action type
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Customer Drop Rejected Successfully!'
        ]);
      } else {
        // Flash success message based on action type
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Customer Drop Accepted Successfully!'
        ]);
      }
    } else {
      // Flash error message if drop details not found
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Drop Customer!'
      ]);
    }

    return redirect('/manage_customer_drop');
  }

  public function customer_drop(Request $request)
  {
    // return $request;
    // Fetch request data
    $cus_sno        = $request->customer_id;
    $checklist      = $request->checklist;
    $refund_chk_drp = $request->refund_chk_drp ?? 0;
    $drp_reason     = $request->drop_refund_reason;
    $course_sno     = $request->course_id_drop;
    $traning_sno    = $request->trans_id_drop;
    // Fetch user and branch details
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;

    // Handle refund-related logic
    $refund_chk      = $request->refund_chk ?? 0;
    $refund_amount   = $request->refund_amount ?? 0;
    $max_refund_date = $request->max_refund_date ? date('Y-m-d', strtotime($request->max_refund_date)) : null;
    $type = $refund_chk ? 1 : 0;  // 1 for refund, 0 for drop

    // Fetch old training details
    $training_details = TrainingModel::where('customer_id', $cus_sno)->where('sno', $traning_sno)->first();
    // return $training_details;

    if ($training_details) {
      // Insert new drop or refund entry
      $insert = DropRefundModel::create([
        'training_id'     => $traning_sno,
        'type'           => $type,
        'branch_id'      => $branch_id,
        'customer_id'    => $cus_sno,
        'course_id'      => $course_sno,
        'bh_status'      => 0,
        'ac_status'      => 0,
        'paid_amount' => $request->paid_amount,
        'min_deducted_amount' => $request->min_deducted_amount,
        'costing_amount' => $request->costing_amount,
        'costing_hours' => $request->costing_hours,
        'posible_eligible_amount' => $request->posible_eligible_amount,
        'refund_amount'  => $refund_amount,
        'max_refund_date' => $max_refund_date,
        'drop_refund_reason' => $drp_reason,
        'check_list'     => $checklist,
        'created_by'     => $user_id,
        'updated_by'     => $user_id,
        'status'         => 0
      ]);

      if ($insert) {
        // Update the training details
        $training_details->update([
          'status'           => 2,
          'drop_check'       => $refund_chk_drp,
          'refund_amount'    => $refund_amount,
          'refund_date_drp'  => $max_refund_date,
          'drop_reason'      => $drp_reason,
          'updated_by'       => $user_id
        ]);

        // Flash success message based on action type
        $message = $refund_chk ? 'Customer Refund Request Successfully!' : 'Customer Drop Successfully!';
        session()->flash('toastr', ['type' => 'success', 'message' => $message]);
        // return $insert;
        return $refund_chk ? redirect('/manage_customer_refund') : redirect('/manage_customer_drop');
      }
    } else {
      // Flash error message if training details not found
      session()->flash('toastr', ['type' => 'error', 'message' => 'Could not update the Drop Customer!']);
      return redirect('/manage_customer');
    }
  }


  // vasanth customer drop
  public function drop_customer_page($id, Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Fetch customer details
    $customer_details = CustomerModel::where('sno', $decryptedValue)->first();
    $genaral_settings = GeneralSettingsModel::where('sno', 1)->first();
    $check_list       = RefundChecklistModel::where('status', 0)->get();

    if (!$customer_details) {
      return redirect()->back()->with('error', 'Customer not found.');
    }

    $services = DB::table('et_customer_services')
      ->select('et_customer_services.*', 'et_product.product_name', 'et_product_category.product_category_name')
      ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->where('et_customer_services.customer_id', $decryptedValue)->get();

    foreach ($services as $cs) {
      $variant_variable_data = json_decode($cs->variant_variable_ids ?? '[]', true);

      $variant_name = '-';
      $variable_name = '-';

      // Loop through the variant_variable_data if it contains multiple variants/variables
      foreach ($variant_variable_data as $pair) {
        // Fetch variant and variable data
        $variant  = DB::table('et_manage_product_variant')->where('sno', $pair['variant_id'])->first();
        $variable = DB::table('et_manage_product_variable')->where('sno', $pair['variable_id'])->first();

        // If a variant or variable is found, assign them
        if ($variant) {
          $variant_name = $variant->product_variant_name ?? '';
        }

        if ($variable) {
          $variable_name = $variable->variable_name ?? '';
        }
      }
      $cs->variant_name = $variant_name;
      $cs->variable_name = $variable_name;
    }


    $customer_data = $helper->customer_total_paid_bal_percentage($decryptedValue);

    // Accessing all the required values and rounding them
    $customer_details->paid_amount = round($customer_data['paid_amount'] ?? 0, 2);         // Rounded to 2 decimal places
    // $customer_details->paid_amount = 5000;        // Rounded to 2 decimal places
    $customer_details->payable_amount = round($customer_data['payable_amount'] ?? 0, 2);   // Rounded to 2 decimal places
    $customer_details->balance_amount = round($customer_data['balance_amount'] ?? 0, 2);   // Rounded to 2 decimal places
    $customer_details->balance_percentage = round($customer_data['balance_percentage'] ?? 0, 2); // Rounded to 2 decimal places
    $customer_details->paid_percentage = round($customer_data['paid_percentage'] ?? 0, 2); // Rounded to 2 decimal places

    // return $services;
    return view('content.customer_management.customer_drop_refund.customer_drop', [
      'customer_details' => $customer_details,
      'genaral_settings' => $genaral_settings,
      'check_list' => $check_list,
      'services' => $services
    ]);
  }

  public function submitDropRequest(Request $request)
  {

    // return $request;
    // return json_encode($request->services_checkbox, true);
    DB::beginTransaction();

    try {
      // Validate the request
      $validator = Validator::make($request->all(), [
        'customer_id' => 'required|integer'
      ]);

      if ($validator->fails()) {
        return response()->json([
          'success' => false,
          'message' => 'Validation failed',
          'errors' => $validator->errors()
        ], 422);
      }

      // Get authenticated user
      $user = auth()->user();

      // Prepare data for insertion matching your table structure
      $dropRefundData = [
        'branch_id' => $request->branch_id ?? $user->branch_id ?? 1,
        'type' => $request->type,
        'customer_id' => $request->customer_id,
        'bh_id' => null,
        'bh_status' => 0,
        'service_ids' => json_encode($request->services_checkbox, true),
        'bh_status_date' => null,
        'bh_reject_reason' => null,
        'acc_id' => null,
        'ac_status' => 0,
        'ac_status_date' => null,
        'ac_reject_reason' => null,
        'refund_amount' => $request->refund_amount ?? 0,
        'max_refund_date' => $request->max_refund_date ?? ($request->type == 1 ? now()->addDays(30)->format('Y-m-d') : null),
        'paid_amount' => $request->paid_amount ?? 0,
        'min_deducted_amount' => $request->min_deducted_amount ?? 0,
        'posible_eligible_amount' => $request->posible_eligible_amount ?? 0,
        'check_list' => $request->check_list,
        'drop_refund_reason' => $request->drop_refund_reason,
        'refunded_date' => null,
        'refunded_payment_mode_id' => 0,
        'refunded_reason' => null,
        'created_by' => $user->user_id,
        'updated_by' => $user->user_id,
        'status' => 0,
      ];


      $dropRefund = DropRefundModel::where('customer_id', $request->customer_id)->first();
      if ($dropRefund) {
        $dropRefund->type = $request->type;
        $dropRefund->refund_amount = $request->refund_amount ?? 0;
        $dropRefund->max_refund_date = $request->max_refund_date ?? ($request->type == 1 ? now()->addDays(30)->format('Y-m-d') : null);
        $dropRefund->paid_amount = $request->paid_amount ?? 0;
        $dropRefund->min_deducted_amount = $request->min_deducted_amount ?? 0;
        $dropRefund->posible_eligible_amount = $request->posible_eligible_amount ?? 0;
        $dropRefund->check_list = $request->check_list;
        $dropRefund->drop_refund_reason = $request->drop_refund_reason;
        $dropRefund->updated_by = $user->user_id;
        $dropRefund->service_ids = json_encode($request->services_checkbox, true);
        $dropRefund->update();
      } else {
        // Insert into database
        $dropRefund = DropRefundModel::create($dropRefundData);
      }

      if ($dropRefund) {
        $updateCustomer = CustomerModel::find($request->customer_id);

        if ($updateCustomer) {
          $status = ($request->type == 1) ? 7 : 6; // Set status based on type
          // Only update if status is different
          if ($updateCustomer->status !== $status) {
            $updateCustomer->status = $status;
            $updateCustomer->drop_refund_id = $dropRefund->sno;
            $updateCustomer->save();
          }
        } else {
          // Handle the case when the customer is not found
          // return response()->json(['error' => 'Customer not found'], 404);
        }
      }


      DB::commit();

      return response()->json([
        'success' => true,
        'message' => $request->type == 1
          ? 'Drop with refund request submitted successfully!'
          : 'Drop request submitted successfully!',
        'data' => [
          'drop_refund_id' => $dropRefund->sno,
          'reference_number' => 'DR-' . str_pad($dropRefund->sno, 6, '0', STR_PAD_LEFT),
          'type' => $dropRefund->type == 1 ? 'Refund' : 'Drop Only',
          'submitted_at' => $dropRefund->created_at->toDateTimeString()
        ]
      ]);
    } catch (\Exception $e) {
      DB::rollBack();
      return response()->json([
        'success' => false,
        'message' => 'Failed to submit drop/refund request: ' . $e->getMessage()
      ], 500);
    }
  }
}
