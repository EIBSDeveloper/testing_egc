<?php

namespace App\Http\Controllers\customer_management\customer_drop_refund;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CourseTypeModel;
use App\Models\CustomerModel;
use App\Models\DropRefundModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModeModel;
use App\Models\SubLedgerModel;
use App\Models\TrainingModel;
use App\Models\TransactionModel;
use App\Models\User;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ManageCustomerRefund extends Controller
{

  public function Index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $search_fill = $request->input('search_fill');
    $offset = ($page - 1) * $perpage;
    $helper =  new \App\Helpers\Helpers();
    $customers = DropRefundModel::select(
      'et_drop_refund.*',
      'et_customer.cus_name',
      'et_customer.cus_pic',
      'et_customer.customer_id as cus_customer_id',
      'et_customer.sno AS cus_sno',
      'et_customer.cus_gender',
      'et_customer.cus_dob',
      'et_customer.cus_mobile',
      'et_customer.cus_alternate_mobile',
      'et_customer.cus_email_id',
      // 'et_staff.staff_name',
      'created_staff.staff_name AS created_staff_name',
      'bh_staff.staff_name AS bh_staff_name',
      'ac_staff.staff_name AS ac_staff_name',
      'et_lead.registered_date',
      'lead_staff.staff_name AS sales_satff'

    )
      ->leftJoin('et_customer', 'et_drop_refund.customer_id', '=', 'et_customer.sno')
      ->leftJoin('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
      ->leftJoin('et_staff AS lead_staff', 'et_lead.created_by', '=', 'lead_staff.sno')
      ->leftJoin('et_staff AS created_staff', 'et_drop_refund.created_by', '=', 'created_staff.sno')
      ->leftJoin('et_staff AS bh_staff', 'et_drop_refund.bh_id', '=', 'bh_staff.sno')
      ->leftJoin('et_staff AS ac_staff', 'et_drop_refund.acc_id', '=', 'ac_staff.sno')
      ->leftJoin('et_branch', 'et_customer.branch_id', '=', 'et_branch.sno')
      ->where('et_drop_refund.type', 1)
      // ->where('lead_staff.sno', '>',0)
      // ->where('created_staff.sno', '>',0)
      // ->where('bh_staff.sno', '>', 0)
      // ->where('ac_staff.sno', '>', 0)
      ->where('et_drop_refund.status', 0)
      ->whereNotNull('et_drop_refund.service_ids')
      ->orderBy('et_drop_refund.sno', 'desc');
    if ($search_fill) {
      $customers->where(function ($customer) use ($search_fill) {
        $customer->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
      });
    }

    $customers = $customers->paginate($perpage);



    foreach ($customers as $cus) {
      // Get all the results from the helper function
      $customer_data = $helper->customer_total_paid_bal_percentage($cus->customer_id);

      // Accessing all the required values and rounding them
      $cus->paid_amount = round($customer_data['paid_amount'] ?? 0, 2);         // Rounded to 2 decimal places
      $cus->payable_amount = round($customer_data['payable_amount'] ?? 0, 2);   // Rounded to 2 decimal places
      $cus->balance_amount = round($customer_data['balance_amount'] ?? 0, 2);   // Rounded to 2 decimal places
      $cus->balance_percentage = round($customer_data['balance_percentage'] ?? 0, 2); // Rounded to 2 decimal places
      $cus->paid_percentage = round($customer_data['paid_percentage'] ?? 0, 2); // Rounded to 2 decimal places
      // Decode service IDs safely
      $cus_services = $cus->service_ids ? json_decode($cus->service_ids, true) : [];

      if (empty($cus_services)) {
        $cus->proposal_details = [];
        continue;
      }

      $proposal = DB::table('et_customer_services')
        ->select(
          'et_customer_services.*',
          'et_product.product_name',
          'et_proposal.proposal_id AS proposal_ids',
        )
        ->where('et_customer_services.customer_id', $cus->customer_id)
        ->whereIn('et_customer_services.sno', $cus_services)
        ->leftJoin('et_proposal', 'et_customer_services.proposal_id', 'et_proposal.sno')
        ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
        ->get();

      $variant_name = null;
      $variable_name = null;
      foreach ($proposal as $pro) {

        $variant_variable_data = json_decode($pro->variant_variable_ids ?? '[]', true);
        if (!empty($variant_variable_data) && is_array($variant_variable_data)) {
          foreach ($variant_variable_data as $cart_item) {
            $variant_name = $helper->get_variant_data_by_id($cart_item['variant_id'])->product_variant_name ?? 'N/A';
            $variable_name = $helper->get_variable_data_by_id($cart_item['variable_id'])->variable_name ?? 'N/A';
            break;
          }
        }

        $pro->variant_name = $variant_name;
        $pro->variable_name = $variable_name;
      }

      $cus->proposal_details = $proposal;
    }

    $pay_mode_list = PaymentModeModel::where('status', 0)->orderBy('paymentmode_name', 'ASC')->get();

    // return $pay_mode_list;
    return view('content.customer_management.customer_drop_refund.customer_refund_list', [
      'customers' => $customers,
      'perpage' => $perpage,
      'search_fill' => $search_fill,
      'pay_mode_list' => $pay_mode_list
    ])->with('filter_on', false);
  }


  public function customer_refund_bh_status_change(Request $request)
  {
    // Fetch request data
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    // Fetch old training details
    $drop_details = DropRefundModel::where('sno', $request->sts_change_id)->first();

    if ($drop_details) {
      // Update the training details
      $drop_details->update([
        'bh_status'        => $request->sts_change_type,
        'bh_reject_reason' => $request->bhreject_reason,
        'bh_status_date'   => now(),
        'bh_id'            => $user_id
      ]);

      if ($request->sts_change_type == 2) {
        // $training_details = TrainingModel::where('sno', $drop_details->training_id)->first();
        // $training_details->update([
        //   'status'           => 0,
        //   'drop_check'       => 0,
        //   'refund_amount'    => 0,
        //   'refund_date_drp'  => null,
        //   'drop_reason'      => null,
        //   'updated_by'       => $user_id
        // ]);
        // Flash success message based on action type
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Authority Refund Rejected Successfully!'
        ]);
      } else {
        // Flash success message based on action type
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Authority Refund Accepted Successfully!'
        ]);
      }
    } else {
      // Flash error message if drop details not found
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Authority Refund!'
      ]);
    }

    return redirect('/manage_customer_refund');
  }
  public function customer_refund_ac_status_change(Request $request)
  {
    // Fetch request data
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    // Fetch old training details
    $drop_details = DropRefundModel::where('sno', $request->sts_change_id)->first();
    if ($drop_details) {
      // Update the training details
      $drop_details->update([
        'ac_status'        => $request->sts_change_type,
        // 'ac_reject_reason' => $request->bhreject_reason,
        'ac_status_date'   => now(),
        'acc_id'           => $user_id
      ]);

      // Flash success message based on action type
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'A/C Refund Accepted Successfully!'
      ]);
    } else {
      // Flash error message if drop details not found
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the A/C Refund!'
      ]);
    }

    return redirect('/manage_customer_refund');
  }
  public function customer_refunded_status_change(Request $request)
  {
    // Validate the required request inputs
    $request->validate([
      'sts_change_id' => 'required|integer',
      'refund_description' => 'required|string|max:255',
      'refunded_date' => 'required|date',
      'pay_mode_list' => 'required|integer',
    ]);

    // Fetch current user's branch and user ID
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    // Fetch related models and handle missing data cases
    $drop_details = DropRefundModel::find($request->sts_change_id);
    $training_details = TrainingModel::find($drop_details->training_id);
    // return $training_details;
    $customer_details = CustomerModel::find($drop_details->customer_id);
    $subledger = SubLedgerModel::where('payment_sno', $training_details->sno)->first();
    if (!$subledger) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Subledger details not found!',
      ]);
      return redirect('/manage_customer_refund');
    }
    $branch = BranchModel::find($branch_id);
    $branch_code = $branch->city_short_code;
    // Generate a new transaction ID
    $last_transaction = TransactionModel::orderBy('sno', 'desc')->first();
    $next_number = $last_transaction
      ? sprintf("%04d", (int)preg_replace('/[^0-9]/', '', $last_transaction->sno) + 1)
      : "0001";
    $transaction_id = date('Y') . "/{$branch_code}/DR{$next_number}";
    // Start a database transaction to ensure atomicity
    $insert =
      TransactionModel::create([
        'ledger_id' => 2,
        'subledger_id' => $subledger->sno,
        'transaction_id' => $transaction_id,
        'transaction_name' => 'Refund',
        'trans_source_id' => $customer_details->customer_id,
        'credit' => 0,
        'debit' => $drop_details->refund_amount,
        'total_amount' => $drop_details->refund_amount,
        'tax' => 0,
        'transaction_type' => 'Debit',
        'trans_desc' => $request->refund_description,
        'status' => 1,
        'branch_id' => $branch_id,
        'created_by' => $user_id,
        'updated_by' => $user_id,
        'daily_acc_chk' => 0,
      ]);

    if ($insert) {
      // Update the drop refund details
      $drop_details->update([
        'ac_status' => 2,
        'ac_status_date' => now(),
        'acc_id' => $user_id,
        'refunded_reason' => $request->refund_description,
        'refunded_date' => date('Y-m-d', strtotime($request->refunded_date)),
        'refunded_payment_mode_id' => $request->pay_mode_list,
      ]);

      // Flash success message and redirect
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Amount Refund Successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Amount Refund !',
      ]);
    }

    return redirect('/manage_customer_refund');
  }
}
