<?php

namespace App\Http\Controllers\journal_management;

use App\Http\Controllers\Controller;
use App\Models\JournalBookletModel;
use App\Models\JournalHistoryModel;
use App\Models\ManageJournalModel;
use App\Models\FollowupReasonModel;
use App\Models\PassLockerModel;
use App\Models\StaffModel;
use App\Models\TaskRequestModel;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;

class ManageJournal extends Controller
{
    // public function index(Request $request)
    // {
    //     $helper = new \App\Helpers\Helpers();
    //     $page = $request->input('page', 1);
    //     $perpage = (int) $request->input('sorting_filter', 25);
    //     $offset = ($page - 1) * $perpage;
    //     $branch_id = $request->user()->branch_id;
    //     $search_fill = $request->search_fill ?? '';
    //     $user_id = $request->user()->user_id;
    //     $user_role = $request->user()->role_id;
    //     $statusFilter = $request->input('status');

    //     // Build main query for customer services
    //     $query = DB::table('et_customer_services')
    //         ->where('et_customer_services.journal_check', 1)
    //         ->where('et_customer_services.branch_id', $branch_id)
    //         ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
    //         ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
    //         ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
    //         ->leftJoin('et_product', function ($join) {
    //             $join->on('et_product.sno', '=', 'et_customer_services.product_id')
    //                 ->where('et_customer_services.product_package', '=', 1);
    //         })
    //         ->leftJoin('et_package', function ($join) {
    //             $join->on('et_package.sno', '=', 'et_customer_services.package_id')
    //                 ->where('et_customer_services.product_package', '=', 2);
    //         })
    //         ->select(
    //             'et_customer.cus_name',
    //             'et_customer.customer_id',
    //             'et_customer_services.sno',
    //             'et_customer_services.created_at',
    //             'et_customer_services.journal_index',
    //             'et_customer_services.proposal_id',
    //             'et_customer.sno as journal_customer_id',
    //             'et_customer_services.jc_id',
    //             'et_customer_services.jc_staff',
    //             'journal_staff.staff_name as journal_staff_name',
    //             'journal_coordinator.staff_name as jouranal_coordinator_name',
    //             'journal_staff.staff_image as journal_staff_image',
    //             'journal_coordinator.staff_image as jouranal_coordinator_image',
    //             DB::raw('CASE
    //             WHEN et_customer_services.product_package = 1 THEN et_product.product_name
    //             WHEN et_customer_services.product_package = 2 THEN et_package.package_name
    //             ELSE NULL
    //         END as service_name')
    //         );

    //     // Apply status filter if provided - only show services that have journal entries with this status
    //     if ($statusFilter !== null) {
    //         $query->whereExists(function ($query) use ($branch_id, $statusFilter) {
    //             $query->select(DB::raw(1))
    //                 ->from('et_manage_journal')
    //                 ->whereRaw('et_manage_journal.service_id = et_customer_services.sno')
    //                 ->whereRaw('et_manage_journal.customer_id = et_customer.sno')
    //                 ->where('et_manage_journal.branch_id', $branch_id)
    //                 ->where('et_manage_journal.status', $statusFilter);
    //         });
    //     }

    //     // Apply user permissions
    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         // User can only view their own data
    //         if ($user_role == 34) {
    //             $query = $query->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $query = $query->where('et_customer_services.jc_id', $user_id);
    //         }
    //     } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'global_cus')) {
    //         // User can view all data - no additional filter needed
    //     } else {
    //         // No permission
    //         abort(403, 'Unauthorized');
    //     }

    //     // Apply search filter
    //     if ($search_fill != '') {
    //         $query->where(function ($list) use ($search_fill) {
    //             $list->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_package.package_name', 'LIKE', "%{$search_fill}%");
    //         });
    //     }

    //     // Instead of GROUP BY, use DISTINCT to get unique records
    //     $query->distinct('et_customer_services.sno');

    //     // Paginate results
    //     $lists = $query->paginate($perpage);

    //     // ========== COUNT QUERIES ==========

    //     // Submitted Count
    //     $submittedCount = DB::table('et_manage_journal')
    //         ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
    //         ->where('et_manage_journal.status', 0);

    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         if ($user_role == 34) {
    //             $submittedCount = $submittedCount->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $submittedCount = $submittedCount->where('et_customer_services.jc_id', $user_id);
    //         }
    //     } elseif (! auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'global_cus')) {
    //         abort(403, 'Unauthorized');
    //     }

    //     $submittedCount = $submittedCount->count();

    //     // Reviewed Count
    //     $reviewedCount = DB::table('et_manage_journal')
    //         ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
    //         ->where('et_manage_journal.status', 4);

    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         if ($user_role == 34) {
    //             $reviewedCount = $reviewedCount->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $reviewedCount = $reviewedCount->where('et_customer_services.jc_id', $user_id);
    //         }
    //     }

    //     $reviewedCount = $reviewedCount->count();

    //     $withEditorCount = DB::table('et_manage_journal')
    //         ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
    //         ->where('et_manage_journal.status', 1);

    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         if ($user_role == 34) {
    //             $withEditorCount = $withEditorCount->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $withEditorCount = $withEditorCount->where('et_customer_services.jc_id', $user_id);
    //         }
    //     }

    //     $withEditorCount = $withEditorCount->count();

    //     $underReviewerCount = DB::table('et_manage_journal')
    //         ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
    //         ->where('et_manage_journal.status', 3);

    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         if ($user_role == 34) {
    //             $underReviewerCount = $underReviewerCount->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $underReviewerCount = $underReviewerCount->where('et_customer_services.jc_id', $user_id);
    //         }
    //     }

    //     $underReviewerCount = $underReviewerCount->count();

    //     $eproofingCount = DB::table('et_manage_journal')
    //         ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
    //         ->where('et_manage_journal.status', 7);

    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         if ($user_role == 34) {
    //             $eproofingCount = $eproofingCount->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $eproofingCount = $eproofingCount->where('et_customer_services.jc_id', $user_id);
    //         }
    //     }

    //     $eproofingCount = $eproofingCount->count();

    //     // Resubmitted Count
    //     $resubmittedCount = DB::table('et_manage_journal')
    //         ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
    //         ->where('et_manage_journal.status', 3);

    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         if ($user_role == 34) {
    //             $resubmittedCount = $resubmittedCount->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $resubmittedCount = $resubmittedCount->where('et_customer_services.jc_id', $user_id);
    //         }
    //     }

    //     $resubmittedCount = $resubmittedCount->count();

    //     // Accepted Count
    //     $acceptedCount = DB::table('et_manage_journal')
    //         ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
    //         ->where('et_manage_journal.status', 5);

    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         if ($user_role == 34) {
    //             $acceptedCount = $acceptedCount->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $acceptedCount = $acceptedCount->where('et_customer_services.jc_id', $user_id);
    //         }
    //     }

    //     $acceptedCount = $acceptedCount->count();

    //     // Rejected Count
    //     $rejectedCount = DB::table('et_manage_journal')
    //         ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
    //         ->where('et_manage_journal.status', 6);

    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         if ($user_role == 34) {
    //             $rejectedCount = $rejectedCount->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $rejectedCount = $rejectedCount->where('et_customer_services.jc_id', $user_id);
    //         }
    //     }

    //     $rejectedCount = $rejectedCount->count();

    //     // Published Count
    //     $publishedCount = DB::table('et_manage_journal')
    //         ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
    //         ->where('et_manage_journal.status', 8);

    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         if ($user_role == 34) {
    //             $publishedCount = $publishedCount->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $publishedCount = $publishedCount->where('et_customer_services.jc_id', $user_id);
    //         }
    //     }

    //     $publishedCount = $publishedCount->count();

    //     // ========== PROCESS EACH SERVICE ==========

    //     foreach ($lists as $list) {
    //         // Get domain names from helper
    //         $domain_names = $helper->get_domain_by_proposalId($list->proposal_id);
    //         $list->domain_names = $domain_names;

    //         // Process journal index
    //         if (! empty($list->journal_index)) {
    //             $decoded = json_decode($list->journal_index, true);

    //             if (is_array($decoded)) {
    //                 $index_ids = $decoded;
    //             } elseif (is_numeric($list->journal_index)) {
    //                 $index_ids = [(int) $list->journal_index];
    //             } else {
    //                 $index_ids = [];
    //             }

    //             if (! empty($index_ids)) {
    //                 $index_names = DB::table('et_journal_index')
    //                     ->whereIn('sno', $index_ids)
    //                     ->where('status', 0)
    //                     ->pluck('index_name')
    //                     ->toArray();

    //                 $list->index_names = ! empty($index_names)
    //                     ? implode(', ', $index_names)
    //                     : 'No Index';
    //             } else {
    //                 $list->index_names = 'No Index';
    //             }
    //         } else {
    //             $list->index_names = 'No Index';
    //         }

    //         // Generate service ID
    //         $year = date('Y', strtotime($list->created_at));
    //         $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
    //         $list->service_id = "SR-{$id}/{$year}";

    //         // Get journal data for this service
    //         $journalDataQuery = DB::table('et_manage_journal')
    //             ->where('et_manage_journal.service_id', $list->sno)
    //             ->where('et_manage_journal.customer_id', $list->journal_customer_id)
    //             ->where('et_manage_journal.branch_id', $branch_id)
    //             ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
    //             ->select(
    //                 'et_journal_booklet.journal_name',
    //                 'et_journal_booklet.domain_id',
    //                 'et_manage_journal.status',
    //                 'et_manage_journal.paper_name',
    //                 'et_manage_journal.journal_id',
    //                 'et_manage_journal.submited_date',
    //                 'et_manage_journal.sno',
    //                 'et_manage_journal.publish_author',
    //                 'et_manage_journal.published_paper_name',
    //                 'et_manage_journal.publish_url',
    //                 'et_manage_journal.publish_date',
    //             );

    //         // Apply status filter to journal data if selected
    //         if ($statusFilter !== null) {
    //             $journalDataQuery->where('et_manage_journal.status', $statusFilter);
    //         }

    //         $list->journal_data = $journalDataQuery->get();

    //         // Process domain names for each journal
    //         foreach ($list->journal_data as $journal) {
    //             if ($journal->domain_id) {
    //                 $domain_ids = json_decode($journal->domain_id, true);

    //                 if (is_array($domain_ids) && ! empty($domain_ids)) {
    //                     $domain_names = DB::table('et_domain')
    //                         ->whereIn('et_domain.sno', $domain_ids)
    //                         ->where('et_domain.status', 0)
    //                         ->pluck('domain_name')
    //                         ->toArray();

    //                     $journal->domain_names = $domain_names;
    //                 } else {
    //                     $journal->domain_names = [];
    //                 }
    //             } else {
    //                 $journal->domain_names = [];
    //             }
    //         }
    //     }

    //     // Return view with all data
    //     return view('content.journal_management.manage_journal.list', [
    //         'lists' => $lists,
    //         'perpage' => $perpage,
    //         'search_fill' => $search_fill,
    //         'submittedCount' => $submittedCount,
    //         'reviewedCount' => $reviewedCount,
    //         'resubmittedCount' => $resubmittedCount,
    //         'underReviewerCount' => $underReviewerCount,
    //         'eproofingCount' => $eproofingCount,
    //         'withEditorCount' => $withEditorCount,
    //         'acceptedCount' => $acceptedCount,
    //         'rejectedCount' => $rejectedCount,
    //         'publishedCount' => $publishedCount,
    //         'currentStatus' => $statusFilter,
    //     ]);
    // }
    
    // public function index(Request $request)
    // {
    //     $helper = new \App\Helpers\Helpers();
    //     $page = $request->input('page', 1);
    //     $perpage = (int) $request->input('sorting_filter', 25);
    //     $branch_id = $request->user()->branch_id;
    //     $search_fill = $request->search_fill ?? '';
    //     $user_id = $request->user()->user_id;
    //     $user_role = $request->user()->role_id;
    //     $status_fill = $request->status ?? '';
 
    //     // ================= MAIN QUERY =================
    //     $query = DB::table('et_customer_services')
    //         ->where('et_customer_services.journal_check', 1)
    //         ->where('et_customer_services.branch_id', $branch_id)
    //         ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
    //         ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
    //         ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
    //         ->leftJoin('et_product', function ($join) {
    //             $join->on('et_product.sno', '=', 'et_customer_services.product_id')
    //                 ->where('et_customer_services.product_package', 1);
    //         })
    //         ->leftJoin('et_package', function ($join) {
    //             $join->on('et_package.sno', '=', 'et_customer_services.package_id')
    //                 ->where('et_customer_services.product_package', 2);
    //         })
    //         ->select(
    //             'et_customer.cus_name',
    //             'et_customer.customer_id',
    //             'et_customer_services.sno',
    //             'et_customer_services.created_at',
    //             'et_customer_services.journal_index',
    //             'et_customer_services.proposal_id',
    //             'et_customer.sno as journal_customer_id',
    //             'et_customer_services.jc_id',
    //             'et_customer_services.jc_staff',
    //             'journal_staff.staff_name as journal_staff_name',
    //             'journal_coordinator.staff_name as jouranal_coordinator_name',
    //             'journal_staff.staff_image as journal_staff_image',
    //             'journal_coordinator.staff_image as jouranal_coordinator_image',
    //             DB::raw('CASE
    //             WHEN et_customer_services.product_package = 1 THEN et_product.product_name
    //             WHEN et_customer_services.product_package = 2 THEN et_package.package_name
    //             ELSE NULL
    //         END as service_name')
    //         );
 
    //     // ================= STATUS FILTER (FIXED) =================
    //     if ($status_fill !== '') {
    //         $query->whereIn('et_customer_services.sno', function ($sub) use ($branch_id, $status_fill) {
    //             $sub->select('service_id')
    //                 ->from('et_manage_journal')
    //                 ->where('branch_id', $branch_id)
    //                 ->where('status', $status_fill)
    //                 ->groupBy('service_id')
    //                 ->havingRaw('COUNT(*) >= 1'); // ✅ only services with >1 journals
    //         });
    //     }
 
    //     // ================= PERMISSIONS =================
    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         if ($user_role == 34) {
    //             $query->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $query->where('et_customer_services.jc_id', $user_id);
    //         }
    //     } elseif (!auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'global_cus')) {
    //         abort(403, 'Unauthorized');
    //     }
 
    //     // ================= SEARCH =================
    //     if ($search_fill != '') {
    //         $query->where(function ($list) use ($search_fill) {
    //             $list->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_package.package_name', 'LIKE', "%{$search_fill}%");
    //         });
    //     }
 
    //     $query->distinct();
 
    //     // ================= PAGINATION =================
    //     $lists = $query->paginate($perpage);
 
    //     // ================= STATUS COUNTS (IMPROVED) =================
    //     $getStatusCount = function ($status) use ($branch_id, $user_id, $user_role) {
    //         $q = DB::table('et_manage_journal')
    //             ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
    //             ->where('et_manage_journal.branch_id', $branch_id)
    //             ->where('et_manage_journal.status', $status);
 
    //         if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //             if ($user_role == 34) {
    //                 $q->where('et_customer_services.jc_staff', $user_id);
    //             } elseif ($user_role == 33) {
    //                 $q->where('et_customer_services.jc_id', $user_id);
    //             }
    //         }
 
    //         return $q->count();
    //     };
 
    //     $submittedCount      = $getStatusCount(0);
    //     $withEditorCount     = $getStatusCount(1);
    //     $underReviewerCount  = $getStatusCount(3);
    //     $reviewedCount       = $getStatusCount(4);
    //     $acceptedCount       = $getStatusCount(5);
    //     $rejectedCount       = $getStatusCount(6);
    //     $eproofingCount      = $getStatusCount(7);
    //     $publishedCount      = $getStatusCount(8);
    //     $resubmittedCount    = $getStatusCount(3); // (same as underReviewer in your logic)
 
    //     // ================= LOOP =================
    //     foreach ($lists as $list) {
 
    //         $list->domain_names = $helper->get_domain_by_proposalId($list->proposal_id);
 
    //         // Journal Index
    //         $index_ids = json_decode($list->journal_index, true);
    //         if (!is_array($index_ids)) {
    //             $index_ids = is_numeric($list->journal_index) ? [(int)$list->journal_index] : [];
    //         }
 
    //         if (!empty($index_ids)) {
    //             $names = DB::table('et_journal_index')
    //                 ->whereIn('sno', $index_ids)
    //                 ->where('status', 0)
    //                 ->pluck('index_name')
    //                 ->toArray();
 
    //             $list->index_names = !empty($names) ? implode(', ', $names) : 'No Index';
    //         } else {
    //             $list->index_names = 'No Index';
    //         }
 
    //         // Service ID
    //         $year = date('Y', strtotime($list->created_at));
    //         $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
    //         $list->service_id = "SR-{$id}/{$year}";
 
    //         // Journal Data
    //         $journalQuery = DB::table('et_manage_journal')
    //             ->where('et_manage_journal.service_id', $list->sno)
    //             ->where('et_manage_journal.customer_id', $list->journal_customer_id)
    //             ->where('et_manage_journal.branch_id', $branch_id)
    //             ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
    //             ->select(
    //                 'et_journal_booklet.journal_name',
    //                 'et_journal_booklet.domain_id',
    //                 'et_manage_journal.status',
    //                 'et_manage_journal.paper_name',
    //                 'et_manage_journal.journal_id',
    //                 'et_manage_journal.submited_date',
    //                 'et_manage_journal.sno',
    //                 'et_manage_journal.publish_author',
    //                 'et_manage_journal.published_paper_name',
    //                 'et_manage_journal.publish_url',
    //                 'et_manage_journal.publish_date'
    //             );
 
    //         if ($status_fill !== '') {
    //             $journalQuery->where('et_manage_journal.status', $status_fill);
    //         }
 
    //         $list->journal_data = $journalQuery->get();
 
    //         // Domain Mapping
    //         foreach ($list->journal_data as $journal) {
    //             $domain_ids = json_decode($journal->domain_id, true);
 
    //             if (is_array($domain_ids) && !empty($domain_ids)) {
    //                 $journal->domain_names = DB::table('et_domain')
    //                     ->whereIn('sno', $domain_ids)
    //                     ->where('status', 0)
    //                     ->pluck('domain_name')
    //                     ->toArray();
    //             } else {
    //                 $journal->domain_names = [];
    //             }
    //         }
    //     }
 
    //     // ================= RETURN =================
    //     return view('content.journal_management.manage_journal.list', compact(
    //         'lists',
    //         'perpage',
    //         'search_fill',
    //         'submittedCount',
    //         'reviewedCount',
    //         'resubmittedCount',
    //         'underReviewerCount',
    //         'eproofingCount',
    //         'withEditorCount',
    //         'acceptedCount',
    //         'rejectedCount',
    //         'publishedCount'
    //     ) + ['currentStatus' => $status_fill]);
    // }

    // public function index(Request $request)
    // {
    //     $helper = new \App\Helpers\Helpers();
    //     $page = $request->input('page', 1);
    //     $perpage = (int) $request->input('sorting_filter', 25);
    //     $branch_id = $request->user()->branch_id;
    //     $search_fill = $request->search_fill ?? '';
    //     $user_id = $request->user()->user_id;
    //     $user_role = $request->user()->role_id;
    //     $status_fill = $request->status ?? '';
 
    //     // ================= BASE QUERY (without filters) =================
    //     $baseQuery = DB::table('et_customer_services')
    //         ->where('et_customer_services.journal_check', 1)
    //         ->where('et_customer_services.branch_id', $branch_id)
    //         ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
    //         ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
    //         ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
    //         ->leftJoin('et_product', function ($join) {
    //             $join->on('et_product.sno', '=', 'et_customer_services.product_id')
    //                 ->where('et_customer_services.product_package', 1);
    //         })
    //         ->leftJoin('et_package', function ($join) {
    //             $join->on('et_package.sno', '=', 'et_customer_services.package_id')
    //                 ->where('et_customer_services.product_package', 2);
    //         });
 
    //     // ================= APPLY PERMISSIONS =================
    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //         if ($user_role == 34) {
    //             $baseQuery->where('et_customer_services.jc_staff', $user_id);
    //         } elseif ($user_role == 33) {
    //             $baseQuery->where('et_customer_services.jc_id', $user_id);
    //         }
    //     } elseif (!auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'global_cus')) {
    //         abort(403, 'Unauthorized');
    //     }
 
 
 
    //     // ================= APPLY SEARCH AND STATUS FILTERS FOR PAGINATED RESULTS =================
    //     $filteredQuery = clone $baseQuery;
 
 
    //     // Status Filter
    //     if ($status_fill !== '') {
    //         $filteredQuery->whereIn('et_customer_services.sno', function ($sub) use ($branch_id, $status_fill) {
    //             $sub->select('service_id')
    //                 ->from('et_manage_journal')
    //                 ->where('branch_id', $branch_id)
    //                 ->where('status', $status_fill)
    //                 ->groupBy('service_id');
    //         });
    //     }
 
    //     // Search Filter
    //     if ($search_fill != '') {
    //         $filteredQuery->where(function ($list) use ($search_fill) {
    //             $list->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_package.package_name', 'LIKE', "%{$search_fill}%");
    //         });
    //     }
 
    //     // ================= CALCULATE TOTAL PAPERS (without search/status filters) =================
 
 
    //     // Add select fields for the filtered query
    //     $filteredQuery->select(
    //         'et_customer.cus_name',
    //         'et_customer.customer_id',
    //         'et_customer_services.sno',
    //         'et_customer_services.created_at',
    //         'et_customer_services.journal_index',
    //         'et_customer_services.proposal_id',
    //         'et_customer.sno as journal_customer_id',
    //         'et_customer_services.jc_id',
    //         'et_customer_services.jc_staff',
    //         'journal_staff.staff_name as journal_staff_name',
    //         'journal_coordinator.staff_name as jouranal_coordinator_name',
    //         'journal_staff.staff_image as journal_staff_image',
    //         'journal_coordinator.staff_image as jouranal_coordinator_image',
    //         DB::raw('CASE
    //         WHEN et_customer_services.product_package = 1 THEN et_product.product_name
    //         WHEN et_customer_services.product_package = 2 THEN et_package.package_name
    //         ELSE NULL
    //     END as service_name')
    //     );

        
    //     $filteredQuery->distinct('et_customer_services.sno'); // Distinct by service ID, not all columns
    //     $filteredQuery1 = clone $filteredQuery;
    //     $filteredQuery1->distinct('et_customer_services.customer_id'); // Distinct by service ID, not all columns
    //     // $filteredQuery2 = clone $filteredQuery;
    //     // ================= PAGINATION =================
    //     $customer_count = $filteredQuery1->count();
    //     // $pending_followupcount = $filteredQuery2->where('et_customer_services.follow_up_count', 0)->count();
    //     // ================= CALCULATE TOTAL PAPERS (without search/status filters) =================
    //     // Count directly from et_customer_services table to avoid join duplication issues
    //     // $totalpapersServices = $filteredQuery->pluck('sno');
 
    //     // $totalpapersQuery = DB::table('et_manage_journal')
    //     //     ->where('status', '!=', 2)
    //     //     ->whereIn('service_id', $totalpapersServices);
 
    //     // $totalpapers = $totalpapersQuery->count();
    //     $totalpapers = $filteredQuery->count();
 
    //     $today_followup_counts = DB::table('et_journal_followup')
    //         ->where('appointment_date', date('Y-m-d'))
    //         ->distinct('customer_service_id')->count();
    //     $pending_followupcount = $totalpapers - $today_followup_counts;
        
 
    //     $lists = $filteredQuery->paginate($perpage);
 
    //     // ================= STATUS COUNTS =================
    //     $getStatusCount = function ($status) use ($branch_id, $user_id, $user_role) {
    //         $q = DB::table('et_manage_journal')
    //             ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
    //             ->where('et_manage_journal.branch_id', $branch_id)
    //             ->where('et_manage_journal.status', $status);
 
    //         if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
    //             if ($user_role == 34) {
    //                 $q->where('et_customer_services.jc_staff', $user_id);
    //             } elseif ($user_role == 33) {
    //                 $q->where('et_customer_services.jc_id', $user_id);
    //             }
    //         }
 
    //         return $q->count();
    //     };
 
    //     $submittedCount      = $getStatusCount(0);
    //     $withEditorCount     = $getStatusCount(1);
    //     $underReviewerCount  = $getStatusCount(3);
    //     $reviewedCount       = $getStatusCount(4);
    //     $acceptedCount       = $getStatusCount(5);
    //     $rejectedCount       = $getStatusCount(6);
    //     $eproofingCount      = $getStatusCount(7);
    //     $publishedCount      = $getStatusCount(8);
    //     $resubmittedCount    = $getStatusCount(9); // Use appropriate status
 
    //     // ================= LOOP =================
    //     foreach ($lists as $list) {
    //         $list->domain_names = $helper->get_domain_by_proposalId($list->proposal_id);
 
    //         // Journal Index
    //         $index_ids = json_decode($list->journal_index, true);
    //         if (!is_array($index_ids)) {
    //             $index_ids = is_numeric($list->journal_index) ? [(int)$list->journal_index] : [];
    //         }
 
    //         if (!empty($index_ids)) {
    //             $names = DB::table('et_journal_index')
    //                 ->whereIn('sno', $index_ids)
    //                 ->where('status', 0)
    //                 ->pluck('index_name')
    //                 ->toArray();
 
    //             $list->index_names = !empty($names) ? implode(', ', $names) : 'No Index';
    //         } else {
    //             $list->index_names = 'No Index';
    //         }
 
    //         // Service ID
    //         $year = date('Y', strtotime($list->created_at));
    //         $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
    //         $list->service_id = "SR-{$id}/{$year}";
 
    //         // Journal Data
    //         $journalQuery = DB::table('et_manage_journal')
    //             ->where('et_manage_journal.service_id', $list->sno)
    //             ->where('et_manage_journal.customer_id', $list->journal_customer_id)
    //             ->where('et_manage_journal.branch_id', $branch_id)
    //             ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
    //             ->select(
    //                 'et_journal_booklet.journal_name',
    //                 'et_journal_booklet.domain_id',
    //                 'et_manage_journal.status',
    //                 'et_manage_journal.paper_name',
    //                 'et_manage_journal.journal_id',
    //                 'et_manage_journal.submited_date',
    //                 'et_manage_journal.sno',
    //                 'et_manage_journal.publish_author',
    //                 'et_manage_journal.published_paper_name',
    //                 'et_manage_journal.publish_url',
    //                 'et_manage_journal.publish_date'
    //             );
 
    //         if ($status_fill !== '') {
    //             $journalQuery->where('et_manage_journal.status', $status_fill);
    //         }
 
    //         $list->journal_data = $journalQuery->get();
 
    //         // Domain Mapping
    //         foreach ($list->journal_data as $journal) {
    //             $domain_ids = json_decode($journal->domain_id, true);
 
    //             if (is_array($domain_ids) && !empty($domain_ids)) {
    //                 $journal->domain_names = DB::table('et_domain')
    //                     ->whereIn('sno', $domain_ids)
    //                     ->where('status', 0)
    //                     ->pluck('domain_name')
    //                     ->toArray();
    //             } else {
    //                 $journal->domain_names = [];
    //             }
    //         }
    //     }
 
    //     // Debug: You can add this temporarily to verify counts
    //     // \Log::info('Total Papers: ' . $totalpapers);
    //     // \Log::info('Customer Count (filtered): ' . $customer_count);
    //     $currentStatus = $status_fill;
    //     $followupReasonList = FollowupReasonModel::select('*')
    //         ->where('status', 0)
    //         ->orderBy('sno', 'desc')->get();
    //     // ================= RETURN =================
    //     return view('content.journal_management.manage_journal.list', compact(
    //         'lists',
    //         'perpage',
    //         'search_fill',
    //         'submittedCount',
    //         'reviewedCount',
    //         'resubmittedCount',
    //         'underReviewerCount',
    //         'eproofingCount',
    //         'withEditorCount',
    //         'acceptedCount',
    //         'rejectedCount',
    //         'publishedCount',
    //         'customer_count',
    //         'totalpapers',
    //         'pending_followupcount',
    //         'followupReasonList',
    //         'currentStatus'
    //     ));
    // }
    
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $branch_id = $request->user()->branch_id;
        $search_fill = $request->search_fill ?? '';
        $user_id = $request->user()->user_id;
        $user_role = $request->user()->role_id;
        $status_fill = $request->status ?? '';

        // ================= BASE QUERY (without filters) =================
        $baseQuery = DB::table('et_customer_services')
            ->where('et_customer_services.journal_check', 1)
            ->where('et_customer_services.branch_id', $branch_id)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
            ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', 2);
            });

        // ================= APPLY PERMISSIONS =================
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $baseQuery->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $baseQuery->where('et_customer_services.jc_id', $user_id);
            }
        } elseif (!auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'global_cus')) {
            abort(403, 'Unauthorized');
        }



        // ================= APPLY SEARCH AND STATUS FILTERS FOR PAGINATED RESULTS =================
        $filteredQuery = clone $baseQuery;


        // Status Filter
        if ($status_fill !== '') {
            $filteredQuery->whereIn('et_customer_services.sno', function ($sub) use ($branch_id, $status_fill) {
                $sub->select('service_id')
                    ->from('et_manage_journal')
                    ->where('branch_id', $branch_id)
                    ->where('status', $status_fill)
                    ->groupBy('service_id');
            });
        }

        // Search Filter
        if ($search_fill != '') {
            $filteredQuery->where(function ($list) use ($search_fill) {
                $list->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_package.package_name', 'LIKE', "%{$search_fill}%");
            });
        }

        // ================= CALCULATE TOTAL PAPERS (without search/status filters) =================


        // Add select fields for the filtered query
        $filteredQuery->select(
            'et_customer.cus_name',
            'et_customer.customer_id',
            'et_customer_services.sno',
            'et_customer_services.created_at',
            'et_customer_services.journal_index',
            'et_customer_services.proposal_id',
            'et_customer.sno as journal_customer_id',
            'et_customer_services.jc_id',
            'et_customer_services.jc_staff',
            'journal_staff.staff_name as journal_staff_name',
            'journal_coordinator.staff_name as jouranal_coordinator_name',
            'journal_staff.staff_image as journal_staff_image',
            'journal_coordinator.staff_image as jouranal_coordinator_image',
            DB::raw('CASE
            WHEN et_customer_services.product_package = 1 THEN et_product.product_name
            WHEN et_customer_services.product_package = 2 THEN et_package.package_name
            ELSE NULL
        END as service_name')
        );

        $filteredQuery->distinct('et_customer_services.sno'); // Distinct by service ID, not all columns
        $filteredQuery1 = clone $filteredQuery;
        $filteredQuery1->distinct('et_customer_services.customer_id'); // Distinct by service ID, not all columns
        // $filteredQuery2 = clone $filteredQuery;
        // ================= PAGINATION =================
        $customer_count = $filteredQuery1->count();
        // $pending_followupcount = $filteredQuery2->where('et_customer_services.follow_up_count', 0)->count();
        // ================= CALCULATE TOTAL PAPERS (without search/status filters) =================
        // Count directly from et_customer_services table to avoid join duplication issues
        // $totalpapersServices = $filteredQuery->pluck('sno');

        // $totalpapersQuery = DB::table('et_manage_journal')
        //     ->where('status', '!=', 2)
        //     ->whereIn('service_id', $totalpapersServices);

        // $totalpapers = $totalpapersQuery->count();
        $totalpapers = $filteredQuery->count();

        $today_followup_counts = DB::table('et_journal_followup')
            ->where('appointment_date', date('Y-m-d'))
            ->distinct('customer_service_id')->count();
        $pending_followupcount = $totalpapers - $today_followup_counts;

        $lists = $filteredQuery->paginate($perpage);

        // ================= STATUS COUNTS =================
        $getStatusCount = function ($status) use ($branch_id, $user_id, $user_role) {
            $q = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->where('et_manage_journal.branch_id', $branch_id)
                ->where('et_manage_journal.status', $status);

            if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
                if ($user_role == 34) {
                    $q->where('et_customer_services.jc_staff', $user_id);
                } elseif ($user_role == 33) {
                    $q->where('et_customer_services.jc_id', $user_id);
                }
            }

            return $q->count();
        };

        $submittedCount      = $getStatusCount(0);
        $withEditorCount     = $getStatusCount(1);
        $underReviewerCount  = $getStatusCount(3);
        $reviewedCount       = $getStatusCount(4);
        $acceptedCount       = $getStatusCount(5);
        $rejectedCount       = $getStatusCount(6);
        $eproofingCount      = $getStatusCount(7);
        $publishedCount      = $getStatusCount(8);
        $resubmittedCount    = $getStatusCount(9); // Use appropriate status

        // ================= LOOP =================
        foreach ($lists as $list) {
            $list->domain_names = $helper->get_domain_by_proposalId($list->proposal_id);

            // Journal Index
            $index_ids = json_decode($list->journal_index, true);
            if (!is_array($index_ids)) {
                $index_ids = is_numeric($list->journal_index) ? [(int)$list->journal_index] : [];
            }

            if (!empty($index_ids)) {
                $names = DB::table('et_journal_index')
                    ->whereIn('sno', $index_ids)
                    ->where('status', 0)
                    ->pluck('index_name')
                    ->toArray();

                $list->index_names = !empty($names) ? implode(', ', $names) : 'No Index';
            } else {
                $list->index_names = 'No Index';
            }

            // Service ID
            $year = date('Y', strtotime($list->created_at));
            $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
            $list->service_id = "SR-{$id}/{$year}";

            // Journal Data
            $journalQuery = DB::table('et_manage_journal')
                ->where('et_manage_journal.service_id', $list->sno)
                ->where('et_manage_journal.customer_id', $list->journal_customer_id)
                ->where('et_manage_journal.branch_id', $branch_id)
                ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
                ->select(
                    'et_journal_booklet.journal_name',
                    'et_journal_booklet.domain_id',
                    'et_manage_journal.status',
                    'et_manage_journal.paper_name',
                    'et_manage_journal.journal_id',
                    'et_manage_journal.submited_date',
                    'et_manage_journal.sno',
                    'et_manage_journal.publish_author',
                    'et_manage_journal.published_paper_name',
                    'et_manage_journal.publish_url',
                    'et_manage_journal.publish_date'
                );

            if ($status_fill !== '') {
                $journalQuery->where('et_manage_journal.status', $status_fill);
            }

            $list->journal_data = $journalQuery->get();

            // Domain Mapping
            foreach ($list->journal_data as $journal) {
                $domain_ids = json_decode($journal->domain_id, true);

                if (is_array($domain_ids) && !empty($domain_ids)) {
                    $journal->domain_names = DB::table('et_domain')
                        ->whereIn('sno', $domain_ids)
                        ->where('status', 0)
                        ->pluck('domain_name')
                        ->toArray();
                } else {
                    $journal->domain_names = [];
                }
            }
        }

        // Debug: You can add this temporarily to verify counts
        // \Log::info('Total Papers: ' . $totalpapers);
        // \Log::info('Customer Count (filtered): ' . $customer_count);
        $currentStatus = $status_fill;
        $followupReasonList = FollowupReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();
        // ================= RETURN =================
        return view('content.journal_management.manage_journal.list', compact(
            'lists',
            'perpage',
            'search_fill',
            'submittedCount',
            'reviewedCount',
            'resubmittedCount',
            'underReviewerCount',
            'eproofingCount',
            'withEditorCount',
            'acceptedCount',
            'rejectedCount',
            'publishedCount',
            'customer_count',
            'totalpapers',
            'pending_followupcount',
            'followupReasonList',
            'currentStatus'
        ));
    }
    
    public function published_list(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $branch_id = $request->user()->branch_id;
        $search_fill = $request->search_fill ?? '';
        $user_id = $request->user()->user_id;
        $user_role = $request->user()->role_id;
        $status_fill = $request->status ?? '';
 
        // ================= BASE QUERY (without filters) =================
        $baseQuery = DB::table('et_manage_journal')
            ->where('et_customer_services.journal_check', 1)
            ->where('et_manage_journal.status', 8)
            ->where('et_manage_journal.branch_id', $branch_id)
            ->leftJoin('et_customer_services', 'et_manage_journal.service_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
            ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', 2);
            });
 
        // ================= APPLY PERMISSIONS =================
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $baseQuery->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $baseQuery->where('et_customer_services.jc_id', $user_id);
            }
        } elseif (!auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'global_cus')) {
            abort(403, 'Unauthorized');
        }
 
 
        // ================= APPLY SEARCH AND STATUS FILTERS FOR PAGINATED RESULTS =================
        $filteredQuery = clone $baseQuery;
 
 
        // Status Filter
        if ($status_fill !== '') {
            $filteredQuery->whereIn('et_customer_services.sno', function ($sub) use ($branch_id, $status_fill) {
                $sub->select('service_id')
                    ->from('et_manage_journal')
                    ->where('branch_id', $branch_id)
                    ->where('status', $status_fill)
                    ->groupBy('service_id');
            });
        }
 
        // Search Filter
        if ($search_fill != '') {
            $filteredQuery->where(function ($list) use ($search_fill) {
                $list->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_journal_booklet.journal_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_manage_journal.paper_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_manage_journal.published_paper_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_package.package_name', 'LIKE', "%{$search_fill}%");
            });
        }
 
        // ================= CALCULATE TOTAL PAPERS (without search/status filters) =================
 
 
        // Add select fields for the filtered query
        $filteredQuery->select(
            'et_manage_journal.sno',
            'et_journal_booklet.journal_name',
            'et_journal_booklet.domain_id',
            'et_manage_journal.paper_name',
            'et_manage_journal.journal_id',
            'et_manage_journal.publish_date',
            'et_manage_journal.published_paper_name',
            'et_manage_journal.publish_url',
            'et_manage_journal.publish_author',
            'et_manage_journal.status as j_status',
            'et_customer.cus_name',
            'et_customer.customer_id',
            'et_customer_services.sno AS ser_sno',
            'et_customer_services.created_at',
            'et_customer_services.journal_index',
            'et_customer_services.proposal_id',
            'et_customer.sno as journal_customer_id',
            'et_customer_services.jc_id',
            'et_customer_services.jc_staff',
            'journal_staff.staff_name as journal_staff_name',
            'journal_coordinator.staff_name as jouranal_coordinator_name',
            'journal_staff.staff_image as journal_staff_image',
            'journal_coordinator.staff_image as jouranal_coordinator_image',
            DB::raw('CASE
            WHEN et_customer_services.product_package = 1 THEN et_product.product_name
            WHEN et_customer_services.product_package = 2 THEN et_package.package_name
            ELSE NULL
        END as service_name')
        );
        $lists = $filteredQuery->orderBy('et_manage_journal.publish_date', 'DESC')->paginate($perpage);
 
        // ================= STATUS COUNTS =================
        $total_published =  DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.branch_id', $branch_id)
            ->where('et_manage_journal.status', 8);
 
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $total_published->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $total_published->where('et_customer_services.jc_id', $user_id);
            }
        }
 
        $total_published = $total_published->count();
 
        $baseQuery = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.branch_id', $branch_id)
            ->where('et_manage_journal.status', 8);
 
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) {
                $baseQuery->where('et_customer_services.jc_staff', $user_id);
            } elseif ($user_role == 33) {
                $baseQuery->where('et_customer_services.jc_id', $user_id);
            }
        }
 
        /*
        |-------------------------
        | This Month
        |-------------------------
        */
        $this_month_published = (clone $baseQuery)
            ->whereYear('et_manage_journal.publish_date', Carbon::now()->year)
            ->whereMonth('et_manage_journal.publish_date', Carbon::now()->month)
            ->count();
 
        /*
        |-------------------------
        | Last Month
        |-------------------------
        */
        $lastMonth = Carbon::now()->subMonth();
 
        $last_month_published = (clone $baseQuery)
            ->whereYear('et_manage_journal.publish_date', $lastMonth->year)
            ->whereMonth('et_manage_journal.publish_date', $lastMonth->month)
            ->count();
 
 
        // ================= LOOP =================
        foreach ($lists as $list) {
 
            // Journal Index
            $index_ids = json_decode($list->journal_index, true);
            if (!is_array($index_ids)) {
                $index_ids = is_numeric($list->journal_index) ? [(int)$list->journal_index] : [];
            }
 
            if (!empty($index_ids)) {
                $names = DB::table('et_journal_index')
                    ->whereIn('sno', $index_ids)
                    ->where('status', 0)
                    ->pluck('index_name')
                    ->toArray();
 
                $list->index_names = !empty($names) ? implode(', ', $names) : 'No Index';
            } else {
                $list->index_names = 'No Index';
            }
 
            // Service ID
            $year = date('Y', strtotime($list->created_at));
            $id = str_pad($list->ser_sno, 5, '0', STR_PAD_LEFT);
            $list->service_id = "SR-{$id}/{$year}";
 
            // Domain Mapping
            $domain_ids = json_decode($list->domain_id, true);
            $list->domain_names = [];
            if (is_array($domain_ids) && !empty($domain_ids)) {
                $list->domain_names = DB::table('et_domain')
                    ->whereIn('sno', $domain_ids)
                    ->where('status', 0)
                    ->pluck('domain_name')
                    ->toArray();
            } else {
                $list->domain_names = [];
            }
        }
        // return $lists;
        // Debug: You can add this temporarily to verify counts
        // \Log::info('Total Papers: ' . $totalpapers);
        // \Log::info('Customer Count (filtered): ' . $customer_count);
        $currentStatus = $status_fill;
        $followupReasonList = FollowupReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();
        // ================= RETURN =================
        return view('content.journal_management.manage_journal.published_list', compact(
            'lists',
            'perpage',
            'search_fill',
            'total_published',
            'this_month_published',
            'last_month_published',
            'currentStatus'
        ));
    }
    
    
    public function addDataFetch($id)
    {
        $fetch = DB::table('et_customer_services')
            ->where('et_customer_services.sno', $id)
            ->where('et_customer_services.journal_check', 1)
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->select(
                'et_customer_services.*',
                'et_customer.cus_name',
                'et_customer.customer_id as cus_id',
                'et_customer.sno as cus_sno',
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name')
            )
            ->first();

        $year = date('Y', strtotime($fetch->created_at));
        $id = str_pad($fetch->sno, 5, '0', STR_PAD_LEFT);
        $fetch->service_id = "SR-{$id}/{$year}";

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $fetch,
        ], 200);
    }

    // ! DropZone File Upload
    public function uploadFiles(Request $request)
    {
        $request->validate([
            'file_upload.*' => 'required|file|max:10240', // max 10MB
        ]);

        $userId = $request->user()->user_id;
        $tempPath = public_path("{$userId}/temp");

        // ! Create Temp Folder If Not Create
        if (! File::exists($tempPath)) {
            File::makeDirectory($tempPath, 0777, true);
        }

        $uploaded = [];

        foreach ($request->file('file_upload') as $file) {

            // ^ Original File Name
            $originalName = $file->getClientOriginalName();

            // ^ Avoid Overwrite If Same Name Exists
            $fileName = time().'_'.$originalName;

            // ^ Move File
            $file->move($tempPath, $fileName);

            $uploaded[] = [
                'original_name' => $originalName,
                'stored_name' => $fileName,
                'path' => "{$userId}/temp/{$fileName}",
            ];
        }

        return response()->json([
            'success' => true,
            'files' => $uploaded,
        ]);
    }

    // ! DropZone File Remove
    public function removeFile(Request $request)
    {
        $request->validate([
            'file_name' => 'required|string',
        ]);

        $userId = $request->user()->user_id;
        $filePath = public_path("{$userId}/temp/{$request->file_name}");

        if (File::exists($filePath)) {
            File::delete($filePath);

            return response()->json([
                'success' => true,
                'message' => 'File removed successfully!',
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'File not found',
        ], 404);
    }

    private function token()
    {
        $client_id = \Config('services.google_drive.client_id');
        $client_secret = \Config('services.google_drive.client_secret');
        $refresh_token = \Config('services.google_drive.refresh_token');
        $google_response = Http::post('https://oauth2.googleapis.com/token', [
            'client_id' => $client_id,
            'client_secret' => $client_secret,
            'refresh_token' => $refresh_token,
            'grant_type' => 'refresh_token',
        ]);

        $access_token = json_decode((string) $google_response->getBody(), true)['access_token'];

        return $access_token;
    }

    // ! Give Permission
    private function makeFilePublic($fileId, $accessToken)
    {
        Http::withToken($accessToken)
            ->post("https://www.googleapis.com/drive/v3/files/{$fileId}/permissions", [
                'role' => 'reader',
                'type' => 'anyone',
            ]);
    }

    public function Create(Request $request)
    {
        try {
            $validated = $request->validate([
                'paper_name' => 'required|string|max:255',
                'journal_booklet_id' => 'required|integer',
                'customer_services_id' => 'required|integer',
                'customer_id' => 'required|integer',
            ]);

            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $submittedDate = $request->submitted_date ? date('Y-m-d', strtotime($request->submitted_date)) : now();

            DB::beginTransaction();

            // ! GENERATE JOURNAL ID
            $latest_journal = DB::table('et_manage_journal')
                ->where('status', '!=', 2)
                ->orderBy('sno', 'desc')
                ->first();

            $year = date('Y');

            if (! $latest_journal) {
                $journal_id = 'JOR0001'.'/'.$year;
            } else {
                $latest_journal_id = $latest_journal->journal_id;
                $parts = explode('/', $latest_journal_id);
                $numericPart = preg_replace('/[^0-9]/', '', $parts[0]);
                $nextNumber = (int) $numericPart + 1; // 8
                $journal_id = sprintf('JOR%04d/%s', $nextNumber, $year);
            }

            $journal = ManageJournalModel::create([
                'branch_id' => $branch_id,
                'service_id' => $validated['customer_services_id'],
                'customer_id' => $validated['customer_id'],
                'journal_id' => $journal_id,
                'booklet_id' => $validated['journal_booklet_id'],
                'paper_name' => $validated['paper_name'],
                'created_by' => $user_id,
                'updated_by' => $user_id,
                'submited_date' => $submittedDate,
            ]);

            DB::table('et_manage_journal')
                ->where('sno', $journal->sno)
                ->increment('submitted_count', 1);

            if (! $journal) {
                throw new Exception('Failed to submit journal.');
            }

            $driveDetails = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $journal->sno)
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_customer.customer_id',
                    'et_customer_services.created_at',
                    'et_customer_services.sno',
                    'et_manage_journal.journal_id',
                    'et_manage_journal.status',
                )
                ->first();

            $year = date('Y', strtotime($driveDetails->created_at));
            $id = str_pad($driveDetails->sno, 5, '0', STR_PAD_LEFT);
            $driveDetails->service_id = "SR-{$id}/{$year}";

            $driveDocuments = [];

            if ($request->filled('uploaded_files')) {
                $accessToken = $this->token();
                $files = json_decode($request->uploaded_files, true);

                $rootFolderId = config('services.google_drive.folder_id');

                // ! Customer Folder
                $customerFolderName = $driveDetails->customer_id;
                $customerFolderId = $this->findDriveFolder($customerFolderName, $rootFolderId, $accessToken)
                    ?? $this->createDriveFolder($customerFolderName, $rootFolderId, $accessToken);

                // ! Service Folder
                $serviceFolderName = $driveDetails->service_id;
                $serviceFolderId = $this->findDriveFolder($serviceFolderName, $customerFolderId, $accessToken)
                    ?? $this->createDriveFolder($serviceFolderName, $customerFolderId, $accessToken);

                // ! Journal Folder
                $journalFolderName = $driveDetails->journal_id;
                $journalFolderId = $this->findDriveFolder($journalFolderName, $serviceFolderId, $accessToken)
                    ?? $this->createDriveFolder($journalFolderName, $serviceFolderId, $accessToken);

                // ! Status Folder
                $status = $driveDetails->status == 0 ? 'Submitted' : 'Not Defined';
                $statusFolderName = "Status_{$status}";
                $statusFolderId = $this->findDriveFolder($statusFolderName, $journalFolderId, $accessToken)
                    ?? $this->createDriveFolder($statusFolderName, $journalFolderId, $accessToken);

                foreach ($files as $file) {

                    $localPath = public_path($file['path']);

                    if (! file_exists($localPath)) {
                        continue;
                    }

                    $driveFile = $this->uploadFileToDrive(
                        $localPath,
                        $file['original_name'],
                        $statusFolderId,
                        $accessToken
                    );

                    if ($driveDetails->status == 0) {
                        $this->makeFilePublic($statusFolderId, $accessToken);
                        $folderLink = "https://drive.google.com/drive/folders/{$statusFolderId}";
                    }

                    $driveFileId = null;

                    if (is_array($driveFile) && isset($driveFile['id'])) {
                        $driveFileId = $driveFile['id'];
                    } else {
                        throw new Exception('Google Drive upload failed for file: '.$file['original_name']);
                    }

                    $driveDocuments[] = [
                        'original_name' => $file['original_name'],
                        'drive_file_id' => $driveFileId,
                        'status' => 'Submitted',
                        'folderLink' => $folderLink ?? null,
                    ];

                    unlink($localPath);
                }

                // Cleanup user temp folder
                File::deleteDirectory(public_path("{$user_id}/temp"));
            }

            $journal->documents = $driveDocuments ? json_encode($driveDocuments) : null;
            $journal->save();

            if ($journal) {
                $history = new JournalHistoryModel();
                $history->branch_id = $branch_id;
                $history->customer_id = $validated['customer_id'];
                $history->service_id = $validated['customer_services_id'];
                $history->journal_id = $journal->sno;
                $history->submitted_date = $submittedDate;
                $history->submitted_documents = json_encode($driveDocuments) ?? null;
                $history->created_by = $user_id;
                $history->updated_by = $user_id;
                $history->save();

                // Customer app notification
                $sts_text = 'Submitted';
                $branch_id = $request->user()->branch_id;
                DB::table('et_notification_customer_app')->insert([
                    'branch_id' => $branch_id,
                    'notification_type_id' => 3,
                    'notification_type' => 'Journal',
                    'header' => $journal->paper_name,
                    'message' => 'Journal Status Updated',
                    'notification_date' => now(),
                    'meesage_for' => 'Journal Submitted',
                    'message_date' => $history->submitted_date,
                    'who' => $user_id,
                    'whom' => $validated['customer_id'],
                    'process_id' => $history->sno,
                    'status_text' => $sts_text,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);
            }

            if (! $history) {
                throw new Exception('Failed to create history.');
            }

            $emails = $request->input('email', []);
            $passwords = $request->input('password', []);

            if (is_array($emails) && is_array($passwords)) {
                foreach ($emails as $index => $email) {
                    $password = $passwords[$index] ?? null;
                    if (empty($email) || empty($password)) {
                        continue;
                    }

                    $credential = new PassLockerModel();
                    $credential->journal_id = $journal->sno;
                    $credential->customer_id = $validated['customer_id'];
                    $credential->user_name = $email;
                    $credential->password = $password;
                    $credential->created_by = $user_id;
                    $credential->updated_by = $user_id;
                    $credential->status = 1;
                    $credential->save();
                }
            }

            DB::commit();

            return response([
                'status' => 200,
                'message' => 'Journal Submitted Successfully!',
                'data' => null,
            ], 200);
        } catch (ValidationException $e) {
            DB::rollBack();

            return response([
                'status' => 422,
                'message' => 'Validation Failed',
                'error_msg' => $e->getMessage(),
                'data' => null,
            ], 422);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                'status' => 500,
                'message' => 'Failed to submit journal.',
                'error_msg' => $e->getMessage(),
                'data' => null,
            ], 500);
        }
    }

    // ! Create Folder If Not Exists
    private function createDriveFolder($name, $parentId, $accessToken)
    {
        $response = Http::withToken($accessToken)
            ->post('https://www.googleapis.com/drive/v3/files', [
                'name' => $name,
                'mimeType' => 'application/vnd.google-apps.folder',
                'parents' => $parentId ? [$parentId] : [],
            ]);

        return $response->json()['id'];
    }

    // ! Find Folder By Name
    private function findDriveFolder($name, $parentId, $accessToken)
    {
        $query = "name='{$name}' and mimeType='application/vnd.google-apps.folder' and trashed=false";

        if ($parentId) {
            $query .= " and '{$parentId}' in parents";
        }

        $response = Http::withToken($accessToken)
            ->get('https://www.googleapis.com/drive/v3/files', [
                'q' => $query,
                'fields' => 'files(id, name)',
            ]);

        return $response->json()['files'][0]['id'] ?? null;
    }

    // ! Upload To Drive
    private function uploadFileToDrive($filePath, $fileName, $parentId, $accessToken)
    {
        $response = Http::withToken($accessToken)
            ->attach(
                'metadata',
                json_encode([
                    'name' => $fileName,
                    'parents' => [$parentId],
                ]),
                'metadata.json'
            )
            ->attach(
                'file',
                fopen($filePath, 'r'),
                $fileName
            )
            ->post('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart');

        return $response->json();
    }

    public function view($id = '')
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $id = $decryptedValue;

        $view = DB::table('et_customer_services')
            ->where('et_customer_services.journal_check', 1)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
            ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer_services.sno',
                'et_customer_services.created_at',
                'et_customer_services.journal_index',
                'et_customer_services.proposal_id',
                'et_customer.sno as journal_customer_id',
                'et_customer_services.jc_id',
                'et_customer_services.jc_staff',
                'journal_staff.staff_name as journal_staff_name',
                'journal_coordinator.staff_name as jouranal_coordinator_name',
                'journal_staff.staff_image as journal_staff_image',
                'journal_coordinator.staff_image as jouranal_coordinator_image',
                DB::raw("CASE 
                WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                ELSE NULL
            END as service_name")
            )
            ->where('et_customer_services.journal_check', 1)
            ->where('et_customer_services.sno', $id)
            ->first();

        $journals = DB::table('et_manage_journal')
            // ->where('et_manage_journal.status', '!=', 2)
            ->where('et_manage_journal.service_id', $id)
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->select(
                'et_manage_journal.submitted_count',
                'et_manage_journal.submited_date',
                'et_manage_journal.reviewed_count',
                'et_manage_journal.resubmitted_count',
                'et_manage_journal.accepted_count',
                'et_manage_journal.reject_count',
                'et_manage_journal.published_count',
                'et_manage_journal.documents',
                'et_manage_journal.sno',
                'et_manage_journal.paper_name',
                'et_manage_journal.status',
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id'
            )
            ->get();

        // ================= STATUS COUNTS =================          

        // Assign with defaults (0 if status not found)
        $view->submittedCount      = $helper->get_submitted_count($view->sno, $view->journal_customer_id) ??
            0;
        $view->withEditorCount     =  $helper->get_with_editor_count(
            $view->sno,
            $view->journal_customer_id,
        ) ?? 0;
        $view->underReviewerCount  = $helper->get_under_reviewer_count(
            $view->sno,
            $view->journal_customer_id,
        ) ?? 0;
        $view->reviewedCount       = $helper->get_reviewed_count($view->sno, $view->journal_customer_id) ??
            0;
        $view->acceptedCount       = $helper->get_accepted_count($view->sno, $view->journal_customer_id) ??
            0;
        $view->rejectedCount       = $helper->get_rejected_count($view->sno, $view->journal_customer_id) ??
            0;
        $view->eproofingCount      = $helper->get_e_proofing_count($view->sno, $view->journal_customer_id) ??
            0;
        $view->publishedCount      =  $helper->get_published_count($view->sno, $view->journal_customer_id) ??
            0;

        // Domain Mapping
        foreach ($journals as $journal) {
            $domain_ids = json_decode($journal->domain_id, true);

            if (is_array($domain_ids) && !empty($domain_ids)) {
                $view->domain_names = DB::table('et_domain')
                    ->whereIn('sno', $domain_ids)
                    ->where('status', 0)
                    ->pluck('domain_name')
                    ->toArray();
            } else {
                $view->domain_names = [];
            }
        }

        if (! empty($view->journal_index)) {

            $decoded = json_decode($view->journal_index, true);

            // CASE 1: valid JSON array
            if (is_array($decoded)) {
                $index_ids = $decoded;
            }
            // CASE 2: single integer or numeric string
            elseif (is_numeric($view->journal_index)) {
                $index_ids = [(int) $view->journal_index];
            }
            // CASE 3: anything else → invalid
            else {
                $index_ids = [];
            }

            if (! empty($index_ids)) {
                $index_names = DB::table('et_journal_index')
                    ->whereIn('sno', $index_ids)
                    ->where('status', 0)
                    ->pluck('index_name')
                    ->toArray();

                $view->index_names = ! empty($index_names)
                    ? implode(', ', $index_names)
                    : 'No Index';
            } else {
                $view->index_names = 'No Index';
            }
        } else {
            $view->index_names = 'No Index';
        }

        $year = date('Y', strtotime($view->created_at));
        $id = str_pad($view->sno, 5, '0', STR_PAD_LEFT);
        $view->service_id = "SR-{$id}/{$year}";

        foreach ($journals as $journal) {
            $domainIds = json_decode($journal->domain_id, true);
            if (is_array($domainIds)) {
                $domains = DB::table('et_domain')->whereIn('sno', $domainIds)->pluck('domain_name')->toArray();
                $journal->domain_names = $domains;
            } else {
                $journal->domain_names = [];
            }

            $statusColors = [
                0 => [
                    'row' => '#CCE5FF',
                    'badge' => '#007BFF',
                    'text_color' => '#FFF',
                    'label' => 'Submitted',
                ],
                1 => [
                    'row' => '#d8d9c1 ',
                    'badge' => '#a8ab14',
                    'text_color' => '#000',
                    'label' => 'With Editor',
                ],
                2 => [
                    'row' => '#e2dddd ',
                    'badge' => '#c7c7c7',
                    'text_color' => '#000',
                    'label' => 'Closed',
                ],
                5 => [
                    'row' => '#abc9e9',
                    'badge' => '#DC3545',
                    'text_color' => '#FFF',
                    'label' => 'Accepted',
                ],
                3 => [
                    'row' => '#e7d4b2 ',
                    'badge' => '#800080',
                    'text_color' => '#FFF',
                    'label' => 'Under Reviewer',
                ],
                4 => [
                    'row' => '#9dd7c1',
                    'badge' => '#28A745',
                    'text_color' => '#FFF',
                    'label' => 'Revision',
                ],
                6 => [
                    'row' => '#dbc1c4 ',
                    'badge' => '#17A2B8',
                    'text_color' => '#FFF',
                    'label' => 'Rejected',
                ],
                7 => [
                    'row' => '#b893b9 ',
                    'badge' => '#17A2B8',
                    'text_color' => '#FFF',
                    'label' => 'E-Proofing',
                ],
                8 => [
                    'row' => '#6bd2e3  ',
                    'badge' => '#7239EA',
                    'text_color' => '#FFF',
                    'label' => 'Published ',
                ],
            ];

            $journal->statusHTML = $statusColors[$journal->status]['label'] ?? 'Unknown';
            $journal->background_color = $statusColors[$journal->status]['badge'] ?? '#6c757d';
            $journal->text_color = $statusColors[$journal->status]['text_color'] ?? '#6c757d';

            $submittedFiles = json_decode($journal->documents, true);
            $journal->submitted_files = is_array($submittedFiles) ? $submittedFiles : [];

            $journalStatus = DB::table('et_journal_history')
                ->where('et_journal_history.journal_id', $journal->sno)
                ->select('et_journal_history.*')
                ->orderBy('et_journal_history.created_at', 'DESC')
                ->get();

            $journal->journalStatus = $journalStatus;
        }
        $view->journals = $journals;

        // return $view;

        return view('content.journal_management.manage_journal.view', [
            'view' => $view,
            'id' => $decryptedValue,
        ]);
    }

    public function AssignDataFetch($id)
    {
        $fetch = DB::table('et_customer_services')
            ->where('et_customer_services.journal_check', 1)
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->select(
                'et_customer_services.sno',
                'et_customer_services.created_at',
                'et_customer.cus_name',
                'et_customer.customer_id as cus_id',
                'et_customer.sno as cus_sno',
                'et_customer.cus_mobile',
                'et_customer.cus_email_id',
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name')
            )
            ->where('et_customer_services.sno', $id)
            ->first();

        $year = date('Y', strtotime($fetch->created_at));
        $id = str_pad($fetch->sno, 5, '0', STR_PAD_LEFT);
        $fetch->service_id = "SR-{$id}/{$year}";

        $staff = StaffModel::select('et_staff.sno', 'et_staff.staff_name', 'et_staff.department_id as dept_id', 'et_job_position.job_position_name as position_name')->where('et_staff.status', 0)->where('et_staff.sno', '>', 1)->join('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $fetch,
            'staff' => $staff,
        ], 200);
    }

    public function AddJournalStaff(Request $request)
    {

        $serviceId = $request->assgn_service_id;
        $staffId = $request->assgn_staff_id;

        //  return DB::table('et_customer_services')->where('sno', $serviceId)->first();

        $AddStaff = DB::table('et_customer_services')->where('sno', $serviceId)->update(['jc_staff' => $staffId]);

        if ($AddStaff) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Staff Assigned Successfully!',
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Staff Assigned Failed!',
            ]);

            return redirect()->back();
        }
    }

    public function journalList(Request $request)
    {

        $books = JournalBookletModel::where('status', '!=', 2)->get();
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        $query = DB::table('et_customer_services')
            ->where('et_customer_services.status', 8)
            ->where('et_customer_services.journal_check', 1)
            ->where('et_customer_services.branch_id', $branch_id)
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_manage_journal', 'et_manage_journal.customer_services_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_journal_history', 'et_journal_history.customer_services_id', '=', 'et_manage_journal.sno')
            ->leftJoin('et_staff as js_id', 'js_id.sno', '=', 'et_customer_services.jc_staff')
            ->leftJoin('et_staff as jc_id', 'jc_id.sno', '=', 'et_customer_services.jc_id')
            ->select(
                'et_customer_services.*',
                'et_customer.cus_name',
                'et_customer.customer_id as cus_id',
                'et_manage_journal.sno as manage_sno',
                'et_manage_journal.submitted_count',
                'et_manage_journal.review_count',
                'et_manage_journal.resubmitted_count',
                'et_manage_journal.accepted_count',
                'et_manage_journal.rejected_count',
                'et_manage_journal.published_count',
                'js_id.staff_name as js_name',
                'jc_id.staff_name as jc_name',
                'js_id.staff_image as js_image',
                'jc_id.staff_image as jc_image',
                DB::raw('CASE
                WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                ELSE NULL
            END as service_name'),
                DB::raw('CASE
                WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                ELSE NULL
            END as category_name')
            );

        $fill_chk = $request->fill_chk ?? 0;
        $customer_fill = $request->customer_fill ?? '';
        $customer_id_fill = $request->customer_id_fill ?? '';
        $booklet_fill = $request->booklet_fill ?? '';
        $paper_fill = $request->paper_fill ?? '';

        if ($customer_fill) {
            $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%");
        }
        if ($customer_id_fill) {
            $query->where('et_customer.customer_id', 'LIKE', "%{$customer_id_fill}%");
        }
        if ($paper_fill) {
            $query->where('et_journal_history.paper_name', 'LIKE', "%{$paper_fill}%");
        }
        if ($booklet_fill) {
            $query->where('et_journal_history.journal_booklet_id', $booklet_fill);
        }

        $fetch = $query->orderBy('et_customer_services.sno', 'desc')->paginate($perpage);

        $pageConfigs = ['myLayout' => 'default'];
        if ($fill_chk == 1) {
            $fill = true;
        } else {
            $fill = false;
        }

        return view('content.journal_management.journal_list', compact('fetch', 'books', 'perpage', 'customer_fill', 'paper_fill', 'booklet_fill', 'customer_id_fill', 'pageConfigs'))->with('filter_on', $fill);
    }

    public function getJournalBookletData()
    {
        $data = JournalBookletModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data,
        ], 200);
    }

    public function getJournalReviewData($id)
    {
        $data = DB::table('et_manage_journal')
            ->where('et_manage_journal.sno', $id)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name'),
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                    ELSE NULL
                END as category_name'),
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id'
            )
            ->first();

        $domain_id = json_decode($data->domain_id);

        if (is_array($domain_id) && ! empty($domain_id)) {
            $domain_names = DB::table('et_domain')
                ->whereIn('et_domain.sno', $domain_id)
                ->where('et_domain.status', 0)
                ->pluck('domain_name')
                ->toArray();

            $data->domain_names = $domain_names;
        } else {
            $data->domain_names = [];
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data,
        ], 200);
    }

    public function journalReviewStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $reviewedDate = $request->reviewed_date
            ? date('Y-m-d', strtotime($request->reviewed_date))
            : now();

        try {

            DB::beginTransaction();

            $review = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_manage_journal.*',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff'
                )
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (! $review) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found',
                ], 404);
            }

            $comment = $request->reviewer_comment;

            DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update([
                    'status' => 4,
                    'reviewed_count' => DB::raw('IFNULL(reviewed_count, 0) + 1'),
                    'reviewed_at' => $reviewedDate,
                    'updated_by' => $user_id,
                ]);

            $driveDetails = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $id)
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_customer.customer_id',
                    'et_customer_services.created_at',
                    'et_customer_services.sno',
                    'et_manage_journal.journal_id',
                    'et_manage_journal.status',
                )
                ->first();

            $year = date('Y', strtotime($driveDetails->created_at));
            $id = str_pad($driveDetails->sno, 5, '0', STR_PAD_LEFT);
            $driveDetails->service_id = "SR-{$id}/{$year}";

            if ($request->filled('reviewed_files')) {
                $accessToken = $this->token();
                $files = json_decode($request->reviewed_files, true);

                $rootFolderId = config('services.google_drive.folder_id');

                // ! Customer Folder
                $customerFolderName = $driveDetails->customer_id;
                $customerFolderId = $this->findDriveFolder($customerFolderName, $rootFolderId, $accessToken)
                    ?? $this->createDriveFolder($customerFolderName, $rootFolderId, $accessToken);

                // ! Service Folder
                $serviceFolderName = $driveDetails->service_id;
                $serviceFolderId = $this->findDriveFolder($serviceFolderName, $customerFolderId, $accessToken)
                    ?? $this->createDriveFolder($serviceFolderName, $customerFolderId, $accessToken);

                // ! Journal Folder
                $journalFolderName = $driveDetails->journal_id;
                $journalFolderId = $this->findDriveFolder($journalFolderName, $serviceFolderId, $accessToken)
                    ?? $this->createDriveFolder($journalFolderName, $serviceFolderId, $accessToken);

                // ! Status Folder
                $status = $driveDetails->status == 4 ? 'Revision' : 'Not Defined';
                $statusFolderName = "Status_{$status}";
                $statusFolderId = $this->createDriveFolder($statusFolderName, $journalFolderId, $accessToken);

                $driveDocuments = [];

                foreach ($files as $file) {

                    $localPath = public_path($file['path']);

                    if (! file_exists($localPath)) {
                        continue;
                    }

                    $driveFile = $this->uploadFileToDrive(
                        $localPath,
                        $file['original_name'],
                        $statusFolderId,
                        $accessToken
                    );

                    if ($driveDetails->status == 4) {
                        $this->makeFilePublic($statusFolderId, $accessToken);
                        $folderLink = "https://drive.google.com/drive/folders/{$statusFolderId}";
                    }

                    $driveDocuments[] = [
                        'original_name' => $file['original_name'],
                        'drive_file_id' => $driveFile['id'] ?? null,
                        'status' => 'Revision',
                        'folderLink' => $folderLink,
                    ];

                    unlink($localPath);
                }

                // Cleanup user temp folder
                File::deleteDirectory(public_path("{$user_id}/temp"));
            }

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $review->customer_id;
            $history->service_id = $review->service_id;
            $history->journal_id = $review->sno;
            $history->reviewed_date = $reviewedDate;
            $history->reviewer_comment = $comment;
            $history->reviewer_document = ! empty($files) ? json_encode($driveDocuments) : null;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 4;
            $history->save();

            // Customer app notification
            $sts_text = 'Revision';
            $branch_id = $request->user()->branch_id;
            DB::table('et_notification_customer_app')->insert([
                'branch_id' => $branch_id,
                'notification_type_id' => 3,
                'notification_type' => 'Journal',
                'header' => $review->paper_name,
                'message' => 'Journal Status Updated',
                'notification_date' => now(),
                'meesage_for' => 'Journal Revision',
                'message_date' => $history->reviewed_date,
                'who' => $user_id,
                'whom' => $review->customer_id,
                'process_id' => $history->sno,
                'status_text' => $sts_text,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);

            if ($history) {
                DB::table('et_journal_revision')->insert([
                    'journal_id' => $review->sno,
                    'service_id' => $review->service_id,
                    'customer_id' => $review->customer_id,
                    'jc_id' => $review->jc_staff,
                    'jtl_id' => $review->jc_id ?? 0,
                    'journal_status' => 4,
                    'documents' => ! empty($files) ? json_encode($driveDocuments) : null,
                    'comments' => $comment,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Review submitted successfully!',
                'data' => null,
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function journalWithEditorStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $withEditorDate = $request->with_editor_date
            ? date('Y-m-d', strtotime($request->with_editor_date))
            : now();

        try {

            DB::beginTransaction();

            $review = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_manage_journal.*',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff'
                )
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (! $review) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found',
                ], 404);
            }

            $comment = $request->with_editor_comment;

            DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update([
                    'status' => 1,
                    'with_editor_count' => DB::raw('IFNULL(with_editor_count, 0) + 1'),
                    'updated_by' => $user_id,
                ]);

            $driveDetails = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $id)
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_customer.customer_id',
                    'et_customer_services.created_at',
                    'et_customer_services.sno',
                    'et_manage_journal.journal_id',
                    'et_manage_journal.status',
                )
                ->first();

            $year = date('Y', strtotime($driveDetails->created_at));
            $id = str_pad($driveDetails->sno, 5, '0', STR_PAD_LEFT);
            $driveDetails->service_id = "SR-{$id}/{$year}";

            if ($request->filled('with_editor_files')) {
                $accessToken = $this->token();
                $files = json_decode($request->with_editor_files, true);

                $rootFolderId = config('services.google_drive.folder_id');

                // ! Customer Folder
                $customerFolderName = $driveDetails->customer_id;
                $customerFolderId = $this->findDriveFolder($customerFolderName, $rootFolderId, $accessToken)
                    ?? $this->createDriveFolder($customerFolderName, $rootFolderId, $accessToken);

                // ! Service Folder
                $serviceFolderName = $driveDetails->service_id;
                $serviceFolderId = $this->findDriveFolder($serviceFolderName, $customerFolderId, $accessToken)
                    ?? $this->createDriveFolder($serviceFolderName, $customerFolderId, $accessToken);

                // ! Journal Folder
                $journalFolderName = $driveDetails->journal_id;
                $journalFolderId = $this->findDriveFolder($journalFolderName, $serviceFolderId, $accessToken)
                    ?? $this->createDriveFolder($journalFolderName, $serviceFolderId, $accessToken);

                // ! Status Folder
                $status = $driveDetails->status == 1 ? 'With Editor' : 'Not Defined';
                $statusFolderName = "Status_{$status}";
                $statusFolderId = $this->findDriveFolder($statusFolderName, $journalFolderId, $accessToken)
                    ?? $this->createDriveFolder($statusFolderName, $journalFolderId, $accessToken);

                $driveDocuments = [];

                foreach ($files as $file) {

                    $localPath = public_path($file['path']);

                    if (! file_exists($localPath)) {
                        continue;
                    }

                    $driveFile = $this->uploadFileToDrive(
                        $localPath,
                        $file['original_name'],
                        $statusFolderId,
                        $accessToken
                    );

                    if ($driveDetails->status == 1) {
                        $this->makeFilePublic($statusFolderId, $accessToken);
                        $folderLink = "https://drive.google.com/drive/folders/{$statusFolderId}";
                    }

                    $driveDocuments[] = [
                        'original_name' => $file['original_name'],
                        'drive_file_id' => $driveFile['id'] ?? null,
                        'status' => 'With Editor',
                        'folderLink' => $folderLink,
                    ];

                    unlink($localPath);
                }

                // Cleanup user temp folder
                File::deleteDirectory(public_path("{$user_id}/temp"));
            }

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $review->customer_id;
            $history->service_id = $review->service_id;
            $history->journal_id = $review->sno;
            $history->with_editor_date = $withEditorDate;
            $history->with_editor_comment = $comment;
            $history->with_editor_documents = ! empty($files) ? json_encode($driveDocuments) : null;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 1;
            $history->save();

            if ($history) {
                DB::table('et_journal_revision')->insert([
                    'journal_id' => $review->sno,
                    'service_id' => $review->service_id,
                    'customer_id' => $review->customer_id,
                    'jc_id' => $review->jc_staff,
                    'jtl_id' => $review->jc_id ?? 0,
                    'journal_status' => 1,
                    'documents' => ! empty($files) ? json_encode($driveDocuments) : null,
                    'comments' => $comment,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);

                // Customer app notification
                $sts_text = 'With Editor';
                $branch_id = $request->user()->branch_id;
                DB::table('et_notification_customer_app')->insert([
                    'branch_id' => $branch_id,
                    'notification_type_id' => 3,
                    'notification_type' => 'Journal',
                    'header' => $review->paper_name,
                    'message' => 'Journal Status Updated',
                    'notification_date' => now(),
                    'meesage_for' => 'Journal With Editor',
                    'message_date' => $history->with_editor_date,
                    'who' => $user_id,
                    'whom' => $review->customer_id,
                    'process_id' => $history->sno,
                    'status_text' => $sts_text,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Review submitted successfully!',
                'data' => null,
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function journalUnderReviewerStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $under_reviewer_date = $request->under_reviewer_date
            ? date('Y-m-d', strtotime($request->under_reviewer_date))
            : now();

        try {

            DB::beginTransaction();

            $review = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_manage_journal.*',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff'
                )
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (! $review) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found',
                ], 404);
            }

            $comment = $request->under_reviewer_comment;

            DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update([
                    'status' => 3,
                    'under_reviewer_count' => DB::raw('IFNULL(under_reviewer_count, 0) + 1'),
                    'updated_by' => $user_id,
                ]);

            $driveDetails = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $id)
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_customer.customer_id',
                    'et_customer_services.created_at',
                    'et_customer_services.sno',
                    'et_manage_journal.journal_id',
                    'et_manage_journal.status',
                )
                ->first();

            $year = date('Y', strtotime($driveDetails->created_at));
            $id = str_pad($driveDetails->sno, 5, '0', STR_PAD_LEFT);
            $driveDetails->service_id = "SR-{$id}/{$year}";

            if ($request->filled('under_reviewer_files')) {
                $accessToken = $this->token();
                $files = json_decode($request->under_reviewer_files, true);

                $rootFolderId = config('services.google_drive.folder_id');

                // ! Customer Folder
                $customerFolderName = $driveDetails->customer_id;
                $customerFolderId = $this->findDriveFolder($customerFolderName, $rootFolderId, $accessToken)
                    ?? $this->createDriveFolder($customerFolderName, $rootFolderId, $accessToken);

                // ! Service Folder
                $serviceFolderName = $driveDetails->service_id;
                $serviceFolderId = $this->findDriveFolder($serviceFolderName, $customerFolderId, $accessToken)
                    ?? $this->createDriveFolder($serviceFolderName, $customerFolderId, $accessToken);

                // ! Journal Folder
                $journalFolderName = $driveDetails->journal_id;
                $journalFolderId = $this->findDriveFolder($journalFolderName, $serviceFolderId, $accessToken)
                    ?? $this->createDriveFolder($journalFolderName, $serviceFolderId, $accessToken);

                // ! Status Folder
                $status = $driveDetails->status == 3 ? 'Under Reviewer' : 'Not Defined';
                $statusFolderName = "Status_{$status}";
                $statusFolderId = $this->findDriveFolder($statusFolderName, $journalFolderId, $accessToken)
                    ?? $this->createDriveFolder($statusFolderName, $journalFolderId, $accessToken);

                $driveDocuments = [];

                foreach ($files as $file) {

                    $localPath = public_path($file['path']);

                    if (! file_exists($localPath)) {
                        continue;
                    }

                    $driveFile = $this->uploadFileToDrive(
                        $localPath,
                        $file['original_name'],
                        $statusFolderId,
                        $accessToken
                    );

                    if ($driveDetails->status == 3) {
                        $this->makeFilePublic($statusFolderId, $accessToken);
                        $folderLink = "https://drive.google.com/drive/folders/{$statusFolderId}";
                    }

                    $driveDocuments[] = [
                        'original_name' => $file['original_name'],
                        'drive_file_id' => $driveFile['id'] ?? null,
                        'status' => 'Under Reviewer',
                        'folderLink' => $folderLink,
                    ];

                    unlink($localPath);
                }

                // Cleanup user temp folder
                File::deleteDirectory(public_path("{$user_id}/temp"));
            }

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $review->customer_id;
            $history->service_id = $review->service_id;
            $history->journal_id = $review->sno;
            $history->under_reviewer_date = $under_reviewer_date;
            $history->under_reviewer_comment = $comment;
            $history->under_reviewer_documents = ! empty($files) ? json_encode($driveDocuments) : null;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 3;
            $history->save();

            // Customer app notification
            $sts_text = 'Under Review';
            $branch_id = $request->user()->branch_id;
            DB::table('et_notification_customer_app')->insert([
                'branch_id' => $branch_id,
                'notification_type_id' => 3,
                'notification_type' => 'Journal',
                'header' => $review->paper_name,
                'message' => 'Journal Status Updated',
                'notification_date' => now(),
                'meesage_for' => 'Journal Under Review',
                'message_date' => $history->under_reviewer_date,
                'who' => $user_id,
                'whom' => $review->customer_id,
                'process_id' => $history->sno,
                'status_text' => $sts_text,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
            if ($history) {
                DB::table('et_journal_revision')->insert([
                    'journal_id' => $review->sno,
                    'service_id' => $review->service_id,
                    'customer_id' => $review->customer_id,
                    'jc_id' => $review->jc_staff,
                    'jtl_id' => $review->jc_id ?? 0,
                    'journal_status' => 3,
                    'documents' => ! empty($files) ? json_encode($driveDocuments) : null,
                    'comments' => $comment,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Under Reviewer Status submitted successfully!',
                'data' => null,
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function getJournalResubmitData($id)
    {
        $data = DB::table('et_manage_journal')
            ->where('et_manage_journal.sno', $id)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name'),
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                    ELSE NULL
                END as category_name'),
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id'
            )
            ->first();

        $domain_id = json_decode($data->domain_id);

        if (is_array($domain_id) && ! empty($domain_id)) {
            $domain_names = DB::table('et_domain')
                ->whereIn('et_domain.sno', $domain_id)
                ->where('et_domain.status', 0)
                ->pluck('domain_name')
                ->toArray();

            $data->domain_names = $domain_names;
        } else {
            $data->domain_names = [];
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data,
        ], 200);
    }

    public function journalResubmitStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $resubmittedDate = $request->resubmitted_date
            ? date('Y-m-d', strtotime($request->resubmitted_date))
            : now();

        try {
            DB::beginTransaction();

            $resubmit = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (! $resubmit) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found',
                ], 404);
            }

            $updateData = [
                'resubmitted_at' => $resubmittedDate,
                'status' => 3,
                'resubmitted_count' => DB::raw('resubmitted_count + 1'),
            ];

            DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update($updateData);

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $resubmit->customer_id;
            $history->service_id = $resubmit->service_id;
            $history->journal_id = $resubmit->sno;
            $history->resubmitted_date = $resubmittedDate;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 3;
            $history->save();

            // Customer app notification
            $sts_text = 'Resubmitted';
            $branch_id = $request->user()->branch_id;
            DB::table('et_notification_customer_app')->insert([
                'branch_id' => $branch_id,
                'notification_type_id' => 3,
                'notification_type' => 'Journal',
                'header' => $resubmit->paper_name,
                'message' => 'Journal Status Updated',
                'notification_date' => now(),
                'meesage_for' => 'Journal Resubmitted',
                'message_date' => $history->resubmitted_date,
                'who' => $user_id,
                'whom' => $resubmit->customer_id,
                'process_id' => $history->sno,
                'status_text' => $sts_text,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Journal resubmitted successfully!',
                'data' => $updateData,
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function getJournalAcceptData($id)
    {
        $data = DB::table('et_manage_journal')
            ->where('et_manage_journal.sno', $id)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name'),
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                    ELSE NULL
                END as category_name'),
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id'
            )
            ->first();

        $domain_id = json_decode($data->domain_id);

        if (is_array($domain_id) && ! empty($domain_id)) {
            $domain_names = DB::table('et_domain')
                ->whereIn('et_domain.sno', $domain_id)
                ->where('et_domain.status', 0)
                ->pluck('domain_name')
                ->toArray();

            $data->domain_names = $domain_names;
        } else {
            $data->domain_names = [];
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data,
        ], 200);
    }

    public function journalAcceptStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $accepted_date = $request->accepted_date
            ? date('Y-m-d', strtotime($request->accepted_date))
            : now();

        try {

            DB::beginTransaction();

            $review = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_manage_journal.*',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff'
                )
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (! $review) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found',
                ], 404);
            }

            $comment = $request->accepted_comment;

            DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update([
                    'status' => 5,
                    'accepted_count' => DB::raw('IFNULL(accepted_count, 0) + 1'),
                    'updated_by' => $user_id,
                ]);

            $driveDetails = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $id)
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_customer.customer_id',
                    'et_customer_services.created_at',
                    'et_customer_services.sno',
                    'et_manage_journal.journal_id',
                    'et_manage_journal.status',
                )
                ->first();

            $year = date('Y', strtotime($driveDetails->created_at));
            $id = str_pad($driveDetails->sno, 5, '0', STR_PAD_LEFT);
            $driveDetails->service_id = "SR-{$id}/{$year}";

            if ($request->filled('accepted_files')) {
                $accessToken = $this->token();
                $files = json_decode($request->accepted_files, true);

                $rootFolderId = config('services.google_drive.folder_id');

                // ! Customer Folder
                $customerFolderName = $driveDetails->customer_id;
                $customerFolderId = $this->findDriveFolder($customerFolderName, $rootFolderId, $accessToken)
                    ?? $this->createDriveFolder($customerFolderName, $rootFolderId, $accessToken);

                // ! Service Folder
                $serviceFolderName = $driveDetails->service_id;
                $serviceFolderId = $this->findDriveFolder($serviceFolderName, $customerFolderId, $accessToken)
                    ?? $this->createDriveFolder($serviceFolderName, $customerFolderId, $accessToken);

                // ! Journal Folder
                $journalFolderName = $driveDetails->journal_id;
                $journalFolderId = $this->findDriveFolder($journalFolderName, $serviceFolderId, $accessToken)
                    ?? $this->createDriveFolder($journalFolderName, $serviceFolderId, $accessToken);

                // ! Status Folder
                $status = $driveDetails->status == 5 ? 'Accepted' : 'Not Defined';
                $statusFolderName = "Status_{$status}";
                $statusFolderId = $this->findDriveFolder($statusFolderName, $journalFolderId, $accessToken)
                    ?? $this->createDriveFolder($statusFolderName, $journalFolderId, $accessToken);

                $driveDocuments = [];

                foreach ($files as $file) {

                    $localPath = public_path($file['path']);

                    if (! file_exists($localPath)) {
                        continue;
                    }

                    $driveFile = $this->uploadFileToDrive(
                        $localPath,
                        $file['original_name'],
                        $statusFolderId,
                        $accessToken
                    );

                    if ($driveDetails->status == 5) {
                        $this->makeFilePublic($statusFolderId, $accessToken);
                        $folderLink = "https://drive.google.com/drive/folders/{$statusFolderId}";
                    }

                    $driveDocuments[] = [
                        'original_name' => $file['original_name'],
                        'drive_file_id' => $driveFile['id'] ?? null,
                        'status' => 'Accepted',
                        'folderLink' => $folderLink,
                    ];

                    unlink($localPath);
                }

                // Cleanup user temp folder
                File::deleteDirectory(public_path("{$user_id}/temp"));
            }

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $review->customer_id;
            $history->service_id = $review->service_id;
            $history->journal_id = $review->sno;
            $history->accepted_date = $accepted_date;
            $history->accepted_comment = $comment;
            $history->accepted_document = ! empty($files) ? json_encode($driveDocuments) : null;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 5;
            $history->save();

            // Customer app notification
            $sts_text = 'Accepted';
            $branch_id = $request->user()->branch_id;
            DB::table('et_notification_customer_app')->insert([
                'branch_id' => $branch_id,
                'notification_type_id' => 3,
                'notification_type' => 'Journal',
                'header' => $review->paper_name,
                'message' => 'Journal Status Updated',
                'notification_date' => now(),
                'meesage_for' => 'Journal Accepted',
                'message_date' => $history->accepted_date,
                'who' => $user_id,
                'whom' => $review->customer_id,
                'process_id' => $history->sno,
                'status_text' => $sts_text,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);

            if ($history) {
                DB::table('et_journal_revision')->insert([
                    'journal_id' => $review->sno,
                    'service_id' => $review->service_id,
                    'customer_id' => $review->customer_id,
                    'jc_id' => $review->jc_staff,
                    'jtl_id' => $review->jc_id ?? 0,
                    'journal_status' => 5,
                    'documents' => ! empty($files) ? json_encode($driveDocuments) : null,
                    'comments' => $comment,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Journal resubmitted successfully!',
                'data' => null,
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function getJournalRejectData($id)
    {
        $data = DB::table('et_manage_journal')
            ->where('et_manage_journal.sno', $id)
            ->where('et_manage_journal.status', '!=', 2)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name'),
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                    ELSE NULL
                END as category_name'),
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id'
            )
            ->first();

        $domain_id = json_decode($data->domain_id);

        if (is_array($domain_id) && ! empty($domain_id)) {
            $domain_names = DB::table('et_domain')
                ->whereIn('et_domain.sno', $domain_id)
                ->where('et_domain.status', 0)
                ->pluck('domain_name')
                ->toArray();

            $data->domain_names = $domain_names;
        } else {
            $data->domain_names = [];
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data,
        ], 200);
    }

    public function journalRejectStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $rejectedDate = $request->rejected_date
            ? date('Y-m-d', strtotime($request->rejected_date))
            : now();

        try {

            DB::beginTransaction();

            $review = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_manage_journal.*',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff'
                )
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (! $review) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found',
                ], 404);
            }

            $comment = $request->reject_reason;

            DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update([
                    'status' => 6,
                    'reject_count' => DB::raw('IFNULL(reject_count, 0) + 1'),
                    'updated_by' => $user_id,
                ]);

            $driveDetails = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $id)
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_customer.customer_id',
                    'et_customer_services.created_at',
                    'et_customer_services.sno',
                    'et_manage_journal.journal_id',
                    'et_manage_journal.status',
                )
                ->first();

            $year = date('Y', strtotime($driveDetails->created_at));
            $id = str_pad($driveDetails->sno, 5, '0', STR_PAD_LEFT);
            $driveDetails->service_id = "SR-{$id}/{$year}";

            if ($request->filled('rejected_files')) {
                $accessToken = $this->token();
                $files = json_decode($request->rejected_files, true);

                $rootFolderId = config('services.google_drive.folder_id');

                // ! Customer Folder
                $customerFolderName = $driveDetails->customer_id;
                $customerFolderId = $this->findDriveFolder($customerFolderName, $rootFolderId, $accessToken)
                    ?? $this->createDriveFolder($customerFolderName, $rootFolderId, $accessToken);

                // ! Service Folder
                $serviceFolderName = $driveDetails->service_id;
                $serviceFolderId = $this->findDriveFolder($serviceFolderName, $customerFolderId, $accessToken)
                    ?? $this->createDriveFolder($serviceFolderName, $customerFolderId, $accessToken);

                // ! Journal Folder
                $journalFolderName = $driveDetails->journal_id;
                $journalFolderId = $this->findDriveFolder($journalFolderName, $serviceFolderId, $accessToken)
                    ?? $this->createDriveFolder($journalFolderName, $serviceFolderId, $accessToken);

                // ! Status Folder
                $status = $driveDetails->status == 6 ? 'Rejected' : 'Not Defined';
                $statusFolderName = "Status_{$status}";
                $statusFolderId = $this->findDriveFolder($statusFolderName, $journalFolderId, $accessToken)
                    ?? $this->createDriveFolder($statusFolderName, $journalFolderId, $accessToken);

                $driveDocuments = [];

                foreach ($files as $file) {

                    $localPath = public_path($file['path']);

                    if (! file_exists($localPath)) {
                        continue;
                    }

                    $driveFile = $this->uploadFileToDrive(
                        $localPath,
                        $file['original_name'],
                        $statusFolderId,
                        $accessToken
                    );

                    if ($driveDetails->status == 6) {
                        $this->makeFilePublic($statusFolderId, $accessToken);
                        $folderLink = "https://drive.google.com/drive/folders/{$statusFolderId}";
                    }

                    $driveDocuments[] = [
                        'original_name' => $file['original_name'],
                        'drive_file_id' => $driveFile['id'] ?? null,
                        'status' => 'E-Proofing',
                        'folderLink' => $folderLink,
                    ];

                    unlink($localPath);
                }

                // Cleanup user temp folder
                File::deleteDirectory(public_path("{$user_id}/temp"));
            }

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $review->customer_id;
            $history->service_id = $review->service_id;
            $history->journal_id = $review->sno;
            $history->accepted_date = $rejectedDate;
            $history->accepted_comment = $comment;
            $history->accepted_document = ! empty($files) ? json_encode($driveDocuments) : null;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 6;
            $history->save();

            // Customer app notification
            $sts_text = 'Rejected';
            $branch_id = $request->user()->branch_id;
            DB::table('et_notification_customer_app')->insert([
                'branch_id' => $branch_id,
                'notification_type_id' => 3,
                'notification_type' => 'Journal',
                'header' => $review->paper_name,
                'message' => 'Journal Status Updated',
                'notification_date' => now(),
                'meesage_for' => 'Journal Rejected',
                'message_date' => $history->accepted_date,
                'who' => $user_id,
                'whom' => $review->customer_id,
                'process_id' => $history->sno,
                'status_text' => $sts_text,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);

            if ($history) {
                DB::table('et_journal_revision')->insert([
                    'journal_id' => $review->sno,
                    'service_id' => $review->service_id,
                    'customer_id' => $review->customer_id,
                    'jc_id' => $review->jc_staff,
                    'jtl_id' => $review->jc_id ?? 0,
                    'journal_status' => 6,
                    'documents' => ! empty($files) ? json_encode($driveDocuments) : null,
                    'comments' => $comment,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Journal resubmitted successfully!',
                'data' => null,
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function journalEProofingStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $e_proofing_date = $request->e_proofing_date
            ? date('Y-m-d', strtotime($request->e_proofing_date))
            : now();

        try {

            DB::beginTransaction();

            $review = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_manage_journal.*',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff'
                )
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (! $review) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found',
                ], 404);
            }

            $comment = $request->reject_reason;

            DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update([
                    'status' => 7,
                    'e_proofing_count' => DB::raw('IFNULL(e_proofing_count, 0) + 1'),
                    'updated_by' => $user_id,
                ]);

            $driveDetails = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $id)
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_customer.customer_id',
                    'et_customer_services.created_at',
                    'et_customer_services.sno',
                    'et_manage_journal.journal_id',
                    'et_manage_journal.status',
                )
                ->first();

            $year = date('Y', strtotime($driveDetails->created_at));
            $id = str_pad($driveDetails->sno, 5, '0', STR_PAD_LEFT);
            $driveDetails->service_id = "SR-{$id}/{$year}";

            if ($request->filled('e_proofing_files')) {
                $accessToken = $this->token();
                $files = json_decode($request->e_proofing_files, true);

                $rootFolderId = config('services.google_drive.folder_id');

                // ! Customer Folder
                $customerFolderName = $driveDetails->customer_id;
                $customerFolderId = $this->findDriveFolder($customerFolderName, $rootFolderId, $accessToken)
                    ?? $this->createDriveFolder($customerFolderName, $rootFolderId, $accessToken);

                // ! Service Folder
                $serviceFolderName = $driveDetails->service_id;
                $serviceFolderId = $this->findDriveFolder($serviceFolderName, $customerFolderId, $accessToken)
                    ?? $this->createDriveFolder($serviceFolderName, $customerFolderId, $accessToken);

                // ! Journal Folder
                $journalFolderName = $driveDetails->journal_id;
                $journalFolderId = $this->findDriveFolder($journalFolderName, $serviceFolderId, $accessToken)
                    ?? $this->createDriveFolder($journalFolderName, $serviceFolderId, $accessToken);

                // ! Status Folder
                $status = $driveDetails->status == 7 ? 'E-Proofing' : 'Not Defined';
                $statusFolderName = "Status_{$status}";
                $statusFolderId = $this->findDriveFolder($statusFolderName, $journalFolderId, $accessToken)
                    ?? $this->createDriveFolder($statusFolderName, $journalFolderId, $accessToken);

                $driveDocuments = [];

                foreach ($files as $file) {

                    $localPath = public_path($file['path']);

                    if (! file_exists($localPath)) {
                        continue;
                    }

                    $driveFile = $this->uploadFileToDrive(
                        $localPath,
                        $file['original_name'],
                        $statusFolderId,
                        $accessToken
                    );

                    if ($driveDetails->status == 7) {
                        $this->makeFilePublic($statusFolderId, $accessToken);
                        $folderLink = "https://drive.google.com/drive/folders/{$statusFolderId}";
                    }

                    $driveDocuments[] = [
                        'original_name' => $file['original_name'],
                        'drive_file_id' => $driveFile['id'] ?? null,
                        'status' => 'E-Proofing',
                        'folderLink' => $folderLink,
                    ];

                    unlink($localPath);
                }

                // Cleanup user temp folder
                File::deleteDirectory(public_path("{$user_id}/temp"));
            }

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $review->customer_id;
            $history->service_id = $review->service_id;
            $history->journal_id = $review->sno;
            $history->e_proofing_date = $e_proofing_date;
            $history->e_proofing_comments = $comment;
            $history->e_proofing_documents = ! empty($files) ? json_encode($driveDocuments) : null;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 7;
            $history->save();

            // Customer app notification
            $sts_text = 'E-Proofing';
            $branch_id = $request->user()->branch_id;
            DB::table('et_notification_customer_app')->insert([
                'branch_id' => $branch_id,
                'notification_type_id' => 3,
                'notification_type' => 'Journal',
                'header' => $review->paper_name,
                'message' => 'Journal Status Updated',
                'notification_date' => now(),
                'meesage_for' => 'Journal E-Proofing',
                'message_date' => $history->e_proofing_date,
                'who' => $user_id,
                'whom' => $review->customer_id,
                'process_id' => $history->sno,
                'status_text' => $sts_text,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);

            if ($history) {
                DB::table('et_journal_revision')->insert([
                    'journal_id' => $review->sno,
                    'service_id' => $review->service_id,
                    'customer_id' => $review->customer_id,
                    'jc_id' => $review->jc_staff,
                    'jtl_id' => $review->jc_id ?? 0,
                    'journal_status' => 7,
                    'documents' => ! empty($files) ? json_encode($driveDocuments) : null,
                    'comments' => $comment,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Journal resubmitted successfully!',
                'data' => null,
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit review',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function getJournalPublishData($id)
    {
        $data = DB::table('et_manage_journal')
            ->where('et_manage_journal.sno', $id)
            ->where('et_manage_journal.status', '!=', 2)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as service_name'),
                DB::raw('CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                    ELSE NULL
                END as category_name'),
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id'
            )
            ->first();

        $domain_id = json_decode($data->domain_id);

        if (is_array($domain_id) && ! empty($domain_id)) {
            $domain_names = DB::table('et_domain')
                ->whereIn('et_domain.sno', $domain_id)
                ->where('et_domain.status', 0)
                ->pluck('domain_name')
                ->toArray();

            $data->domain_names = $domain_names;
        } else {
            $data->domain_names = [];
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully',
            'error_msg' => 'Data Fetched Failed',
            'data' => $data,
        ], 200);
    }

    public function journalPublishStatus($id, Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;

        try {

            DB::beginTransaction();

            $publish = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $id)
                ->where('et_manage_journal.status', '!=', 2)
                ->first();

            if (! $publish) {
                return response([
                    'status' => 404,
                    'message' => 'Record not found',
                    'error_msg' => 'Record not found',
                ], 404);
            }

            $publish_date = date('Y-m-d', strtotime($request->publish_date));
            $paper_name = $request->paper_name;
            $publish_url = $request->publish_url;
            $publish_author = $request->publish_author;

            $updateData = [
                'publish_date' => $publish_date,
                'published_paper_name' => $paper_name,
                'publish_url' => $publish_url,
                'publish_author' => $publish_author,
                'published_at' => now(),
                'status' => 8,
                'published_count' => DB::raw('published_count + 1'),
            ];

            DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update($updateData);

            $driveDetails = DB::table('et_manage_journal')
                ->where('et_manage_journal.sno', $id)
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->select(
                    'et_customer.customer_id',
                    'et_customer_services.created_at',
                    'et_customer_services.sno',
                    'et_manage_journal.journal_id',
                    'et_manage_journal.status',
                )
                ->first();

            $year = date('Y', strtotime($driveDetails->created_at));
            $id = str_pad($driveDetails->sno, 5, '0', STR_PAD_LEFT);
            $driveDetails->service_id = "SR-{$id}/{$year}";

            if ($request->filled('published_files')) {
                $accessToken = $this->token();
                $files = json_decode($request->published_files, true);

                $rootFolderId = config('services.google_drive.folder_id');

                // ! Customer Folder
                $customerFolderName = $driveDetails->customer_id;
                $customerFolderId = $this->findDriveFolder($customerFolderName, $rootFolderId, $accessToken)
                    ?? $this->createDriveFolder($customerFolderName, $rootFolderId, $accessToken);

                // ! Service Folder
                $serviceFolderName = $driveDetails->service_id;
                $serviceFolderId = $this->findDriveFolder($serviceFolderName, $customerFolderId, $accessToken)
                    ?? $this->createDriveFolder($serviceFolderName, $customerFolderId, $accessToken);

                // ! Journal Folder
                $journalFolderName = $driveDetails->journal_id;
                $journalFolderId = $this->findDriveFolder($journalFolderName, $serviceFolderId, $accessToken)
                    ?? $this->createDriveFolder($journalFolderName, $serviceFolderId, $accessToken);

                // ! Status Folder
                $status = $driveDetails->status == 8 ? 'Published' : 'Not Defined';
                $statusFolderName = "Status_{$status}";
                $statusFolderId = $this->findDriveFolder($statusFolderName, $journalFolderId, $accessToken)
                    ?? $this->createDriveFolder($statusFolderName, $journalFolderId, $accessToken);

                $driveDocuments = [];

                foreach ($files as $file) {

                    $localPath = public_path($file['path']);

                    if (! file_exists($localPath)) {
                        continue;
                    }

                    $driveFile = $this->uploadFileToDrive(
                        $localPath,
                        $file['original_name'],
                        $statusFolderId,
                        $accessToken
                    );

                    if ($driveDetails->status == 8) {
                        $this->makeFilePublic($statusFolderId, $accessToken);
                        $folderLink = "https://drive.google.com/drive/folders/{$statusFolderId}";
                    }

                    $driveDocuments[] = [
                        'original_name' => $file['original_name'],
                        'drive_file_id' => $driveFile['id'] ?? null,
                        'status' => 'E-Proofing',
                        'folderLink' => $folderLink,
                    ];

                    unlink($localPath);
                }

                // Cleanup user temp folder
                File::deleteDirectory(public_path("{$user_id}/temp"));
            }

            $history = new JournalHistoryModel();
            $history->branch_id = $branch_id;
            $history->customer_id = $publish->customer_id;
            $history->service_id = $publish->service_id;
            $history->journal_id = $publish->sno;
            $history->published_date = date('Y-m-d', strtotime($request->publish_date));
            $history->published_files = ! empty($files) ? json_encode($driveDocuments) : null;
            $history->published_author = $publish_author;
            $history->published_url = $publish_url;
            $history->publiched_paper = $paper_name;
            $history->created_by = $user_id;
            $history->updated_by = $user_id;
            $history->status = 8;
            $history->save();

            // Customer app notification
            $sts_text = 'Published';
            $branch_id = $request->user()->branch_id;
            DB::table('et_notification_customer_app')->insert([
                'branch_id' => $branch_id,
                'notification_type_id' => 3,
                'notification_type' => 'Journal',
                'header' => $publish->paper_name,
                'message' => 'Journal Status Updated',
                'notification_date' => now(),
                'meesage_for' => 'Journal Published',
                'message_date' => $history->published_date,
                'who' => $user_id,
                'whom' => $publish->customer_id,
                'process_id' => $history->sno,
                'status_text' => $sts_text,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Journal published successfully!',
                'data' => null,
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'Failed to submit publish',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function journalDashboard(Request $request)
    {
        $user = $request->user();
        $userId = $user->user_id;
        $branchId = $user->branch_id;
        $dateFilter = $request->input('date', date('M-Y'));
        $helper = new \App\Helpers\Helpers();

        try {
            $date = Carbon::createFromFormat('M-Y', $dateFilter);
            $month = $date->month;
            $year = $date->year;
        } catch (\Exception $e) {
            $date = Carbon::now();
            $month = $date->month;
            $year = $date->year;
        }

        $today = date('Y-m-d');
        $prevMonthDate = Carbon::create($year, $month, 1)->subMonth();
        $prevMonth = $prevMonthDate->month;
        $prevYear = $prevMonthDate->year;
        $yesterday = Carbon::yesterday()->format('Y-m-d');

        $publishedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_id', $userId)
            ->where('et_journal_history.status', 8)
            ->whereMonth('et_journal_history.published_date', $month)
            ->whereYear('et_journal_history.published_date', $year)
            ->count();

        $submittedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_id', $userId)
            ->where('et_journal_history.status', 0)
            ->whereMonth('et_journal_history.submitted_date', $month)
            ->whereYear('et_journal_history.submitted_date', $year)
            ->count();

        $withEditorCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_id', $userId)
            ->where('et_journal_history.status', 1)
            ->whereMonth('et_journal_history.with_editor_date', $month)
            ->whereYear('et_journal_history.with_editor_date', $year)
            ->count();

        $underReviewerCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_id', $userId)
            ->where('et_journal_history.status', 3)
            ->whereMonth('et_journal_history.under_reviewer_date', $month)
            ->whereYear('et_journal_history.under_reviewer_date', $year)
            ->count();

        $revisionCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_id', $userId)
            ->where('et_journal_history.status', 4)
            ->whereMonth('et_journal_history.reviewed_date', $month)
            ->whereYear('et_journal_history.reviewed_date', $year)
            ->count();

        $acceptedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_id', $userId)
            ->where('et_journal_history.status', 5)
            ->whereMonth('et_journal_history.accepted_date', $month)
            ->whereYear('et_journal_history.accepted_date', $year)
            ->count();

        $rejectedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_id', $userId)
            ->where('et_journal_history.status', 6)
            ->whereMonth('et_journal_history.rejected_date', $month)
            ->whereYear('et_journal_history.rejected_date', $year)
            ->count();

        $eproofingCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_id', $userId)
            ->where('et_journal_history.status', 6)
            ->whereMonth('et_journal_history.e_proofing_date', $month)
            ->whereYear('et_journal_history.e_proofing_date', $year)
            ->count();

        $overallClients = DB::table('et_customer_services')
            ->where('et_customer_services.jc_id', $userId)
            ->where('et_customer_services.journal_check', 1)
            ->distinct('customer_id')
            ->count('customer_id');

        $allocatedPaper = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', '!=', 2)
            ->where('et_customer_services.jc_id', $userId)
            ->whereMonth('et_manage_journal.created_at', $month)
            ->whereYear('et_manage_journal.created_at', $year)
            ->count();

        $pendingPublication = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->whereNotIn('et_manage_journal.status', [0, 8])
            ->where('et_customer_services.jc_id', $userId)
            ->whereMonth('et_manage_journal.created_at', $month)
            ->whereYear('et_manage_journal.created_at', $year)
            ->count();

        $monthlyPublished = DB::table('et_journal_history')
            ->join('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_id', $userId)
            ->where('et_journal_history.status', 8)
            ->whereYear('et_journal_history.published_date', $year)
            ->selectRaw('MONTH(et_journal_history.published_date) as month, COUNT(*) as count')
            ->groupByRaw('MONTH(et_journal_history.published_date)')
            ->orderByRaw('MONTH(et_journal_history.published_date)')
            ->get()
            ->keyBy('month');

        $publishedMonthWise = [];

        for ($m = 1; $m <= 12; $m++) {
            $publishedMonthWise[] = [
                'month' => Carbon::create()->month($m)->format('M'),
                'count' => $monthlyPublished[$m]->count ?? 0,
            ];
        }

        return response([
            'status' => 200,
            'message' => 'Data Successfull',
            'publishedCount' => $publishedCount,
            'submittedCount' => $submittedCount,
            'withEditorCount' => $withEditorCount,
            'underReviewerCount' => $underReviewerCount,
            'acceptedCount' => $acceptedCount,
            'rejectedCount' => $rejectedCount,
            'eproofingCount' => $eproofingCount,
            'allocatedPaper' => $allocatedPaper,
            'pendingPublication' => $pendingPublication,
            'revisionCount' => $revisionCount,
            'publishedMonthWise' => $publishedMonthWise,
            'overallClients' => $overallClients,
        ], 200);
    }

    public function journalPassLocker($id)
    {
        $customer = DB::table('et_customer')
            ->where('sno', $id)
            ->where('status', '!=', 2)
            ->select(
                'cus_name',
                'customer_id',
                'cus_mobile',
                'cus_email_id'
            )
            ->first();

        $passLocker = DB::table('et_pass_locker')
            ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_pass_locker.journal_id')
            ->select(
                'et_manage_journal.paper_name',
                'et_pass_locker.user_name',
                'et_pass_locker.password'
            )
            ->where('et_pass_locker.customer_id', $id)
            ->where('et_pass_locker.status', 1)
            ->get();

        if ($customer && $passLocker) {
            return response([
                'status' => 200,
                'message' => 'Pass Locker Data Fetched Successfully!',
                'data' => [
                    'customer' => $customer,
                    'passLocker' => $passLocker,
                ],
            ], 200);
        }

        return response([
            'status' => 404,
            'message' => 'No Data Found!',
            'data' => null,
        ], 404);
    }

    public function get_task_request()
    {
        $data = DB::table('et_journal_request')
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();

        return response([
            'status' => 200,
            'message' => 'Task request data fetched successfully !',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function createTaskRequest(Request $request)
    {
        $userId = $request->user()->user_id;

        $journalId = $request->id;
        $requestId = $request->request_id;
        $taskDesc = $request->task_desc;

        $task = TaskRequestModel::create([
            'journal_id' => $journalId,
            'request_id' => $requestId,
            'task_request_desc' => $taskDesc ?? null,
            'assigned_by' => $userId,
            'created_by' => $userId,
            'updated_by' => $userId,
        ]);

        $driveDetails = DB::table('et_manage_journal')
            ->where('et_manage_journal.sno', $journalId)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->select(
                'et_customer.customer_id',
                'et_customer_services.created_at',
                'et_customer_services.sno',
                'et_manage_journal.journal_id',
                'et_manage_journal.status',
            )
            ->first();

        $year = date('Y', strtotime($driveDetails->created_at));
        $id = str_pad($driveDetails->sno, 5, '0', STR_PAD_LEFT);
        $driveDetails->service_id = "SR-{$id}/{$year}";

        $driveDocuments = [];

        if ($request->filled('uploaded_files')) {
            $accessToken = $this->token();
            $files = json_decode($request->uploaded_files, true);

            $rootFolderId = config('services.google_drive.folder_id');

            // ! Customer Folder
            $customerFolderName = $driveDetails->customer_id;
            $customerFolderId = $this->findDriveFolder($customerFolderName, $rootFolderId, $accessToken)
                ?? $this->createDriveFolder($customerFolderName, $rootFolderId, $accessToken);

            // ! Service Folder
            $serviceFolderName = $driveDetails->service_id;
            $serviceFolderId = $this->findDriveFolder($serviceFolderName, $customerFolderId, $accessToken)
                ?? $this->createDriveFolder($serviceFolderName, $customerFolderId, $accessToken);

            // ! Journal Folder
            $journalFolderName = $driveDetails->journal_id;
            $journalFolderId = $this->findDriveFolder($journalFolderName, $serviceFolderId, $accessToken)
                ?? $this->createDriveFolder($journalFolderName, $serviceFolderId, $accessToken);

            // ! Status Folder
            $statusFolderName = 'Requested Task';
            $statusFolderId = $this->findDriveFolder($statusFolderName, $journalFolderId, $accessToken)
                ?? $this->createDriveFolder($statusFolderName, $journalFolderId, $accessToken);

            foreach ($files as $file) {

                $localPath = public_path($file['path']);

                if (! file_exists($localPath)) {
                    continue;
                }

                $driveFile = $this->uploadFileToDrive(
                    $localPath,
                    $file['original_name'],
                    $statusFolderId,
                    $accessToken
                );

                $this->makeFilePublic($statusFolderId, $accessToken);
                $folderLink = "https://drive.google.com/drive/folders/{$statusFolderId}";

                $driveFileId = null;

                if (is_array($driveFile) && isset($driveFile['id'])) {
                    $driveFileId = $driveFile['id'];
                } else {
                    throw new Exception('Google Drive upload failed for file: '.$file['original_name']);
                }

                $driveDocuments[] = [
                    'original_name' => $file['original_name'],
                    'drive_file_id' => $driveFileId,
                    'status' => 'Submitted',
                    'folderLink' => $folderLink ?? null,
                ];

                unlink($localPath);
            }

            // Cleanup user temp folder
            File::deleteDirectory(public_path("{$userId}/temp"));
        }

        $task->drive_link = $driveDocuments ? json_encode($driveDocuments) : null;
        $task->save();

        return response([
            'status' => 200,
            'message' => 'Task Requested Successfully !',
            'data' => null,
        ], 200);
    }
    public function closeJournal($id)
    {
        try {
            // Validate ID
            if (!is_numeric($id)) {
                return response()->json([
                    'status' => 400,
                    'message' => 'Invalid journal ID',
                    'error_msg' => 'ID must be numeric',
                ], 400);
            }
 
            // Check if journal exists and get current status
            $journal = DB::table('et_manage_journal')
                ->select('status')
                ->where('sno', $id)
                ->first();
 
            if (!$journal) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Journal not found',
                    'error_msg' => 'No record found with the given ID',
                ], 404);
            }
 
            if ($journal->status == 2) {
                return response()->json([
                    'status' => 400,
                    'message' => 'Journal already closed',
                    'error_msg' => 'Journal is already in closed state',
                ], 400);
            }
 
            $updated = DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update(['status' => 2]);
 
            if ($updated) {
                return response()->json([
                    'status' => 200,
                    'message' => 'Journal Closed Successfully',
                    'error_msg' => null,
                    'data' => ['closed_journal_id' => $id],
                ], 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'Failed to close journal',
                    'error_msg' => 'Database update failed',
                ], 500);
            }
        } catch (\Exception $e) {
            // \Log::error('Journal closure failed: ' . $e->getMessage(), [
            //     'id' => $id,
            //     'trace' => $e->getTraceAsString()
            // ]);
 
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong',
                'error_msg' => 'An internal server error occurred',
            ], 500);
        }
    }
    
     public function journal_noc_generate($id)
    {
        try {


            // Fetch journal details
            $journal_details = DB::table('et_manage_journal')
                ->where('sno', $id)
                ->first();

            if (!$journal_details) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Journal not found',
                    'error_msg' => 'No journal record exists for this ID'
                ], 404);
            }

            // Fetch customer details
            $customer_details = DB::table('et_customer_services')
                ->select(
                    'et_customer.cus_name',
                    'et_customer.customer_id',
                    'et_customer_services.sno',
                    'et_customer_services.created_at',
                    'et_customer_services.journal_index',
                    'et_customer_services.proposal_id',
                    'et_customer.sno as journal_customer_id',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff',
                    'journal_staff.staff_name as journal_staff_name',
                    'journal_coordinator.staff_name as journal_coordinator_name',
                    'journal_staff.staff_image as journal_staff_image',
                    'journal_coordinator.staff_image as journal_coordinator_image',
                    DB::raw("
            CASE
                WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                ELSE NULL
            END as service_name
        ")
                )
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
                ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
                ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
                ->leftJoin('et_product', function ($join) {
                    $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                        ->where('et_customer_services.product_package', 1);
                })
                ->leftJoin('et_package', function ($join) {
                    $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                        ->where('et_customer_services.product_package', 2);
                })
                ->where('et_customer_services.journal_check', 1)
                ->where('et_customer_services.sno', $journal_details->service_id ?? null)
                ->first();

            if (!$customer_details) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Customer not found',
                    'error_msg' => 'No customer linked to this journal'
                ], 404);
            } else {
                $helper = new \App\Helpers\Helpers();

                $customer_details->domain_names = $helper->get_domain_by_proposalId($customer_details->proposal_id);

                // Journal Data
                // Journal Data
                $journalData = DB::table('et_manage_journal')
                    ->where('et_manage_journal.sno', $journal_details->booklet_id)
                    ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
                    ->select(
                        'et_journal_booklet.journal_name',
                        'et_journal_booklet.domain_id',
                        'et_manage_journal.status',
                        'et_manage_journal.paper_name',
                        'et_manage_journal.journal_id',
                        'et_manage_journal.submited_date',
                        'et_manage_journal.sno',
                        'et_manage_journal.publish_author',
                        'et_manage_journal.published_paper_name',
                        'et_manage_journal.publish_url',
                        'et_manage_journal.publish_date'
                    )
                    ->first();

                $customer_details->journal_data = $journalData;

                // ✅ Domain Mapping FIX
                $domain_ids = json_decode($journalData->domain_id ?? '[]', true);

                if (is_array($domain_ids) && !empty($domain_ids)) {
                    $domainNames = DB::table('et_domain')
                        ->whereIn('sno', $domain_ids)
                        ->where('status', 0)
                        ->pluck('domain_name')
                        ->toArray();

                    // ✅ Convert to comma-separated string
                    $customer_details->journal_data->domain_names = implode(', ', $domainNames);
                } else {
                    $customer_details->journal_data->domain_names = '';
                }

                // Service ID
                $year = date('Y', strtotime($customer_details->created_at));
                $id = str_pad($customer_details->sno, 5, '0', STR_PAD_LEFT);
                $customer_details->service_id = "SR-{$id}/{$year}";
            }

            return response()->json([
                'status' => 200,
                'message' => 'Journal fetched successfully',
                'error_msg' => null,
                'data' => [
                    'journal_id' => $id,
                    'journal_details' => $journal_details,
                    'customer_details' => $customer_details,
                ],
            ], 200);
        } catch (\Exception $e) {
            // \Log::error('Journal NOC Error: ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong',
                'error_msg' => $e->getMessage() // optional: hide in production
            ], 500);
        }
    }


    public function journal_noc($id)
    {
        try {
            $helper = new \App\Helpers\Helpers();
            $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

            // Check if decryption failed
            if ($decryptedValue === false || empty($decryptedValue)) {
                return redirect()->back()->with('error', 'Invalid Entry');
            }
            $encryptIDs = $id;
            $id = $decryptedValue;

            // Validate that $id is numeric
            if (!is_numeric($id)) {
                return redirect()->back()->with('error', 'Invalid Entry ID');
            }

            $journal_details = DB::table('et_manage_journal')->where('sno', $id)->first();

            // Check if journal exists
            if (!$journal_details) {
                return redirect()->back()->with('error', 'Journal not found');
            } elseif ($journal_details->noc_appoved == 1) {
                return view('content.journal_management.manage_journal.thankyou_screen');
            }
            // Fetch customer details
            $customer_details = DB::table('et_customer_services')
                ->select(
                    'et_customer.cus_name',
                    'et_customer.customer_id',
                    'et_customer_services.sno',
                    'et_customer_services.created_at',
                    'et_customer_services.journal_index',
                    'et_customer_services.proposal_id',
                    'et_customer.sno as journal_customer_id',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff',
                    'journal_staff.staff_name as journal_staff_name',
                    'journal_coordinator.staff_name as journal_coordinator_name',
                    'journal_staff.staff_image as journal_staff_image',
                    'journal_coordinator.staff_image as journal_coordinator_image',
                    DB::raw("
            CASE
                WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                ELSE NULL
            END as service_name
        ")
                )
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
                ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
                ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
                ->leftJoin('et_product', function ($join) {
                    $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                        ->where('et_customer_services.product_package', 1);
                })
                ->leftJoin('et_package', function ($join) {
                    $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                        ->where('et_customer_services.product_package', 2);
                })
                ->where('et_customer_services.journal_check', 1)
                ->where('et_customer_services.sno', $journal_details->service_id ?? null)
                ->first();

            if (!$customer_details) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Customer not found',
                    'error_msg' => 'No customer linked to this journal'
                ], 404);
            } else {
                $helper = new \App\Helpers\Helpers();

                $customer_details->domain_names = $helper->get_domain_by_proposalId($customer_details->proposal_id);

                // Journal Data
                // Journal Data
                $journalData = DB::table('et_manage_journal')
                    ->where('et_manage_journal.sno', $journal_details->booklet_id)
                    ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
                    ->select(
                        'et_journal_booklet.journal_name',
                        'et_journal_booklet.domain_id',
                        'et_manage_journal.status',
                        'et_manage_journal.paper_name',
                        'et_manage_journal.journal_id',
                        'et_manage_journal.submited_date',
                        'et_manage_journal.sno',
                        'et_manage_journal.publish_author',
                        'et_manage_journal.published_paper_name',
                        'et_manage_journal.publish_url',
                        'et_manage_journal.publish_date'
                    )
                    ->first();

                $customer_details->journal_data = $journalData;

                // ✅ Domain Mapping FIX
                $domain_ids = json_decode($journalData->domain_id ?? '[]', true);

                if (is_array($domain_ids) && !empty($domain_ids)) {
                    $domainNames = DB::table('et_domain')
                        ->whereIn('sno', $domain_ids)
                        ->where('status', 0)
                        ->pluck('domain_name')
                        ->toArray();

                    // ✅ Convert to comma-separated string
                    $customer_details->journal_data->domain_names = implode(', ', $domainNames);
                } else {
                    $customer_details->journal_data->domain_names = '';
                }

                // Service ID
                $year = date('Y', strtotime($customer_details->created_at));
                $id = str_pad($customer_details->sno, 5, '0', STR_PAD_LEFT);
                $customer_details->service_id = "SR-{$id}/{$year}";
            }

            $journal_credentials = DB::table('et_pass_locker')->where('journal_id', $journal_details->sno)->orderBy('sno', 'DESC')->first();


            // Pass data to view
            return view('content.journal_management.manage_journal.journal_noc', compact(
                'journal_details',
                'customer_details',
                'encryptIDs',
                'journal_credentials'
            ));
        } catch (\Exception $e) {
            // Log the error for debugging
            // \Log::error('Journal NOC Error: ' . $e->getMessage());

            // Return user-friendly error
            return redirect()->back()->with('error', 'An error occurred while processing your request');
        }
    }
    public function thank_you_NOC($id)
    {

        try {
            $helper = new \App\Helpers\Helpers();
            $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

            if (!$decryptedValue || !is_numeric($decryptedValue)) {
                return redirect()->back()->with('error', 'Invalid Entry');
            }

            $id = $decryptedValue;
            $view = 'content.journal_management.manage_journal.thankyou_screen';

            $journal = DB::table('et_manage_journal')
                ->select('noc_appoved')
                ->where('sno', $id)
                ->first();

            if (!$journal || $journal->noc_appoved == 1) {
                return view($view);
            }

            DB::table('et_manage_journal')
                ->where('sno', $id)
                ->update(['noc_appoved' => 1]);

            return view($view);
        } catch (\Exception $e) {
            return view('content.journal_management.manage_journal.thankyou_screen');
        }
    }
 
}
