<?php

namespace App\Http\Controllers\journal_management;

use App\Http\Controllers\Controller;
use App\Models\FollowupReasonModel;
use App\Models\JournalBookletModel;
use App\Models\JournalHistoryModel;
use App\Models\ManageJournalfollowupModel;
use App\Models\ManageJournalModel;
use App\Models\PassLockerModel;
use App\Models\StaffModel;
use App\Models\TaskRequestModel;
use Carbon\Carbon;
use DateTime;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class ManageJournalfollowup extends Controller
{
    public function today_followup_list(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;
        // Filters

        $search_fill  = $request->input('search_fill', '');

        $listQuery = ManageJournalfollowupModel::select(
            'et_journal_followup.*',
            'et_customer.cus_name',
            'et_customer.customer_id',
            'et_customer_services.sno as services_sno',
            'et_customer_services.created_at',
            'et_customer_services.journal_index',
            'et_customer_services.proposal_id',
            'et_customer.sno as journal_customer_id',
            'created_staff.staff_name as created_staff_name',
            // 'et_customer_services.jc_id',
            // 'et_customer_services.jc_staff',
            // 'journal_staff.staff_name as journal_staff_name',
            // 'journal_coordinator.staff_name as jouranal_coordinator_name',
            // 'journal_staff.staff_image as journal_staff_image',
            // 'journal_coordinator.staff_image as jouranal_coordinator_image',
            DB::raw('CASE
                        WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                        WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                        ELSE NULL
                    END as service_name')
        )
            ->join('et_customer_services', 'et_journal_followup.customer_service_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_staff as created_staff', 'created_staff.sno', '=', 'et_journal_followup.staff_id')
            // ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
            // ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', 2);
            })

            ->whereNotIn('et_journal_followup.status', [2])
            ->orderBy('et_journal_followup.sno', 'desc')
            ->where('et_journal_followup.appointment_date', date('y-m-d'))
            ->where('et_journal_followup.branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            // User can only view their own data
            $listQuery = $listQuery->where('et_journal_followup.staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }

        if ($search_fill != '') {
            $listQuery->where(function ($query) use ($search_fill) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer_services.proposal_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_package.package_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('created_staff.staff_name', 'LIKE', "%{$search_fill}%");
            });
        }

        $List = $listQuery->orderBy('et_journal_followup.sno', 'desc')->paginate($perpage);

        foreach ($List as $list) {

            $list->domain_names = $helper->get_domain_by_proposalId($list->proposal_id);
            // Journal Index
            $index_ids = json_decode($list->journal_index, true);
            if (!is_array($index_ids)) {
                $index_ids = is_numeric($list->journal_index) ? [(int)$list->journal_index] : [];
            }
            if (!empty($index_ids)) {
                $names = DB::table('et_journal_index')
                    ->whereIn('sno', $index_ids)
                    ->where('status', 0)
                    ->pluck('index_name')
                    ->toArray();

                $list->index_names = !empty($names) ? implode(', ', $names) : 'No Index';
            } else {
                $list->index_names = 'No Index';
            }
            // Service ID
            $year = date('Y', strtotime($list->created_at));
            $id   = str_pad($list->services_sno, 5, '0', STR_PAD_LEFT);
            $list->service_id = "SR-{$id}/{$year}";

            $list->formatted_date = date('d-M-Y', strtotime($list->appointment_date));
            $list->formatted_time = date('h:i A', strtotime($list->appointment_time));
        }


        $todayFollowupCount = DB::table('et_journal_followup')
            ->where('status', '!=', 2)
            ->where('branch_id', $branch_id)
            ->where('appointment_date', date('Y-m-d'));

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $todayFollowupCount = $todayFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $todayFollowupCount = $todayFollowupCount->count();

        $closedFollowupCount = DB::table('et_journal_followup')
            ->where('status', 1)
            ->where('branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $closedFollowupCount = $closedFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $closedFollowupCount = $closedFollowupCount->count();

        $rescheduleFollowupCount = DB::table('et_journal_followup')
            ->where('status', 1)
            ->where('is_reschedule', 1)
            ->where('branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();

        $unFollowupCount = DB::table('et_journal_followup')
            ->where('status', 0)
            ->where('branch_id', $branch_id)
            ->where('appointment_date', '<=', date('Y-m-d'))
            ->where('appointment_time', '<=', now()->format('H:i'));

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $unFollowupCount = $unFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $unFollowupCount = $unFollowupCount->count();

        // return $List;

        return view('content.journal_management.journal_followup.today_list', compact(
            'List',
            'search_fill',
            'perpage',
            'unFollowupCount',
            'todayFollowupCount',
            'closedFollowupCount',
            'rescheduleFollowupCount',
            'unFollowupCount',
        ));
    }
    public function closed_followup_list(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;
        // Filters

        $search_fill  = $request->input('search_fill', '');

        $listQuery = ManageJournalfollowupModel::select(
            'et_journal_followup.*',
            'et_customer.cus_name',
            'et_customer.customer_id',
            'et_customer_services.sno as services_sno',
            'et_customer_services.created_at',
            'et_customer_services.journal_index',
            'et_customer_services.proposal_id',
            'et_customer.sno as journal_customer_id',
            'created_staff.staff_name as created_staff_name',
            // 'et_customer_services.jc_id',
            // 'et_customer_services.jc_staff',
            // 'journal_staff.staff_name as journal_staff_name',
            // 'journal_coordinator.staff_name as jouranal_coordinator_name',
            // 'journal_staff.staff_image as journal_staff_image',
            // 'journal_coordinator.staff_image as jouranal_coordinator_image',
            DB::raw('CASE
                        WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                        WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                        ELSE NULL
                    END as service_name')
        )
            ->join('et_customer_services', 'et_journal_followup.customer_service_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_staff as created_staff', 'created_staff.sno', '=', 'et_journal_followup.staff_id')
            // ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
            // ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', 2);
            })

            ->where('et_journal_followup.status', 1)
            ->orderBy('et_journal_followup.sno', 'desc')
            // ->where('et_journal_followup.appointment_date', date('y-m-d'))
            ->where('et_journal_followup.branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            // User can only view their own data
            $listQuery = $listQuery->where('et_journal_followup.staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }

        if ($search_fill != '') {
            $listQuery->where(function ($query) use ($search_fill) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer_services.proposal_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_package.package_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('created_staff.staff_name', 'LIKE', "%{$search_fill}%");
            });
        }

        $List = $listQuery->orderBy('et_journal_followup.sno', 'desc')->paginate($perpage);

        foreach ($List as $list) {

            $list->domain_names = $helper->get_domain_by_proposalId($list->proposal_id);
            // Journal Index
            $index_ids = json_decode($list->journal_index, true);
            if (!is_array($index_ids)) {
                $index_ids = is_numeric($list->journal_index) ? [(int)$list->journal_index] : [];
            }
            if (!empty($index_ids)) {
                $names = DB::table('et_journal_index')
                    ->whereIn('sno', $index_ids)
                    ->where('status', 0)
                    ->pluck('index_name')
                    ->toArray();

                $list->index_names = !empty($names) ? implode(', ', $names) : 'No Index';
            } else {
                $list->index_names = 'No Index';
            }
            // Service ID
            $year = date('Y', strtotime($list->created_at));
            $id   = str_pad($list->services_sno, 5, '0', STR_PAD_LEFT);
            $list->service_id = "SR-{$id}/{$year}";

            $list->formatted_date = date('d-M-Y', strtotime($list->appointment_date));
            $list->formatted_time = date('h:i A', strtotime($list->appointment_time));
        }


        $todayFollowupCount = DB::table('et_journal_followup')
            ->where('status', '!=', 2)
            ->where('branch_id', $branch_id)
            ->where('appointment_date', date('Y-m-d'));

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $todayFollowupCount = $todayFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $todayFollowupCount = $todayFollowupCount->count();

        $closedFollowupCount = DB::table('et_journal_followup')
            ->where('status', 1)
            ->where('branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $closedFollowupCount = $closedFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $closedFollowupCount = $closedFollowupCount->count();

        $rescheduleFollowupCount = DB::table('et_journal_followup')
            ->where('status', 1)
            ->where('is_reschedule', 1)
            ->where('branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();

        $unFollowupCount = DB::table('et_journal_followup')
            ->where('status', 0)
            ->where('branch_id', $branch_id)
            ->where('appointment_date', '<=', date('Y-m-d'))
            ->where('appointment_time', '<=', now()->format('H:i'));

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $unFollowupCount = $unFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $unFollowupCount = $unFollowupCount->count();

        // return $List;

        return view('content.journal_management.journal_followup.closed_list', compact(
            'List',
            'search_fill',
            'perpage',
            'unFollowupCount',
            'todayFollowupCount',
            'closedFollowupCount',
            'rescheduleFollowupCount',
            'unFollowupCount',
        ));
    }
    public function reschedule_followup_list(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;
        // Filters

        $search_fill  = $request->input('search_fill', '');

        $listQuery = ManageJournalfollowupModel::select(
            'et_journal_followup.*',
            'et_customer.cus_name',
            'et_customer.customer_id',
            'et_customer_services.sno as services_sno',
            'et_customer_services.created_at',
            'et_customer_services.journal_index',
            'et_customer_services.proposal_id',
            'et_customer.sno as journal_customer_id',
            'created_staff.staff_name as created_staff_name',
            // 'et_customer_services.jc_id',
            // 'et_customer_services.jc_staff',
            // 'journal_staff.staff_name as journal_staff_name',
            // 'journal_coordinator.staff_name as jouranal_coordinator_name',
            // 'journal_staff.staff_image as journal_staff_image',
            // 'journal_coordinator.staff_image as jouranal_coordinator_image',
            DB::raw('CASE
                        WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                        WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                        ELSE NULL
                    END as service_name')
        )
            ->join('et_customer_services', 'et_journal_followup.customer_service_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_staff as created_staff', 'created_staff.sno', '=', 'et_journal_followup.staff_id')
            // ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
            // ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', 2);
            })

            ->where('et_journal_followup.is_reschedule', 1)
            ->orderBy('et_journal_followup.sno', 'desc')
            // ->where('et_journal_followup.appointment_date', date('y-m-d'))
            ->where('et_journal_followup.branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            // User can only view their own data
            $listQuery = $listQuery->where('et_journal_followup.staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }

        if ($search_fill != '') {
            $listQuery->where(function ($query) use ($search_fill) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer_services.proposal_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_package.package_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('created_staff.staff_name', 'LIKE', "%{$search_fill}%");
            });
        }

        $List = $listQuery->orderBy('et_journal_followup.sno', 'desc')->paginate($perpage);

        foreach ($List as $list) {

            $list->domain_names = $helper->get_domain_by_proposalId($list->proposal_id);
            // Journal Index
            $index_ids = json_decode($list->journal_index, true);
            if (!is_array($index_ids)) {
                $index_ids = is_numeric($list->journal_index) ? [(int)$list->journal_index] : [];
            }
            if (!empty($index_ids)) {
                $names = DB::table('et_journal_index')
                    ->whereIn('sno', $index_ids)
                    ->where('status', 0)
                    ->pluck('index_name')
                    ->toArray();

                $list->index_names = !empty($names) ? implode(', ', $names) : 'No Index';
            } else {
                $list->index_names = 'No Index';
            }
            // Service ID
            $year = date('Y', strtotime($list->created_at));
            $id   = str_pad($list->services_sno, 5, '0', STR_PAD_LEFT);
            $list->service_id = "SR-{$id}/{$year}";

            $list->formatted_date = date('d-M-Y', strtotime($list->appointment_date));
            $list->formatted_time = date('h:i A', strtotime($list->appointment_time));
        }


        $todayFollowupCount = DB::table('et_journal_followup')
            ->where('status', '!=', 2)
            ->where('branch_id', $branch_id)
            ->where('appointment_date', date('Y-m-d'));

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $todayFollowupCount = $todayFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $todayFollowupCount = $todayFollowupCount->count();

        $closedFollowupCount = DB::table('et_journal_followup')
            ->where('status', 1)
            ->where('branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $closedFollowupCount = $closedFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $closedFollowupCount = $closedFollowupCount->count();

        $rescheduleFollowupCount = DB::table('et_journal_followup')
            ->where('status', 1)
            ->where('is_reschedule', 1)
            ->where('branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();

        $unFollowupCount = DB::table('et_journal_followup')
            ->where('status', 0)
            ->where('branch_id', $branch_id)
            ->where('appointment_date', '<=', date('Y-m-d'))
            ->where('appointment_time', '<=', now()->format('H:i'));

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $unFollowupCount = $unFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $unFollowupCount = $unFollowupCount->count();

        // return $List;

        return view('content.journal_management.journal_followup.reschedule_list', compact(
            'List',
            'search_fill',
            'perpage',
            'unFollowupCount',
            'todayFollowupCount',
            'closedFollowupCount',
            'rescheduleFollowupCount',
            'unFollowupCount',
        ));
    }
    public function unfollowup_list(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;
        // Filters

        $search_fill  = $request->input('search_fill', '');

        $listQuery = ManageJournalfollowupModel::select(
            'et_journal_followup.*',
            'et_customer.cus_name',
            'et_customer.customer_id',
            'et_customer_services.sno as services_sno',
            'et_customer_services.created_at',
            'et_customer_services.journal_index',
            'et_customer_services.proposal_id',
            'et_customer.sno as journal_customer_id',
            'created_staff.staff_name as created_staff_name',
            // 'et_customer_services.jc_id',
            // 'et_customer_services.jc_staff',
            // 'journal_staff.staff_name as journal_staff_name',
            // 'journal_coordinator.staff_name as jouranal_coordinator_name',
            // 'journal_staff.staff_image as journal_staff_image',
            // 'journal_coordinator.staff_image as jouranal_coordinator_image',
            DB::raw('CASE
                        WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                        WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                        ELSE NULL
                    END as service_name')
        )
            ->join('et_customer_services', 'et_journal_followup.customer_service_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_staff as created_staff', 'created_staff.sno', '=', 'et_journal_followup.staff_id')
            // ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
            // ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', 2);
            })

            ->where('et_journal_followup.status', 0)
            ->orderBy('et_journal_followup.sno', 'desc')
            // ->where('et_journal_followup.appointment_date', date('y-m-d'))
            ->where('et_journal_followup.branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            // User can only view their own data
            $listQuery = $listQuery->where('et_journal_followup.staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }

        if ($search_fill != '') {
            $listQuery->where(function ($query) use ($search_fill) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer_services.proposal_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_package.package_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('created_staff.staff_name', 'LIKE', "%{$search_fill}%");
            });
        }

        $List = $listQuery->orderBy('et_journal_followup.sno', 'desc')->paginate($perpage);

        foreach ($List as $list) {

            $list->domain_names = $helper->get_domain_by_proposalId($list->proposal_id);
            // Journal Index
            $index_ids = json_decode($list->journal_index, true);
            if (!is_array($index_ids)) {
                $index_ids = is_numeric($list->journal_index) ? [(int)$list->journal_index] : [];
            }
            if (!empty($index_ids)) {
                $names = DB::table('et_journal_index')
                    ->whereIn('sno', $index_ids)
                    ->where('status', 0)
                    ->pluck('index_name')
                    ->toArray();

                $list->index_names = !empty($names) ? implode(', ', $names) : 'No Index';
            } else {
                $list->index_names = 'No Index';
            }
            // Service ID
            $year = date('Y', strtotime($list->created_at));
            $id   = str_pad($list->services_sno, 5, '0', STR_PAD_LEFT);
            $list->service_id = "SR-{$id}/{$year}";

            $list->formatted_date = date('d-M-Y', strtotime($list->appointment_date));
            $list->formatted_time = date('h:i A', strtotime($list->appointment_time));
        }


        $todayFollowupCount = DB::table('et_journal_followup')
            ->where('status', '!=', 2)
            ->where('branch_id', $branch_id)
            ->where('appointment_date', date('Y-m-d'));

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $todayFollowupCount = $todayFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $todayFollowupCount = $todayFollowupCount->count();

        $closedFollowupCount = DB::table('et_journal_followup')
            ->where('status', 1)
            ->where('branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $closedFollowupCount = $closedFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $closedFollowupCount = $closedFollowupCount->count();

        $rescheduleFollowupCount = DB::table('et_journal_followup')
            ->where('status', 1)
            ->where('is_reschedule', 1)
            ->where('branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();

        $unFollowupCount = DB::table('et_journal_followup')
            ->where('status', 0)
            ->where('branch_id', $branch_id)
            ->where('appointment_date', '<=', date('Y-m-d'))
            ->where('appointment_time', '<=', now()->format('H:i'));

        if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'view_self_cus')) {
            $unFollowupCount = $unFollowupCount->where('staff_id', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)
        }
        $unFollowupCount = $unFollowupCount->count();

        // return $List;
        $followupReasonList = FollowupReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();
        return view('content.journal_management.journal_followup.unfollowup_list', compact(
            'List',
            'search_fill',
            'perpage',
            'unFollowupCount',
            'todayFollowupCount',
            'closedFollowupCount',
            'rescheduleFollowupCount',
            'unFollowupCount',
            'followupReasonList',
        ));
    }

    public function Newfollowup(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'appointment_date' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $appointment_time   = $request->appointment_time;
            $appointment_date   = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
            $user_id            = $request->user()->user_id;
            $branch_id          = $request->user()->branch_id;
            $entity_id          = $request->user()->entity_id;

            $category_check = ManageJournalfollowupModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
            if (!$category_check) {
                $year = substr(date("y"), -2);
                $appointment_id = "JF-0001/" . $year;
            } else {

                $data = $category_check->appointment_id;
                $slice = explode("/", $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);

                $next_number = (int)$result + 1;
                $request_id = sprintf("JF-%04d", $next_number);

                $year = substr(date("y"), -2);
                $appointment_id = $request_id . '/' . $year;
            }
            // return $request;

            $add = new ManageJournalfollowupModel();
            $add->entity_id           = $entity_id;
            $add->branch_id           = $branch_id;
            $add->follow_up_id        = $appointment_id;
            $add->customer_id         = $request->new_customer_id;
            $add->customer_service_id = $request->new_service_id;
            $add->appointment_date    = $appointment_date;
            $add->appointment_time    = $appointment_time;
            $add->staff_id            = $user_id;
            $add->created_by          = $user_id;
            $add->updated_by          = $user_id;
            $add->save();

            if ($add) {
                $Journal = DB::table('et_customer_services')
                    ->where('customer_id', $add->customer_id)
                    ->where('sno', $add->customer_service_id)
                    ->update([
                        'follow_up_count' => DB::raw('follow_up_count + 1'),
                        'followup_status' => 1
                    ]);
            }

            if ($add) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Follow-up added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Follow-up !'
                ]);
            }
            // }
            // return $result;
            return redirect('journal_management/manage_journal');
        }
    }

    public function EditjournalFollowup($id)
    {
        $helper = new \App\Helpers\Helpers();
        // Fetch the latest appointment details for a specific customer_service_id
        $latestAppointment = ManageJournalfollowupModel::select(
            'et_journal_followup.*',
            'et_customer.cus_name',
            'et_customer.customer_id',
            'et_customer_services.sno as services_sno',
            'et_customer_services.created_at',
            'et_customer_services.journal_index',
            'et_customer_services.proposal_id',
            'et_customer.sno as journal_customer_id',
            'et_customer_services.jc_id',
            'et_customer_services.jc_staff',
            'journal_staff.staff_name as journal_staff_name',
            'journal_coordinator.staff_name as jouranal_coordinator_name',
            'journal_staff.staff_image as journal_staff_image',
            'journal_coordinator.staff_image as jouranal_coordinator_image',
            DB::raw('CASE
            WHEN et_customer_services.product_package = 1 THEN et_product.product_name
            WHEN et_customer_services.product_package = 2 THEN et_package.package_name
            ELSE NULL
        END as service_name')
        )
            ->join('et_customer_services', 'et_journal_followup.customer_service_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
            ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', 2);
            })

            ->whereNotIn('et_journal_followup.status', [2])
            ->where('et_journal_followup.customer_service_id', $id)
            ->orderBy('et_journal_followup.sno', 'desc')
            ->first();

        $latestAppointment->domain_names = $helper->get_domain_by_proposalId($latestAppointment->proposal_id);

        // Journal Index
        $index_ids = json_decode($latestAppointment->journal_index, true);
        if (!is_array($index_ids)) {
            $index_ids = is_numeric($latestAppointment->journal_index) ? [(int)$latestAppointment->journal_index] : [];
        }

        if (!empty($index_ids)) {
            $names = DB::table('et_journal_index')
                ->whereIn('sno', $index_ids)
                ->where('status', 0)
                ->pluck('index_name')
                ->toArray();

            $latestAppointment->index_names = !empty($names) ? implode(', ', $names) : 'No Index';
        } else {
            $latestAppointment->index_names = 'No Index';
        }

        // Service ID
        $year = date('Y', strtotime($latestAppointment->created_at));
        $id = str_pad($latestAppointment->services_sno, 5, '0', STR_PAD_LEFT);
        $latestAppointment->service_id = "SR-{$id}/{$year}";

        $appointmentCount = ManageJournalfollowupModel::where('customer_service_id', $id)
            ->whereNotIn('status', [2])
            ->count();

        $historicalLeadIds = ManageJournalfollowupModel::select('et_journal_followup.*', 'et_staff.staff_name')
            ->join('et_staff', 'et_journal_followup.created_by', '=', 'et_staff.sno')
            ->where('et_journal_followup.customer_service_id', $id)
            ->where('et_journal_followup.status', '!=', 2)
            ->orderBy('et_journal_followup.sno', 'desc')
            ->get();

        // Extract appointment_date and appointment_time from the latest appointment
        $appointment_date = null;
        $appointment_time = null;
        if ($latestAppointment) {
            $appointment_date = $latestAppointment->appointment_date;
            $appointment_time = $latestAppointment->appointment_time;
        }

        // Include previous appointment date and time in historicalLeadIds
        $historicalLeadIds = $historicalLeadIds->map(function ($appointment, $key) use ($id) {
            // Fetch the previous appointment by skipping the current one
            $previousAppointment = ManageJournalfollowupModel::select('et_journal_followup.*')
                ->where('customer_service_id', $id)
                ->whereNotIn('status', [2])
                ->where('sno', '<', $appointment->sno)
                ->orderBy('sno', 'desc')
                ->first();

            $appointment->previous_appointment_date = $previousAppointment ? $previousAppointment->appointment_date : null;
            $appointment->previous_appointment_time = $previousAppointment ? $previousAppointment->appointment_time : null;

            return $appointment;
        });

        $reschedule_count  = DB::table('et_journal_followup')
            ->where('customer_service_id', $id)
            ->where('is_reschedule', 1)
            ->count();

        return response()->json([
            'status'    => 200,
            'message'   => 'Appointment details fetched successfully',
            'data'      => [
                'appointment_date' => $appointment_date,
                'appointment_time' => $appointment_time,
                'appointmentCount' => $appointmentCount,
                'latestAppointment' => $latestAppointment,
                'historicalLeadIds' => $historicalLeadIds,
                'reschedule_count' => $reschedule_count,
            ]
        ], 200);
    }

    public function FollowupUpdate($id, $customer_id, Request $request)
    {
        $validator = Validator::make($request->all(), [
            'progressed' => 'required|max:255',

        ]);
        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {
            //   return $request;
            $progressed       = $request->progressed;
            $appointment_time   = $request->appointment_time;
            $follow_through     = $request->follow_through ?? 0;
            $user_id            = $request->user()->user_id;
            $branch_id          = $request->user()->branch_id;
            $entity_id          = $request->user()->entity_id;
            $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
            if ($progressed == 1) {
                $upd_lead =  ManageJournalfollowupModel::where('customer_service_id', $id)->orderBy('sno', 'desc')->first();
                $upd_lead->progressed                 = $progressed;
                $upd_lead->score                      = $request->app_score;
                $upd_lead->follow_through             = $follow_through;
                $upd_lead->convo_message              = $request->convo_message;
                $upd_lead->status                     = 1;
                $upd_lead->update();
            } else {
                $category_check = ManageJournalfollowupModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                if (!$category_check) {
                    $year = substr(date("y"), -2);
                    $appointment_id = "JF-0001/" . $year;
                } else {
                    $data = $category_check->appointment_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int)$result + 1;
                    $request_id = sprintf("JF-%04d", $next_number);
                    $year = substr(date("y"), -2);
                    $appointment_id = $request_id . '/' . $year;
                }

                $upd_app = ManageJournalfollowupModel::where('customer_service_id', $id)
                    // ->where('status', 1)
                    ->where(function ($query) {
                        $query->where('progressed', 0)
                            ->orWhere('progressed', 2);
                    })
                    ->orderBy('sno', 'desc')
                    ->first();

                if ($upd_app) {
                    $upd_app->is_reschedule = 1;
                    $upd_app->progressed                 = $progressed;
                    $upd_app->score                      = $request->app_score;
                    $upd_app->follow_through             = $follow_through;
                    $upd_app->reason              = $request->reason;
                    $upd_app->status = 1;
                    $upd_app->update();
                }

                $upd_lead = new ManageJournalfollowupModel();
                $upd_lead->entity_id           = $entity_id;
                $upd_lead->branch_id           = $branch_id;
                $upd_lead->follow_up_id        = $appointment_id;
                $upd_lead->customer_id         = $customer_id;
                $upd_lead->customer_service_id = $id;
                $upd_lead->appointment_date    = $appointment_date;
                $upd_lead->appointment_time    = $appointment_time;
                $upd_lead->staff_id            = $user_id;
                $upd_lead->created_by          = $user_id;
                $upd_lead->updated_by          = $user_id;
                $upd_lead->save();
                $upd_lead->save();
            }
            if ($upd_lead) {
                $result = response([
                    'status'    => 200,
                    'message'   => 'Successfully Updated!',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);
            } else {
                $result = response([
                    'status'    => 401,
                    'message'   => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data'      => null,
                ], 401);
            }
            return $result;
        }
    }
}