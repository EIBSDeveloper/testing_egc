<?php

namespace App\Http\Controllers\metrics;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\BusinessGoalSetModel;
use App\Models\ManageTargetModel;
use App\Models\TransactionModel;
use App\Models\StaffModel;
use App\Models\CustomerModel;
use App\Models\IncentiveModel;
use App\Models\OldCustomerModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\GoalSetTeamModel;
use App\Models\AttendanceModel;
use Carbon\Carbon;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Collection;

class ManageBhIncentive extends Controller
{
  public function index(Request $request)
  {
    
    $branch_id = $request->user()->branch_id;


    return view('content.metrics.manage_bh_incentive');
  }

  public function fetchIncentive(Request $request)
  {
    // Use input() to safely fetch values (or use $request->get() / query() for GET)
    $role_id   = $request->input('role_id');
    $month     = $request->input('month'); // you named it monthRaw, but using as month
    $year      = $request->input('year');
    $branchId  = $request->input('branch_id') ?? $request->user()->branch_id;

    // Fetch staff list
    $staff = StaffModel::select('et_staff.staff_name')
      ->where('et_staff.branch_id', $branchId)
      ->where('et_staff.role_id', $role_id)
      ->where('et_staff.status', 0)
      ->get();

    // Check if staff exists
    if ($staff->isEmpty()) {
      return response()->json([
        'status' => false,
        'message' => 'Staff not found'
      ]);
    }

    // Get unique staff names
    $staffNames = $staff->pluck('staff_name')->unique()->values();

    // Define incentive types
    $types = ['ECI', 'PI', 'BI', '10X', 'SI', 'LI'];

    // Return response
    return response()->json([
      'status' => true,
      'staff_names' => $staffNames,
      'types' => $types
    ]);
  }

   public function getIncentiveMetrics(Request $request)
  {
    $branchId = $request->branch_id ?? $request->user()->branch_id;
    $departmentId = $request->department_id;
    $role_id = $request->role_id;

    $year = $request->year;

    if (!empty($request->month)) {
      $request->month = is_numeric($request->month)
        ? (int) $request->month
        : (int) date('m', strtotime($request->month . ' 1'));
    }

    $month = $request->month;

    // Get the first and last date of the requested month
    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

    $query = StaffModel::join('et_division', 'et_division.sno', '=', 'et_staff.sub_department_id')
      ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
      ->join('et_branch', 'et_branch.sno', '=', 'et_staff.branch_id')
      ->where('et_staff.branch_id', $branchId);

    $query->where('et_staff.role_id', $role_id);

    $staffList = $query
      ->where('et_staff.status', 0)
      ->select(
        'et_staff.sno as staff_id',
        'et_staff.staff_name',
        'et_staff.role_id',
        'et_staff.department_id',
        'et_staff.staff_image',
        'et_staff.nick_name',
        'et_staff.branch_id',
        'et_branch.branch_name',
        'et_branch.franchise_name',
        'et_branch.cert_auth_sign',
        'et_staff.avaiable_points',
        'et_staff.per_hour_cost',
        'et_staff.basic_salary',
        'et_division.division_name as sub_department_name',
        'et_department.department_name'
      )
      ->get();

    $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
      ->whereMonth('branch_target.date', $request->month)
      ->whereYear('branch_target.date', $year)
      ->first();

    $goalset = GoalSetTeamModel::where('et_goal_set_team.branch_id', $branchId)
      ->where('et_goal_set_team.team_goal_month', $request->month)
      ->where('et_goal_set_team.team_goal_year', $year)
      ->where('et_goal_set_team.department_id', 1)
      ->first();
  // return $goalset;
    $result = [];

    foreach ($staffList as $staff) {
      $incentive = IncentiveModel::where('role_id', $staff->role_id)
        ->where('branch_id', $branchId)
        ->whereMonth('incentive_month', $month)
        ->whereYear('incentive_month', $year)
        ->where('status', 0)
        ->first();

      $points = [];
      $calculations = [];
      $originalValues = [];

      // 1. 10X Award
      $result10xAward = $this->calculate10xAward($goalset, $targets, $startDate, $endDate, $branchId, $incentive, $year, $month);
      $points['10xaward'] = $result10xAward['value'];
      $calculations['10xaward'] = $result10xAward['calculation'];
      $originalValues['10xaward'] = $incentive->tenx_award ?? 0;

      // 2. Ceiling
      $resultCeiling = $this->calculateCeiling($targets, $startDate, $endDate, $branchId, $incentive, $year, $month);
      $points['ceiling'] = $resultCeiling['value'];
      $calculations['ceiling'] = $resultCeiling['calculation'];
      $originalValues['ceiling'] = $incentive->ceiling ?? 0;

      // 3. Quarterly
      $resultQuarterly = $this->calculateQuarterly($targets, $branchId, $incentive, $year, $month);
      $points['quarterly'] = $resultQuarterly['value'];
      $calculations['quarterly'] = $resultQuarterly['calculation'];
      $originalValues['quarterly'] = $incentive->quarterly ?? 0;

      // 4. 25%
      $result25 = $this->calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, 25);
      $points['twenty_five_percentage'] = $result25['value'];
      $calculations['twenty_five_percentage'] = $result25['calculation'];
      $originalValues['twenty_five_percentage'] = $incentive->twenty_five_percentage ?? 0;

      // 5. 50%
      $result50 = $this->calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, 50);
      $points['fifty_percentage'] = $result50['value'];
      $calculations['fifty_percentage'] = $result50['calculation'];
      $originalValues['fifty_percentage'] = $incentive->fifty_percentage ?? 0;

      // 6. 6 Month
      $result6Month = $this->calculateMonthBased($targets, $branchId, $incentive, $year, 6);
      $points['six_month'] = $result6Month['value'];
      $calculations['six_month'] = $result6Month['calculation'];
      $originalValues['six_month'] = $incentive->six_month ?? 0;

      // 7. 12 Month
      $result12Month = $this->calculateMonthBased($targets, $branchId, $incentive, $year, 12);
      $points['twelve_month'] = $result12Month['value'];
      $calculations['twelve_month'] = $result12Month['calculation'];
      $originalValues['twelve_month'] = $incentive->twelve_month ?? 0;

      // 8. 9 Month Add
      $result9MonthAdd = $this->calculateMonthAdd($targets, $branchId, $incentive, $year, 9);
      $points['nine_monthadd'] = $result9MonthAdd['value'];
      $calculations['nine_monthadd'] = $result9MonthAdd['calculation'];
      $originalValues['nine_monthadd'] = $incentive->nine_monthadd ?? 0;

      // 9. 12 Month Add
      $result12MonthAdd = $this->calculateMonthAdd($targets, $branchId, $incentive, $year, 12);
      $points['twelve_monthadd'] = $result12MonthAdd['value'];
      $calculations['twelve_monthadd'] = $result12MonthAdd['calculation'];
      $originalValues['twelve_monthadd'] = $incentive->twelve_monthadd ?? 0;

      // 10. Overall Year
      $resultOverallYear = $this->calculateOverallYear($targets, $branchId, $incentive, $year);
      $points['overall_year'] = $resultOverallYear['value'];
      $calculations['overall_year'] = $resultOverallYear['calculation'];
      $originalValues['overall_year'] = $incentive->overall_year ?? 0;

      // 11. Presale
      $resultPresale = $this->calculatePresale($targets, $branchId, $incentive, $year);
      $points['presale'] = $resultPresale['value'];
      $calculations['presale'] = $resultPresale['calculation'];
      $originalValues['presale'] = $incentive->presale ?? 0;

      // 12. Mega Bonus
      $resultMegaBonus = $this->calculateMegaBonus($targets, $branchId, $incentive, $year);
      $points['megabonus'] = $resultMegaBonus['value'];
      $calculations['megabonus'] = $resultMegaBonus['calculation'];
      $originalValues['megabonus'] = $incentive->megabonus ?? 0;

      // Calculate total earned and total original
      $conditionMet = $calculations['10xaward']['condition_met'] ?? false;

      if (!$conditionMet) {
        foreach ($points as $key => $val) {
          $points[$key] = 0;
        }

        foreach ($originalValues as $key => $val) {
          $originalValues[$key] = 0;
        }
      }

      $totalEarned = array_sum($points);
      $totalOriginal = array_sum($originalValues);
      $totalOriginal = array_sum($originalValues);

      $result[] = [
        'staff_id' => $staff->staff_id,
        'staff_name' => $staff->staff_name,
        'branch_name' => $staff->branch_name,
        'bh_signature' => $staff->cert_auth_sign,
        'staff_image' => $staff->staff_image,
        'role_id' => $staff->role_id,
        'nick_name' => $staff->nick_name,
        'sub_department_name' => $staff->sub_department_name,
        'department_name' => $staff->department_name,
        'incentive_value' => $points,
        'incentive_value_original' => $originalValues, // Default values from IncentiveModel
        'incentive_cal' => $calculations,
        'total_earned' => $totalEarned,
        'total_original' => $totalOriginal,
        'incentive_type' => [
          'presale' => 'gold',
        ]
      ];
    }
  
    return response()->json([
      'status' => 200,
      'data' => $result
    ]);
  }



  public function getIncentiveMetricsOld(Request $request)
  {
    $branchId = $request->branch_id ?? $request->user()->branch_id;
    $departmentId = $request->department_id;
    $role_id = $request->role_id;

    $year = $request->year;

    if (!empty($request->month)) {
      $request->month = is_numeric($request->month)
        ? (int) $request->month
        : (int) date('m', strtotime($request->month . ' 1'));
    }

    $month = $request->month;

    // Get the first and last date of the requested month
    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

    // Generate all dates in the month
    $dates = [];
    $currentDate = $startDate->copy();
    while ($currentDate->lte($endDate)) {
      $dates[] = $currentDate->toDateString();
      $currentDate->addDay();
    }

    // Directly use startDate and endDate for formatting
    $startOfMonth = $startDate->format('Y-m-d');
    $endOfMonth = $endDate->format('Y-m-d');

    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
    $prevYear  = Carbon::createFromDate($year, $month, 1)->subMonth()->year;

    $current = Carbon::create($year, $month, 1);
    // 20 years ago from now
    $startDateold = $current->copy()->subYears(20)->startOfMonth();
    $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month

    $query = StaffModel::join('et_division', 'et_division.sno', '=', 'et_staff.sub_department_id')
      ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
      ->join('et_branch', 'et_branch.sno', '=', 'et_staff.branch_id')
      ->where('et_staff.branch_id', $branchId);

    // Apply condition properly
    $query->where('et_staff.role_id', $role_id);

    $staffList = $query
      ->where('et_staff.status', 0)
      ->select(
        'et_staff.sno as staff_id',
        'et_staff.staff_name',
        'et_staff.role_id',
        'et_staff.department_id',
        'et_staff.staff_image',
        'et_staff.nick_name',
        'et_staff.branch_id',
        'et_branch.branch_name',
        'et_branch.franchise_name',
        'et_branch.cert_auth_sign',
        'et_staff.avaiable_points',
        'et_staff.per_hour_cost',
        'et_staff.basic_salary',
        'et_division.division_name',
        'et_department.department_name'
      )
      ->get();

    $departmentIds = $staffList->pluck('department_id')->unique()->toArray();

    $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
      ->whereMonth('branch_target.date', $request->month)
      ->whereYear('branch_target.date', $year)
      ->first();

    $result = [];
    // return $staffList

    foreach ($staffList as $staff) {
      $incentive = IncentiveModel::where('role_id', $staff->role_id)
        ->where('branch_id', $branchId)
        ->whereMonth('incentive_month', $month)
        ->whereYear('incentive_month', $year)
        ->where('status', 0)
        ->first();

      $points = [];
      $calculations = [];
      
      // 1. 10X Award
      $result10xAward = $this->calculate10xAward($targets, $startDate, $endDate, $branchId, $incentive, $year, $month);
      $points['10xaward'] = $result10xAward['value'];
      $calculations['10xaward'] = $result10xAward['calculation'];
     

      // 2. Ceiling
      $resultCeiling = $this->calculateCeiling($targets, $startDate, $endDate, $branchId, $incentive, $year, $month);
      $points['ceiling'] = $resultCeiling['value'];
      $calculations['ceiling'] = $resultCeiling['calculation'];

      // 3. Quarterly
      $resultQuarterly = $this->calculateQuarterly($targets, $branchId, $incentive, $year, $month);
      $points['quarterly'] = $resultQuarterly['value'];
      $calculations['quarterly'] = $resultQuarterly['calculation'];

      // 4. 25%
      $result25 = $this->calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, 25);
      $points['twenty_five_percentage'] = $result25['value'];
      $calculations['twenty_five_percentage'] = $result25['calculation'];

      // 5. 50%
      $result50 = $this->calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, 50);
      $points['fifty_percentage'] = $result50['value'];
      $calculations['fifty_percentage'] = $result50['calculation'];

      // 6. 6 Month
      $result6Month = $this->calculateMonthBased($targets, $branchId, $incentive, $year, 6);
      $points['six_month'] = $result6Month['value'];
      $calculations['six_month'] = $result6Month['calculation'];

      // 7. 12 Month
      $result12Month = $this->calculateMonthBased($targets, $branchId, $incentive, $year, 12);
      $points['twelve_month'] = $result12Month['value'];
      $calculations['twelve_month'] = $result12Month['calculation'];

      // 8. 9 Month Add
      $result9MonthAdd = $this->calculateMonthAdd($targets, $branchId, $incentive, $year, 9);
      $points['nine_monthadd'] = $result9MonthAdd['value'];
      $calculations['nine_monthadd'] = $result9MonthAdd['calculation'];

      // 9. 12 Month Add
      $result12MonthAdd = $this->calculateMonthAdd($targets, $branchId, $incentive, $year, 12);
      $points['twelve_monthadd'] = $result12MonthAdd['value'];
      $calculations['twelve_monthadd'] = $result12MonthAdd['calculation'];

      // 10. Overall Year
      $resultOverallYear = $this->calculateOverallYear($targets, $branchId, $incentive, $year);
      $points['overall_year'] = $resultOverallYear['value'];
      $calculations['overall_year'] = $resultOverallYear['calculation'];

      // 11. Dynamic
      $resultDynamic = $this->calculateDynamic($staff);
      $points['dynamic'] = $resultDynamic['value'];
      $calculations['dynamic'] = $resultDynamic['calculation'];

      // 12. Presale
      $resultPresale = $this->calculatePresale($targets, $branchId, $incentive, $year);
      $points['presale'] = $resultPresale['value'];
      $calculations['presale'] = $resultPresale['calculation'];

      // 13. Mega Bonus
      $resultMegaBonus = $this->calculateMegaBonus($targets, $branchId, $incentive, $year);
      $points['megabonus'] = $resultMegaBonus['value'];
      $calculations['megabonus'] = $resultMegaBonus['calculation'];

      $result[] = [
        'staff_id'            => $staff->staff_id,
        'staff_name'          => $staff->staff_name,
        'branch_name'         => $staff->branch_name,
        'bh_signature'        => $staff->cert_auth_sign,
        'staff_image'         => $staff->staff_image,
        'role_id'             => $staff->role_id,
        'nick_name'           => $staff->nick_name,
        'division_name' => $staff->division_name,
        'department_name'     => $staff->department_name,
        'incentive_value'     => $points,
        'incentive_cal'       => $calculations,
        'incentive_type' => [  // Specify which incentives are gold-based
          'presale' => 'gold',
          'megabonus' => 'gold',
          'tenxaward' => 'gold',  // if 10X award is also gold
        ]
      ];
    }
    return response()->json([
      'status' => 200,
      'data' => $result
    ]);
  }

   private function calculate10xAward($goalset, $targets, $startDate, $endDate, $branchId, $incentive, $year, $month)
  {
    $calculation = [
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'target_label' => 'Monthly Target & Registrations'
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    // overall
      $helper = new \App\Helpers\Helpers();

      $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

         $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0; // final net after GST

        $total_collection_value = 0;
          
         $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code')
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
            $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
            $total_collection_value += $netAmountInr;
        }
            
          
        
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);

    
   
    $customerConvertData = DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                      ->whereRaw('et_payment.transaction_date = (
                          SELECT MIN(ep.transaction_date)
                          FROM et_payment ep
                          WHERE ep.customer_id = et_customer.sno
                      )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
              ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->where('et_proposal.post_sale_check', 0)
            ->where('et_customer.branch_id', $branchId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->where('et_lead.created_by', '>',0)
            ->orderBy('et_customer.sno', 'asc')
            ->get();
           
            $presaleCount =count($customerConvertData);

          $customerConvertDataPost = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                     ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.proposal_id = et_proposal.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', '>',1)
            ->whereYear('et_payment.transaction_date',  date('Y'))
            ->whereMonth('et_payment.transaction_date', date('m'))
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->distinct('et_customer.sno')
            ->get();
          $postSaleCount =count($customerConvertDataPost);

   

    // Get presale customers
    $presaleCustomers = DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                      ->whereRaw('et_payment.transaction_date = (
                          SELECT MIN(ep.transaction_date)
                          FROM et_payment ep
                          WHERE ep.customer_id = et_customer.sno
                      )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
              ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->where('et_proposal.post_sale_check', 0)
            ->where('et_customer.branch_id', $branchId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->where('et_lead.created_by', '>',0)
            ->orderBy('et_customer.sno', 'asc')
            ->pluck('et_customer.sno')
            ->toArray();

    // Get postsale customers
    $postsaleCustomers =DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                     ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.proposal_id = et_proposal.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', '>',1)
            ->whereYear('et_payment.transaction_date',  date('Y'))
            ->whereMonth('et_payment.transaction_date', date('m'))
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->distinct('et_customer.sno')
            ->toArray();

    // Calculate for presale customers
    $presaleTotalOverallFees = 0;
    $presaleTotalCredit = 0;

    // if (!empty($presaleCustomers)) {
    //   $presaleTotalOverallFees = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
    //     ->whereIn('za_customer.customer_id', $presaleCustomers)
    //     ->sum('za_training.overall_fees');

    //   $presaleTotalCredit = TransactionModel::where('branch_id', $branchId)
    //     ->whereIn('trans_source_id', $presaleCustomers)
    //     ->whereBetween('transaction_date', [$startDate, $endDate])
    //     ->sum('credit');
    // }

    $presaleABV = ($presaleCount > 0) ? $presaleTotalOverallFees / $presaleCount : 0;
    $presaleACV = ($presaleCount > 0) ? $presaleTotalCredit / $presaleCount : 0;

    // Calculate for postsale customers
    $postsaleTotalOverallFees = 0;
    $postsaleTotalCredit = 0;

    // if (!empty($postsaleCustomers)) {
    //   $postsaleTotalOverallFees = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
    //     ->whereIn('za_training.sno', $postsaleCustomers)
    //     ->sum('za_training.overall_fees');

    //   $postsaleTotalCredit = TransactionModel::where('branch_id', $branchId)
    //     ->whereIn('training_id', $postsaleCustomers)
    //     ->whereBetween('transaction_date', [$startDate, $endDate])
    //     ->sum('credit');
    // }

    $postsaleABV = ($postSaleCount > 0) ? $postsaleTotalOverallFees / $postSaleCount : 0;
    $postsaleACV = ($postSaleCount > 0) ? $postsaleTotalCredit / $postSaleCount : 0;

    // Calculate for overall (combine presale + postsale)
    $totalCustomers = $presaleCount + $postSaleCount;
    $totalOverallFees = $presaleTotalOverallFees + $postsaleTotalOverallFees;
    $totalCreditAll = $presaleTotalCredit + $postsaleTotalCredit;

    $overallABV = ($totalCustomers > 0) ? $totalOverallFees / $totalCustomers : 0;
    $overallACV = ($totalCustomers > 0) ? $totalCreditAll / $totalCustomers : 0;

    $calculation = [
      'target' => [
        'monthly_target' => $targets->monthly_target ?? 0,
        'registrations' => $targets->no_of_registrations ?? 0,
        'post_sale' => $targets->post_sale ?? 0,
        'abv' => $goalset->abv_over_all ?? 0,
        'acv' => $goalset->acv_over_all ?? 0
      ],
      'actual' => [
        'total_credit' => round($totalCredit),
        'presale_count' => $presaleCount,
        'postsale_count' => $postSaleCount,
        'presale' => [
          'count' => $presaleCount,
          'abv_actual' => round($presaleABV, 2),
          'acv_actual' => round($presaleACV, 2),
          'total_overall_fees' => round($presaleTotalOverallFees, 2),
          'total_credit' => round($presaleTotalCredit, 2),
        ],
        'postsale' => [
          'count' => $postSaleCount,
          'abv_actual' => round($postsaleABV, 2),
          'acv_actual' => round($postsaleACV, 2),
          'total_overall_fees' => round($postsaleTotalOverallFees, 2),
          'total_credit' => round($postsaleTotalCredit, 2),
        ],
        'overall' => [
          'count' => $totalCustomers,
          'abv_actual' => round($overallABV, 2),
          'acv_actual' => round($overallACV, 2),
          'total_overall_fees' => round($totalOverallFees, 2),
          'total_credit' => round($totalCreditAll, 2),
        ],
      ],
      'unit' => '₹',
      'target_label' => 'Monthly Target & Registrations',
      'condition_met' => (
        $presaleCount >= ($targets->no_of_registrations ?? 0) &&
        $postSaleCount >= ($targets->post_sale ?? 0) &&
        $totalCredit >= ($targets->monthly_target ?? 0) &&
        $overallABV >= ($goalset->abv_over_all ?? 0) &&
        $overallACV >= ($goalset->acv_over_all ?? 0)
      )
    ];

    // Main condition
    if (
      $presaleCount >= ($targets->no_of_registrations ?? 0) &&
      $totalCredit >= ($targets->monthly_target ?? 0)
    ) {
      return ['value' => $incentive->tenx_award ?? 0, 'calculation' => $calculation];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }

  private function calculate10xAwardOld($targets, $startDate, $endDate, $branchId, $incentive, $year, $month)
  {
    $calculation = [
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'target_label' => 'Monthly Target & Registrations'
    ];


    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }

      $helper = new \App\Helpers\Helpers();
      $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

         $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0; // final net after GST

        $total_collection_value = 0;
          
         $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code')
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
        
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
            $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
        
            $total_collection_value += $netAmountInr;
        }
            
          
        
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);

                $customerConvertData = DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                      ->whereRaw('et_payment.transaction_date = (
                          SELECT MIN(ep.transaction_date)
                          FROM et_payment ep
                          WHERE ep.customer_id = et_customer.sno
                      )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
              ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->where('et_proposal.post_sale_check', 0)
            ->where('et_customer.branch_id', $branchId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->where('et_lead.created_by', '>',0)
            ->orderBy('et_customer.sno', 'asc')
            ->get();
           
            $presaleCount =count($customerConvertData);
        


    $calculation = [
      'target' => [
        'monthly_target' => $targets->monthly_target ?? 0,
        'registrations' => $targets->no_of_registrations ?? 0
      ],
      'actual' => [
        'total_credit' => round($totalCredit),
        'presale_count' => $presaleCount
      ],
      'unit' => '₹',
      'target_label' => 'Monthly Target & Registrations',
      'condition_met' => ($presaleCount >= ($targets->no_of_registrations ?? 0) && $totalCredit >= ($targets->monthly_target ?? 0))
    ];

    // Main condition
    if (
      $presaleCount >= ($targets->no_of_registrations ?? 0) &&
      $totalCredit >= ($targets->monthly_target ?? 0)
    ) {
      return ['value' => $incentive->tenx_award ?? 0, 'calculation' => $calculation];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }

  private function calculateCeiling($targets, $startDate, $endDate, $branchId, $incentive, $year, $month)
  {
    $calculation = [
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'target_label' => 'Monthly Target',
      'profit' => 0,
      'percentage' => 0
    ];

    if (!$targets || !$incentive) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    // $totalCredit = TransactionModel::where('branch_id', $branchId)
    //   ->whereBetween('transaction_date', [$startDate, $endDate])
    //   ->sum('credit');
     $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

         $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0; // final net after GST

         $total_collection_value = 0;
          
         $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code')
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
        
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
            $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
        
            $total_collection_value += $netAmountInr;
        }
            
          
        
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);

    $target = $targets->monthly_target ?? 0;

    $calculation = [
      'target' => $target,
      'actual' => $totalCredit,
      'unit' => '₹',
      'target_label' => 'Monthly Target',
      'profit' => max(0, $totalCredit - $target),
      'percentage' => $incentive->ceiling ?? 0
    ];

    // Only if target achieved
    if ($totalCredit > $target) {
      $profit = $totalCredit - $target;
      $percentage = $incentive->ceiling ?? 0;
      $percentageValue = ($profit * $percentage) / 100;
      $calculation['calculated_value'] = $percentageValue;
      return ['value' => $percentageValue, 'calculation' => $calculation];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }

  private function calculateQuarterly($targets, $branchId, $incentive, $year, $currentMonth)
  {
    $calculation = [
      'eligible_quarter' => null,
      'months' => [],
      'message' => 'Not eligible'
    ];

    // if (!$targets || !$incentive) {
    //   return ['value' => 0, 'calculation' => $calculation];
    // }

    //  Define quarters
    $quarters = [
      1 => [4, 5, 6],   // Q1
      2 => [7, 8, 9],   // Q2
      3 => [10, 11, 12], // Q3
      4 => [1, 2, 3]    // Q4
    ];

    // Map reward month → previous quarter
      $rewardMap = [
        1  => 3,
        2  => 4,
        3  => 4,
        4  => 4,
        5  => 1,
        6  => 1,
        7  => 1,
        8  => 2,
        9  => 2,
        10 => 2,
        11 => 3,
        12 => 3,
      ];

      $quarterKey = $rewardMap[$currentMonth] ?? null;

      if (!$quarterKey) {
          return ['value' => 0, 'calculation' => $calculation];
      }

  
    $months = $quarters[$quarterKey];

    $allAchieved = true;
    $monthData = [];

    foreach ($months as $m) {

      // Handle year change for Q4 (Jan–Mar belongs to NEXT year logic)
      $loopYear = ($quarterKey == 4) ? $year : $year;

      $startDate = Carbon::create($loopYear, $m, 1)->startOfMonth();
      $endDate   = Carbon::create($loopYear, $m, 1)->endOfMonth();

      // $totalCredit = TransactionModel::where('branch_id', $branchId)
      //   ->whereBetween('transaction_date', [$startDate, $endDate])
      //   ->sum('credit');
    
       $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

         $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0; // final net after GST

         $total_collection_value = 0;
          
         $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code')
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
        
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
            $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
        
            $total_collection_value += $netAmountInr;
        }
            
          
        
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);

      $targetsMonth = ManageTargetModel::where('branch_id', $branchId)
        ->whereMonth('date', $m)
        ->whereYear('date', $loopYear)
        ->first();

      $target = $targetsMonth->monthly_target ?? $targets->monthly_target ?? 0;

      $achieved = ($target > 0 && $totalCredit >= $target);

      if (!$achieved) {
        $allAchieved = false;
      }

      $monthData[] = [
        'month' => $m,
        'month_name' => Carbon::create($loopYear, $m, 1)->format('F'),
        'target' => $target,
        'actual' => $totalCredit,
        'achieved' => $achieved
      ];
    }

    $calculation['eligible_quarter'] = "Q{$quarterKey}";
    $calculation['months'] = $monthData;

    // FINAL CHECK (strict 3/3)
    if ($allAchieved) {
      return [
        'value' => $incentive->quarterly ?? 0,
        'calculation' => $calculation
      ];
    }

    return [
      'value' => 0,
      'calculation' => $calculation
    ];
  }

  private function calculatePercentage($targets, $startDate, $endDate, $branchId, $incentive, $year, $month, $percent)
  {
      $calculation = [
        'target' => 0,
        'actual' => 0,
        'unit' => '₹',
        'target_label' => "{$percent}% Achievement",
        'achievement_percent' => 0,
        'applied_slab' => 'below_target'
      ];
      
        // if (!$targets || !$incentive) {
        //   return ['value' => 0, 'calculation' => $calculation];
        // }

          $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

         $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0; // final net after GST

         $total_collection_value = 0;
          
         $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code')
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
        
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
            $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
        
            $total_collection_value += $netAmountInr;
        }
            
          
        
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);

    $target = $targets->monthly_target ?? 0;

    if ($target <= 0) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    // $achievementPercent = ($totalCredit / $target) * 100;
    $achievementPercent = ($target > 0) ? ($totalCredit / $target) * 100 : 0;

    $calculation = [
      'target' => $target,
      'actual' => $totalCredit,
      'unit' => '₹',
      'target_label' => "{$percent}% Achievement",
      'achievement_percent' => round($achievementPercent, 2),
      'profit' => max(0, $totalCredit - $target)
    ];

    if ($percent == 25 && $achievementPercent >= 50) {
      return [
        'value' => 0,
        'calculation' => [
          'target' => $target,
          'actual' => $totalCredit,
          'unit' => '₹',
          'target_label' => "25% Achievement (blocked by 50%)",
          'achievement_percent' => round($achievementPercent, 2),
          'applied_slab' => 'blocked_by_50_percent'
        ]
      ];
    }

    // Only if target achieved
    if ($totalCredit > $target) {
      $profit = $totalCredit - $target;
 
      // Apply slab logic
      if ($achievementPercent >= 50) {
        $percentage = $incentive->fifty_percentage ?? 0;
        $calculation['applied_slab'] = '50%_slab';
        $calculation['slab_percentage'] = $percentage;
      } else {
        $percentage = $incentive->twenty_five_percentage ?? 0;
        $calculation['applied_slab'] = '25%_slab';
        $calculation['slab_percentage'] = $percentage;
      }
 
      $percentageValue = ($profit * $percentage) / 100;
      $calculation['calculated_value'] = $percentageValue;
      return ['value' => $percentageValue, 'calculation' => $calculation];
    }
 
    $calculation['applied_slab'] = 'target_not_achieved';
    return ['value' => 0, 'calculation' => $calculation];
  }

  



    private function calculateMonthBased($targets, $branchId, $incentive, $year, $months)
  {
    $calculation = [
      'target_label' => "{$months} Month Achievement (FY Apr–Mar)",
      'months_achieved' => 0,
      'required_months' => $months,
      'monthly_breakdown' => []
    ];
 
    // if (!$targets || !$incentive) {
    //   return ['value' => 0, 'calculation' => $calculation];
    // }
 
    $startMonth = 4; // April
 
    $achievedMonths = 0;
    $monthlyBreakdown = [];
 
    for ($i = 0; $i < 12; $i++) {
 
      $m = (($startMonth + $i - 1) % 12) + 1;
      $fyYear = ($m >= 4) ? $year : $year + 1;
 
      $startDate = Carbon::create($fyYear, $m, 1)->startOfMonth();
      $endDate   = Carbon::create($fyYear, $m, 1)->endOfMonth();
 
      $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

         $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0; // final net after GST

         $total_collection_value = 0;
          
         $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code')
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
        
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
            $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
        
            $total_collection_value += $netAmountInr;
        }
            
          
        
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);
 
      $target = ManageTargetModel::where('branch_id', $branchId)
        ->whereMonth('date', $m)
        ->whereYear('date', $fyYear)
        ->first()
        ->monthly_target ?? 0;
 
      $achieved = ($target > 0 && $totalCredit >= $target);
 
      if ($achieved) {
        $achievedMonths++;
      }
 
      $monthlyBreakdown[] = [
        'month' => $m,
        'year' => $fyYear,
        'month_name' => Carbon::create($fyYear, $m, 1)->format('F'),
        'target' => $target,
        'actual' => $totalCredit,
        'achieved' => $achieved
      ];
    }
 
    $calculation['months_achieved'] = $achievedMonths;
    $calculation['monthly_breakdown'] = $monthlyBreakdown;
 
    if ($achievedMonths >= 12) {
      return [
        'value' => $incentive->twelve_month ?? 0,
        'calculation' => $calculation
      ];
    }
 
    if ($achievedMonths >= 6) {
      return [
        'value' => $incentive->six_month ?? 0,
        'calculation' => $calculation
      ];
    }
 
    return [
      'value' => 0,
      'calculation' => $calculation
    ];
  }

  

  private function calculateMonthAdd($targets, $branchId, $incentive, $year, $months)
  {
    $calculation = [
      'target_label' => "{$months} Month Add-on (FY Apr–Mar)",
      'months_achieved' => 0,
      'monthly_breakdown' => []
    ];
 
    // if (!$targets || !$incentive) {
    //   return ['value' => 0, 'calculation' => $calculation];
    // }
 
    $startMonth = 4; // April
    $achievedMonths = 0;
    $monthlyBreakdown = [];
 
    for ($i = 0; $i < 12; $i++) {
 
      $m = (($startMonth + $i - 1) % 12) + 1;
 
      // financial year mapping
      $fyYear = ($m >= 4) ? $year : $year + 1;
 
      $startDate = Carbon::create($fyYear, $m, 1)->startOfMonth();
      $endDate   = Carbon::create($fyYear, $m, 1)->endOfMonth();
 
      $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

         $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0; // final net after GST

         $total_collection_value = 0;
          
         $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code')
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
        
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
            $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
        
            $total_collection_value += $netAmountInr;
        }
            
          
        
        // Final net collection (matches verified_collection_net style)
        $totalCredit = round($total_collection_value);
 
      $targetsMonth = ManageTargetModel::where('branch_id', $branchId)
        ->whereMonth('date', $m)
        ->whereYear('date', $fyYear)
        ->first();
 
      $target = $targetsMonth->monthly_target ?? 0;
 
      $achieved = ($target > 0 && $totalCredit >= $target);
 
      if ($achieved) {
        $achievedMonths++;
      }
 
      $monthlyBreakdown[] = [
        'month' => $m,
        'year' => $fyYear,
        'month_name' => Carbon::create($fyYear, $m, 1)->format('F'),
        'target' => $target,
        'actual' => $totalCredit,
        'achieved' => $achieved
      ];
    }
 
    $calculation['months_achieved'] = $achievedMonths;
    $calculation['monthly_breakdown'] = $monthlyBreakdown;
 
    if ($achievedMonths >= 12) {
      return ['value' => $incentive->twelve_monthadd ?? 0, 'calculation' => $calculation];
    }
 
    if ($achievedMonths >= 9) {
      return ['value' => $incentive->nine_monthadd ?? 0, 'calculation' => $calculation];
    }
 
    return ['value' => 0, 'calculation' => $calculation];
  }

  private function calculateOverallYear($targets, $branchId, $incentive, $year)
  {
    $calculation = [
      'target_label' => 'Overall Year (150%)',
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'achievement_percent' => 0
    ];

    // if (!$targets || !$incentive) {
    //   return ['value' => 0, 'calculation' => $calculation];
    // }

    // Year start & end
    $startDate = Carbon::create($year, 1, 1)->startOfYear();
    $endDate   = Carbon::create($year, 12, 31)->endOfYear();

    // Total yearly credit
    // $yearTotal = TransactionModel::where('branch_id', $branchId)
    //   ->whereBetween('transaction_date', [$startDate, $endDate])
    //   ->sum('credit');
      

          $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

         $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0; // final net after GST

         $total_collection_value = 0;
          
         $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code')
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
        
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
            $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
        
            $total_collection_value += $netAmountInr;
        }
            
          
        
        // Final net collection (matches verified_collection_net style)
        $yearTotal = round($total_collection_value);

    // Year target (monthly × 12)
    $yearTarget = ($targets->monthly_target ?? 0) * 12;

    $calculation = [
      'target_label' => 'Overall Year (150%)',
      'target' => $yearTarget,
      'actual' => $yearTotal,
      'unit' => '₹',
      'achievement_percent' => $yearTarget > 0 ? round(($yearTotal / $yearTarget) * 100, 2) : 0
    ];

    if ($yearTarget <= 0) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    $achievementPercent = ($yearTotal / $yearTarget) * 100;

    // Condition: 150% or more
    if ($achievementPercent >= 150) {
      return ['value' => $incentive->overall_year ?? 0, 'calculation' => $calculation];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }

  private function calculateDynamic($staff)
  {
    return ['value' => 0, 'calculation' => ['message' => 'Dynamic logic pending']];
  }

  private function calculatePresale($targets, $branchId, $incentive, $year)
  {
    $calculation = [
      'target_label' => 'Presale (150% of Yearly Registrations)',
      'target' => 0,
      'actual' => 0,
      'unit' => 'registrations',
      'achievement_percent' => 0
    ];

    // if (!$targets || !$incentive) {
    //   return ['value' => 0, 'calculation' => $calculation];
    // }

    // Total yearly presale count
    // $yearCount = CustomerModel::whereIn('status', [0, 6])
    //   ->where('post_sale_check', '!=', 1)
    //   ->where('branch_id', $branchId)
    //   ->whereYear('created_at', $year)
    //   ->count();

              $customerConvertData = DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                      ->whereRaw('et_payment.transaction_date = (
                          SELECT MIN(ep.transaction_date)
                          FROM et_payment ep
                          WHERE ep.customer_id = et_customer.sno
                      )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
              ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->where('et_proposal.post_sale_check', 0)
            ->where('et_customer.branch_id', $branchId)
            ->whereYear('et_payment.transaction_date', $year)
            // ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->where('et_lead.created_by', '>',0)
            ->orderBy('et_customer.sno', 'asc')
            ->get();
            
            $yearCount =count($customerConvertData);

    // Year target (monthly registrations × 12)
    $yearTarget = ($targets->no_of_registrations ?? 0) * 12;

    $calculation = [
      'target_label' => 'Presale (150% of Yearly Registrations)',
      'target' => $yearTarget,
      'actual' => $yearCount,
      'unit' => 'registrations',
      'achievement_percent' => $yearTarget > 0 ? round(($yearCount / $yearTarget) * 100, 2) : 0
    ];

    if ($yearTarget <= 0) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    $achievementPercent = ($yearCount / $yearTarget) * 100;

    // Condition: 150% or more
    if ($achievementPercent >= 150) {
      return ['value' => $incentive->presale ?? 0, 'calculation' => $calculation];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }

  private function calculateMegaBonus($targets, $branchId, $incentive, $year)
  {
    $calculation = [
      'target_label' => 'Mega Bonus (200% of Yearly Target)',
      'target' => 0,
      'actual' => 0,
      'unit' => '₹',
      'achievement_percent' => 0
    ];

    // if (!$targets || !$incentive) {
    //   return ['value' => 0, 'calculation' => $calculation];
    // }

    // Year range
    $startDate = Carbon::create($year, 1, 1)->startOfYear();
    $endDate   = Carbon::create($year, 12, 31)->endOfYear();

    // Total yearly credit
    // $yearTotal = TransactionModel::where('branch_id', $branchId)
    //   ->whereBetween('transaction_date', [$startDate, $endDate])
    //   ->sum('credit');

       

          $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

         $gstPercentage = $branch ? $branch->gst_percentage  : 18;
        $transactionTotalNet = 0; // final net after GST

         $total_collection_value = 0;
          
         $allVerified = DB::table('et_transaction')
            ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_transaction.payment_status',1)
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by','>',1)
            ->where('et_lead.status','!=',2)
            ->where('et_customer.status',0)
            ->where('et_customer.branch_id',$branchId)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                     'et_proposal.gst_perc','et_country_currencies.currency_code')
            ->get();
        
        foreach ($allVerified as $row) {
            // Determine INR value
            if ($row->total_amount_inr > 0) {
                $convertedPaidAmountInr = $row->total_amount_inr;
            } else {
                $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
            }
        
            // Use transaction GST%
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($gstPercentage/100);
            $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
        
            $total_collection_value += $netAmountInr;
        }
            
          
        
        // Final net collection (matches verified_collection_net style)
        $yearTotal =round($total_collection_value);

    // Year target
    $yearTarget = ($targets->monthly_target ?? 0) * 12;

    $calculation = [
      'target_label' => 'Mega Bonus (200% of Yearly Target)',
      'target' => $yearTarget,
      'actual' => $yearTotal,
      'unit' => '₹',
      'achievement_percent' => $yearTarget > 0 ? round(($yearTotal / $yearTarget) * 100, 2) : 0
    ];

    if ($yearTarget <= 0) {
      return ['value' => 0, 'calculation' => $calculation];
    }

    $achievementPercent = ($yearTotal / $yearTarget) * 100;

    // 200% condition (DOUBLE target)
    if ($achievementPercent >= 200) {
      return ['value' => $incentive->megabonus ?? 0, 'calculation' => $calculation];
    }

    return ['value' => 0, 'calculation' => $calculation];
  }


}
