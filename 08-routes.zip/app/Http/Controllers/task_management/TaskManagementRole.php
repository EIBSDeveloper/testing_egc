<?php

namespace App\Http\Controllers\task_management;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\BusinessGoalSetModel;
use App\Models\TaskManagementModel;
use App\Models\AttendanceModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use App\Models\ManageCoursesModel;
use App\Events\TaskCreatedEvent;
use Illuminate\Support\Collection;
class TaskManagementRole extends Controller
{
   public function index(Request $request)
   {
    $branch_id = $request->user()->branch_id;
    $perpage = $request->input('perpage', 25); // default 25
    $cus_fill = $request->input('cus_fill');

    $query = \DB::table('za_task as t')
        ->leftJoin('et_staff as s', 't.staff_id', '=', 's.sno')
        ->select(
            't.*',
            's.staff_name',
            's.nick_name',
            's.gender',
            's.staff_image'
        )
        ->where('t.branch_id', $branch_id);

    // Optional search by task_name
    if (!empty($cus_fill)) {
        $query->where('t.task_name', 'like', "%$cus_fill%");
    }

    $task = $query->paginate($perpage); // 🔁 paginated now

    foreach ($task as $t) {
        $t->task_date_formatted = $t->task_date ? \Carbon\Carbon::parse($t->task_date)->format('d-M-Y h:i A') : null;
        $t->task_completed_date_formatted = $t->task_completed_date ? \Carbon\Carbon::parse($t->task_completed_date)->format('d-M-Y h:i A') : null;
    }

    return view('content.task_management.task_list', compact('task', 'perpage', 'cus_fill'));
}

    public function taskStaff(Request $request)
     {
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;

    // Step 1: Get current staff
    $currentStaff = StaffModel::where('sno', $user_id)->first();
    if (!$currentStaff) {
        return response()->json(['message' => 'Staff not found'], 404);
    }

    // Step 2: Get role's user_role_id (not sno!)
    $currentRole = \DB::table('et_user_role')->where('sno', $currentStaff->role_id)->first();
    if (!$currentRole || !$currentRole->sno) {
        return response()->json(['message' => 'User role not valid'], 404);
    }

    $startingUserRoleId = $currentRole->sno;

    // Step 3: Fetch all roles
    $allRoles = \DB::table('et_user_role')->get();

    // Step 4: Collect child role user_role_ids
    $collectedUserRoleIds = collect();
    $visited = [];
    
    $collectChildRoles = function ($parentUserRoleId) use (&$collectChildRoles, $allRoles, &$collectedUserRoleIds, &$visited) {
        if (in_array($parentUserRoleId, $visited)) return;
        $visited[] = $parentUserRoleId;
    
        foreach ($allRoles as $role) {
            if ($role->map_under == 1 && $role->user_role_id !== null) {
                $collectedUserRoleIds->push($role->user_role_id);
                $collectChildRoles($role->user_role_id);
            }
        }
    };

    $collectChildRoles($startingUserRoleId);
    $collectedUserRoleIds->push($startingUserRoleId); // include own role

    // Step 5: Get staff with matching roles (user_role_id → match via et_user_role.user_role_id)
    $staffList = StaffModel::select('et_staff.*', 'et_user_role.role_name','et_department.department_name')
        ->leftJoin('et_user_role', 'et_user_role.sno', '=', 'et_staff.role_id')
        ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
        ->where('et_staff.branch_id', $branch_id)
        ->where('et_staff.status', 0)
        ->whereIn('et_user_role.user_role_id', $collectedUserRoleIds->unique())
        ->get();
    $groupedStaff = $staffList->groupBy('department_id')->map(function ($staffInDept) {
    return $staffInDept->map(function ($staff) {
        return [
            'sno'         => $staff->sno,
            'staff_name'  => $staff->staff_name,
            'role_name'   => $staff->role_name,
            'department_id'   => $staff->department_id,
            'department_name' => $staff->department_name, // make sure it's available
        ];
    })->values();
});

    return response()->json([
        'message' => 'Staff fetched successfully.',
        'data' => $groupedStaff 
    ]);
}
  

    public function createTask(Request $request)
    {
    $branch_id = $request->user()->branch_id;

    $validated = $request->validate([
        'task_name'   => 'required|string|max:255',
        'staff_ids'   => 'required|array|min:1',
        'staff_ids.*' => 'integer|exists:et_staff,sno',
        'task_date'   => 'required',
        'priority'    => 'required|in:High,Medium,Low',
        'description' => 'nullable|string|max:1000',
    ]);

    $taskDate = Carbon::createFromFormat('d-M-Y h:i A', $validated['task_date'])->format('Y-m-d H:i:s');

    foreach ($validated['staff_ids'] as $staffId) {
        $taskId = DB::table('za_task')->insertGetId([
            'task_name'            => $validated['task_name'],
            'staff_id'             => $staffId,
            'branch_id'            => $branch_id,
            'task_date'            => $taskDate,
            'task_priority'        => $validated['priority'],
            'task_description'     => $validated['description'] ?? null,
            'task_approval'        => 0,
            'task_completed_status'=> 0,
            'created_by'           => $request->user()->user_id,
            'updated_by'           => $request->user()->user_id,
        ]);

        // Fetch the inserted task
        $task = DB::table('za_task')->where('sno', $taskId)->first();

        // Format date (optional)
        $task->task_date_formatted = $task->task_date 
            ? Carbon::parse($task->task_date)->format('d-M-Y h:i A') 
            : null;

        // Fire event per task
        event(new TaskCreatedEvent($task));
    }

    return response()->json(['message' => 'Task created successfully.'], 200);
}

    public function taskList(Request $request)
    {
        $user_id = $request->user()->user_id;
    
        $tasks = \DB::table('za_task')
            ->where('staff_id', $user_id)
            ->where('status', 0)
            ->orderBy('task_date', 'asc')
            ->get();
    
        // Format the date fields
        foreach ($tasks as $task) {
            $task->task_date_formatted = $task->task_date 
                ? \Carbon\Carbon::parse($task->task_date)->format('d-M-Y h:i A') 
                : null;
    
            $task->task_completed_date_formatted = $task->task_completed_date 
                ? Carbon::parse($task->task_completed_date)->format('d-M-Y') 
                : null;
        }
    
        return response()->json([
            'message' => 'Task list fetched successfully.',
            'data'    => $tasks
        ]);
    }
    public function markCompleted(Request $request)
     {
        $request->validate([
            'task_id' => 'required|integer|exists:za_task,sno',
            'is_checked' => 'required|in:0,1',
        ]);
    
        \DB::table('za_task')
            ->where('sno', $request->task_id)
            ->update(['task_completed_status' => $request->is_checked]);
    
        return response()->json([
            'status' => true,
            'message' => $request->is_checked ? 'Task marked as completed' : 'Task marked as incomplete'
        ]);
    }
    
      public function approveTask(Request $request)
    {
        $taskId = $request->input('task_id');
    
        // Update the task
        DB::table('za_task')
            ->where('sno', $taskId)
            ->where('staff_id', $request->user()->user_id)
            ->update(['task_approval' => 1]);
    
        // Fetch the updated task
        $task = DB::table('za_task')->where('sno', $taskId)->first();
    
        // Optional: Format for broadcasting
        if ($task && $task->task_date) {
            $task->task_date_formatted = \Carbon\Carbon::parse($task->task_date)->format('d-M-Y h:i A');
        }
    
        // Fire event
        event(new TaskCreatedEvent($task));
    
        return response()->json([
            'status' => true,
            'message' => 'Task approved.'
        ]);
    }

    public function editTask(Request $request, $id)
    {
        $branch_id = $request->user()->branch_id;
    
        $task = \DB::table('za_task')
            ->where('branch_id', $branch_id)
            ->where('sno', $id)
            ->first();
    
        if (!$task) {
            return response()->json(['status' => false, 'message' => 'Task not found.']);
        }
    
        return response()->json([
            'status' => true,
            'data'   => $task
        ]);
    }
    
    public function updateTask(Request $request, $id)
    {
        $validated = $request->validate([
            'task_name'   => 'required|string|max:255',
            'staff_id'   => 'required',
            'task_date'   => 'required',
            'task_priority' => 'required',
            'task_description' => 'nullable',
        ]);
    
        $updated = \DB::table('za_task')
            ->where('sno', $id)
            ->update([
                'task_name'        => $validated['task_name'],
                'staff_id'         => $validated['staff_id'],
                'task_date'        => $validated['task_date'],
                'task_priority'    => $validated['task_priority'],
                'task_description' => $validated['task_description'] ?? null,
                'updated_by'       => $request->user()->user_id,
            ]);
    
        return response()->json([
            'status'  => true,
            'message' => $updated ? 'Task updated successfully.' : 'No changes made or task not found.'
        ]);
    }
    public function delete($id)
    {
        TaskManagementModel::where('sno', $id)->update(['status' => 2]);
    
        return response()->json(['success' => true]);
    }
    
   public function markComplete($id)
    {
        TaskManagementModel::where('sno', $id)->update(['status' => 1]);
        return response()->json(['success' => true]);
    }
    
    public function markReopen($id)
    {
        TaskManagementModel::where('sno', $id)->update(['task_reopen' => 1,'task_completed_status' => 0,'task_completed_date' => null]);
        return response()->json(['success' => true]);
    }




}