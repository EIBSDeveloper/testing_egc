<?php
namespace App\Http\Controllers\monitor_tool;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CustomerModel;
use App\Models\DropReasonModel;
use App\Models\FollowupReasonModel;
use App\Models\InternalReasonModel;
use App\Models\LeadMetricsModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use Illuminate\Support\Facades\Cache;
use Illuminate\Pagination\LengthAwarePaginator;
class CallLog extends Controller
{
  public function index(Request $request)
  {
    $user_id = $request->user()->user_id;
    // if($user_id!=0){
    //     return view('content.working_on_progress');
    // }
      $month_filter = $request->get('month_filter', date('M-Y'));
            $parsedDate   = Carbon::createFromFormat('M-Y', $month_filter);
        
            $page      = $request->input('page', 1);
            $perpage   = (int) $request->input('sorting_filter', 25);
            $branch_id = $request->user()->branch_id;
            $user_id   = $request->user()->user_id;
        
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        
            $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
        
            // Staff list cache
            $staff_list = Cache::remember("staff_list_branch_{$branch_id}", 300, function () {
                return DB::table('et_cug_management')
                    ->select(
                        'et_cug_management.staff_id',
                        'et_staff.staff_name',
                        'et_staff.nick_name',
                        'et_staff.staff_image',
                        'et_staff.gender',
                        'et_staff.mobile_no'
                    )
                    ->join('et_staff', 'et_staff.sno', '=', 'et_cug_management.staff_id')
                    ->where('et_staff.status', '!=', 2)
                    ->distinct()
                    ->get();
            });
        
            // Filters
            $call_fill        = $request->input('call_fill', '');
            $staff_fill       = $request->input('staff_fill', '');
            $status_fill      = $request->input('status_fill', '');
            $from_date_filter = $request->input('from_date_fillter_textbox');
            $to_date_filter   = $request->input('to_date_fillter_textbox');
        
            $startTime = microtime(true);
        
            /**
             * Step 1: Query only IDs for pagination
             */
            $callIdQuery = DB::table('et_call_tracker')
                ->where('et_call_tracker.branch_id', $branch_id);
        
            // Month filter (only if no date range is given)
            if (!$from_date_filter && !$to_date_filter) {
                $callIdQuery->whereYear('et_call_tracker.call_start_date', $year)
                    ->whereMonth('et_call_tracker.call_start_date', $month);
            }
        
            // Date range filter
            if ($from_date_filter && $to_date_filter) {
                $callIdQuery->whereBetween('et_call_tracker.call_start_date', [$from_date_filter, $to_date_filter]);
            }
        
            // Permission check
            if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Calls', 'view_self_lead')) {
                $callIdQuery->where('et_call_tracker.branch_staff_id', $user_id);
            }
        
            if ($status_fill !== '') {
                $callIdQuery->where('et_call_tracker.call_status', $status_fill);
            }
            if ($staff_fill) {
                $callIdQuery->where('et_call_tracker.branch_staff_id', $staff_fill);
            }
            if ($call_fill != '') {
                $callIdQuery->join('et_staff', 'et_staff.sno', '=', 'et_call_tracker.branch_staff_id')
                    ->where(function ($query) use ($call_fill) {
                        $query->where('et_call_tracker.customer_phone_no', 'LIKE', "%{$call_fill}%")
                            ->orWhere('et_call_tracker.staff_phone_no', 'LIKE', "%{$call_fill}%")
                            ->orWhere('et_staff.staff_name', 'LIKE', "%{$call_fill}%")
                            ->orWhere('et_staff.nick_name', 'LIKE', "%{$call_fill}%")
                            ->orWhere('et_call_tracker.customer_name', 'LIKE', "%{$call_fill}%");
                    });
            }
        
            // Get paginated IDs
            $paginatedIds = $callIdQuery
                ->orderBy('et_call_tracker.call_start_date', 'desc')
                ->orderBy('et_call_tracker.call_start_time', 'desc')
                ->paginate($perpage, ['et_call_tracker.sno']);
        
            $callIds = $paginatedIds->pluck('sno')->toArray();
        
            /**
             * Step 2: Fetch full data with same filters
             */
            $calls = DB::table('et_call_tracker')
                ->select(
                    'et_call_tracker.call_status',
                    'et_call_tracker.sno',
                    'et_call_tracker.staff_phone_no',
                    'et_call_tracker.customer_name',
                    'et_call_tracker.customer_phone_no',
                    'et_call_tracker.call_start_date',
                    'et_call_tracker.call_start_time',
                    'et_call_tracker.call_end_time',
                    'et_call_tracker.call_duration',
                    'et_call_tracker.latitude',
                    'et_call_tracker.longitude',
                    'et_lead.lead_name',
                    'et_lead.drop_verified',
                    'et_lead.drop_tl_verified',
                    'et_lead.spam_verified',
                    'et_lead.spam_tl_verified',
                    'et_lead.status AS lead_status',
                    'et_staff.staff_name',
                    'sb.staff_name AS lead_staff',
                    'et_Internal_cugs.user_name as internal_user_name',
                    'et_lead.created_by',
                    'et_department.department_name',
                    'et_department.sno as dept_id',
                    'et_job_position.job_position_name'
                )
                ->join('et_staff', 'et_staff.sno', '=', 'et_call_tracker.branch_staff_id')
                ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                ->join('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
                ->leftJoin('et_lead', function ($join) {
                    $join->on('et_lead.lead_mobile', '=', DB::raw("RIGHT(et_call_tracker.customer_phone_no, 10)"));
                })
                ->leftJoin('et_Internal_cugs', function ($join) {
                    $join->on('et_Internal_cugs.cug_mobile_no', '=', DB::raw("RIGHT(et_call_tracker.customer_phone_no, 10)"));
                })
                ->leftJoin('et_staff as sb', 'sb.sno', '=', 'et_lead.created_by')
                ->whereIn('et_call_tracker.sno', $callIds)
                ->orderBy('et_call_tracker.call_start_date', 'desc')
                ->orderBy('et_call_tracker.call_start_time', 'desc')
                ->get();
        
            /**
             * Step 3: Aggregate counts
             */
            $call_counts = DB::table('et_call_tracker')
                ->selectRaw('
                    COUNT(CASE WHEN call_status = 1 THEN 1 END) as incoming_call_count,
                    COUNT(CASE WHEN call_status = 0 THEN 1 END) as outgoing_call_count,
                    COUNT(CASE WHEN call_status = 2 THEN 1 END) as missedcall_count,
                    COUNT(CASE WHEN call_status = 3 THEN 1 END) as rejected_call_count,
                    COUNT(CASE WHEN call_status = 4 THEN 1 END) as dialedcall_count
                ')
                ->where('branch_id', $branch_id)
                ->whereYear('call_start_date', $year)
                ->whereMonth('call_start_date', $month);
        
            if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Calls', 'view_self_lead')) {
                $call_counts->where('branch_staff_id', $user_id);
            }
            if ($staff_fill) {
                $call_counts->where('branch_staff_id', $staff_fill);
            }
            if ($status_fill !== '') {
                $call_counts->where('call_status', $status_fill);
            }
        
            $call_counts = $call_counts->first();
        
            $incoming_call_count = $call_counts->incoming_call_count ?? 0;
            $outgoingcall_count  = $call_counts->outgoing_call_count ?? 0;
            $missedcall_count    = $call_counts->missedcall_count ?? 0;
            $rejected_call_count = $call_counts->rejected_call_count ?? 0;
            $dialedcall_count    = $call_counts->dialedcall_count ?? 0;
        
            $missed_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count > 0)
                ? ($missedcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count)) * 100
                : 0;
        
            $outgoing_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count > 0)
                ? ($outgoingcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count)) * 100
                : 0;
        
            $reasonList = SpamReasonModel::where('status', 0)
                ->orderBy('sno', 'desc')
                ->get();
        
            /**
             * Step 4: Fetch loginData (mysql_secondary)
             */
            $staffPhones = $calls->pluck('staff_phone_no')->filter()->unique()->values();
        
            $loginData = DB::connection('mysql_secondary')
                ->table('user as u')
                ->select('u.phone_no', 'u.last_sync_date', 'u.last_sync_time')
                ->whereIn('u.phone_no', $staffPhones)
                ->get()
                ->keyBy('phone_no');
        
            // If you want to debug just like indexold
            // if ($user_id == 0) {
            //     return $loginData;
            // }
        
            $callsPaginator = new LengthAwarePaginator(
                $calls,
                $paginatedIds->total(),
                $paginatedIds->perPage(),
                $paginatedIds->currentPage(),
                ['path' => request()->url(), 'query' => request()->query()]
            );
        
            return view('content.monitor_tool.call_log.call_log', [
                'calls'               => $callsPaginator,
                'month_chk'           => $month_chk,
                'month'               => $month,
                'year'                => $year,
                'staff_list'          => $staff_list,
                'staff_fill'          => $staff_fill,
                'month_filter'        => $month_filter,
                'call_fill'           => $call_fill,
                'perpage'             => $perpage,
                'reasonList'          => $reasonList,
                'incoming_call_count' => $incoming_call_count,
                'outgoingcall_count'  => $outgoingcall_count,
                'missedcall_count'    => $missedcall_count,
                'rejected_call_count' => $rejected_call_count,
                'dialedcall_count'    => $dialedcall_count,
                'missed_call_ratio'   => $missed_call_ratio,
                'outgoing_call_ratio' => $outgoing_call_ratio,
                'status_fill'         => $status_fill,
                'lastLoginDataMap'    => $loginData,
            ]);
    
  }
  
 public function List(Request $request, $month = null, $year = null)
{
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $year = $request->get('year', $year ?? date('Y'));
    $month = $request->get('month', $month ?? date('m'));

    $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
    $lead_fill = $request->input('lead_fill', '');

    // Base staff query
    $salesStaff = DB::table('et_staff')
        ->select(
            'et_staff.sno',
            'et_staff.staff_name',
            'et_staff.staff_image',
            'et_staff.gender',
            'et_staff.mobile_no',
            'et_staff.lead_bank_count',
            'et_staff.status as staff_status',
            'et_cug_management.staff_mobile as cug_mobile',
            'et_department.department_name',
            'et_department.sno as dept_id',
            'et_job_position.job_position_name'
        )
        ->join('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
        ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
        ->join('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
        ->where('et_staff.branch_id', $branch_id)
        ->where('et_cug_management.status', 0)
        ->where(function ($query) use ($year, $month) {
            $query->where(function ($query) use ($year, $month) {
                    $query->where('et_staff.status', 4)
                        ->whereYear('et_staff.notice_end_date', '>=', $year)
                        ->whereMonth('et_staff.notice_end_date', '>=', $month);
                })
                ->orWhere(function ($query) use ($year, $month) {
                    $query->where('et_staff.status', 5)
                        ->whereYear('et_staff.updated_at', '>=', $year)
                        ->whereMonth('et_staff.updated_at', '>=', $month);
                })
                ->orWhere(function ($query) use ($year, $month) {
                    $query->where('et_staff.status', 6)
                        ->whereYear('et_staff.staff_last_date', '>=', $year)
                        ->whereMonth('et_staff.staff_last_date', '>=', $month);
                })
                ->orWhere(function ($query) use ($year, $month) {
                    $query->where('et_staff.status', 7)
                        ->whereYear('et_staff.updated_at', '>=', $year)
                        ->whereMonth('et_staff.updated_at', '>=', $month);
                })
                ->orWhere('et_staff.status', 0);
        });

    if ($lead_fill != '') {
        $salesStaff->where(function ($query) use ($lead_fill) {
            $query->where('staff_name', 'LIKE', "%{$lead_fill}%")
                ->orWhere('nick_name', 'LIKE', "%{$lead_fill}%")
                ->orWhere('mobile_no', 'LIKE', "%{$lead_fill}%")
                ->orWhere('email_id', 'LIKE', "%{$lead_fill}%");
        });
    }

    $salesStaff = $salesStaff->orderBy('sno', 'desc')->paginate($perpage);

    // Date range
    $startDate = Carbon::create($year, $month, 1);
    $currentDate = Carbon::now();
    $endDate = ($currentDate->year == $year && $currentDate->month == $month)
        ? $currentDate
        : $startDate->copy()->endOfMonth();
    $dayCount = $startDate->diffInDays($endDate) + 1;

    // --- Call Stats ---
    $callData = DB::table('et_call_tracker')
        ->select(
            'branch_staff_id',
            DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming_call_count"),
            DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoingcall_count"),
            DB::raw("SUM(CASE WHEN call_status = 2 THEN 1 ELSE 0 END) AS missedcall_count"),
            DB::raw("SUM(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected_call_count"),
            DB::raw("SUM(CASE WHEN customer_status = 0 THEN 1 ELSE 0 END) AS unknown_count")
        )
        ->whereYear('call_start_date', $year)
        ->whereMonth('call_start_date', $month)
        ->whereIn('branch_staff_id', $salesStaff->pluck('sno')->toArray())
        ->groupBy('branch_staff_id')
        ->get()
        ->keyBy('branch_staff_id');

    // Totals
    $total_incoming_call_count = $total_outgoingcall_count = $total_missedcall_count = $total_rejected_call_count = $total_unknown_count = 0;

    // instantiate helper for last-login lookups
    $helper = new \App\Helpers\Helpers();

    $salesStaff->getCollection()->transform(function ($staff) use ($callData, $dayCount, $helper, &$total_incoming_call_count, &$total_outgoingcall_count, &$total_missedcall_count, &$total_rejected_call_count, &$total_unknown_count) {
        $data = $callData[$staff->sno] ?? (object) [
            'incoming_call_count' => 0,
            'outgoingcall_count' => 0,
            'missedcall_count' => 0,
            'rejected_call_count' => 0,
            'unknown_count' => 0
        ];

        $staff->incoming_call_count = $data->incoming_call_count;
        $staff->outgoingcall_count = $data->outgoingcall_count;
        $staff->missedcall_count = $data->missedcall_count;
        $staff->rejected_call_count = $data->rejected_call_count;
        $staff->unknown_count = $data->unknown_count;

        // Ratios
        $staff->outgoing_call_ratio = $dayCount > 0 ? round($data->outgoingcall_count / $dayCount, 2) : 0;
        $staff->incoming_call_ratio = $dayCount > 0 ? round($data->incoming_call_count / $dayCount, 2) : 0;
        $staff->missed_call_rate = $dayCount > 0 ? round($data->missedcall_count / $dayCount, 2) : 0;

        $total_calls = $data->incoming_call_count + $data->missedcall_count + $data->rejected_call_count;
        $staff->missed_call_ratio = $total_calls > 0 ? round(($data->missedcall_count / $total_calls) * 100, 2) : 0;

        // Update totals
        $total_incoming_call_count += $data->incoming_call_count;
        $total_outgoingcall_count += $data->outgoingcall_count;
        $total_missedcall_count += $data->missedcall_count;
        $total_rejected_call_count += $data->rejected_call_count;
        $total_unknown_count += $data->unknown_count;

        // -----------------------
        // LAST LOGIN + DURATION
        // -----------------------
        $last_login_data = $helper->get_tracker_last_login_data($staff->cug_mobile ?? null);
        $last_login_date = $last_login_data->last_sync_date ?? null;
        $last_login_time = $last_login_data->last_sync_time ?? null;

        $duration = '-';
        $last_login_display = null;

        if ($last_login_date && $last_login_time) {
            try {
                // parse and convert to Asia/Kolkata for display
                $dt = Carbon::parse($last_login_date . ' ' . $last_login_time);
                $last_login_display = $dt->timezone('Asia/Kolkata')->format('d M Y h:i A');

                // compute human readable duration (difference from now)
                $now = Carbon::now('Asia/Kolkata');
                $diff = $now->diff($dt); // DateInterval

                $parts = [];
                if ($diff->y > 0) $parts[] = $diff->y . ' year' . ($diff->y > 1 ? 's' : '');
                if ($diff->m > 0) $parts[] = $diff->m . ' month' . ($diff->m > 1 ? 's' : '');
                if ($diff->d > 0) $parts[] = $diff->d . ' day' . ($diff->d > 1 ? 's' : '');
                if ($diff->h > 0) $parts[] = $diff->h . ' hour' . ($diff->h > 1 ? 's' : '');
                if ($diff->i > 0) $parts[] = $diff->i . ' minute' . ($diff->i > 1 ? 's' : '');
                if ($diff->s > 0 && empty($parts)) $parts[] = $diff->s . ' second' . ($diff->s > 1 ? 's' : '');
                if (empty($parts)) $parts[] = 'Just now';

                $duration = implode(' ', $parts);
            } catch (\Exception $e) {
                $duration = '-';
                $last_login_display = null;
            }
        }

        // attach to staff row for frontend AJAX consumption
        $staff->last_login_date = $last_login_date;
        $staff->last_login_time = $last_login_time;
        $staff->last_login_display = $last_login_display;
        $staff->duration = $duration;

        return $staff;
    });

    // Totals & Ratios
    $total_staff = $salesStaff->total() ?? 0;
    $total_outgoing_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_outgoingcall_count / ($total_staff * $dayCount), 2) : 0;
    $total_incoming_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_incoming_call_count / ($total_staff * $dayCount), 2) : 0;
    $total_missed_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_missedcall_count / ($total_staff * $dayCount), 2) : 0;

    $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();

    // --- JSON Response ---
    return response()->json([
        'status' => 200,
        'message' => 'Team Call Monthly Report',
        'filters' => [
            'branch_id' => $branch_id,
            'month' => $month,
            'year' => $year,
            'month_chk' => $month_chk,
            'day_count' => $dayCount,
            'lead_fill' => $lead_fill,
            'per_page' => $perpage,
            'current_page' => $page,
        ],
        'totals' => [
            'incoming' => $total_incoming_call_count,
            'outgoing' => $total_outgoingcall_count,
            'missed' => $total_missedcall_count,
            'rejected' => $total_rejected_call_count,
            'unknown' => $total_unknown_count,
            'incoming_ratio' => $total_incoming_call_ratio,
            'outgoing_ratio' => $total_outgoing_call_ratio,
            'missed_ratio' => $total_missed_call_ratio,
        ],
        'lead_metric' => $Lead_metric_list,
        'data' => $salesStaff,
    ]);
}


  
 
    
 



}