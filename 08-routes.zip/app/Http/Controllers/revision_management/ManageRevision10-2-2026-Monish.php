<?php

namespace App\Http\Controllers\revision_management;

use App\Http\Controllers\Controller;
use App\Models\DailyTaskModel;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Throwable;

class ManageRevision extends Controller
{
  public function index(Request $request) {

    $user_id = $request->user()->user_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $search_fill = $request->search_fill ?? '';
    $journal_coordinator_fill = $request->journal_coordinator_fill ?? '';
    $journal_team_lead_fill = $request->journal_team_lead_fill ?? '';
    $journal_status_fill = $request->journal_status_fill ?? '';
    $pc_fill = $request->pc_fill ?? '';
    $staffs_fill = $request->staffs_fill ?? '';

    $lists = DB::table('et_journal_revision')
      ->leftJoin('et_staff as jc_staff', 'jc_staff.sno', '=', 'et_journal_revision.jc_id')
      ->leftJoin('et_staff as jtl_staff', 'jtl_staff.sno', '=', 'et_journal_revision.jtl_id')
      ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_journal_revision.journal_id')
      ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_revision.service_id')
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_revision.customer_id')
      ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
      ->select(
        'jc_staff.staff_image as jc_staff_image',
        'jc_staff.staff_name as jc_staff_name',
        'et_journal_revision.journal_id',
        'et_journal_revision.jc_id',
        'et_journal_revision.jtl_id',
        'jtl_staff.staff_image as jtl_staff_image',
        'jtl_staff.staff_name as jtl_staff_name',
        'et_manage_journal.paper_name',
        'et_manage_journal.journal_id as manage_journal_id',
        'et_product.product_name',
        'et_customer_services.sno',
        'et_customer_services.created_at',
        'et_customer.cus_name',
        'et_customer.customer_id',
      )
      ->groupBy(
        'jc_staff.staff_image',
        'jc_staff.staff_name',
        'et_journal_revision.journal_id',
        'et_journal_revision.jc_id',
        'et_journal_revision.jtl_id',
        'jtl_staff.staff_image',
        'jtl_staff.staff_name',
        'et_manage_journal.paper_name',
        'et_manage_journal.journal_id',
        'et_product.product_name',
        'et_customer_services.sno',
        'et_customer_services.created_at',
        'et_customer.cus_name',
        'et_customer.customer_id',
      );

    if (auth()->user()->hasPermissionradio('Revision Management', 'Manage Revision', 'view_self_revision')) {
      // User can only view their own data
      $userRole = auth()->user()->role_id;

      if ($userRole == 33) {
        $lists = $lists->where('et_journal_revision.jtl_id', $user_id);
      } elseif ($userRole == 34) {
        $lists = $lists->where('et_journal_revision.jc_id', $user_id);
      } elseif ($userRole === 15) {
        $lists = $lists->where('et_journal_revision.pc_id', $user_id);
      } elseif ($userRole === 32 || $userRole === 36) {
        $lists = $lists->where('et_journal_revision.staff_id', $user_id);
      }

    } elseif (auth()->user()->hasPermissionradio('Revision Management', 'Manage Revision', 'global_revision')) {
      // User can view all data — no extra filter needed
      $lists = $lists;
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }

    if($journal_coordinator_fill != '') {
      $lists->where('et_journal_revision.jc_id', $journal_coordinator_fill);
    }

    if($journal_team_lead_fill != '') {
      $lists->where('et_journal_revision.jtl_id', $journal_team_lead_fill);
    }

    $lists = $lists->paginate($perpage);

    foreach($lists as $list) {
      $year = date('Y', strtotime($list->created_at));
      $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
      $list->formatted_service_id = "SR-{$id}/{$year}";

      $revisions = DB::table('et_journal_revision')
        ->where('et_journal_revision.journal_id', $list->journal_id)
        ->leftJoin('et_staff as pc_staff', 'pc_staff.sno', '=', 'et_journal_revision.pc_id')
        ->leftJoin('et_staff as staff', 'staff.sno', '=', 'et_journal_revision.staff_id')
        ->select(
          'et_journal_revision.journal_status',
          'et_journal_revision.documents',
          'et_journal_revision.staff_documents',
          'et_journal_revision.comments',
          'et_journal_revision.pc_id',
          'et_journal_revision.staff_id',
          'pc_staff.staff_image as pc_image',
          'pc_staff.staff_name as pc_name',
          'staff.staff_image as staff_image',
          'staff.staff_name as staff_name',
          'et_journal_revision.status',
          'et_journal_revision.sno',
          'et_journal_revision.created_at'
        );

      if (auth()->user()->hasPermissionradio('Revision Management', 'Manage Revision', 'view_self_revision')) {
        // User can only view their own data
        $userRole = auth()->user()->role_id;

        if ($userRole == 15) {
          $revisions = $revisions->where('et_journal_revision.pc_id', $user_id);
        } elseif ($userRole == 32 || $userRole == 36) {
          $revisions = $revisions->where('et_journal_revision.staff_id', $user_id);
        }
      } elseif (auth()->user()->hasPermissionradio('Revision Management', 'Manage Revision', 'global_revision')) {
        // User can view all data — no extra filter needed
        $revisions = $revisions;
      } else {
        // No permission
        abort(403, 'Unauthorized');
      }

      if($journal_status_fill != '') {
        $revisions->where('et_journal_revision.journal_status', $journal_status_fill);
      }

      if($pc_fill != '') {
        $revisions->where('et_journal_revision.pc_id', $pc_fill);
      }

      if($staffs_fill != '') {
        $revisions->where('et_journal_revision.staff_id', $staffs_fill);
      }

      $revisions = $revisions->get();

      $list->revisions = $revisions;
    }

    $journalCoordinators = DB::table('et_staff')
      ->where('status', 0)
      ->where('role_id', 34)
      ->get();

    $journalTeamLead = DB::table('et_staff')
      ->where('status', 0)
      ->where('role_id', 33)
      ->get();

    $pc = DB::table('et_staff')
      ->where('status', 0)
      ->where('role_id', 15)
      ->get();

    $productionStaffs = DB::table('et_staff')
      ->where('status', 0)
      ->whereIn('role_id', [32, 36])
      ->get();

    // ************** MINI DASHBOARD ************* //
    $jtlVerification = 0;
    $staffAssigned = 0;
    $inProgress = 0;
    $waitingForDocumentation = 0;
    $pcNotAssign = 0;
    $staffNotAssign = 0;
    $completed = 0;
    $jtlPendingVerification = 0;
    $pcPendingVerification = 0;
    $rework = 0;

    $jtlVerification = DB::table('et_journal_revision')
      ->where('status', 0)
      ->count();

    $pcNotAssign = DB::table('et_journal_revision')
      ->where('status', 1)
      ->count();

    $staffNotAssign = DB::table('et_journal_revision')
      ->where('status', 3)
      ->count();

    $staffAssigned = DB::table('et_journal_revision')
      ->where('status', 4)
      ->count();

    $inProgress = DB::table('et_journal_revision')
      ->where('status', 5)
      ->count();

    $waitingForDocumentation = DB::table('et_journal_revision')
      ->where('status', 6)
      ->count();

    $pcPendingVerification = DB::table('et_journal_revision')
      ->where('status', 7)
      ->count();

    $jtlPendingVerification = DB::table('et_journal_revision')
      ->where('status', 8)
      ->count();

    $completed = DB::table('et_journal_revision')
      ->where('status', 9)
      ->count();

    $rework = DB::table('et_journal_revision')
      ->where('status', '>', 9)
      ->count();

    return view('content.revision_management.manage_revision.list', [
      'lists' => $lists,
      'perpage' => $perpage,
      'search_fill' => $search_fill,
      'journal_coordinators' => $journalCoordinators,
      'journal_coordinator_fill' => $journal_coordinator_fill,
      'journal_team_lead' => $journalTeamLead,
      'journal_team_lead_fill' => $journal_team_lead_fill,
      'journalStatusFill' => $journal_status_fill,
      'pc' => $pc,
      'pc_fill' => $pc_fill,
      'productionStaffs' => $productionStaffs,
      'staffs_fill' => $staffs_fill,
      'jtlVerification' => $jtlVerification,
      'staffAssigned' => $staffAssigned,
      'inProgress' => $inProgress,
      'waitingForDocumentation' => $waitingForDocumentation,
      'pcNotAssign' => $pcNotAssign,
      'staffNotAssign' => $staffNotAssign,
      'completed' => $completed,
      'jtlPendingVerification' => $jtlPendingVerification,
      'pcPendingVerification' => $pcPendingVerification,
      'rework' => $rework,
    ]);
  }

  public function JTLVerificationDataFetch($id) {
    $data = DB::table('et_journal_revision')
      ->where('et_journal_revision.sno', $id)
      ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_journal_revision.journal_id')
      ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_revision.service_id')
      ->leftJoin('et_staff as jc_staff', 'jc_staff.sno', '=', 'et_journal_revision.jc_id')
      ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_journal_revision.pc_id')
      ->leftJoin('et_staff as staff', 'staff.sno', '=', 'et_journal_revision.staff_id')
      ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
      ->select(
        'et_manage_journal.paper_name',
        'et_manage_journal.journal_id',
        'et_journal_revision.journal_status',
        'et_journal_revision.comments',
        'et_product.product_name',
        'jc_staff.staff_name as jc_name',
        'staff.staff_name as staff_name',
        'pc.staff_name as pc_name',
        'et_customer_services.created_at',
        'et_customer_services.sno'
      )
      ->where('et_journal_revision.status', '!=', 2)
      ->first();

    $year = date('Y', strtotime($data->created_at));
    $id = str_pad($data->sno, 5, '0', STR_PAD_LEFT);
    $data->formatted_service_id = "SR-{$id}/{$year}";

    return response([
      'status' => 200,
      'message' => "Data fetched successfully!",
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function verifyJTL($id, Request $request)
  {
    $user_id = $request->user()->user_id;

    $query = DB::table('et_journal_revision')
      ->where('sno', $id)
      ->where('status', '!=', 2);

    $data = $query->first();

    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Record not found',
        'error_msg' => null,
        'data' => null
      ], 404);
    }

    $query->update([
      'status' => 1,
      'updated_by' => $user_id
    ]);

    return response([
      'status' => 200,
      'message' => 'Data updated successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function assignPC($id, Request $request)
  {
    $user_id = $request->user()->user_id;
    $pc_id = $request->pc_id;

    $query = DB::table('et_journal_revision')
      ->where('sno', $id)
      ->where('status', '!=', 2);

    $data = $query->first();

    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Record not found',
        'error_msg' => null,
        'data' => null
      ], 404);
    }

    $query->update([
      'pc_id' => $pc_id,
      'status' => 3,
      'updated_by' => $user_id
    ]);

    return response([
      'status' => 200,
      'message' => 'Data updated successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function assignRevisionStaff(Request $request)
  {
    $request->validate([
      'id' => 'required|integer',
      'staff_id' => 'required|integer'
    ]);

    $id = $request->id;
    $staffId = $request->staff_id;
    $user_id = $request->user()->user_id;
    $task_date = $request->task_date;
    $task_hours = $request->task_hours;

    $query = DB::table('et_journal_revision')
      ->where('sno', $id)
      ->where('status', '!=', 2);

    $data = $query->first();

    if (!$data) {
      return response()->json([
        'status' => 'error',
        'message' => 'Record Not Found!'
      ]);
    }

    DB::beginTransaction();

    try {
      $updated = $query->update([
        'staff_id' => $staffId,
        'status' => 4,
        'updated_by' => $user_id
      ]);

      if ($updated > 0) {
        $task = new DailyTaskModel();
        $task->service_id = $data->service_id;
        $task->task_id = $data->sno;
        $task->staff_id = $staffId;
        $task->task_date = $task_date;
        $task->task_hours = $task_hours;
        $task->is_journal = 1;
        $task->created_by = $user_id;
        $task->updated_by = $user_id;
        $task->save();
      }

      DB::commit();

      return response()->json([
        'status' => 'success',
        'message' => 'Staff Assigned Successfully!'
      ]);
    } catch (\Exception $e) {
      DB::rollBack();

      return response()->json([
        'status' => 'error',
        'message' => 'Something went wrong!'
      ], 500);
    }
  }

  public function jtlAccepted($id, Request $request) {
    $user_id = $request->user()->user_id;

    $query = DB::table('et_journal_revision')
      ->where('sno', $id)
      ->where('status', '!=', 2);

    $data = $query->first();

    if(!$data) {
      return response([
        'status' => 404,
        'message' => 'Record Not Found !'
      ]);
    }

    $query->update([
      'status' => 9,
      'updated_by' => $user_id
    ]);

    return response([
      'status' => 200,
      'message' => 'Revision Marked as Complete !'
    ], 200);
  }

  public function jtlRejected($id, Request $request) {
    $user_id = $request->user()->user_id;

    DB::beginTransaction();

    try {
      $query = DB::table('et_journal_revision')
        ->where('status', '!=', 2)
        ->where('sno', $id);

      $data = $query->first();

      if (!$data) {
        return response([
          'status' => 404,
          'message' => 'Record Not Found !'
        ]);
      }

      $query->update([
        'status' => 10,
        'updated_by' => $user_id
      ]);

      $inserted = DB::table('et_journal_revision')->insert([
        'journal_id' => $data->journal_id,
        'service_id' => $data->service_id,
        'customer_id' => $data->customer_id,
        'jc_id' => $data->jc_id,
        'jtl_id' => $data->jtl_id,
        'journal_status' => $data->journal_status,
        'documents' => $data->documents,
        'comments' => $request->reject_reason,
        'created_by' => $user_id,
        'updated_by' => $user_id
      ]);

      if(!$inserted) {
        throw new Exception('Insert Failed');
      }

      DB::commit();

      return response([
        'status' => 200,
        'message' => 'Revision Rejected Successfully !'
      ]);
    } catch (Throwable $e) {
      DB::rollBack();

      return response([
        'status' => 500,
        'message' => 'Something Went Wrong',
        'error' => $e->getMessage()
      ]);
    }
  }

  public function pcJournalAccepted(Request $request, $id) {
    $user_id = $request->user()->user_id;

    $query = DB::table('et_journal_revision')
      ->where('status', '!=', 2)
      ->where('sno', $id);

    $data = $query->first();

    if(!$data) {
      return response([
        'status' => 404,
        'message' => 'Record Not Found !'
      ]);
    }

    $query->update([
      'status' => 8,
      'updated_by' => $user_id
    ]);

    return response([
      'status' => 200,
      'message' => 'Revision Accepted Successfully !'
    ]);
  }

  public function pcJournalReject(Request $request, $id) {
    $user_id = $request->user()->user_id;

    DB::beginTransaction();

    try {
      $query = DB::table('et_journal_revision')
        ->where('sno', $id)
        ->where('status', '!=', 2);

      $data = $query->first();

      if(!$data) {
        return response()->json([
          'status' => 'error',
          'message' => 'Record Not Found !'
        ]);
      }

      DB::table('et_daily_tasks')
        ->where('status', '!=', 2)
        ->where('is_journal', 1)
        ->where('task_id', $data->sno)
        ->update([
          'status' => 5,
          'updated_by' => $user_id
        ]);

      $query->update([
        'status' => 10,
        'updated_by' => $user_id
      ]);

      $insertedId = DB::table('et_journal_revision')
        ->insertGetId([
          'journal_id' => $data->journal_id,
          'service_id' => $data->service_id,
          'customer_id' => $data->customer_id,
          'jc_id' => $data->jc_id,
          'jtl_id' => $data->jtl_id,
          'pc_id' => $data->pc_id,
          'staff_id' => $request->staff_id ?? $data->staff_id,
          'journal_status' => $data->journal_status,
          'documents' => $data->documents,
          'comments' => $request->reject_reason,
          'created_by' => $user_id,
          'updated_by' => $user_id,
          'status' => 4
        ]);

      DB::table('et_daily_tasks')
        ->insert([
          'service_id' => $data->service_id,
          'task_id' => $insertedId,
          'staff_id' => $request->staff_id ?? $data->staff_id,
          'task_date' => now(),
          'description' => $request->reject_reason,
          'is_journal' => 1,
          'created_by' => $user_id,
          'updated_by' => $user_id
        ]);

      if(!$insertedId) {
        throw new Exception('Unable to insert the record.');
      }

      DB::commit();

      return response()->json([
        'status' => 'success',
        'message' => 'Revision Rejected Successfully !'
      ]);
    } catch (Throwable $e) {
      DB::rollBack();

      return response([
        'status' => 500,
        'message' => 'Something Went Wrong',
        'error' => $e->getMessage()
      ]);
    }
  }

  public function commentsView($id) {
    $data = DB::table('et_journal_revision')
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_revision.customer_id')
      ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_journal_revision.journal_id')
      ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_revision.service_id')
      ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
      ->leftJoin('et_staff as jtl', 'jtl.sno', '=', 'et_journal_revision.jtl_id')
      ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_journal_revision.pc_id')
      ->leftJoin('et_staff as staff', 'staff.sno', '=', 'et_journal_revision.staff_id')
      ->where('et_journal_revision.status', '!=', 2)
      ->where('et_journal_revision.sno', $id)
      ->select(
        'et_journal_revision.journal_status',
        'et_journal_revision.created_at',
        'et_journal_revision.comments',
        'et_customer.cus_name',
        'et_customer.customer_id',
        'jtl.staff_name as jtl_name',
        'jtl.staff_image as jtl_image',
        'pc.staff_name as pc_name',
        'pc.staff_image as pc_image',
        'staff.staff_name',
        'staff.staff_image',
        'et_manage_journal.paper_name',
        'et_manage_journal.journal_id',
        'et_product.product_name',
        'et_customer_services.sno as service_sno',
        'et_customer_services.created_at as service_created_at'
      )
      ->first();

    $journalStatus = $data->journal_status;

    switch ($journalStatus) {
      case 0:
        $data->journalStatus = 'Submitted';
        break;
      case 1:
        $data->journalStatus = 'With Editor';
        break;
      case 3:
        $data->journalStatus = 'Under Reviewer';
        break;
      case 4:
        $data->journalStatus = 'Revision';
        break;
      case 5:
        $data->journalStatus = 'Accepted';
        break;
      case 6:
        $data->journalStatus = 'Rejected';
        break;
      case 7:
        $data->journalStatus = 'E-Proofing';
        break;
      case 8:
        $data->journalStatus = 'Published';
        break;
    }

    $year = date('Y', strtotime($data->service_created_at));
    $formattedId = str_pad($data->service_sno, 5, '0', STR_PAD_LEFT);
    $data->formatted_service_id = "SR-{$formattedId}/{$year}";

    return response([
      'status' => 200,
      'message' => "Data Fetched Successfully !",
      'data' => $data
    ], 200);
  }
}
