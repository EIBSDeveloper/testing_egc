<?php

namespace App\Http\Controllers\users_management;

use App\Http\Controllers\Controller;
use App\Models\UserRolePermissionModel;
use App\Models\UserRoleModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class ManageUsers extends Controller
{
  public function index()
  {
    $userpermission = UserRolePermissionModel::where('et_user_role_permission.status', '!=', 2)
      ->join('et_user_role', 'et_user_role_permission.role_id', '=', 'et_user_role.sno')
      ->select(
        'et_user_role_permission.sno',
        'et_user_role.sno as role_id',
        'et_user_role.role_name',
        'et_user_role_permission.status'
      )
      ->get();

    return view('content.users_management.manage_users.list', compact('userpermission'));
  }

  public function users_add()
  {

    // Path to the JSON file
    $path = resource_path('menu/verticalMenu.json');

    // Read the file content
    $json = File::get($path);

    // Decode JSON to array
    $menu = json_decode($json, true);
    // dd($menu);
    // Pass the menu data to the view
    return view('content.users_management.manage_users.add', compact('menu'));
  }



  public function users_edit($id)
  {


    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');


    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    // $id = Crypt::decrypt($id);
    $path = resource_path('menu/verticalMenu.json');

    // Check if the menu file exists
    if (!File::exists($path)) {
      abort(500, 'Menu file not found.');
    }

    // Read the file content
    $json = File::get($path);

    // Decode JSON to array
    $menu = json_decode($json, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
      abort(500, 'Error decoding menu JSON file: ' . json_last_error_msg());
    }

    // Fetch the role data
    $role = UserRolePermissionModel::where('sno', $id)->first();
    if (!$role) {
      abort(404, 'Role not found');
    }

    // Decode the JSON permissions string into an array
    $rolePermissions = json_decode($role->permissions, true);

    // Check if rolePermissions is a JSON string
    if (is_string($rolePermissions)) {
      $rolePermissions = json_decode($rolePermissions, true);
    }
    // Ensure rolePermissions is an array
    $rolePermissions = is_array($rolePermissions) ? $rolePermissions : [];

    // Initialize flattenedPermissions array
    $flattenedPermissions = [];

    // Process role permissions
    foreach ($rolePermissions as $menuItem) {
      $menuName = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['menuName']);
      $menuChecked = isset($menuItem['menuChecked']) ? $menuItem['menuChecked'] : 0;

      if (isset($menuItem['submenu'])) {
        foreach ($menuItem['submenu'] as $submenuItem) {
          $submenuName = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['submenuName']);
          $submenuChecked = isset($submenuItem['submenuChecked']) ? $submenuItem['submenuChecked'] : 0;

          if (isset($submenuItem['actions'])) {
            foreach ($submenuItem['actions'] as $actionItem) {
              $actionName = preg_replace('/[^a-zA-Z0-9_]/', '', $actionItem['actionName']);
              $actionChecked = $actionItem['actionChecked'];

              $flattenedPermissions[$menuName]['submenu'][$submenuName]['actions'][] = [
                'actionName' => $actionName,
                'actionChecked' => $actionChecked
              ];
            }
          }

          if (isset($submenuItem['radios'])) {
            foreach ($submenuItem['radios'] as $radioItem) {
              $radioName = preg_replace('/[^a-zA-Z0-9_]/', '', $radioItem['radioName']);
              $radioValue = $radioItem['radioValue'];
              $checked = $radioItem['checked'];

              $flattenedPermissions[$menuName]['submenu'][$submenuName]['radios'][] = [
                'radioName' => $radioName,
                'radioValue' => $radioValue,
                'checked' => $checked
              ];
            }
          }

          $flattenedPermissions[$menuName]['submenu'][$submenuName]['submenuChecked'] = $submenuChecked;
        }
      }

      if (isset($menuItem['actions'])) {
        foreach ($menuItem['actions'] as $actionItem) {
          $actionName = preg_replace('/[^a-zA-Z0-9_]/', '', $actionItem['actionName']);
          $actionChecked = $actionItem['actionChecked'];

          $flattenedPermissions[$menuName]['actions'][] = [
            'actionName' => $actionName,
            'actionChecked' => $actionChecked
          ];
        }
      }

      if (isset($menuItem['radios'])) {
        foreach ($menuItem['radios'] as $radioItem) {
          $radioName = preg_replace('/[^a-zA-Z0-9_]/', '', $radioItem['radioName']);
          $radioValue = $radioItem['radioValue'];
          $checked = $radioItem['checked'];

          $flattenedPermissions[$menuName]['radios'][] = [
            'radioName' => $radioName,
            'radioValue' => $radioValue,
            'checked' => $checked
          ];
        }
      }

      $flattenedPermissions[$menuName]['menuChecked'] = $menuChecked;
    }
    // dd($flattenedPermissions['SalesManagement']['submenu']); // or dd($submenuItem);
    // dd($flattenedPermissions);

    // Pass the menu and permissions data to the view
    return view('content.users_management.manage_users.edit', compact('menu', 'rolePermissions', 'flattenedPermissions', 'role'));
  }



  public function users_view($id)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');


    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;

    $path = resource_path('menu/verticalMenu.json');

    // Check if the menu file exists
    if (!File::exists($path)) {
      abort(500, 'Menu file not found.');
    }

    // Read the file content
    $json = File::get($path);

    // Decode JSON to array
    $menu = json_decode($json, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
      abort(500, 'Error decoding menu JSON file: ' . json_last_error_msg());
    }

    // Fetch the role data
    $role = UserRolePermissionModel::where('sno', $id)->first();
    if (!$role) {
      abort(404, 'Role not found');
    }
    $role_name = UserRolePermissionModel::where('et_user_role_permission.sno', $id)
      ->join('et_user_role', 'et_user_role_permission.role_id', '=', 'et_user_role.sno')
      ->select(
        'et_user_role_permission.sno',
        'et_user_role.sno as role_id',
        'et_user_role.role_name',
        'et_user_role_permission.status',
      )->first();
    if (!$role) {
      abort(404, 'Role not found');
    }
    // Decode the JSON permissions string into an array
    $rolePermissions = json_decode($role->permissions, true);

    // Check if rolePermissions is a JSON string
    if (is_string($rolePermissions)) {
      $rolePermissions = json_decode($rolePermissions, true);
    }
    // Ensure rolePermissions is an array
    $rolePermissions = is_array($rolePermissions) ? $rolePermissions : [];

    // Initialize flattenedPermissions array
    $flattenedPermissions = [];

    // Process role permissions
    foreach ($rolePermissions as $menuItem) {
      $menuName = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['menuName']);
      $menuChecked = isset($menuItem['menuChecked']) ? $menuItem['menuChecked'] : 0;

      if (isset($menuItem['submenu'])) {
        foreach ($menuItem['submenu'] as $submenuItem) {
          $submenuName = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['submenuName']);
          $submenuChecked = isset($submenuItem['submenuChecked']) ? $submenuItem['submenuChecked'] : 0;

          if (isset($submenuItem['actions'])) {
            foreach ($submenuItem['actions'] as $actionItem) {
              $actionName = preg_replace('/[^a-zA-Z0-9_]/', '', $actionItem['actionName']);
              $actionChecked = $actionItem['actionChecked'];

              $flattenedPermissions[$menuName]['submenu'][$submenuName]['actions'][] = [
                'actionName' => $actionName,
                'actionChecked' => $actionChecked
              ];
            }
          }

          if (isset($submenuItem['radios'])) {
            foreach ($submenuItem['radios'] as $radioItem) {
              $radioName = preg_replace('/[^a-zA-Z0-9_]/', '', $radioItem['radioName']);
              $radioValue = $radioItem['radioValue'];
              $checked = $radioItem['checked'];

              $flattenedPermissions[$menuName]['submenu'][$submenuName]['radios'][] = [
                'radioName' => $radioName,
                'radioValue' => $radioValue,
                'checked' => $checked
              ];
            }
          }

          $flattenedPermissions[$menuName]['submenu'][$submenuName]['submenuChecked'] = $submenuChecked;
        }
      }

      if (isset($menuItem['actions'])) {
        foreach ($menuItem['actions'] as $actionItem) {
          $actionName = preg_replace('/[^a-zA-Z0-9_]/', '', $actionItem['actionName']);
          $actionChecked = $actionItem['actionChecked'];

          $flattenedPermissions[$menuName]['actions'][] = [
            'actionName' => $actionName,
            'actionChecked' => $actionChecked
          ];
        }
      }

      if (isset($menuItem['radios'])) {
        foreach ($menuItem['radios'] as $radioItem) {
          $radioName = preg_replace('/[^a-zA-Z0-9_]/', '', $radioItem['radioName']);
          $radioValue = $radioItem['radioValue'];
          $checked = $radioItem['checked'];

          $flattenedPermissions[$menuName]['radios'][] = [
            'radioName' => $radioName,
            'radioValue' => $radioValue,
            'checked' => $checked
          ];
        }
      }

      $flattenedPermissions[$menuName]['menuChecked'] = $menuChecked;
    }

    // Pass the menu and permissions data to the view
    return view('content.users_management.manage_users.view', compact('menu', 'rolePermissions', 'flattenedPermissions', 'role', 'role_name'));
  }


  public function Add(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'role' => 'required|integer',
      'manage_branch' => 'required',
      'permissions' => 'required',
      'permissions.*.menu' => 'required|string',
      'permissions.*.submenu' => 'nullable',
      'permissions.*.submenu.*.name' => 'nullable|string',
      'permissions.*.submenu.*.actions' => 'nullable',
      'permissions.*.submenu.*.actions.*' => 'nullable|string',
      'permissions.*.actions' => 'nullable',
      'permissions.*.actions.*' => 'nullable|string',
    ]);

    if ($validator->fails()) {
      $errors = $validator->errors()->all();
      $firstError = $validator->errors()->first();

      session()->flash('toastr', [
        'type' => 'error',
        'message' => $firstError . ' | Detailed errors: ' . implode(', ', $errors)
      ]);

      return redirect()->back()->withInput();
    }

    try {
      $permissionsJson = json_encode($request->permissions);
      if (json_last_error() !== JSON_ERROR_NONE) {
        throw new \Exception('Invalid JSON data');
      }

      $add_user_role_permission = new UserRolePermissionModel();
      $add_user_role_permission->role_id = $request->role;
      $add_user_role_permission->manage_branch = $request->manage_branch;
      if ($add_user_role_permission->manage_branch == 2) {
        $add_user_role_permission->access_head      = $request->access_head;
      } else {
        $add_user_role_permission->access_head      = null;
      }
      $add_user_role_permission->permissions = $permissionsJson;
      $add_user_role_permission->created_by = $request->user()->user_id;
      $add_user_role_permission->updated_by = $request->user()->user_id;

      $add_user_role_permission->save();

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'User Role Permissions added Successfully!'
      ]);
    } catch (\Exception $e) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the User Role Permissions! ' . $e->getMessage()
      ]);
    }

    return redirect('users/manage_users');
  }


  public function Edit($id)
  {
    $role = UserRolePermissionModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $role
    ], 200);
  }

  public function update(Request $request, $id)
  {
    $validator = Validator::make($request->all(), [
      'role' => 'required|integer',
      'permissions' => 'required',
      'permissions.*.menu' => 'required|string',
      'permissions.*.submenu' => 'nullable',
      'permissions.*.submenu.*.name' => 'nullable|string',
      'permissions.*.submenu.*.actions' => 'nullable',
      'permissions.*.submenu.*.actions.*' => 'nullable|string',
      'permissions.*.actions' => 'nullable',
      'permissions.*.actions.*' => 'nullable|string',
    ]);

    if ($validator->fails()) {
      $errors = $validator->errors()->all();
      $firstError = $validator->errors()->first();

      session()->flash('toastr', [
        'type' => 'error',
        'message' => $firstError . ' | Detailed errors: ' . implode(', ', $errors)
      ]);
    }

    $rolePermission = UserRolePermissionModel::where('sno', $id)->first();
    try {
      $permissionsJson = json_encode($request->permissions);
      if (json_last_error() !== JSON_ERROR_NONE) {
      }


      $rolePermission->role_id          = $request->role;
      $rolePermission->manage_branch    = $request->manage_branch;
      if ($rolePermission->manage_branch == 2) {
        $rolePermission->access_head      = $request->access_head;
      } else {
        $rolePermission->access_head      = null;
      }

      $rolePermission->permissions      = $permissionsJson;
      $rolePermission->updated_by       = $request->user()->user_id;
      $rolePermission->update();


      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'User Role Permissions Updated Successfully!'
      ]);
    } catch (\Exception $e) {

      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Updated the User Role Permissions!'
      ]);
    }

    return redirect('users/manage_users');
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  UserRolePermissionModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  UserRolePermissionModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->status;
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
  public function user_role_chart(Request $request) {

    $filter_on = $request->filter_on ?? '';
    $selectedRoles = $request->input('role_fill', []);

    $path = resource_path('menu/verticalMenu.json');

    // Check if the menu file exists
    if (!File::exists($path)) {
      abort(500, 'Menu file not found.');
    }

    // Read the file content
    $json = File::get($path);

    // Decode JSON to array
    $menu = json_decode($json, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
      abort(500, 'Error decoding menu JSON file: ' . json_last_error_msg());
    }

    // Fetch the role data
    $roleQuery = UserRolePermissionModel::where('et_user_role_permission.status', 0)
      ->join('et_user_role', 'et_user_role_permission.role_id', '=', 'et_user_role.sno')
      ->select(
        'et_user_role_permission.*',
        'et_user_role.role_name'
      );

      if(!empty($selectedRoles) && !in_array(0, $selectedRoles)) {
        $roleQuery->whereIn('et_user_role.sno', $selectedRoles);
      }

    $roles = $roleQuery->get();

    $rolesWithPermissions = [];

    foreach ($roles as $role) {
      $rolePermissions = json_decode($role->permissions, true);
      if (is_string($rolePermissions)) {
        $rolePermissions = json_decode($rolePermissions, true);
      }
      $rolePermissions = is_array($rolePermissions) ? $rolePermissions : [];

      $flattenedPermissions = [];

      foreach ($rolePermissions as $menuItem) {
        $menuName = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['menuName']);
        $menuChecked = $menuItem['menuChecked'] ?? 0;

        if (isset($menuItem['submenu'])) {
          foreach ($menuItem['submenu'] as $submenuItem) {
            $submenuName = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['submenuName']);
            $submenuChecked = $submenuItem['submenuChecked'] ?? 0;

            if (isset($submenuItem['actions'])) {
              foreach ($submenuItem['actions'] as $actionItem) {
                $actionName = preg_replace('/[^a-zA-Z0-9_]/', '', $actionItem['actionName']);
                $actionChecked = $actionItem['actionChecked'];

                $flattenedPermissions[$menuName]['submenu'][$submenuName]['actions'][] = [
                  'actionName' => $actionName,
                  'actionChecked' => $actionChecked
                ];
              }
            }

            $flattenedPermissions[$menuName]['submenu'][$submenuName]['submenuChecked'] = $submenuChecked;
          }
        }

        $flattenedPermissions[$menuName]['menuChecked'] = $menuChecked;
      }

      $rolesWithPermissions[] = [
        'role' => $role,
        'permissions' => $flattenedPermissions
      ];
    }

    $roleFill = UserRoleModel::where('status', 0)->orderBy('sno', 'asc')->get();

    return view('content.users_management.manage_users.user_role_chart', compact('menu', 'rolesWithPermissions', 'roleFill', 'filter_on', 'selectedRoles'));
  }
}