<?php

namespace App\Http\Controllers\users_management;

use App\Http\Controllers\Controller;
use App\Models\UserRolePermissionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use App\Models\StaffModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\DepartmentModel;
use App\Models\BranchModel;
class UserManage extends Controller
{
  public function index()
  {
    
    return view('content.users_management.users_manage.list');
  }
  
  public function List(Request $request)
  {
        $branch_id = $request->branch_id ?? $request->user()->branch_id;
    
        // Get staff list for the branch
        $stafflist = StaffModel::where('status', 0)
            ->where('branch_id', $branch_id)
            ->where('sno','>', 1)
            ->orderBy('sno', 'desc')
            ->get();
         // Department-wise staff counts for current staff's branch
            $sales_staff = StaffModel::where('status', 0)
                ->where('department_id', 1)
                ->where('branch_id', $branch_id)
                ->count();
        
            $production_staff = StaffModel::where('status', 0)
                ->where('department_id', 2)
                ->where('position_role', '!=', 38)
                ->where('branch_id', $branch_id)
                ->count();
        
            $production_staff_freelance = StaffModel::where('status', 0)
                ->where('department_id', 2)
                ->where('position_role', 38)
                ->where('branch_id', $branch_id)
                ->count();
        
            $placement_staff = StaffModel::where('status', 0)
                ->where('department_id', 8)
                ->where('branch_id', $branch_id)
                ->count();
    
       $staffData = $stafflist->map(function ($staff) {
                $branchId = $staff->branch_id;
            
               
            
                // Related data
                $department = DepartmentModel::where('status', 0)->where('sno', $staff->department_id)->first();
                $user = User::where('user_id', $staff->sno)->first();
            
                $Branch = $user
                    ? BranchModel::where('status', 0)->where('sno', $user->branch_id)->first()
                    : BranchModel::where('status', 0)->where('sno', $staff->branch_id)->first();
            
                $role = UserRoleModel::where('status', 0)->where('sno', $staff->role_id)->first();
                $creator = StaffModel::where('sno', $staff->created_by)->first();
            
                return [
                    'staff_name'                    => $staff->staff_name,
                    'sno'                           => $staff->sno,
                    'nick_name'                     => $staff->nick_name,
                    'staff_image'                   => $staff->staff_image,
                    'email_id'                      => $staff->email_id,
                    'gender'                        => $staff->gender,
                    'mobile_no'                     => $staff->mobile_no,
                    'created_by'                    => $creator ? $creator->staff_name : 'N/A',
                    'created_by_staff_image'        => $creator ? $creator->staff_image : 'N/A',
                    'created_by_nick_name'          => $creator ? $creator->nick_name : 'N/A',
                    'created_date'                  => optional($staff->created_at)->format('d-M-Y'),
                    'role_name'                     => $role ? $role->role_name : 'N/A',
                    'branch_name'                   => $Branch ? (!empty($Branch->franchise_name) ? $Branch->franchise_name : $Branch->branch_name) : 'N/A',
                    'branch_id'                     => $user ? $user->branch_id : 'N/A',
                    'original_branch_id'            => $staff->branch_id ?? 'N/A',
                    'department_name'               => $department ? $department->department_name : 'N/A',
                   
                ];
            });

    
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $staffData,
            'sales_staff'                   => $sales_staff,
            'production_staff'              => $production_staff,
            'production_staff_freelance'    => $production_staff_freelance,
            'placement_staff'               => $placement_staff,
        ], 200);
    }
    
   public function View(Request $request, $id)
{
    $staff = StaffModel::where('sno', $id)->where('status', 0)->first();

    if (!$staff) {
        return response()->json([
            'status' => 404,
            'message' => 'Staff not found'
        ], 404);
    }

    $user = User::where('user_id', $staff->sno)->first();
    $branch = $user
        ? BranchModel::where('status', 0)->where('sno', $user->branch_id)->first()
        : BranchModel::where('status', 0)->where('sno', $staff->branch_id)->first();

    $role = UserRoleModel::where('status', 0)->where('sno', $staff->role_id)->first();
    $department = DepartmentModel::where('status', 0)->where('sno', $staff->department_id)->first();
    $creator = StaffModel::where('sno', $staff->created_by)->first();

    return response()->json([
        'status' => 200,
        'data' => [
            'staff_name' => $staff->staff_name,
            'nick_name' => $staff->nick_name,
            'staff_image' => $staff->staff_image,
            'email_id' => $staff->email_id,
            'mobile_no' => $staff->mobile_no,
            'username' => $staff->user_name,
            'password' => $staff->password,
            'gender' => $staff->gender,
            'created_by' => $creator?->staff_name ?? 'N/A',
            'created_by_nick_name' => $creator?->nick_name ?? 'N/A',
            'created_by_staff_image' => $creator?->staff_image ?? 'N/A',
            'branch_name' => $branch ? ($branch->franchise_name ?: $branch->branch_name) : 'N/A',
            'role_name' => $role->role_name ?? 'N/A',
            'department_name' => $department->department_name ?? 'N/A',
            'created_date' => optional($staff->created_at)->format('d-M-Y'),
        ]
    ]);
}



}