<?php

namespace App\Http\Controllers\marketing_management;

use App\Http\Controllers\Controller;
use App\Models\MarketingKitModel;
use App\Models\MarketingKitDeliveryModel;
use App\Models\MarketingKitCartModel;
use App\Models\MarketingKitOrderModel;
use App\Models\VariableModel;
use App\Models\VariablesModel;
use App\Models\VariantModel;

use App\Models\MarketingKitCategoryModel;
use App\Models\MarketingKitSubCategoryModel;
use DateTime;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\MarketingCampaignExport;
use Razorpay\Api\Api;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Collection;
class MarketingKit extends Controller
{
   public function index()
    {
        $categories = MarketingKitCategoryModel::where('status', 0)->get(['sno', 'category_name']);
        $Variabledata = VariablesModel::where('status', 0)->get(['sno', 'variant_id', 'variables_name']);
        $Variantdatas = VariantModel::where('status', 0)->get(['sno', 'variant_name']);
    
        // Filter and attach only variants that have related variables
        $Variantdata = $Variantdatas->filter(function ($variant) use ($Variabledata) {
            $variables = $Variabledata->where('variant_id', $variant->sno)->values();
            if ($variables->isNotEmpty()) {
                $variant->variables = $variables;
                return true;
            }
            return false;
        })->values(); // reset keys
    
        return view('content.marketing_management.marketing_kit.marketing_kit', compact('categories', 'Variantdata'));
    }
   public function getcategories()
    {
    return MarketingKitCategoryModel::where('sno', $subcategoryId)->where('status',0)->get(['sno', 'category_name']);

  }
  public function getSubcategories($categoryId)
  {
      return MarketingKitSubCategoryModel::where('marketing_category_id', $categoryId)->where('status',0)->get(['sno', 'marketing_subcategory_name']);
  }

  public function getVariables($subcategoryId)
  {
      return VariableModel::where('sno', $subcategoryId)->where('status',0)->get(['sno', 'color_name','color_code','width','height','variable']);
  }
  public function MarketingKitAdd(Request $request)
  {
      $validated = $request->validate([
          'marketing_kit_name' => 'required|string|max:255',
          'category_id' => 'required|integer',
          'sub_category_id' => 'required',
          'file_type' => 'required',
      ]);
    // return $request->all();


    //   $fileName = '';

    //   if ($request->hasFile('marketing_attachments')) {
    //     $file = $request->file('marketing_attachments');
    //     $fileName = time() . '_' . $file->getClientOriginalName();
    //     $destinationPath = public_path('marketing_kits');
    //     $file->move($destinationPath, $fileName);

    //     $filePath = $destinationPath . '/' . $fileName;
    //     $apiKey = '5c67a80e923be51253e2216e814b1e8a0bfff34d'; // Ensure this is valid

    //     $response = Http::attach(
    //         'image', // field name
    //         file_get_contents($filePath), // actual file content
    //         $fileName // file name
    //     )->asMultipart()->post('https://app.imagify.io/api/upload/', [
    //         [
    //             'name' => 'data',
    //             'contents' => json_encode([
    //                 'ultra' => true,
    //                 'resize' => ['width' => 800], // optional resize
    //             ]),
    //         ],
    //         [
    //             'name' => 'key',
    //             'contents' => $apiKey,
    //         ]
    //     ]);

    //     $data = json_decode($response->body(), true);

    //     if (isset($data['success']) && $data['success']) {
    //         $optimizedUrl = $data['data']['image'];
    //         $optimizedContent = file_get_contents($optimizedUrl);
    //         file_put_contents($filePath, $optimizedContent);
    //     } else {
    //         \Log::error('Imagify compression failed', [
    //             'error' => $data['message'] ?? 'Unknown error',
    //             'response' => $data,
    //         ]);
    //     }
    // }


     $fileName = null;


     if ($request->source_type === 'upload' && $request->hasFile('marketing_attachments')) {
          $file = $request->file('marketing_attachments');
          $fileName = time() . '_' . $file->getClientOriginalName();
          $destinationPath = public_path('marketing_kits');
          $file->move($destinationPath, $fileName);
      
          $filePath = $destinationPath . '/' . $fileName;
      
          // Check if the uploaded file is an image
          $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
          $fileMimeType = mime_content_type($filePath);
      
          if (in_array($fileMimeType, $allowedMimeTypes)) {
              // Compress image using Imagify
              $apiKey = '5c67a80e923be51253e2216e814b1e8a0bfff34d'; // replace with your actual API key
      
              $response = Http::withHeaders([
                  'Authorization' => 'token ' . $apiKey,
              ])->attach(
                  'image',
                  file_get_contents($filePath),
                  $fileName
              )->asMultipart()->post('https://app.imagify.io/api/upload/', [
                  [
                      'name' => 'data',
                      'contents' => json_encode([
                          'aggressive' => true,
                      ]),
                  ]
              ]);
      
              $data = json_decode($response->body(), true);
      
              if (isset($data['success']) && $data['success']) {
                  $optimizedUrl = $data['image'];
                  $optimizedContent = file_get_contents($optimizedUrl);
                  file_put_contents($filePath, $optimizedContent);
              } else {
                  \Log::error('Imagify compression failed', [
                      'error' => $data['detail'] ?? 'Unknown error',
                      'response' => $data,
                  ]);
              }
          } else {
              // Skip Imagify for non-image files
              \Log::info("File is not an image. Skipping compression: {$fileName}");
          }
      }
  

      $fileNamethumbnail = '';
      if ($request->hasFile('marketing_thumbnail')) {
          $fileNamethumbnail = time() . '_' . $request->file('marketing_thumbnail')->getClientOriginalName();
          $destinationPath = public_path('marketing_kits_thumbnail');
          $request->file('marketing_thumbnail')->move($destinationPath, $fileNamethumbnail);
          $path = $fileNamethumbnail;
      }


      // Generate a unique category ID
      $add = MarketingKitModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$add) {
        $year = substr(date('y'), -2);
        $marketing_kit_id = 'MK-0001/' . $year;
      } else {
        $data = $add->marketing_kit_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int)$result + 1;
        $requestId = sprintf('MK-%04d', $next_number);
        $year = substr(date('y'), -2);
        $marketing_kit_id = $requestId . '/' . $year;
      }

    //   return $request->buy_items;
      $kit = new MarketingKitModel();
      $kit->marketing_kit_name = $request->marketing_kit_name;
      $kit->marketing_kit_id = $marketing_kit_id;
      $kit->category_id = $request->category_id;
      $kit->sub_category_id = $request->sub_category_id;
      $kit->file_type = $request->file_type;
      $kit->preview_check = $request->preview_check;
      $kit->download_check = $request->download_check;
      $kit->buy_check = $request->buy_check;
      $kit->buy_items = $request->buy_check ? $request->buy_items : null;
      $kit->variant_datas = $request->variant_datas;
      $kit->source_type = $request->source_type;
       if ($request->source_type === 'upload') {
            $kit->marketing_attachments = $fileName;
            $kit->marketing_url = null;
        } else if ($request->source_type === 'url') {
            $kit->marketing_attachments = null;
            $kit->marketing_url = $request->marketing_url;
        }
      $kit->marketing_thumbnail = $fileNamethumbnail;
      $kit->description = $request->description;
      $kit->created_by = auth()->id();
      $kit->updated_by = auth()->id();
      $kit->save();

      // return response()->json(['status' => 'success']);
      return response()->json([
        'status'         => $data['success'] ?? false,
        'original_size'   => $data['data']['original_size'] ?? null,
        'optimized_size'  => $data['data']['optimized_size'] ?? null,
        'saved_bytes'     => $data['data']['saved_bytes'] ?? null,
        'saved_percent'   => $data['data']['saved_percent'] ?? null,
        'message'         => $data['message'] ?? null,
    ]);

  }



 public function MarketingKitUpdate(Request $request)
  {
      $validated = $request->validate([
          'marketing_kit_name' => 'required',
          'category_id' => 'required|integer',
          'sub_category_id' => 'required',
          'file_type' => 'required',
      ]);
    // return $request->all();




     $fileName = null;
     if ($request->source_type === 'upload' && $request->hasFile('marketing_attachments')) {
    $file = $request->file('marketing_attachments');
    $fileName = time() . '_' . $file->getClientOriginalName();
    $destinationPath = public_path('marketing_kits');
    $file->move($destinationPath, $fileName);

    $filePath = $destinationPath . '/' . $fileName;

    // Check if the uploaded file is an image
    $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $fileMimeType = mime_content_type($filePath);

    if (in_array($fileMimeType, $allowedMimeTypes)) {
        // Compress image using Imagify
        $apiKey = '5c67a80e923be51253e2216e814b1e8a0bfff34d';

        $response = Http::withHeaders([
            'Authorization' => 'token ' . $apiKey,
        ])->attach(
            'image',
            file_get_contents($filePath),
            $fileName
        )->asMultipart()->post('https://app.imagify.io/api/upload/', [
            [
                'name' => 'data',
                'contents' => json_encode(['aggressive' => true]),
            ]
        ]);

        $data = json_decode($response->body(), true);

        if (isset($data['success']) && $data['success']) {
            $optimizedUrl = $data['image'];
            $optimizedContent = file_get_contents($optimizedUrl);
            file_put_contents($filePath, $optimizedContent);
        } else {
            \Log::error('Imagify compression failed', [
                'error' => $data['detail'] ?? 'Unknown error',
                'response' => $data,
            ]);
        }
        } else {
            \Log::info("File is not an image. Skipping compression: {$fileName}");
        }
    }
  

   
      $fileNamethumbnail = null;
        if ($request->hasFile('marketing_thumbnail')) {
            $fileNamethumbnail = time() . '_' . $request->file('marketing_thumbnail')->getClientOriginalName();
            $destinationPath = public_path('marketing_kits_thumbnail');
            $request->file('marketing_thumbnail')->move($destinationPath, $fileNamethumbnail);
        }


      // Generate a unique category ID
      $add = MarketingKitModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$add) {
        $year = substr(date('y'), -2);
        $marketing_kit_id = 'MK-0001/' . $year;
      } else {
        $data = $add->marketing_kit_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int)$result + 1;
        $requestId = sprintf('MK-%04d', $next_number);
        $year = substr(date('y'), -2);
        $marketing_kit_id = $requestId . '/' . $year;
      }

    //   return $request->buy_items;
      $kit = MarketingKitModel::where('sno', $request->sno)->first();
        if (!$kit) {
            return response()->json(['status' => false, 'message' => 'Marketing Kit not found.'], 404);
        }
      $kit->marketing_kit_name = $request->marketing_kit_name;
      $kit->marketing_kit_id = $marketing_kit_id;
      $kit->category_id = $request->category_id;
      $kit->sub_category_id = $request->sub_category_id;
      $kit->file_type = $request->file_type;
      $kit->preview_check = $request->preview_check;
      $kit->download_check = $request->download_check;
      $kit->buy_check = $request->buy_check;
      $kit->buy_items = $request->buy_check ? $request->buy_items : null;
      $kit->variant_datas = $request->variant_datas;
      $kit->source_type = $request->source_type;
       if ($request->source_type === 'upload' && $fileName) {
            $kit->marketing_attachments = $fileName;
            $kit->marketing_url = null;
        } elseif ($request->source_type === 'url') {
            $kit->marketing_attachments = null;
            $kit->marketing_url = $request->marketing_url;
        }
        
        // only update thumbnail if present
        if ($fileNamethumbnail) {
            $kit->marketing_thumbnail = $fileNamethumbnail;
        }
      $kit->description = $request->description;
      $kit->updated_by = auth()->id();
      $kit->save();

      // return response()->json(['status' => 'success']);
        return response()->json([
            'status' => true,
            'message' => 'Marketing Kit updated successfully.',
        ]);

  }

  public function MarketingKitList(Request $request) 
   {
    // Step 1: Fetch kits with category name via join
    $query = MarketingKitModel::where('za_marketing_kit.status', 0)
        ->join('marketing_category', 'za_marketing_kit.category_id', '=', 'marketing_category.sno')
        ->select('za_marketing_kit.*', 'marketing_category.category_name as category_name'); // Add category name

    $kits = $query->get();

    // Step 2: Fetch all subcategories (to map later)
    $subcategoriesMap = MarketingKitSubCategoryModel::pluck('marketing_subcategory_name', 'sno')->toArray(); // [34 => "Posters", ...]

    // Step 3: Filter kits
    $kits = $kits->filter(function ($kit) use ($request) {
        $kitSubcats = json_decode($kit->sub_category_id, true);
        if (is_string($kitSubcats)) {
            $kitSubcats = json_decode($kitSubcats, true);
        }

        if (!empty($request->subcategories)) {
            if (!is_array($kitSubcats) || empty(array_intersect($request->subcategories, $kitSubcats))) {
                return false;
            }
        }

        if (!empty($request->variants) && is_array($request->variants)) {
            $variantData = json_decode($kit->variant_datas, true);
            if (!is_array($variantData)) return false;

            foreach ($request->variants as $variantId => $variableIds) {
                if (!is_array($variableIds) || empty($variableIds)) continue;

                $variantBlock = collect($variantData)->firstWhere('variant_id', (string) $variantId);
                if (!$variantBlock || empty($variantBlock['variables'])) return false;

                $kitVariableIds = collect($variantBlock['variables'])
                    ->pluck('variable_id')
                    ->map(fn($id) => (string) $id)
                    ->toArray();

                if (empty(array_intersect($variableIds, $kitVariableIds))) {
                    return false;
                }
            }
        }

        return true;
    })->values();

    // Step 4: Add subcategory names to each kit
    foreach ($kits as $kit) {
        $subcatIds = json_decode($kit->sub_category_id, true);
        if (is_string($subcatIds)) {
            $subcatIds = json_decode($subcatIds, true);
        }

        $kit->subcategory_names = collect($subcatIds)
            ->map(function ($id) use ($subcategoriesMap) {
                return $subcategoriesMap[$id] ?? null;
            })
            ->filter()
            ->values()
            ->toArray();
    }

    // Step 5: Sort
    if ($request->sort === 'New to Old') {
        $kits = $kits->sortByDesc('sno')->values();
    } elseif ($request->sort === 'Old to New') {
        $kits = $kits->sortBy('sno')->values();
    } else {
        $kits = $kits->sortByDesc('sno')->values();
    }

    return response()->json([
        'kits' => $kits,
        'kit_count' => str_pad($kits->count(), 2, '0', STR_PAD_LEFT)
    ]);
}


  public function removeFromCart($cartId, Request $request)
  {
      // Find the cart item by its ID
      $cartItem = MarketingKitCartModel::find($cartId);

      if ($cartItem) {
          // Update the status to 2 (removed)
          $cartItem->status = 2;
          $cartItem->save();

          return response()->json(['success' => true, 'message' => 'Item removed from cart successfully.']);
      }

      return response()->json(['success' => false, 'message' => 'Item not found.'], 404);
  }


  public function softDelete(Request $request)
  {
      $request->validate([
          'id' => 'required|integer',
      ]);

      $kit = MarketingKitModel::where('sno',$request->id)->first();
      if ($kit) {
          $kit->status = 2;
          $kit->updated_by = auth()->id();
          $kit->save();

          return response()->json(['status' => 'success']);
      }

      return response()->json(['status' => 'error', 'message' => 'Kit not found'], 404);
  }

  //   public function MarketingKitView(Request $request,$id)
  //   {
//       $kitsview = MarketingKitModel::where('status', 0)
//           ->where('sno', $id)
//           ->first();

//       if (!$kitsview) {
//           return response()->json(['message' => 'Marketing kit not found'], 404);
//       }

//       // Convert JSON fields to arrays
//       $buy_items = json_decode($kitsview->buy_items, true) ?? [];
//       $subCategoryIds = json_decode($kitsview->sub_category_id, true) ?? [];
//       $colorVarients = json_decode($kitsview->color_varients, true) ?? [];
//       $sizeVarients = json_decode($kitsview->size_varients, true) ?? [];

//       // Category name
//       $category = MarketingKitCategoryModel::where('sno', $kitsview->category_id)->first();

//       // Subcategory names
//       $subCategories = MarketingKitSubCategoryModel::whereIn('sno', $subCategoryIds)->get();

//       // Color details
//       $colorIds = collect($colorVarients)->pluck('color_id')->unique();
//       $colors = VariableModel::whereIn('sno', $colorIds)
//           ->where('variable', 'color')
//           ->get(['sno', 'color_name', 'color_code']);

//       // Size details
//       $sizeIds = collect($sizeVarients)->pluck('size_id')->unique();
//       $sizes = VariableModel::whereIn('sno', $sizeIds)
//           ->where('variable', 'size')
//           ->get(['sno', 'width', 'height']);

//       // Add extra info to the kit object
//       $kitsview->buy_items = $buy_items;
//       $kitsview->category_name = $category?->category_name;
//       $kitsview->sub_categories = $subCategories;
//       $variantDatas = json_decode($kitsview->variant_datas, true) ?? [];

//         // Get all unique variant & variable IDs
//         $variantIds = collect($variantDatas)->pluck('variant_id')->unique();
//         $variableIds = collect($variantDatas)
//             ->pluck('variables')
//             ->flatten(1)
//             ->pluck('variable_id')
//             ->unique();
        
//         // Get variant and variable names
//         $variants = VariantModel::whereIn('sno', $variantIds)->get(['sno', 'variant_name']);
//         $variables = VariableModel::whereIn('sno', $variableIds)->get(['sno', 'variable_name']);
        
//         // Enrich variant_datas
//         $enrichedVariants = [];
        
//         foreach ($variantDatas as $variant) {
//             $variantName = $variants->firstWhere('sno', $variant['variant_id'])?->variant_name ?? null;
        
//             $enrichedVars = [];
//             foreach ($variant['variables'] as $var) {
//                 $variableName = $variables->firstWhere('sno', $var['variable_id'])?->variable_name ?? null;
        
//                 $enrichedVars[] = [
//                     'variable_id' => $var['variable_id'],
//                     'variable_name' => $variableName,
//                     'cost' => $var['cost'],
//                 ];
//             }
        
//             $enrichedVariants[] = [
//                 'variant_id' => $variant['variant_id'],
//                 'variant_name' => $variantName,
//                 'variables' => $enrichedVars,
//             ];
//         }
        
//         $kitsview->variant_details = $enrichedVariants;

//       return response()->json($kitsview);
//   }
  public function MarketingKitView(Request $request, $id)
  {
    $kitsview = MarketingKitModel::where('status', 0)
        ->where('sno', $id)
        ->first();

    if (!$kitsview) {
        return response()->json(['message' => 'Marketing kit not found'], 404);
    }

    // Decode JSON fields
    $buy_items = json_decode($kitsview->buy_items, true) ?? [];
    $subCategoryIds = json_decode($kitsview->sub_category_id, true) ?? [];
    $colorVarients = json_decode($kitsview->color_varients, true) ?? [];
    $sizeVarients = json_decode($kitsview->size_varients, true) ?? [];
    $variantDatas = json_decode($kitsview->variant_datas, true) ?? [];

    // Category & Subcategories
    $category = MarketingKitCategoryModel::find($kitsview->category_id);
    $subCategories = MarketingKitSubCategoryModel::whereIn('sno', $subCategoryIds)->get();

    // Color Details
    $colorIds = collect($colorVarients)->pluck('color_id')->unique();
    $colors = VariableModel::whereIn('sno', $colorIds)->where('variable', 'color')->get(['sno', 'color_name', 'color_code']);

    $enrichedColors = collect($colorVarients)->map(function ($color) use ($colors) {
        $info = $colors->firstWhere('sno', $color['color_id']);
        return array_merge($color, [
            'color_name' => $info->color_name ?? null,
            'color_code' => $info->color_code ?? null,
        ]);
    });

    // Size Details
    $sizeIds = collect($sizeVarients)->pluck('size_id')->unique();
    $sizes = VariableModel::whereIn('sno', $sizeIds)->where('variable', 'size')->get(['sno', 'width', 'height']);

    $enrichedSizes = collect($sizeVarients)->map(function ($size) use ($sizes) {
        $info = $sizes->firstWhere('sno', $size['size_id']);
        return array_merge($size, [
            'width' => $info->width ?? null,
            'height' => $info->height ?? null,
        ]);
    });

    // Variant + Variables
    $variantIds = collect($variantDatas)->pluck('variant_id')->unique();
    $variableIds = collect($variantDatas)->pluck('variables')->flatten(1)->pluck('variable_id')->unique();

    $variants = VariantModel::whereIn('sno', $variantIds)->get(['sno', 'variant_name']);
    $variables = VariablesModel::whereIn('sno', $variableIds)->get(['sno', 'variables_name']);

    $enrichedVariants = collect($variantDatas)->map(function ($variant) use ($variants, $variables) {
        $variantName = $variants->firstWhere('sno', $variant['variant_id'])?->variant_name ?? null;

        $enrichedVars = collect($variant['variables'])->map(function ($var) use ($variables) {
            $variableName = $variables->firstWhere('sno', $var['variable_id'])?->variables_name ?? null;
            return [
                'variable_id' => $var['variable_id'],
                'variable_name' => $variableName,
                'cost' => $var['cost'],
            ];
        });

        return [
            'variant_id' => $variant['variant_id'],
            'variant_name' => $variantName,
            'variables' => $enrichedVars,
        ];
    });

    // Final assembled response
    $kitsview->buy_items = $buy_items;
    $kitsview->category_name = $category?->category_name;
    $kitsview->sub_categories = $subCategories;
    $kitsview->color_details = $enrichedColors;
    $kitsview->size_details = $enrichedSizes;
    $kitsview->variant_details = $enrichedVariants;

    return response()->json($kitsview);
}
 public function downloadKit($id)
 {
    $kit = MarketingKitModel::findOrFail($id);

    // Check type
    if ($kit->source_type === 'upload') {
        $filePath = public_path('marketing_kits/' . $kit->marketing_attachments);

        if (file_exists($filePath)) {
            return response()->download($filePath, $kit->marketing_attachments);
        }
    }

    return abort(404, 'File not found or invalid source type.');
}

  public function MarketingKitEdit(Request $request,$id)
  {
      $kitsview = MarketingKitModel::where('status', 0)
          ->where('sno', $id)
          ->first();

      if (!$kitsview) {
          return response()->json(['message' => 'Marketing kit not found'], 404);
      }

      // Convert JSON fields to arrays
      $buy_items = json_decode($kitsview->buy_items, true) ?? [];
      $subCategoryIds = json_decode($kitsview->sub_category_id, true) ?? [];
      $colorVarients = json_decode($kitsview->color_varients, true) ?? [];
      $sizeVarients = json_decode($kitsview->size_varients, true) ?? [];

      // Category name
      $category = MarketingKitCategoryModel::where('sno', $kitsview->category_id)->first();

      // Subcategory names
      $subCategories = MarketingKitSubCategoryModel::whereIn('sno', $subCategoryIds)->get();

      // Color details
      $colorIds = collect($colorVarients)->pluck('color_id')->unique();
      $colors = VariableModel::whereIn('sno', $colorIds)
          ->where('variable', 'color')
          ->get(['sno', 'color_name', 'color_code']);

      // Size details
      $sizeIds = collect($sizeVarients)->pluck('size_id')->unique();
      $sizes = VariableModel::whereIn('sno', $sizeIds)
          ->where('variable', 'size')
          ->get(['sno', 'width', 'height']);

      // Add extra info to the kit object
      $kitsview->buy_items = $buy_items;
      $kitsview->category_name = $category?->category_name;
      $kitsview->sub_categories = $subCategories;
      $kitsview->color_details = $colorVarients;
      $kitsview->size_details = $sizeVarients;

      // Replace color IDs with names
      $enrichedColors = [];

      foreach ($colorVarients as $color) {
          $colorInfo = $colors->firstWhere('sno', $color['color_id']);
          $color['color_name'] = $colorInfo->color_name ?? null;
          $color['color_code'] = $colorInfo->color_code ?? null;
          $enrichedColors[] = $color;
      }

      $kitsview->color_details = $enrichedColors;

      // Replace size IDs with dimensions
      $enrichedSizes = [];

      foreach ($sizeVarients as $size) {
          $sizeInfo = $sizes->firstWhere('sno', $size['size_id']);
          $size['width'] = $sizeInfo->width ?? null;
          $size['height'] = $sizeInfo->height ?? null;
          $enrichedSizes[] = $size;
      }

      $kitsview->size_details = $enrichedSizes;

      return response()->json($kitsview);
  }
  public function MarketingKitCartView(Request $request,$id)
  {
      $kitsview = MarketingKitModel::where('status', 0)
          ->where('sno', $id)
          ->first();

      if (!$kitsview) {
          return response()->json(['message' => 'Marketing kit not found'], 404);
      }

      // Convert JSON fields to arrays
      $buy_items = json_decode($kitsview->buy_items, true) ?? [];
      $subCategoryIds = json_decode($kitsview->sub_category_id, true) ?? [];
      $colorVarients = json_decode($kitsview->color_varients, true) ?? [];
      $sizeVarients = json_decode($kitsview->size_varients, true) ?? [];

      // Category name
      $category = MarketingKitCategoryModel::where('sno', $kitsview->category_id)->first();

      // Subcategory names
      $subCategories = MarketingKitSubCategoryModel::whereIn('sno', $subCategoryIds)->get();

      // Color details
      $colorIds = collect($colorVarients)->pluck('color_id')->unique();
      $colors = VariableModel::whereIn('sno', $colorIds)
          ->where('variable', 'color')
          ->get(['sno', 'color_name', 'color_code']);

      // Size details
      $sizeIds = collect($sizeVarients)->pluck('size_id')->unique();
      $sizes = VariableModel::whereIn('sno', $sizeIds)
          ->where('variable', 'size')
          ->get(['sno', 'width', 'height']);

      // Add extra info to the kit object
      $kitsview->buy_items = $buy_items;
      $kitsview->category_name = $category?->category_name;
      $kitsview->sub_categories = $subCategories;

     $variantDatas = json_decode($kitsview->variant_datas, true) ?? [];

    // Get all unique variant & variable IDs
    $variantIds = collect($variantDatas)->pluck('variant_id')->unique();
    $variableIds = collect($variantDatas)
        ->pluck('variables')
        ->flatten(1)
        ->pluck('variable_id')
        ->unique();
    
    // Fetch from DB
    $variants = VariantModel::whereIn('sno', $variantIds)->get(['sno', 'variant_name']);
    $variables = VariablesModel::whereIn('sno', $variableIds)->get(['sno', 'variables_name']);
    
    // Enrich variant data
    $enrichedVariants = [];
    
    foreach ($variantDatas as $variant) {
        $variantName = $variants->firstWhere('sno', $variant['variant_id'])?->variant_name ?? null;
    
        $enrichedVars = [];
        foreach ($variant['variables'] as $var) {
            $variableName = $variables->firstWhere('sno', $var['variable_id'])?->variables_name ?? null;
    
            $enrichedVars[] = [
                'variable_id' => $var['variable_id'],
                'variable_name' => $variableName,
                'cost' => $var['cost'],
            ];
        }
    
        $enrichedVariants[] = [
            'variant_id' => $variant['variant_id'],
            'variant_name' => $variantName,
            'variables' => $enrichedVars,
        ];
    }
    
    $kitsview->variant_details = $enrichedVariants;
      // Check for cart existence
        $user_id = auth()->id();
        $branch_id = $request->user()->branch_id;
        $filtered_buy_items = [];

        foreach ($buy_items as $item) {
            $exists = MarketingKitCartModel::where([
                'user_id' => $user_id,
                'branch_id' => $branch_id,
                'marketing_kit_id' => $kitsview->sno,
                'buy_item_id' => $item['index_id'],
                'status' => 0
            ])->exists();

            if (!$exists) {
                $filtered_buy_items[] = $item;
            }
        }

        $kitsview->buy_items = $filtered_buy_items;

      return response()->json($kitsview);
  }
  public function MarketingKitAddToCart(Request $request)
    {
        $validated = $request->validate([
            'marketing_kit_id'     => 'required',
            'buy_item_id'          => 'required'
        ]);
    
        $user_id   = auth()->id();
        $branch_id = $request->user()->branch_id;
    
        // Save or update
        $cartItem = MarketingKitCartModel::updateOrCreate(
            [
                'user_id'         => $user_id,
                'branch_id'       => $branch_id,
                'marketing_kit_id'=> $validated['marketing_kit_id'],
                'buy_item_id'     => $validated['buy_item_id'],
                'status'          => 0 // Active cart only
            ],
            [
                'created_by'         => $user_id,
                'updated_by'         => $user_id,
            ]
        );
    
        return response()->json([
            'message' => 'Item added to cart successfully.',
            'data'    => $cartItem
        ]);
    }
  public function GetCartCount(Request $request)
  {
      $user_id   = auth()->id();
      $branch_id = $request->user()->branch_id;
     $cartcount =   MarketingKitCartModel::where('branch_id',$branch_id)->where('user_id',$user_id)->where('status',0)->count();
     return response()->json($cartcount);
  }
   //   public function GetCartview(Request $request)
   //   {
//     $user_id   = auth()->id();
//     $branch_id = $request->user()->branch_id;

//     $cartcount = MarketingKitCartModel::where('branch_id', $branch_id)
//         ->where('user_id', $user_id)
//         ->where('status', 0)
//         ->count();

//     $cartItems = MarketingKitCartModel::where('branch_id', $branch_id)
//         ->where('user_id', $user_id)
//         ->where('status', 0)
//         ->get();

//     if ($cartItems->isEmpty()) {
//         return response()->json(['message' => 'No items in cart'], 404);
//     }

//     $kitIds = $cartItems->pluck('marketing_kit_id')->unique();
//     $kits = MarketingKitModel::whereIn('sno', $kitIds)->where('status', 0)->get();

//     $response = [];
//     $totalPrice = 0;
//     $totalGst = 0;
//     $totalDeliveryCharge = 0;
//     $totalItemCount = 0;

//     foreach ($cartItems as $cart) {
//         $kit = $kits->firstWhere('sno', $cart->marketing_kit_id);
//         if (!$kit) continue;
    
//         $buyItems = json_decode($kit->buy_items, true) ?? [];
//         $buyItem = collect($buyItems)->firstWhere('index_id', $cart->buy_item_id);
//         $count = (int) ($buyItem['count'] ?? 0);
//         $cost = (int) ($buyItem['cost'] ?? 0);
    
//         $gstPercentage = (float) ($buyItem['gst'] ?? 0);
//         $deliveryCharge = (float) ($buyItem['delivery_charges'] ?? 0);
//         $category = MarketingKitCategoryModel::find($kit->category_id)?->category_name;
    
//         // Decode variant data from kit
//         $kitVariantData = json_decode($kit->variant_datas, true) ?? [];
    
//         // Handle dynamic variants from cart
//         $variantSelections = json_decode($cart->variant_datas, true) ?? [];
//         $variantDatas = [];
    
//         foreach ($variantSelections as $vs) {
//             $variantId = $vs['variant_id'] ?? null;
//             $variableId = $vs['variable_id'] ?? null;
    
//             if (!$variantId || !$variableId) continue;
    
//             // Find variant name and variable name
//             $variantName = VariantModel::find($variantId)?->variant_name;
//             $variable = VariablesModel::find($variableId);
//             $variableName = $variable?->variables_name;
    
//             // Match cost from kit.variant_datas
//             $matchedCost = 0;
//             foreach ($kitVariantData as $group) {
//                 if ((string) $group['variant_id'] === (string) $variantId) {
//                     foreach ($group['variables'] as $v) {
//                         if ((string) $v['variable_id'] === (string) $variableId) {
//                             $matchedCost = (float) ($v['cost'] ?? 0);
//                             break 2;
//                         }
//                     }
//                 }
//             }
    
//             $variantDatas[] = [
//                 'variant_id' => $variantId,
//                 'variant_name' => $variantName,
//                 'variable_id' => $variableId,
//                 'variable_name' => $variableName,
//                 'cost' => $matchedCost,
//             ];
//         }
    
//         // Total price for this cart item (sum of variant costs × count)
//         $variantPriceTotal = array_sum(array_column($variantDatas, 'cost')) * $count;
//         $itemTotal = $variantPriceTotal;
//         $totalPrice += $itemTotal;
    
//         $gstAmount = ($gstPercentage / 100) * $itemTotal;
//         $totalGst += $gstAmount;
//         $totalDeliveryCharge += $deliveryCharge;
//         $totalItemCount += $count;
    
//         $response[] = [
//             'cart_id' => $cart->sno,
//             'marketing_kit_id' => $kit->sno,
//             'buy_item_id' => $cart->buy_item_id,
//             'marketing_kit_name' => $kit->marketing_kit_name,
//             'marketing_attachments' => $kit->marketing_attachments,
//             'marketing_thumbnail' => $kit->marketing_thumbnail,
//             'category_name' => $category,
//             'count' => $count,
//             'cost' => $cost,
//             'variant_datas' => $variantDatas,
//             'gst' => $gstAmount,
//             'delivery_charge' => $deliveryCharge,
//             'item_total' => $itemTotal + $gstAmount + $deliveryCharge,
//         ];
//     }


//     $finalTotal = $totalPrice + $totalGst + $totalDeliveryCharge;

//     return response()->json([
//         'items' => $response,
//         'summary' => [
//             'item_total' => $totalPrice,
//             'gst_value' => $totalGst,
//             'gst_percentage' => $gstPercentage,
//             'total_item' => $cartcount,
//             'delivery_charge' => $totalDeliveryCharge,
//             'final_total' => $finalTotal,
//         ]
//     ]);
// }
  public function GetCartview(Request $request)
  {
    $user_id   = auth()->id();
    $branch_id = $request->user()->branch_id;

    $cartcount = MarketingKitCartModel::where('branch_id', $branch_id)
        ->where('user_id', $user_id)
        ->where('status', 0)
        ->count();

    $cartItems = MarketingKitCartModel::where('branch_id', $branch_id)
        ->where('user_id', $user_id)
        ->where('status', 0)
        ->get();

    if ($cartItems->isEmpty()) {
        return response()->json(['message' => 'No items in cart'], 404);
    }

    $kitIds = $cartItems->pluck('marketing_kit_id')->unique();
    $kits = MarketingKitModel::whereIn('sno', $kitIds)->where('status', 0)->get();

    $response = [];
    $totalPrice = 0;
    $totalGst = 0;
    $totalDeliveryCharge = 0;
    $totalItemCount = 0;

    foreach ($cartItems as $cart) {
        $kit = $kits->firstWhere('sno', $cart->marketing_kit_id);
        if (!$kit) continue;
    
        $buyItems = json_decode($kit->buy_items, true) ?? [];
        $buyItem = collect($buyItems)->firstWhere('index_id', $cart->buy_item_id);
        $count = (int) ($buyItem['count'] ?? 0);
        $cost = (int) ($buyItem['cost'] ?? 0);
    
        $gstPercentage = (float) ($buyItem['gst'] ?? 0);
        $weightValue = (float) ($buyItem['weight_value'] ?? 0);
        $weightUnit = strtolower(trim($buyItem['weight_unit'] ?? 'kg'));
    
        // ✅ Convert to KG
        $weightInKg = ($weightUnit === 'gram') ? $weightValue / 1000 : $weightValue;
    //  return $weightInKg;
        // ✅ Fetch delivery cost based on weight
        $delivery = \App\Models\MarketingKitDeliveryModel::where('range_from', '<=', $weightInKg)
                    ->where('range_to', '>', $weightInKg)
                    ->where('status', '!=', 2)
                    ->first();
                    // return $delivery;
    
        $deliveryCharge = (float) ($delivery->delivery_cost ?? 0);
        $category = MarketingKitCategoryModel::find($kit->category_id)?->category_name;
    
        // Decode variant data from kit
        $kitVariantData = json_decode($kit->variant_datas, true) ?? [];
    
    
    
       
    
        // Total price for this cart item (sum of variant costs × count)
        $itemTotal = $cost;
        $totalPrice += $itemTotal;
    
        $gstAmount = ($gstPercentage / 100) * $itemTotal;
        $totalGst += $gstAmount;
        $totalDeliveryCharge += $deliveryCharge;
        $totalItemCount += $count;
    
        $response[] = [
            'cart_id' => $cart->sno,
            'marketing_kit_id' => $kit->sno,
            'buy_item_id' => $cart->buy_item_id,
            'marketing_kit_name' => $kit->marketing_kit_name,
            'marketing_attachments' => $kit->marketing_attachments,
            'marketing_thumbnail' => $kit->marketing_thumbnail,
            'category_name' => $category,
            'count' => $count,
            'cost' => $cost,
            'gst' => $gstAmount,
            'gstpercentage' => $gstPercentage,
            'delivery_charge' => $deliveryCharge,
            'item_total' => $itemTotal + $gstAmount,
        ];
    }


    $finalTotal = $totalPrice + $totalGst + $totalDeliveryCharge;

    return response()->json([
        'items' => $response,
        'summary' => [
            'item_total' => $totalPrice,
            'gst_value' => $totalGst,
            'gst_percentage' => $gstPercentage,
            'total_item' => $cartcount,
            'delivery_charge' => $totalDeliveryCharge,
            'final_total' => $finalTotal,
        ]
    ]);
}


  public function GetMarketingPayment(Request $request)
  {
    $marketing_kit_id = $request->marketing_kit_id;
    $add_to_cart_id   = $request->add_to_cart_id; // maybe or not it will come one or two add_to_cart_items ?
    $user_id   = auth()->id();
    $branch_id = $request->user()->branch_id;
     if(!empty($add_to_cart_id)){
      $cartItems = MarketingKitCartModel::where('branch_id', $branch_id)->where('sno', $add_to_cart_id)
      ->where('user_id', $user_id)
      ->where('status', 0)
      ->get();
      //we will do after the else condition finished okay
     }else{
      $kitsview = MarketingKitModel::where('status', 0)
          ->where('sno', $marketing_kit_id)
          ->first();

      if (!$kitsview) {
          return response()->json(['message' => 'Marketing kit not found'], 404);
      }

      // Convert JSON fields to arrays
        $buy_items = json_decode($kitsview->buy_items, true) ?? [];
        $subCategoryIds = json_decode($kitsview->sub_category_id, true) ?? [];
        $variantDatas = json_decode($kitsview->variant_datas, true) ?? [];
        
        // Category name
        $category = MarketingKitCategoryModel::where('sno', $kitsview->category_id)->first();
        
        // Subcategory names
        $subCategories = MarketingKitSubCategoryModel::whereIn('sno', $subCategoryIds)->get();
        
        // Fetch variable details used in variants
        $allVariableIds = collect($variantDatas)
            ->pluck('variables')
            ->flatten(1)
            ->pluck('variable_id')
            ->unique();
        $variantIds = collect($variantDatas)->pluck('variant_id')->unique();
        $variantMasters = VariantModel::whereIn('sno', $variantIds)->get(['sno', 'variant_name']);
        $variableDetails = VariablesModel::whereIn('sno', $allVariableIds)->get([
            'sno', 'variables_name'
        ]);
        
        // Enrich variant_datas
        $enrichedVariants = [];
        foreach ($variantDatas as $variant) {
            $enrichedVariables = [];
        
            foreach ($variant['variables'] ?? [] as $variable) {
                $varInfo = $variableDetails->firstWhere('sno', $variable['variable_id']);
                $enrichedVariables[] = [
                    'variable_id' => $variable['variable_id'],
                    'cost'        => $variable['cost'],
                    'name'        => $varInfo->variables_name ?? null,
                ];
            }
        
           $variantMaster = $variantMasters->firstWhere('sno', $variant['variant_id']);

            $enrichedVariants[] = [
                'variant_id'   => $variant['variant_id'],
                'variant_name' => $variantMaster?->variant_name,
                'variables'    => $enrichedVariables
            ];
        }
        
        // Attach to response object
        $kitsview->buy_items       = $buy_items;
        $kitsview->category_name   = $category?->category_name;
        $kitsview->sub_categories  = $subCategories;
        $kitsview->variant_datas   = $enrichedVariants;
        
        // Remove these legacy static keys:
        unset($kitsview->color_varients, $kitsview->size_varients);
        unset($kitsview->color_details, $kitsview->size_details);
        
        // Filter out buy_items already in cart
        $filtered_buy_items = [];
        
        foreach ($buy_items as $item) {
            $exists = MarketingKitCartModel::where([
                'user_id'         => $user_id,
                'branch_id'       => $branch_id,
                'marketing_kit_id'=> $kitsview->sno,
                'buy_item_id'     => $item['index_id'],
                'status'          => 0
            ])->exists();
        
            if (!$exists) {
                $filtered_buy_items[] = $item;
            }
        }
        
        $kitsview->buy_items = $filtered_buy_items;
        return response()->json($kitsview);
     }


  }
  public function storePaymentData(Request $request)
  {
      session([
          'payment_data_razor' => [
              'count'           => $request->count,
              'cost'            => $request->cost,
              'gst'             => $request->gst,
              'delivery'        => $request->delivery,
              'total'           => $request->total,
              'index_id'        => $request->index_id,
              'marketing_kit_id'=> $request->marketing_kit_id,
              'buy_item_id'     => $request->buy_item_id,
              'color_id'        => $request->color_id,
              'size_id'         => $request->size_id,
              'items'           => $request->items,
              'cart_ids'           => $request->cart_ids,
          ]
      ]);

    //   dd($request->all());
      return response()->json(['status' => 'stored']);
  }


  public function showPaymentPage()
  {
    $data = session('payment_data_razor');
    if (!$data) return redirect()->back()->with('error', 'Payment session expired.');

    $api = new Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));

    $order = $api->order->create([
        'receipt'         => uniqid(),
        'amount'          => (int) round(floatval($data['total']) * 100), // ensures it's an integer in paise
        'currency'        => 'INR',
        'payment_capture' => 1
    ]);

    $data['razorpay_order_id'] = $order['id'];

      return view('content.marketing_management.marketing_kit.PaymentRazorPay', compact('data'));
  }

  public function MarketingOrderPayment(Request $request)
  {
    $data = session('payment_data_razor');
    $attributes = $request->only('razorpay_payment_id', 'razorpay_signature', 'razorpay_order_id');
    // dd($request);
    // if (is_string($data)) {
    //     $data = json_decode($data, true);
    // }

    try {
        $api = new Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));
        $api->utility->verifyPaymentSignature($attributes);
        $payment = $api->payment->fetch($attributes['razorpay_payment_id']);
        $paymentDATA =  $payment->toArray();
        // return $paymentDATA;
        // Prepare marketing_item_details
        if (!empty($data['items'])) {
          // decode JSON string into array
          $marketingDetails = json_decode($data['items'], true);
        } else {
          $marketingDetails = [[
            'index_id'         => 1,
            'marketing_kit_id' => $data['marketing_kit_id'],
            'buy_item_id'      => $data['buy_item_id'],
            'color_id'         => $data['color_id'],
            'size_id'          => $data['size_id'],
          ]];

        }




      // Generate a unique category ID

        $add = MarketingKitOrderModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$add) {
            $year = substr(date('y'), -2);
            $order_id = 'ORD-0001/' . $year;
        } else {
            $lastOrderId = $add->order_id;
            $slice = explode('/', $lastOrderId);
            $result = preg_replace('/[^0-9]/', '', $slice[0]);
            $next_number = (int)$result + 1;
            $requestId = sprintf('ORD-%04d', $next_number);
            $year = substr(date('y'), -2);
            $order_id = $requestId . '/' . $year;
        }
        // ✅ Store final order
        MarketingKitOrderModel::create([
            'branch_id'             => auth()->user()->branch_id,
            'user_id'               => auth()->id(),
            'order_id'              => $order_id,
            'razor_pay_order_id'    => $attributes['razorpay_order_id'],
            'transaction_datas'     => json_encode($paymentDATA),
            'order_date'            => now(),
            'courier_id'            => null,
            'count'                 => !empty($data['items']) ? $data['count'] : 1, // conditional count
            'total_amount'          => $data['total'],
            'marketing_item_details' => json_encode($marketingDetails),
            'created_by'            => auth()->id(),
            'updated_by'            => auth()->id(),
            'status'                => 0,
        ]);

        // Loop through the cart_ids and update their status
        if (!empty($data['cart_ids']) && is_array($data['cart_ids'])) {
          foreach ($data['cart_ids'] as $cartId) {
              if ($cartId) {
                  $cartItem = MarketingKitCartModel::find($cartId);
                  if ($cartItem) {
                      $cartItem->status = 2; // Mark as removed
                      $cartItem->save();
                  }
              }
          }
        }


        session()->forget('payment_data_razor');
        return redirect('/marketing_order')->with('success', 'Payment verification Success.');
    } catch (\Exception $e) {
        return redirect('/payment-failure')->with('error', 'Payment verification failed.');
    }
}

   //   public function MarketingKitFilterList()
   //   {
       
//         $marketing = MarketingKitModel::get();
//         $categories = MarketingKitCategoryModel::where('status', 0)->get(['sno', 'category_name']);
//         $subCategories = MarketingKitSubCategoryModel::where('status', 0)->get(['sno', 'marketing_category_id', 'marketing_subcategory_name']);
    
//         $variantList = VariantModel::where('status', 0)->get(['sno', 'variant_name']);
//         $variableList = VariablesModel::where('status', 0)->get(['sno', 'variant_id', 'variables_name']);
    
//         return response()->json([
//             'categories' => $categories,
//             'subcategories' => $subCategories,
//             'variants' => $variantList,
//             'variables' => $variableList,
//         ]);
//     }
  public function MarketingKitFilterList() 
  {
    $categories = MarketingKitCategoryModel::where('status', 0)->get(['sno', 'category_name']);

    $subCategories = MarketingKitSubCategoryModel::where('status', 0)
        ->get(['sno', 'marketing_category_id', 'marketing_subcategory_name']);

    // Count marketing kits per subcategory
    $kits = MarketingKitModel::where('status', 0)->get(['sub_category_id']);

    $subcatCounts = [];

    foreach ($kits as $kit) {
        $subcatIds = json_decode($kit->sub_category_id, true);
        if (is_string($subcatIds)) $subcatIds = json_decode($subcatIds, true);

        if (is_array($subcatIds)) {
            foreach ($subcatIds as $subId) {
                if (!isset($subcatCounts[$subId])) $subcatCounts[$subId] = 0;
                $subcatCounts[$subId]++;
            }
        }
    }

    // Add count to each subcategory
    $subCategories = $subCategories->map(function ($sub) use ($subcatCounts) {
        $sub->kit_count = $subcatCounts[$sub->sno] ?? 0;
        return $sub;
    });

    $variantList = VariantModel::where('status', 0)->get(['sno', 'variant_name']);
    $variableList = VariablesModel::where('status', 0)->get(['sno', 'variant_id', 'variables_name']);

    return response()->json([
        'categories' => $categories,
        'subcategories' => $subCategories,
        'variants' => $variantList,
        'variables' => $variableList,
    ]);
}


  public function orders(Request $request)
  {
        $branch_id = $request->user()->branch_id;
        // return $branch_id;

        $order_list = MarketingKitOrderModel::select('za_marketing_kit_orders.*', 'za_staff.sno AS staff_sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_branch.branch_type', 'za_branch.branch_name', 'za_branch.franchise_name')
             ->leftJoin('users', 'za_marketing_kit_orders.user_id', '=', 'users.id')
            ->leftJoin('za_staff', 'users.user_id', '=', 'za_staff.sno')
            ->leftJoin('za_branch', 'za_marketing_kit_orders.branch_id', '=', 'za_branch.sno')
            ->where('za_marketing_kit_orders.status', '!=', 2)
            ->where('za_marketing_kit_orders.branch_id', $branch_id)
            ->get();

        return view('content.marketing_management.marketing_kit.marketing_order',[
            'order_list' => $order_list
        ]);
    } 

  public function deliverOrder(Request $request)
   {
        // return $request;

        $order_sno = $request->order_sno;
        $branch_id = $request->user()->branch_id;

        $order = MarketingKitOrderModel::where('sno', $order_sno)->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

        if($order){
            $order->status = 4;
            $order->delivered_date = date('Y-m-d');
            $order->updated_by = $request->user()->user_id;
            $order->updated_at = date('Y-m-d');
        }
        // return $order;

        $order->update();

        if ($order) {
            session()->flash('toastr', [
              'type' => 'success',
              'message' => 'Order Delivered Successfully!'
            ]);
          } else {
            session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Could not deliver the Order!'
            ]);
          }
        
        return redirect()->back()->with('success', 'Order Delivered successfully!');
    }

  public function EditOrder($sno, Request $request)
   {
        $branch_id = $request->user()->branch_id;
        $get_order = MarketingKitOrderModel::where('sno', $sno)->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $get_order
          ], 200);
        
    }

  public function updateOrder(Request $request)
  {
        // return $request;

        $id = $request->order_edit_sno;
        $courier_name = $request->order_courier_name;
        $courier_tracking_id = $request->courier_tracking_id;

        $branch_id = $request->user()->branch_id;

        $get_order = MarketingKitOrderModel::where('sno', $id)->where('branch_id', $branch_id)->where('status', '!=', 2)->first();
        // return $get_order;

        if($get_order){
            $get_order->courier_name = $courier_name;
            $get_order->courier_id = $courier_tracking_id;
            $get_order->status = 3;
            $get_order->updated_by = $request->user()->user_id;
            $get_order->updated_at = now();
            // return $get_order;

            $get_order->update();

            if ($get_order) {
                session()->flash('toastr', [
                  'type' => 'success',
                  'message' => 'Order updated Successfully!'
                ]);
              } else {
                session()->flash('toastr', [
                  'type' => 'error',
                  'message' => 'Could not update the Order!'
                ]);
              }
            
            return redirect()->back()->with('success', 'Order updated successfully!');
        }else{
            return redirect()->back()->with('error', 'Order not found!');
        }
        
    }


  public function Feedback(Request $request)
   {
        // return $request;
        $id = $request->order_feed_sno;
        $rating = $request->order_ratings_hidden;
        $feedback = $request->ord_feedback;

        $branch_id = $request->user()->branch_id;

        $get_order = MarketingKitOrderModel::where('sno', $id)->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

        // return $get_order;

        if($get_order){
            $get_order->order_rating = $rating;
            $get_order->order_feedback = $feedback;
            $get_order->updated_by = $request->user()->user_id;
            $get_order->updated_at = now();
            // return $get_order;

            $get_order->update();

            if ($get_order) {
                session()->flash('toastr', [
                  'type' => 'success',
                  'message' => 'Order Reviewed Successfully!'
                ]);
              } else {
                session()->flash('toastr', [
                  'type' => 'error',
                  'message' => 'Could not review the Order!'
                ]);
              }
            
            return redirect()->back()->with('success', 'Order reviewed successfully!');
        }else{
            return redirect()->back()->with('error', 'Order not found!');
        }
    }

  public function viewOrder($id, Request $request)
   {
        $branch_id = $request->user()->branch_id;
        $get_order = MarketingKitOrderModel::select('za_marketing_kit_orders.*', 'za_staff.sno AS staff_sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_branch.branch_type', 'za_branch.branch_name', 'za_branch.franchise_name')
            ->leftJoin('za_staff', 'za_marketing_kit_orders.user_id', '=', 'za_staff.sno')
            ->leftJoin('za_branch', 'za_marketing_kit_orders.branch_id', '=', 'za_branch.sno')
            ->where('za_marketing_kit_orders.status', '!=', 2)
            ->where('za_marketing_kit_orders.sno', '=', $id)
            ->where('za_marketing_kit_orders.branch_id', $branch_id)
            ->first();

        $user_id   = $get_order->user_id;
        $branch_id = $request->user()->branch_id;
        $cartcount =   MarketingKitCartModel::where('branch_id',$branch_id)->where('user_id',$user_id)->where('status',0)->count();
        $cartItems = MarketingKitCartModel::where('branch_id', $branch_id)
            ->where('user_id', $user_id)
            ->where('status', 0)
            ->get();

        if ($cartItems->isEmpty()) {
            return response()->json(['message' => 'No items in cart'], 404);
        }

        $kitIds = $cartItems->pluck('marketing_kit_id')->unique();
        $kits = MarketingKitModel::whereIn('sno', $kitIds)->where('status', 0)->get();

        $response = [];
        $totalPrice = 0;
        $totalGst = 0;
        $totalDeliveryCharge = 0;
        $totalItemCount = 0; // Keep track of total item count

        foreach ($cartItems as $cart) {
            $kit = $kits->firstWhere('sno', $cart->marketing_kit_id);
            if (!$kit) continue;

            // Decode JSON fields
            $buyItems = json_decode($kit->buy_items, true) ?? [];
            $colorVariants = json_decode($kit->color_varients, true) ?? [];
            $sizeVariants = json_decode($kit->size_varients, true) ?? [];

            // Get buy item
            $buyItem = collect($buyItems)->firstWhere('index_id', $cart->buy_item_id);
            $count = (int) ($buyItem['count'] ?? 0);

            // GST and delivery charges from buy_item
            $gstPercentage = (float) ($buyItem['gst'] ?? 0); // GST percentage
            $deliveryCharge = (float) ($buyItem['delivery_charges'] ?? 0);

            // Category name
            $category = MarketingKitCategoryModel::find($kit->category_id)?->category_name;

            // Color info
            $colorInfo = collect($colorVariants)->firstWhere('color_id', $cart->color_id);
            $colorMeta = VariableModel::where('sno', $cart->color_id)->where('variable', 'color')->first();
            $colorPrice = (float) ($colorInfo['cost'] ?? 0);

            // Size info
            $sizeInfo = collect($sizeVariants)->firstWhere('size_id', $cart->size_id);
            $sizeMeta = VariableModel::where('sno', $cart->size_id)->where('variable', 'size')->first();
            $sizePrice = (float) ($sizeInfo['cost'] ?? 0);

            // Final price for this entry (before GST)
            $itemTotal = ($colorPrice + $sizePrice) * $count;
            $totalPrice += $itemTotal;

            // Calculate GST amount based on percentage
            $gstAmount = ($gstPercentage / 100) * $itemTotal;
            $totalGst += $gstAmount;

            // Delivery charge (multiply by item count)
            $totalDeliveryCharge += $deliveryCharge;

            // Total item count
            $totalItemCount += $count;

            $response[] = [
                'cart_id' => $cart->sno,
                'marketing_kit_id' => $kit->sno,
                'marketing_kit_name' => $kit->marketing_kit_name,
                'marketing_attachments' => $kit->marketing_attachments,
                'category_name' => $category,
                'count' => $count,
                'color' => [
                    'id' => $cart->color_id,
                    'name' => $colorMeta?->color_name,
                    'code' => $colorMeta?->color_code,
                    'price' => $colorPrice,
                ],
                'size' => [
                    'id' => $cart->size_id,
                    'width' => $sizeMeta?->width,
                    'height' => $sizeMeta?->height,
                    'price' => $sizePrice,
                ],
                'item_total' => $itemTotal + $gstAmount + $deliveryCharge,
            ];
        }

        // Final totals (add GST and delivery charges)
        $finalTotal = $totalPrice + $totalGst + $totalDeliveryCharge;

        // return $response;

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => [
                'data' => $get_order,
                'items' => $response,
                'summary' => [
                    'item_total' => $totalPrice,
                    'gst_value'  => $totalGst,
                    'gst_percentage'  => $gstPercentage,
                    'total_item' => $cartcount, // Total item count across cart
                    'delivery_charge' => $totalDeliveryCharge,
                    'final_total' => $finalTotal,
                ]
            ]
          ], 200);
    }

  

    //  try{
    //             $order = $api->order->create([
    //                 'receipt' => $order_no,
    //                 'amount' => $amount *100,
    //                 'currency' => $currency,
    //             ]);
    //         } catch (\Razorpay\Api\Errors\ServerError $e) {
    //             // Razorpay server error
    //             return 'Razorpay Server Error: ' . $e->getMessage();
    //         } catch (\Razorpay\Api\Errors\Base $e) {
    //             // Razorpay API error (like bad request, unauthorized, etc.)
    //             return 'Razorpay API Error: ' . $e->getMessage();
    //         } catch (\Exception $e) {
    //             // Any other error (network, PHP, etc.)
    //             return 'Unexpected Error: ' . $e->getMessage();
    //         }

}
