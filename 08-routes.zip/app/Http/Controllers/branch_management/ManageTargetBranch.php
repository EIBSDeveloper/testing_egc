<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManageTargetModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use Illuminate\Support\Facades\DB;
use App\Models\CustomerModel;
use App\Models\BranchModel; 
class ManageTargetBranch extends Controller
{


  public function index()
    {
        return view('content.branch_management.manage_target');
    }

       public function getTargets(Request $request)
    {
        // Convert month name to numeric month (e.g., "May" → 05)
        $monthNumber = date('m', strtotime("1 " . $request->month));
    
        // Format date string as 'YYYY-MM-01'
        $targetDate = $request->year . '-' . $monthNumber . '-01';
    
        // Fetch target record for given branch and date
        $targets = ManageTargetModel::where('branch_target.branch_id', $request->branch_id)
                    ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->first();
    
        return response()->json(['status' => 200, 'data' => $targets]);
    }
    
    // public function getTargetsTeam(Request $request)
    // {
    //     $monthNumber = date('m', strtotime("1 " . $request->month));
    //     $targetDate = $request->year . '-' . $monthNumber . '-01';
    //     $year = $request->year;
    //     $month = $monthNumber;
    
    //     // Fetch target
    //     $targets = ManageTargetModel::where('branch_target.branch_id', $request->branch_id)
    //                 ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
    //                 ->where('branch_target.date', $targetDate)
    //                 ->select('branch_target.*') // Ensure you're returning only target column
    //                 ->first();
    
    //     // Old payments
    //     $totalPaidAmountOld = 0;
    
    //     // New payments
    //     // $totalPaidAmountNew = DB::table('et_payment')
    //     //     ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
    //     //     ->where('et_customer.branch_id', $request->branch_id)
    //     //     ->where('et_payment.status', 1)
    //     //     ->where('et_customer.status', 0)
    //     //     ->where('et_payment.amount', '>', 0)
    //     //     ->whereYear('et_payment.initialPayDate', $year)
    //     //     ->whereMonth('et_payment.initialPayDate', $month)
    //     //     ->sum('et_payment.paidAmount');
    //     $totalPaidAmountNew =0;
    //          $transaction = DB::table('et_transaction')
    //                  ->where('et_transaction.branch_id', $request->branch_id)
    //                   ->whereYear('et_transaction.transaction_date', $year)
    //                 ->whereMonth('et_transaction.transaction_date', $month)
    //                  ->sum('et_transaction.credit');
                    
    //             // $targetActual = $totalPaidAmountOld + $totalPaidAmountNew;
    //             $targetActual = $transaction;
    
    //     // Post-sale & pre-sale actuals (count only)
    //     // $postSaleActual = CustomerModel::whereIn('status', [0, 6])
    //     //     ->where('post_sale_check', 1)
    //     //     ->where('branch_id', $request->branch_id)
    //     //     ->whereYear('created_at', $year)
    //     //     ->whereMonth('created_at', $month)
    //     //     ->count();
    //         //  $postSaleActual = CustomerModel::join('et_training', 'et_customer.sno', '=', 'et_training.customer_id')
    //         // ->whereIn('et_customer.status', [0, 6])
    //         // ->where('et_customer.post_sale_check', 1)
    //         // ->where('et_training.post_sale_check', 1)
    //         // ->where('et_training.branch_id', $request->branch_id)
    //         // ->whereYear('et_training.created_at', $year)
    //         // ->whereMonth('et_training.created_at', $month)
    //         // ->distinct('et_training.sno')
    //         // ->count('et_training.sno');
            
    //         $postSaleActual = 0;
    
    //     $preSaleActual = CustomerModel::whereIn('status', [0, 6]) 
    //         ->where('post_sale_check', 0)
    //         ->where('branch_id', $request->branch_id)
    //         ->whereYear('created_at', $year)
    //         ->whereMonth('created_at', $month)
    //         ->count();
    
    //     return response()->json([
    //         'status' => 200,
    //         'data' => $targets,
    //         'actuals' => [
    //             'target_actual' => $targetActual,
    //             'post_sale_actual' => $postSaleActual,
    //             'pre_sale_actual' => $preSaleActual,
    //         ]
    //     ]);
    // }

     public function getTargetsTeam(Request $request)
    {
        $monthNumber = date('m', strtotime("1 " . $request->month));
        $targetDate = $request->year . '-' . $monthNumber . '-01';
        $year = $request->year;
        $month = $monthNumber;
        $branch_id = $request->user()->branch_id;
        $helper = new \App\Helpers\Helpers();
   
        // Fetch target
        $targets = ManageTargetModel::where('branch_target.branch_id', $request->branch_id)
                    ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();
   
       $branch = BranchModel::where('sno', $branch_id)
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->first();
 
        $gstPercentage = $branch ? $branch->gst_percentage  : 18;
 
        $transactionTotalNet = 0; // final net after GST
 
        // 1. INR transactions
        $transactionInr = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_lead.status', '!=', 2)
            ->where('et_customer.status', 0)
            ->where('et_transaction.payment_status', 1)
            ->where('et_payment.currency', 'INR')
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->select('et_payment.paid_amount as paidAmount', 'et_proposal.gst_perc')
            ->get();
 
        foreach ($transactionInr as $row) {
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc / 100 : ($branch ? $branch->gst_percentage / 100 : 0.18);
            $net = $row->paidAmount / (1 + $gstRate);
            $transactionTotalNet += $net;
        }
 
        // 2. Non-INR with already converted INR total
        $transactionNonInrConvert = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_lead.status', '!=', 2)
            ->where('et_customer.status', 0)
            ->where('et_transaction.payment_status', 1)
            ->whereNot('et_payment.currency', 'INR')
            ->where('et_transaction.total_amount_inr', '>', 0)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->select('et_transaction.total_amount_inr', 'et_proposal.gst_perc')
            ->get();
 
        foreach ($transactionNonInrConvert as $row) {
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc / 100 : ($branch ? $branch->gst_percentage / 100 : 0.18);
            $net = $row->total_amount_inr / (1 + $gstRate);
            $transactionTotalNet += $net;
        }
 
        // 3. Non-INR need conversion
        $transactionNonInr = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_lead.status', '!=', 2)
            ->where('et_customer.status', 0)
            ->where('et_transaction.payment_status', 1)
            ->whereNot('et_payment.currency', 'INR')
            ->where(function ($q) {
                $q->where('et_transaction.total_amount_inr', '<', 0)
                    ->orWhereNull('et_transaction.total_amount_inr');
            })
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->select('et_payment.paid_amount as paidAmount', 'et_proposal.gst_perc', 'et_country_currencies.currency_code')
            ->get();
 
        foreach ($transactionNonInr as $row) {
            $convertedInr = $helper->ConvertedAmountInr($row->currency_code, $row->paidAmount);
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc / 100 : ($branch ? $branch->gst_percentage / 100 : 0.18);
            $net = $convertedInr / (1 + $gstRate);
            $transactionTotalNet += $net;
        }
 
        // Final net collection (matches verified_collection_net style)
        $targetActual = round($transactionTotalNet,2);
 
        $customerConvertDataPost = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_customer.cus_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                    ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.proposal_id = et_proposal.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', '>', 1)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
             ->distinct('et_customer.sno')
            ->get();
 
        $postSaleActual = count($customerConvertDataPost);
 
        $customerConvertData = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                             SELECT MIN(ep.transaction_date)
                             FROM et_payment ep
                             WHERE ep.customer_id = et_customer.sno
                         )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', '>', 1)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();
 
        $preSaleActual = count($customerConvertData);
 
 
 
        return response()->json([
            'status' => 200,
            'data' => $targets,
            'actuals' => [
                'target_actual' => round($targetActual),
                'post_sale_actual' => $postSaleActual,
                'pre_sale_actual' => $preSaleActual,
            ]
        ]);
    }
    
    
    public function updateTargets(Request $request)
{
    $request->validate([
        'branch_id' => 'required|integer',
        'no_of_registrations' => 'required|integer|min:0',
        'post_sale' => 'required|integer|min:0',
        'monthly_target' => 'required|integer|min:0',
    ]);

    // Convert month name to numeric month (e.g., "May" → 05)
        $monthNumber = date('m', strtotime("1 " . $request->month));
    
        // Format date string as 'YYYY-MM-01'
        $targetDate = $request->year . '-' . $monthNumber . '-01';
    $userId = auth()->user()->user_id ?? 0; // Get current logged-in user

    // Check if record already exists
    $existing = ManageTargetModel::where('branch_id', $request->branch_id)
                ->where('date', $targetDate)
                ->first();

    if ($existing) {
        // Update path
        $existing->no_of_registrations = $request->no_of_registrations;
        $existing->post_sale = $request->post_sale;
        $existing->monthly_target = $request->monthly_target;
        $existing->updated_by = $userId;
        $existing->save();
    } else {
        // Insert path
        ManageTargetModel::create([
            'branch_id' => $request->branch_id,
            'date' => $targetDate,
            'no_of_registrations' => $request->no_of_registrations,
             'post_sale' => $request->post_sale,
            'monthly_target' => $request->monthly_target,
            'created_by' => $userId,
            'updated_by' => $userId,
        ]);
    }

    return response()->json([
        'status' => 200,
        'message' => 'Target saved successfully.'
    ]);
}



}
