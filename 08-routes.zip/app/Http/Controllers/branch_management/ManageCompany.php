<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
// Models
use App\Models\ManageCompanyModel;
use App\Models\User;
use App\Models\BranchModel;
use App\Models\CompanyTypeModel;

class ManageCompany extends Controller
{
  public function index()
  {
    $Company = ManageCompanyModel::where('et_company.status', '!=', 2)
      ->select('et_company.*', 'et_company_type.company_type_name', 'et_company_type.slug_name', 'et_countries.name', 'et_states.name as statename', 'et_cities.name as citiesname')
      ->leftJoin('et_company_type', 'et_company.company_type', 'et_company_type.sno')
      ->leftJoin('et_countries', 'et_company.company_country', 'et_countries.id')
      ->leftJoin('et_states', 'et_company.company_state', 'et_states.id')
      ->leftJoin('et_cities', 'et_company.company_city', 'et_cities.id')
      ->orderBy('et_company.sno', 'desc')->get();

    // return $Company;
    $Company_type_list = CompanyTypeModel::where('status', 0)->orderBy('company_type_name', 'ASC')->get();
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.branch_management.manage_company.list', [
      'ListTable' => $Company,
      'Company_type_list' => $Company_type_list,
      'pageConfigs' => $pageConfigs
    ]);
  }
 public function List()
  {
    $company = ManageCompanyModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $company
    ], 200);
  }
  public function Status($id, Request $request)
  {

    $staff =  ManageCompanyModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Company  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Company  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Company  Status!',
        'error_msg' => 'Could not, update  Company  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $exit_entity  = DB::table('et_entity')->where('company_id', $id)->first();
    if($exit_entity){
        return response([
        'status'    => 302,
        'message'   => 'Deletion not allowed: This company is linked to one or more entities',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
    $upd_StaffModel = ManageCompanyModel::where('sno', $id)->first();
    $upd_StaffModel->status = 2;
    $upd_StaffModel->Update();

    if ($upd_StaffModel) {
      return response([
        'status'    => 200,
        'message'   => 'Company Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Company ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
  public function View($id)
  {
    $data =  ManageCompanyModel::where('et_company.status', '!=', 2)
      ->select('et_company.*', 'et_company_type.company_type_name', 'et_company_type.slug_name', 'et_countries.name', 'et_states.name as statename', 'et_cities.name as citiesname')
      ->leftJoin('et_company_type', 'et_company.company_type', 'et_company_type.sno')
      ->leftJoin('et_countries', 'et_company.company_country', 'et_countries.id')
      ->leftJoin('et_states', 'et_company.company_state', 'et_states.id')
      ->leftJoin('et_cities', 'et_company.company_city', 'et_cities.id')
      ->orderBy('et_company.sno', 'desc')->where('et_company.sno', $id)->first();

    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Company not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Company fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  public function Add(Request $request)
  {
      $chk = ManageCompanyModel::where('company_name', $request->company_name)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Company Name already Exists!'
        ]);
        return redirect()->back();
      }
    $category_check = ManageCompanyModel::orderBy('sno', 'desc')->first();

    if (!$category_check) {

      $year = substr(date('y'), -2);
      $company_id = 'ETC-0001/' . $year;
    } else {

      $data = $category_check->company_id;
      $slice = explode('/', $data);
      $result = preg_replace('/[^0-9]/', '', $slice[0]);

      $next_number = (int) $result + 1;
      $request_id = sprintf('ETC-%04d', $next_number);

      $year = substr(date('y'), -2);
      $company_id = $request_id . '/' . $year;
    }
    $user_id = $request->user()->user_id;
    $Add = new ManageCompanyModel();

    $Add->company_id = $company_id;
    $Add->company_name = $request->company_name;
    $Add->company_type = $request->company_type;
    $Add->company_mail = $request->company_mail;
    $Add->company_website = $request->website_url;
    $Add->company_ct_person = $request->ct_person;
    $Add->company_ct_number = $request->ct_per_mobile_no;
    $Add->company_country = $request->country;
    $Add->company_state = $request->state;
    $Add->company_city = $request->city;
    $Add->company_area = $request->area_street;
    $Add->company_door_no = $request->door_flat_no;
    $Add->company_pincode = $request->pincode;
    $Add->company_gst = $request->gst_no;
    $Add->company_cin = $request->cin_no;
    $Add->company_pan = $request->pan_no;
    $Add->company_desc = $request->company_desc;
    $Add->company_bank_name = $request->comapny_bank_name;
    $Add->company_bank_branch = $request->comapny_bank_branch;
    $Add->company_acc_holder = $request->comapny_acc_holder;
    $Add->company_acc_no = $request->comapny_acc_no;
    $Add->company_ifsc = $request->comapny_bank_ifsc;
    $Add->created_by = $user_id;
    $Add->updated_by = $user_id;

    $Add->save();

    if ($Add) {
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Company added Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Company!'
      ]);
    }

    return redirect()->back();

    return $Add;
  }
  public function Update(Request $request)
  {

    $user_id = $request->user()->user_id;
    $id = $request->edit_id;
    
    $chk = ManageCompanyModel::where('company_name', $request->company_name)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Company Name already Exists!'
        ]);
        return redirect()->back();
      }
    $update = ManageCompanyModel::where('sno', $id)->first();
    $update->company_name = $request->company_name;
    $update->company_type = $request->company_type;
    $update->company_mail = $request->company_mail;
    $update->company_website = $request->website_url;
    $update->company_ct_person = $request->ct_person;
    $update->company_ct_number = $request->ct_per_mobile_no;
    $update->company_country = $request->country;
    $update->company_state = $request->state;
    $update->company_city = $request->city;
    $update->company_area = $request->area_street;
    $update->company_door_no = $request->door_flat_no;
    $update->company_pincode = $request->pincode;
    $update->company_gst = $request->gst_no;
    $update->company_cin = $request->cin_no;
    $update->company_pan = $request->pan_no;
    $update->company_desc = $request->company_desc;
    $update->company_bank_name = $request->comapny_bank_name;
    $update->company_bank_branch = $request->comapny_bank_branch;
    $update->company_acc_holder = $request->comapny_acc_holder;
    $update->company_acc_no = $request->comapny_acc_no;
    $update->company_ifsc = $request->comapny_bank_ifsc;
    $update->created_by = $user_id;
    $update->updated_by = $user_id;

    $update->update();

    if ($update) {
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Company Updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Company!'
      ]);
    }

    return redirect()->back();

    return $Add;
  }
  public function changeBranch(Request $request)
    {
        $validated = $request->validate([
          'branch_id' => 'required', // Validate that the branch exists
        ]);
        
        // Update the user's role_id in the users table
        $branch    =  BranchModel::where('sno', $validated['branch_id'])->first();
        $entity_id = $branch->entity_id ?? 1;
        // Update the user's branch_id in the users table
        $user =  User::where('user_id', $request->user()->user_id)->first();
        if ($user) {
          $user->branch_id = $validated['branch_id'];
          $user->entity_id = $entity_id;
          $user->save();
        }
    
        return response()->json(['success' => true]);
    }
   public function changeRole(Request $request)
    {
        $validated = $request->validate([
          'role_id' => 'required', // Validate that the branch exists
        ]);
    
        
         
        $user =  User::where('user_id', $request->user()->user_id)->where('role_id', $request->user()->role_id)->first();
        if ($user) {
          $user->role_id = $validated['role_id'];
         
          $user->save();
        }
    
        return response()->json(['success' => true]);
    }
    public function getUsersByRole(Request $request)
    {
        $request->validate([
            'role_id' => 'required|integer',
        ]);
        //   return $request->user()->branch_id;
    
        $users = User::where('et_staff.role_id', $request->role_id)->where('users.branch_id', $request->user()->branch_id)
                ->join('et_staff', 'users.user_id', '=', 'et_staff.sno')
                ->where('et_staff.status', 0) // Only active users
                ->where('et_staff.sno','>', 0) // Only active users
                ->get(['et_staff.sno','et_staff.staff_name']); // Fetch only required columns
    
        return response()->json(['users' => $users]);
    }
    public function changeUser(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,user_id', // Ensure user exists
        ]);
    
        $newUser = User::where('user_id', $request->user_id)->first();
    
        if (!$newUser) {
            return response()->json(['success' => false, 'message' => 'User not found.'], 404);
        }
    
        // Generate new token for the selected user
        $token = $newUser->createToken('SuperUserToken')->plainTextToken;
    
        // Store the token in session or database as per your requirement
        session(['super_user_token' => $token]); // For session-based auth
    
        // If storing in DB, update the super_user_token column
        $newUser->update(['super_user_token' => $token]);
    
        // Log in as the new user
        Auth::loginUsingId($newUser->id);
    
        return response()->json([
            'success' => true,
            'message' => 'User switched successfully.',
            'token' => $token
        ]);
    }

  public function checkDuplicates(Request $request)
  {
    $field = $request->field;
    $value = $request->value;
    $currentSno = $request->sno;

    $query = DB::table('et_company')->where($field, $value);

    if (!empty($currentSno)) {
      $query->where('sno', '!=', $currentSno);
    }

    $exists = $query->exists();

    return response()->json([
      'exists' => $exists,
      'message' => $exists ? ucfirst(str_replace('_', ' ', $field)) . ' already exists.' : ''
    ]);
  }
}