<?php

namespace App\Http\Controllers\branch_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\CompanyTypeModel;
use App\Models\ManageCompanyModel;
use App\Models\ManageEntityModel;
use Illuminate\Support\Facades\DB;

class ManageEntity extends Controller
{
  public function index()
  {
    $Entity = ManageEntityModel::where('et_entity.status', '!=', 2)
      ->select('et_entity.*', 'et_countries.name', 'et_states.name as statename', 'et_cities.name as citiesname', 'et_company.company_name')
      ->leftJoin('et_countries', 'et_entity.entity_country', 'et_countries.id')
      ->leftJoin('et_states', 'et_entity.entity_state', 'et_states.id')
      ->leftJoin('et_cities', 'et_entity.entity_city', 'et_cities.id')
      ->leftJoin('et_company', 'et_company.sno', 'et_entity.company_id')
      ->orderBy('et_entity.sno', 'desc')->get();

    // return $Company;
    $Company = ManageCompanyModel::where('status', 0)->orderBy('company_name', 'ASC')->get();
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.branch_management.manage_entity.list', [
      'ListTable' => $Entity,
      'Company' => $Company,
      'pageConfigs' => $pageConfigs
    ]);
  }
  
   public function List(Request $request)
  {

      $company_id = $request->input('company_id');
      $entity = ManageEntityModel::where('status', 0)->where('company_id', $company_id)->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $entity
      ], 200);
  }
   public function DropdownList(Request $request)
  {

    $entity = ManageEntityModel::where('status', 0)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $entity
    ], 200);
  }
  public function Status($id, Request $request)
  {

    $staff =  ManageEntityModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Entity  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Entity  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Entity  Status!',
        'error_msg' => 'Could not, update  Entity  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_StaffModel = ManageEntityModel::where('sno', $id)->first();
    $upd_StaffModel->status = 2;
    $upd_StaffModel->Update();

    if ($upd_StaffModel) {
      return response([
        'status'    => 200,
        'message'   => 'Entity Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Entity ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
  public function View($id)
  {
    $data = ManageEntityModel::select('et_entity.*', 'et_countries.name', 'et_states.name as statename', 'et_cities.name as citiesname', 'et_company.company_name')
      ->leftJoin('et_countries', 'et_entity.entity_country', 'et_countries.id')
      ->leftJoin('et_states', 'et_entity.entity_state', 'et_states.id')
      ->leftJoin('et_cities', 'et_entity.entity_city', 'et_cities.id')
      ->leftJoin('et_company', 'et_company.sno', 'et_entity.company_id')
      ->where('et_entity.sno', $id)
      ->orderBy('et_entity.sno', 'desc')->first();


    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Entity not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Entity fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }

  public function Add(Request $request)
  {
      
     $chk = ManageEntityModel::where('entity_name', $request->entity_name)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Entity Name has been already created!'
        ]);
        return redirect()->back();
      }
    $category_check = ManageEntityModel::orderBy('sno', 'desc')->first();

    if (!$category_check) {

      $year = substr(date('y'), -2);
      $entity_id = 'ETE-0001/' . $year;
    } else {

      $data = $category_check->entity_id;
      $slice = explode('/', $data);
      $result = preg_replace('/[^0-9]/', '', $slice[0]);

      $next_number = (int) $result + 1;
      $request_id = sprintf('ETE-%04d', $next_number);

      $year = substr(date('y'), -2);
      $entity_id = $request_id . '/' . $year;
    }
    $user_id = $request->user()->user_id;
    $Add = new ManageEntityModel();

    $Add->entity_id = $entity_id;
    $Add->company_id = $request->company_id;
    $Add->entity_name = $request->entity_name;
    $Add->entity_mail = $request->entity_mail;
    $Add->entity_website = $request->website_url;
    $Add->entity_ct_person = $request->ct_person;
    $Add->entity_ct_number = $request->ct_per_mobile_no;
    $Add->entity_country = $request->country;
    $Add->entity_state = $request->state;
    $Add->entity_city = $request->city;
    $Add->entity_area = $request->area_street;
    $Add->entity_door_no = $request->door_flat_no;
    $Add->entity_pincode = $request->pincode;
    $Add->entity_gst = $request->gst_no;
    $Add->entity_cin = $request->cin_no;
    $Add->entity_pan = $request->pan_no;
    $Add->entity_desc = $request->entity_desc;
    $Add->entity_bank_name = $request->comapny_bank_name;
    $Add->entity_bank_branch = $request->comapny_bank_branch;
    $Add->entity_acc_holder = $request->comapny_acc_holder;
    $Add->entity_acc_no = $request->comapny_acc_no;
    $Add->entity_ifsc = $request->comapny_bank_ifsc;
    $Add->created_by = $user_id;
    $Add->updated_by = $user_id;

    $Add->save();

    if ($Add) {
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Entity added Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Entity!'
      ]);
    }

    return redirect()->back();
  }
  public function Update(Request $request)
  {
      $user_id = $request->user()->user_id;
    $id = $request->edit_id;
    
    $chk = ManageEntityModel::where('entity_name', $request->entity_name)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Entity Name has been already created!'
        ]);
        return redirect()->back();
      }
      
    
    $update = ManageEntityModel::where('sno', $id)->first();
    $update->company_id = $request->company_id;
    $update->entity_name = $request->entity_name;
    $update->entity_mail = $request->entity_mail;
    $update->entity_website = $request->website_url;
    $update->entity_ct_person = $request->ct_person;
    $update->entity_ct_number = $request->ct_per_mobile_no;
    $update->entity_country = $request->country;
    $update->entity_state = $request->state;
    $update->entity_city = $request->city;
    $update->entity_area = $request->area_street;
    $update->entity_door_no = $request->door_flat_no;
    $update->entity_pincode = $request->pincode;
    $update->entity_gst = $request->gst_no;
    $update->entity_cin = $request->cin_no;
    $update->entity_pan = $request->pan_no;
    $update->entity_desc = $request->entity_desc;
    $update->entity_bank_name = $request->comapny_bank_name;
    $update->entity_bank_branch = $request->comapny_bank_branch;
    $update->entity_acc_holder = $request->comapny_acc_holder;
    $update->entity_acc_no = $request->comapny_acc_no;
    $update->entity_ifsc = $request->comapny_bank_ifsc;
    $update->created_by = $user_id;
    $update->updated_by = $user_id;

    $update->update();

    if ($update) {
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Entity Updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Entity!'
      ]);
    }

    return redirect()->back();
  }

  public function checkDuplicates(Request $request)
  {
    $field = $request->field;
    $value = $request->value;
    $currentSno = $request->sno;

    $query = DB::table('et_entity')->where($field, $value);

    if (!empty($currentSno)) {
      $query->where('sno', '!=', $currentSno);
    }

    $exists = $query->exists();

    return response()->json([
      'exists' => $exists,
      'message' => $exists ? ucfirst(str_replace('_', ' ', $field)) . ' already exists.' : ''
    ]);
  }
}