<?php

namespace App\Http\Controllers\intern_management;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\GeneralSettingsModel;
use App\Models\LeadModel;
use App\Models\ManageInternModel;
use App\Models\TransactionModel;
use App\Models\SubLedgerModel;
use App\Models\ManageInternLeadModel;
use App\Models\StaffModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use PDF;

class ManageIntern extends Controller
{
    public function Index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        // Fetch year and month from the request
        $year = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        // Get the current date
        $currentDate = now()->toDateString();

        // Fetch total intern count, total payment, total paid, total balance
        $allInternCount = ManageInternModel::where('branch_id', $branch_id)
            ->where('status', 0)
            ->count();

        $totalPayment = ManageInternModel::where('branch_id', $branch_id)
            ->where('status', 0)
            ->sum('payment');  // Assuming 'payment' is the field in your model

        $totalPaid = ManageInternModel::where('branch_id', $branch_id)
            ->where('status', 0)
            ->sum('paid');  // Assuming 'paid' is the field in your model

        $totalBalance = ManageInternModel::where('branch_id', $branch_id)
            ->where('status', 0)
            ->sum('balance');  // Assuming 'balance' is the field in your model

        // Get the filter for customer name, email, or mobile
        $customer_fill = $request->cus_fill ?? '';

        // Joining with the 'colleges' and 'et_staff' tables
        $interns = ManageInternModel::join('et_intern_college', 'et_intern.college_id', '=', 'et_intern_college.sno')
            ->join('et_staff', 'et_intern.staff_id', '=', 'et_staff.sno')
            ->join('et_topic', 'et_intern.topic', '=', 'et_topic.sno')
            ->where('et_intern.branch_id', $branch_id)
            ->where('et_intern.status', 0)
            // ->whereYear('et_intern.start_date', $year)  // Filter by year
            // ->whereMonth('et_intern.start_date', $month) // Filter by month
            ->when(!empty($customer_fill), function ($query) use ($customer_fill) {
                return $query->where(function ($q) use ($customer_fill) {
                    $q->where('et_intern.intern_name', 'LIKE', "%{$customer_fill}%")
                        ->orWhere('et_intern.intern_email', 'LIKE', "%{$customer_fill}%")
                        ->orWhere('et_intern.intern_mobile', 'LIKE', "%{$customer_fill}%");
                });
            })
            ->select(
                'et_intern.intern_name',
                'et_intern.intern_email',
                'et_intern.intern_id',
                'et_intern.user_type',
                'et_intern.intern_mobile',
                'et_intern.certificate_issue_date',
                'et_intern.college_id',
                'et_intern.staff_id',
                'et_intern.sno',
                'et_intern.college_to',
                'et_intern.topic',
                'et_topic.title',
                'et_intern_college.college_name',
                'et_intern.generate_status',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.gender',
                'et_intern.start_date',
                'et_intern.end_date',
                'et_intern.payment',
                'et_intern.paid',
                'et_intern.balance'
            )
            ->orderBy('et_intern.sno', 'desc')
            ->paginate($perpage);


        // Grouped college-course counts filtered by created_at month/year
        $collegeCourseCounts = ManageInternModel::leftJoin('et_intern_college', 'et_intern.college_id', '=', 'et_intern_college.sno')
            ->leftJoin('et_topic', 'et_intern.topic', '=', 'et_topic.sno')
            ->where('et_intern.branch_id', $branch_id)
            ->where('et_intern.status', 0)
            ->whereYear('et_intern.created_at', $year)
            ->whereMonth('et_intern.created_at', $month)
            ->groupBy('et_intern_college.college_name')
            ->selectRaw('
                et_intern_college.college_name,
                COUNT(*) as intern_count,
                MIN(et_topic.title) as course_title
            ')
            ->orderByDesc('intern_count')
            ->get();

        // Total intern count filtered by created_at month/year
        $totalInternCount = ManageInternModel::where('branch_id', $branch_id)
            ->where('status', 0)
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->count();
            
         $branch_data = DB::table('et_branch')->where('sno', $request->user()->branch_id)->first();

        // Fetch any other necessary details (like payment, training, etc.)
        // return $interns;
        // Return the data to the view
        return view('content.intern_management.manage_intern.manage_intern', [
            'perpage' => $perpage,
            'interns' => $interns,
            'allInternCount' => $allInternCount,
            'totalInternCount' => $totalInternCount,
            'collegeCourseCounts' => $collegeCourseCounts,
            'branch_data' => $branch_data,
            'totalPayment' => $totalPayment,
            'totalPaid' => $totalPaid,
            'totalBalance' => $totalBalance,
            'year' => $year,
            'month' => $month,
            'customer_fill' => $customer_fill,
        ]);
    }
    
    public function Index_lead(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        // Get the filter for customer name, email, or mobile
        $customer_fill = $request->cus_fill ?? '';

        // Joining with the 'colleges' and 'et_staff' tables
        $interns = ManageInternLeadModel::where('branch_id', $branch_id)
            ->where('status', 0)
            // ->whereYear('start_date', $year)  // Filter by year
            // ->whereMonth('start_date', $month) // Filter by month
            ->when(!empty($customer_fill), function ($query) use ($customer_fill) {
                return $query->where(function ($q) use ($customer_fill) {
                    $q->where('intern_name', 'LIKE', "%{$customer_fill}%")
                        ->orWhere('intern_mobile', 'LIKE', "%{$customer_fill}%");
                });
            })
            ->orderBy('sno', 'desc')
            ->paginate($perpage);

        // Fetch any other necessary details (like payment, training, etc.)
        // return $interns;
        // Return the data to the view
        return view('content.intern_management.manage_intern.manage_intern_lead', [
            'perpage' => $perpage,
            'interns' => $interns,
            'customer_fill' => $customer_fill,
        ]);
    }
    
    public function lead_add_intern($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $id = $helper->encrypt_decrypt($id, 'decrypt');
        $exp = explode('~', $id);
        $id = str_replace(' ', '', $exp[0] ?? '');
        $branch_id = $request->user()->branch_id;

        // Check if decryption failed
        if ($id === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $interns = ManageInternLeadModel::where('sno', $id)
            ->first();

        //  return $interns;
        return view('content.intern_management.manage_intern.lead_add_intern', compact('interns'));
    }
    
    public function LeadIntern(Request $request)
    {
        // return 'sfsdfsdfsdfs';
        $validator = Validator::make($request->all(), [
            'lead_id' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }
        $lead_id = $request->lead_id;

        $helper = new \App\Helpers\Helpers();
        $encrypted_values = $helper->encrypt_decrypt($lead_id . '~' . '1', 'encrypt');
        return redirect()->route('lead_add_intern_lead', ['id' => $encrypted_values]);
    }
    
    
    public function Add_lead(Request $request)
    {
        $request->validate([
            'intern_name' => 'required|string|max:255',
            'intern_mobile' => 'required|digits:10',
        ]);
    
        // Check if an intern with the same mobile number already exists
        $existingIntern = ManageInternLeadModel::where('intern_mobile', $request->intern_mobile)->first();
    
        if ($existingIntern) {
            return response()->json([
                'status' => 'error',
                'message' => 'This mobile number is already in use.'
            ]);
        }
        $user_id   = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
    
        $intern = new ManageInternLeadModel();
        $intern->intern_name = $request->intern_name;
        $intern->intern_mobile = $request->intern_mobile;
        $intern->intern_email = $request->intern_email;
        $intern->branch_id = $branch_id;
        $intern->created_by = $user_id;
        $intern->updated_by = $user_id;
        $intern->save();
        return response()->json([
            'status' => 'success',
            'message' => 'Intern Lead Created successfully',
            'intern' => $intern,
        ]);
    }

    public function Add(Request $request)
    {
        return view('content.intern_management.manage_intern.add_intern')->with('filter_on', false);
    }
    public function viewCertificate($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        $branch_id = $request->user()->branch_id;
        $interns = ManageInternModel::where('et_intern.sno', $decryptedValue)
            ->join('et_intern_college', 'et_intern.college_id', '=', 'et_intern_college.sno')
            ->join('et_staff', 'et_intern.staff_id', '=', 'et_staff.sno')
            ->join('et_topic', 'et_intern.topic', '=', 'et_topic.sno')
            ->join('et_intern_company', 'et_intern.company_id', '=', 'et_intern_company.sno')
            ->join('et_intern_education', 'et_intern.degree_id', '=', 'et_intern_education.sno')
            ->join('et_branch', 'et_intern.branch_id', '=', 'et_branch.sno')
            ->join('et_states', 'et_branch.state_id', '=', 'et_states.id')
            ->join('et_cities', 'et_branch.city_id', '=', 'et_cities.id')
            ->where('et_intern.branch_id', $branch_id)
            ->where('et_intern.status', 0)
            ->select(
                'et_intern.intern_name',
                'et_intern.intern_email',
                'et_intern.intern_id',
                'et_intern.intern_mobile',
                'et_intern.college_id',
                'et_intern.staff_id',
                'et_intern.sno',
                'et_topic.title',
                'et_intern.topic',
                'et_intern.year',
                'et_intern.generate_status',
                'et_intern.certificate_issue_date',
                'et_intern_education.education',
                'et_intern_college.college_name',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.gender',
                'et_branch.area_street',
                'et_branch.door_no',
                'et_branch.pincode',
                'et_branch.mail',
                'et_branch.comm_email_id',
                'et_branch.mobile',
                'et_branch.gst_no',
                'et_branch.tax_no',
                'et_branch.cre_mobile',
                'et_intern_company.email',
                'et_intern_company.company',
                'et_intern_company.letter_header',
                'et_intern_company.letter_footer',
                'et_intern_company.letter_logo',
                'et_intern_company.logo_width',
                'et_intern_company.logo_height',
                'et_intern_company.signature',
                'et_intern_company.phone',
                'et_intern_company.letter_pad_desc',
                'et_cities.name as city_name',
                'et_states.name as state_name',
                'et_intern.start_date',
                'et_intern.end_date',
                'et_intern.payment',
                'et_intern.paid',
                'et_intern.balance'
            )
            ->first();

        // Format the dates
        if ($interns) {
            $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
            $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
            $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');

            $qrContent = "Name         : {$interns->intern_name}\n"
                . "Start Date   : {$interns->start_date_formatted}\n"
                . "End Date     : {$interns->end_date_formatted}\n"
                . "Company      : {$interns->company}\n"
                . "Issue Date   : {$issueDateFormatted}\n"
                . "Certificate  : Verified";



            // Create QR using PHP without installation
            $qrImage = imagecreate(200, 200);
            $white = imagecolorallocate($qrImage, 255, 255, 255);
            $black = imagecolorallocate($qrImage, 0, 0, 0);
            imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);

            // Just a placeholder pattern (real QR not generated like this)
            // Since you don't want to install any package and can't rely on Google API,
            // we're forced to ask: are you open to use a **small local script** or CDN?

            // RECOMMENDED: Use API from https://api.qrserver.com/

            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";

            // Convert to base64
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
        }

        // return $interns;
        $pdf = PDF::loadView('content.intern_management.manage_intern.certificate', [
            'interns' => $interns,
            'qrBase64' => $qrBase64
        ])
            ->setPaper('a4', 'portrait')
            ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
            ->setOption('isPhpEnabled', true)
            ->setOption('isRemoteEnabled', true)  // now you can safely set false
            ->setPaper('a4');
        // return $pdf;  
        return $pdf->download('certificate.pdf');
        // return view('content.intern_management.manage_intern.certificate', ['interns' => $interns, 'qrBase64' => $qrBase64,
        // 'qrCodeUrl' => $qrCodeUrl ]);
    }
    public function viewCertificate_confirm($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        $branch_id = $request->user()->branch_id;
        $interns = ManageInternModel::where('et_intern.sno', $decryptedValue)
            ->join('et_intern_college', 'et_intern.college_id', '=', 'et_intern_college.sno')
            ->join('et_staff', 'et_intern.staff_id', '=', 'et_staff.sno')
            ->join('et_topic', 'et_intern.topic', '=', 'et_topic.sno')
            ->join('et_intern_company', 'et_intern.company_id', '=', 'et_intern_company.sno')
            ->join('et_intern_education', 'et_intern.degree_id', '=', 'et_intern_education.sno')
            ->join('et_branch', 'et_intern.branch_id', '=', 'et_branch.sno')
            ->join('et_states', 'et_branch.state_id', '=', 'et_states.id')
            ->join('et_cities', 'et_branch.city_id', '=', 'et_cities.id')
            ->where('et_intern.branch_id', $branch_id)
            ->where('et_intern.status', 0)
            ->select(
                'et_intern.intern_name',
                'et_intern.intern_email',
                'et_intern.intern_id',
                'et_intern.intern_mobile',
                'et_intern.college_id',
                'et_intern.staff_id',
                'et_intern.sno',
                'et_topic.title',
                'et_intern.topic',
                'et_intern.year',
                'et_intern.college_to',
                'et_intern.generate_status',
                'et_intern.certificate_issue_date',
                'et_intern_education.education',
                'et_intern_college.college_name',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.gender',
                'et_branch.area_street',
                'et_branch.door_no',
                'et_branch.pincode',
                'et_branch.mail',
                'et_branch.comm_email_id',
                'et_branch.mobile',
                'et_branch.gst_no',
                'et_branch.tax_no',
                'et_branch.cre_mobile',
                'et_intern_company.email',
                'et_intern_company.company',
                'et_intern_company.letter_header',
                'et_intern_company.letter_footer',
                'et_intern_company.letter_logo',
                'et_intern_company.logo_width',
                'et_intern_company.logo_height',
                'et_intern_company.signature',
                'et_intern_company.phone',
                'et_intern_company.letter_pad_desc',
                'et_cities.name as city_name',
                'et_states.name as state_name',
                'et_intern.start_date',
                'et_intern.end_date',
                'et_intern.payment',
                'et_intern.paid',
                'et_intern.balance'
            )
            ->first();

        // Format the dates
        if ($interns) {
            $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
            $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
            $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');
            $Confirmation_date = Carbon::parse($interns->confirmation_date)->format('jS F Y');

            $qrContent = "Name         : {$interns->intern_name}\n"
                . "Confirmation Date   : {$Confirmation_date}\n"
                . "Start Date   : {$interns->start_date_formatted}\n"
                . "End Date     : {$interns->end_date_formatted}\n"
                . "Company      : {$interns->company}\n"
                . "Issue Date   : {$issueDateFormatted}\n"
                . "Certificate  : Verified";



            // Create QR using PHP without installation
            $qrImage = imagecreate(200, 200);
            $white = imagecolorallocate($qrImage, 255, 255, 255);
            $black = imagecolorallocate($qrImage, 0, 0, 0);
            imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);

            // Just a placeholder pattern (real QR not generated like this)
            // Since you don't want to install any package and can't rely on Google API,
            // we're forced to ask: are you open to use a **small local script** or CDN?

            // RECOMMENDED: Use API from https://api.qrserver.com/

            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";

            // Convert to base64
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
        }

        // return $interns;
        $pdf = PDF::loadView('content.intern_management.manage_intern.certificate_confirm', [
            'interns' => $interns,
            'qrBase64' => $qrBase64
        ])
            ->setPaper('a4', 'portrait')
            ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
            ->setOption('isPhpEnabled', true)
            ->setOption('isRemoteEnabled', true)  // now you can safely set false
            ->setPaper('a4');
        // return $pdf;  
        return $pdf->download('Confirmation_certificate.pdf');
        // return view('content.intern_management.manage_intern.certificate', ['interns' => $interns, 'qrBase64' => $qrBase64,
        // 'qrCodeUrl' => $qrCodeUrl ]);
    }
    public function viewCertificateEmployee($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        $branch_id = $request->user()->branch_id;

        $interns = ManageInternModel::where('et_intern.sno', $decryptedValue)
            ->join('et_intern_college', 'et_intern.college_id', '=', 'et_intern_college.sno')
            ->join('et_staff', 'et_intern.staff_id', '=', 'et_staff.sno')
            ->join('et_topic', 'et_intern.topic', '=', 'et_topic.sno')
            ->join('et_intern_company', 'et_intern.company_id', '=', 'et_intern_company.sno')
            // ->join('et_intern_education', 'et_intern.degree_id', '=', 'et_intern_education.sno')
            ->join('et_branch', 'et_intern.branch_id', '=', 'et_branch.sno')
            ->join('et_states', 'et_branch.state_id', '=', 'et_states.id')
            ->join('et_cities', 'et_branch.city_id', '=', 'et_cities.id')
            ->where('et_intern.branch_id', $branch_id)
            ->where('et_intern.status', 0)
            ->select(
                'et_intern.intern_name',
                'et_intern.intern_email',
                'et_intern.intern_id',
                'et_intern.intern_mobile',
                'et_intern.college_id',
                'et_intern.staff_id',
                'et_intern.sno',
                'et_topic.title',
                'et_intern.topic',
                'et_intern.year',
                'et_intern.certificate_issue_date',
                // 'et_intern_education.education',
                'et_intern_college.college_name',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.gender',
                'et_branch.area_street',
                'et_branch.door_no',
                'et_branch.pincode',
                'et_branch.mail',
                'et_branch.comm_email_id',
                'et_branch.mobile',
                'et_branch.gst_no',
                'et_branch.tax_no',
                'et_branch.cre_mobile',
                'et_intern_company.email',
                'et_intern_company.company',
                'et_intern_company.letter_header',
                'et_intern_company.letter_footer',
                'et_intern_company.letter_logo',
                'et_intern_company.logo_width',
                'et_intern_company.logo_height',
                'et_intern_company.signature',
                'et_intern_company.phone',
                'et_intern_company.letter_pad_desc',
                'et_cities.name as city_name',
                'et_states.name as state_name',
                'et_intern.start_date',
                'et_intern.end_date',
                'et_intern.payment',
                'et_intern.paid',
                'et_intern.balance'
            )
            ->first();
        // return $interns;
        // Format the dates
        if ($interns) {
            $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
            $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
            $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');

            $qrContent = "Name         : {$interns->intern_name}\n"
                . "Start Date   : {$interns->start_date_formatted}\n"
                . "End Date     : {$interns->end_date_formatted}\n"
                . "Company      : {$interns->company}\n"
                . "Issue Date   : {$issueDateFormatted}\n"
                . "Certificate  : Verified";



            // Create QR using PHP without installation
            $qrImage = imagecreate(200, 200);
            $white = imagecolorallocate($qrImage, 255, 255, 255);
            $black = imagecolorallocate($qrImage, 0, 0, 0);
            imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);

            // Just a placeholder pattern (real QR not generated like this)
            // Since you don't want to install any package and can't rely on Google API,
            // we're forced to ask: are you open to use a **small local script** or CDN?

            // RECOMMENDED: Use API from https://api.qrserver.com/

            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";

            // Convert to base64
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
        }
        // return $interns;
        $pdf = PDF::loadView('content.intern_management.manage_intern.Employee-Certificate', [
            'interns' => $interns,
            'qrBase64' => $qrBase64
        ])
            ->setPaper('a4', 'portrait')
            ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
            ->setOption('isPhpEnabled', true)
            ->setOption('isRemoteEnabled', true)  // now you can safely set false
            ->setPaper('a4');
        // return $pdf;  
        return $pdf->download('Employee-Certificate.pdf');

        // return view('content.intern_management.manage_intern.Employee-Certificate', ['interns' => $interns]);
    }
    public function previewCertificate($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        $branch_id = $request->user()->branch_id;
        // return $id;
        $interns = ManageInternModel::where('et_intern.sno', $id)
            ->join('et_intern_college', 'et_intern.college_id', '=', 'et_intern_college.sno')
            ->join('et_staff', 'et_intern.staff_id', '=', 'et_staff.sno')
            ->join('et_topic', 'et_intern.topic', '=', 'et_topic.sno')
            ->join('et_intern_company', 'et_intern.company_id', '=', 'et_intern_company.sno')
            ->join('et_intern_education', 'et_intern.degree_id', '=', 'et_intern_education.sno')
            ->join('et_branch', 'et_intern.branch_id', '=', 'et_branch.sno')
            ->join('et_states', 'et_branch.state_id', '=', 'et_states.id')
            ->join('et_cities', 'et_branch.city_id', '=', 'et_cities.id')
            ->where('et_intern.status', 0)
            ->select(
                'et_intern.intern_name',
                'et_intern.intern_email',
                'et_intern.intern_id',
                'et_intern.intern_mobile',
                'et_intern.college_id',
                'et_intern.staff_id',
                'et_intern.sno',
                'et_topic.title',
                'et_intern.topic',
                'et_intern.year',
                'et_intern.certificate_issue_date',
                'et_intern_education.education',
                'et_intern_college.college_name',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.gender',
                'et_branch.area_street',
                'et_branch.door_no',
                'et_branch.pincode',
                'et_branch.mail',
                'et_branch.comm_email_id',
                'et_branch.mobile',
                'et_branch.gst_no',
                'et_branch.tax_no',
                'et_branch.cre_mobile',
                'et_intern_company.email',
                'et_intern_company.company',
                'et_intern_company.letter_header',
                'et_intern_company.letter_footer',
                'et_intern_company.letter_logo',
                'et_intern_company.logo_width',
                'et_intern_company.logo_height',
                'et_intern_company.signature',
                'et_intern_company.phone',
                'et_intern_company.letter_pad_desc',
                'et_intern_company.short_code',
                'et_cities.name as city_name',
                'et_states.name as state_name',
                'et_intern.start_date',
                'et_intern.end_date',
                'et_intern.payment',
                'et_intern.paid',
                'et_intern.balance'
            )
            ->first();
        // return $interns;
        $qrBase64 = null;
        // Format the dates
        if ($interns) {
            $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
            $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
            $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');

            $qrContent = "Name         : {$interns->intern_name}\n"
                . "Start Date   : {$interns->start_date_formatted}\n"
                . "End Date     : {$interns->end_date_formatted}\n"
                . "Company      : {$interns->company}\n"
                . "Issue Date   : {$issueDateFormatted}\n"
                . "Certificate  : Verified";



            // Create QR using PHP without installation
            $qrImage = imagecreate(200, 200);
            $white = imagecolorallocate($qrImage, 255, 255, 255);
            $black = imagecolorallocate($qrImage, 0, 0, 0);
            imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);

            // Just a placeholder pattern (real QR not generated like this)
            // Since you don't want to install any package and can't rely on Google API,
            // we're forced to ask: are you open to use a **small local script** or CDN?

            // RECOMMENDED: Use API from https://api.qrserver.com/

            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";

            // Convert to base64
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
        }


        //   $pdf = PDF::loadView('content.intern_management.manage_intern.certificate', [
        //             'interns' => $interns,
        //               'qrBase64' => $qrBase64
        //         ])
        //         ->setPaper('a4', 'portrait')
        //         ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
        //         ->setOption('isPhpEnabled', true)  
        //         ->setOption('isRemoteEnabled', true)  // now you can safely set false
        //         ->setPaper('a4');
        // return $pdf;  
        //  return $pdf->download('certificate.pdf');  
        return view('content.intern_management.manage_intern.preview_certificate', ['interns' => $interns, 'qrBase64' => $qrBase64]);
    }
     public function previewCertificate_confirm($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        $branch_id = $request->user()->branch_id;
        // return $id;
        $interns = ManageInternModel::where('et_intern.sno', $id)
            ->join('et_intern_college', 'et_intern.college_id', '=', 'et_intern_college.sno')
            ->join('et_staff', 'et_intern.staff_id', '=', 'et_staff.sno')
            ->join('et_topic', 'et_intern.topic', '=', 'et_topic.sno')
            ->join('et_intern_company', 'et_intern.company_id', '=', 'et_intern_company.sno')
            ->join('et_intern_education', 'et_intern.degree_id', '=', 'et_intern_education.sno')
            ->join('et_branch', 'et_intern.branch_id', '=', 'et_branch.sno')
            ->join('et_states', 'et_branch.state_id', '=', 'et_states.id')
            ->join('et_cities', 'et_branch.city_id', '=', 'et_cities.id')
            ->where('et_intern.status', 0)
            ->select(
                'et_intern.intern_name',
                'et_intern.intern_email',
                'et_intern.intern_id',
                'et_intern.intern_mobile',
                'et_intern.college_id',
                'et_intern.staff_id',
                'et_intern.sno',
                'et_topic.title',
                'et_intern.topic',
                'et_intern.college_to',
                'et_intern.year',
                'et_intern.certificate_issue_date',
                'et_intern_education.education',
                'et_intern_college.college_name',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.gender',
                'et_branch.area_street',
                'et_branch.door_no',
                'et_branch.pincode',
                'et_branch.mail',
                'et_branch.comm_email_id',
                'et_branch.mobile',
                'et_branch.gst_no',
                'et_branch.tax_no',
                'et_branch.cre_mobile',
                'et_intern_company.email',
                'et_intern_company.company',
                'et_intern_company.letter_header',
                'et_intern_company.letter_footer',
                'et_intern_company.letter_logo',
                'et_intern_company.logo_width',
                'et_intern_company.logo_height',
                'et_intern_company.signature',
                'et_intern_company.phone',
                'et_intern_company.letter_pad_desc',
                'et_intern_company.short_code',
                'et_cities.name as city_name',
                'et_states.name as state_name',
                'et_intern.start_date',
                'et_intern.end_date',
                'et_intern.payment',
                'et_intern.paid',
                'et_intern.balance'
            )
            ->first();
        // return $interns;
        $qrBase64 = null;
        // Format the dates
        if ($interns) {
            $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
            $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
            $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');

            $qrContent = "Name         : {$interns->intern_name}\n"
                . "Start Date   : {$interns->start_date_formatted}\n"
                . "End Date     : {$interns->end_date_formatted}\n"
                . "Company      : {$interns->company}\n"
                . "Issue Date   : {$issueDateFormatted}\n"
                . "Certificate  : Verified";



            // Create QR using PHP without installation
            $qrImage = imagecreate(200, 200);
            $white = imagecolorallocate($qrImage, 255, 255, 255);
            $black = imagecolorallocate($qrImage, 0, 0, 0);
            imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);

            // Just a placeholder pattern (real QR not generated like this)
            // Since you don't want to install any package and can't rely on Google API,
            // we're forced to ask: are you open to use a **small local script** or CDN?

            // RECOMMENDED: Use API from https://api.qrserver.com/

            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";

            // Convert to base64
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
        }


        //   $pdf = PDF::loadView('content.intern_management.manage_intern.certificate', [
        //             'interns' => $interns,
        //               'qrBase64' => $qrBase64
        //         ])
        //         ->setPaper('a4', 'portrait')
        //         ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
        //         ->setOption('isPhpEnabled', true)  
        //         ->setOption('isRemoteEnabled', true)  // now you can safely set false
        //         ->setPaper('a4');
        // return $pdf;  
        //  return $pdf->download('certificate.pdf');  
        return view('content.intern_management.manage_intern.preview_certificate_confirm', ['interns' => $interns, 'qrBase64' => $qrBase64]);
    }
    public function previewCertificateEmployee($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        $branch_id = $request->user()->branch_id;

        $interns = ManageInternModel::where('et_intern.sno', $id)
            ->join('et_intern_college', 'et_intern.college_id', '=', 'et_intern_college.sno')
            ->join('et_staff', 'et_intern.staff_id', '=', 'et_staff.sno')
            ->join('et_topic', 'et_intern.topic', '=', 'et_topic.sno')
            ->join('et_intern_company', 'et_intern.company_id', '=', 'et_intern_company.sno')
            // ->join('et_intern_education', 'et_intern.degree_id', '=', 'et_intern_education.sno')
            ->join('et_branch', 'et_intern.branch_id', '=', 'et_branch.sno')
            ->join('et_states', 'et_branch.state_id', '=', 'et_states.id')
            ->join('et_cities', 'et_branch.city_id', '=', 'et_cities.id')
            ->where('et_intern.status', 0)
            ->select(
                'et_intern.intern_name',
                'et_intern.intern_email',
                'et_intern.intern_id',
                'et_intern.intern_mobile',
                'et_intern.college_id',
                'et_intern.staff_id',
                'et_intern.sno',
                'et_topic.title',
                'et_intern.topic',
                'et_intern.year',
                'et_intern.certificate_issue_date',
                // 'et_intern_education.education',
                'et_intern_college.college_name',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.gender',
                'et_branch.area_street',
                'et_branch.door_no',
                'et_branch.pincode',
                'et_branch.mail',
                'et_branch.comm_email_id',
                'et_branch.mobile',
                'et_branch.gst_no',
                'et_branch.tax_no',
                'et_branch.cre_mobile',
                'et_intern_company.email',
                'et_intern_company.company',
                'et_intern_company.letter_header',
                'et_intern_company.letter_footer',
                'et_intern_company.letter_logo',
                'et_intern_company.logo_width',
                'et_intern_company.logo_height',
                'et_intern_company.signature',
                'et_intern_company.phone',
                'et_intern_company.letter_pad_desc',
                'et_cities.name as city_name',
                'et_states.name as state_name',
                'et_intern.start_date',
                'et_intern.end_date',
                'et_intern.payment',
                'et_intern.paid',
                'et_intern.balance'
            )
            ->first();
        //   return $interns;
        // Format the dates
        if ($interns) {
            $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
            $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
            $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');

            $qrContent = "Name         : {$interns->intern_name}\n"
                . "Start Date   : {$interns->start_date_formatted}\n"
                . "End Date     : {$interns->end_date_formatted}\n"
                . "Company      : {$interns->company}\n"
                . "Issue Date   : {$issueDateFormatted}\n"
                . "Certificate  : Verified";



            // Create QR using PHP without installation
            $qrImage = imagecreate(200, 200);
            $white = imagecolorallocate($qrImage, 255, 255, 255);
            $black = imagecolorallocate($qrImage, 0, 0, 0);
            imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);

            // Just a placeholder pattern (real QR not generated like this)
            // Since you don't want to install any package and can't rely on Google API,
            // we're forced to ask: are you open to use a **small local script** or CDN?

            // RECOMMENDED: Use API from https://api.qrserver.com/

            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";

            // Convert to base64
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
        }
        //   return $qrBase64;
        //   $pdf = PDF::loadView('content.intern_management.manage_intern.Employee-Certificate', [
        //             'interns' => $interns,
        //               'qrBase64' => $qrBase64
        //         ])
        //         ->setPaper('a4', 'portrait')
        //         ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
        //         ->setOption('isPhpEnabled', true)  
        //         ->setOption('isRemoteEnabled', true)  // now you can safely set false
        //         ->setPaper('a4');
        // return $pdf;  
        //  return $pdf->download('Employee-Certificate.pdf');
        // return $interns;

        return view('content.intern_management.manage_intern.preview_Employee_Certificate', ['interns' => $interns, 'qrBase64' => $qrBase64]);
    }
    public function updateStatus(Request $request)
    {
        $intern_id = $request->intern_id;

        $student = ManageInternModel::find($intern_id);
        if (!$student) {
            return response()->json(['status' => 404, 'message' => 'Student not found']);
        }

        // Assuming there's a 'certificate_status' field
        $student->generate_status = 1; // or whatever value indicates "generated"
        $student->save();

        return response()->json(['status' => 200, 'message' => 'Status updated']);
    }
    public function StaffListIntern(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $staff = StaffModel::where('status', 0)
        // ->where('department_id', 2)
        ->where('sno','>', 1)
        ->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();
        // return $College;
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $staff
        ], 200);
    }
    public function intern_summary(Request $request)
    {
        $branch_id = $request->user()->branch_id;

        $year = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        // College-wise intern count
        $collegeCounts = ManageInternModel::leftJoin('et_intern_college', 'et_intern.college_id', '=', 'et_intern_college.sno')
            ->where('et_intern.branch_id', $branch_id)
            ->where('et_intern.status', 0)
            ->whereYear('et_intern.created_at', $year)
            ->whereMonth('et_intern.created_at', $month)
            ->groupBy('et_intern_college.college_name')
            ->selectRaw('et_intern_college.college_name, COUNT(*) as intern_count')
            ->orderByDesc('intern_count')
            ->get();

        // Course-wise intern count
        $courseCounts = ManageInternModel::leftJoin('et_topic', 'et_intern.topic', '=', 'et_topic.sno')
            ->where('et_intern.branch_id', $branch_id)
            ->where('et_intern.status', 0)
            ->whereYear('et_intern.created_at', $year)
            ->whereMonth('et_intern.created_at', $month)
            ->groupBy('et_topic.title')
            ->selectRaw('et_topic.title as course_title, COUNT(*) as course_count')
            ->orderByDesc('course_count')
            ->get();

        // Total intern count
        $totalInternCount = ManageInternModel::where('branch_id', $branch_id)
            ->where('status', 0)
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->count();

        return response()->json([
            'year' => $year,
            'month' => $month,
            'collegeCounts' => $collegeCounts,   // Clean college-wise data
            'courseCounts' => $courseCounts,     // Clean course-wise data
            'totalInternCount' => $totalInternCount
        ]);
    }
    public function CreateIntern(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        // Step 1: Validate common fields
        $request->validate([
            'colleage_id'      => 'required|integer',
            'topic_id'         => 'required',
            'payment'          => 'required|numeric',
            'start_date'       => 'required|date',
            'end_date'         => 'required|date',
            'staff_id'         => 'required|integer',
            'intern_name'      => 'required|string',
            'intern_email_id'  => 'required|email',
            'intern_mobile_no' => 'required|digits:10',
            'college_to'       => 'required',
        ]);
        // return $request;
        $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code;
        $year = date("Y");

        // Get last intern_id for the same branch and format
        $intern_check = ManageInternModel::whereNotNull('intern_id')
            ->where('intern_id', 'LIKE', $year . '/' . $branch_code . '/IND%')
            ->orderByRaw("CAST(SUBSTRING_INDEX(intern_id, 'IND', -1) AS UNSIGNED) DESC")
            ->first();

        if (!$intern_check || !isset($intern_check->intern_id)) {
            $intern_id = $year . '/' . $branch_code . '/' . "IND2005";
        } else {
            $last_intern_id = $intern_check->intern_id; // e.g. 2025/MDU01/IND2042
            $parts = explode("/", $last_intern_id);

            if (isset($parts[2]) && preg_match('/IND(\d+)/', $parts[2], $matches)) {
                $next_number = (int)$matches[1] + 1;
            } else {
                $next_number = 2005;
            }

            $new_code = sprintf("IND%04d", $next_number);
            $intern_id = $year . '/' . $branch_code . '/' . $new_code;
        }

        $common = [
            'branch_id' => $branch_id,
            'college_id' => $request->colleage_id,
            'topic'       => $request->topic_id,
            'payment'     => $request->payment,
            'payment_gst' => round(($request->payment * 18) / 100, 2),
            'paid'        => 0,
            'balance'     => $request->payment,
            'start_date'   => \Carbon\Carbon::createFromFormat('d-M-Y', $request->start_date)->format('Y-m-d'),
            'end_date'    => \Carbon\Carbon::createFromFormat('d-M-Y', $request->end_date)->format('Y-m-d'),
            'staff_id'    => $request->staff_id,
            'college_to'   => $request->college_to,
            'created_by'  => $request->user()->id ?? null,
            'updated_by'  => $request->user()->id ?? null,
            'status'      => 0,
        ];
        
        // return $common;

        // Save the main intern
        $internId = $intern_id;
        ManageInternModel::create(array_merge($common, [
            'intern_id'    => $internId,
            'intern_name'  => $request->intern_name,
            'intern_email' => $request->intern_email_id,
            'intern_mobile' => $request->intern_mobile_no,
        ]));

        // Save dynamic interns
        if ($request->has('interns')) {
            foreach ($request->interns as $intern) {
                $internId = $intern_id;
                ManageInternModel::create(array_merge($common, [
                    'intern_id'    => $internId,
                    'intern_name'  => $intern['name'],
                    'intern_email' => $intern['email'],
                    'intern_mobile' => $intern['mobile'],
                ]));
            }
        }

        return redirect('manage_intern')->with('success', 'Interns added successfully!');
    }

    public function update(Request $request)
    {
        $request->validate([
            'sno' => 'required|',
            'college_id' => 'required|integer',
            'topic_name' => 'required',
            'payment' => 'required|numeric',
            'start_date' => 'required',
            'end_date' => 'required',
            'staff_id' => 'required|integer',
            'intern_name' => 'required|string|max:255',
            'intern_email' => 'required|email',
            'intern_mobile' => 'required|digits:10',
        ]);

        $intern = ManageInternModel::find($request->sno);

        if (!$intern || $intern->status != 0) {
            return response()->json(['status' => 'error', 'message' => 'Intern not found or already inactive.']);
        }

        $intern->college_id = $request->college_id;
        $intern->topic = $request->topic_name;
        $intern->payment = $request->payment;
        $intern->start_date = $request->start_date;
        $intern->end_date = $request->end_date;
        $intern->staff_id = $request->staff_id;
        $intern->intern_name = $request->intern_name;
        $intern->intern_email = $request->intern_email;
        $intern->intern_mobile = $request->intern_mobile;
        $intern->college_to = $request->college_to;

        $intern->save();

        return response()->json(['status' => 'success', 'message' => 'Intern updated successfully']);
    }
    
    




    public function View(Request $request)
    {
        $intern = ManageInternModel::join('et_intern_college', 'et_intern.college_id', '=', 'et_intern_college.sno')
            ->join('et_staff', 'et_intern.staff_id', '=', 'et_staff.sno')
            ->join('et_topic', 'et_intern.topic', '=', 'et_topic.sno')
            ->select(
                'et_intern.intern_name',
                'et_intern.intern_email',
                'et_intern.intern_id',
                'et_intern.intern_mobile',
                'et_intern.college_id',
                'et_intern.staff_id',
                'et_intern.sno',
                'et_intern.topic as topic_id',
                'et_topic.title as topic',
                'et_intern_college.college_name',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.gender',
                'et_intern.start_date',
                'et_intern.end_date',
                'et_intern.payment',
                'et_intern.paid',
                'et_intern.balance'
            )
            ->where('et_intern.sno', $request->sno)
            ->first();
        $intern->start_date = Carbon::parse($intern->start_date)->format('d-M-Y');
        $intern->end_date = Carbon::parse($intern->end_date)->format('d-M-Y');
        if (!$intern) {
            return response()->json(['status' => 'error', 'message' => 'Intern not found'], 404);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Intern fetched successfully',
            'data' => $intern
        ]);
    }

    public function Payment(Request $request, $id)
    {
        $request->validate([
            'pay_amount' => 'required|numeric|min:1',
            'transaction_all' => 'required|array',
            'payment_mode' => 'required|string',
            // 'reciptid' => 'required|string',
        ]);

        DB::beginTransaction();

        try {
            $intern = ManageInternModel::findOrFail($id);
            $user_id = auth()->user()->id ?? 0;
            $branch_id = auth()->user()->branch_id;
            
            // STEP 1: Fetch all transaction_all fields from this branch
            $allInterns = ManageInternModel::where('branch_id', $branch_id)
                ->whereNotNull('transaction_all')
                ->get(['transaction_all']);

            // STEP 2: Loop through all invoices and find the max number
            $lastInvoiceNumber = 2004;
            foreach ($allInterns as $internEntry) {
                $transactions = json_decode($internEntry->transaction_all, true);
                if (is_array($transactions)) {
                    foreach ($transactions as $txn) {
                        if (!empty($txn['invoice_id']) && preg_match('/INV(\d+)/', $txn['invoice_id'], $matches)) {
                            $num = (int)$matches[1];
                            if ($num > $lastInvoiceNumber) {
                                $lastInvoiceNumber = $num;
                            }
                        }
                    }
                }
            }

            // STEP 3: Create next invoice number
            $prefix = "ET";
            $year = date("Y");
            $nextInvoiceNumber = $lastInvoiceNumber + 1;
            $newInvoiceId = $prefix . '/' . $year . '/' . sprintf("INV%04d", $nextInvoiceNumber);

            // STEP 4: Append new transaction to THIS intern
            $oldTransactions = [];
            if (!empty($intern->transaction_all)) {
                $decoded = json_decode($intern->transaction_all, true);
                if (is_array($decoded)) {
                    $oldTransactions = $decoded;
                }
            }

            $newTransaction = $request->transaction_all;
            $newTransaction['payment_mode'] = $request->payment_mode;
            $newTransaction['receipt_id'] = $request->reciptid??"";
            $newTransaction['invoice_id'] = $newInvoiceId;
            $newTransaction['timestamp'] = now();

            $oldTransactions[] = $newTransaction;

            // STEP 5: Update payment totals
            $newPaidAmount = floatval($intern->paid) + floatval($request->pay_amount);
            $newBalance    = floatval($intern->payment) - $newPaidAmount;

            $intern->paid = $newPaidAmount;
            $intern->balance = $newBalance;
            $intern->transaction_all = json_encode($oldTransactions);
            $intern->updated_by = $user_id;
            $intern->save();
            
            // return $intern;


            // Prepare subledger
            $branch = BranchModel::where('sno', $branch_id)->firstOrFail();
            $branch_code = $branch->city_short_code;

            $latestSubledger = SubLedgerModel::where('branch_id', $branch_id)->orderByDesc('sno')->first();
            if (!$latestSubledger) {
                $subledger_id = date("Y") . '/' . $branch_code . '/SUB2005';
            } else {
                $last = explode('/', $latestSubledger->subledger_id);
                $num = (int) preg_replace('/[^0-9]/', '', $last[2]) + 1;
                $subledger_id = date("Y") . '/' . $branch_code . '/' . sprintf("SUB%04d", $num);
            }
            //  return $branch_id;
           $subledger = SubLedgerModel::create([
                'ledger_id' => 1,
                'subledger_id' => $subledger_id,
                'subledger_name' => ucfirst($intern->intern_name) . ' - ' . $intern->intern_id,
                'subledger_desc' => 'Intern Students fees',
                'branch_id' => $branch_id,
                'payment_sno' => 0,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);

            
           

            // Prepare transaction ID
            $latestTr = TransactionModel::orderByDesc('sno')->first();
            if (!$latestTr) {
                $transaction_id = date("Y") . '/' . $branch_code . '/TRA2005';
            } else {
                $last = explode('/', $latestTr->transaction_id);
                $num = (int) preg_replace('/[^0-9]/', '', $last[2]) + 1;
                $transaction_id = date("Y") . '/' . $branch_code . '/' . sprintf("TRA%04d", $num);
            }
            //  return $latestTr;

            $paidAmount = $request->pay_amount;
            $tax = $paidAmount * ($branch->gst_percentage / 100);
            $total = $paidAmount + $tax;

            // Create transaction record
            TransactionModel::create([
                'branch_id' => $branch_id,
                'transaction_id' => $transaction_id,
                'transaction_type' => 'Credit',
                'transaction_name' => 'Customer',
                'trans_source_id' => $intern->intern_id,
                'ledger_id' => 1,
                'subledger_id' => $subledger->sno,
                'customer_type' => 2,
                'credit' => $paidAmount,
                'invoice_id' => null,
                'receipt_id' => $request->reciptid,
                'training_id' => 0,
                'debit' => null,
                'tax' => $tax,
                'total_amount' => $total,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
            
            
            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'Payment updated successfully',
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'status' => 'error',
                'message' => 'Payment update failed.',
                'error' => $e->getMessage(), // Actual error message
            ], 500);
        }
    }
    public function ViewInvoice(Request $request)
    {
        $intern = ManageInternModel::join('et_intern_college', 'et_intern.college_id', '=', 'et_intern_college.sno')
            ->join('et_staff', 'et_intern.staff_id', '=', 'et_staff.sno')
            ->join('et_topic', 'et_intern.topic', '=', 'et_topic.sno')
            ->select(
                'et_intern.intern_name',
                'et_intern.intern_email',
                'et_intern.intern_id',
                'et_intern.intern_mobile',
                'et_intern.college_id',
                'et_intern.staff_id',
                'et_intern.sno',
                'et_intern.topic as topic_id',
                'et_intern.transaction_all',
                'et_topic.title as topic',
                'et_intern_college.college_name',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.gender',
                'et_intern.start_date',
                'et_intern.end_date',
                'et_intern.payment',
                'et_intern.paid',
                'et_intern.balance'
            )
            ->where('et_intern.sno', $request->sno)
            ->first();

        if (!$intern) {
            return response()->json(['status' => 'error', 'message' => 'Intern not found'], 404);
        }

        // Helper and settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'd-M-Y';

        // Format dates
        $intern->start_date = \Carbon\Carbon::parse($intern->start_date)->format($dateFormat);
        $intern->end_date = \Carbon\Carbon::parse($intern->end_date)->format($dateFormat);

        // Decode and enhance transaction list
        $transactions = json_decode($intern->transaction_all, true) ?? [];

        foreach ($transactions as $i => &$payment) {
            $payment['encryptedValue'] = $helper->encrypt_decrypt($payment['invoice_id'] ?? '', 'encrypt');
            $payment['printValue'] = $helper->encrypt_decrypt($i + 1, 'encrypt');
        }

        // Attach modified transactions back
        $intern->transactions = $transactions;

        return response()->json([
            'status' => 'success',
            'message' => 'Intern fetched successfully',
            'data' => $intern
        ]);
    }

    //intern_invoice

    public function intern_invoice($id = '', $print_id = '', $sno = '', Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        // return  $sno;
        // Decrypt values
        $decryptedInvoiceId = $helper->encrypt_decrypt($id, 'decrypt');
        $transactionIndex = (int) $helper->encrypt_decrypt($print_id, 'decrypt');

        // Fetch intern and related info
        $payment = ManageInternModel::select(
            'et_intern.paid as amount',
            'et_intern.transaction_all',
            'et_intern.intern_name',
            'et_intern.intern_id',
            'et_intern.intern_mobile',
            'et_topic.title',
            'et_branch.door_no',
            'et_branch.pincode',
            'et_branch.mobile',
            'et_branch.branch_name',
            'et_branch.branch_type',
            'et_branch.franchise_name',
            'et_branch.mail',
            'et_branch.area_street',
            'et_states.name as state_name',
            'et_cities.name as city_name'
        )
            ->leftJoin('et_topic', 'et_topic.sno', '=', 'et_intern.topic')
            ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_intern.branch_id')
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->where('et_intern.sno', $sno)
            ->first();

        if (!$payment) {
            return response()->view('errors.404', [], 404);
        }

        // Initialize selected transaction
        $selectedTransaction = null;

        // Decode transactions
        $transactions = [];
        if (!empty($payment->transaction_all)) {
            $decoded = json_decode($payment->transaction_all, true);
            if (is_array($decoded)) {
                $transactions = $decoded;

                // First try using the index
                if (isset($transactions[$transactionIndex])) {
                    $txn = $transactions[$transactionIndex];

                    // Match invoice_id to confirm
                    if (!empty($txn['invoice_id']) && $txn['invoice_id'] === $decryptedInvoiceId) {
                        $selectedTransaction = $txn;
                    }
                }

                // Fallback: try finding by invoice_id
                if (!$selectedTransaction) {
                    foreach ($transactions as $txn) {
                        if (!empty($txn['invoice_id']) && $txn['invoice_id'] === $decryptedInvoiceId) {
                            $selectedTransaction = $txn;
                            break;
                        }
                    }
                }
            }
        }

        // Final check
        if (!$selectedTransaction) {
            return response()->view('errors.404', [], 404);
        }


        // Terms & conditions
        $terms_conditions = GeneralSettingsModel::select('terms_1', 'terms_2', 'terms_3', 'terms_4', 'terms_5')
            ->where('status', 0)
            ->get();

        // GST % from branch
        $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();

        // QR Code data
        $qrCodeData = [
            'Customer Name' => $payment->intern_name,
            'Customer ID' => $payment->intern_id,
            'Paid Amount' => $selectedTransaction['payment_amount']
        ];
        // return $selectedTransaction;
        return view('content.intern_management.manage_intern.intern_print', [
            'payment' => $payment,
            'transaction' => $selectedTransaction,
            'print_decryptedValue' => $transactionIndex,
            'gstPercentage' => $branch->gst_percentage ?? 0,
            'terms' => $terms_conditions,
            'qrCodeData' => json_encode($qrCodeData)
        ]);
    }

    public function generate(Request $request)
    {
        // Basic required validation
        $rules = [
            'company_id' => 'required|integer',
            'certificate_issue_date' => 'required|date',
            'generate_id' => 'required|integer',
            'user_type' => 'required|string|in:Student,Employee',
        ];

        // Conditional rules based on user_type
        if ($request->user_type === 'Student') {
            $rules['degree_id'] = 'required|integer';
            $rules['year'] = 'required|string';
        }

        $request->validate($rules);

        try {
            // Find intern by ID
            $intern = ManageInternModel::where('sno', $request->generate_id)->first();

            if (!$intern) {
                return response()->json(['success' => false, 'message' => 'Intern not found']);
            }

            // Update intern fields
            $intern->user_type = $request->user_type === 'Student' ? 1 : ($request->user_type === 'Employee' ? 2 : null);
            $intern->company_id = $request->company_id;
            $intern->degree_id = $request->degree_id ?? null; // null for Employee
            $intern->year = $request->year ?? null;
            $intern->certificate_issue_date = $request->certificate_issue_date;
            $intern->confirmation_date = $request->confirmation_date;
            $intern->save();

            return response()->json([
                'success' => true,
                'message' => 'Certificate generated successfully.',
                'user_type' => $intern->user_type, // 1 = Student, 2 = Employee
                'intern_id' => $intern->sno // 1 = Student, 2 = Employee
            ]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Failed to update certificate data.']);
        }
    }

    public function lead_add($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $id = $helper->encrypt_decrypt($id, 'decrypt');
        $exp = explode('~', $id);
        $id = str_replace(' ', '', $exp[0] ?? '');
        $branch_id = $request->user()->branch_id;

        // Check if decryption failed
        if ($id === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $interns = ManageInternModel::where('lead_id', $id)
            ->first();

        //  return $interns;
        return view('content.intern_management.manage_intern.lead_add_intern', compact('interns'));
    }
    public function CustomerIntern(Request $request)
    {
        
        // return $request->all();
        $validator = Validator::make($request->all(), [
            'lead_id' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }
        $branch_id = $request->user()->branch_id;
        $lead_id = $request->lead_id;
        $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code;
        $year = date("Y");

        // Get last intern_id for the same branch and format
        $intern_check = ManageInternModel::whereNotNull('intern_id')
            ->where('intern_id', 'LIKE', $year . '/' . $branch_code . '/IND%')
            ->orderByRaw("CAST(SUBSTRING_INDEX(intern_id, 'IND', -1) AS UNSIGNED) DESC")
            ->first();

        if (!$intern_check || !isset($intern_check->intern_id)) {
            $intern_id = $year . '/' . $branch_code . '/' . "IND2005";
        } else {
            $last_intern_id = $intern_check->intern_id; // e.g. 2025/MDU01/IND2042
            $parts = explode("/", $last_intern_id);

            if (isset($parts[2]) && preg_match('/IND(\d+)/', $parts[2], $matches)) {
                $next_number = (int)$matches[1] + 1;
            } else {
                $next_number = 2005;
            }

            $new_code = sprintf("IND%04d", $next_number);
            $intern_id = $year . '/' . $branch_code . '/' . $new_code;
        }
        // Fetch lead details
        $upd_lead = LeadModel::where('sno', $lead_id)->first();
        if (!$upd_lead) {
            return response([
                'status'    => 404,
                'message'   => 'Lead not found',
                'data'      => null,
            ], 404);
        }

        // Prepare customer data
        $customerData = [
            'lead_id'                => $lead_id,
            'intern_id'                => $intern_id,
            'intern_name'            => ucfirst($upd_lead->lead_name),
            'intern_mobile'          => $upd_lead->lead_mobile,
            'intern_email'           => $upd_lead->lead_email_id,
            'start_date'             => date('Y-m-d'),
            'end_date'               => date('Y-m-d'),
            'branch_id'              => $branch_id,
            'created_by'             => $request->user()->user_id,
            'updated_by'             => $request->user()->user_id,
            'status'                 => 3, // Assuming status = 3 for a new intern
        ];

        // Update or create the customer record
        ManageInternModel::updateOrCreate(
            ['lead_id' => $lead_id], // Match condition
            $customerData            // Data to update or insert
        );

        $helper = new \App\Helpers\Helpers();
        $encrypted_values = $helper->encrypt_decrypt($lead_id . '~' . '1', 'encrypt');
        return redirect()->route('lead_add_intern', ['id' => $encrypted_values]);
    }
    public function UpdateInternLead(Request $request)
    {
        $branch_id = $request->user()->branch_id;

        // Step 1: Validate request data
        $request->validate([
            'lead_id'           => 'required|integer',
            'college_id'        => 'required|integer',
            'topic_id'          => 'required',
            'payment'           => 'required|numeric',
            'start_date'        => 'required|date_format:d-M-Y',
            'end_date'          => 'required|date_format:d-M-Y',
            'staff_id'          => 'required|integer',
            'intern_name'       => 'required|string',
            'intern_email_id'   => 'required|email',
            'intern_mobile_no'  => 'required|digits:10',
        ]);

        // Fetch branch details
        $branch_check = BranchModel::where('sno', $branch_id)->first();
        $branch_code = $branch_check->city_short_code ?? '';

        // Find the intern record by lead_id
        $intern = ManageInternModel::where('lead_id', $request->lead_id)->first();

        if (!$intern) {
            return redirect()->back()->with('error', 'Intern record not found.');
        }

        // Prepare update data
        $updateData = [
            'branch_id'     => $branch_id,
            'college_id'    => $request->colleage_id,
            'topic'         => $request->topic_id,
            'intern_name'   => $request->intern_name,
            'intern_email'  => $request->intern_email_id,
            'intern_mobile' => $request->intern_mobile_no,
            'payment'       => $request->payment,
            'payment_gst'   => round(($request->payment * 18) / 100, 2),
            'paid'          => 0,
            'balance'       => $request->payment,
            'start_date'    => \Carbon\Carbon::createFromFormat('d-M-Y', $request->start_date)->format('Y-m-d'),
            'end_date'      => \Carbon\Carbon::createFromFormat('d-M-Y', $request->end_date)->format('Y-m-d'),
            'staff_id'      => $request->staff_id,
            'updated_by'    => $request->user()->id ?? null,
            'status'        => 0,
        ];

        // Update intern record
        $intern->update($updateData);

        return redirect('manage_intern')->with('success', 'Intern updated successfully!');
    }
    public function payment_mode_List(Request $request)
    {
        $Paymentmode = DB::table('et_payment_mode')->where('status', 0)->get();
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $Paymentmode
        ], 200);
    }
    public function encrypt_ids(Request $request)
    {
        // Get the values sent from JavaScript
        $values = $request->input('values');
        // Encrypt the combined values
        $helper = new \App\Helpers\Helpers();
        $encrypted_values = $helper->encrypt_decrypt($values, 'encrypt');
        // Return the encrypted value as JSON
        return response()->json($encrypted_values);
    }
}
