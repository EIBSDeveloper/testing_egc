<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\LeadTypeModel;
use App\Models\LeadSourceModel;

class CustomerReport extends Controller
{
    public static $report_heading = 'Analysis';
    protected static $temp = [];

    public function customer_drop()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.customer_report.customer_drop_yearly_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusDropYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $result = $this->GetCustomerDropDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];

            // return $result;

            $types_list = [
                'customer_count' => 'Customers',
                'drop_customer_count' => 'Drops'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years']) ? collect($result['years']) : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $month_percentages = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        $date_format = sprintf('%02d-%d', $monthNum, $year);
                        
                        $paymentSums = isset($result) && !empty($result) ? $result : [];

                        $monthly_data = !empty($yearlyData) ? $yearlyData : [];

                        foreach ($types_list as $type_key => $type_name) {

                            if (strtotime($date_format) <= strtotime($currentDate)) {
                                $amount = isset($monthlyData[$year][$monthNum][$type_key]) ? $monthlyData[$year][$monthNum][$type_key] : 0;
                            } else {
                                $amount = 0;
                            }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($monthly_data[$year][$type_key] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $percentages[$year] = ($monthly_data[$year]['drop_percentage'] ?? 0);
                                $month_percentages[$year][$monthNum] = isset($monthlyData[$year][$monthNum]['drop_percentage']) ? $monthlyData[$year][$monthNum]['drop_percentage'] : 0;

                                $typeMonthTotals[$type_key][$year] = ($monthly_data[$year][$type_key] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'month_percentages' => $month_percentages,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_drop_monthly(Request $request)
    {
        $days = range(1,31);
        $year = date('Y');
        $yearShort = date('y');

        return view('content.report_management.customer_report.customer_drop_list', compact('days','year','yearShort'))->with('report_heading', self::$report_heading);
    }

    public function CusDropMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate = date('d-m-Y');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetCustomerDropDetails($branch_id);

            // return $result;

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];
            
            $types_list = [
                'customer_count' => 'Customers',
                'drop_customer_count' => 'Drops'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $increment_data  = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $day_percentages = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($days as $day) {

                    $date_format = sprintf('%02d-%02d-%d', $day, $monthNum, $year);
                    
                    $paymentSums = isset($result) && !empty($result) ? $result : [];
                    $monthly_data = isset($monthlyData) && !empty($monthlyData) ? $monthlyData : [];

                    foreach ($types_list as $type_key => $type_name) {

                        if (strtotime($date_format) <= strtotime($currentDate)) {
                            $amount = isset($dailyData[$year][$monthNum][$day][$type_key]) ? round($dailyData[$year][$monthNum][$day][$type_key]) : 0;
                        } else {
                            $amount = 0;
                        }

                        if (strtotime($date_format) <= strtotime($currentDate)) {
                            $incre_amount = isset($dailyData[$year][$monthNum][$day][$type_key]) ? round($dailyData[$year][$monthNum][$day][$type_key]) : 0;
                        } else {
                            $incre_amount = 0;
                        }

                        $pre_amount = isset($dailyData[$pre_year][12][$pre_daysInMonth][$type_key]) ? round($dailyData[$pre_year][12][$pre_daysInMonth][$type_key]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $increment_data[$monthNum][$day][$type_key] = $incre_amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        $Trend_data_list[$type_key] = $amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + ($totals[$monthNum][$type_key] ?? 0);

                        $percentages[$monthNum] = ($monthly_data[$year][$monthNum]['drop_percentage'] ?? 0);
                        $day_percentages[$monthNum][$day] = isset($dailyData[$year][$monthNum][$day]['drop_percentage']) && !empty($dailyData[$year][$monthNum][$day]['drop_percentage']) ? $dailyData[$year][$monthNum][$day]['drop_percentage'] : 0;

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'increment_data' => $increment_data,
                'pre_inern_cal_data' => $pre_data,
                'day_percentages' => $day_percentages,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_src_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.customer_report.customer_src_yearly_list', compact(
            'months',
            'short_months',
            'currentMonth',
            'currentYear'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusSrcYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = date('Y-01-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetCustSourceDetails($branch_id, $search_lead_src_fill);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            // $lead_source_list = $result['lead_source_list'] ?? [];

            $sortedLeadSource = DB::table('et_lead_source')
                    ->select('sno', 'lead_source_name')
                    ->where('status', '!=', 2)
                    ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
                        $q->whereIn('sno', $search_lead_src_fill);
                    })->orderBy('lead_source_name', 'asc')
                    ->get();
                    
            $lead_source_list = $sortedLeadSource->mapWithKeys(function ($item) {
                return ['type_'.$item->sno => $item->lead_source_name];
            })->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                // 'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = (int)$year - 1;

            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $lead_source_id_new = str_replace("type_", "", $lead_source_id);

                foreach ($months as $monthNum => $monthName) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $monthlyData[$lead_source_id_new][$year][$monthNum][$type_key] ?? 0;

                        $data[$lead_source_id][$monthNum][$type_key] = $amount;

                        // Previous Month / Year logic
                        if ($monthNum == 1) {
                            $prevYear  = $year - 1;
                            $prevMonth = 12;
                        } else if ($monthNum != 1) {
                            $prevYear  = $year;
                            $prevMonth = $monthNum - 1;
                        }

                        $pre_count = $monthlyData[$lead_source_id_new][$prevYear][$prevMonth][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevMonth][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        // $percentages[$lead_source_id] =
                        //     $yearlyData[$lead_source_id][$year]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;
                            
                        $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $source_totals = $totals[$lead_source_id][$type_key] ?? 0;

                foreach ($months as $monthNum => $monthName) {

                    foreach ($types_list as $type_key => $type_name) {

                        $percentages[$lead_source_id][$monthNum] = ($source_totals > 0) ? round(($data[$lead_source_id][$monthNum][$type_key] / $source_totals) * 100, 2) : 0;
                    }
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_src_monthly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

        $months = $this->getYearBasedMonths($currentYear);

        $days = range(1, $daysInMonth);

        return view('content.report_management.customer_report.customer_src_list', [
            'days','currentMonth', 'currentYear','months'
        ])->with('report_heading', self::$report_heading);
    }

    public function CusSrcMonthlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));
            $Month_name      = date('F', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetCustSourceDetails($branch_id, $search_lead_src_fill);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            // $lead_source_list = $result['lead_source_list'] ?? [];

            // ================================
            //  🔥 SORT LEAD SOURCE LIST BY NAME (A → Z)
            //  AND KEEP KEYS AS STRINGS
            // ================================
            $sortedLeadSource = DB::table('et_lead_source')
                    ->select('sno', 'lead_source_name')
                    ->where('status', '!=', 2)
                    ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
                        $q->whereIn('sno', $search_lead_src_fill);
                    })->orderBy('lead_source_name', 'asc')
                    ->get();
                    
            $lead_source_list = $sortedLeadSource->mapWithKeys(function ($item) {
                return ['type_'.$item->sno => $item->lead_source_name];
            })->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                // 'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = $year - 1;

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);
        
            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $lead_source_id_new = str_replace("type_", "", $lead_source_id);

                // return $lead_source_id_new;

                foreach ($days as $day) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $dailyData[$lead_source_id_new][$year][$Month][$day][$type_key] ?? 0;

                        $data[$lead_source_id][$day][$type_key] = $amount;

                        $prevMonth = 0;
                        $prevYear = 0;
                        $prevDay = 0;

                        if ((int)$Month == 1 && $day == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }else if($day == 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$Month - 1;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }

                        $pre_count = $dailyData[$lead_source_id_new][$prevYear][$prevMonth][$prevDay][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevDay][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        // $percentages[$lead_source_id] =
                        //     $monthlyData[$lead_source_id][$year][$Month]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $source_totals = $totals[$lead_source_id][$type_key] ?? 0;

                foreach ($days as $day) {

                    foreach ($types_list as $type_key => $type_name) {

                        $percentages[$lead_source_id][$day] = ($source_totals > 0) ? round(($data[$lead_source_id][$day][$type_key] / $source_totals) * 100, 2) : 0;
                    }
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'Month_name' => $Month_name,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_age_yearly()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.customer_report.cus_age_gen_yearly_list', compact(
            'months',
        ))->with('report_heading', self::$report_heading);
    }

    public function CusAgeYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $result = $this->GetCustGenderDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];

            // return $result;

            $types_list = [
                'male_count' => 'Male',
                'female_count' => 'Female',
                'others_count' => 'Others',
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years']) ? collect($result['years']) : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        $date_format = sprintf('%02d-%d', $monthNum, $year);
                        
                        $paymentSums = isset($result) && !empty($result) ? $result : [];

                        $monthly_data = !empty($yearlyData) ? $yearlyData : [];

                        foreach ($types_list as $type_key => $type_name) {

                            if (strtotime($date_format) <= strtotime($currentDate)) {
                                $amount = isset($monthlyData[$year][$monthNum][$type_key]) ? $monthlyData[$year][$monthNum][$type_key] : 0;
                            } else {
                                $amount = 0;
                            }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($monthly_data[$year][$type_key] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                // $percentages[$year] = ($monthly_data[$year]['conversion_percentage'] ?? 0);

                                $typeMonthTotals[$type_key][$year] = ($monthly_data[$year][$type_key] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_age_monthly()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $days = range(1,31);
        $year = date('Y');
        $yearShort = date('y');
        return view('content.report_management.customer_report.cus_age_gen_list', compact(
            'months',
            'days',
            'yearShort'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusAgeMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate = date('d-m-Y');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetCustGenderDetails($branch_id);

            // return ['result' => $result];

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];
            
            $types_list = [
                'male_count' => 'Male',
                'female_count' => 'Female',
                'others_count' => 'Others',
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $increment_data  = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($days as $day) {

                    $date_format = sprintf('%02d-%02d-%d', $day, $monthNum, $year);
                    
                    $paymentSums = isset($result) && !empty($result) ? $result : [];
                    $monthly_data = isset($monthlyData) && !empty($monthlyData) ? $monthlyData : [];

                    foreach ($types_list as $type_key => $type_name) {

                        if (strtotime($date_format) <= strtotime($currentDate)) {
                            $amount = isset($dailyData[$year][$monthNum][$day][$type_key]) ? round($dailyData[$year][$monthNum][$day][$type_key]) : 0;
                        } else {
                            $amount = 0;
                        }

                        $pre_amount = isset($dailyData[$pre_year][12][$pre_daysInMonth][$type_key]) ? round($dailyData[$pre_year][12][$pre_daysInMonth][$type_key]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        $Trend_data_list[$type_key] = $amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + $amount;

                        // $percentages[$monthNum] = ($monthly_data[$year][$monthNum]['conversion_percentage'] ?? 0);

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'increment_data' => $increment_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_employee_type_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.customer_report.customer_type_yearly_list', compact(
            'months',
            'short_months',
            'currentMonth',
            'currentYear'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusTypeYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');
            

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = date('Y-01-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetCustTypeDetails($branch_id, $search_lead_src_fill);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;
            
            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            // $lead_source_list = $result['lead_source_list'] ?? [];

            $sortedLeadSource = DB::table('et_lead_type')
                                ->select('sno', 'lead_type_name')
                                ->where('status', '!=', 2)
                                ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
                                    $q->whereIn('sno', $search_lead_src_fill);
                                })->orderBy('lead_type_name', 'asc')
                                ->get();
                    
            $lead_source_list = $sortedLeadSource->mapWithKeys(function ($item) {
                return ['type_'.$item->sno => $item->lead_type_name];
            })->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                // 'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = (int)$year - 1;

            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $lead_source_id_new = str_replace("type_", "", $lead_source_id);

                foreach ($months as $monthNum => $monthName) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $monthlyData[$lead_source_id_new][$year][$monthNum][$type_key] ?? 0;

                        $data[$lead_source_id][$monthNum][$type_key] = $amount;

                        // Previous Month / Year logic
                        if ($monthNum == 1) {
                            $prevYear  = $year - 1;
                            $prevMonth = 12;
                        } else if ($monthNum != 1) {
                            $prevYear  = $year;
                            $prevMonth = $monthNum - 1;
                        }

                        $pre_count = $monthlyData[$lead_source_id_new][$prevYear][$prevMonth][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevMonth][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        // $percentages[$lead_source_id] =
                        //     $yearlyData[$lead_source_id][$year]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $source_totals = $totals[$lead_source_id][$type_key] ?? 0;

                foreach ($months as $monthNum => $monthName) {

                    foreach ($types_list as $type_key => $type_name) {

                        $percentages[$lead_source_id][$monthNum] = ($source_totals > 0) ? round(($data[$lead_source_id][$monthNum][$type_key] / $source_totals) * 100, 2) : 0;
                    }
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_employee_type_monthly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

        $months = $this->getYearBasedMonths($currentYear);

        $days = range(1, $daysInMonth);

        return view('content.report_management.customer_report.customer_type_list', compact(
            'days','currentMonth', 'currentYear','months'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusTypeMonthlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));
            $Month_name      = date('F', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetCustTypeDetails($branch_id, $search_lead_src_fill);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            // $lead_source_list = $result['lead_source_list'] ?? [];

            // ================================
            //  🔥 SORT LEAD SOURCE LIST BY NAME (A → Z)
            //  AND KEEP KEYS AS STRINGS
            // ================================
            $sortedLeadSource = DB::table('et_lead_type')
                                ->select('sno', 'lead_type_name')
                                ->where('status', '!=', 2)
                                ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
                                    $q->whereIn('sno', $search_lead_src_fill);
                                })->orderBy('lead_type_name', 'asc')
                                ->get();
                    
            $lead_source_list = $sortedLeadSource->mapWithKeys(function ($item) {
                return ['type_'.$item->sno => $item->lead_type_name];
            })->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                // 'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = $year - 1;

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);
        
            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $lead_source_id_new = str_replace("type_", "", $lead_source_id);

                // return $lead_source_id_new;

                foreach ($days as $day) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $dailyData[$lead_source_id_new][$year][$Month][$day][$type_key] ?? 0;

                        $data[$lead_source_id][$day][$type_key] = $amount;

                        $prevMonth = 0;
                        $prevYear = 0;
                        $prevDay = 0;

                        if ((int)$Month == 1 && $day == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }else if($day == 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$Month - 1;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }

                        $pre_count = $dailyData[$lead_source_id_new][$prevYear][$prevMonth][$prevDay][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevDay][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        // $percentages[$lead_source_id] =
                        //     $monthlyData[$lead_source_id][$year][$Month]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                $source_totals = $totals[$lead_source_id][$type_key] ?? 0;

                foreach ($days as $day) {

                    foreach ($types_list as $type_key => $type_name) {

                        $percentages[$lead_source_id][$day] = ($source_totals > 0) ? round(($data[$lead_source_id][$day][$type_key] / $source_totals) * 100, 2) : 0;
                    }
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'Month_name' => $Month_name,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function GetCustTypeDetails($branch_id, $search_lead_src_fill = [])
    {
        if (!$branch_id) {
            throw new \Exception("Branch ID required");
        }

        $leadSources = [];
        $daily = [];
        $monthly = [];
        $yearly = [];

        /* ------------------------------------
        * LEAD SOURCE LIST
        * ------------------------------------ */
        $leadSource_list = DB::table('et_lead_type')
            ->select('sno', 'lead_type_name')
            ->where('status', '!=', 2)
            ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
                $q->whereIn('sno', $search_lead_src_fill);
            })
            ->get();

        $OthersleadSource_data = DB::table('et_lead_type')
            ->select('sno', 'lead_type_name')
            ->where('status', '!=', 2)
            ->where('lead_type_name', 'LIKE', '%others%')
            ->first();

        $otherSourceId   = $OthersleadSource_data->sno ?? 0;
        $otherSourceName = $OthersleadSource_data->lead_type_name ?? 'Others';

        $leadSourceListIds = $leadSource_list->pluck('sno')->toArray();
        $leadSourceList    = $leadSource_list->pluck('lead_type_name', 'sno')->toArray();

        /* ---------------------------------------------------------
        * LEAD DATA
        * --------------------------------------------------------- */
        $leadData = DB::table('et_lead')
            ->join('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
            ->select(
                'et_lead_type.sno as source_id',
                'et_lead_type.lead_type_name as source_name',
                DB::raw('YEAR(et_lead.registered_date) as y'),
                DB::raw('MONTH(et_lead.registered_date) as m'),
                DB::raw('DAY(et_lead.registered_date) as d'),
                DB::raw('COUNT(et_lead.sno) as lead_count')
            )
            ->where('et_lead.internal_status', '!=', 1)
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.created_by', '>', 0)
            ->where('et_lead.branch_id', $branch_id)
            ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
            ->get();

        /* ---------------------------------------------------------
        * CONVERSION DATA (PRE + POST)
        * --------------------------------------------------------- */
        $conversionData = DB::query()
            ->fromSub(function ($q) use ($branch_id, $otherSourceId, $otherSourceName) {

                /* PRE CUSTOMER */
                $q->from('et_customer')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->LeftJoin('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(p.transaction_date)
                                FROM et_payment p
                                WHERE p.customer_id = et_customer.sno
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->select(
                        DB::raw("COALESCE(et_lead_type.sno, {$otherSourceId}) as source_id"),
                        DB::raw("COALESCE(et_lead_type.lead_type_name, '{$otherSourceName}') as source_name"),
                        DB::raw('YEAR(et_payment.transaction_date) as y'),
                        DB::raw('MONTH(et_payment.transaction_date) as m'),
                        DB::raw('DAY(et_payment.transaction_date) as d'),
                        DB::raw('COUNT(et_customer.sno) as conversion_count')
                    )
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_customer.status', 0)
                    ->where('et_lead.created_by', '>', 0)
                    ->where('et_customer.branch_id', $branch_id)
                    ->groupBy('source_id', 'source_name', 'y', 'm', 'd')

                    /* POST CUSTOMER */
                    ->unionAll(
                        DB::table('et_customer')
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->LeftJoin('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
                            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                            ->join('et_payment', function ($join) {
                                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                    ->whereRaw('et_payment.transaction_date = (
                                        SELECT MIN(p.transaction_date)
                                        FROM et_payment p
                                        WHERE p.proposal_id = et_proposal.sno
                                    )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->select(
                                DB::raw("COALESCE(et_lead_type.sno, {$otherSourceId}) as source_id"),
                                DB::raw("COALESCE(et_lead_type.lead_type_name, '{$otherSourceName}') as source_name"),
                                DB::raw('YEAR(et_payment.transaction_date) as y'),
                                DB::raw('MONTH(et_payment.transaction_date) as m'),
                                DB::raw('DAY(et_payment.transaction_date) as d'),
                                DB::raw('COUNT(et_customer.sno) as conversion_count')
                            )
                            ->where('et_transaction.payment_status', 1)
                            ->where('et_customer.status', 0)
                            ->where('et_customer.post_sale_check', 1)
                            ->where('et_proposal.post_sale_check', 1)
                            ->where('et_lead.created_by', '>', 0)
                            ->where('et_customer.branch_id', $branch_id)
                            ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
                    );
            }, 'combined')
            ->select(
                'source_id',
                'source_name',
                'y', 'm', 'd',
                DB::raw('SUM(conversion_count) as conversion_count')
            )
            ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
            ->get();

        // return $conversionData;
        
        /* ---------------------------------------------------------
        * MERGE LEAD + CONVERSION
        * --------------------------------------------------------- */
        foreach ($leadData as $row) {
            $leadSources[$row->source_id]['source_name'] = $row->source_name;
            $leadSources[$row->source_id][$row->y][$row->m][$row->d] = [
                'lead_count' => $row->lead_count,
                'conversion_count' => 0
            ];
        }

        foreach ($conversionData as $row) {
            $leadSources[$row->source_id]['source_name'] ??= $row->source_name;
            $leadSources[$row->source_id][$row->y][$row->m][$row->d]['lead_count'] ??= 0;
            $leadSources[$row->source_id][$row->y][$row->m][$row->d]['conversion_count'] = $row->conversion_count;
        }

        /* ---------------------------------------------------------
        * DAILY / MONTHLY / YEARLY
        * --------------------------------------------------------- */
        foreach ($leadSources as $sid => $srcData) {
            foreach ($srcData as $y => $mData) {
                if ($y === 'source_name') continue;

                foreach ($mData as $m => $dData) {

                    foreach ($dData as $d => $v) {
                        $daily[$sid][$y][$m][$d] = [
                            'lead_count' => $v['lead_count'],
                            'conversion_count' => $v['conversion_count'],
                            'conversion_percentage' =>
                                $v['lead_count'] > 0
                                    ? round(($v['conversion_count'] / $v['lead_count']) * 100, 2)
                                    : 0
                        ];
                    }

                    $monthLead = array_sum(array_column($dData, 'lead_count'));
                    $monthConv = array_sum(array_column($dData, 'conversion_count'));

                    $monthly[$sid][$y][$m] = [
                        'lead_count' => $monthLead,
                        'conversion_count' => $monthConv,
                        'conversion_percentage' =>
                            $monthLead > 0 ? round(($monthConv / $monthLead) * 100, 2) : 0
                    ];
                }

                $yearLead = array_sum(array_column($monthly[$sid][$y], 'lead_count'));
                $yearConv = array_sum(array_column($monthly[$sid][$y], 'conversion_count'));

                $yearly[$sid][$y] = [
                    'lead_count' => $yearLead,
                    'conversion_count' => $yearConv,
                    'conversion_percentage' =>
                        $yearLead > 0 ? round(($yearConv / $yearLead) * 100, 2) : 0
                ];
            }
        }

        return [
            'lead_type_list' => $leadSourceList,
            'daily'   => $daily,
            'monthly' => $monthly,
            'yearly'  => $yearly
        ];
    }

    public function GetCustSourceDetails($branch_id, $search_lead_src_fill = [])
    {
        if (!$branch_id) {
            throw new \Exception("Branch ID required");
        }

        $leadSources = [];
        $daily = [];
        $monthly = [];
        $yearly = [];
        // $leadSourceList = [];

        /* ------------------------------------
        * 1. Lead Sources List (ASC order)
        * ------------------------------------ */
        $leadSource_list = DB::table('et_lead_source')
        ->select('sno', 'lead_source_name as source_name')
        ->where('status', '!=', 2)
        ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
            $q->whereIn('sno', $search_lead_src_fill);
        })
        ->get();

        // Ensure alphabetical sorting A → Z
        $sortedLeadSource = $leadSource_list->sortBy(function ($item) {
            return strtolower($item->source_name);
        });

        // Final arrays
        $leadSourceListIds = $sortedLeadSource->pluck('sno')->toArray();
        $leadSourceList    = $sortedLeadSource->pluck('source_name', 'sno')->toArray();

        /* ---------------------------------------------------------
        | 1. LEAD DATA (ALL YEARS, ALL MONTHS)
        --------------------------------------------------------- */
        $leadData = DB::table('et_lead')
            ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->select(
                'et_lead_source.sno as source_id',
                'et_lead_source.lead_source_name as source_name',
                DB::raw('DAY(et_lead.registered_date) as d'),
                DB::raw('MONTH(et_lead.registered_date) as m'),
                DB::raw('YEAR(et_lead.registered_date) as y'),
                DB::raw('COUNT(et_lead.sno) as lead_count')
            )
            ->where('et_lead.internal_status', '!=', 1)
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.created_by', '>', 0)
            ->where('et_lead.branch_id', $branch_id)
            ->whereIn('et_lead_source.sno', $leadSourceListIds)
            ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
            ->get();


        /* ---------------------------------------------------------
        | 2. CONVERSION DATA (ALL YEARS, ALL MONTHS)
        --------------------------------------------------------- */
        $conversionData = DB::query()
            ->fromSub(function ($query) use ($branch_id, $leadSourceListIds) {

                /* ---------------- PRE CUSTOMER ---------------- */
                $query->from('et_customer')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->select(
                        'et_lead_source.sno as source_id',
                        'et_lead_source.lead_source_name as source_name',
                        DB::raw('YEAR(et_payment.transaction_date) as y'),
                        DB::raw('MONTH(et_payment.transaction_date) as m'),
                        DB::raw('DAY(et_payment.transaction_date) as d'),
                        DB::raw('COUNT(et_customer.sno) as conversion_count')
                    )
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_customer.status', 0)
                    ->where('et_lead.created_by', '>', 0)
                    ->where('et_customer.branch_id', $branch_id)
                    ->whereIn('et_lead_source.sno', $leadSourceListIds)
                    ->groupBy('source_id', 'source_name', 'y', 'm', 'd')

                /* ---------------- UNION ALL POST CUSTOMER ---------------- */
                ->unionAll(
                    DB::table('et_customer')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function ($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->select(
                            'et_lead_source.sno as source_id',
                            'et_lead_source.lead_source_name as source_name',
                            DB::raw('YEAR(et_payment.transaction_date) as y'),
                            DB::raw('MONTH(et_payment.transaction_date) as m'),
                            DB::raw('DAY(et_payment.transaction_date) as d'),
                            DB::raw('COUNT(et_customer.sno) as conversion_count')
                        )
                        ->where('et_transaction.payment_status', 1)
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_proposal.created_by', '>', 0)
                        ->where('et_lead.created_by', '>', 0)
                        ->where('et_customer.branch_id', $branch_id)
                        ->whereIn('et_lead_source.sno', $leadSourceListIds)
                        ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
                );

            }, 'combined')
            ->select(
                'source_id',
                'source_name',
                'y',
                'm',
                'd',
                DB::raw('SUM(conversion_count) as conversion_count')
            )
            ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
            ->orderBy('y')
            ->orderBy('m')
            ->orderBy('d')
            ->get();


        /* ---------------------------------------------------------
        | Merge both LEAD + CONVERSION
        --------------------------------------------------------- */
        foreach ($leadData as $row) {

            // build lead source list
            // $leadSourceList[$row->source_id] = [
            //     "source_id" => $row->source_id,
            //     "source_name" => $row->source_name
            // ];

            $s = $row->source_id;
            $y = $row->y;
            $m = $row->m;
            $d = $row->d;

            $leadSources[$s]['source_name'] = $row->source_name;
            $leadSources[$s][$y][$m][$d]['lead_count'] = $row->lead_count;
            $leadSources[$s][$y][$m][$d]['conversion_count'] = 0;
        }

        foreach ($conversionData as $row) {

            // ensure lead source exists
            // if (!isset($leadSourceList[$row->source_id])) {
            //     $leadSourceList[$row->source_id] = [
            //         "source_id" => $row->source_id,
            //         "source_name" => $row->source_name
            //     ];
            // }

            $s = $row->source_id;
            $y = $row->y;
            $m = $row->m;
            $d = $row->d;

            if (!isset($leadSources[$s]['source_name'])) {
                $leadSources[$s]['source_name'] = $row->source_name;
            }

            if (!isset($leadSources[$s][$y][$m][$d]['lead_count'])) {
                $leadSources[$s][$y][$m][$d]['lead_count'] = 0;
            }

            $leadSources[$s][$y][$m][$d]['conversion_count'] = $row->conversion_count;
        }


        /* ---------------------------------------------------------
        | DAILY / MONTHLY / YEARLY summary
        --------------------------------------------------------- */
        foreach ($leadSources as $sourceId => $srcData) {

            foreach ($srcData as $y => $mData) {
                if ($y === 'source_name') continue;

                foreach ($mData as $m => $dData) {

                    // DAILY
                    foreach ($dData as $d => $v) {

                        $lead = $v['lead_count'];
                        $conv = $v['conversion_count'];

                        $daily[$sourceId][$y][$m][$d] = [
                            'lead_count' => $lead,
                            'conversion_count' => $conv,
                            'conversion_percentage' =>
                                ($lead > 0 ? round(($conv / $lead) * 100, 2) : 0)
                        ];
                    }

                    // MONTHLY
                    $monthLead = array_sum(array_column($dData, 'lead_count'));
                    $monthConv = array_sum(array_column($dData, 'conversion_count'));

                    $monthly[$sourceId][$y][$m] = [
                        'lead_count' => $monthLead,
                        'conversion_count' => $monthConv,
                        'conversion_percentage' =>
                            ($monthLead > 0 ? round(($monthConv / $monthLead) * 100, 2) : 0)
                    ];
                }

                // YEARLY
                $yearLead = 0;
                $yearConv = 0;

                foreach ($monthly[$sourceId][$y] as $m => $vals) {
                    $yearLead += $vals['lead_count'];
                    $yearConv += $vals['conversion_count'];
                }

                $yearly[$sourceId][$y] = [
                    'lead_count' => $yearLead,
                    'conversion_count' => $yearConv,
                    'conversion_percentage' =>
                        ($yearLead > 0 ? round(($yearConv / $yearLead) * 100, 2) : 0)
                ];
            }
        }


        /* ---------------------------------------------------------
        | FINAL RETURN
        --------------------------------------------------------- */
        return [
            "lead_source_list" => $leadSourceList, // clean list
            "daily"   => $daily,
            "monthly" => $monthly,
            "yearly"  => $yearly
        ];
    }

    private function GetCustomerDropDetails($branch_id)
    {
        if (!$branch_id) {
            throw new \Exception("Branch ID required");
        }

        $daily   = [];
        $monthly = [];
        $yearly  = [];
        $yearsList = [];

        $customerData = DB::query()
            ->fromSub(function ($query) use ($branch_id) {

                /* ---------------- PRE CUSTOMER ---------------- */
                $query->from('et_customer')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->select(
                        DB::raw('YEAR(et_payment.transaction_date) as y'),
                        DB::raw('MONTH(et_payment.transaction_date) as m'),
                        DB::raw('DAY(et_payment.transaction_date) as d'),
                        DB::raw('COUNT(et_customer.sno) as customer_count')
                    )
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_customer.status', 0)
                    ->where('et_lead.created_by', '>', 0)
                    ->where('et_customer.branch_id', $branch_id)
                    ->groupBy('y', 'm', 'd')

                /* ---------------- UNION ALL POST CUSTOMER ---------------- */
                ->unionAll(
                    DB::table('et_customer')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function ($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->select(
                            DB::raw('YEAR(et_payment.transaction_date) as y'),
                            DB::raw('MONTH(et_payment.transaction_date) as m'),
                            DB::raw('DAY(et_payment.transaction_date) as d'),
                            DB::raw('COUNT(et_customer.sno) as customer_count')
                        )
                        ->where('et_transaction.payment_status', 1)
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_proposal.created_by', '>', 0)
                        ->where('et_lead.created_by', '>', 0)
                        ->where('et_customer.branch_id', $branch_id)
                        ->groupBy('y', 'm', 'd')
                );

            }, 'combined')
            ->select(
                'y',
                'm',
                'd',
                DB::raw('SUM(customer_count) as customer_count')
            )
            ->groupBy('y', 'm', 'd')
            ->orderBy('y')
            ->orderBy('m')
            ->orderBy('d')
            ->get();

        /* ---------------------------------------------------------
        | 2. DROP CUSTOMER COUNT (et_drop_refund)
        --------------------------------------------------------- */
        $dropData = DB::table('et_drop_refund')
            ->select(
                DB::raw('DAY(created_at) as d'),
                DB::raw('MONTH(created_at) as m'),
                DB::raw('YEAR(created_at) as y'),
                DB::raw('COUNT(DISTINCT customer_id) as drop_count')
            )
            ->where([
                ['type', '=', 0],
                ['bh_status', '=', 1],
                ['status', '=', 0],
                ['branch_id', '=', $branch_id],
            ])
            ->groupBy('y', 'm', 'd')
            ->get();

        /* ---------------------------------------------------------
        | 3. NORMALIZE CUSTOMER DATA
        --------------------------------------------------------- */
        foreach ($customerData as $row) {

            $y = $row->y;
            $m = $row->m;
            $d = $row->d;
            $count = (int) $row->customer_count;

            if (!in_array($y, $yearsList)) {
                $yearsList[] = $y;
            }

            // DAILY
            if (!isset($daily[$y][$m][$d]['customer_count'])) {
                $daily[$y][$m][$d]['customer_count'] = 0;
            }
            $daily[$y][$m][$d]['customer_count'] += $count;

            // MONTHLY
            if (!isset($monthly[$y][$m]['customer_count'])) {
                $monthly[$y][$m]['customer_count'] = 0;
            }
            $monthly[$y][$m]['customer_count'] += $count;

            // YEARLY
            if (!isset($yearly[$y]['customer_count'])) {
                $yearly[$y]['customer_count'] = 0;
            }
            $yearly[$y]['customer_count'] += $count;
        }

        /* ---------------------------------------------------------
        | 4. NORMALIZE DROP CUSTOMER DATA
        --------------------------------------------------------- */
        foreach ($dropData as $row) {

            $y = $row->y;
            $m = $row->m;
            $d = $row->d;
            $count = (int) $row->drop_count;

            if (!in_array($y, $yearsList)) {
                $yearsList[] = $y;
            }

            // DAILY
            if (!isset($daily[$y][$m][$d]['drop_customer_count'])) {
                $daily[$y][$m][$d]['drop_customer_count'] = 0;
            }
            $daily[$y][$m][$d]['drop_customer_count'] += $count;

            // MONTHLY
            if (!isset($monthly[$y][$m]['drop_customer_count'])) {
                $monthly[$y][$m]['drop_customer_count'] = 0;
            }
            $monthly[$y][$m]['drop_customer_count'] += $count;

            // YEARLY
            if (!isset($yearly[$y]['drop_customer_count'])) {
                $yearly[$y]['drop_customer_count'] = 0;
            }
            $yearly[$y]['drop_customer_count'] += $count;
        }

        sort($yearsList);

        /* ---------------------------------------------------------
        | 5. DAILY DROP PERCENTAGE
        --------------------------------------------------------- */
        foreach ($daily as $y => $months) {
            foreach ($months as $m => $days) {
                foreach ($days as $d => $data) {

                    $customer = $data['customer_count'] ?? 0;
                    $drop     = $data['drop_customer_count'] ?? 0;

                    $daily[$y][$m][$d]['drop_percentage'] = $customer > 0 ? round(($drop / $customer) * 100, 2) : 0;
                }
            }
        }

        /* ---------------------------------------------------------
        | 6. MONTHLY DROP PERCENTAGE
        --------------------------------------------------------- */
        foreach ($monthly as $y => $months) {
            foreach ($months as $m => $data) {

                $customer = $data['customer_count'] ?? 0;
                $drop     = $data['drop_customer_count'] ?? 0;

                $monthly[$y][$m]['drop_percentage'] = $customer > 0 ? round(($drop / $customer) * 100, 2) : 0;
            }
        }

        /* ---------------------------------------------------------
        | 7. YEARLY DROP PERCENTAGE
        --------------------------------------------------------- */
        foreach ($yearly as $y => $data) {

            $customer = $data['customer_count'] ?? 0;
            $drop     = $data['drop_customer_count'] ?? 0;

            $yearly[$y]['drop_percentage'] = $customer > 0 ? round(($drop / $customer) * 100, 2) : 0;
        }

        return [
            "daily"   => $daily,
            "monthly" => $monthly,
            "yearly"  => $yearly,
            "years"   => $yearsList
        ];
    }

    private function GetCustGenderDetails($branch_id)
    {
        if (!$branch_id) {
            throw new \Exception("Branch ID required");
        }

        $daily = [];
        $monthly = [];
        $yearly = [];
        $yearsList = [];

        /* ---------------------------------------------------------
        | 1. FETCH CUSTOMER (NO LEAD-SOURCE CONDITION)
        --------------------------------------------------------- */
        $genderData = DB::query()
            ->fromSub(function ($query) use ($branch_id) {

                /* ---------------- PRE CUSTOMER ---------------- */
                $query->from('et_customer')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->select(
                        'et_lead.lead_gender as gender',
                        DB::raw('YEAR(et_payment.transaction_date) as y'),
                        DB::raw('MONTH(et_payment.transaction_date) as m'),
                        DB::raw('DAY(et_payment.transaction_date) as d'),
                        DB::raw('COUNT(et_customer.sno) as customer_count'),
                        DB::raw('COUNT(et_customer.sno) as gender_count')
                    )
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_customer.status', 0)
                    ->where('et_lead.created_by', '>', 0)
                    ->where('et_customer.branch_id', $branch_id)
                    ->groupBy('gender', 'y', 'm', 'd')

                /* ---------------- UNION ALL POST CUSTOMER ---------------- */
                ->unionAll(
                    DB::table('et_customer')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function ($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->select(
                            'et_lead.lead_gender as gender',
                            DB::raw('YEAR(et_payment.transaction_date) as y'),
                            DB::raw('MONTH(et_payment.transaction_date) as m'),
                            DB::raw('DAY(et_payment.transaction_date) as d'),
                            DB::raw('COUNT(et_customer.sno) as customer_count'),
                            DB::raw('COUNT(et_customer.sno) as gender_count')
                        )
                        ->where('et_transaction.payment_status', 1)
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_proposal.created_by', '>', 0)
                        ->where('et_lead.created_by', '>', 0)
                        ->where('et_customer.branch_id', $branch_id)
                        ->groupBy('gender', 'y', 'm', 'd')
                );

            }, 'combined')
            ->select(
                'gender',
                'y',
                'm',
                'd',
                DB::raw('SUM(customer_count) as customer_count'),
                DB::raw('SUM(gender_count) as gender_count')
            )
            ->groupBy('gender', 'y', 'm', 'd')
            ->orderBy('y')
            ->orderBy('m')
            ->orderBy('d')
            ->get();


        /* ---------------------------------------------------------
        | 2. NORMALIZE GENDER → male_count / female_count / others_count
        --------------------------------------------------------- */
        $keyMap = [
            1 => 'male_count',
            2 => 'female_count',
            3 => 'others_count',
            '' => 'unknown_count',
            null => 'unknown_count'
        ];

        foreach ($genderData as $row) {

            $key = isset($row->gender) && !empty($row->gender) ? $keyMap[$row->gender] : 'others_count';

            $y = $row->y;
            $m = $row->m;
            $d = $row->d;
            $count = isset($row->gender_count) && !empty($row->gender_count) ? (int) $row->gender_count : 0;

            /* Track year */
            if (!in_array($y, $yearsList)) {
                $yearsList[] = $y;
            }

            /* -------------------------------
            | DAILY  →  [$y][$m][$d][$key]
            ------------------------------- */
            if (!isset($daily[$y][$m][$d][$key])) $daily[$y][$m][$d][$key] = 0;
            $daily[$y][$m][$d][$key] = $count;

            /* -------------------------------
            | MONTHLY → [$y][$m][$key]
            ------------------------------- */
            if (!isset($monthly[$y][$m][$key])) $monthly[$y][$m][$key] = 0;
            $monthly[$y][$m][$key] += $count;

            /* -------------------------------
            | YEARLY → [$y][$key]
            ------------------------------- */
            if (!isset($yearly[$y][$key])) $yearly[$y][$key] = 0;
            $yearly[$y][$key] += $count;
        
        }

        return [
            "daily"   => $daily,
            "monthly" => $monthly,
            "yearly"  => $yearly,
            "years"  => $yearsList
        ];
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    public function get_lead_type_list()
    {
        $LeadTypeModelList = LeadTypeModel::where('status', '!=', 2)->orderBy('lead_type_name', 'asc')->get();
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $LeadTypeModelList
        ], 200);
    }

    private function generateLeadSourceAttractiveColorsNew($leadTypesMapped, $baseHue = 200)
    {
        $colors = [];
        if (!empty($leadTypesMapped)) {
            foreach ($leadTypesMapped as $slotType => $slots) {
                // Ensure valid data
                if (!is_array($slots) || empty($slots)) {
                    continue;
                }
                $count = count($slots);
                $i = 0;
                foreach ($slots as $slug => $label) {
                    $hue = ($baseHue + $i * (360 / $count)) % 360;
                    // Assign color to slug within its slotType
                    $colors[$slotType][$slug] = "hsl({$hue}, 65%, 55%)";

                    $i++;
                }
            }
        }
        return $colors;
    }
}