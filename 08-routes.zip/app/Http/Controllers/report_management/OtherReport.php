<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\EventModel;
use App\Models\MarketingModel;
use App\Models\ExamModel;
use App\Models\ManageExamModel;
use App\Models\DepartmentModel;
use DateTime;

class OtherReport extends Controller
{
    public static $report_heading = 'Analysis';

    public function index()
    {
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.other_report.events_yr_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function EventYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $days = range(1, 31); // Daily

            $data                = [];
            $present_data        = [];
            $Trend_data          = [];
            $pre_data            = [];
            $percentages         = [];
            $Trend_percentages   = [];
            $total_students_data = [];
            $grandMonthTotals    = []; // per month (all types)
            $grandDayTotals      = [];
            $grandAllTotal       = 0; 
            $grandAllStudentsTotal = 0; 

            $result = $this->GetEventsDetails($branch_id);
            
            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            $paymentMonthSums = isset($result['yearly']) && !empty($result['yearly']) ? $result['yearly'] : [];
            $att_years = !empty($paymentMonthSums) ? collect(array_keys($paymentMonthSums)) : collect();
            $paymentSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];
            
            // Step 2: deduplicate, sort
            $allYears = $att_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            // return $years;
            
            foreach ($finalYears as $year_index => $year) {

                $pre_year  = (int)$year - 1;

                $Trend_data_list = [];
                
                foreach ($months as $monthNum => $monthName) {

                    $amount = isset($paymentSums[$year][$monthNum]['event_count']) ? round($paymentSums[$year][$monthNum]['event_count']) : 0;

                    // Save raw daily data
                    $data[$year][$monthNum] = $amount;

                    if($year_index != 0){
                        
                        $Trend_data_list[$monthNum] = $amount;

                        // Month grand total
                        $grandMonthTotals[$year] = ($grandMonthTotals[$year] ?? 0) + $amount;

                        // Day totals across months
                        $grandDayTotals[$monthNum] = ($grandDayTotals[$monthNum] ?? 0) + $amount;
                    }
                }

                if($year_index != 0){
                    $Trend_data[$year] = $Trend_data_list;
                }
            }

            foreach ($years as $year) {
                $monthTotal = $grandMonthTotals[$year] ?? 0;
                $grandAllTotal += $monthTotal;
            }

            $year_colors = $this->generateAttractiveColors($years);
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'inern_per_trend_data' => $Trend_percentages,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'grandAllStudentsTotal' => $grandAllStudentsTotal,
                'total_students_data' => $total_students_data,
                'present_data' => $present_data,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function events_monthly()
    {
        // Days (1–31 max)
        $days = range(1, 31);

        // Months
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.other_report.events_monthly_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function EventMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetEventsDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            $paymentSums = isset($result['daily']) && !empty($result['daily']) ? $result['daily'] : [];
            $paymentMonthSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];

            // return $paymentSums;
            $days = range(1, 31);

            $data                = [];
            $present_data        = [];
            $Trend_data          = [];
            $pre_data            = [];
            $percentages         = [];
            $Trend_percentages   = [];
            $total_students_data = [];
            $grandMonthTotals    = []; // per month (all types)
            $grandDayTotals      = [];
            $grandAllTotal       = 0; 
            $grandAllStudentsTotal = 0; 

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                        
                    $amount = isset($paymentSums[$year][$monthNum][$day]['event_count']) ? round($paymentSums[$year][$monthNum][$day]['event_count']) : 0;
                    
                    $pre_amount = isset($paymentSums[$pre_year][12][$pre_daysInMonth]['event_count']) ? round($paymentSums[$pre_year][12][$pre_daysInMonth]['event_count']) : 0;

                    // Save raw daily data
                    $data[$monthNum][$day] = $amount;

                    $Trend_data_list[$day] = $amount;

                    $pre_data[12][$pre_daysInMonth] = $pre_amount;

                    // Month grand total
                    $grandMonthTotals[$monthNum] = ($grandMonthTotals[$monthNum] ?? 0) + $amount;

                    // Day totals across months
                    $grandDayTotals[$day] = ($grandDayTotals[$day] ?? 0) + $amount;
                }

                $Trend_data[$monthName] = $Trend_data_list;
            }

            foreach ($months as $monthNum => $monthName) {
                $monthTotal = $grandMonthTotals[$monthNum] ?? 0;
                $grandAllTotal += $monthTotal;
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'inern_per_trend_data' => $Trend_percentages,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'grandAllStudentsTotal' => $grandAllStudentsTotal,
                'total_students_data' => $total_students_data,
                'present_data' => $present_data,
                'year' => $year
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function marketing_activity_yearly()
    {
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.other_report.marketing_activity_yr_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function MarketingActivityYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $days = range(1, 31); // Daily

            $data                = [];
            $present_data        = [];
            $Trend_data          = [];
            $pre_data            = [];
            $percentages         = [];
            $Trend_percentages   = [];
            $total_students_data = [];
            $grandMonthTotals    = []; // per month (all types)
            $grandDayTotals      = [];
            $grandAllTotal       = 0; 
            $grandAllStudentsTotal = 0; 

            $result = $this->GetMarketingActivityDetails($branch_id);
            
            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            $paymentMonthSums = isset($result['yearly']) && !empty($result['yearly']) ? $result['yearly'] : [];
            $att_years = !empty($paymentMonthSums) ? collect(array_keys($paymentMonthSums)) : collect();
            $paymentSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];
            
            // Step 2: deduplicate, sort
            $allYears = $att_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            // return $years;
            
            foreach ($finalYears as $year_index => $year) {

                $pre_year  = (int)$year - 1;

                $Trend_data_list = [];
                
                foreach ($months as $monthNum => $monthName) {

                    $amount = isset($paymentSums[$year][$monthNum]['activity_count']) ? round($paymentSums[$year][$monthNum]['activity_count']) : 0;

                    // Save raw daily data
                    $data[$year][$monthNum] = $amount;

                    if($year_index != 0){
                        
                        $Trend_data_list[$monthNum] = $amount;

                        // Month grand total
                        $grandMonthTotals[$year] = ($grandMonthTotals[$year] ?? 0) + $amount;

                        // Day totals across months
                        $grandDayTotals[$monthNum] = ($grandDayTotals[$monthNum] ?? 0) + $amount;
                    }
                }

                if($year_index != 0){
                    $Trend_data[$year] = $Trend_data_list;
                }
            }

            foreach ($years as $year) {
                $monthTotal = $grandMonthTotals[$year] ?? 0;
                $grandAllTotal += $monthTotal;
            }

            $year_colors = $this->generateAttractiveColors($years);
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'inern_per_trend_data' => $Trend_percentages,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'grandAllStudentsTotal' => $grandAllStudentsTotal,
                'total_students_data' => $total_students_data,
                'present_data' => $present_data,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function marketing_activity_monthly()
    {
       // Days (1–31 max)
        $days = range(1, 31);

        // Months
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.other_report.marketing_activity_monthly_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function MarketingActivityMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetMarketingActivityDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            $paymentSums = isset($result['daily']) && !empty($result['daily']) ? $result['daily'] : [];
            $paymentMonthSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];

            // return $paymentSums;
            $days = range(1, 31);

            $data                = [];
            $present_data        = [];
            $Trend_data          = [];
            $pre_data            = [];
            $percentages         = [];
            $Trend_percentages   = [];
            $total_students_data = [];
            $grandMonthTotals    = []; // per month (all types)
            $grandDayTotals      = [];
            $grandAllTotal       = 0; 
            $grandAllStudentsTotal = 0; 

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                        
                    $amount = isset($paymentSums[$year][$monthNum][$day]['activity_count']) ? round($paymentSums[$year][$monthNum][$day]['activity_count']) : 0;
                    
                    $pre_amount = isset($paymentSums[$pre_year][12][$pre_daysInMonth]['activity_count']) ? round($paymentSums[$pre_year][12][$pre_daysInMonth]['activity_count']) : 0;

                    // Save raw daily data
                    $data[$monthNum][$day] = $amount;

                    $Trend_data_list[$day] = $amount;

                    $pre_data[12][$pre_daysInMonth] = $pre_amount;

                    // Month grand total
                    $grandMonthTotals[$monthNum] = ($grandMonthTotals[$monthNum] ?? 0) + $amount;

                    // Day totals across months
                    $grandDayTotals[$day] = ($grandDayTotals[$day] ?? 0) + $amount;
                }

                $Trend_data[$monthName] = $Trend_data_list;
            }

            foreach ($months as $monthNum => $monthName) {
                $monthTotal = $grandMonthTotals[$monthNum] ?? 0;
                $grandAllTotal += $monthTotal;
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'inern_per_trend_data' => $Trend_percentages,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'grandAllStudentsTotal' => $grandAllStudentsTotal,
                'total_students_data' => $total_students_data,
                'present_data' => $present_data,
                'year' => $year
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function exam_completed_yearly()
    {
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.other_report.exam_completed_yr_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function ExamCompletedYearData(Request $request)
    {
        try {
            $selected_year = $request->year;
            // $selected_month = $request->month;

            // Accept multiple slugs (array or comma-separated string)
            $slugs = collect($request->slugs)
                ->when(is_string($request->slugs), fn($c) => collect(explode(',', $request->slugs)))
                ->map(fn($s) => strtolower(trim($s)))
                ->filter()
                ->unique()
                ->values()
                ->toArray();

            $search_lead_src_fill = $request->search_lead_src_fill ?? [];
            // $is_existing_val = (int)($request->is_existing_val ?? 2);

            // Validate year/month
            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year)
            ) {
                // $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = "{$selected_year}-01-01";
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = date('Y', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year,2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            $result = $this->GetExamDetails($branch_id);

            $order_list = ['staff'];

            // Initialize exam queries
            $student_exam_list = collect();
            $staff_exam_list = collect();

            // if (empty($slugs) || in_array('student', $slugs)) {
            //     $student_exam_list = ExamModel::where('branch_id', $branch_id)
            //         ->where('status', '!=', 2);
            // }
            if (empty($slugs) || in_array('staff', $slugs)) {
                $staff_exam_list = ManageExamModel::where('branch_id', $branch_id)
                    ->where('status', '!=', 2);
            }

            // Filter selected exams
            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $student_ids = [];
                $staff_ids = [];
                foreach ($search_lead_src_fill as $id) {
                    // if (strpos($id, 'student_') === 0) $student_ids[] = str_replace('student_', '', $id);
                    if (strpos($id, 'staff_') === 0) $staff_ids[] = str_replace('staff_', '', $id);
                }
                // if (!empty($student_ids) && (empty($slugs) || in_array('student', $slugs))) {
                //     $student_exam_list->whereIn('sno', $student_ids);
                // }
                if (!empty($staff_ids) && (empty($slugs) || in_array('staff', $slugs))) {
                    $staff_exam_list->whereIn('sno', $staff_ids);
                }
            }

            // Fetch exams
            // $student_exam_list = (empty($slugs) || in_array('student', $slugs))
            //     ? $student_exam_list->orderBy('exam_name')->get() : collect();
            $staff_exam_list = (empty($slugs) || in_array('staff', $slugs))
                ? $staff_exam_list->orderBy('exam_name')->get() : collect();

            // Map exams
            // $studentMapped = $student_exam_list->mapWithKeys(fn($e) => ['student_'.$e->sno => $e->exam_name])->toArray();
            $staffMapped = $staff_exam_list->mapWithKeys(fn($e) => ['staff_'.$e->sno => $e->exam_name])->toArray();

            $leadTypesMapped = ['staff' => $staffMapped];
            $leadTypes_keys = ['staff' => array_keys($staffMapped)];
            $leadTypes_list = array_values($staffMapped);

            // Days in month (restrict to today if current month)
            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);
            if ($today_year == $year && $today_month == $Month) $daysInMonth = (int)$today;
            $days = range(1, $daysInMonth);

            // Initialize data containers
            $leadData = [];
            $preleadData = [];
            $sourceTotals = [];
            $dayTotals = [];
            $sourceTrends = [];
            $grandTotalAll = 0;

            foreach ($leadTypesMapped as $type => $exams) {
                foreach ($exams as $examId => $examName) {
                    foreach ($months as $monthNum => $monthName) {
                        // Example: random numbers; replace with real DB counts

                        $count = (int)($result['monthly'][$year][$monthNum][$examId] ?? 0);
                        
                        $leadData[$type][$examId][$monthNum] = $count;

                        $sourceTotals[$examId] = ($sourceTotals[$examId] ?? 0) + $count;
                        $dayTotals[$monthNum] = ($dayTotals[$monthNum] ?? 0) + $count;
                        $grandTotalAll += $count;

                        $sourceTrends[$type][$examId][$monthNum] = $count;

                        $prevMonth = 0;
                        $prevYear = 0;

                        $day_query = false;

                        if ($monthNum == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                        }else if($monthNum != 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$monthNum - 1;
                        }
                        
                        $pre_count = isset($result['monthly'][$prevYear][$prevMonth][$examId]) ? (int) $result['monthly'][$prevYear][$prevMonth][$examId] : 0;

                        $preleadData[$type][$examId][$prevMonth] = (int)$pre_count;
                    }
                }
            }

            // Generate chart colors
            // $line_stu_MonthColors = $this->generateLeadSourceAttractiveColorsNew($studentMapped);
            $line_staff_MonthColors = $this->generateLeadSourceAttractiveColorsNew($staffMapped);
            $pie_MonthColors = [];

            return response()->json([
                'slugs' => $slugs,
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'leadTypes' => $leadTypesMapped,
                'leadTypes_keys' => $leadTypes_keys,
                'leadTypes_list' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'sourceTrends' => $sourceTrends,
                // 'line_MonthColors' => $line_stu_MonthColors,
                'line_staff_MonthColors' => $line_staff_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
                // 'student_exam_count' => $student_exam_list->count(),
                'staff_exam_count' => $staff_exam_list->count(),
                'order_list' => $order_list,
                'currentMonth' => (int)date('n'),
                'currentYear' => (int)date('Y'),
                'currentDay' => (int)date('j'),
                'year' => $year,
                'daysInMonth' => $daysInMonth,
                'month' => $Month,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load exam completion data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function exam_completed_monthly()
    {
        // Days (1–31 max)
        $days = range(1, 31);

        // Months
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.other_report.exam_completed_monthly_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function ExamCompletedMonthData(Request $request)
    {
        try {
            $selected_year = $request->year;
            $selected_month = $request->month;

            // Accept multiple slugs (array or comma-separated string)
            $slugs = collect($request->slugs)
                ->when(is_string($request->slugs), fn($c) => collect(explode(',', $request->slugs)))
                ->map(fn($s) => strtolower(trim($s)))
                ->filter()
                ->unique()
                ->values()
                ->toArray();

            $search_lead_src_fill = $request->search_lead_src_fill ?? [];
            // $is_existing_val = (int)($request->is_existing_val ?? 2);

            // Validate year/month
            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = "{$selected_year}-{$monthFormatted}-01";
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user();
            $branch_id = $user->branch_id;

            $result = $this->GetExamDetails($branch_id);

            $order_list = ['staff'];

            // Initialize exam queries
            // $student_exam_list = collect();
            $staff_exam_list = collect();

            // if (empty($slugs) || in_array('student', $slugs)) {
            //     $student_exam_list = ExamModel::where('branch_id', $branch_id)
            //         ->where('status', '!=', 2);
            // }
            if (empty($slugs) || in_array('staff', $slugs)) {
                $staff_exam_list = ManageExamModel::where('branch_id', $branch_id)
                    ->where('status', '!=', 2);
            }

            // Filter selected exams
            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $student_ids = [];
                $staff_ids = [];
                foreach ($search_lead_src_fill as $id) {
                    // if (strpos($id, 'student_') === 0) $student_ids[] = str_replace('student_', '', $id);
                    if (strpos($id, 'staff_') === 0) $staff_ids[] = str_replace('staff_', '', $id);
                }
                // if (!empty($student_ids) && (empty($slugs) || in_array('student', $slugs))) {
                //     $student_exam_list->whereIn('sno', $student_ids);
                // }
                if (!empty($staff_ids) && (empty($slugs) || in_array('staff', $slugs))) {
                    $staff_exam_list->whereIn('sno', $staff_ids);
                }
            }

            // Fetch exams
            // $student_exam_list = (empty($slugs) || in_array('student', $slugs))
            //     ? $student_exam_list->orderBy('exam_name')->get() : collect();
            $staff_exam_list = (empty($slugs) || in_array('staff', $slugs))
                ? $staff_exam_list->orderBy('exam_name')->get() : collect();

            // Map exams
            // $studentMapped = $student_exam_list->mapWithKeys(fn($e) => ['student_'.$e->sno => $e->exam_name])->toArray();
            $staffMapped = $staff_exam_list->mapWithKeys(fn($e) => ['staff_'.$e->sno => $e->exam_name])->toArray();

            $leadTypesMapped = ['staff' => $staffMapped];
            $leadTypes_keys = ['staff' => array_keys($staffMapped)];
            $leadTypes_list = array_values($staffMapped);

            // Days in month (restrict to today if current month)
            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);
            if ($today_year == $year && $today_month == $Month) $daysInMonth = (int)$today;
            $days = range(1, $daysInMonth);

            // Initialize data containers
            $leadData = [];
            $preleadData = [];
            $sourceTotals = [];
            $dayTotals = [];
            $sourceTrends = [];
            $grandTotalAll = 0;

            foreach ($leadTypesMapped as $type => $exams) {
                foreach ($exams as $examId => $examName) {
                    foreach ($days as $day) {
                        // Example: random numbers; replace with real DB counts

                        $count = (int)($result['daily'][$year][$Month][$day][$examId] ?? 0);

                        $leadData[$type][$examId][$day] = $count;

                        $sourceTotals[$examId] = ($sourceTotals[$examId] ?? 0) + $count;
                        $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;
                        $grandTotalAll += $count;

                        $sourceTrends[$type][$examId][$day] = $count;

                        $prevMonth = 0;
                        $prevYear = 0;
                        $prevDay = 0;

                        $day_query = false;

                        if ((int)$Month == 1 && $day == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }else if($day == 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$Month - 1;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }
                        
                        $pre_count = isset($result['daily'][$prevYear][$prevMonth][$prevDay][$examId]) ? (int) $result['daily'][$prevYear][$prevMonth][$prevDay][$examId] : 0;

                        $preleadData[$type][$examId][$prevDay] = (int)$pre_count;
                    }
                }
            }

            // Generate chart colors
            // $line_stu_MonthColors = $this->generateLeadSourceAttractiveColorsNew($studentMapped);
            $line_staff_MonthColors = $this->generateLeadSourceAttractiveColorsNew($staffMapped);
            $pie_MonthColors = [];

            return response()->json([
                'slugs' => $slugs,
                'days' => $days,
                'leadTypes' => $leadTypesMapped,
                'leadTypes_keys' => $leadTypes_keys,
                'leadTypes_list' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'sourceTrends' => $sourceTrends,
                // 'line_MonthColors' => $line_stu_MonthColors,
                'line_staff_MonthColors' => $line_staff_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
                // 'student_exam_count' => $student_exam_list->count(),
                'staff_exam_count' => $staff_exam_list->count(),
                'order_list' => $order_list,
                'currentMonth' => (int)date('n'),
                'currentYear' => (int)date('Y'),
                'currentDay' => (int)date('j'),
                'year' => $year,
                'daysInMonth' => $daysInMonth,
                'month' => $Month,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load exam completion data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    
    public function staff_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.other_report.staff_yr_list', compact(
            'currentMonth', 'currentYear','months','short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function StaffYearData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year,2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetStaffDetails($branch_id,$is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $query = DepartmentModel::where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'department_name')->orderBy('department_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->department_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;

            $days = range(1, 31);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($months as $monthNum => $monthName) {
                    
                    $paymentSums = isset($result['monthly'][$lead_type_id]) && !empty($result['monthly'][$lead_type_id]) ? $result['monthly'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$monthNum]['staff_count']) ? (int) $paymentSums[$year][$monthNum]['staff_count'] : 0;

                    $leadData[$monthNum][$leadType] = $count;

                    $monthTotals[$monthNum] = ($monthTotals[$monthNum] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;

                    if ((int)$monthNum == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                    }else if((int)$monthNum != 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$monthNum - 1;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth]['staff_count']) ? (int) $paymentSums[$prevYear][$prevMonth]['staff_count'] : 0;

                    $preleadData[$prevMonth][$leadType] = $pre_count;

                    // $monthTotals[$day] = $dayTotal;
                }
                
                if (!isset($sourceTotals[$leadType])) $sourceTotals[$leadType] = 0;
                
                $sourceTotals[$leadType] = isset($leadData[$lastMonth][$leadType]) ? (int) $leadData[$lastMonth][$leadType] : 0;
                
                $grandTotalAll += $sourceTotals[$leadType] ?? 0;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$leadType] ?? 0;
                }
                $sourceTrends[$leadType] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Staff data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function staff_monthly()
    {
        // Days (1–31 max)
        $days = range(1, 31);

        // Months
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.other_report.staff_monthly_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function StaffMonthData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetStaffDetails($branch_id,$is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $query = DepartmentModel::where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'department_name')->orderBy('department_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->department_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;
            

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($days as $day) {
                    
                    $paymentSums = isset($result['daily'][$lead_type_id]) && !empty($result['daily'][$lead_type_id]) ? $result['daily'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$Month][$day]['staff_count']) ? (int) $paymentSums[$year][$Month][$day]['staff_count'] : 0;

                    $leadData[$day][$leadType] = $count;

                    $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    $day_query = false;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay]['staff_count']) ? (int) $paymentSums[$prevYear][$prevMonth][$prevDay]['staff_count'] : 0;

                    $preleadData[$prevDay][$leadType] = $pre_count;

                    // $dayTotals[$day] = $dayTotal;
                }
                
                if (!isset($sourceTotals[$leadType])) $sourceTotals[$leadType] = 0;
                
                $sourceTotals[$leadType] = isset($leadData[$daysInMonth][$leadType]) ? (int) $leadData[$daysInMonth][$leadType] : 0;
                
                $grandTotalAll += $sourceTotals[$leadType] ?? 0;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$leadType] ?? 0;
                }
                $sourceTrends[$leadType] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Staff data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    private function GetEventsDetails(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $dailyData   = [];
            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];

            $event_list = EventModel::select('et_event.*')
                ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
                ->whereNotIn('et_event.status', [2,3]);

            if ($branch_id != 0) {
                $event_list->where('et_event.branch_id', $branch_id);
            }
            
            $job_list = $event_list->orderBy('et_event.sno', 'desc')->distinct()->get();

            // --- Loop staff for daily counts ---
            foreach ($job_list as $job) {
                
                if (empty($job->event_date)) continue;

                $loopDate = date('Y-m-d', strtotime($job->event_date));

                $y = (int) date('Y', strtotime($loopDate));
                $m = (int) date('n', strtotime($loopDate));
                $d = (int) date('j', strtotime($loopDate));

                $yearlyData[$y]['event_count'] = ($yearlyData[$y]['event_count'] ?? 0) + 1;
                $monthlyData[$y][$m]['event_count'] = ($monthlyData[$y][$m]['event_count'] ?? 0) + 1;
                $dailyData[$y][$m][$d]['event_count'] = ($dailyData[$y][$m][$d]['event_count'] ?? 0) + 1;
                $years[$y] = $y;
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyDetails: " . $e->getMessage());
            return null;
        }
    }

    public function GetExamDetails(int $branch_id)
    {
        try {
            
            // ✅ Validate branch_id properly
            if (empty($branch_id) || !is_numeric($branch_id) || (int)$branch_id <= 0) {
                throw new \InvalidArgumentException("Valid Branch ID is required");
            }

            $currentDate = date('Y-m-d');

            /** ------------------ INITIALIZE STRUCTURES ------------------ */
            $yearlyData = [];
            $monthlyData = [];
            $dailyData = [];

            /** ------------------ STUDENT EXAM DATA ------------------ */
            // try {
                
            //     $student_exam_list = DB::table('za_exam')
            //         ->where('branch_id', $branch_id)
            //         ->where('status', '!=', 2)
            //         ->get();

            //     foreach ($student_exam_list as $student_exam) {

            //         $student_exam_status = DB::table('za_exam_process')
            //             ->where('branch_id', $branch_id)
            //             ->where('exam_id', $student_exam->sno)
            //             ->where('status', 2)
            //             ->get();

            //         foreach ($student_exam_status as $exam_status) {
            //             $date = date('Y-m-d', strtotime($exam_status->updated_at));
            //             $y = (int) date('Y', strtotime($date));
            //             $m = (int) date('n', strtotime($date));
            //             $d = (int) date('j', strtotime($date));

            //             // ✅ Ensure counters are initialized correctly
            //             if (!isset($yearlyData[$y]['student_'.$student_exam->sno])) {
            //                 $yearlyData[$y]['student_'.$student_exam->sno] = 0;
            //             }
            //             if (!isset($monthlyData[$y][$m]['student_'.$student_exam->sno])) {
            //                 $monthlyData[$y][$m]['student_'.$student_exam->sno] = 0;
            //             }
            //             if (!isset($dailyData[$y][$m][$d]['student_'.$student_exam->sno])) {
            //                 $dailyData[$y][$m][$d]['student_'.$student_exam->sno] = 0;
            //             }

            //             // ✅ Increment counts properly
            //             $yearlyData[$y]['student_'.$student_exam->sno]++;
            //             $monthlyData[$y][$m]['student_'.$student_exam->sno]++;
            //             $dailyData[$y][$m][$d]['student_'.$student_exam->sno]++;
            //         }
            //     }

            // } catch (\Throwable $e) {
            //     \Log::error("Error fetching exam data: " . $e->getMessage());
            // }
            
            try {

                $staff_exam_list = DB::table('et_manage_exam')
                    ->where('branch_id', $branch_id)
                    ->where('status', '!=', 2)
                    ->get();

                foreach ($staff_exam_list as $staff_exam) {

                    $staff_exam_status = DB::table('et_exam_process')
                        ->where('branch_id', $branch_id)
                        ->where('exam_id', $staff_exam->sno)
                        ->where('status', 2)
                        ->get();

                    foreach ($staff_exam_status as $exam_status) {

                        $date = date('Y-m-d', strtotime($exam_status->updated_at));
                        $y = (int) date('Y', strtotime($date));
                        $m = (int) date('n', strtotime($date));
                        $d = (int) date('j', strtotime($date));

                        // ✅ Ensure counters are initialized correctly
                        if (!isset($yearlyData[$y]['staff_'.$staff_exam->sno])) {
                            $yearlyData[$y]['staff_'.$staff_exam->sno] = 0;
                        }
                        if (!isset($monthlyData[$y][$m]['staff_'.$staff_exam->sno])) {
                            $monthlyData[$y][$m]['staff_'.$staff_exam->sno] = 0;
                        }
                        if (!isset($dailyData[$y][$m][$d]['staff_'.$staff_exam->sno])) {
                            $dailyData[$y][$m][$d]['staff_'.$staff_exam->sno] = 0;
                        }

                        // ✅ Increment counts properly
                        $yearlyData[$y]['staff_'.$staff_exam->sno]++;
                        $monthlyData[$y][$m]['staff_'.$staff_exam->sno]++;
                        $dailyData[$y][$m][$d]['staff_'.$staff_exam->sno]++;
                    }
                }

            } catch (\Throwable $e) {
                \Log::error("Error fetching exam data: " . $e->getMessage());
            }

            ksort($yearlyData);
            ksort($monthlyData);
            ksort($dailyData);

            /** ------------------ SUCCESS RESPONSE ------------------ */
            return [
                'status'  => true,
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_keys($yearlyData),
                'message' => 'Exam details fetched successfully.'
            ];

        } catch (\InvalidArgumentException $e) {
            \Log::warning("Invalid input: " . $e->getMessage());
            return [
                'status' => false,
                'error'  => 'Invalid input provided.',
                'details' => $e->getMessage()
            ];

        } catch (\Throwable $e) {
            \Log::error("Unexpected error in GetExamDetails: " . $e->getMessage());
            return [
                'status' => false,
                'error'  => 'An unexpected error occurred while fetching exam details.',
                'details' => $e->getMessage()
            ];
        }
    }

    private function GetMarketingActivityDetails(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $dailyData   = [];
            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];

            $event_list = MarketingModel::select('et_marketing.*')
                ->where('et_marketing.status', '!=', 2);

            if ($branch_id != 0) {
                $event_list->where('et_marketing.branch_id', $branch_id);
            }
            
            $job_list = $event_list->orderBy('et_marketing.sno', 'desc')->distinct()->get();

            // --- Loop staff for daily counts ---
            foreach ($job_list as $job) {
                
                if (empty($job->created_at)) continue;

                $loopDate = date('Y-m-d', strtotime($job->created_at));

                $y = (int) date('Y', strtotime($loopDate));
                $m = (int) date('n', strtotime($loopDate));
                $d = (int) date('j', strtotime($loopDate));

                $yearlyData[$y]['activity_count'] = ($yearlyData[$y]['activity_count'] ?? 0) + 1;
                $monthlyData[$y][$m]['activity_count'] = ($monthlyData[$y][$m]['activity_count'] ?? 0) + 1;
                $dailyData[$y][$m][$d]['activity_count'] = ($dailyData[$y][$m][$d]['activity_count'] ?? 0) + 1;
                $years[$y] = $y;
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetMarketingActivityDetails: " . $e->getMessage());
            return null;
        }
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }
    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }
    private function generateLeadSourceAttractiveColorsNew($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[$key] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }
    public function get_all_exam_list(Request $request)
    {
        try {
            $user = $request->user();
            $branch_id = $user->branch_id;

            // // 🧩 Get student exams
            // $student_exam_list = DB::table('za_exam')
            //     ->select('sno', 'exam_name')
            //     ->where('branch_id', $branch_id)
            //     ->where('status', '!=', 2)
            //     ->orderBy('exam_name', 'asc')
            //     ->get();

            // 🧩 Get staff exams
            $staff_exam_list = DB::table('et_manage_exam')
                ->select('sno', 'exam_name')
                ->where('branch_id', $branch_id)
                ->where('status', '!=', 2)
                ->orderBy('exam_name', 'asc')
                ->get();

            // 🧩 Format result as grouped options
            $data = [
                // [
                //     'option_group_name' => 'student',
                //     'options' => $student_exam_list
                // ],
                [
                    'option_group_name' => 'staff',
                    'options' => $staff_exam_list
                ]
            ];

            return response([
                'status'    => 200,
                'message'   => 'Exam list retrieved successfully.',
                'error_msg' => null,
                'data'      => $data
            ], 200);

        } catch (\Exception $e) {
            return response([
                'status'    => 500,
                'message'   => 'Failed to fetch exam list.',
                'error_msg' => $e->getMessage(),
                'data'      => []
            ], 500);
        }
    }

    private function GetStaffDetails(int $branch_id, int $is_existing_val = 2)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $dailyData   = [];
            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];

            // --- Fetch job positions ---
            $job_positions = DB::table('et_department')
            ->where('status', '!=', 2)
            ->get();

            foreach ($job_positions as $position) {

                // --- Fetch staff under this position ---
                $staff_list = DB::table('et_staff')
                    ->where('branch_id', $branch_id)
                    ->where('sno','>', 1)
                    ->where('department_id', $position->sno)
                    ->where(function($query) use ($currentYear, $currentMonth, $is_existing_val) {
                        if($is_existing_val == 2){
                            $query->where(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 4)
                                ->whereYear('notice_end_date', '>=', $currentYear)
                                ->whereMonth('notice_end_date', '>=', $currentMonth);
                            })
                            ->orWhere(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 5)
                                ->whereYear('updated_at', '>=', $currentYear)
                                ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 6)
                                ->whereYear('staff_last_date', '>=', $currentYear)
                                ->whereMonth('staff_last_date', '>=', $currentMonth);
                            })
                            ->orWhere(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 7)
                                ->whereYear('updated_at', '>=', $currentYear)
                                ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere('status', 0);
                        }else{
                            $query->whereNotIn('status', [1,2]);
                        }
                    })
                    ->orderBy('sno', 'desc')
                    ->get();

                // --- Loop staff for daily counts ---
                foreach ($staff_list as $staff) {
                    
                    if (empty($staff->date_of_joining)) continue;

                    $staffStart = date('Y-m-d', strtotime($staff->date_of_joining));

                    $staffEnd   = $currentDate;

                    $loopDate = $staffStart;

                    while ($loopDate <= $staffEnd) {

                        $y = (int) date('Y', strtotime($loopDate));
                        $m = (int) date('n', strtotime($loopDate));
                        $d = (int) date('j', strtotime($loopDate));

                        if (!isset($dailyData[$position->sno][$y][$m][$d])) {

                            $dailyData[$position->sno][$y][$m][$d] = [
                                'staff_count' => 0
                            ];
                        }

                        // --- Staff count ---
                        $dailyData[$position->sno][$y][$m][$d]['staff_count']++;
                        $years[$y] = $y;

                        $loopDate = date('Y-m-d', strtotime($loopDate . ' +1 day'));
                    }
                }
            }

            // --- Monthly aggregation including attendance ---
            foreach ($dailyData as $positionId => $yearsData) {
                foreach ($yearsData as $year => $months) {
                    foreach ($months as $month => $days) {
                        $lastDay = (int) date('t', strtotime("$year-$month-01"));
                        if ($year == $currentYear && $month == $currentMonth) {
                            $lastDay = (int) date('j', strtotime($currentDate));
                        }

                        $monthlyData[$positionId][$year][$month] = [
                            'staff_count' => $days[$lastDay]['staff_count'] ?? 0
                        ];
                    }
                }
            }

            // --- Yearly aggregation including attendance ---
            foreach ($monthlyData as $positionId => $yearsData) {

                foreach ($yearsData as $year => $months) {

                    $lastMonth = ($year == $currentYear)
                    ? $currentMonth
                    : max(array_keys($months));

                    $yearlyData[$positionId][$year] = [
                        'staff_count'          => $months[$lastMonth]['staff_count'] ?? 0
                    ];
                }
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyDetails: " . $e->getMessage());
            return null;
        }
    }

    public function get_other_report_department_list()
    {
        $LeadTypeModelList = DepartmentModel::where('status', '!=', 2)->orderBy('department_name', 'asc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $LeadTypeModelList
        ], 200);
    }
}
