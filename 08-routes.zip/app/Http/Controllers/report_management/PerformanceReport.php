<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\BusinessGoalSetModel;
use App\Models\ManageTargetModel;
use App\Models\PaymentModel;
use App\Models\TrainingModel;
use App\Models\TransactionModel;
use App\Models\StaffModel;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\CustomerModel;
use App\Models\IncentiveModel;
use App\Models\OldCustomerModel;
use App\Models\BranchModel;
use App\Models\StaffAttendanceModel;
use App\Models\BatchModel;
use App\Models\AttendanceModel;
use Carbon\Carbon;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Collection;

class PerformanceReport extends Controller
{
    public static $report_heading = 'Analysis';
    protected static $temp = [];

    public function index()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear, 2);

        $feedbacknavHtml = $this->generateNavHtml();

        return view('content.report_management.performance_report.production_yr_list', compact(
            'months',
            'short_months','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function ProductionYearlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int) $request->is_existing_val ?? 2;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetProductionPerDetails($branch_id, $search_lead_src_fill, $is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate = date('Y-m-d');
            $currentYear = (int) date('Y');
            $currentMonth = (int) date('n');

            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

            // Sort by staff_name
            uasort($leadTypesMapped, function ($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate = strtotime($staff['doj']);
                    $dojYear = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int) $year) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate = strtotime($staff['exist_date']);
                    $exitYear = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int) $year) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = isset($leadTypesMapped) && !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];
            $grandTotalAll = 0;

            $days = range(1, 31);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            // return $leadTypesMapped;

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {

                $exist_status = isset($leadType['exist_status']) ? $leadType['exist_status'] : false;
                $exist_date = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : '';
                $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;

                // ---------- Exit Staff Tracking ----------
                if ($exist_status) {
                    $exist_y = (int) date('Y', strtotime($exist_date));
                    $exist_m = (int) date('n', strtotime($exist_date));

                    while ($exist_m <= (int) $currentMonth) {
                        $exit_staff_details[$exist_y][$exist_m][$lead_type_id] = [
                            'exist_status' => true,
                            'exist_date' => null
                        ];
                        $exist_m++;
                    }

                    $exit_status_staffs[$lead_type_id] = $exist_status;
                }

                $dayTotal = 0;

                foreach ($months as $monthNum => $monthName) {

                    $paymentSums = isset($result['monthly'][$lead_type_id]) && !empty($result['monthly'][$lead_type_id]) ? $result['monthly'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$monthNum]['revenue']) ? $paymentSums[$year][$monthNum]['revenue'] : 0;
                    $earned_per = isset($paymentSums[$year][$monthNum]['production_percentage']) && ($paymentSums[$year][$monthNum]['production_percentage'] >= 100) ? 100 : ($paymentSums[$year][$monthNum]['production_percentage'] ?? 0);

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$monthNum][$lead_type_id] = $count;
                    $percentages[$lead_type_id][$monthNum] = $earned_per;

                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $monthTotals[$monthNum] = ($monthTotals[$monthNum] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;

                    if ((int) $monthNum == 1) {
                        $prevYear = (int) $year - 1;
                        $prevMonth = 12;
                    } else if ((int) $monthNum != 1) {
                        $prevYear = (int) $year;
                        $prevMonth = (int) $monthNum - 1;
                    }

                    $pre_count = isset($paymentSums[$prevYear][$prevMonth]['revenue']) ? $paymentSums[$prevYear][$prevMonth]['revenue'] : 0;

                    $preleadData[$prevMonth][$lead_type_id] = $pre_count;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int) $year) {
                            if ((int) $monthNum >= $doj_m) {
                                $doj_status = true;
                            }
                        } else if ($doj_y < (int) $year) {
                            $doj_status = true;
                        } else if ($doj_y > (int) $year) {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$year][$monthNum][$lead_type_id] = [
                        'doj_status' => $doj_status,
                    ];

                    // $monthTotals[$day] = $dayTotal;
                }


                $grandTotalAll += $dayTotal;

                // Calculate percentages
            }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'staff_details' => $leadTypesMapped,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'monthTotals' => $monthTotals,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int) $currentMonth,
                'currentYear' => (int) $currentYear,
                'currentDay' => (int) $currentDay,
                'Month' => (int) $Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int) $year,
                'yearShort' => (int) $yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function leave_percent_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear, 2);

        $feedbacknavHtml = $this->generateNavHtml();

        return view('content.report_management.performance_report.leave_percent_yr_list', compact(
            'months',
            'short_months','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function LeavePerYearlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int) ($request->is_existing_val ?? 2);

            // --- Validate and determine year ---
            $filterDate = ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year))
                ? $selected_year . '-01-01'
                : now()->format('Y-01-01');

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user();
            $branch_id = $user->branch_id;

            // --- Fetch Faculty Attendance Data ---
            $result = $this->GetFacultyAttendanceDetails($branch_id, $search_lead_src_fill, $is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get faculty data'], 500);
            }

            // return $result;

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];
            $deptSummary = $result['dept_summary'] ?? [];

            // --- Initialize output containers ---
            $leadData = [];       // monthly count per staff
            $preleadData = [];    // previous month data
            $percentages = [];    // placeholder for percentages (attendance ratio)
            $sourceTotals = [];   // total per staff
            $deptTotals = [];   // total per staff
            $monthTotals = [];    // total per month
            $sourceTrends = [];   // line chart data
            $grandTotalAll = 0;

            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];

            // --- Flatten Department + Staff Structure ---
            $staffDetails = [];
            foreach ($deptSummary as $dept_id => $deptInfo) {
                foreach ($deptInfo['staff_list'] as $staff) {

                    $exist_status = isset($staff['exist_status']) ? $staff['exist_status'] : false;
                    $exist_date = !empty($staff['exist_date']) ? date('Y-m-d', strtotime($staff['exist_date'])) : '';

                    // ---------- Exit Staff Tracking ----------
                    if ($exist_status) {
                        $exist_y = (int) date('Y', strtotime($exist_date));
                        $exist_m = (int) date('n', strtotime($exist_date));

                        while ($exist_m <= (int) $today_month) {
                            $exit_staff_details[$exist_y][$exist_m][$staff['staff_id']] = [
                                'exist_status' => true,
                                'exist_date' => null
                            ];
                            $exist_m++;
                        }

                        $exit_status_staffs[$staff['staff_id']] = $exist_status;
                    }

                    $staffDetails[$staff['staff_id']] = [
                        'staff_name' => $staff['staff_name'],
                        'department_id' => $deptInfo['department_id'],
                        'doj' => $staff['doj']
                    ];
                }
            }

            // --- Sort staff alphabetically ---
            uasort($staffDetails, fn($a, $b) => strcmp($a['staff_name'], $b['staff_name']));
            $staffIds = array_keys($staffDetails);

            // --- Build Monthly Dataset ---
            foreach ($staffIds as $staff_id) {

                $staff_info = $staffDetails[$staff_id];
                $dept_id = $staff_info['department_id'];
                $doj = !empty($staff_info['doj']) ? date('Y-m-d', strtotime($staff_info['doj'])) : null;

                foreach ($months as $monthNum => $monthName) {

                    $monthVal = $monthlyData[$dept_id][$staff_id][$year][$monthNum]['total_attendance'] ?? 0;

                    $leadData[$dept_id][$staff_id][$monthNum] = $monthVal;

                    $sourceTotals[$dept_id][$staff_id] = ($sourceTotals[$dept_id][$staff_id] ?? 0) + $monthVal;

                    $deptTotals[$dept_id] = ($deptTotals[$dept_id] ?? 0) + $monthVal;

                    $monthTotals[$dept_id][$monthNum] = ($monthTotals[$dept_id][$monthNum] ?? 0) + $monthVal;

                    // --- Previous month data ---
                    $prevMonth = ($monthNum == 1) ? 12 : $monthNum - 1;
                    $prevYear = ($monthNum == 1) ? $year - 1 : $year;
                    $preVal = $monthlyData[$dept_id][$staff_id][$prevYear][$prevMonth]['total_attendance'] ?? 0;
                    $preleadData[$dept_id][$staff_id][$prevMonth] = $preVal;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = true;

                    // if ($doj) {

                    //     $doj_y = (int) date('Y', strtotime($doj));
                    //     $doj_m = (int) date('n', strtotime($doj));

                    //     // Case 1: DOJ is this year
                    //     if ($doj_y === (int) $year) {
                    //         if ((int) $monthNum >= $doj_m) {
                    //             $doj_status = true;
                    //         }
                    //     } else if ($doj_y < (int) $year) {
                    //         $doj_status = true;
                    //     } else if ($doj_y > (int) $year) {
                    //         $doj_status = false;
                    //     }
                    // }

                    $exit_staff_doj_details[$year][$monthNum][$staff_id] = [
                        'doj_status' => $doj_status,
                    ];
                }
            }

            // --- Source Trends for Graphs (month-wise) ---
            foreach ($staffIds as $staff_id) {

                $staff_info = $staffDetails[$staff_id];
                $dept_id = $staff_info['department_id'];

                $trend = [];
                foreach ($months as $monthNum => $monthName) {

                    $daysInMonth = $this->getDaysWithoutSundays($monthNum, $year);

                    $percentage_value = ($daysInMonth > 0)
                        ? round((($leadData[$dept_id][$staff_id][$monthNum] ?? 0) / $daysInMonth) * 100, 2)
                        : 0;

                    $percentages[$dept_id][$staff_id][$monthNum] = $monthlyData[$dept_id][$staff_id][$year][$monthNum]['present_percent'] ?? 0;

                    $trend[] = $monthlyData[$dept_id][$staff_id][$year][$monthNum]['present_percent'] ?? 0;
                }

                $sourceTrends[$staff_id] = $trend;
            }

            $line_MonthColors = $this->generateAttractiveColors($staffIds);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors)
                ? array_values($line_MonthColors)
                : [];

            $chartDetails = [];

            foreach ($deptSummary as $deptInfo) {

                $dept_id = $deptInfo['department_id'] ?? 0;
                $department_name = $deptInfo['department_name'] ?? 'Unknown';

                // Initialize department array if not set
                if (!isset($chartDetails[$dept_id])) {
                    $chartDetails[$dept_id] = [
                        'department_name' => $department_name,
                        'staff_ids' => [],
                        'staff_names' => [],
                        'staff_shot_names' => [],
                        'staff_colors' => [],
                        'staff_pre_per' => [],
                    ];
                }

                foreach ($deptInfo['staff_list'] as $staff) {
                    $staff_id = $staff['staff_id'];
                    $staff_name = $staff['staff_name'] ?? 'Unknown';
                    $staff_position = $staff['staff_position'] ?? 'Unknown';

                    $chartDetails[$dept_id]['staff_ids'][] = $staff_id;
                    $chartDetails[$dept_id]['staff_names'][] = $staff_name . ' (' . $staff_position . ')';
                    $chartDetails[$dept_id]['staff_shot_names'][] = $staff_name;
                    $chartDetails[$dept_id]['staff_colors'][] = $line_MonthColors[$staff_id] ?? '#1e90ff';
                    $chartDetails[$dept_id]['staff_pre_per'][] = $yearlyData[$dept_id][$staff_id][$year]['present_percent'] ?? 0;
                }
            }

            // --- Final Response ---
            return response()->json([
                'months' => $months,
                'short_months' => $short_months,
                'leadTypes' => $staffIds,
                'staff_details' => $staffDetails,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'deptTotals' => $deptTotals,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int) date('n'),
                'currentYear' => (int) date('Y'),
                'currentDay' => (int) date('j'),
                'Month' => (int) $Month,
                'sourceTrends' => $sourceTrends,
                'year' => (int) $year,
                'yearShort' => (int) $yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
                'dept_summary' => $deptSummary,
                'chartDetails' => $chartDetails,
                'total_departments' => count($deptSummary)
            ]);

        } catch (\Exception $e) {
            \Log::error("Error in FacultyYearlyData: " . $e->getMessage());
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function goalset_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        $feedbacknavHtml = $this->generateNavHtml();

        return view('content.report_management.performance_report.goalset_yr_list', compact(
            'months','short_months','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function GoalsetYearlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int) ($request->is_existing_val ?? 2);

            // --- Validate and determine year ---
            $filterDate = ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year))
                ? $selected_year . '-01-01'
                : now()->format('Y-01-01');

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user();
            $branch_id = $user->branch_id;

            // --- Fetch Faculty Attendance Data ---
            $result = $this->GetFacultyAchievementDetails($branch_id, $search_lead_src_fill, $is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get faculty data'], 500);
            }

            // return $result;

            // $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];
            $deptSummary = $result['dept_summary'] ?? [];

            // --- Initialize output containers ---
            $leadData = [];       // monthly count per staff
            $preleadData = [];    // previous month data
            $percentages = [];    // placeholder for percentages (attendance ratio)
            $sourceTotals = [];   // total per staff
            $deptTotals = [];   // total per staff
            $monthTotals = [];    // total per month
            $sourceTrends = [];   // line chart data
            $grandTotalAll = 0;

            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];

            if(!empty($deptSummary)) {
                foreach ($deptSummary as $dept_id => &$deptInfo) {

                    $deptInfo['staff_list'] = $deptInfo['staff_list']
                        ->filter(function ($staff) use ($year) {

                            $keep = true;

                            /* ========= DOJ FILTER ========= */
                            if (!empty($staff['doj'])) {
                                $dojDate = strtotime($staff['doj']);
                                $dojYear = (int) date('Y', $dojDate);

                                if ($dojYear > (int)$year) {
                                    $keep = false;
                                }
                            }

                            /* ========= EXIT FILTER ========= */
                            if (!empty($staff['exist_status']) && !empty($staff['exist_date'])) {
                                $exitDate = strtotime($staff['exist_date']);
                                $exitYear = (int) date('Y', $exitDate);

                                if ($exitYear < (int)$year) {
                                    $keep = false;
                                }
                            }

                            return $keep;
                    })
                    ->values(); // reindex collection

                    $deptInfo['staff_count'] = isset($deptInfo['staff_list']) && !empty($deptInfo['staff_list']) ? $deptInfo['staff_list']->count() : 0;
                }
                unset($deptInfo);
            }


            // return $deptSummary;

            // --- Flatten Department + Staff Structure ---
            $staffDetails = [];
            foreach ($deptSummary as $dept_id => $deptInfo) {
                foreach ($deptInfo['staff_list'] as $staff) {
                    $staffDetails[$staff['staff_id']] = [
                        'staff_name' => $staff['staff_name'],
                        'department_id' => $deptInfo['department_id'],
                        'doj' => $staff['doj'],
                        'exist_status' => $staff['exist_status'],
                        'exist_date' => $staff['exist_date']
                    ];
                }
            }

            // --- Sort staff alphabetically ---
            uasort($staffDetails, fn($a, $b) => strcmp($a['staff_name'], $b['staff_name']));
            $staffIds = array_keys($staffDetails);

            // --- Build Monthly Dataset ---
            foreach ($staffIds as $staff_id) {

                $staff_info = $staffDetails[$staff_id];
                $dept_id = $staff_info['department_id'];

                foreach ($months as $monthNum => $monthName) {

                    $doj = !empty($staff_info['doj']) ? date('Y-m-d', strtotime($staff_info['doj'])) : null;
                    // ---------- Exit Staff Tracking ----------
                    $exist_status = isset($staff_info['exist_status']) ? (bool)$staff_info['exist_status'] : false;
                    $exist_date   = !empty($staff_info['exist_date']) ? date('Y-m-d', strtotime($staff_info['exist_date'])) : null;

                    if ($exist_status && $exist_date) {

                        $exist_y = (int) date('Y', strtotime($exist_date));
                        $exist_m = (int) date('n', strtotime($exist_date));
                        $exist_d = (int) date('j', strtotime($exist_date));

                        // If exit is before selected month/year → mark as inactive
                        if ($exist_y > (int)$year || ($exist_y === (int)$year && $exist_m > (int)$monthNum)) {
                            $exist_status = false;
                        }
                        // If same month but exited before current month → inactive for remaining days
                        elseif ($exist_y === (int)$year && $exist_m > (int)$monthNum) {
                            $exist_status = false;
                        }

                        $exit_staff_details[$monthNum][$staff_id] = [
                            'exist_status' => $exist_status,
                            'exist_date'   => $exist_date
                        ];

                        $exit_status_staffs[$staff_id] = $exist_status;
                    }

                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int)$year) {
                            if ((int)$monthNum >= $doj_m) {
                                $doj_status = true;
                            }
                        }elseif ($doj_y < $year) {
                            $doj_status = true;
                        }else {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$monthNum][$staff_id] = [
                        'doj_status' => $doj_status,
                    ];

                    $monthVal = $monthlyData[$dept_id][$staff_id][$year][$monthNum]['status_10x'] ?? 0;
                    $goal_status = $monthlyData[$dept_id][$staff_id][$year][$monthNum]['goal_status'] ?? 0;

                    $leadData[$dept_id][$staff_id][$monthNum] = [
                        '10x_status'=>$monthVal,
                        'goal_status'=>$goal_status
                    ];

                    $sourceTotals[$dept_id][$staff_id] = ($sourceTotals[$dept_id][$staff_id] ?? 0) + $monthVal;

                    $deptTotals[$dept_id] = ($deptTotals[$dept_id] ?? 0) + $monthVal;
                    $monthTotals[$dept_id][$monthNum] = ($monthTotals[$dept_id][$monthNum] ?? 0) + $monthVal;

                    // --- Previous month data ---
                    // $prevMonth = ($monthNum == 1) ? 12 : $monthNum - 1;
                    // $prevYear = ($monthNum == 1) ? $year - 1 : $year;
                    // $preVal = $monthlyData[$dept_id][$staff_id][$prevYear][$prevMonth]['total_attendance'] ?? 0;
                    // $preleadData[$dept_id][$staff_id][$prevMonth] = $preVal;
                }
            }

            // --- Source Trends for Graphs (month-wise) ---
            foreach ($staffIds as $staff_id) {

                $staff_info = $staffDetails[$staff_id];
                $dept_id = $staff_info['department_id'];

                $trend = [];
                foreach ($months as $monthNum => $monthName) {

                    // $daysInMonth = $this->getDaysWithoutSundays($monthNum, $year);

                    // $percentage_value = ($daysInMonth > 0)
                    // ? round((($leadData[$dept_id][$staff_id][$monthNum] ?? 0) / $daysInMonth) * 100, 2)
                    // : 0;

                    // $percentages[$dept_id][$staff_id][$monthNum] = $monthlyData[$dept_id][$staff_id][$year][$monthNum]['present_percent'] ?? 0;

                    $trend[] = $monthlyData[$dept_id][$staff_id][$year][$monthNum]['status_10x'] ?? 0;
                }

                $sourceTrends[$staff_id] = $trend;
            }

            // --- Compute Grand Total ---
            // $grandTotalAll = array_sum($sourceTotals);

            // --- Generate colors for charts ---
            $line_MonthColors = $this->generateAttractiveColors($staffIds);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors)
                ? array_values($line_MonthColors)
                : [];


            $chartDetails = [];

            foreach ($deptSummary as $deptInfo) {

                $dept_id = $deptInfo['department_id'] ?? 0;
                $department_name = $deptInfo['department_name'] ?? 'Unknown';

                // Initialize department array if not set
                if (!isset($chartDetails[$dept_id])) {
                    $chartDetails[$dept_id] = [
                        'department_name' => $department_name,
                        'staff_ids'     => [],
                        'staff_names'     => [],
                        'staff_shot_names' => [],
                        'staff_colors'    => [],
                        'staff_pre_per'   => [],
                    ];
                }

                foreach ($deptInfo['staff_list'] as $staff) {

                    $staff_id   = $staff['staff_id'];
                    $staff_name = $staff['staff_name'] ?? 'Unknown';
                    $staff_position = $staff['staff_position'] ?? 'Unknown';

                    $chartDetails[$dept_id]['staff_ids'][]   = $staff_id;
                    $chartDetails[$dept_id]['staff_names'][]   = $staff_name.' ('.$staff_position.')';
                    $chartDetails[$dept_id]['staff_shot_names'][]   = $staff_name;
                    $chartDetails[$dept_id]['staff_colors'][]  = $line_MonthColors[$staff_id] ?? '#1e90ff';
                    $chartDetails[$dept_id]['staff_pre_per'][] = $sourceTotals[$dept_id][$staff_id] ?? 0;
                }
            }

            // --- Final Response ---
            return response()->json([
                'months'         => $months,
                'short_months'   => $short_months,
                'leadTypes'      => $staffIds,
                'staff_details'  => $staffDetails,
                'leadData'       => $leadData,
                'preleadData'    => $preleadData,
                'percentages'    => $percentages,
                'sourceTotals'   => $sourceTotals,
                'deptTotals'   => $deptTotals,
                'monthTotals'    => $monthTotals,
                'grandTotalAll'  => $grandTotalAll,
                'currentMonth'   => (int) date('n'),
                'currentYear'    => (int) date('Y'),
                'currentDay'     => (int) date('j'),
                'Month'          => (int) $Month,
                'sourceTrends'   => $sourceTrends,
                'year'           => (int) $year,
                'yearShort'      => (int) $yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors'  => $pie_MonthColors,
                'dept_summary'   => $deptSummary,
                'chartDetails'   => $chartDetails,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'total_departments' => count($deptSummary)
            ]);

        } catch (\Exception $e) {
            \Log::error("Error in FacultyYearlyData: " . $e->getMessage());
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    private function GetProductionPerDetails(int $branch_id, $search_lead_src_fill = null, int $is_existing_val = 2)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate = date('Y-m-d');
            $currentYear = (int) date('Y');
            $currentMonth = (int) date('n');

            $staff_details = [];
            $dailyData = [];
            $monthlyData = [];
            $yearlyData = [];
            $years = [];

            // --- Fetch job positions ---
            $job_positions = DB::table('et_job_position')
                ->where('department_id', 2)
                ->where('status', '!=', 2)
                ->get();

            $job_positionsIds = $job_positions->pluck('sno')->toArray();

            // --- Staff list ---
            $staff_query = DB::table('et_staff')
                ->join('et_user_role', 'et_user_role.sno', '=', 'et_staff.role_id')
                ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
                ->where('et_staff.branch_id', $branch_id)
                ->whereIn('et_staff.position_role', $job_positionsIds);

            // Active/existing staff logic
            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 4)
                            ->whereYear('et_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('et_staff.notice_end_date', '>=', $currentMonth);
                    })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 5)
                                ->whereYear('et_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 6)
                                ->whereYear('et_staff.staff_last_date', '>=', $currentYear)
                                ->whereMonth('et_staff.staff_last_date', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 7)
                                ->whereYear('et_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere('et_staff.status', 0);
                });
            } else {
                $staff_query->where('et_staff.status', '!=', 2);
            }

            // Search filter
            if (!empty($search_lead_src_fill)) {
                $staff_query->whereIn('et_staff.sno', $search_lead_src_fill);
            }

            // Fetch staff
            $staff_list = $staff_query->orderBy('staff_name', 'asc')->get([
                'et_staff.*',
                'et_user_role.role_name',
                'et_job_position.job_position_name'
            ]);


            // --- Loop staff for daily counts ---
            foreach ($staff_list as $staff) {

                if (!isset($staff_details[$staff->sno])) {
                    $staff_details[$staff->sno] = [];
                }

                $doj = !empty($staff->date_of_joining) ? $staff->date_of_joining : null;
                $exist_date = match ($staff->status) {
                    4 => $staff->notice_end_date,
                    5 => $staff->updated_at,
                    6 => $staff->staff_last_date,
                    7 => $staff->updated_at,
                    default => null,
                };

                $staff_details[$staff->sno] = [
                    'staff_name' => $staff->staff_name ?? 'None',
                    'staff_position' => $staff->job_position_name ?: ($staff->role_name ?: 'None'),
                    'staff_full_name' => $staff->staff_name . ' (' . $staff->job_position_name ?: ($staff->role_name ?: 'None') . ')' ?? 'None',
                    'doj' => $doj,
                    'exist_status' => in_array($staff->status, [4, 5, 6, 7]),
                    'exist_date' => $exist_date,
                ];
            }

            $result = $this->get_faculty_revenue_data(null,$branch_id,null);

            // return $result;

            return [
                'yearly'  => isset($result['yearly']) && !empty($result['yearly']) ? $result['yearly'] : [],
                'monthly' => isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [],
                'daily'   => isset($result['daily']) && !empty($result['daily']) ? $result['daily'] : [],
                'staff_details' => $staff_details,
                'years' => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyRevenueDetails: " . $e->getMessage());
            return null;
        }
    }

    public function getStaffPerformList(Request $request)
    {
        $currentDate = date('Y-m-d');
        $currentYear = (int) date('Y');
        $currentMonth = (int) date('n');

        $is_existing_val = (int) $request->checked_val ?? 2;

        $user = $request->user();
        $user_id = $user->user_id;
        $branch_id = $user->branch_id;

        $staff_details = [];

        $job_positions = DB::table('et_job_position')
            ->where('department_id', 2)
            ->where('status', '!=', 2)
            ->get();

        foreach ($job_positions as $position) {

            // --- Fetch staff under this position ---
            $staff_list = DB::table('et_staff')
                ->where('branch_id', $branch_id)
                ->where('position_role', $position->sno)
                // ->where('role_id', 22)
                // ->where('et_staff.status', 0)
                ->where(function ($query) use ($currentYear, $currentMonth, $is_existing_val) {
                    if ($is_existing_val == 2) {
                        $query->where(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('status', 4)
                                ->whereYear('notice_end_date', '>=', $currentYear)
                                ->whereMonth('notice_end_date', '>=', $currentMonth);
                        })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 5)
                                    ->whereYear('updated_at', '>=', $currentYear)
                                    ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 6)
                                    ->whereYear('staff_last_date', '>=', $currentYear)
                                    ->whereMonth('staff_last_date', '>=', $currentMonth);
                            })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 7)
                                    ->whereYear('updated_at', '>=', $currentYear)
                                    ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere('status', 0);
                    } else {
                        $query->where('status', '!=', 2);
                    }
                })
                ->orderBy('staff_name', 'asc')
                ->get();

            $staff_list = $staff_list->unique('staff_id');

            // --- Loop staff for daily counts ---
            foreach ($staff_list as $staff) {

                if (!isset($staff_details[$staff->sno])) {
                    $staff_details[$staff->sno] = [];
                }

                $staff_details[$staff->sno] = [
                    'sno' => $staff->sno ?? 0,
                    'staff_name' => $staff->staff_name ?? 'None',
                    'staff_position' => $position->job_position_name ?? 'None',
                    'staff_full_name' => $staff->staff_name . ' (' . $position->job_position_name . ')' ?? 'None',
                ];
            }
        }

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => array_values($staff_details)
        ], 200);
    }

    public function GetFacultyAttendanceDetails(int $branch_id, $search_lead_src_fill = null, int $is_existing_val = 2)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate = date('Y-m-d');
            $currentYear = (int) date('Y');
            $currentMonth = (int) date('n');

            $dailyData = [];
            $monthlyData = [];
            $yearlyData = [];
            $years = [];
            $deptSummary = [];

            $attendanceTypes = StaffAttendanceModel::distinct()->pluck('attendance')->toArray();
            ;

            // --- Fetch job positions (departments) ---
            $departments = DB::table('et_department')
                ->where('status', '!=', 2)
                ->orderBy('department_name', 'asc')
                ->get();
                
                
            if ($departments->isEmpty()) {
                return [
                    'daily' => [],
                    'monthly' => [],
                    'yearly' => [],
                    'years' => [],
                    'dept_summary' => [],
                    'total_departments' => 0
                ];
            }

            $departmentIds = $departments->pluck('sno')->toArray();

            // --- Fetch staff list ---
            $staff_query = DB::table('et_staff')
                ->join('et_user_role', 'et_user_role.sno', '=', 'et_staff.role_id')
                ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
                ->where('et_staff.branch_id', $branch_id)
                ->where('et_staff.sno','>', 1)
                ->whereIn('et_staff.department_id', $departmentIds);

            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 4)
                            ->whereYear('et_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('et_staff.notice_end_date', '>=', $currentMonth);
                    })
                    ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 5)
                            ->whereYear('et_staff.updated_at', '>=', $currentYear)
                            ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                    })
                    ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 6)
                            ->whereYear('et_staff.staff_last_date', '>=', $currentYear)
                            ->whereMonth('et_staff.staff_last_date', '>=', $currentMonth);
                    })
                    ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 7)
                            ->whereYear('et_staff.updated_at', '>=', $currentYear)
                            ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                    })
                    ->orWhere('et_staff.status', 0);
                });
            } else {
                $staff_query->whereNotIn('et_staff.status', [1,2]);
            }

            if (!empty($search_lead_src_fill)) {
                $staff_query->whereIn('et_staff.sno', $search_lead_src_fill);
            }

            $staff_list = $staff_query->orderBy('et_staff.staff_name', 'asc')->get([
                'et_staff.*',
                'et_user_role.role_name',
                'et_job_position.job_position_name'
            ]);

            if ($staff_list->isEmpty()) {
                return [
                    'daily' => [],
                    'monthly' => [],
                    'yearly' => [],
                    'years' => [],
                    'dept_summary' => [],
                    'total_departments' => 0
                ];
            }

            $staffIds = $staff_list->pluck('sno')->toArray();
            
            // ✅ Department summary
            $deptSummary = $staff_list->groupBy('department_id')->map(function ($group, $deptId) {
                return [
                    'department_id' => $deptId,
                    'department_name' => $this->getDepartmentName($deptId),
                    'staff_count' => $group->count(),
                    'staff_list' => $group->map(fn($s) => [
                        'staff_id' => $s->sno,
                        'staff_name' => $s->staff_name,
                        'staff_position' => (isset($s->job_position_name) && !empty($s->job_position_name) ? $s->job_position_name : (isset($s->role_name) && !empty($s->role_name) ? $s->role_name : 'None')),
                        'doj' => !empty($s->date_of_joining) ? $s->date_of_joining : null,
                        'exist_status' => in_array($s->status, [4, 5, 6, 7]),
                        'exist_date' => match ($s->status) {
                            4 => $s->notice_end_date,
                            5 => $s->updated_at,
                            6 => $s->staff_last_date,
                            7 => $s->updated_at,
                            default => null,
                        },
                    ])->values(),
                ];
            })->values()->toArray();

            // // --- Fetch attendance data in bulk ---
            $attendances = DB::table('et_staff_attendance')
                ->where('branch_id', $branch_id)
                ->whereIn('staff_id', $staffIds)
                ->whereDate('date', '<=', $currentDate)
                ->select('staff_id', 'date', 'attendance')
                ->get();

            // return [ 'staff_query' => $attendances ];

            if ($attendances->isEmpty()) {
                return [
                    'daily' => [],
                    'monthly' => [],
                    'yearly' => [],
                    'years' => [],
                    'dept_summary' => $deptSummary,
                    'total_departments' => count($deptSummary)
                ];
            }

            // --- Group attendance by staff ---
            $attGroup = $attendances->groupBy('staff_id');

            // --- Build daily, monthly, yearly data ---
            foreach ($staff_list as $staff) {
                $sid = $staff->sno;
                $dept = $staff->department_id;
                $records = $attGroup[$sid] ?? collect();

                foreach ($records as $att) {
                    $y = (int) date('Y', strtotime($att->date));
                    $m = (int) date('n', strtotime($att->date));
                    $d = (int) date('j', strtotime($att->date));
                    $years[$y] = $y;

                    // ✅ Daily data
                    $dailyRef = &$dailyData[$dept][$sid][$y][$m][$d];
                    if (!isset($dailyRef)) {
                        $dailyRef = array_fill_keys($attendanceTypes, 0);
                        $dailyRef['total_attendance'] = 0;
                    }
                    if (in_array($att->attendance, $attendanceTypes)) {
                        $dailyRef[$att->attendance]++;
                    }

                    $dailyRef['total_attendance'] = ((int) $dailyRef['P'] ?? 0) + ((int) $dailyRef['HD'] ?? 0);

                    // ✅ Monthly data
                    $monthlyRef = &$monthlyData[$dept][$sid][$y][$m];
                    if (!isset($monthlyRef)) {
                        $monthlyRef = array_fill_keys($attendanceTypes, 0);
                        $monthlyRef['total_attendance'] = 0;
                    }
                    if (in_array($att->attendance, $attendanceTypes)) {
                        $monthlyRef[$att->attendance]++;
                    }
                    $monthlyRef['total_attendance'] = ((int) $monthlyRef['P'] ?? 0) + ((int) $monthlyRef['HD'] ?? 0);

                    // ✅ Yearly data
                    $yearlyRef = &$yearlyData[$dept][$sid][$y];
                    if (!isset($yearlyRef)) {
                        $yearlyRef = array_fill_keys($attendanceTypes, 0);
                        $yearlyRef['total_attendance'] = 0;
                    }
                    if (in_array($att->attendance, $attendanceTypes)) {
                        $yearlyRef[$att->attendance]++;
                    }
                    $yearlyRef['total_attendance'] = ((int) $yearlyRef['P'] ?? 0) + ((int) $yearlyRef['HD'] ?? 0);
                }
            }

            // --- Monthly ---
            foreach ($monthlyData as $deptId => &$deptStaffs) {
                foreach ($deptStaffs as $staffId => &$yearsData) {
                    foreach ($yearsData as $year => &$monthsData) {
                        foreach ($monthsData as $month => &$mdata) {
                            // totalDays includes P
                            $totalDays = array_sum(array_intersect_key($mdata, array_flip($attendanceTypes)));
                            $P = ((int) $mdata['P'] ?? 0);

                            $mdata['present_percent'] = $totalDays > 0
                                ? round(($P / $totalDays) * 100, 2)
                                : 0;
                        }
                    }
                }
            }

            // --- Yearly ---
            foreach ($yearlyData as $deptId => &$deptStaffs) {
                foreach ($deptStaffs as $staffId => &$yearsData) {
                    foreach ($yearsData as $year => &$ydata) {
                        $totalDays = array_sum(array_intersect_key($ydata, array_flip($attendanceTypes)));
                        $P = ((int) $ydata['P'] ?? 0);

                        $ydata['present_percent'] = $totalDays > 0
                            ? round(($P / $totalDays) * 100, 2)
                            : 0;
                    }
                }
            }

            // --- Sort for consistent output ---
            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'daily' => $dailyData,
                'monthly' => $monthlyData,
                'yearly' => $yearlyData,
                'years' => array_values($years),
                'dept_summary' => $deptSummary,
                'total_departments' => count($deptSummary)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyAttendanceDetails: " . $e->getMessage());
            return null;
        }
    }

    public function GetFacultyAchievementDetails(int $branch_id, $search_lead_src_fill = null, int $is_existing_val = 2)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate  = date('Y-m-01');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];
            $deptSummary = [];

            /* ================= DEPARTMENTS ================= */
            $departments = DB::table('et_department')
                ->where('status', '!=', 2)
                ->whereIn('sno', [1,2,6,14,15])
                ->orderBy('department_name', 'asc')
                ->get();

            if ($departments->isEmpty()) {
                return [
                    'monthly' => [],
                    'yearly' => [],
                    'years' => [],
                    'dept_summary' => [],
                    'total_departments' => 0
                ];
            }

            $departmentIds = $departments->pluck('sno')->toArray();

            
            /* ================= STAFF LIST ================= */
            $staff_query = DB::table('et_staff')
                ->join('et_user_role', 'et_user_role.sno', '=', 'et_staff.role_id')
                ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
                ->where('et_staff.branch_id', $branch_id)
                ->where('et_staff.sno', '>', 1)
                ->whereIn('et_staff.department_id', $departmentIds);

            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 4)
                            ->whereYear('et_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('et_staff.notice_end_date', '>=', $currentMonth);
                    })
                    ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 5)
                            ->whereYear('et_staff.updated_at', '>=', $currentYear)
                            ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                    })
                    ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 6)
                            ->whereYear('et_staff.staff_last_date', '>=', $currentYear)
                            ->whereMonth('et_staff.staff_last_date', '>=', $currentMonth);
                    })
                    ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 7)
                            ->whereYear('et_staff.updated_at', '>=', $currentYear)
                            ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                    })
                    ->orWhere('et_staff.status', 0);
                });
            } else {
                $staff_query->whereNotIn('et_staff.status', [1, 2]);
            }

            if (!empty($search_lead_src_fill)) {
                $staff_query->whereIn('et_staff.sno', $search_lead_src_fill);
            }

            $staff_list = $staff_query->orderBy('et_staff.staff_name', 'asc')->get([
                'et_staff.*',
                'et_user_role.role_name',
                'et_job_position.job_position_name'
            ]);

            if ($staff_list->isEmpty()) {
                return [
                    'monthly' => [],
                    'yearly' => [],
                    'years' => [],
                    'dept_summary' => [],
                    'total_departments' => 0
                ];
            }

            $staffIds = $staff_list->pluck('sno')->toArray();

            /* ================= DEPT SUMMARY ================= */
            $deptSummary = $staff_list->groupBy('department_id')->map(function ($group, $deptId) {
                return [
                    'department_id'   => $deptId,
                    'department_name' => $this->getDepartmentName($deptId),
                    'staff_count'     => $group->count(),
                    'staff_list'      => $group->map(fn($s) => [
                        'staff_id'        => $s->sno,
                        'staff_name'      => $s->staff_name,
                        'staff_position'  => !empty($s->job_position_name)
                            ? $s->job_position_name
                            : (!empty($s->role_name) ? $s->role_name : 'None'),
                        'doj'             => $s->date_of_joining ?: null,
                        'exist_status'    => in_array($s->status, [4,5,6,7]),
                        'exist_date'      => match ($s->status) {
                            4 => $s->notice_end_date,
                            5 => $s->updated_at,
                            6 => $s->staff_last_date,
                            7 => $s->updated_at,
                            default => null,
                        },
                    ])->values(),
                ];
            })->values()->toArray();

            /* ================= ACHIEVEMENTS ================= */
            $achievements = DB::table('et_goal_set_staff')
                ->where('branch_id', $branch_id)
                ->whereIn('staff_id', $staffIds)
                ->where('status', '!=', 2)
                ->whereDate('goal_date', '<=', $currentDate)
                ->select('staff_id', 'department_id', 'goal_date', 'status_10x')
                ->get();

            $achGroup = $achievements->groupBy('staff_id');


            /* ================= BUILD MONTHLY + YEARLY ================= */
            foreach ($staff_list as $staff) {

                $sid  = $staff->sno;
                $dept = $staff->department_id;

                $records = $achGroup[$sid] ?? collect();

                $hasGoalTrueYear = false;

                foreach ($records as $row) {

                    if (!empty($row)) {
                        $hasGoalTrueYear = true;
                    }

                    $y = (int) date('Y', strtotime($row->goal_date));
                    $m = (int) date('n', strtotime($row->goal_date));

                    $years[$y] = $y;

                    if (!isset($monthlyData[$dept][$sid][$y][$m])) {
                        $monthlyData[$dept][$sid][$y][$m] = [
                            'achievement_count' => 0,
                            'goal_status' => 0,
                            'status_10x' => 0
                        ];
                    }

                    if (isset($row->status_10x) && $row->status_10x == 1) {
                        $monthlyData[$dept][$sid][$y][$m]['achievement_count']++;
                    }

                    if (!empty($row)) {
                        $monthlyData[$dept][$sid][$y][$m]['goal_status'] = 1;
                    }

                    if (isset($row->status_10x) && $row->status_10x == 1) {
                        $monthlyData[$dept][$sid][$y][$m]['status_10x'] = 1;
                    }

                    if (!isset($yearlyData[$dept][$sid][$y])) {
                        $yearlyData[$dept][$sid][$y] = [
                            'achievement_count' => 0,
                            'goal_status' => false,
                            'status_10x' => 0
                        ];
                    }

                    if (isset($row->status_10x) && $row->status_10x == 1) {
                        $yearlyData[$dept][$sid][$y]['achievement_count']++;
                    }

                    if (isset($row->status_10x) && $row->status_10x == 1) {
                        $yearlyData[$dept][$sid][$y]['status_10x'] = 1;
                    }
                }

                // ANY TRUE → TRUE
                if ($hasGoalTrueYear) {
                    foreach ($yearlyData[$dept][$sid] ?? [] as $y => $v) {
                        $yearlyData[$dept][$sid][$y]['goal_status'] = 1;
                    }
                }
            }

            ksort($monthlyData);
            ksort($yearlyData);
            ksort($years);

            return [
                'monthly' => $monthlyData,
                'yearly' => $yearlyData,
                'years' => array_values($years),
                'dept_summary' => $deptSummary,
                'total_departments' => count($deptSummary)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyAchievementDetails: " . $e->getMessage());
            return null;
        }
    }

    private function getYearBasedMonths($year, $type = 1)
    {

        $months = [
            1 => 'January',
            2 => 'February',
            3 => 'March',
            4 => 'April',
            5 => 'May',
            6 => 'June',
            7 => 'July',
            8 => 'August',
            9 => 'September',
            10 => 'October',
            11 => 'November',
            12 => 'December'
        ];

        if ($type == 2) {
            $months = [
                1 => 'Jan',
                2 => 'Feb',
                3 => 'Mar',
                4 => 'Apr',
                5 => 'May',
                6 => 'Jun',
                7 => 'Jul',
                8 => 'Aug',
                9 => 'Sep',
                10 => 'Oct',
                11 => 'Nov',
                12 => 'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function ($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl(' . $hue . ', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if ($count > 0) {
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl(' . $hue . ', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    private function slugify($text)
    {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    private function getDepartmentName($id)
    {
        // Initialize 'details' if not already
        if (!isset(self::$temp['department_name'])) {
            self::$temp['department_name'] = [];
        }
        // Check if the id is already cached
        if (!isset(self::$temp['department_name'][$id])) {
            $state = DB::table('et_department')->select('department_name')->where('sno', $id)->first();
            self::$temp['department_name'][$id] = $state ? $state->department_name : null;
        }
        return self::$temp['department_name'][$id];
    }

    public function get_all_department_wise_staff(Request $request)
    {
        try {
            $user = $request->user();
            $branch_id = $user->branch_id;
            $is_existing_val = $request->filled('checked_val') ? (int) $request->checked_val : 2;
            $is_filter_department = $request->filled('is_filter_department') ? (int) $request->is_filter_department : 2;

            $currentDate = date('Y-m-d');
            $currentYear = (int) date('Y');
            $currentMonth = (int) date('n');
            
            $departments = DB::table('et_department')
                ->where('status', '!=', 2)
                ->orderBy('department_name', 'asc')
                ->when($is_filter_department == 1, function ($q) {
                    $q->whereIn('sno', [1,2,6,14,15]);
                })
                ->get();

            if ($departments->isEmpty()) {
                return response([
                    'status' => 200,
                    'message' => 'list retrieved successfully.',
                    'error_msg' => null,
                    'data' => [
                        [
                            'option_group_name' => 'Unknown Group Name',
                            'option_group_id' => null,
                            'options' => []
                        ]
                    ]
                ], 200);
            }

            $departmentIds = $departments->pluck('sno')->toArray();

            $staff_query = DB::table('et_staff')
                ->join('et_user_role', 'et_user_role.sno', '=', 'et_staff.role_id')
                ->where('et_staff.branch_id', $branch_id)
                ->whereIn('et_staff.department_id', $departmentIds);

            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 4)
                            ->whereYear('et_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('et_staff.notice_end_date', '>=', $currentMonth);
                    })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 5)
                                ->whereYear('et_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 6)
                                ->whereYear('et_staff.staff_last_date', '>=', $currentYear)
                                ->whereMonth('et_staff.staff_last_date', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 7)
                                ->whereYear('et_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere('et_staff.status', 0);
                });
            } else {
                $staff_query->where('et_staff.status', '!=', 2);
            }

            $staff_list = $staff_query
                ->orderBy('et_staff.staff_name', 'asc')
                ->get([
                    'et_staff.sno',
                    'et_staff.staff_name',
                    'et_staff.department_id',
                    'et_staff.date_of_joining',
                    'et_user_role.role_name'
                ]);

            // ✅ Group staff by department
            $data = [];
            foreach ($departments as $dept) {

                $dept_staff = $staff_list->where('department_id', $dept->sno)->map(function ($s) {
                    return [
                        'value' => $s->sno,
                        'label' => $s->staff_name . ' (' . $s->role_name . ')',
                        'date_of_joining' => $s->date_of_joining
                    ];
                })->values();

                if (!$dept_staff->isEmpty()) {
                    $data[] = [
                        'option_group_name' => $dept->department_name,
                        'option_group_id' => $dept->sno,
                        'options' => $dept_staff
                    ];
                }
            }

            return response([
                'status' => 200,
                'message' => 'list retrieved successfully.',
                'error_msg' => null,
                'data' => $data
            ], 200);

        } catch (\Exception $e) {
            return response([
                'status' => 500,
                'message' => 'Failed to fetch list.',
                'error_msg' => $e->getMessage(),
                'data' => []
            ], 500);
        }
    }

    private function getDaysWithoutSundays($month, $year)
    {

        $totalDays = cal_days_in_month(CAL_GREGORIAN, $month, $year); // Total days in the month
        $daysWithoutSundays = 0;

        for ($day = 1; $day <= $totalDays; $day++) {
            $date = "$year-$month-$day";
            if (date('w', strtotime($date)) != 0) { // Check if the day is not Sunday (0 represents Sunday)
                $daysWithoutSundays++;
            }
        }

        return $daysWithoutSundays;
    }

    private function generateNavHtml()
    {
        $menus =  [
            [
                'title' => 'Production Percentage',
                'url' => url('/manage_reports/production_yearly'),
                'is_active' => request()->is([
                    'manage_reports/production_yearly'
                ]),
            ],
            [
                'title' => '10x Achievement',
                'url' => url('/manage_reports/goalset_yearly'),
                'is_active' => request()->is([
                    'manage_reports/goalset_yearly'
                ]),
            ],
            [
                'title' => 'Present Percentage',
                'url' => url('/manage_reports/leave_yearly'),
                'is_active' => request()->is([
                    'manage_reports/leave_yearly'
                ]),
            ]
        ];

        $menu_width = !empty($menus) ? count($menus) * 20 : 0;

        $html = '<div class="w-'.(($menu_width >= 50) ? 50 : $menu_width).' nav-align-top mb-2"><div class="nav-align-top mb-2">';
        $html .= '<ul class="nav nav-pills flex-nowrap" role="tablist">
            <div class="scroll-container-wrapper">
                <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                <div class="scroll-container" id="scrollContainer">';

        foreach ($menus as $menu) {

            $active = $menu['is_active'] ? 'active' : '';

            $html .= "<div class='item'><li class='nav-item'>
                    <a href='{$menu['url']}' class='nav-link text-capitalize {$active}'>
                        {$menu['title']}
                    </a>
                </li></div>
            ";
        }

        $html .= '</div><button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button></div></ul></div></div>';

        return $html;
    }

    private function get_faculty_revenue_data($staffId = null, $branchId = null, $yearOrMonth = null)
    {

        try {

            /* ---------------- VALIDATION ---------------- */

            if ($staffId !== null && !is_numeric($staffId)) {
                return ['status'=>false,'message'=>'Invalid staffId'];
            }

            if ($branchId !== null && !is_numeric($branchId)) {
                return ['status'=>false,'message'=>'Invalid branchId'];
            }

            if ($yearOrMonth !== null) {
                if (!preg_match('/^\d{4}$/', $yearOrMonth) && !preg_match('/^\d{4}\-\d{2}$/', $yearOrMonth)) {
                    return ['status'=>false,'message'=>'Invalid year or year-month format'];
                }
            }

            /* ---------------- WHERE ---------------- */

            $bindings = [];
            $where = " WHERE dt.status = 0 AND tr.transaction_type='credit' ";

            if ($staffId) {
                $where .= " AND dt.staff_id = ? ";
                $bindings[] = $staffId;
            }

            if ($branchId) {
                $where .= " AND t.branch_id = ? ";
                $bindings[] = $branchId;
            }

            if ($yearOrMonth) {
                if (strlen($yearOrMonth) == 4) {
                    $where .= " AND YEAR(tr.transaction_date) = ? ";
                    $bindings[] = $yearOrMonth;
                } else {
                    $where .= " AND DATE_FORMAT(tr.transaction_date,'%Y-%m') = ? ";
                    $bindings[] = $yearOrMonth;
                }
            }

            /* ---------------- SQL ---------------- */

            $sql = "
            SELECT 
                final.staff_id,
                final.txn_date,
                YEAR(final.txn_date) yr,
                MONTH(final.txn_date) mn,
                DAY(final.txn_date) dy,
                final.staff_revenue,
                final.staff_cost,
                final.task_hours,
                final.task_id

            FROM
            (
                SELECT 
                    dt.staff_id,
                    dt.task_id,
                    dt.task_hours,
                    t.per_hour_cost,
                    DATE(tr.transaction_date) txn_date,

                    CASE 
                        WHEN proposal.currency_id = 70 
                        THEN tr.total_amount
                        ELSE tr.total_amount_inr
                    END AS milestone_amount,

                    (
                        SELECT COUNT(DISTINCT t2.sno)
                        FROM et_task t2
                        WHERE JSON_CONTAINS(mm.task_ids, CONCAT('\"', t2.task_name, '\"'))
                    ) AS milestone_task_count,

                    (
                        SELECT COUNT(DISTINCT dt2.staff_id)
                        FROM et_daily_tasks dt2
                        WHERE dt2.task_id = t.sno
                    ) AS task_staff_count,

                    (
                        (
                            CASE 
                                WHEN proposal.currency_id = 70 
                                THEN tr.total_amount
                                ELSE tr.total_amount_inr
                            END
                        )
                        /
                        (
                            SELECT COUNT(DISTINCT t2.sno)
                            FROM et_task t2
                            WHERE JSON_CONTAINS(mm.task_ids, CONCAT('\"', t2.task_name, '\"'))
                        )
                    )
                    /
                    (
                        SELECT COUNT(DISTINCT dt2.staff_id)
                        FROM et_daily_tasks dt2
                        WHERE dt2.task_id = t.sno
                    )
                    AS staff_revenue,

                    (dt.task_hours * t.per_hour_cost) AS staff_cost

                FROM et_daily_tasks dt
                JOIN et_task t ON t.sno = dt.task_id
                JOIN et_milestone_mapping mm 
                    ON JSON_CONTAINS(mm.task_ids, CONCAT('\"', t.task_name, '\"'))
                JOIN et_proposal_pay_slot ps ON ps.sno = mm.milestone_id
                JOIN et_proposal proposal ON proposal.sno = ps.proposal_sno
                JOIN et_payment pay ON pay.pay_slot_id = ps.sno
                JOIN et_transaction tr 
                    ON tr.payment_id = pay.sno
                    AND tr.transaction_type='credit'

                $where

            ) final
            ";

            /* ---------------- QUERY EXECUTE ---------------- */

            $rows = \DB::select($sql, $bindings);

            /* ---------------- EMPTY CHECK ---------------- */

            if (!$rows) {
                return [
                    'status' => true,
                    'message' => 'No data found',
                    'yearly'=>[],
                    'monthly'=>[],
                    'daily'=>[]
                ];
            }

            /* ---------------- BUILD ARRAYS ---------------- */

            $yearly = [];
            $monthly = [];
            $daily = [];

            foreach ($rows as $r) {

                $s = $r->staff_id;
                $y = $r->yr;
                $m = $r->mn;
                $d = $r->dy;

                // yearly
                $yearly[$s][$y]['revenue'] = ($yearly[$s][$y]['revenue'] ?? 0) + $r->staff_revenue;
                $yearly[$s][$y]['cost']    = ($yearly[$s][$y]['cost'] ?? 0) + $r->staff_cost;
                $yearly[$s][$y]['profit']  = ($yearly[$s][$y]['profit'] ?? 0) + ($r->staff_revenue - $r->staff_cost);
                $yearly[$s][$y]['production_percentage'] = $yearly[$s][$y]['profit'] > 0 ? round(($yearly[$s][$y]['revenue'] / $yearly[$s][$y]['profit']) * 100, 2) : 0;

                // monthly
                $monthly[$s][$y][$m]['revenue'] = ($monthly[$s][$y][$m]['revenue'] ?? 0) + $r->staff_revenue;
                $monthly[$s][$y][$m]['cost']    = ($monthly[$s][$y][$m]['cost'] ?? 0) + $r->staff_cost;
                $monthly[$s][$y][$m]['profit']  = ($monthly[$s][$y][$m]['profit'] ?? 0) + ($r->staff_revenue - $r->staff_cost);
                $monthly[$s][$y][$m]['production_percentage'] = $monthly[$s][$y][$m]['profit'] > 0 ? round(($monthly[$s][$y][$m]['revenue'] / $monthly[$s][$y][$m]['profit']) * 100, 2) : 0;

                // daily
                $daily[$s][$y][$m][$d]['revenue'] = ($daily[$s][$y][$m][$d]['revenue'] ?? 0) + $r->staff_revenue;
                $daily[$s][$y][$m][$d]['cost']    = ($daily[$s][$y][$m][$d]['cost'] ?? 0) + $r->staff_cost;
                $daily[$s][$y][$m][$d]['profit']  = ($daily[$s][$y][$m][$d]['profit'] ?? 0) + ($r->staff_revenue - $r->staff_cost);
                $daily[$s][$y][$m][$d]['production_percentage'] = $daily[$s][$y][$m][$d]['profit'] > 0 ? round(($daily[$s][$y][$m][$d]['revenue'] / $daily[$s][$y][$m][$d]['profit']) * 100, 2) : 0;
            }

            // return $yearly;

            return [
                'status'=>true,
                'yearly'=>$yearly,
                'monthly'=>$monthly,
                'daily'=>$daily
            ];

        } catch (\Illuminate\Database\QueryException $e) {

            \Log::error('Revenue SQL Error', [
                'msg'=>$e->getMessage(),
                'sql'=>$e->getSql() ?? '',
            ]);

            return [
                'status'=>false,
                'message'=>'Database error',
            ];

        } catch (\Throwable $e) {

            \Log::error('Revenue System Error', [
                'msg'=>$e->getMessage(),
            ]);

            return [
                'status'=>false,
                'message'=>'System error'
            ];
        }
    }
}
