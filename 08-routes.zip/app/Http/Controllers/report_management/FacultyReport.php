<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use DateTime;
use App\Models\BatchModel;
use App\Models\JobpositionModel;

class FacultyReport extends Controller
{
    public static $report_heading = 'Analysis';

    public function index()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $feedbacknavHtml = $this->generateNavHtml();

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.faculty_report.faculty_yearly_list', compact(
            'currentMonth', 'currentYear','months','short_months','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function FacultyYearData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year,2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFacultyDetails($branch_id,$is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $query = JobpositionModel::where('department_id', 2)->where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'job_position_name')->orderBy('job_position_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->job_position_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;

            $days = range(1, 31);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($months as $monthNum => $monthName) {
                    
                    $paymentSums = isset($result['monthly'][$lead_type_id]) && !empty($result['monthly'][$lead_type_id]) ? $result['monthly'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$monthNum]['staff_count']) ? (int) $paymentSums[$year][$monthNum]['staff_count'] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$monthNum][$leadType] = $count;

                    $monthTotals[$monthNum] = ($monthTotals[$monthNum] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;

                    if ((int)$monthNum == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                    }else if((int)$monthNum != 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$monthNum - 1;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth]['staff_count']) ? (int) $paymentSums[$prevYear][$prevMonth]['staff_count'] : 0;

                    $preleadData[$prevMonth][$leadType] = $pre_count;

                    // $monthTotals[$day] = $dayTotal;
                }
                
                if (!isset($sourceTotals[$leadType])) $sourceTotals[$leadType] = 0;
                
                $sourceTotals[$leadType] = isset($leadData[$lastMonth][$leadType]) ? (int) $leadData[$lastMonth][$leadType] : 0;
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$leadType] ?? 0;
                }
                $sourceTrends[$leadType] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function faculty_monthly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

        $feedbacknavHtml = $this->generateNavHtml();

        $months = $this->getYearBasedMonths($currentYear);

        $days = range(1, $daysInMonth);

        return view('content.report_management.faculty_report.faculty_monthly_list', compact(
            'days','currentMonth', 'currentYear','months','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function FacultyMonthData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFacultyDetails($branch_id,$is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $query = JobpositionModel::where('department_id', 2)->where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'job_position_name')->orderBy('job_position_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->job_position_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;
            

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($days as $day) {
                    
                    $paymentSums = isset($result['daily'][$lead_type_id]) && !empty($result['daily'][$lead_type_id]) ? $result['daily'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$Month][$day]['staff_count']) ? (int) $paymentSums[$year][$Month][$day]['staff_count'] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$day][$leadType] = $count;

                    $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    $day_query = false;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay]['staff_count']) ? (int) $paymentSums[$prevYear][$prevMonth][$prevDay]['staff_count'] : 0;

                    $preleadData[$prevDay][$leadType] = $pre_count;

                    // $dayTotals[$day] = $dayTotal;
                }
                
                if (!isset($sourceTotals[$leadType])) $sourceTotals[$leadType] = 0;
                
                $sourceTotals[$leadType] = isset($leadData[$daysInMonth][$leadType]) ? (int) $leadData[$daysInMonth][$leadType] : 0;
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$leadType] ?? 0;
                }
                $sourceTrends[$leadType] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function faculty_revenue_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $feedbacknavHtml = $this->generateNavHtml();

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.faculty_report.faculty_revenue_yr_list', compact(
            'months','short_months','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function FacultyRevenueYearData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year,2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFacultyRevenueDetails($branch_id,$search_lead_src_fill,$is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');
            
            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

            // Sort by staff_name
            uasort($leadTypesMapped, function($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate  = strtotime($staff['doj']);
                    $dojYear  = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int)$year) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate  = strtotime($staff['exist_date']);
                    $exitYear  = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int)$year) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = isset($leadTypesMapped) && !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;

            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];

            $days = range(1, 31);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            // return $leadTypesMapped;

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($months as $monthNum => $monthName) {
                    
                    $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;
                    // ---------- Exit Staff Tracking ----------
                    $exist_status = isset($leadType['exist_status']) ? (bool)$leadType['exist_status'] : false;
                    $exist_date   = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : null;

                    if ($exist_status && $exist_date) {

                        $exist_y = (int) date('Y', strtotime($exist_date));
                        $exist_m = (int) date('n', strtotime($exist_date));
                        $exist_d = (int) date('j', strtotime($exist_date));

                        // If exit is before selected month/year → mark as inactive
                        if ($exist_y > (int)$year || ($exist_y === (int)$year && $exist_m > (int)$monthNum)) {
                            $exist_status = false;
                        }
                        // If same month but exited before current month → inactive for remaining days
                        elseif ($exist_y === (int)$year && $exist_m > (int)$monthNum) {
                            $exist_status = false;
                        }

                        $exit_staff_details[$monthNum][$lead_type_id] = [
                            'exist_status' => $exist_status,
                            'exist_date'   => $exist_date
                        ];

                        $exit_status_staffs[$lead_type_id] = $exist_status;
                    }

                    $paymentSums = isset($result['monthly'][$lead_type_id]) && !empty($result['monthly'][$lead_type_id]) ? $result['monthly'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$monthNum]['revenue']) ? $paymentSums[$year][$monthNum]['revenue'] : 0;
                    $earned_per = isset($paymentSums[$year][$monthNum]['production_percentage']) ? $paymentSums[$year][$monthNum]['production_percentage'] : 0;
                    
                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$monthNum][$lead_type_id] = $count;
                    $percentages[$lead_type_id][$monthNum] = $earned_per;
                    
                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $monthTotals[$monthNum] = ($monthTotals[$monthNum] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;

                    if ((int)$monthNum == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                    }else if((int)$monthNum != 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$monthNum - 1;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth]['revenue']) ? $paymentSums[$prevYear][$prevMonth]['revenue'] : 0;

                    $preleadData[$prevMonth][$lead_type_id] = $pre_count;

                    // $monthTotals[$day] = $dayTotal;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int)$year) {
                            if ((int)$monthNum >= $doj_m) {
                                $doj_status = true;
                            }
                        }

                        // Case 2: DOJ is before this year → always true
                        elseif ($doj_y < $year) {
                            $doj_status = true;
                        }

                        // Case 3: DOJ is after this year → always false
                        else {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$monthNum][$lead_type_id] = [
                        'doj_status' => $doj_status,
                    ];
                }
                
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'staff_details' => $leadTypesMapped,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function faculty_revenue_monthly()
    {
        $days = range(1, 31);

        $feedbacknavHtml = $this->generateNavHtml();

        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.faculty_report.faculty_revenue_month_list', compact(
            'months','days','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function FacultyRevenueMonthData(Request $request)
    {
        try {
            
            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFacultyRevenueDetails($branch_id,$search_lead_src_fill,$is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');
            
            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

            // Sort by staff_name
            uasort($leadTypesMapped, function($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year, $Month) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate  = strtotime($staff['doj']);
                    $dojYear  = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int)$year || ($dojYear === (int)$year && $dojMonth > (int)$Month)) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate  = strtotime($staff['exist_date']);
                    $exitYear  = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int)$year || ($exitYear === (int)$year && $exitMonth < (int)$Month)) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = isset($leadTypesMapped) && !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;

            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            // $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            // return $leadTypesMapped;

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($days as $day) {

                    $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;

                    // ---------- Exit Staff Tracking ----------
                    $exist_status = isset($leadType['exist_status']) ? (bool)$leadType['exist_status'] : false;
                    $exist_date   = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : null;

                    if ($exist_status && $exist_date) {

                        $exist_y = (int) date('Y', strtotime($exist_date));
                        $exist_m = (int) date('n', strtotime($exist_date));
                        $exist_d = (int) date('j', strtotime($exist_date));

                        // If exit is before selected month/year → mark as inactive
                        if ($exist_y > (int)$year || ($exist_y === (int)$year && $exist_m > (int)$Month)) {
                            $exist_status = false;
                        }
                        // If same month but exited before current day → inactive for remaining days
                        elseif ($exist_y === (int)$year && $exist_m === (int)$Month && $exist_d > (int)$day) {
                            $exist_status = false;
                        }

                        $exit_staff_details[$day][$lead_type_id] = [
                            'exist_status' => $exist_status,
                            'exist_date'   => $exist_date
                        ];

                        $exit_status_staffs[$lead_type_id] = $exist_status;
                    }
                    
                    $paymentSums = isset($result['daily'][$lead_type_id]) && !empty($result['daily'][$lead_type_id]) ? $result['daily'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$Month][$day]['revenue']) ? $paymentSums[$year][$Month][$day]['revenue'] : 0;
                    // $earned_per = isset($paymentSums[$year][$monthNum]['production_percentage']) ? $paymentSums[$year][$monthNum]['production_percentage'] : 0;
                    
                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$day][$lead_type_id] = $count;
                    // $percentages[$lead_type_id][$monthNum] = $earned_per;
                    
                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay]['revenue']) ? $paymentSums[$prevYear][$prevMonth][$prevDay]['revenue'] : 0;

                    $preleadData[$prevDay][$lead_type_id] = $pre_count;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));
                        $doj_d = (int) date('j', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int)$year) {

                            // Same month
                            if ((int)$Month === $doj_m) {
                                if ($day >= $doj_d) {
                                    $doj_status = true;
                                }
                            }

                            // Month after DOJ month (still same year)
                            elseif ((int)$Month > $doj_m) {
                                $doj_status = true;
                            }

                            // Month before DOJ month → false
                            else {
                                $doj_status = false;
                            }
                        }

                        // Case 2: DOJ is before this year → always true
                        elseif ($doj_y < $year) {
                            $doj_status = true;
                        }

                        // Case 3: DOJ is after this year → always false
                        else {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$day][$lead_type_id] = [
                        'doj_status' => $doj_status,
                    ];

                    // $dayTotals[$day] = $dayTotal;
                }
                
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'staff_details' => $leadTypesMapped,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    
    public function faculty_attendance_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $feedbacknavHtml = $this->generateNavHtml();

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.faculty_report.faculty_attendance_yr_list', compact(
            'months','short_months','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function FacultyAttYearData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = isset($request->is_existing_val) ? (int)$request->is_existing_val : 2;

            // Validate year
            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = (int) date('Y', strtotime($filterDate));
            $yearShort = (int) date('y', strtotime($filterDate));
            $querycurrentMonth = (int) date('m', strtotime($filterDate));
            $Month = (int) date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFacultyAttendanceDetails($branch_id, $search_lead_src_fill, $is_existing_val, $year);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];

            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

            // Sort by staff_name alphabetically
            uasort($leadTypesMapped, function ($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate  = strtotime($staff['doj']);
                    $dojYear  = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int)$year) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate  = strtotime($staff['exist_date']);
                    $exitYear  = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int)$year) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];
            $grandTotalAll = 0;

            $holiday_status_staffs = [];
            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];
            
            $days = range(1, 31);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {

                // ---------- Month Loop ----------
                foreach ($months as $monthNum => $monthName) {

                    $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;
                    // ---------- Exit Staff Tracking ----------
                    $exist_status = isset($leadType['exist_status']) ? (bool)$leadType['exist_status'] : false;
                    $exist_date   = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : null;

                    if ($exist_status && $exist_date) {

                        $exist_y = (int) date('Y', strtotime($exist_date));
                        $exist_m = (int) date('n', strtotime($exist_date));
                        $exist_d = (int) date('j', strtotime($exist_date));

                        // If exit is before selected month/year → mark as inactive
                        if ($exist_y > (int)$year || ($exist_y === (int)$year && $exist_m > (int)$monthNum)) {
                            $exist_status = false;
                        }
                        // If same month but exited before current month → inactive for remaining days
                        elseif ($exist_y === (int)$year && $exist_m > (int)$monthNum) {
                            $exist_status = false;
                        }

                        $exit_staff_details[$monthNum][$lead_type_id] = [
                            'exist_status' => $exist_status,
                            'exist_date'   => $exist_date
                        ];

                        $exit_status_staffs[$lead_type_id] = $exist_status;
                    }
                    
                    $paymentSums = $monthlyData[$lead_type_id] ?? [];
                    $count = $paymentSums[$year][$monthNum]['leave_abs_count'] ?? 0;

                    $earned_per = isset($paymentSums[$year][$monthNum]['present_percentage']) ? $paymentSums[$year][$monthNum]['present_percentage'] : 0;

                    $holiday_status = isset($paymentSums[$year][$monthNum]['holiday_status']) ? $paymentSums[$year][$monthNum]['holiday_status'] : false;

                    $leadData[$monthNum][$lead_type_id] = $count;
                    $percentages[$monthNum][$lead_type_id] = $earned_per;
                    $holiday_status_staffs[$monthNum][$lead_type_id] = $holiday_status;

                    $sourceTotals[$lead_type_id] = $yearlyData[$lead_type_id][$year]['leave_abs_count'] ?? 0;

                    $monthTotals[$monthNum] = ($monthTotals[$monthNum] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;

                    // Previous month calc
                    if ((int)$monthNum === 1) {
                        $prevYear = $year - 1;
                        $prevMonth = 12;
                    } else {
                        $prevYear = $year;
                        $prevMonth = (int)$monthNum - 1;
                    }

                    $pre_count = $paymentSums[$prevYear][$prevMonth]['leave_abs_count'] ?? 0;
                    $preleadData[$prevMonth][$lead_type_id] = $pre_count;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int)$year) {
                            if ((int)$monthNum >= $doj_m) {
                                $doj_status = true;
                            }
                        }

                        // Case 2: DOJ is before this year → always true
                        elseif ($doj_y < $year) {
                            $doj_status = true;
                        }

                        // Case 3: DOJ is after this year → always false
                        else {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$monthNum][$lead_type_id] = [
                        'doj_status' => $doj_status,
                    ];
                }

                $grandTotalAll += (int) ($sourceTotals[$lead_type_id] ?? 0);
            }

            // ---------- Prepare monthly trends for JS chart ----------
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors)
                ? array_values($line_MonthColors)
                : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'staff_details' => $leadTypesMapped,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'holiday_status_staffs' => $holiday_status_staffs,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'sourceTotals' => $sourceTotals,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => $currentMonth,
                'currentYear' => $currentYear,
                'currentDay' => (int) date('j'),
                'Month' => $Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => $year,
                'yearShort' => $yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function faculty_attendance_monthly()
    {
        $days = range(1, 31);

        $feedbacknavHtml = $this->generateNavHtml();

        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.faculty_report.faculty_attendance_month_list', compact(
            'months','days','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function FacultyAttMonthData(Request $request)
    {
        try {
            
            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFacultyAttendanceDetails($branch_id, $search_lead_src_fill, $is_existing_val, $year);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');
            
            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];
            
            
            // Sort by staff_name
            uasort($leadTypesMapped, function($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year, $Month) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate  = strtotime($staff['doj']);
                    $dojYear  = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int)$year || ($dojYear === (int)$year && $dojMonth > (int)$Month)) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate  = strtotime($staff['exist_date']);
                    $exitYear  = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int)$year || ($exitYear === (int)$year && $exitMonth < (int)$Month)) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = isset($leadTypesMapped) && !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            
            $holiday_status_staffs = [];
            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];

            $grandTotalAll = 0;

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            // return $leadTypesMapped;

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($days as $day) {

                    $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;

                    // ---------- Exit Staff Tracking ----------
                    $exist_status = isset($leadType['exist_status']) ? (bool)$leadType['exist_status'] : false;
                    $exist_date   = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : null;

                    if ($exist_status && $exist_date) {

                        $exist_y = (int) date('Y', strtotime($exist_date));
                        $exist_m = (int) date('n', strtotime($exist_date));
                        $exist_d = (int) date('j', strtotime($exist_date));

                        // If exit is before selected month/year → mark as inactive
                        if ($exist_y > (int)$year || ($exist_y === (int)$year && $exist_m > (int)$Month)) {
                            $exist_status = false;
                        }
                        // If same month but exited before current day → inactive for remaining days
                        elseif ($exist_y === (int)$year && $exist_m === (int)$Month && $exist_d > (int)$day) {
                            $exist_status = false;
                        }

                        $exit_staff_details[$day][$lead_type_id] = [
                            'exist_status' => $exist_status,
                            'exist_date'   => $exist_date
                        ];

                        $exit_status_staffs[$lead_type_id] = $exist_status;
                    }
                    
                    $paymentSums = isset($result['daily'][$lead_type_id]) && !empty($result['daily'][$lead_type_id]) ? $result['daily'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$Month][$day]['leave_abs_count']) ? $paymentSums[$year][$Month][$day]['leave_abs_count'] : 0;
                    
                    $earned_per = isset($paymentSums[$year][$Month][$day]['present_percentage']) ? $paymentSums[$year][$Month][$day]['present_percentage'] : 0;

                    $holiday_status = isset($paymentSums[$year][$Month][$day]['holiday_status']) ? $paymentSums[$year][$Month][$day]['holiday_status'] : false;
                    
                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$day][$lead_type_id] = $count;
                    $percentages[$day][$lead_type_id] = $earned_per;
                    $holiday_status_staffs[$day][$lead_type_id] = $holiday_status;
                    
                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay]['leave_abs_count']) ? $paymentSums[$prevYear][$prevMonth][$prevDay]['leave_abs_count'] : 0;

                    $preleadData[$prevDay][$lead_type_id] = $pre_count;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));
                        $doj_d = (int) date('j', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int)$year) {

                            // Same month
                            if ((int)$Month === $doj_m) {
                                if ($day >= $doj_d) {
                                    $doj_status = true;
                                }
                            }

                            // Month after DOJ month (still same year)
                            elseif ((int)$Month > $doj_m) {
                                $doj_status = true;
                            }

                            // Month before DOJ month → false
                            else {
                                $doj_status = false;
                            }
                        }

                        // Case 2: DOJ is before this year → always true
                        elseif ($doj_y < $year) {
                            $doj_status = true;
                        }

                        // Case 3: DOJ is after this year → always false
                        else {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$day][$lead_type_id] = [
                        'doj_status' => $doj_status,
                    ];

                    // $dayTotals[$day] = $dayTotal;
                }
                
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'staff_details' => $leadTypesMapped,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'holiday_status_staffs' => $holiday_status_staffs,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function GetFacultyDetails(int $branch_id, int $is_existing_val = 2)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $dailyData   = [];
            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];

            // --- Fetch job positions ---
            $job_positions = DB::table('et_job_position')
                ->where('department_id', 2)
                ->where('status', '!=', 2)
                ->get();

            // $list = [];

            foreach ($job_positions as $position) {

                // --- Fetch staff under this position ---
                $staff_list = DB::table('et_staff')
                    ->where('branch_id', $branch_id)
                    ->where('position_role', $position->sno)
                    ->where('department_id', 2)
                    ->where(function($query) use ($currentYear, $currentMonth, $is_existing_val) {
                        if($is_existing_val == 2){
                            $query->where(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 4)
                                ->whereYear('notice_end_date', '>=', $currentYear)
                                ->whereMonth('notice_end_date', '>=', $currentMonth);
                            })
                            ->orWhere(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 5)
                                ->whereYear('updated_at', '>=', $currentYear)
                                ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 6)
                                ->whereYear('staff_last_date', '>=', $currentYear)
                                ->whereMonth('staff_last_date', '>=', $currentMonth);
                            })
                            ->orWhere(function($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 7)
                                ->whereYear('updated_at', '>=', $currentYear)
                                ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhereIn('status', [0,1]);
                        }else{
                            $query->where('status','!=',2);
                        }
                    })
                    ->orderBy('sno', 'desc')
                    ->get();

                // $list[] = $staff_list;

                // --- Loop staff for daily counts ---
                foreach ($staff_list as $staff) {
                    
                    if (empty($staff->date_of_joining)) continue;

                    $staffStart = date('Y-m-d', strtotime($staff->date_of_joining));

                    $staffEnd   = $currentDate;

                    $loopDate = $staffStart;

                    while ($loopDate <= $staffEnd) {

                        $y = (int) date('Y', strtotime($loopDate));
                        $m = (int) date('n', strtotime($loopDate));
                        $d = (int) date('j', strtotime($loopDate));

                        if (!isset($dailyData[$position->sno][$y][$m][$d])) {

                            $dailyData[$position->sno][$y][$m][$d] = [
                                'staff_count' => 0
                            ];
                        }

                        // --- Staff count ---
                        $dailyData[$position->sno][$y][$m][$d]['staff_count']++;
                        $years[$y] = $y;

                        $loopDate = date('Y-m-d', strtotime($loopDate . ' +1 day'));
                    }
                }
            }

            // return $list;

            // --- Monthly aggregation including attendance ---
            foreach ($dailyData as $positionId => $yearsData) {
                foreach ($yearsData as $year => $months) {
                    foreach ($months as $month => $days) {
                        $lastDay = (int) date('t', strtotime("$year-$month-01"));
                        if ($year == $currentYear && $month == $currentMonth) {
                            $lastDay = (int) date('j', strtotime($currentDate));
                        }

                        $monthlyData[$positionId][$year][$month] = [
                            'staff_count' => $days[$lastDay]['staff_count'] ?? 0
                        ];
                    }
                }
            }

            // --- Yearly aggregation including attendance ---
            foreach ($monthlyData as $positionId => $yearsData) {

                foreach ($yearsData as $year => $months) {

                    $lastMonth = ($year == $currentYear)
                    ? $currentMonth
                    : max(array_keys($months));

                    $yearlyData[$positionId][$year] = [
                        'staff_count'          => $months[$lastMonth]['staff_count'] ?? 0
                    ];
                }
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyDetails: " . $e->getMessage());
            return null;
        }
    }

    private function GetFacultyAttendanceDetails(int $branch_id,$search_lead_src_fill = null,int $is_existing_val = 2,int $year) 
    {
        try {
            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $staff_details = [];
            $dailyData     = [];
            $monthlyData   = [];
            $yearlyData    = [];
            $years         = [];

            // Get months for given year
            $months = $this->getYearBasedMonths($year);

            // --- Fetch faculty job positions ---
            $job_positions = DB::table('et_job_position')
                ->where('department_id', 2)
                ->where('status', '!=', 2)
                ->get();

            $job_positionsIds = $job_positions->pluck('sno')->toArray();

            // --- Fetch faculty/staff list ---
            $staff_query = DB::table('et_staff')
                ->join('et_user_role', 'et_user_role.sno', '=', 'et_staff.role_id')
                ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
                ->where('et_staff.branch_id', $branch_id)
                ->whereIn('et_staff.position_role', $job_positionsIds);

            // Existing / active staff filter
            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 4)
                            ->whereYear('et_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('et_staff.notice_end_date', '>=', $currentMonth);
                    })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 5)
                                ->whereYear('et_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 6)
                                ->whereYear('et_staff.staff_last_date', '>=', $currentYear)
                                ->whereMonth('et_staff.staff_last_date', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 7)
                                ->whereYear('et_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere('et_staff.status', 0);
                });
            } else {
                $staff_query->where('et_staff.status', '!=', 2);
            }

            // Search filter
            if (!empty($search_lead_src_fill)) {
                $staff_query->whereIn('et_staff.sno', $search_lead_src_fill);
            }

            // Get staff data
            $staff_list = $staff_query->orderBy('et_staff.staff_name', 'asc')->get([
                'et_staff.*',
                'et_user_role.role_name',
                'et_job_position.job_position_name'
            ]);

            // --- Loop through each staff ---
            foreach ($staff_list as $staff) {

                $staffId = $staff->sno;

                $staff_details[$staffId] = [
                    'staff_name'      => $staff->staff_name ?? 'None',
                    'staff_position'  => (isset($staff->job_position_name) && !empty($staff->job_position_name)
                        ? $staff->job_position_name
                        : ($staff->role_name ?? 'None')),
                    'doj'             => $staff->date_of_joining ?? null,
                    'staff_full_name' => ($staff->staff_name ?? 'None') . ' (' . ($staff->role_name ?? 'None') . ')',
                    'exist_status'    => in_array($staff->status, [4, 5, 6, 7]),
                    'exist_date'      => match ($staff->status) {
                        4 => $staff->notice_end_date,
                        5 => $staff->updated_at,
                        6 => $staff->staff_last_date,
                        7 => $staff->updated_at,
                        default => null,
                    },
                ];

                $year_start = "$year-01-01";
                $year_end   = "$year-12-31";

                // --- Attendance Base Query ---
                $attBaseQuery = DB::table('et_staff_attendance')
                    ->where('branch_id', $branch_id)
                    ->where('staff_id', $staffId)
                    ->whereBetween('date', [$staff->date_of_joining ?? $year_start, $staff_details[$staffId]['exist_date'] ?? date('Y-m-d')]);

                // --- Yearly Data ---
                $yearQuery = clone $attBaseQuery;
                $yearQuery->whereBetween('date', [$year_start, $year_end]);

                $total_attendance = $yearQuery->count();
                $attTypeWise      = $yearQuery->select('attendance', DB::raw('COUNT(*) as count'))
                    ->groupBy('attendance')->pluck('count', 'attendance')->toArray();

                $present_count      = $attTypeWise['P'] ?? 0;
                $leave_abs_count    = ($attTypeWise['L'] ?? 0) + ($attTypeWise['A'] ?? 0);
                $present_percentage = $total_attendance > 0 ? round(($present_count / $total_attendance) * 100, 2) : 0;
                $holiday_status = isset($attTypeWise['HD']) && !empty($attTypeWise['HD']) ? true : false;

                $yearlyData[$staffId][$year] = [
                    'total_attendance'   => $total_attendance,
                    'att_type_wise'      => $attTypeWise,
                    'present_count'      => $present_count,
                    'leave_abs_count'    => $leave_abs_count,
                    'present_percentage' => $present_percentage,
                    'holiday_status' => $holiday_status,
                ];

                // --- Monthly & Daily Data (Optimized) ---
                foreach ($months as $monthNum => $monthName) {

                    $month_start = date('Y-m-01', strtotime("$year-$monthNum-01"));
                    $month_end   = date('Y-m-t', strtotime("$year-$monthNum-01"));

                    // 🔹 Fetch all attendance in one go for this month
                    $monthRecords = (clone $attBaseQuery)
                        ->whereBetween('date', [$month_start, $month_end])
                        ->select('date', 'attendance')
                        ->get();

                    // Group data by day
                    $dailyGrouped = $monthRecords->groupBy(function ($item) {
                        return date('j', strtotime($item->date)); // day number
                    });

                    // --- Monthly Aggregation ---
                    $total_attendance_m = $monthRecords->count();
                    $attTypeWise_m      = $monthRecords->groupBy('attendance')->map->count()->toArray();

                    $present_count_m      = $attTypeWise_m['P'] ?? 0;
                    $leave_abs_count_m    = ($attTypeWise_m['L'] ?? 0) + ($attTypeWise_m['A'] ?? 0);
                    $present_percentage_m = $total_attendance_m > 0 ? round(($present_count_m / $total_attendance_m) * 100, 1) : 0;
                    $holiday_status_m = isset($attTypeWise_m['HD']) && !empty($attTypeWise_m['HD']) ? true : false;

                    $monthlyData[$staffId][$year][$monthNum] = [
                        'total_attendance'   => $total_attendance_m,
                        'att_type_wise'      => $attTypeWise_m,
                        'present_count'      => $present_count_m,
                        'leave_abs_count'    => $leave_abs_count_m,
                        'present_percentage' => $present_percentage_m,
                        'holiday_status' => $holiday_status_m,
                    ];

                    // --- Daily Breakdown from grouped data ---
                    foreach ($dailyGrouped as $day => $records) {

                        $attTypeWise_d = $records->groupBy('attendance')->map->count()->toArray();

                        $total_attendance_d   = count($records);
                        $present_count_d      = $attTypeWise_d['P'] ?? 0;
                        $leave_abs_count_d    = ($attTypeWise_d['L'] ?? 0) + ($attTypeWise_d['A'] ?? 0);
                        $present_percentage_d = $total_attendance_d > 0 ? round(($present_count_d / $total_attendance_d) * 100, 2) : 0;
                        $holiday_status_d = isset($attTypeWise_d['HD']) && !empty($attTypeWise_d['HD']) ? true : false;

                        $dailyData[$staffId][$year][$monthNum][$day] = [
                            'total_attendance'   => $total_attendance_d,
                            'att_type_wise'      => $attTypeWise_d,
                            'present_count'      => $present_count_d,
                            'leave_abs_count'    => $leave_abs_count_d,
                            'present_percentage' => $present_percentage_d,
                            'holiday_status' => $holiday_status_d,
                        ];
                    }
                }
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly'        => $yearlyData,
                'monthly'       => $monthlyData,
                'daily'         => $dailyData,
                'staff_details' => $staff_details,
                'years'         => array_values(array_unique([$year])),
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyStudentsDetails: " . $e->getMessage());
            return null;
        }
    }

    public function GetFacultyRevenueDetails(int $branch_id = 1, $search_lead_src_fill = null, int $is_existing_val = 2)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $staff_details   = [];
            $dailyData   = [];
            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];
            
            // --- Fetch faculty job positions ---
            $job_positions = DB::table('et_job_position')
                ->where('department_id', 2)
                ->where('status', '!=', 2)
                ->get();

            $job_positionsIds = $job_positions->pluck('sno')->toArray();

            // --- Fetch faculty/staff list ---
            $staff_query = DB::table('et_staff')
                ->join('et_user_role', 'et_user_role.sno', '=', 'et_staff.role_id')
                ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
                ->where('et_staff.branch_id', $branch_id)
                ->whereIn('et_staff.position_role', $job_positionsIds);

            // Existing / active staff filter
            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('et_staff.status', 4)
                            ->whereYear('et_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('et_staff.notice_end_date', '>=', $currentMonth);
                    })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 5)
                                ->whereYear('et_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 6)
                                ->whereYear('et_staff.staff_last_date', '>=', $currentYear)
                                ->whereMonth('et_staff.staff_last_date', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('et_staff.status', 7)
                                ->whereYear('et_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere('et_staff.status', 0);
                });
            } else {
                $staff_query->where('et_staff.status', '!=', 2);
            }

            // Search filter
            if (!empty($search_lead_src_fill)) {
                $staff_query->whereIn('et_staff.sno', $search_lead_src_fill);
            }

            // Get staff data
            $staff_list = $staff_query->orderBy('staff_name', 'asc')->get([
                'et_staff.*',
                'et_user_role.role_name',
                'et_job_position.job_position_name'
            ]);

            // --- Loop staff for daily counts ---
            foreach ($staff_list as $staff) {

                if(!isset($staff_details[$staff->sno])){
                    $staff_details[$staff->sno] = [];
                }

                $staff_details[$staff->sno] = [
                    // 'staff_name' => $staff->staff_name ?? 'None',
                    // 'staff_position' => $position->job_position_name ?? 'None',
                    // 'staff_full_name' => $staff->staff_name.' ('.$position->job_position_name.')' ?? 'None',
                    'staff_name'      => $staff->staff_name ?? 'None',
                    'staff_position'  => (isset($staff->job_position_name) && !empty($staff->job_position_name)
                        ? $staff->job_position_name
                        : ($staff->role_name ?? 'None')),
                    'doj'             => $staff->date_of_joining ?? null,
                    'staff_full_name' => ($staff->staff_name ?? 'None') . ' (' . (isset($staff->job_position_name) && !empty($staff->job_position_name)
                        ? $staff->job_position_name
                        : ($staff->role_name ?? 'None')) . ')',
                    'exist_status'    => in_array($staff->status, [4, 5, 6, 7]),
                    'exist_date'      => match ($staff->status) {
                        4 => $staff->notice_end_date,
                        5 => $staff->updated_at,
                        6 => $staff->staff_last_date,
                        7 => $staff->updated_at,
                        default => null,
                    },
                ];
            }

            $result = $this->get_faculty_revenue_data(null,$branch_id,null);
            
            // return $result;

            return [
                'yearly'  => isset($result['yearly']) && !empty($result['yearly']) ? $result['yearly'] : [],
                'monthly' => isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [],
                'daily'   => isset($result['daily']) && !empty($result['daily']) ? $result['daily'] : [],
                'staff_details'   => $staff_details,
                'years'   => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyRevenueDetails: " . $e->getMessage());
            return null;
        }
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    public function get_faculty_positions_list()
    {
        $LeadTypeModelList = JobpositionModel::where('department_id', 2)
                                ->where('status', '!=', 2)
                                ->orderBy('job_position_name', 'asc')->get();
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $LeadTypeModelList
        ], 200);
    }

    public function getProductionStaffList(Request $request)
    {
        $currentDate = date('Y-m-d');
        $currentYear = (int) date('Y');
        $currentMonth = (int) date('n');

        $is_existing_val = (int) $request->checked_val ?? 2;

        $user = $request->user();
        $user_id = $user->user_id;
        $branch_id = $user->branch_id;

        $staff_details = [];

        $job_positions = DB::table('et_job_position')
            ->where('department_id', 2)
            ->where('status', '!=', 2)
            ->get();

        foreach ($job_positions as $position) {

            // --- Fetch staff under this position ---
            $staff_list = DB::table('et_staff')
                ->where('branch_id', $branch_id)
                ->where('position_role', $position->sno)
                // ->where('role_id', 22)
                // ->where('et_staff.status', 0)
                ->where(function ($query) use ($currentYear, $currentMonth, $is_existing_val) {
                    if ($is_existing_val == 2) {
                        $query->where(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('status', 4)
                                ->whereYear('notice_end_date', '>=', $currentYear)
                                ->whereMonth('notice_end_date', '>=', $currentMonth);
                        })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 5)
                                    ->whereYear('updated_at', '>=', $currentYear)
                                    ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 6)
                                    ->whereYear('staff_last_date', '>=', $currentYear)
                                    ->whereMonth('staff_last_date', '>=', $currentMonth);
                            })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 7)
                                    ->whereYear('updated_at', '>=', $currentYear)
                                    ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere('status', 0);
                    } else {
                        $query->where('status', '!=', 2);
                    }
                })
                ->orderBy('staff_name', 'asc')
                ->get();

            $staff_list = $staff_list->unique('staff_id');

            // --- Loop staff for daily counts ---
            foreach ($staff_list as $staff) {

                if (!isset($staff_details[$staff->sno])) {
                    $staff_details[$staff->sno] = [];
                }

                $staff_details[$staff->sno] = [
                    'sno' => $staff->sno ?? 0,
                    'staff_name' => $staff->staff_name ?? 'None',
                    'staff_position' => $position->job_position_name ?? 'None',
                    'staff_full_name' => $staff->staff_name . ' (' . $position->job_position_name . ')' ?? 'None',
                ];
            }
        }

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => array_values($staff_details)
        ], 200);
    }

    private function generateNavHtml()
    {

        $menus =  [
            [
                'title' => 'Positions Vs Staffs',
                'url' => url('/manage_reports/faculty_yearly'),
                'is_active' => request()->is([
                    'manage_reports/faculty_yearly*',
                    'manage_reports/faculty_monthly*'
                ]),
            ],
            [
                'title' => 'Production Vs Revenue',
                'url' => url('/manage_reports/faculty_revenue_yearly'),
                 'is_active' => request()->is([
                    'manage_reports/faculty_revenue_yearly*',
                    'manage_reports/faculty_revenue_monthly*'
                ]),
            ],
            [
                'title' => 'Production Vs Attendance %',
                'url' => url('/manage_reports/faculty_attendance_yearly'),
                'is_active' => request()->is([
                    'manage_reports/faculty_attendance_yearly*',
                    'manage_reports/faculty_attendance_monthly*'
                ]),
            ]
        ];

        $html = '<div class="w-50 nav-align-top mb-2"><div class="nav-align-top mb-2">';
        $html .= '<ul class="nav nav-pills flex-nowrap" role="tablist">
            <div class="scroll-container-wrapper">
                <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                <div class="scroll-container" id="scrollContainer">';

        foreach ($menus as $menu) {

            $active = $menu['is_active'] ? 'active' : '';

            $html .= "<div class='item'><li class='nav-item'>
                    <a href='{$menu['url']}' class='nav-link text-capitalize {$active}'>
                        {$menu['title']}
                    </a>
                </li></div>
            ";
        }

        $html .= '</div><button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button></div></ul></div></div>';

        return $html;
    }
    
    private function get_faculty_revenue_data($staffId = null, $branchId = null, $yearOrMonth = null)
    {

        try {

            /* ---------------- VALIDATION ---------------- */

            if ($staffId !== null && !is_numeric($staffId)) {
                return ['status'=>false,'message'=>'Invalid staffId'];
            }

            if ($branchId !== null && !is_numeric($branchId)) {
                return ['status'=>false,'message'=>'Invalid branchId'];
            }

            if ($yearOrMonth !== null) {
                if (!preg_match('/^\d{4}$/', $yearOrMonth) && !preg_match('/^\d{4}\-\d{2}$/', $yearOrMonth)) {
                    return ['status'=>false,'message'=>'Invalid year or year-month format'];
                }
            }

            /* ---------------- WHERE ---------------- */

            $bindings = [];
            $where = " WHERE dt.status = 0 AND tr.transaction_type='credit' ";

            if ($staffId) {
                $where .= " AND dt.staff_id = ? ";
                $bindings[] = $staffId;
            }

            if ($branchId) {
                $where .= " AND t.branch_id = ? ";
                $bindings[] = $branchId;
            }

            if ($yearOrMonth) {
                if (strlen($yearOrMonth) == 4) {
                    $where .= " AND YEAR(tr.transaction_date) = ? ";
                    $bindings[] = $yearOrMonth;
                } else {
                    $where .= " AND DATE_FORMAT(tr.transaction_date,'%Y-%m') = ? ";
                    $bindings[] = $yearOrMonth;
                }
            }

            /* ---------------- SQL ---------------- */

            $sql = "
            SELECT 
                final.staff_id,
                final.txn_date,
                YEAR(final.txn_date) yr,
                MONTH(final.txn_date) mn,
                DAY(final.txn_date) dy,
                final.staff_revenue,
                final.staff_cost,
                final.task_hours,
                final.task_id

            FROM
            (
                SELECT 
                    dt.staff_id,
                    dt.task_id,
                    dt.task_hours,
                    t.per_hour_cost,
                    DATE(tr.transaction_date) txn_date,

                    CASE 
                        WHEN proposal.currency_id = 70 
                        THEN tr.total_amount
                        ELSE tr.total_amount_inr
                    END AS milestone_amount,

                    (
                        SELECT COUNT(DISTINCT t2.sno)
                        FROM et_task t2
                        WHERE JSON_CONTAINS(mm.task_ids, CONCAT('\"', t2.task_name, '\"'))
                    ) AS milestone_task_count,

                    (
                        SELECT COUNT(DISTINCT dt2.staff_id)
                        FROM et_daily_tasks dt2
                        WHERE dt2.task_id = t.sno
                    ) AS task_staff_count,

                    (
                        (
                            CASE 
                                WHEN proposal.currency_id = 70 
                                THEN tr.total_amount
                                ELSE tr.total_amount_inr
                            END
                        )
                        /
                        (
                            SELECT COUNT(DISTINCT t2.sno)
                            FROM et_task t2
                            WHERE JSON_CONTAINS(mm.task_ids, CONCAT('\"', t2.task_name, '\"'))
                        )
                    )
                    /
                    (
                        SELECT COUNT(DISTINCT dt2.staff_id)
                        FROM et_daily_tasks dt2
                        WHERE dt2.task_id = t.sno
                    )
                    AS staff_revenue,

                    (dt.task_hours * t.per_hour_cost) AS staff_cost

                FROM et_daily_tasks dt
                JOIN et_task t ON t.sno = dt.task_id
                JOIN et_milestone_mapping mm 
                    ON JSON_CONTAINS(mm.task_ids, CONCAT('\"', t.task_name, '\"'))
                JOIN et_proposal_pay_slot ps ON ps.sno = mm.milestone_id
                JOIN et_proposal proposal ON proposal.sno = ps.proposal_sno
                JOIN et_payment pay ON pay.pay_slot_id = ps.sno
                JOIN et_transaction tr 
                    ON tr.payment_id = pay.sno
                    AND tr.transaction_type='credit'

                $where

            ) final
            ";

            /* ---------------- QUERY EXECUTE ---------------- */

            $rows = \DB::select($sql, $bindings);

            /* ---------------- EMPTY CHECK ---------------- */

            if (!$rows) {
                return [
                    'status' => true,
                    'message' => 'No data found',
                    'yearly'=>[],
                    'monthly'=>[],
                    'daily'=>[]
                ];
            }

            /* ---------------- BUILD ARRAYS ---------------- */

            $yearly = [];
            $monthly = [];
            $daily = [];

            foreach ($rows as $r) {

                $s = $r->staff_id;
                $y = $r->yr;
                $m = $r->mn;
                $d = $r->dy;

                // yearly
                $yearly[$s][$y]['revenue'] = ($yearly[$s][$y]['revenue'] ?? 0) + $r->staff_revenue;
                $yearly[$s][$y]['cost']    = ($yearly[$s][$y]['cost'] ?? 0) + $r->staff_cost;
                $yearly[$s][$y]['profit']  = ($yearly[$s][$y]['profit'] ?? 0) + ($r->staff_revenue - $r->staff_cost);
                $yearly[$s][$y]['production_percentage'] = $yearly[$s][$y]['profit'] > 0 ? round(($yearly[$s][$y]['revenue'] / $yearly[$s][$y]['profit']) * 100, 2) : 0;

                // monthly
                $monthly[$s][$y][$m]['revenue'] = ($monthly[$s][$y][$m]['revenue'] ?? 0) + $r->staff_revenue;
                $monthly[$s][$y][$m]['cost']    = ($monthly[$s][$y][$m]['cost'] ?? 0) + $r->staff_cost;
                $monthly[$s][$y][$m]['profit']  = ($monthly[$s][$y][$m]['profit'] ?? 0) + ($r->staff_revenue - $r->staff_cost);
                $monthly[$s][$y][$m]['production_percentage'] = $monthly[$s][$y][$m]['profit'] > 0 ? round(($monthly[$s][$y][$m]['revenue'] / $monthly[$s][$y][$m]['profit']) * 100, 2) : 0;

                // daily
                $daily[$s][$y][$m][$d]['revenue'] = ($daily[$s][$y][$m][$d]['revenue'] ?? 0) + $r->staff_revenue;
                $daily[$s][$y][$m][$d]['cost']    = ($daily[$s][$y][$m][$d]['cost'] ?? 0) + $r->staff_cost;
                $daily[$s][$y][$m][$d]['profit']  = ($daily[$s][$y][$m][$d]['profit'] ?? 0) + ($r->staff_revenue - $r->staff_cost);
                $daily[$s][$y][$m][$d]['production_percentage'] = $daily[$s][$y][$m][$d]['profit'] > 0 ? round(($daily[$s][$y][$m][$d]['revenue'] / $daily[$s][$y][$m][$d]['profit']) * 100, 2) : 0;
            }

            // return $yearly;

            return [
                'status'=>true,
                'yearly'=>$yearly,
                'monthly'=>$monthly,
                'daily'=>$daily
            ];

        } catch (\Illuminate\Database\QueryException $e) {

            \Log::error('Revenue SQL Error', [
                'msg'=>$e->getMessage(),
                'sql'=>$e->getSql() ?? '',
            ]);

            return [
                'status'=>false,
                'message'=>'Database error',
            ];

        } catch (\Throwable $e) {

            \Log::error('Revenue System Error', [
                'msg'=>$e->getMessage(),
            ]);

            return [
                'status'=>false,
                'message'=>'System error'
            ];
        }
    }
}
