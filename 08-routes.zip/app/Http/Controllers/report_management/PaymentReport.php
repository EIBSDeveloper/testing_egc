<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\ManageInternModel;
use App\Models\CustomerModel;
use App\Models\BranchModel;
use App\Models\TransactionModel;
use App\Models\ManageTargetModel;

class PaymentReport extends Controller
{
    public static $report_heading = 'Analysis';
    protected static $temp = [];

    public function index()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.payment_report.payment_collection_yr_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function PaymentCollectionYearData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];
           
            $types_list = [
                'collection_sale' => 'Collection',
                'target_sale' => 'Target'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $monthly_target_data   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];
            $grandTotalAll = 0;

            $result = $this->getPostPreSalesData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;
            
            // Step 1: Extract years from result safely
            // $presale_years = isset($result['pre_sale']['years']) && !empty($result['pre_sale']['years']) ? collect($result['pre_sale']['years']) : collect();
            
            // $postsale_years = isset($result['post_sale']['years']) && !empty($result['post_sale']['years']) ? collect($result['post_sale']['years']) : collect();

            // $targetsale_years = isset($result['target_sale']['years']) && !empty($result['target_sale']['years']) ? collect($result['target_sale']['years']) : collect();
                        
            // Step 2: Merge, deduplicate, sort
            $collectionYears =  isset($result['years']) && !empty($result['years']) ? collect($result['years']) : collect();

            $allYears = $collectionYears->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            // return $result;

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        foreach ($types_list as $type_key => $type_name) {

                            $paymentSums = isset($result[$type_key]) && !empty($result[$type_key]) ? $result[$type_key] : [];

                            $yearhly_target_data = isset($paymentSums['yearly']) ? $paymentSums['yearly'] : [];

                            if ($type_key == 'target_sale') {

                                $monthly_target_data = isset($paymentSums['monthly']) ? $paymentSums['monthly'] : [];

                                $amount = isset($monthly_target_data[$year][$monthNum]) ? round($monthly_target_data[$year][$monthNum], 2) : 0;

                            } else {
                                $amount = isset($paymentSums['monthly'][$year][$monthNum]) ? round($paymentSums['monthly'][$year][$monthNum]) : 0;
                            }

                            // Save raw daily data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){
                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($totals[$year][$type_key] ?? 0) + $amount;

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $typeMonthTotals[$type_key][$year] = ($typeMonthTotals[$type_key][$year] ?? 0) + $amount;

                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;

                                $grandTotalAll += $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'monthly_target_data' => $yearhly_target_data,
                'year' => $year,
                'years' => $years,
                'year_colors' => $year_colors,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function payment_collection_monthly()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $days = range(1, 31);

        return view('content.report_management.payment_report.payment_collection_month_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);

    }

    public function PaymentCollectionMonthData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getPostPreSalesData($branch_id);

            // return $result;

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            $types_list = [
                'collection_sale' => 'Collection',
                'target_sale' => 'Target'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $monthly_target_data   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];
            $grandTotalAll = 0;

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($days as $day) {

                    $day_format = str_pad($day, 2, '0', STR_PAD_LEFT);
                    $month_format = str_pad($monthNum, 2, '0', STR_PAD_LEFT);

                    $date_format = $day_format . '-' . $month_format . '-' . $year;

                    foreach ($types_list as $type_key => $type_name) {

                        $paymentSums = isset($result[$type_key]) && !empty($result[$type_key]) ? $result[$type_key] : [];

                        if ($type_key == 'target_sale') {

                            $monthly_target_data = isset($paymentSums['monthly']) ? $paymentSums['monthly'] : [];

                            // if($day != 1){
                            //     $amount = isset($paymentSums['daily'][$year][$monthNum][$day]) ? round($paymentSums['daily'][$year][$monthNum][$day], 2) : 0;
                            //     $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) ? round($paymentSums['daily'][$pre_year][12][$pre_daysInMonth], 2) : 0;
                            // }else{
                                $amount = isset($paymentSums['daily'][$year][$monthNum][$day]) ? $paymentSums['daily'][$year][$monthNum][$day] : 0;
                                $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) ? $paymentSums['daily'][$pre_year][12][$pre_daysInMonth] : 0;
                            // }

                        } else {

                            $amount = isset($paymentSums['daily'][$year][$monthNum][$day]) ? round($paymentSums['daily'][$year][$monthNum][$day]) : 0;

                            $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) ? round($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) : 0;

                        }

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $Trend_data_list[$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = ($totals[$monthNum][$type_key] ?? 0) + $amount;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + $amount;

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = ($typeMonthTotals[$type_key][$monthNum] ?? 0) + $amount;

                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;

                        $grandTotalAll += $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'monthly_target_data' => $monthly_target_data,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function pre_post_yearly()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.payment_report.pre_post_collection_yr_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function PrePostYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $types_list = [
                'pre_sale' => 'Pre Sale Collection', 
                'post_sale' => 'Post Sale Collection',
                // 'closed_sale' => 'Others'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $grandTotalAll = 0;

            $result = $this->getPostPreSalesDataNew($request);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            // Step 1: Extract years from result safely
            $presale_years = isset($result['years']) && !empty($result['years']) ? collect($result['years']) : collect();
            
            // $postsale_years = isset($result['post_sale']['years']) && !empty($result['post_sale']['years']) ? collect($result['post_sale']['years']) : collect();
                        
            // Step 2: Merge, deduplicate, sort
            $allYears = $presale_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            // return $finalYears;
            $days = range(1, 31);

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){

                    $pre_year  = (int)$year - 1;

                    foreach ($months as $monthNum => $monthName) {

                        $Trend_data_list = [];

                        foreach ($types_list as $type_key => $type_name) {
                            
                            $paymentSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];
                            
                            $amount = isset($paymentSums[$type_key][$year][$monthNum]) ? round($paymentSums[$type_key][$year][$monthNum]) : 0;

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($totals[$year][$type_key] ?? 0) + $amount;

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $typeMonthTotals[$type_key][$year] = ($typeMonthTotals[$type_key][$year] ?? 0) + $amount;
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;

                                $grandTotalAll += $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }

                }
            }
            
            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'years' => $years,
                'year_colors' => $year_colors,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function pre_post_monthly()
    {
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        $days = range(1, 31);

        return view('content.report_management.payment_report.pre_post_collection_month_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function PrePostMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;
    
            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y',strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year,2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getPostPreSalesDataNew($request);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $types_list = [
                'pre_sale' => 'Pre Sale Collection', 
                'post_sale' => 'Post Sale Collection',
                // 'closed_sale' => 'Others'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $grandTotalAll = 0;

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                    foreach ($types_list as $type_key => $type_name) {
                        
                        $paymentSums = isset($result['daily']) && !empty($result['daily']) ? $result['daily'] : [];

                        $amount = isset($paymentSums[$type_key][$year][$monthNum][$day]) ? round($paymentSums[$type_key][$year][$monthNum][$day]) : 0;
                        
                        $pre_amount = isset($paymentSums[$type_key][$pre_year][12][$pre_daysInMonth]) ? round($paymentSums[$type_key][$pre_year][12][$pre_daysInMonth]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $Trend_data_list[$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = ($totals[$monthNum][$type_key] ?? 0) + $amount;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + $amount;

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = ($typeMonthTotals[$type_key][$monthNum] ?? 0) + $amount;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;

                        $grandTotalAll += $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            // 🔹 Percentages
            foreach ($months as $monthNum => $monthName) {
                foreach ($days as $day) {
                    foreach ($types_list as $type_key => $type_name) {

                        $monthTotal = $totals[$monthNum][$type_key] ?? 0;
                        $amount     = $data[$monthNum][$day][$type_key] ?? 0;

                        $percentages[$monthNum][$day][$type_key] = $monthTotal > 0
                            ? round(($amount / $monthTotal) * 100, 2)
                            : 0;
                    }
                }
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function drop_payment_yearly()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];
        return view('content.report_management.payment_report.drop_payment_yr_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function DropPaymentYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $result = $this->getOutstandingMonthlyData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // Step 1: Extract years from result safely
            $collection_years = isset($result['out_rejected']['years']) && !empty($result['out_rejected']['years'])
                ? collect($result['out_rejected']['years'])
                : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data             = [];
            $Trend_data       = [];
            $pre_data         = [];
            $percentages      = [];
            $grandMonthTotals = []; // per month (all types)
            $grandDayTotals   = [];
            $grandAllTotal    = 0;

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){

                    $pre_year  = (int)$year - 1;

                    $paymentSums = isset($result['out_rejected']) && !empty($result['out_rejected']) ? $result['out_rejected'] : [];

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {
                        
                        if((int)$monthNum > $currentMonth){
                            $amount = 0;
                        }else{
                            $amount = isset($paymentSums['monthTotals'][$year][$monthNum]) ? round($paymentSums['monthTotals'][$year][$monthNum]) : 0;
                        }
                            

                        // Save raw daily data
                        $data[$year][$monthNum] = $amount;

                        if($year_index != 0){

                            $Trend_data_list[$monthNum] = $amount;

                            // Month grand total
                            $grandMonthTotals[$year] = ($grandMonthTotals[$year] ?? 0) + $amount;

                            // Day totals across months
                            $grandDayTotals[$monthNum] = ($grandDayTotals[$monthNum] ?? 0) + $amount;

                            $grandAllTotal += $grandDayTotals[$monthNum] ?? 0;
                        }
                        
                    }

                    if($year_index != 0){
                        $Trend_data[$year] = $Trend_data_list;
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'year_colors' => $year_colors,
                'years' => $years
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function drop_payment_monthly()
    {
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        $days = range(1, 31);

        return view('content.report_management.payment_report.drop_payment_monthly_list', compact('months','days'))->with('report_heading', self::$report_heading);
    }

    public function DropPaymentMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;
    
            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y',strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year,2);

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getOutstandingMonthlyData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $paymentSums = isset($result['out_rejected']) && !empty($result['out_rejected']) ? $result['out_rejected'] : [];

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $percentages     = [];
            $grandMonthTotals     = []; // per month (all types)
            $grandDayTotals = [];
            $grandAllTotal = 0; 

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                        
                    $amount = isset($paymentSums['dayTotals'][$year][$monthNum][$day]) ? round($paymentSums['dayTotals'][$year][$monthNum][$day]) : 0;
                    
                    $pre_amount = isset($paymentSums['dayTotals'][$pre_year][12][$pre_daysInMonth]) ? round($paymentSums['dayTotals'][$pre_year][12][$pre_daysInMonth]) : 0;

                    // Save raw daily data
                    $data[$monthNum][$day] = $amount;

                    $Trend_data_list[$day] = $amount;

                    $pre_data[12][$pre_daysInMonth] = $pre_amount;

                    // Month grand total
                    $grandMonthTotals[$monthNum] = ($grandMonthTotals[$monthNum] ?? 0) + $amount;

                    // Day totals across months
                    $grandDayTotals[$day] = ($grandDayTotals[$day] ?? 0) + $amount;
                }

                $Trend_data[$monthName] = $Trend_data_list;
            }

            // 🔹 Percentages
            foreach ($months as $monthNum => $monthName) {
                $monthTotal = $grandMonthTotals[$monthNum] ?? 0;
                $grandAllTotal += $monthTotal;
                foreach ($days as $day) {
                    $amount     = $data[$monthNum][$day] ?? 0;
                    $percentage_val = $monthTotal > 0 ? round(($amount / $monthTotal) * 100) : 0;
                    $percentages[$monthNum][$day] = $percentage_val > 100 ? 100 : $percentage_val;
                }
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'year' => $year
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function outstanding_yearly()
    {
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.payment_report.outstanding_yr_list', compact(
            'months',
        ))->with('report_heading', self::$report_heading);
    }

    public function OutstandingYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $result = $this->getOutstandingMonthlyData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;
            
            // Step 1: Extract years from result safely
            $collection_years = isset($result['collection']['years']) && !empty($result['collection']['years'])
                ? collect($result['collection']['years'])
                : collect();

            $payment_years = isset($result['payment']['years']) && !empty($result['payment']['years'])
                ? collect($result['payment']['years'])
                : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->merge($payment_years)->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $types = ['Payment', 'Collection'];

            $type_keys = array_map(fn($type) => $this->slugify($type), $types);

            $types_list = array_combine($type_keys, $types);

            $type_count = !empty($types) && is_array($types) ? count($types) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){

                    foreach ($months as $monthNum => $monthName) {
    
                        $Trend_data_list = [];
                                        
                        foreach ($types_list as $type_key => $type_name) {
                            
                            $paymentSums = isset($result[$type_key]) && !empty($result[$type_key]) ? $result[$type_key] : [];
    
                            if((int)$year == $currentYear && (int)$monthNum > $currentMonth){
                                $amount = 0;
                            }else{
                                $amount = isset($paymentSums['monthTotals'][$year][$monthNum]) ? round($paymentSums['monthTotals'][$year][$monthNum]) : 0;
                            }
                            
                            // Save raw daily data
                            $data[$year][$monthNum][$type_key] = $amount;
    
                            if($year_index != 0){
    
                                $Trend_data_list[$type_key] = $amount;
    
                                // Month totals per type
                                $totals[$year][$type_key] = ($totals[$year][$type_key] ?? 0) + $amount;
    
                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;
    
                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;
    
                                $typeMonthTotals[$type_key][$year] = ($typeMonthTotals[$type_key][$year] ?? 0) + $amount;
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }
    
                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            // 🔹 Percentages
            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){
                    foreach ($months as $monthNum => $monthName) {

                        foreach ($types_list as $type_key => $type_name) {

                            if($year_index != 0){

                                $monthTotal = $totals[$year][$type_key] ?? 0;
                                $amount     = $data[$year][$monthNum][$type_key] ?? 0;

                                $percentages[$year][$monthNum][$type_key] = $monthTotal > 0
                                    ? round(($amount / $monthTotal) * 100, 2)
                                    : 0;
                            }
                        }
                    }
                }
            }
            
            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'types' => $types,
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function outstanding_monthly(Request $request)
    {
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        $days = range(1, 31);

        return view('content.report_management.payment_report.outstanding_monthly_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function OutstandingMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;
    
            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y',strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year,2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getOutstandingMonthlyData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $types = ['Payment', 'Collection'];

            $type_keys = array_map(fn($type) => $this->slugify($type), $types);

            $types_list = array_combine($type_keys, $types);

            $type_count = !empty($types) && is_array($types) ? count($types) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                    foreach ($types_list as $type_key => $type_name) {
                        
                        $paymentSums = isset($result[$type_key]) && !empty($result[$type_key]) ? $result[$type_key] : [];

                        $amount = isset($paymentSums['dayTotals'][$year][$monthNum][$day]) ? round($paymentSums['dayTotals'][$year][$monthNum][$day]) : 0;
                        
                        $pre_amount = isset($paymentSums['dayTotals'][$pre_year][12][$pre_daysInMonth]) ? round($paymentSums['dayTotals'][$pre_year][12][$pre_daysInMonth]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $Trend_data_list[$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = ($totals[$monthNum][$type_key] ?? 0) + $amount;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + $amount;

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = ($typeMonthTotals[$type_key][$monthNum] ?? 0) + $amount;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            // 🔹 Percentages
            foreach ($months as $monthNum => $monthName) {
                foreach ($days as $day) {
                    foreach ($types_list as $type_key => $type_name) {

                        $monthTotal = $totals[$monthNum][$type_key] ?? 0;
                        $amount     = $data[$monthNum][$day][$type_key] ?? 0;

                        $percentages[$monthNum][$day][$type_key] = $monthTotal > 0
                            ? round(($amount / $monthTotal) * 100, 2)
                            : 0;
                    }
                }
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => $types,
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }
    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }
    
    // private function getOutstandingMonthlyData(int $branch_id)
    // {

    //     try {

    //         if (!$branch_id) {
    //             throw new \InvalidArgumentException("Branch ID is required");
    //         }


    //         /* =====================================================
    //         * 1. FETCH CUSTOMER + SLOT DATA (FLAT)
    //         * ===================================================== */
    //         $customers = DB::table('et_customer')
    //             ->where('et_customer.branch_id', $branch_id)
    //             ->where('et_customer.status', 0)
    //             ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.lead_id', '=', 'et_customer.lead_id')
    //             ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //             ->leftJoin('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
    //             ->leftJoin('et_country_currencies', 'et_country_currencies.sno', '=', 'et_proposal.currency_id')
    //             ->whereNotIn('et_proposal.proposal_status', [0, 2])
    //             ->where('et_lead.created_by', '>', 1)
    //             ->select(
    //                 'et_customer.cus_name',
    //                 'et_customer.customer_id',
    //                 'et_customer.lead_id',

    //                 'et_proposal_pay_slot.payable_amount',
    //                 'et_proposal_pay_slot.paid_status',
    //                 'et_proposal_pay_slot.initialPayDate',
    //                 'et_proposal_pay_slot.nextPayDate',

    //                 'et_proposal.currency_id',
    //                 'et_country_currencies.currency_code'
    //             )
    //             ->get();

    //         /* =====================================================
    //         * 2. BRANCH SETTINGS
    //         * ===================================================== */
    //         $branch = BranchModel::where('sno', $branch_id)
    //             ->where('status', 0)
    //             ->select('min_prd_cost', 'gst_percentage')
    //             ->first();

    //         $branchCost = $branch->min_prd_cost ?? 0;
    //         $gstPer     = $branch->gst_percentage ?? 0;

    //         $helper = new \App\Helpers\Helpers();

    //         /* =====================================================
    //         * 3. GROUP BY CUSTOMER
    //         * ===================================================== */
    //         $grouped = $customers->groupBy('lead_id');

    //         $result = [];

    //         $drop_customer_status = DB::table('et_drop_refund')
    //             ->where('branch_id', $branch_id)
    //             ->where('status', 0)
    //             ->where('type', 1)
    //             ->whereIn('ac_status', [1, 2])
    //             ->get();

    //         if ($drop_customer_status->isNotEmpty()) {

    //             foreach ($drop_customer_status as $drop_customer) {

    //                 if (empty($drop_customer->ac_status_date)) {
    //                     continue;
    //                 }

    //                 if (!isset($result['out_rejected'])) {
    //                     $result['out_rejected'] = [
    //                         'yearTotals'  => [],
    //                         'monthTotals' => [],
    //                         'dayTotals'   => [],
    //                         'years'       => []
    //                     ];
    //                 }

    //                 $date = \Carbon\Carbon::parse($drop_customer->ac_status_date);

    //                 $y = $date->year;
    //                 $m = $date->month;
    //                 $d = $date->day;

    //                 $amountToShow = !empty($drop_customer->refund_amount)
    //                     ? (float) $drop_customer->refund_amount
    //                     : 0;

    //                 /* YEAR */
    //                 $result['out_rejected']['yearTotals'][$y] =
    //                     ($result['out_rejected']['yearTotals'][$y] ?? 0) + $amountToShow;

    //                 $result['out_rejected']['years'][$y] = $y;

    //                 /* MONTH */
    //                 if (!isset($result['out_rejected']['monthTotals'][$y])) {
    //                     $result['out_rejected']['monthTotals'][$y] = [];
    //                 }

    //                 $result['out_rejected']['monthTotals'][$y][$m] =
    //                     ($result['out_rejected']['monthTotals'][$y][$m] ?? 0) + $amountToShow;

    //                 /* DAY */
    //                 if (!isset($result['out_rejected']['dayTotals'][$y])) {
    //                     $result['out_rejected']['dayTotals'][$y] = [];
    //                 }

    //                 if (!isset($result['out_rejected']['dayTotals'][$y][$m])) {
    //                     $result['out_rejected']['dayTotals'][$y][$m] = [];
    //                 }

    //                 $result['out_rejected']['dayTotals'][$y][$m][$d] =
    //                     ($result['out_rejected']['dayTotals'][$y][$m][$d] ?? 0) + $amountToShow;
    //             }
    //         }

    //         foreach ($grouped as $lead_id => $slots) {

    //             $customerCumulative = 0.0;
    //             $reachedThreshold   = false;

    //             $customerName = $slots->first()->cus_name;
    //             $customerId   = $slots->first()->customer_id;

    //             foreach ($slots as $slot) {

    //                 $status       = (int) $slot->paid_status;
    //                 $isInr = $slot->currency_id === 70;
    //                 $slotAmount = (float) $slot->payable_amount;
    //                 $basePaidAmount = (float) $slot->payable_amount;
    //                 $currencyCode = $slot->currency_code;

    //                 // if ($payable <= 0 || $status === 2) {
    //                 //     continue;
    //                 // }

    //                 $gstAmount = 0.0;
    //                 $paidAmount = 0.0;
    //                 $amount = 0.0;

    //                 /* ============================================
    //                 * AMOUNT CALCULATION
    //                 * ============================================ */
    //                 if ($isInr) {

    //                     // INR → GST applied directly
    //                     $gstAmount  = $basePaidAmount * ($gstPer / 100);
    //                     $paidAmount = $basePaidAmount + $gstAmount;
    //                     $amount = $slotAmount;

    //                 } else {

    //                     $baseAmount = $basePaidAmount / (1 + ($gstPer / 100));

    //                     // Non-INR → remove GST → convert → reapply GST
    //                     // $baseWithoutGst = $payable / (1 + ($gstPer / 100));
    //                     $convertedInr   = $helper->ConvertedAmountInr($currencyCode, $baseAmount);

    //                     $gstAmount      = $convertedInr * ($gstPer / 100);
    //                     $paidAmount     = $convertedInr + $gstAmount;

    //                     $amount = 0.0;
    //                 }

                    
    //                 if ($status === 2 || $amount < 0 || $paidAmount < 0) {
    //                     continue;
    //                 }

    //                 /* ============================================
    //                 * THRESHOLD LOGIC
    //                 * ============================================ */
    //                 if ($status === 1) {

    //                     $customerCumulative += $paidAmount;

    //                     if (!$reachedThreshold && $customerCumulative <= $branchCost) {
    //                         continue;
    //                     }

    //                     if (!$reachedThreshold && $customerCumulative > $branchCost) {
    //                         $reachedThreshold = true;
    //                     }
    //                 }

    //                 /* ============================================
    //                 * DATE & GROUP TYPE
    //                 * ============================================ */
    //                 if ($status === 0) {

    //                     if (is_null($slot->nextPayDate)) {
    //                         continue;
    //                     }

    //                     $date = \Carbon\Carbon::parse($slot->nextPayDate);
    //                     $amountToShow = $amount;
    //                     $bg = 'payment';

    //                 } else {

    //                     if (is_null($slot->initialPayDate)) {
    //                         continue;
    //                     }

    //                     $date = \Carbon\Carbon::parse($slot->initialPayDate);
    //                     $amountToShow = $paidAmount;
    //                     $bg = 'collection';
    //                 }

    //                 $y = $date->year;
    //                 $m = $date->month;
    //                 $d = $date->day;

    //                 /* ============================================
    //                 * STRUCTURE INIT
    //                 * ============================================ */
    //                 if (!isset($result[$bg])) {
    //                     $result[$bg] = [
    //                         'yearTotals'  => [],
    //                         'monthTotals' => [],
    //                         'dayTotals'   => [],
    //                         'years'       => []
    //                     ];
    //                 }

    //                 /* YEAR */
    //                 $result[$bg]['yearTotals'][$y] =
    //                     ($result[$bg]['yearTotals'][$y] ?? 0) + $amountToShow;

    //                 $result[$bg]['years'][$y] = $y;

    //                 /* MONTH */
    //                 $result[$bg]['monthTotals'][$y][$m] =
    //                     ($result[$bg]['monthTotals'][$y][$m] ?? 0) + $amountToShow;

    //                 /* DAY */
    //                 $result[$bg]['dayTotals'][$y][$m][$d] =
    //                     ($result[$bg]['dayTotals'][$y][$m][$d] ?? 0) + $amountToShow;
    //             }
    //         }

    //         /* =====================================================
    //         * 4. ROUND VALUES
    //         * ===================================================== */
    //         foreach ($result as &$group) {

    //             foreach ($group['yearTotals'] as &$v) {
    //                 $v = round($v, 2);
    //             }

    //             foreach ($group['monthTotals'] as &$months) {
    //                 foreach ($months as &$v) {
    //                     $v = round($v, 2);
    //                 }
    //             }

    //             foreach ($group['dayTotals'] as &$months) {
    //                 foreach ($months as &$days) {
    //                     foreach ($days as &$v) {
    //                         $v = round($v, 2);
    //                     }
    //                 }
    //             }

    //             $group['years'] = array_values($group['years']);
    //         }

    //         return !empty($result) ? $result : null;

    //     } catch (\Exception $e) {
    //         \Log::error("getOutstandingMonthlyDataNew error: ".$e->getMessage());
    //         return null;
    //     }

    // }

    private function getOutstandingMonthlyData(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID required");
            }

            $helper = new \App\Helpers\Helpers();

            /* ================================
            * BRANCH CONFIG
            * ================================ */
            $branch = BranchModel::where('sno', $branch_id)
                ->where('status', 0)
                ->select('min_prd_cost')
                ->first();

            $branchCost = $branch->min_prd_cost ?? 0;

            /* ================================
            * FIRST SLOT IDS (IGNORE)
            * ================================ */
            $firstSlotIds = DB::table('et_proposal_pay_slot')
                ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                ->where('et_proposal.status', 0)
                ->where('et_proposal_pay_slot.status', 0)
                ->whereNotIn('et_proposal.proposal_status', [0, 2])
                ->select(DB::raw('MIN(et_proposal_pay_slot.sno)'))
                ->groupBy('et_proposal_pay_slot.proposal_sno');

            /* ================================
            * DROPPED CUSTOMERS
            * ================================ */
            $dropCustomerIds = DB::table('et_customer')
                ->where('drop_refund_id', '!=', 0)
                ->where('drop_verified', 1)
                ->pluck('sno')
                ->toArray();

            /* ================================
            * OUTSTANDING PAYMENTS
            * ================================ */
            $payments = DB::table('et_proposal_pay_slot')
                ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->leftJoin('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_country_currencies', 'et_country_currencies.sno', '=', 'et_proposal.currency_id')
                ->where('et_lead.created_by', '>', 1)
                ->whereNotIn('et_customer.sno', $dropCustomerIds)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstSlotIds)
                ->where('et_proposal_pay_slot.branch_id', $branch_id)
                ->whereNotIn('et_proposal.proposal_status', [0, 2])
                ->select(
                    'et_proposal_pay_slot.paid_status',
                    'et_proposal_pay_slot.payable_amount',
                    'et_proposal_pay_slot.paidAmount',
                    'et_proposal_pay_slot.nextPayDate',
                    'et_proposal_pay_slot.initialPayDate',
                    'et_proposal.gst_perc',
                    'et_proposal.currency_id',
                    'et_country_currencies.currency_code',
                    'et_transaction.total_amount_inr'
                )
                ->get();

            $drop_customer_status = DB::table('et_drop_refund')
                ->where('branch_id', $branch_id)
                ->where('status', 0)
                ->where('type', 1)
                ->whereIn('ac_status', [1, 2])
                ->get();

            /* ================================
            * RESULT STRUCTURE
            * ================================ */
            $result = [
                'payment' => [
                    'yearTotals'  => [],
                    'monthTotals' => [],
                    'dayTotals'   => [],
                    'years'   => []
                ],
                'collection' => [
                    'yearTotals'  => [],
                    'monthTotals' => [],
                    'dayTotals'   => [],
                    'years'   => []
                ],
                'out_rejected' => [
                    'yearTotals'  => [],
                    'monthTotals' => [],
                    'dayTotals'   => [],
                    'years'   => []
                ]
            ];

            $customerCumulative = 0;
            $reachedThreshold = false;

            /* ================================
            * PROCESS PAYMENTS
            * ================================ */
            foreach ($payments as $pay) {

                $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc / 100 : 0;

                /* ---- Amount in INR ---- */
                if ($pay->currency_id != 70) {
                    $amountInr = $pay->total_amount_inr
                        ? $pay->total_amount_inr
                        : $helper->ConvertedAmountInr(
                            $pay->currency_code,
                            $pay->paid_status ? $pay->paidAmount : $pay->payable_amount
                        );
                } else {
                    $amountInr = $pay->paid_status
                        ? $pay->paidAmount
                        : $pay->payable_amount;
                }

                /* ---- Net without GST ---- */
                $netAmount = $amountInr / (1 + $gstRate);

                if ($netAmount <= 0) continue;

                /* ---- Threshold logic (ONLY FOR COLLECTION) ---- */
                if ($pay->paid_status == 1) {
                    $customerCumulative += $netAmount;

                    if (!$reachedThreshold && $customerCumulative <= $branchCost) {
                        continue;
                    }

                    if (!$reachedThreshold && $customerCumulative > $branchCost) {
                        $reachedThreshold = true;
                    }
                }

                /* ---- TYPE ---- */
                $type = $pay->paid_status == 0 ? 'payment' : 'collection';

                /* ---- Date selection ---- */
                $date = $pay->paid_status == 0
                    ? $pay->nextPayDate
                    : $pay->initialPayDate;

                if (!$date) continue;

                $c = \Carbon\Carbon::parse($date);
                $y = $c->year;
                $m = $c->month;
                $d = $c->day;

                /* ---- YEAR ---- */
                $result[$type]['yearTotals'][$y] =
                    ($result[$type]['yearTotals'][$y] ?? 0) + $netAmount;

                $result[$type]['years'][$y] = $y;

                /* ---- MONTH ---- */
                $result[$type]['monthTotals'][$y][$m] =
                    ($result[$type]['monthTotals'][$y][$m] ?? 0) + $netAmount;

                /* ---- DAY ---- */
                $result[$type]['dayTotals'][$y][$m][$d] =
                    ($result[$type]['dayTotals'][$y][$m][$d] ?? 0) + $netAmount;
            }

            if ($drop_customer_status->isNotEmpty()) {

                foreach ($drop_customer_status as $drop_customer) {

                    if (empty($drop_customer->ac_status_date)) {
                        continue;
                    }

                    if (!isset($result['out_rejected'])) {
                        $result['out_rejected'] = [
                            'yearTotals'  => [],
                            'monthTotals' => [],
                            'dayTotals'   => [],
                            'years'       => []
                        ];
                    }

                    $date = \Carbon\Carbon::parse($drop_customer->ac_status_date);

                    $y = $date->year;
                    $m = $date->month;
                    $d = $date->day;

                    $amountToShow = !empty($drop_customer->refund_amount)
                        ? (float) $drop_customer->refund_amount
                        : 0;

                    /* YEAR */
                    $result['out_rejected']['yearTotals'][$y] =
                        ($result['out_rejected']['yearTotals'][$y] ?? 0) + $amountToShow;

                    $result['out_rejected']['years'][$y] = $y;

                    /* MONTH */
                    if (!isset($result['out_rejected']['monthTotals'][$y])) {
                        $result['out_rejected']['monthTotals'][$y] = [];
                    }

                    $result['out_rejected']['monthTotals'][$y][$m] =
                        ($result['out_rejected']['monthTotals'][$y][$m] ?? 0) + $amountToShow;

                    /* DAY */
                    if (!isset($result['out_rejected']['dayTotals'][$y])) {
                        $result['out_rejected']['dayTotals'][$y] = [];
                    }

                    if (!isset($result['out_rejected']['dayTotals'][$y][$m])) {
                        $result['out_rejected']['dayTotals'][$y][$m] = [];
                    }

                    $result['out_rejected']['dayTotals'][$y][$m][$d] =
                        ($result['out_rejected']['dayTotals'][$y][$m][$d] ?? 0) + $amountToShow;
                }
            }

            return $result;

        } catch (\Exception $e) {
            \Log::error("getOutstandingMonthlyDataNew error: " . $e->getMessage());
            return null;
        }
    }

    private function getPostPreSalesData(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $branch = DB::table('et_branch')->where('sno', $branch_id)->first();
            $branchGst = $branch ? ($branch->gst_percentage / 100) : 0.18;

            /* ============================================================
                COLLECTION QUERY (same logic as your code)
            ============================================================ */
            $collectionRows = DB::table('et_proposal_pay_slot')
                ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_lead.status', '!=', 2)
                ->where('et_customer.status', 0)
                ->where('et_proposal_pay_slot.paid_status', 1)
                ->where('et_transaction.payment_status', 1)
                ->where('et_proposal_pay_slot.branch_id', $branch_id)
                ->select(
                    DB::raw("DATE(et_payment.transaction_date) as date"),
                    "et_payment.paid_amount",
                    "et_transaction.total_amount_inr",
                    "et_proposal.gst_perc"
                )
                ->get();

            /* ============================================================
                TARGET QUERY
            ============================================================ */
            $totalTargets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
                ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                ->select(
                    DB::raw('YEAR(branch_target.date) as year'),
                    DB::raw('MONTH(branch_target.date) as month'),
                    'branch_target.monthly_target as monthly_target'
                )
                ->get();

            /* ============================================================
                FORMAT TARGET AS DAILY TARGETS
            ============================================================ */
            $dailyTargets = collect();

            foreach ($totalTargets as $target) {

                $year = $target->year;
                $month = $target->month;
                $monthlyTarget = $target->monthly_target;

                $daysInMonth = Carbon::create($year, $month, 1)->daysInMonth;
                $dailyValue = $monthlyTarget / $daysInMonth;

                for ($day = 1; $day <= $daysInMonth; $day++) {
                    $dailyTargets->push((object)[
                        'year' => $year,
                        'month' => $month,
                        'day' => $day,
                        'target_amount' => round($dailyValue, 2),
                    ]);
                }
            }

            /* ============================================================
                PREPARE COLLECTION + TARGET STRUCTURES
            ============================================================ */

            $collection_sale = [
                'yearly'  => [],
                'monthly' => [],
                'daily'   => [],
            ];

            $target_sale = [
                'yearly'  => [],
                'monthly' => [],
                'daily'   => [],
            ];

            $years = [];

            /* ============================================================
                PROCESS COLLECTION
            ============================================================ */

            foreach ($collectionRows as $row) {

                if (empty($row->date)) continue;

                $date = $row->date;

                $y = (int) date('Y', strtotime($date));
                $m = (int) date('n', strtotime($date));
                $d = (int) date('j', strtotime($date));

                // amount logic
                $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                    ? $row->total_amount_inr
                    : $row->paid_amount;

                $gstRate = $row->gst_perc > 0 ? ($row->gst_perc / 100) : $branchGst;

                $netAmount = $amountInr / (1 + $gstRate);

                if(!isset($collection_sale['yearly'][$y])){
                    $collection_sale['yearly'][$y] = 0;
                }

                if(!isset($collection_sale['monthly'][$y][$m])){
                    $collection_sale['monthly'][$y][$m] = 0;
                }

                if(!isset($collection_sale['daily'][$y][$m][$d])){
                    $collection_sale['daily'][$y][$m][$d] = 0;
                }

                // accumulate
                $collection_sale['yearly'][$y] =
                    ($collection_sale['yearly'][$y] ?? 0) + $netAmount;

                $collection_sale['monthly'][$y][$m] =
                    ($collection_sale['monthly'][$y][$m] ?? 0) + $netAmount;

                $collection_sale['daily'][$y][$m][$d] =
                    ($collection_sale['daily'][$y][$m][$d] ?? 0) + $netAmount;

                $years[$y] = $y;
            }

            /* ============================================================
                PROCESS TARGETS
            ============================================================ */

            foreach ($dailyTargets as $t) {

                $y = $t->year;
                $m = $t->month;
                $d = $t->day;
                $target = $t->target_amount;

                if(!isset($target_sale['yearly'][$y])){
                    $target_sale['yearly'][$y] = 0;
                }

                if(!isset($target_sale['monthly'][$y][$m])){
                    $target_sale['monthly'][$y][$m] = 0;
                }

                if(!isset($target_sale['daily'][$y][$m][$d])){
                    $target_sale['daily'][$y][$m][$d] = 0;
                }

                // accumulate
                $target_sale['yearly'][$y] =
                    ($target_sale['yearly'][$y] ?? 0) + $target;

                $target_sale['monthly'][$y][$m] =
                    ($target_sale['monthly'][$y][$m] ?? 0) + $target;

                $target_sale['daily'][$y][$m][$d] =
                    ($target_sale['daily'][$y][$m][$d] ?? 0) + $target;

                $years[$y] = $y;
            }

            /* ============================================================
                FINAL RETURN (Option-A)
            ============================================================ */

            return [
                'collection_sale' => $collection_sale,
                'target_sale'     => $target_sale,
                'years'           => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetLeadConversionDetails: " . $e->getMessage());
            return null;
        }
    }

    public function getPostPreSalesDataNew($request)
    {

        try {

            $branch_id = $request->user()->branch_id;

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $branch = DB::table('et_branch')->where('sno', $branch_id)->first();

            $data = [
                'years' => [],
                'yearly'  => ['pre_sale'=>[], 'post_sale'=>[], 'closed_sale'=>[]],
                'monthly' => ['pre_sale'=>[], 'post_sale'=>[], 'closed_sale'=>[]],
                'daily'   => ['pre_sale'=>[], 'post_sale'=>[], 'closed_sale'=>[]],
            ];

            $years = [];

            /* =====================================================
            | BASE QUERY (PRE + POST + OTHERS)
            ===================================================== */
            $rows = DB::table('et_proposal_pay_slot')
                ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_lead.status', '!=', 2)
                ->where('et_customer.status', 0)
                ->where('et_transaction.customer_type', 0)
                ->where('et_transaction.payment_status', 1)
                ->where('et_transaction.status', 0)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->where('et_proposal_pay_slot.branch_id', $branch_id)
                ->select(
                    // 'et_customer.post_sale_check',
                    'et_proposal.post_sale_check as proposal_post_sale',
                    DB::raw("DATE(et_payment.transaction_date) as pay_date"),
                    'et_payment.paid_amount',
                    'et_transaction.total_amount_inr',
                    'et_proposal.gst_perc'
                )
                ->get();

            /* =====================================================
            | PROCESS DATA
            ===================================================== */
            foreach ($rows as $row) {

                /* ---------- TYPE ---------- */
                if ($row->proposal_post_sale == 1) {
                    $type = 'post_sale';
                } else{
                    $type = 'pre_sale';
                }

                /* ---------- DATE ---------- */
                $date = \Carbon\Carbon::parse($row->pay_date);
                $y = $date->year;
                $m = $date->month;
                $d = $date->day;

                if (!in_array($y, $data['years'])) {
                    $data['years'][] = $y;
                }

                /* ---------- AMOUNT (INR FIRST) ---------- */
                $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                    ? $row->total_amount_inr
                    : $row->paid_amount;

                /* ---------- GST ---------- */
                $gstRate = $row->gst_perc > 0
                    ? ($row->gst_perc / 100)
                    : ($branch ? $branch->gst_percentage / 100 : 0.18);

                /* ---------- NET ---------- */
                $netAmount = $amountInr / (1 + $gstRate);

                /* ---------- YEARLY ---------- */
                $data['yearly'][$type][$y] =
                    ($data['yearly'][$type][$y] ?? 0) + $netAmount;

                /* ---------- MONTHLY ---------- */
                $data['monthly'][$type][$y][$m] =
                    ($data['monthly'][$type][$y][$m] ?? 0) + $netAmount;

                /* ---------- DAILY ---------- */
                $data['daily'][$type][$y][$m][$d] =
                    ($data['daily'][$type][$y][$m][$d] ?? 0) + $netAmount;
            }

            ksort($years);

            return $data;

        } catch (\Exception $e) {
            \Log::error("getPostPreSalesDataNew error: " . $e->getMessage());
            return null;
        }
    }
}