<?php

namespace App\Http\Controllers\lead_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\LeadRequirementModel;
use App\Models\RequirementReasonModel;
use App\Models\LeadModel;
use App\Models\RequirementDocModel;
use Illuminate\Support\Facades\Validator;

class ManageRequirements extends Controller
{

  public function index(Request $request)
  {
    $page         = $request->input('page', 1);
    $perpage      = (int) $request->input('sorting_filter', 25);
    $offset       = ($page - 1) * $perpage;
    $branch_id    = $request->user()->branch_id ?? 1;
    $entity_id    = $request->user()->entity_id ?? 1;
    $currentMonth = date('m');
    $currentYear = date('Y');
    $user_id    = $request->user()->user_id ?? 1;

    $lead_fill        = $request->lead_fill ?? '';


    $lead_requirements = LeadRequirementModel::select(
      'et_lead_requirement.*',
      'et_lead.lead_name',
      'et_lead.lead_email_id',
      'et_lead.lead_gender',
      'et_lead.lead_id',
      'et_lead.service_id',
      'et_lead.lead_mobile',
      'pc_staff.staff_name as pc_name',
      'assign_staff.staff_name as assign_staff_name',
      'et_product_category.product_category_name',
      'et_product.product_name',
      'pc_job.job_position_name as pc_job_name',
      'assign_staff_job.job_position_name as assign_staff_job_name',
      DB::raw('(SELECT COUNT(*) FROM et_lead_requirement_doc WHERE et_lead_requirement_doc.lead_id = et_lead_requirement.lead_id and status !=2) AS requirement_count')
    )

      ->join('et_lead', 'et_lead_requirement.lead_id', '=', 'et_lead.sno')
      ->leftJoin('et_staff as assign_staff', 'et_lead_requirement.staff_id', '=', 'assign_staff.sno')
      ->leftJoin('et_staff as pc_staff', 'et_lead_requirement.pc_id', '=', 'pc_staff.sno')
      ->leftJoin('et_product_category', 'et_lead.service_category_id', '=', 'et_product_category.sno')
      ->leftJoin('et_product', 'et_lead.service_id', '=', 'et_product.sno')
      ->leftJoin('et_job_position as pc_job', 'pc_job.sno', "=", "pc_staff.position_role")
      ->leftJoin('et_job_position as assign_staff_job', 'assign_staff_job.sno', "=", "assign_staff.position_role")
      ->whereNotIn('et_lead.status', [2, 4])
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.entity_id', $entity_id)

      ->orderBy('et_lead_requirement.sno', 'desc');

    if ($lead_fill != '') {
      $lead_requirements->where(function ($query) use ($lead_fill) {
        $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }


    // if (auth()->user()->hasPermissionradio('P Management', 'Manage Requirments', 'view_self_lead')) {
    //   // User can only view their own data
    //   $lead_requirements = $lead_requirements->where('et_lead_requirement.staff_id', $user_id);
    //   // return "view_self_lead";
    // } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Requirments', 'global_lead')) {
    //   // User can view all data
    //   $lead_requirements = $lead_requirements;
    //   // return "global_lead";
    // } else {
    //   // No permission
    //   abort(403, 'Unauthorized');
    // }

    $lead_requirements = $lead_requirements->paginate($perpage);

    foreach ($lead_requirements as $req) {
      $serviceIds = json_decode($req->service_id, true);
      if (!is_array($serviceIds)) {
        continue;
      }
      $products = DB::table('et_product')
        ->select('et_product_category.product_category_name', 'et_product.product_name')
        ->whereIn('et_product.sno', $serviceIds)
        ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->get();

      // Extract product names
      $productNames = $products->pluck('product_name')->toArray();
      $req->product_name = implode(', ', $productNames); // e.g., "product1, product2"

      // Extract unique category names
      $uniqueCategories = $products->pluck('product_category_name')->unique()->values()->toArray();
      $req->product_category_name = implode(', ', $uniqueCategories); // e.g., "Category1, Category2"
    }

    $reasonList_reject = DB::table('et_requirement_reason')->select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    return view('content.lead_management.manage_requirements.lead_requirements_list', [
      'perpage'           => $perpage,
      'lead_requirements'      => $lead_requirements,
      'reasonList_reject'      => $reasonList_reject,
      'lead_fill'         => $lead_fill,
    ]);
  }


  public function RequirementDetails($id){

    $requirements = RequirementDocModel::where('lead_id', $id)->where('status', '!=', 2)->get();
    $leadData = DB::table('et_lead')->select('et_lead.*','et_product_category.product_category_name','et_product.product_name')->leftJoin('et_product_category', 'et_lead.service_category_id', '=', 'et_product_category.sno')->leftJoin('et_product', 'et_lead.service_id', '=', 'et_product.sno')->where('et_lead.sno', $id)->first();

     $serviceIds = json_decode($leadData->service_id, true);

        if (is_array($serviceIds) && count($serviceIds) > 0) {
            $products = DB::table('et_product')
                ->select('et_product_category.product_category_name', 'et_product.product_name')
                ->whereIn('et_product.sno', $serviceIds)
                ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
                ->get();
        
            // Extract product names
            $productNames = $products->pluck('product_name')->toArray();
            $leadData->product_name = implode(', ', $productNames); // e.g., "product1, product2"
        
            // Extract unique category names
            $uniqueCategories = $products->pluck('product_category_name')->unique()->values()->toArray();
            $leadData->product_category_name = implode(', ', $uniqueCategories); // e.g., "Category1, Category2"
        } else {
            // Fallback values to avoid further errors
            $leadData->product_name = '';
            $leadData->product_category_name = '';
        }
 
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $requirements,
      'lead'      => $leadData
    ], 200);


  }

  public function addOrUpdateRequirement(Request $request) 
  {

    // return $request;

    $validator = Validator::make($request->all(), [
      'requirement_lead_id' => 'required|integer',
      'requirement_name' => 'nullable|array',
      'requirement_name_*' => 'nullable|array',
      'requirement_name.*' => 'nullable|string',
      'requirement_name_.*' => 'nullable|string',
      'document_upload' => 'nullable|array',
      'document_upload.*' => 'nullable|file|mimes:jpg,jpeg,png,pdf,doc,docx',
    ]);

      if ($validator->fails()) {
          return redirect()->back()->withErrors($validator)->withInput();
      }

      $data = $validator->validated();


      $leadId = $data['requirement_lead_id']; 
      $branch_id = $request->user()->branch_id ?? 1;
      $user_id = $request->user()->user_id ?? 1;
      $entity_id = $request->user()->entity_id ?? 1;
      $requirement_status = $request->requirement_status;



      // Check if the lead already has a requirement
      $leadChk = LeadRequirementModel::where('lead_id', $leadId)->where('status', '!=', 2)->first();
    
 
        if ($leadChk) {
  
            // If lead exists, update it
            $leadRequirement = $leadChk;
            $leadRequirement->updated_by = $user_id;
            $leadRequirement->staff_approval = 0;
            $leadRequirement->pc_approval = 0;
            $leadRequirement->delivery_status = 0;
            $leadRequirement->update();

            $requirementNames = $data['requirement_name'] ?? [];
            $requirementDocIds = $data['require_doc_id'] ?? [];
            $requirementUploads = $data['document_upload'] ?? [];
   
            $leadDoc = RequirementDocModel::where('lead_id', $leadId)
                               ->where('status', '!=', 2)
                               ->get();
            $existingDocIds = $leadDoc->pluck('sno')->toArray();

            $updateIds=$request->require_doc_id;
            $docIdsToDelete = array_diff($existingDocIds, $updateIds);
            $docIdsToDelete = array_values($docIdsToDelete);
       
      
            if (!empty($docIdsToDelete)) {
                $deleteDoc=RequirementDocModel::whereIn('sno', $docIdsToDelete)
                                  ->update(['status' => 2]);
            }

            
            foreach ($updateIds as $index => $id) {
              
                // Get the requirementDocId from the array
                $requirementDocId = $id ?? null;
                $documentUrl = null;
               
                if ($requirementDocId) {
                    $existingRequirementDoc = RequirementDocModel::find($requirementDocId);
              
                    if ($existingRequirementDoc) {
                        // Dynamically update requirement_name based on the _id
                        $requirementNameKey = "requirement_name_" . $requirementDocId;  
                     
                        if (isset($request->$requirementNameKey)) {
                            $requirementName = $request->$requirementNameKey[0] ?? null; // e.g., "Test2"
                            if ($requirementName) {
                                $existingRequirementDoc->requirement_name = $requirementName;
                            }
                        }
            
                        // Dynamically update document_upload based on the _id
                        $documentUploadKey = "document_upload_" . $requirementDocId;  // e.g., "document_upload_1"
                        if (isset($request->$documentUploadKey)) {
                            $file = $request->$documentUploadKey[0];
                            $documentUrl = $this->handleFileUpload($file);  // Handle file upload logic
                        }
            
                        // If a document URL is set or updated, update it in the database
                        if ($documentUrl) {
                            $existingRequirementDoc->document_url = $documentUrl;
                        }
            
                        // Update the record with the new information
                        $existingRequirementDoc->updated_by = $user_id;
                        $existingRequirementDoc->update();
                    }
                }
            }
            
            foreach ($requirementNames as $index => $requirementName) {
              $requirementDocId = $requirementDocIds[$index] ?? null;
              $documentUrl = null;
                  // If no document ID, it's a new record
                  if (isset($requirementUploads[$index]) && $requirementUploads[$index]) {
                      $file = $requirementUploads[$index];
                      $documentUrl = $this->handleFileUpload($file); // Handle file upload function
                  }
  
                  // Create a new requirement document record
                  RequirementDocModel::create([
                      'lead_id' => $leadId,
                      'lead_requirement_id' => $leadRequirement->sno,
                      'requirement_name' => $requirementName,
                      'document_url' => $documentUrl ?? null,
                      'created_by' => $user_id,
                      'updated_by' => $user_id,
                  ]);
             
            }
  
              session()->flash('toastr', [
                  'type' => 'success',
                  'message' => 'Lead Requirement updated Successfully!'
              ]);
        
            return redirect('manage_requirements');
            
        }else {
          // If no lead requirement found, create a new one
          $lead_reqr_chk = LeadRequirementModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

          if (!$lead_reqr_chk) {
              $year = substr(date('y'), -2);
              $lead_requirement_id = 'LDRM-0001/' . $year;
          } else {
              $last_id = $lead_reqr_chk->lead_requirement_id;
              $slice = explode('/', $last_id);
              $result = preg_replace('/[^0-9]/', '', $slice[0]);
              $next_number = (int) $result + 1;
              $request = sprintf('LDRM-%04d', $next_number);
              $year = substr(date('y'), -2);
              $lead_requirement_id = $request . '/' . $year;
          }

          // Create new lead requirement record
          $leadRequirement = new LeadRequirementModel();
          $leadRequirement->lead_requirement_id = $lead_requirement_id;
          $leadRequirement->lead_id = $leadId;
          $leadRequirement->branch_id = $branch_id;
          $leadRequirement->entity_id = $entity_id;
          $leadRequirement->created_by = $user_id;
          $leadRequirement->updated_by = $user_id;

          $leadRequirement->save();
     

          if ($leadRequirement) {
              foreach ($data['requirement_name'] as $index => $requirementName) {

                $documentUrl = null;

                if (isset($data['document_upload'][$index])) {
                  $file = $data['document_upload'][$index];

                  // Get all existing filenames in the requirement_documents directory
                  $existingFiles = glob(public_path('requirement_documents/requirement_doc_*.{jpg,jpeg,png,pdf,doc,docx}'), GLOB_BRACE);

                  $maxIndex = 0;
                  foreach ($existingFiles as $existingFile) {
                      $basename = pathinfo($existingFile, PATHINFO_FILENAME); // e.g., "requirement_doc_2"
                      if (preg_match('/requirement_doc_(\d+)/', $basename, $matches)) {
                          $num = (int)$matches[1];
                          if ($num > $maxIndex) {
                              $maxIndex = $num;
                          }
                      }
                  }

                  $nextFileIndex = $maxIndex + 1;

                  $extension = $file->getClientOriginalExtension();
                  $filename = 'requirement_doc_' . $nextFileIndex . '.' . $extension;

                  $file->move(public_path('requirement_documents'), $filename);

                  $documentUrl = $filename;
              }

                RequirementDocModel::create([
                      'lead_id' => $leadId,
                      'lead_requirement_id' => $leadRequirement->sno,
                      'requirement_name' => $requirementName,
                      'document_url' => $documentUrl ?? null,
                      'created_by' => $user_id,
                      'updated_by' => $user_id,
                  ]);
                  


              }
              session()->flash('toastr', [
                  'type' => 'success',
                  'message' => 'Lead Requirement added Successfully!'
                ]);
            return redirect('manage_requirements');
          } else {
              session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Lead Requirement could not be add!'
              ]);
            // If no lead requirement record was found or created
            return redirect('manage_lead');
          }
        }
  }


  public function StaffList(Request $request)
  {
    $branch_id = $request->user()->branch_id ?? 1;
    $entity_id = $request->user()->entity_id ?? 1;

    $staff =   $staff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', '!=', 2)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id)
      ->where('et_staff.entity_id', $entity_id)
      ->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $staff,
    ], 200);
  }

   public function AssignStaffRequirement(Request $request)
  {
    $id=$request->assign_requirement_id;
    $user_id = $request->user()->user_id ?? 1;
    $lead    = LeadRequirementModel::where('sno', $id)->first();

    if ($lead) {
      $lead->staff_id    = $request->assign_staff_id;
      $lead->updated_by   = $user_id;
      $lead->update();
      if ($lead->update()) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => ' Staff Updated Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Could Not Update!'
        ]);
      }
    } 
    return redirect()->back();
  }

  
  public function RequirementView($id){

    $leadData = DB::table('et_lead_requirement')
    ->select(
      'et_lead.*',
      'et_lead_requirement.staff_id',
      'et_lead_requirement.staff_approval',
      'et_lead_requirement.pc_approval',
      'et_lead_requirement.delivery_status',
      'et_product_category.product_category_name','et_product.product_name',
      'et_staff.staff_name',
      'et_job_position.job_position_name as position_name'
      )
    ->join('et_lead', 'et_lead.sno', '=', 'et_lead_requirement.lead_id')
    ->leftJoin('et_staff', 'et_lead_requirement.staff_id', '=', 'et_staff.sno')
    ->leftJoin('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
    ->leftJoin('et_product_category', 'et_lead.service_category_id', '=', 'et_product_category.sno')
    ->leftJoin('et_product', 'et_lead.service_id', '=', 'et_product.sno')
    ->where('et_lead_requirement.sno', $id)
    ->first();

    $requirementsDocument = DB::table('et_lead_requirement_doc')
      ->select('et_lead_requirement_doc.*')
      ->join('et_lead', 'et_lead.sno', '=', 'et_lead_requirement_doc.lead_id')
      ->join('et_lead_requirement', 'et_lead.sno', '=', 'et_lead_requirement.lead_id')
      ->where('et_lead_requirement.sno', $id)
      ->where('et_lead_requirement_doc.status', '!=', 2)
      ->get();

        $serviceIds = json_decode($leadData->service_id, true);

        if (is_array($serviceIds) && count($serviceIds) > 0) {
            $products = DB::table('et_product')
                ->select('et_product_category.product_category_name', 'et_product.product_name')
                ->whereIn('et_product.sno', $serviceIds)
                ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
                ->get();
        
            // Extract product names
            $productNames = $products->pluck('product_name')->toArray();
            $leadData->product_name = implode(', ', $productNames); // e.g., "product1, product2"
        
            // Extract unique category names
            $uniqueCategories = $products->pluck('product_category_name')->unique()->values()->toArray();
            $leadData->product_category_name = implode(', ', $uniqueCategories); // e.g., "Category1, Category2"
        } else {
            // Fallback values to avoid further errors
            $leadData->product_name = '';
            $leadData->product_category_name = '';
        }
 
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $requirementsDocument,
      'lead'      => $leadData
    ], 200);

  }

  

  
  public function RequirementReject(Request $request)
  {
   
    // return $request;
    $id = $request->requirement_id_reject;
    $type = $request->requirement_approval_type;
    $user_id = $request->user()->user_id ?? 1;
    $reason_reject_select = $request->reason_reject_select;
    $lead = LeadRequirementModel::where('sno', $id)->first();

    if($type=="delivery"){
      $lead->delivery_status = 2;
      $lead->updated_by = $user_id ;
      $lead->update();
        if ($lead) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Requirement Cancelled Successfully!'
          ]);
        }
    }else{
      if ($request) {
        if( $type == 'staff'){
          $lead->staff_approval = 2;
          $lead->updated_by = $user_id ;
        }else if($type == 'pc'){
          $lead->pc_approval = 2;
          $lead->updated_by = $user_id ;
        }

        if ($request->reason_reject_select == 1) {
          $lead->reason = $request->reject_reason_text; 
        } else {
          $reject = RequirementReasonModel::where('reason_name', $reason_reject_select)->first();
          if ($reject->comments_check == 1) {
            $lead->comments = $request->reject_comments_text;
          }
          $lead->reason = $reason_reject_select;
        }
        $lead->updated_by = $user_id ;
         $lead->update();
      }

      if ($lead) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Requirement Rejected Successfully!'
        ]);
      }

    }
    return redirect()->back();
  }


  public function RequirementApprove(Request $request)
{
    $id = $request->requirement_id_reject;
    $type = $request->requirement_approval_type;
    $docIds = $request->input('require_doc_id');

    $lead = LeadRequirementModel::where('sno', $id)->first();

    $user_id = $request->user()->user_id ?? 1;

    if($type=="delivery"){
      $lead->delivery_status = 1;
      $lead->updated_by = $user_id ;
      $lead->update();
        if ($lead) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Requirement Delivered Successfully!'
          ]);
        }
    }else{
      foreach ($docIds as $docId) {
        $checkbox = $request->input("chck_req_$docId");
        $reason   = $request->input("reason_req_$docId");

        $status = $checkbox ? 1 : 0;

        $updateData = [
            'requirement_doc_status' => $status,
            'updated_by' => $user_id,
        ];

        if (!$checkbox && $reason) {
            $updateData['reason'] = $reason;
        }

        $docUpdate=RequirementDocModel::where('sno', $docId)->update($updateData);
      }
   
      if( $type == 'staff'){
        $lead->staff_approval = 1;
        $lead->updated_by = $user_id ;
      }else if($type == 'pc'){
        $lead->pc_approval = 1;
        $lead->updated_by = $user_id ;
      }
      $lead->update();

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Requirement Approved Successfully!'
      ]);
    
    }

     

    return redirect()->back();
}

private function handleFileUpload($file)
{
    // Get all existing filenames in the requirement_documents directory
    $existingFiles = glob(public_path('requirement_documents/requirement_doc_*.{jpg,jpeg,png,pdf,doc,docx}'), GLOB_BRACE);
    $maxIndex = 0;
    foreach ($existingFiles as $existingFile) {
        $basename = pathinfo($existingFile, PATHINFO_FILENAME); 
        if (preg_match('/requirement_doc_(\d+)/', $basename, $matches)) {
            $num = (int)$matches[1];
            if ($num > $maxIndex) {
                $maxIndex = $num;
            }
        }
    }

    $nextFileIndex = $maxIndex + 1;
    $extension = $file->getClientOriginalExtension();
    $filename = 'requirement_doc_' . $nextFileIndex . '.' . $extension;
    $file->move(public_path('requirement_documents'), $filename);

    return $filename;
}
//vasanth
public function addOrUpdateRequirement_customer(Request $request)
  {

    // return $request;

    $validator = Validator::make($request->all(), [
      'requirement_lead_id' => 'required|integer',
      'requirement_name' => 'nullable|array',
      'requirement_name_*' => 'nullable|array',
      'requirement_name.*' => 'nullable|string',
      'requirement_name_.*' => 'nullable|string',
      'document_upload' => 'nullable|array',
      'document_upload.*' => 'nullable|file|mimes:jpg,jpeg,png,pdf,doc,docx',
    ]);

    if ($validator->fails()) {
      return redirect()->back()->withErrors($validator)->withInput();
    }

    $data = $validator->validated();


    $leadId = $data['requirement_lead_id'];
    $branch_id = $request->user()->branch_id ?? 1;
    $user_id = $request->user()->user_id ?? 1;
    $entity_id = $request->user()->entity_id ?? 1;
    $requirement_status = $request->requirement_status;



    // Check if the lead already has a requirement
    $leadChk = LeadRequirementModel::where('lead_id', $leadId)->where('status', '!=', 2)->first();


    if ($leadChk) {

      // If lead exists, update it
      $leadRequirement = $leadChk;
      $leadRequirement->updated_by = $user_id;
      $leadRequirement->staff_approval = 0;
      $leadRequirement->pc_approval = 0;
      $leadRequirement->delivery_status = 0;
      $leadRequirement->update();

      $requirementNames = $data['requirement_name'] ?? [];
      $requirementDocIds = $data['require_doc_id'] ?? [];
      $requirementUploads = $data['document_upload'] ?? [];

      $leadDoc = RequirementDocModel::where('lead_id', $leadId)
        ->where('status', '!=', 2)
        ->get();
      $existingDocIds = $leadDoc->pluck('sno')->toArray();

      $updateIds = $request->require_doc_id;
      $docIdsToDelete = array_diff($existingDocIds, $updateIds);
      $docIdsToDelete = array_values($docIdsToDelete);


      if (!empty($docIdsToDelete)) {
        $deleteDoc = RequirementDocModel::whereIn('sno', $docIdsToDelete)
          ->update(['status' => 2]);
      }


      foreach ($updateIds as $index => $id) {

        // Get the requirementDocId from the array
        $requirementDocId = $id ?? null;
        $documentUrl = null;

        if ($requirementDocId) {
          $existingRequirementDoc = RequirementDocModel::find($requirementDocId);

          if ($existingRequirementDoc) {
            // Dynamically update requirement_name based on the _id
            $requirementNameKey = "requirement_name_" . $requirementDocId;

            if (isset($request->$requirementNameKey)) {
              $requirementName = $request->$requirementNameKey[0] ?? null; // e.g., "Test2"
              if ($requirementName) {
                $existingRequirementDoc->requirement_name = $requirementName;
              }
            }

            // Dynamically update document_upload based on the _id
            $documentUploadKey = "document_upload_" . $requirementDocId;  // e.g., "document_upload_1"
            if (isset($request->$documentUploadKey)) {
              $file = $request->$documentUploadKey[0];
              $documentUrl = $this->handleFileUpload($file);  // Handle file upload logic
            }

            // If a document URL is set or updated, update it in the database
            if ($documentUrl) {
              $existingRequirementDoc->document_url = $documentUrl;
            }

            // Update the record with the new information
            $existingRequirementDoc->updated_by = $user_id;
            $existingRequirementDoc->update();
          }
        }
      }

      foreach ($requirementNames as $index => $requirementName) {
        $requirementDocId = $requirementDocIds[$index] ?? null;
        $documentUrl = null;
        // If no document ID, it's a new record
        if (isset($requirementUploads[$index]) && $requirementUploads[$index]) {
          $file = $requirementUploads[$index];
          $documentUrl = $this->handleFileUpload($file); // Handle file upload function
        }

        // Create a new requirement document record
        RequirementDocModel::create([
          'lead_id' => $leadId,
          'lead_requirement_id' => $leadRequirement->sno,
          'requirement_name' => $requirementName,
          'document_url' => $documentUrl ?? null,
          'created_by' => $user_id,
          'updated_by' => $user_id,
        ]);
      }

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Services Requirement updated Successfully!'
      ]);

      return redirect('manage_service');
    } else {
      // If no lead requirement found, create a new one
      $lead_reqr_chk = LeadRequirementModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$lead_reqr_chk) {
        $year = substr(date('y'), -2);
        $lead_requirement_id = 'LDRM-0001/' . $year;
      } else {
        $last_id = $lead_reqr_chk->lead_requirement_id;
        $slice = explode('/', $last_id);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int) $result + 1;
        $request = sprintf('LDRM-%04d', $next_number);
        $year = substr(date('y'), -2);
        $lead_requirement_id = $request . '/' . $year;
      }

      // Create new lead requirement record
      $leadRequirement = new LeadRequirementModel();
      $leadRequirement->lead_requirement_id = $lead_requirement_id;
      $leadRequirement->lead_id = $leadId;
      $leadRequirement->branch_id = $branch_id;
      $leadRequirement->entity_id = $entity_id;
      $leadRequirement->created_by = $user_id;
      $leadRequirement->updated_by = $user_id;

      $leadRequirement->save();


      if ($leadRequirement) {
        foreach ($data['requirement_name'] as $index => $requirementName) {

          $documentUrl = null;

          if (isset($data['document_upload'][$index])) {
            $file = $data['document_upload'][$index];

            // Get all existing filenames in the requirement_documents directory
            $existingFiles = glob(public_path('requirement_documents/requirement_doc_*.{jpg,jpeg,png,pdf,doc,docx}'), GLOB_BRACE);

            $maxIndex = 0;
            foreach ($existingFiles as $existingFile) {
              $basename = pathinfo($existingFile, PATHINFO_FILENAME); // e.g., "requirement_doc_2"
              if (preg_match('/requirement_doc_(\d+)/', $basename, $matches)) {
                $num = (int)$matches[1];
                if ($num > $maxIndex) {
                  $maxIndex = $num;
                }
              }
            }

            $nextFileIndex = $maxIndex + 1;

            $extension = $file->getClientOriginalExtension();
            $filename = 'requirement_doc_' . $nextFileIndex . '.' . $extension;

            $file->move(public_path('requirement_documents'), $filename);

            $documentUrl = $filename;
          }

          RequirementDocModel::create([
            'lead_id' => $leadId,
            'lead_requirement_id' => $leadRequirement->sno,
            'requirement_name' => $requirementName,
            'document_url' => $documentUrl ?? null,
            'created_by' => $user_id,
            'updated_by' => $user_id,
          ]);
        }
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Services Requirement added Successfully!'
        ]);
        return redirect('manage_service');
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Services Requirement could not be add!'
        ]);
        // If no lead requirement record was found or created
        return redirect('manage_service');
      }
    }
  }
  
  // Vasanth 
  // Customer Service Requirement updates 

  public function RequirementDetails_customer($id)
  {
    // Get lead + customer + product + category details
    $leadData = DB::table('et_customer_services')
      ->select(
        'et_customer_services.*',
        'et_customer.cus_name',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.country_code',
        'et_customer.customer_id AS cus_id',
        'et_product.product_name',
        'et_product.duration',
        'et_product.duration_in',
        'et_product_category.product_category_name'
      )
      ->leftJoin('et_customer', 'et_customer_services.customer_id', '=', 'et_customer.sno')
      ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
      ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->where('et_customer_services.sno', $id)
      ->first();

    // Handle missing data gracefully
    if (!$leadData) {
      return response([
        'status'    => 404,
        'message'   => 'Customer service record not found',
        'error_msg' => 'Invalid ID or data not found',
        'data'      => null,
        'lead'      => null
      ], 404);
    }

    // Fetch requirement documents using lead_id
    $requirements = RequirementDocModel::where('lead_id', $leadData->lead_id)
      ->where('status', '!=', 2)
      ->get();

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $requirements,
      'lead'      => $leadData
    ], 200);
  }

  public function ManageRequirementIndex(Request $request)
  {
    $page         = $request->input('page', 1);
    $perpage      = (int) $request->input('sorting_filter', 25);
    $offset       = ($page - 1) * $perpage;
    $branch_id    = $request->user()->branch_id ?? 1;
    $entity_id    = $request->user()->entity_id ?? 1;
    $currentMonth = date('m');
    $currentYear = date('Y');
    $user_id    = $request->user()->user_id ?? 1;

    $lead_fill        = $request->lead_fill ?? '';


    $lead_requirements = LeadRequirementModel::select(
      'et_lead_requirement.*',
      'et_lead.lead_name',
      'et_lead.lead_email_id',
      'et_lead.lead_gender',
      'et_lead.lead_id',
      'et_lead.service_id',
      'et_lead.lead_mobile',
      'pc_staff.staff_name as pc_name',
      'assign_staff.staff_name as assign_staff_name',
      'et_product_category.product_category_name',
      'et_product.product_name',
      'pc_job.job_position_name as pc_job_name',
      'assign_staff_job.job_position_name as assign_staff_job_name',
      DB::raw('(SELECT COUNT(*) FROM et_lead_requirement_doc WHERE et_lead_requirement_doc.lead_id = et_lead_requirement.lead_id and status !=2) AS requirement_count')
    )

      ->join('et_lead', 'et_lead_requirement.lead_id', '=', 'et_lead.sno')
      ->leftJoin('et_staff as assign_staff', 'et_lead_requirement.staff_id', '=', 'assign_staff.sno')
      ->leftJoin('et_staff as pc_staff', 'et_lead_requirement.pc_id', '=', 'pc_staff.sno')
      ->leftJoin('et_product_category', 'et_lead.service_category_id', '=', 'et_product_category.sno')
      ->leftJoin('et_product', 'et_lead.service_id', '=', 'et_product.sno')
      ->leftJoin('et_job_position as pc_job', 'pc_job.sno', "=", "pc_staff.position_role")
      ->leftJoin('et_job_position as assign_staff_job', 'assign_staff_job.sno', "=", "assign_staff.position_role")
      ->whereNotIn('et_lead.status', [2, 4])
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.entity_id', $entity_id)

      ->orderBy('et_lead_requirement.sno', 'desc');

    if ($lead_fill != '') {
      $lead_requirements->where(function ($query) use ($lead_fill) {
        $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }


    // if (auth()->user()->hasPermissionradio('P Management', 'Manage Requirments', 'view_self_lead')) {
    //   // User can only view their own data
    //   $lead_requirements = $lead_requirements->where('et_lead_requirement.staff_id', $user_id);
    //   // return "view_self_lead";
    // } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Requirments', 'global_lead')) {
    //   // User can view all data
    //   $lead_requirements = $lead_requirements;
    //   // return "global_lead";
    // } else {
    //   // No permission
    //   abort(403, 'Unauthorized');
    // }

    $lead_requirements = $lead_requirements->paginate($perpage);

    foreach ($lead_requirements as $req) {
      $serviceIds = json_decode($req->service_id, true);
      if (!is_array($serviceIds)) {
        continue;
      }
      $products = DB::table('et_product')
        ->select('et_product_category.product_category_name', 'et_product.product_name')
        ->whereIn('et_product.sno', $serviceIds)
        ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->get();

      // Extract product names
      $productNames = $products->pluck('product_name')->toArray();
      $req->product_name = implode(', ', $productNames); // e.g., "product1, product2"

      // Extract unique category names
      $uniqueCategories = $products->pluck('product_category_name')->unique()->values()->toArray();
      $req->product_category_name = implode(', ', $uniqueCategories); // e.g., "Category1, Category2"
    }

    $reasonList_reject = DB::table('et_requirement_reason')->select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    return view('content.production_management.manage_requirement.manage_requirement', [
      'perpage'           => $perpage,
      'lead_requirements'      => $lead_requirements,
      'reasonList_reject'      => $reasonList_reject,
      'lead_fill'         => $lead_fill,
    ]);
  }

  public function AssignPCRequirement(Request $request)
  {
    $id = $request->assign_requirement_id;
    $user_id = $request->user()->user_id ?? 1;
    $lead    = LeadRequirementModel::where('sno', $id)->first();

    if ($lead) {
      $lead->pc_id    = $request->assign_staff_id;
      $lead->updated_by   = $user_id;
      $lead->update();
      if ($lead->update()) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => ' PC Assigned Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Could Not Update!'
        ]);
      }
    }
    return redirect()->back();
  }

}
