<?php

namespace App\Http\Controllers\lead_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\LeadModel;
use App\Models\LeadBankReasonModel;
use App\Models\ProductModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class HotLead extends Controller
{


  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    $entity_id = $request->user()->entity_id;

    // Filters
    $lead_fill = $request->input('lead_fill', '');

    $leads = LeadModel::select(
      'et_lead.sno',
      'et_lead.lead_id',
      'et_lead.transfer_status',
      'et_lead.is_hot_lead',
      'et_lead.created_at',
      'et_lead.created_by',
      'et_lead.dc_staff_id',
      'et_lead.inter_calls',
      'et_lead.registered_date',
      'et_lead.lead_mobile',
      'et_lead.dialed_count',
      'et_lead.document_send_count',
      'et_lead.incoming_count',
      'et_lead.outgoing_count',
      'et_lead.missed_reject_count',
      'et_lead.spam_verified',
      'et_lead.drop_verified',
      'et_lead.spam_tl_verified',
      'et_lead.last_hot_lead_date',
      'et_lead.drop_tl_verified',
      'et_lead.service_id',
      'et_lead.phone_verify_status',
      'et_lead.phone_verify_content',
      'et_lead.just_dial_id',
      'et_lead.cloud_call_id',
      'et_lead.website_id',
      'et_lead.call_tracker_id',
      'et_lead.lead_email_id',
      'et_lead.lead_gender',
      'et_lead.lead_dob',
      'et_lead.lead_answer',
      'et_lead.lead_marital_status',
      'et_lead_status.lead_bg_color',
      'et_staff.staff_name',
      'et_staff.nick_name',
      'et_lead.lead_score',
      'et_lead.status',
      'et_lead.lead_condition',
      'et_lead.lead_status_id',
      'et_lead.lead_name',
      'et_lead_type.lead_type_name',
      'et_lead_type.sno as lead_type_id',
      'et_lead_source.lead_source_name',
      'et_lead_source.sno as lead_source_id',
      'et_potential_type.potential_type_name as potential_type_name',
      'et_potential_type.potential_type_image',
      'et_lead.is_potential',
      'et_lead.potential_comments',
      'et_lead.potentail_reason',
      DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
      DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments'),
      'latest_appointment.appointment_date',
      'latest_appointment.lead_id as followup_latest_id'
    )
      ->leftJoin(
        DB::raw('(SELECT lead_id, status, appointment_date,
            SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score,
            ROW_NUMBER() OVER (PARTITION BY lead_id ORDER BY appointment_date DESC) as rn
            FROM et_appointment) AS latest_appointment'),
        function ($join) {
          $join->on('et_lead.sno', '=', 'latest_appointment.lead_id')
            ->where('latest_appointment.rn', '=', 1);
        }
      )
      ->leftJoin(
        DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
            FROM et_appointment
            GROUP BY lead_id) AS appointment_counts'),
        'et_lead.sno',
        '=',
        'appointment_counts.lead_id'
      )
      ->leftJoin('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
      ->leftJoin('et_lead_status', 'et_lead.lead_status_id', '=', 'et_lead_status.sno')
      ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
      ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
      ->leftJoin('et_potential_type', 'et_lead.lead_potential_type_id', '=', 'et_potential_type.sno')
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.status', 0)
       ->where(function ($q) {
        $q->where('et_lead.lead_status_id', 3)
          ->orWhere('et_lead.is_hot_lead', 1);
      })
      ->groupBy(
        'et_lead.sno',
        'et_lead.lead_id',
        'et_lead.transfer_status',
        'et_lead.is_hot_lead',
        'et_lead.lead_mobile',
        'et_lead.created_at',
        'et_lead.incoming_count',
        'et_lead.dialed_count',
        'et_lead.created_by',
        'et_lead.dc_staff_id',
        'latest_appointment.lead_id',
        'et_lead.outgoing_count',
        'et_lead.missed_reject_count',
        'et_lead.spam_verified',
        'et_lead.drop_verified',
        'et_lead.spam_tl_verified',
        'et_lead.drop_tl_verified',
        'et_lead.document_send_count',
        'et_lead.phone_verify_status',
        'et_lead.last_hot_lead_date',
        'et_lead.phone_verify_content',
        'et_lead.just_dial_id',
        'et_lead.cloud_call_id',
        'et_lead.website_id',
        'et_lead.call_tracker_id',
        'et_lead.registered_date',
        'et_lead.lead_email_id',
        'et_lead.service_id',
        'et_lead.lead_gender',
        'et_lead.lead_dob',
        'et_lead.inter_calls',
        'et_lead.lead_answer',
        'et_lead.lead_marital_status',
        'et_lead_status.lead_bg_color',
        'et_staff.staff_name',
        'et_staff.nick_name',
        'et_lead.lead_score',
        'et_lead.status',
        'et_lead.lead_condition',
        'et_lead.lead_status_id',
        'et_lead.lead_name',
        'et_lead_type.lead_type_name',
        'et_lead_type.sno',
        'et_lead_source.lead_source_name',
        'et_lead_source.sno',
        'latest_appointment.appointment_date',
        'latest_appointment.total_app_score',
        'et_potential_type.potential_type_name',
        'et_potential_type.potential_type_image',
        'et_lead.potential_comments',
        'et_lead.is_potential',
        'et_lead.potentail_reason',
        'appointment_counts.total_appointments'
      );

    // Apply permission filters
    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      $leads = $leads->where('et_lead.created_by', $user_id);
    } elseif (!auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
      abort(403, 'Unauthorized');
    }

    // Apply search filter
    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }

    // Apply ordering and pagination
    $leads = $leads->orderBy('et_lead.spam_verified', 'asc')
      ->orderBy('et_lead.sno', 'desc') // Add secondary order for consistency
      ->paginate($perpage);

    $follwup_count = 0;
    $not_follow_up_ids = [];

    // Pre-fetch all proposal data for leads to avoid N+1 queries
    $leadIds = $leads->pluck('sno')->toArray();

    // Fetch all proposals at once
    $proposals = DB::table('et_proposal')
      ->where('status', 0)
      ->whereIn('lead_id', $leadIds)
      ->orderBy('sno', 'desc')
      ->get()
      ->groupBy('lead_id');

    // Fetch all appointments at once
    $appointments = DB::table('et_appointment')
      ->whereIn('lead_id', $leadIds)
      ->orderBy('sno', 'desc')
      ->get()
      ->groupBy('lead_id');

    $leadAppointments = DB::table('et_lead_appointment')
      ->whereIn('lead_id', $leadIds)
      ->orderBy('sno', 'desc')
      ->get()
      ->groupBy('lead_id');

    $helper = new \App\Helpers\Helpers();
    $hotLeadDays = DB::table('et_general_settings')->value('hot_lead_days');

    foreach ($leads as $singleLead) {
      // Follow-up count logic
      $createdAt = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      $chk1day = $createdAt->diffInHours($currentDateTime) >= 24;

      if ($chk1day && !$singleLead->followup_latest_id) {
        $follwup_count++;
        $not_follow_up_ids[] = $singleLead->sno;
      }
      if ($singleLead->last_hot_lead_date) {

        $lastDate = \Carbon\Carbon::parse($singleLead->last_hot_lead_date);
        $expiryDate = $lastDate->copy()->addDays($hotLeadDays);

        $singleLead->hot_lead_days_left = now()->diffInDays($expiryDate, false);
      } else {
        $singleLead->hot_lead_days_left = 0;
      }

      // Format phone number
      $normalizedPhoneNo = ltrim($singleLead->lead_mobile, '0');
      $singleLead->phoneWithCountryCode = '+91' . $normalizedPhoneNo;

      // Add proposals from pre-fetched data
      $proposal_list = isset($proposals[$singleLead->sno]) ? $proposals[$singleLead->sno] : collect();
      foreach ($proposal_list as $proposal) {
        $proposal->encrypt_id = $helper->encrypt_decrypt($proposal->sno, 'encrypt');
      }
      $singleLead->proposal_list = $proposal_list;

      // Add product data
      if ($singleLead->service_id) {
        $service_ids = json_decode($singleLead->service_id);
        if (is_array($service_ids) && count($service_ids) > 0) {
          $product_data = ProductModel::select('et_product.product_name', 'et_product_category.product_category_name')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->whereIn('et_product.sno', $service_ids)
            ->get();
          $singleLead->productsData = $product_data;
        } else {
          $singleLead->productsData = collect();
        }
      }

      // Add appointment data from pre-fetched collections
      $lead = isset($appointments[$singleLead->sno]) ? $appointments[$singleLead->sno]->first() : null;
      $leadapp = isset($leadAppointments[$singleLead->sno]) ? $leadAppointments[$singleLead->sno]->first() : null;

      $singleLead->lead_appointment_status = $leadapp->appointment_status ?? "0";
      $singleLead->appointment_lead_id = $leadapp->lead_id ?? "0";
      $singleLead->appointment_status = $lead->status ?? "0";

      // Alert status calculation
      $alert_status = 0;
      if ($chk1day && !$singleLead->followup_latest_id) {
        $alert_status = 1;
      }
      $singleLead->alert_status = $alert_status;

      // Registered date difference
      $registeredDate = Carbon::parse($singleLead->registered_date);
      $diff = $registeredDate->diff(Carbon::now());

      $parts = [];
      if ($diff->y > 0) {
        $parts[] = "{$diff->y} year" . ($diff->y > 1 ? 's' : '');
      }
      if ($diff->m > 0) {
        $parts[] = "{$diff->m} month" . ($diff->m > 1 ? 's' : '');
      }
      if ($diff->d > 0 || empty($parts)) {
        $parts[] = "{$diff->d} day" . ($diff->d > 1 ? 's' : '');
      }

      $singleLead->formattedDifference = implode(' and ', $parts);
      $singleLead->formattedDayDifference = $diff->d;

      // Remove undefined variable issue
      $singleLead->staff_id = "0";
    }

    $reasonList_lead_bank = LeadBankReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->get();
    $monitor = DB::table('et_cronjob_monitor')
      ->where('sno', 21)
      ->first();

    return view('content.lead_management.manage_lead.hot_lead_list', compact(
      'leads',
      'perpage',
      'lead_fill',
      'monitor',
      'reasonList_lead_bank'
    ));
  }
  public function unMarkHotLead($id)
  {
    $sch = DB::table('et_lead')->where('sno', $id)->first();

    if (!$sch) {
      return response([
        'status' => 404,
        'message' => "Could not find the lead table to unmark.",
        'error_msg' => null,
        'data' => null,
      ], 404);
    }

    DB::transaction(function () use ($sch, $id) {
      DB::table('et_lead')
        ->where('sno',  $id)
        ->update([
          'lead_status_id' => 2,
          'is_hot_lead' => 2,
          'updated_at' => now()
        ]);
    });

    return response([
      'status' => 200,
      'message' => 'Successfully unMark Hot Lead!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
}
