<?php

namespace App\Http\Controllers\lead_management;

use App\Http\Controllers\Controller;
use App\Models\LeadModel;
use App\Models\PaymentModel;
use App\Models\CustomerModel;
use App\Models\CloudCallModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class LeadCalendar extends Controller
{
    public function lead_calendar(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;

        // Get current month and year from request, defaulting to current month-year format (e.g., "Apr-2025")
        $month_filter = $request->get('month_filter', date('M-Y'));

        // Parse the date using Carbon for better reliability
        $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);

        // Extract month and year properly
        $month = $parsedDate->month; // numeric month (1-12)
        $year = $parsedDate->year;

        // Calculate previous and next month/year
        $previousMonth = $month > 1 ? $month - 1 : 12;
        $previousYear = $month == 1 ? $year - 1 : $year;

        $nextMonth = $month < 12 ? $month + 1 : 1;
        $nextYear = $month == 12 ? $year + 1 : $year;

        // First day of selected month
        $firstDayOfMonth = Carbon::createFromDate($year, $month, 1);
        $daysInMonth = $firstDayOfMonth->daysInMonth;
        $startDayOfWeek = $firstDayOfMonth->dayOfWeek; // 0 (Sun) to 6 (Sat)

        // Check if selected month is current or future
        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;

        // return $month_chk;

        // Initialize arrays to store lead counts
        $totalLeadCount = [];
        $LeadDetail = [];
        $datesInMonth = collect();
        // return $month;

        $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
            // ->where('et_lead.created_by', '>', 0)
            ->where('et_lead.branch_id', $branch_id)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0);
         if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
            // User can only view their own data
            $monthLeadCount = $monthLeadCount->where('et_lead.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
            // User can view all data
            $monthLeadCount = $monthLeadCount;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        
           $monthLeadCount=$monthLeadCount->count();

        $monthCustomerCount = CustomerModel::select('et_customer.sno')
            ->where('et_customer.branch_id', $branch_id)
            ->join('et_lead','et_customer.lead_id','=','et_lead.sno')
            ->whereYear('et_customer.created_at', $year)
            ->whereMonth('et_customer.created_at', $month);
          if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                // User can only view their own data
                $monthCustomerCount = $monthCustomerCount->where('et_lead.created_by', $user_id);
                // return "view_self_lead";
            } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                // User can view all data
                $monthCustomerCount = $monthCustomerCount;
                // return "global_lead";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
            $monthCustomerCount=$monthCustomerCount->count();

        $monthSpamCount = LeadModel::select('*')
            ->where('status', 7)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.spam_verified', 1)
            // ->where('created_by', '>', 0)
            ->where('branch_id', $branch_id);
            if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                // User can only view their own data
                $monthSpamCount = $monthSpamCount->where('et_lead.created_by', $user_id);
                // return "view_self_lead";
            } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                // User can view all data
                $monthSpamCount = $monthSpamCount;
                // return "global_lead";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
            
            $monthSpamCount=$monthSpamCount->count();

        $monthCallLog = CloudCallModel::select(
            'et_cloud_call.*',
            'et_lead.lead_name',
            'et_lead.drop_verified',
            'et_lead.drop_tl_verified',
            'et_lead.spam_verified',
            'et_lead.spam_tl_verified',
            'et_lead.status AS lead_status',
            'et_lead.lead_mobile',
            'et_lead.created_by AS lead_created_by',
            'et_staff.staff_name'
        )
            ->leftJoin('et_lead', function ($join) {
                $join->on('et_lead.lead_mobile', '=', DB::raw("RIGHT(et_cloud_call.caller_number, 10)"));
            })
            ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
            ->whereYear('start_time', $year)
            ->where('et_cloud_call.branch_id', $branch_id)
            ->whereMonth('start_time', $month);
            if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                // User can only view their own data
                $monthCallLog = $monthCallLog->where('et_lead.created_by', $user_id);
                // return "view_self_lead";
            } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                // User can view all data
                $monthCallLog = $monthCallLog;
                // return "global_lead";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
            
            $monthCallLog=$monthCallLog->orderBy('start_time', 'DESC')->count();

        // return $monthCallLog;


        // return $monthLeadCount;


        // Loop through all the days of the selected month
        for ($i = 1; $i <= $daysInMonth; $i++) {
            $datesInMonth = Carbon::createFromDate($year, $month, $i)->toDateString();
            

            // Fetch total leads for the given day
            $totalLeadCounts = LeadModel::select('*')
                ->whereNotIn('status', [2, 6])
                ->whereDate('registered_date', $datesInMonth)
                // ->where('created_by', '>', 0)
                ->where('branch_id', $branch_id)
                ->where('spam_verified', 0)
                ->where('internal_status', 0);
                if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                    // User can only view their own data
                    $totalLeadCounts = $totalLeadCounts->where('created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                    // User can view all data
                    $totalLeadCounts = $totalLeadCounts;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                
               $totalLeadCounts=$totalLeadCounts->get();

            $totalLeadCount[] = [
                'Date' => $datesInMonth,
                'TotalLeads' => $totalLeadCounts->count()
            ];

            $LeadDetails = LeadModel::select('et_lead.lead_name', 'et_lead.lead_mobile', 'et_staff.staff_name', 'et_staff.position_role', 'et_job_position.job_position_name', 'et_lead_source.lead_source_name')
                ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
                ->leftJoin('et_job_position', 'et_staff.position_role', '=', 'et_job_position.sno')
                ->whereNotIn('et_lead.status', [2, 6])
                // ->where('et_lead.created_by', '>', 0)
                ->where('spam_verified', 0)
                ->where('internal_status', 0)
                ->whereDate('et_lead.registered_date', $datesInMonth)
                ->where('et_lead.branch_id', $branch_id);
                if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                    // User can only view their own data
                    $LeadDetails = $LeadDetails->where('et_lead.created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                    // User can view all data
                    $LeadDetails = $LeadDetails;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                
                $LeadDetails=$LeadDetails->get();

            $LeadDetail[] = [
                'Date' => $datesInMonth,
                'TotalLeads' => $totalLeadCounts->count(),
                'LeadDetails' => $LeadDetails
            ];

            // return $LeadDetail;
        }

        // Initialize array for lead conversions
        $leadConvert = [];
        $LeadConvertDetail = [];

        // Loop through all the days of the selected month
        for ($i = 1; $i <= $daysInMonth; $i++) {
            $datesInMonth = Carbon::createFromDate($year, $month, $i)->toDateString();
            // return $datesInMonth;

            // Fetch lead conversions for the given day
            $leadConverts = CustomerModel::select('et_customer.sno')
                ->join('et_lead','et_customer.lead_id','=','et_lead.sno')
                // ->where('et_customer.status', 0)
                ->where('et_customer.branch_id', $branch_id)
                ->whereDate('et_customer.created_at', $datesInMonth);
                if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                    // User can only view their own data
                    $leadConverts = $leadConverts->where('et_lead.created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                    // User can view all data
                    $leadConverts = $leadConverts;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                
                $leadConverts=$leadConverts->get();

            $leadConvert[] = [
                'Date' => $datesInMonth,
                'LeadConvert' => $leadConverts->count()
            ];
            // return $leadConvert;

            $LeadConvertDetails = CustomerModel::select('et_customer.cus_name', 'et_customer.cus_mobile', 'et_staff.staff_name', 'et_staff.position_role', 'et_job_position.job_position_name')
                ->leftJoin('et_staff', 'et_customer.created_by', '=', 'et_staff.sno')
                ->leftJoin('et_job_position', 'et_staff.position_role', '=', 'et_job_position.sno')
                // ->leftJoin('et_course_type', 'et_course.course_type_id', '=', 'et_course_type.sno')
                // ->where('et_customer.status', 0)
                ->where('et_customer.branch_id', $branch_id)
                ->whereDate('et_customer.created_at', $datesInMonth)
                ->get();
            // $LeadConvertDetails = [];

            $LeadConvertDetail[] = [
                'Date' => $datesInMonth,
                'LeadConvert' => $leadConverts->count(),
                'LeadConvertDetails' => $LeadConvertDetails
            ];
        }
        // return $leadConvert;

        // Initialize array for lead conversions
        $spamCount = [];
        $spamCountDetails = [];

        // Loop through all the days of the selected month
        for ($i = 1; $i <= $daysInMonth; $i++) {
            $datesInMonth = Carbon::createFromDate($year, $month, $i)->toDateString();

            // Fetch lead conversions for the given day
            $spamCounts = LeadModel::select('*')
                ->where('status', 7)
                // ->where('created_by', '>', 0)
                ->where('et_lead.spam_verified', 1)
                ->where('internal_status', 0)
                ->whereDate('registered_date', $datesInMonth)
                ->where('branch_id', $branch_id);
                if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                    // User can only view their own data
                    $spamCounts = $spamCounts->where('created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                    // User can view all data
                    $spamCounts = $spamCounts;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                
                $spamCounts=$spamCounts->get();

            $spamCount[] = [
                'Date' => $datesInMonth,
                'spamCount' => $spamCounts->count()  // The count is stored here
            ];

            $spamCountDetail = LeadModel::select('et_lead.lead_name', 'et_lead.lead_mobile', 'et_staff.staff_name', 'et_staff.position_role', 'et_job_position.job_position_name', 'et_lead_source.lead_source_name')
                ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
                ->leftJoin('et_job_position', 'et_staff.position_role', '=', 'et_job_position.sno')
                ->where('et_lead.status', 7)
                // ->where('et_lead.created_by', '>', 0)
                ->where('et_lead.spam_verified', 1)
                ->where('internal_status', 0)
                ->whereDate('et_lead.registered_date', $datesInMonth)
                ->where('et_lead.branch_id', $branch_id);
              if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                    // User can only view their own data
                    $spamCountDetail = $spamCountDetail->where('et_lead.created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                    // User can view all data
                    $spamCountDetail = $spamCountDetail;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                $spamCountDetail=$spamCountDetail->get();

            $spamCountDetails[] = [
                'Date' => $datesInMonth,
                'spamCount' => $spamCounts->count(),
                'spamCountDetails' => $spamCountDetail
            ];
        }

        $callLog = [];
        $callLogDetail = [];
        // return $spamCountDetails;
        for ($i = 1; $i <= $daysInMonth; $i++) {

            $datesInMonth = Carbon::createFromDate($year, $month, $i)->toDateString();


            $callLogs = CloudCallModel::select(
                'et_cloud_call.*',
                'et_lead.lead_name',
                'et_lead.drop_verified',
                'et_lead.drop_tl_verified',
                'et_lead.spam_verified',
                'et_lead.spam_tl_verified',
                'et_lead.status AS lead_status',
                'et_lead.lead_mobile',
                'et_lead.created_by AS lead_created_by',
                'et_staff.staff_name'
            )
                ->leftJoin('et_lead', function ($join) {
                    $join->on('et_lead.lead_mobile', '=', DB::raw("RIGHT(et_cloud_call.caller_number, 10)"));
                })

                ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
                ->where('et_cloud_call.branch_id', $branch_id)
                ->whereDate('start_time', $datesInMonth);
                if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                    // User can only view their own data
                    $callLogs = $callLogs->where('et_lead.created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                    // User can view all data
                    $callLogs = $callLogs;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                
               $callLogs=$callLogs->get();

            $callLog[] = [
                'Date' => $datesInMonth,
                'callLog' => $callLogs->count()
            ];

            $callLogDetails = CloudCallModel::select(
                'et_cloud_call.*',
                'et_lead.lead_name',
                'et_lead.drop_verified',
                'et_lead.drop_tl_verified',
                'et_lead.spam_verified',
                'et_lead.spam_tl_verified',
                'et_lead.status AS lead_status',
                'et_lead.lead_mobile',
                'et_lead.created_by AS lead_created_by',
                'et_staff.staff_name'
            )
                ->leftJoin('et_lead', function ($join) {
                    $join->on('et_lead.lead_mobile', '=', DB::raw("RIGHT(et_cloud_call.caller_number, 10)"));
                })
                ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
                ->where('et_cloud_call.branch_id', $branch_id)
                ->whereDate('start_time', $datesInMonth);
                if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                    // User can only view their own data
                    $callLogDetails = $callLogDetails->where('et_lead.created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                    // User can view all data
                    $callLogDetails = $callLogDetails;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                
               $callLogDetails=$callLogDetails->get();

            $callLogDetail[] = [
                'Date' => $datesInMonth,
                'callLog' => $callLogs->count(),
                'callLogDetail' => $callLogDetails
            ];
        }
        // return $callLogDetail;

        $dateData_garph = [];
        for ($i = 1; $i <= $daysInMonth; $i++) {
            $datesInMonth = Carbon::createFromDate($year, $month, $i)->toDateString();
            $spamCounts = LeadModel::select('*')
                ->where('status', 7)
                // ->where('created_by', '>', 0)
                ->where('et_lead.spam_verified', 1)
                ->where('internal_status', 0)
                ->whereDate('registered_date', $datesInMonth)
                ->where('branch_id', $branch_id);
                if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                    // User can only view their own data
                    $spamCounts = $spamCounts->where('created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                    // User can view all data
                    $spamCounts = $spamCounts;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                
               $spamCounts=$spamCounts->get();

            $leadConverts = CustomerModel::select('et_customer.*')
                ->join('et_lead','et_customer.lead_id','=','et_lead.sno')
                // ->where('et_customer.status', 0)
                ->where('et_customer.branch_id', $branch_id)
                ->whereDate('et_customer.created_at', $datesInMonth);
                if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                    // User can only view their own data
                    $leadConverts = $leadConverts->where('et_lead.created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                    // User can view all data
                    $leadConverts = $leadConverts;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                
              $leadConverts=$leadConverts->get();

            $totalLeadCounts = LeadModel::select('*')
                ->whereNotIn('status', [2, 6])
                ->whereDate('registered_date', $datesInMonth)
                // ->where('created_by', '>', 0)
                ->where('spam_verified', 0)
                ->where('internal_status', 0)
                ->where('branch_id', $branch_id);
                if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                    // User can only view their own data
                    $totalLeadCounts = $totalLeadCounts->where('created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                    // User can view all data
                    $totalLeadCounts = $totalLeadCounts;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                
                $totalLeadCounts=$totalLeadCounts->get();

            $totalCallLogs = CloudCallModel::select(
                'et_cloud_call.*',
                'et_lead.lead_name',
                'et_lead.drop_verified',
                'et_lead.drop_tl_verified',
                'et_lead.spam_verified',
                'et_lead.spam_tl_verified',
                'et_lead.status AS lead_status',
                'et_lead.lead_mobile',
                'et_lead.created_by AS lead_created_by',
                'et_staff.staff_name'
            )
                ->leftJoin('et_lead', function ($join) {
                    $join->on('et_lead.lead_mobile', '=', DB::raw("RIGHT(et_cloud_call.caller_number, 10)"));
                })
                ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
                ->where('et_cloud_call.branch_id', $branch_id)
                ->whereDate('start_time', $datesInMonth);
                if(auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'view_self_lead')) {
                    // User can only view their own data
                    $totalCallLogs = $totalCallLogs->where('et_lead.created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead Calendar', 'global_lead')) {
                    // User can view all data
                    $totalCallLogs = $totalCallLogs;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                
                $totalCallLogs=$totalCallLogs->get();


            $dateData_garph[] =  [
                'Date' => $datesInMonth,
                'customer_count' => $leadConverts->count(),
                'lead_count' => $totalLeadCounts->count(),
                'spam_count' => $spamCounts->count(),
                'cloud_count' => $totalCallLogs->count()
            ];
        }

        // return $dateData_garph;
        // return  [
        //     'month_chk' => $month_chk,
        //     'previousMonth' => $previousMonth,
        //     'previousYear' => $previousYear,
        //     'nextMonth' => $nextMonth,
        //     'nextYear' => $nextYear,
        //     'startDayOfWeek' => $startDayOfWeek,
        //     'totalLeadCount' => $totalLeadCount,
        //     'leadConvert' => $leadConvert,
        //     'callLog' => $callLog,
        //     'month_filter' => $month_filter,
        //     'LeadDetail' => $LeadDetail,
        //     'LeadConvertDetail' => $LeadConvertDetail,
        //     'spamCountDetails' => $spamCountDetails,
        //     'callLogDetail' => $callLogDetail,
        //     'spamCount' => $spamCount,
        //     'monthSpamCount' => $monthSpamCount,
        //     'monthCustomerCount' => $monthCustomerCount,
        //     'monthLeadCount' => $monthLeadCount,
        //     'monthCallLog' => $monthCallLog,
        //     'dateData_garph' => $dateData_garph
        // ];

        // Return the view with the necessary data
        return view('content.lead_management.manage_calendar.list', [
            'month_chk' => $month_chk,
            'previousMonth' => $previousMonth,
            'previousYear' => $previousYear,
            'nextMonth' => $nextMonth,
            'nextYear' => $nextYear,
            'startDayOfWeek' => $startDayOfWeek,
            'totalLeadCount' => $totalLeadCount,
            'leadConvert' => $leadConvert,
            'callLog' => $callLog,
            'month_filter' => $month_filter,
            'LeadDetail' => $LeadDetail,
            'LeadConvertDetail' => $LeadConvertDetail,
            'spamCountDetails' => $spamCountDetails,
            'callLogDetail' => $callLogDetail,
            'spamCount' => $spamCount,
            'monthSpamCount' => $monthSpamCount,
            'monthCustomerCount' => $monthCustomerCount,
            'monthLeadCount' => $monthLeadCount,
            'monthCallLog' => $monthCallLog,
            'dateData_garph' => $dateData_garph,
            'currentMonth' => $month,
            'currentYear'  => $year,
        ]);
    }
}