<?php

namespace App\Http\Controllers\lead_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\AppointmentModel;
use App\Models\BranchModel;
use App\Models\DropReasonModel;
use App\Models\LeadExportExcel;
use App\Models\LeadExportModel;
use App\Models\LeadModel;
use App\Models\LeadTransferLogModel;
use App\Models\RawLeadModel;
use App\Models\SpamReasonModel;
use App\Models\User;

use App\Models\StaffpointsModel;
use App\Models\LeadBankReasonModel;
use App\Models\ProductModel;
use Carbon\Carbon;
use DateTime;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;

class DailyCallLead extends Controller
{


  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    $entity_id = $request->user()->entity_id;

    // Filters
    $lead_fill = $request->input('lead_fill', '');

    $leads = LeadModel::select(
      'et_schedule_daily_call.sno as sch_sno',
      'et_lead.sno',
      'et_lead.lead_id',
      'et_lead.transfer_status',
      'et_lead.is_hot_lead',
      'et_lead.created_at',
      'et_lead.created_by',
      'et_lead.dc_staff_id',
      'et_lead.inter_calls',
      'et_lead.registered_date',
      'et_lead.lead_mobile',
      'et_lead.dialed_count',
      'et_lead.document_send_count',
      'et_lead.incoming_count',
      'et_lead.outgoing_count',
      'et_lead.missed_reject_count',
      'et_lead.spam_verified',
      'et_lead.drop_verified',
      'et_lead.spam_tl_verified',
      'et_lead.drop_tl_verified',
      'et_lead.service_id',
      'et_lead.phone_verify_status',
      'et_lead.phone_verify_content',
      'et_lead.just_dial_id',
      'et_lead.cloud_call_id',
      'et_lead.website_id',
      'et_lead.call_tracker_id',
      'et_lead.lead_email_id',
      'et_lead.lead_gender',
      'et_lead.lead_dob',
      'et_lead.lead_answer',
      'et_lead.lead_marital_status',
      'et_lead_status.lead_bg_color',
      'et_staff.staff_name',
      'et_staff.nick_name',
      'et_lead.lead_score',
      'et_lead.status',
      'et_lead.lead_condition',
      'et_lead.lead_status_id',
      'et_lead.lead_name',
      'et_lead_type.lead_type_name',
      'et_lead_type.sno as lead_type_id',
      'et_lead_source.lead_source_name',
      'et_lead_source.sno as lead_source_id',
      'et_potential_type.potential_type_name as potential_type_name',
      'et_potential_type.potential_type_image',
      'assgin.staff_name as assgin_staff',
      'et_lead.is_potential',
      'et_lead.potential_comments',
      'et_lead.potentail_reason',
      DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
      DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments'),
      'latest_appointment.appointment_date',
      'latest_appointment.lead_id as followup_latest_id'
    )
      ->leftJoin(
        DB::raw('(SELECT lead_id, status, appointment_date,
            SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score,
            ROW_NUMBER() OVER (PARTITION BY lead_id ORDER BY appointment_date DESC) as rn
            FROM et_appointment) AS latest_appointment'),
        function ($join) {
          $join->on('et_lead.sno', '=', 'latest_appointment.lead_id')
            ->where('latest_appointment.rn', '=', 1);
        }
      )
      ->leftJoin(
        DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
            FROM et_appointment
            GROUP BY lead_id) AS appointment_counts'),
        'et_lead.sno',
        '=',
        'appointment_counts.lead_id'
      )
      ->join('et_schedule_daily_call', 'et_lead.sno', '=', 'et_schedule_daily_call.lead_id')
      ->join('et_staff as assgin', 'et_schedule_daily_call.current_staff', '=', 'assgin.sno')
      ->leftJoin('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
      ->leftJoin('et_lead_status', 'et_lead.lead_status_id', '=', 'et_lead_status.sno')
      ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
      ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
      ->leftJoin('et_potential_type', 'et_lead.lead_potential_type_id', '=', 'et_potential_type.sno')
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.status', 0)
      ->where('et_schedule_daily_call.status', 0)
      ->whereDate('et_schedule_daily_call.sch_date', '<=', now())
      ->where('et_lead.lead_bank_status', '!=', 1)
      ->groupBy(
        'et_schedule_daily_call.sno',
        'et_lead.sno',
        'et_lead.lead_id',
        'et_lead.transfer_status',
        'et_lead.is_hot_lead',
        'et_lead.lead_mobile',
        'et_lead.created_at',
        'et_lead.incoming_count',
        'et_lead.dialed_count',
        'et_lead.created_by',
        'et_lead.dc_staff_id',
        'et_lead.outgoing_count',
        'et_lead.missed_reject_count',
        'et_lead.spam_verified',
        'et_lead.drop_verified',
        'et_lead.spam_tl_verified',
        'et_lead.drop_tl_verified',
        'et_lead.document_send_count',
        'et_lead.phone_verify_status',
        'et_lead.phone_verify_content',
        'et_lead.just_dial_id',
        'et_lead.cloud_call_id',
        'latest_appointment.lead_id',
        'et_lead.website_id',
        'et_lead.call_tracker_id',
        'assgin.staff_name',
        'et_lead.registered_date',
        'et_lead.lead_email_id',
        'et_lead.service_id',
        'et_lead.lead_gender',
        'et_lead.lead_dob',
        'et_lead.inter_calls',
        'et_lead.lead_answer',
        'et_lead.lead_marital_status',
        'et_lead_status.lead_bg_color',
        'et_staff.staff_name',
        'et_staff.nick_name',
        'et_lead.lead_score',
        'et_lead.status',
        'et_lead.lead_condition',
        'et_lead.lead_status_id',
        'et_lead.lead_name',
        'et_lead_type.lead_type_name',
        'et_lead_type.sno',
        'et_lead_source.lead_source_name',
        'et_lead_source.sno',
        'latest_appointment.appointment_date',
        'latest_appointment.total_app_score',
        'et_potential_type.potential_type_name',
        'et_potential_type.potential_type_image',
        'et_lead.potential_comments',
        'et_lead.is_potential',
        'et_lead.potentail_reason',
        'appointment_counts.total_appointments'
      );

    // Apply permission filters
    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      $leads = $leads->where('et_schedule_daily_call.current_staff', $user_id);
    } elseif (!auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
      abort(403, 'Unauthorized');
    }

    // Apply search filter
    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }

    // Apply ordering and pagination
    $leads = $leads->orderBy('et_lead.spam_verified', 'asc')
      ->orderBy('et_lead.sno', 'desc') // Add secondary order for consistency
      ->paginate($perpage);

    $follwup_count = 0;
    $not_follow_up_ids = [];

    // Pre-fetch all proposal data for leads to avoid N+1 queries
    $leadIds = $leads->pluck('sno')->toArray();

    // Fetch all proposals at once
    $proposals = DB::table('et_proposal')
      ->where('status', 0)
      ->whereIn('lead_id', $leadIds)
      ->orderBy('sno', 'desc')
      ->get()
      ->groupBy('lead_id');

    // Fetch all appointments at once
    $appointments = DB::table('et_appointment')
      ->whereIn('lead_id', $leadIds)
      ->orderBy('sno', 'desc')
      ->get()
      ->groupBy('lead_id');

    $leadAppointments = DB::table('et_lead_appointment')
      ->whereIn('lead_id', $leadIds)
      ->orderBy('sno', 'desc')
      ->get()
      ->groupBy('lead_id');

    $helper = new \App\Helpers\Helpers();

    foreach ($leads as $singleLead) {
      // Follow-up count logic
      $createdAt = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      $chk1day = $createdAt->diffInHours($currentDateTime) >= 24;

      if ($chk1day && !$singleLead->followup_latest_id) {
        $follwup_count++;
        $not_follow_up_ids[] = $singleLead->sno;
      }

      // Format phone number
      $normalizedPhoneNo = ltrim($singleLead->lead_mobile, '0');
      $singleLead->phoneWithCountryCode = '+91' . $normalizedPhoneNo;

      // Add proposals from pre-fetched data
      $proposal_list = isset($proposals[$singleLead->sno]) ? $proposals[$singleLead->sno] : collect();
      foreach ($proposal_list as $proposal) {
        $proposal->encrypt_id = $helper->encrypt_decrypt($proposal->sno, 'encrypt');
      }
      $singleLead->proposal_list = $proposal_list;

      // Add product data
      if ($singleLead->service_id) {
        $service_ids = json_decode($singleLead->service_id);
        if (is_array($service_ids) && count($service_ids) > 0) {
          $product_data = ProductModel::select('et_product.product_name', 'et_product_category.product_category_name')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->whereIn('et_product.sno', $service_ids)
            ->get();
          $singleLead->productsData = $product_data;
        } else {
          $singleLead->productsData = collect();
        }
      }

      // Add appointment data from pre-fetched collections
      $lead = isset($appointments[$singleLead->sno]) ? $appointments[$singleLead->sno]->first() : null;
      $leadapp = isset($leadAppointments[$singleLead->sno]) ? $leadAppointments[$singleLead->sno]->first() : null;

      $singleLead->lead_appointment_status = $leadapp->appointment_status ?? "0";
      $singleLead->appointment_lead_id = $leadapp->lead_id ?? "0";
      $singleLead->appointment_status = $lead->status ?? "0";

      // Alert status calculation
      $alert_status = 0;
      if ($chk1day && !$singleLead->followup_latest_id) {
        $alert_status = 1;
      }
      $singleLead->alert_status = $alert_status;

      // Registered date difference
      $registeredDate = Carbon::parse($singleLead->registered_date);
      $diff = $registeredDate->diff(Carbon::now());

      $parts = [];
      if ($diff->y > 0) {
        $parts[] = "{$diff->y} year" . ($diff->y > 1 ? 's' : '');
      }
      if ($diff->m > 0) {
        $parts[] = "{$diff->m} month" . ($diff->m > 1 ? 's' : '');
      }
      if ($diff->d > 0 || empty($parts)) {
        $parts[] = "{$diff->d} day" . ($diff->d > 1 ? 's' : '');
      }

      $singleLead->formattedDifference = implode(' and ', $parts);
      $singleLead->formattedDayDifference = $diff->d;

      // Remove undefined variable issue
      $singleLead->staff_id = "0";
    }

    $reasonList_lead_bank = LeadBankReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->get();

    return view('content.lead_management.manage_lead.daily_calls_list', compact(
      'leads',
      'perpage',
      'lead_fill',
      'reasonList_lead_bank'
    ));
  }
  public function Appointment(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'appointment_date' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      // return $request;
      $lead_id                  = $request->lead_id;
      // $appointment_date         = $request->appointment_date;
      $appointment_time         = $request->appointment_time;

      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);

      $user_id            = $request->user()->user_id;
      $branch_id          = $request->user()->branch_id;


      $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


      if (!$category_check) {

        $year = substr(date("y"), -2);
        $appointment_id = "AP-0001/" . $year;
      } else {

        $data = $category_check->appointment_id;
        $slice = explode("/", $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int)$result + 1;
        $request = sprintf("AP-%04d", $next_number);

        $year = substr(date("y"), -2);
        $appointment_id = $request . '/' . $year;
      }


      $add_category = new AppointmentModel();
      $add_category->appointment_id          = $appointment_id;
      $add_category->lead_id                 = $lead_id;
      $add_category->appointment_date        = $appointment_date;
      $add_category->appointment_time        = $appointment_time;
      $add_category->branch_id               = $branch_id;
      $add_category->status                  = 1;
      $add_category->created_by              = $user_id;
      $add_category->updated_by              = $user_id;

      $add_category->save();
      if ($add_category) {
        $LeadData =  LeadModel::where('sno', $lead_id)->first();
        $LeadData->lead_status_id   = 2; //followup lead
        // $LeadData->drop_verified    = 0;
        // $LeadData->drop_tl_verified = 0;
        // $LeadData->spam_verified    = 0;
        // $LeadData->spam_tl_verified = 0;
        // $LeadData->internal_status  = 0;
        // $LeadData->transfer_status  = 1;
        // $LeadData->potential_verify = 0;
        // $LeadData->is_potential     = 0;
        // $LeadData->is_dc            = 0;
        $LeadData->update();
      }

      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Appointment added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Appointment!'
        ]);
      }
      // }
      // return $result;
      return redirect('/daily_call_lead');
    }
  }
  public function add_appointment_daily_update($id, Request $request)
  {
    $validator = Validator::make($request->all(), [
      'progressed' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $schedule = DB::table('et_schedule_daily_call')->where('sno', $request->schsno)->first();
      // return $schedule;
      $progressed       = $request->progressed;
      $reason_appt      = $request->reason;
      $appointment_time     = $request->appointment_time;
      $app_score            = $request->app_score;
      $pb                   = $request->pb ?? 0;
      $user_id              = $request->user()->user_id;
      $branch_id            = $request->user()->branch_id;
      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
      if ($progressed == 1) {
        $upd_lead =  AppointmentModel::where('lead_id', $schedule->lead_id)->orderBy('sno', 'desc')->first();
        $upd_lead->progressed                 = $progressed;
        $upd_lead->app_score                  = $request->app_score;
        $upd_lead->convo_message              = $request->convo_message;
        $upd_lead->status                     = 4;
        // return $upd_lead;
        $upd_lead->update();

        DB::table('et_schedule_daily_call')
          ->where('sno', $schedule->sno)
          ->update([
            'status'      => 1,
            'updated_at'  => now()
          ]);

        // Update Lead
        $LeadData = LeadModel::where('sno', $schedule->lead_id)->first();
        $LeadData->lead_status_id        = 2;
        $LeadData->drop_verified         = 0;
        $LeadData->drop_tl_verified      = 0;
        $LeadData->spam_verified         = 0;
        $LeadData->spam_tl_verified      = 0;
        $LeadData->internal_status       = 0;
        $LeadData->transfer_status       = 1;
        $LeadData->potential_verify      = 0;
        $LeadData->is_potential          = 0;
        $LeadData->is_dc                 = 0;
        $LeadData->update();

        // Create or Update Daily Call
        $dailyCall = DB::table('za_sales_dailly_call')
          ->where('branch_id', $LeadData->branch_id)
          ->where('status', 1)
          ->where('staff_id', $user_id)
          ->whereDate('dc_date', $LeadData->dc_date)
          ->first();

        if ($dailyCall) {
          // Update existing record
          DB::table('za_sales_dailly_call')
            ->where('sno', $dailyCall->sno)
            ->update([
              'dc_count'    => $dailyCall->dc_count + 1,
              'updated_by'  => $user_id,
              'updated_at'  => now()
            ]);
        } else {
          // Create new record
          DB::table('za_sales_dailly_call')->insert([
            'branch_id'   => $LeadData->branch_id,
            'staff_id'    => $user_id,
            'dc_date'     => $LeadData->dc_date,
            'dc_count'    => 1,
            'status'      => 1,
            'created_by'  => $user_id,
            'updated_by'  => $user_id,
            'created_at'  => now(),
            'updated_at'  => now()
          ]);
        }
        // if ($pb == 1) {
        //   $LeadData = LeadModel::where('sno', $upd_lead->lead_id)->first();
        //   if ($LeadData) {
        //     $LeadData->drop_verified = 0;
        //     $LeadData->drop_tl_verified = 0;
        //     $LeadData->spam_verified = 0;
        //     $LeadData->spam_tl_verified = 0;
        //     $LeadData->internal_status  = 0;
        //     $LeadData->transfer_status  = 1;
        //     $LeadData->potential_verify = 0;
        //     $LeadData->is_dc = 0;
        //     $LeadData->dc_date = null;
        //     $LeadData->is_potential = 0;
        //     // $LeadData->created_by   = $user_id;
        //     $LeadData->save();
        //   }
        //   $add_history = new LeadTransferLogModel();
        //   $add_history->lead_id = $LeadData->sno;
        //   $add_history->branch_id = $LeadData->branch_id;
        //   $add_history->start_date = date('Y-m-d', strtotime($LeadData->created_at));
        //   $add_history->current_staff_id = $LeadData->created_by;
        //   $add_history->change_staff_id = 0;
        //   $add_history->transferred_from = 17; // from Bulk transfer  
        //   $add_history->created_by = $user_id;
        //   $add_history->updated_by = $user_id;
        //   // return $add_history;
        //   $add_history->save();
        // }
        // ****************** */ Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        // $helper = new \App\Helpers\Helpers();
        // $pointsData = $helper->get_points_by_id(4);
        // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // Save new points for the staff
        // $newPoints = new StaffpointsModel();
        // $newPoints->branch_id = $branch_id;
        // $newPoints->staff_id = $user_id;
        // $newPoints->points_by = $id;
        // $newPoints->points_id = 4;
        // $newPoints->points = $point;
        // $newPoints->reason = $reason;
        // $newPoints->save();

        // Update staff's available points
        // $staff_points = StaffModel::where('sno', $user_id)->first();
        // if ($staff_points) {
        //   $staff_points->avaiable_points += $point; // Increment the available points
        //   $staff_points->save();
        // }
        // ****************** */ Update Staff Sales Person Points
      } else {

        $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        if (!$category_check) {

          $year = substr(date("y"), -2);
          $appointment_id = "AP-0001/" . $year;
        } else {

          $data = $category_check->appointment_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("AP-%04d", $next_number);

          $year = substr(date("y"), -2);
          $appointment_id = $request . '/' . $year;
        }

        $upd_app = AppointmentModel::where('lead_id', $id)
          ->where('status', 1)
          ->where(function ($query) {
            $query->where('progressed', 0)
              ->orWhere('progressed', 2);
          })
          ->orderBy('sno', 'desc')
          ->first();

        if ($upd_app) {
          $upd_app->status = 5;
          $upd_app->update();
        }

        $upd_lead = new AppointmentModel();
        $upd_lead->appointment_id           = $appointment_id;
        $upd_lead->lead_id                  = $id;
        $upd_lead->branch_id                = $branch_id;
        $upd_lead->progressed               = $progressed;
        $upd_lead->app_score                = $app_score;
        $upd_lead->reason                   = $reason_appt;
        $upd_lead->appointment_date         = $appointment_date;
        $upd_lead->appointment_time         = $appointment_time;
        $upd_lead->status                   = 1;
        $upd_lead->created_by               = $user_id;
        $upd_lead->updated_by               = $user_id;
        //  return $upd_lead;
        $upd_lead->save();

        DB::table('et_schedule_daily_call')
          ->where('sno', $schedule->sno)
          ->update([
            'status'      => 2,
            'updated_at'  => now()
          ]);

        // Update Lead
        $LeadData = LeadModel::where('sno', $schedule->lead_id)->first();
        $LeadData->lead_status_id        = 2;
        $LeadData->drop_verified         = 0;
        $LeadData->drop_tl_verified      = 0;
        $LeadData->spam_verified         = 0;
        $LeadData->spam_tl_verified      = 0;
        $LeadData->internal_status       = 0;
        $LeadData->transfer_status       = 1;
        $LeadData->potential_verify      = 0;
        $LeadData->is_potential          = 0;
        $LeadData->is_dc                 = 0;
        $LeadData->update();

        // Create or Update Daily Call
        $dailyCall = DB::table('za_sales_dailly_call')
          ->where('branch_id', $LeadData->branch_id)
          ->where('status', 1)
          ->where('staff_id', $user_id)
          ->whereDate('dc_date', $LeadData->dc_date)
          ->first();

        if ($dailyCall) {
          // Update existing record
          DB::table('za_sales_dailly_call')
            ->where('sno', $dailyCall->sno)
            ->update([
              'dc_count'    => $dailyCall->dc_count + 1,
              'updated_by'  => $user_id,
              'updated_at'  => now()
            ]);
        } else {
          // Create new record
          DB::table('za_sales_dailly_call')->insert([
            'branch_id'   => $LeadData->branch_id,
            'staff_id'    => $user_id,
            'dc_date'     => $LeadData->dc_date,
            'dc_count'    => 1,
            'status'      => 1,
            'created_by'  => $user_id,
            'updated_by'  => $user_id,
            'created_at'  => now(),
            'updated_at'  => now()
          ]);
        }

        // $upd_app =  AppointmentModel::where('lead_id', $id)->whereIN('progressed', [null,2])->where('status', 1)->orderBy('sno', 'desc')->first();
        // if($upd_app){
        //     $upd_app->status = 5;
        //     $upd_app->update();
        // // }

        //****************** */ Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        // $helper = new \App\Helpers\Helpers();
        // $pointsData = $helper->get_points_by_id(3);
        // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // // Save new points for the staff
        // $newPoints = new StaffpointsModel();
        // $newPoints->branch_id = $branch_id;
        // $newPoints->staff_id = $user_id;
        // $newPoints->points_by = $id;
        // $newPoints->points_id = 3;
        // $newPoints->points = $point;
        // $newPoints->reason = $reason;
        // $newPoints->save();

        // // Update staff's available points
        // $staff_points = StaffModel::where('sno', $user_id)->first();
        // if ($staff_points) {
        //   $staff_points->avaiable_points += $point; // Increment the available points
        //   $staff_points->save();
        // }
        //****************** */ Update Staff Sales Person Points
      }
      if ($upd_lead) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }
  }
}
