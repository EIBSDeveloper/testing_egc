<?php

namespace App\Http\Controllers\lead_management;

use App\Http\Controllers\Controller;
use App\Models\AppointmentModel;
use App\Models\BranchModel;
use App\Models\ProductModel;
use App\Models\LeadModel;
use App\Models\PostLeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\RawLeadModel;
use App\Models\StaffModel;
use App\Models\LeadAppointmentModel;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\AppointmentCategoryModel;
use App\Models\LeadTransferLogModel;
use App\Models\PreProposalModel;
use App\Models\ProposalModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;

class ManagePostSaleLead extends Controller
{
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $entity_id = $request->user()->entity_id;
    $startTime = microtime(true);
    $gender_fill         = $request->gender_fill ?? '';
    $lead_type_fill      = $request->lead_type_fill ?? '';
    $lead_source_fill    = $request->lead_source_fill ?? '';
    $potential_type_fill = $request->potential_type_fill ?? '';
    $lead_status_fill    = $request->lead_status_fill ?? '';
    $staff_fill          = $request->staff_fill ?? '';
    $date_filter         = $request->dt_fill_issue_rpt;
    $from_date_filter    = $request->from_date_fillter_textbox;
    $to_date_filter      = $request->to_date_fillter_textbox;
    $lead_fill           = $request->lead_fill ?? '';
    $filter_on           = $request->filter_on ?? '';
    $fin_yr_fill         = $request->fin_yr_fill ?? '';
    $product_fill        = $request->product_fill ?? '';
    $pending_followUp_fill = $request->pending_followUp_fill ?? '';
    $tranfer_order       = $request->tranfer_order ?? '';
    $month_lead_filt     = $request->month_lead_filt ?? '';

    // Calculate follow-up counts first (optimized)
    $not_follow_up_ids = [];
    $follwup_count = 0;

    // Only calculate if needed for pending_followUp_fill
    if ($pending_followUp_fill == 1) {
      $followUpQuery = DB::table('et_post_lead')
        ->select('et_post_lead.sno', 'et_post_lead.created_at')
        ->leftJoin(
          DB::raw('(SELECT lead_id, COUNT(*) as total_appointments FROM et_appointment GROUP BY lead_id) AS appointment_counts'),
          'et_post_lead.sno',
          '=',
          'appointment_counts.lead_id'
        )
        ->leftJoin(
          DB::raw('(SELECT lead_id FROM et_appointment GROUP BY lead_id) AS latest_appointment'),
          'et_post_lead.sno',
          '=',
          'latest_appointment.lead_id'
        )
        ->where('et_post_lead.branch_id', $branch_id)
        ->where('et_post_lead.created_by', '!=', 0)
        ->where('et_post_lead.entity_id', $entity_id)
        ->where('et_post_lead.status', 0)
        ->where('et_post_lead.internal_status', '!=', 1);

      if ($staff_fill != '') {
        $followUpQuery->where('et_post_lead.created_by', $staff_fill);
      }

      $followUpLeads = $followUpQuery->get();

      foreach ($followUpLeads as $singleLead) {
        $createdAt = Carbon::parse($singleLead->created_at);
        $currentDateTime = Carbon::now();
        $chk1day = $createdAt->diffInHours($currentDateTime) >= 24;

        if ($chk1day && !$singleLead->latest_appointment) {
          $follwup_count++;
          $not_follow_up_ids[] = $singleLead->sno;
        }
      }
    }

    $selectedMonthsText = '';
    if ($fin_yr_fill != '') {
      $helper = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true);

        if (is_array($monthsArray) && !empty($monthsArray)) {
          $months = [
            1 => 'January',
            2 => 'February',
            3 => 'March',
            4 => 'April',
            5 => 'May',
            6 => 'June',
            7 => 'July',
            8 => 'August',
            9 => 'September',
            10 => 'October',
            11 => 'November',
            12 => 'December',
          ];
          $selectedMonths = [];
          foreach ($monthsArray as $month) {
            if (isset($months[$month])) {
              $selectedMonths[] = $months[$month];
            }
          }
          $selectedMonthsText = implode(', ', $selectedMonths);
        }
      }
    }

    // Main query
    $leads = PostLeadModel::select(
      'et_post_lead.sno',
      'et_post_lead.customer_sno',
      'et_post_lead.is_post_sale_lead',
      'et_post_lead.lead_id',
      'et_post_lead.transfer_status',
      'et_post_lead.is_hot_lead',
      'et_post_lead.created_at',
      'et_post_lead.created_by',
      'et_post_lead.inter_calls',
      'et_post_lead.registered_date',
      'et_post_lead.lead_mobile',
      'et_post_lead.dialed_count',
      'et_post_lead.document_send_count',
      'et_post_lead.incoming_count',
      'et_post_lead.outgoing_count',
      'et_post_lead.missed_reject_count',
      'et_post_lead.spam_verified',
      'et_post_lead.drop_verified',
      'et_post_lead.spam_tl_verified',
      'et_post_lead.drop_tl_verified',
      'et_post_lead.service_id',
      'et_post_lead.phone_verify_status',
      'et_post_lead.phone_verify_content',
      'et_post_lead.just_dial_id',
      'et_post_lead.cloud_call_id',
      'et_post_lead.website_id',
      'et_post_lead.call_tracker_id',
      'et_post_lead.lead_email_id',
      'et_post_lead.lead_gender',
      'et_post_lead.lead_dob',
      'et_post_lead.lead_answer',
      'et_post_lead.lead_marital_status',
      'et_lead_status.lead_bg_color',
      'et_staff.staff_name',
      'et_staff.nick_name',
      'et_post_lead.lead_score',
      'et_post_lead.status',
      'et_post_lead.lead_condition',
      'et_post_lead.lead_status_id',
      'et_post_lead.lead_name',
      'et_lead_type.lead_type_name',
      'et_lead_type.sno as lead_type_id',
      'et_lead_source.lead_source_name',
      'et_lead_source.sno as lead_source_id',
      'et_potential_type.potential_type_name as potential_type_name',
      'et_potential_type.potential_type_image',
      'appointment_counts.lead_id as followup_id',
      'latest_appointment.lead_id as latest_lead_id',
      'latest_appointment.appointment_date',
      'latest_appointment.lead_id as followup_latest_id',
      DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
      DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments')
    )
      ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
            SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
            FROM et_appointment
            WHERE (lead_id, appointment_date) IN (
                SELECT lead_id, MAX(appointment_date) AS appointment_date
                FROM et_appointment              
                GROUP BY lead_id
            )) AS latest_appointment'), 'et_post_lead.sno', '=', 'latest_appointment.lead_id')
      ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
            FROM et_appointment
            GROUP BY lead_id) AS appointment_counts'), 'et_post_lead.sno', '=', 'appointment_counts.lead_id')
      ->leftJoin('et_lead_type', 'et_post_lead.lead_type_id', '=', 'et_lead_type.sno')
      ->leftJoin('et_lead_status', 'et_post_lead.lead_status_id', '=', 'et_lead_status.sno')
      ->leftJoin('et_staff', 'et_post_lead.created_by', '=', 'et_staff.sno')
      ->leftJoin('et_lead_source', 'et_post_lead.lead_source_id', '=', 'et_lead_source.sno')
      ->leftJoin('et_potential_type', 'et_post_lead.lead_potential_type_id', '=', 'et_potential_type.sno')
      ->where('et_post_lead.internal_status', '!=', 1)
      ->where('et_post_lead.branch_id', $branch_id)
      ->where('et_post_lead.entity_id', $entity_id)
      ->whereIn('et_post_lead.status', [0, 1, 4, 5, 7, 10]);

    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $leads->whereDate('et_post_lead.registered_date', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate   = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate   = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $leads->whereBetween('et_post_lead.registered_date', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth  = date('Y-m-t');
      $leads->whereBetween('et_post_lead.registered_date', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate   = date('Y-m-d', strtotime($to_date_filter));
        $leads->whereBetween('et_post_lead.registered_date', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $leads->where('et_post_lead.registered_date', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $leads->where('et_post_lead.registered_date', '<=', $toDate);
      }
    }

    // Apply filters
    if ($lead_type_fill != '') {
      $leads->where('et_post_lead.lead_type_id', $lead_type_fill);
    }
    if ($staff_fill != '') {
      $leads->where('et_post_lead.created_by', $staff_fill);
    }
    if ($lead_source_fill != '') {
      $leads->where('et_post_lead.lead_source_id', $lead_source_fill);
    }
    if ($potential_type_fill != '') {
      $leads->where('et_post_lead.lead_potential_type_id', $potential_type_fill);
    }
    if ($lead_status_fill !== '') {
      $leads->where('et_post_lead.status', $lead_status_fill);
    }
    if ($gender_fill != '') {
      $leads->where('et_post_lead.lead_gender', $gender_fill);
    }
    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('et_post_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_post_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_post_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    if (!empty($product_fill)) {
      $leads->where(function ($query) use ($product_fill) {
        foreach ($product_fill as $productId) {
          $query->orWhereJsonContains('et_post_lead.service_id', $productId);
        }
      });
    }
    if ($pending_followUp_fill == 1 && !empty($not_follow_up_ids)) {
      $leads->whereIn('et_post_lead.sno', $not_follow_up_ids);
    }
    if ($month_lead_filt == 1) {
      $leads->whereYear('et_post_lead.registered_date', date('Y'))
        ->whereMonth('et_post_lead.registered_date', date('m'))
        ->where('et_post_lead.spam_verified', 0)
        ->where('et_post_lead.internal_status', 0)
        ->where('et_post_lead.drop_verified', 0);
    }

    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      $leads = $leads->where('et_post_lead.created_by', $user_id)
        ->where('et_post_lead.wallet_status', 0)
        ->where('et_post_lead.drop_verified', 0)
        ->where('et_post_lead.spam_verified', 0);
    } elseif (!auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
      abort(403, 'Unauthorized');
    }

    // Group by and ordering
    $leads = $leads->groupBy(
      'et_post_lead.sno',
      'et_post_lead.customer_sno',
      'et_post_lead.is_post_sale_lead',
      'et_post_lead.lead_id',
      'et_post_lead.transfer_status',
      'et_post_lead.is_hot_lead',
      'et_post_lead.lead_mobile',
      'et_post_lead.created_at',
      'et_post_lead.incoming_count',
      'et_post_lead.dialed_count',
      'et_post_lead.created_by',
      'et_post_lead.outgoing_count',
      'et_post_lead.missed_reject_count',
      'et_post_lead.spam_verified',
      'et_post_lead.drop_verified',
      'et_post_lead.spam_tl_verified',
      'et_post_lead.drop_tl_verified',
      'et_post_lead.document_send_count',
      'et_post_lead.phone_verify_status',
      'et_post_lead.phone_verify_content',
      'et_post_lead.just_dial_id',
      'et_post_lead.cloud_call_id',
      'et_post_lead.website_id',
      'et_post_lead.call_tracker_id',
      'et_post_lead.registered_date',
      'et_post_lead.lead_email_id',
      'et_post_lead.service_id',
      'et_post_lead.lead_gender',
      'et_post_lead.lead_dob',
      'et_post_lead.inter_calls',
      'et_post_lead.lead_answer',
      'et_post_lead.lead_marital_status',
      'et_lead_status.lead_bg_color',
      'et_staff.staff_name',
      'et_staff.nick_name',
      'et_post_lead.lead_score',
      'et_post_lead.status',
      'et_post_lead.lead_condition',
      'et_post_lead.lead_status_id',
      'et_post_lead.lead_name',
      'et_lead_type.lead_type_name',
      'et_lead_type.sno',
      'et_lead_source.lead_source_name',
      'et_lead_source.sno',
      'latest_appointment.appointment_date',
      'latest_appointment.total_app_score',
      'et_potential_type.potential_type_name',
      'et_potential_type.potential_type_image',
      'appointment_counts.lead_id',
      'latest_appointment.lead_id',
      'appointment_counts.total_appointments'
    );

    // if ($tranfer_order == 1) {
    //   $leads->orderByRaw('transfer_status = 1 desc')
    //     ->orderBy('et_post_lead.registered_date', 'desc');
    // } else {
    // $leads->orderBy('et_post_lead.registered_date', 'desc');
    // }

    // Pagination
    $leads = $leads->orderBy('et_post_lead.registered_date', 'desc')->paginate($perpage);

    // Process each lead
    foreach ($leads as $singleLead) {
      // Get proposals
      $proposal_list = DB::table('et_proposal')
        ->where('status', 0)
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->get();

      foreach ($proposal_list as $proposal) {
        $helper = new \App\Helpers\Helpers();
        $encrypted_values = $helper->encrypt_decrypt($proposal->sno, 'encrypt');
        $proposal->encrypt_id = $encrypted_values;
      }
      $singleLead->proposal_list = $proposal_list;

      // Get product data
      if ($singleLead->service_id) {
        $service_ids = json_decode($singleLead->service_id);
        if (is_array($service_ids) && count($service_ids) > 0) {
          $product_data = ProductModel::select('et_product.product_name', 'et_product_category.product_category_name')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->whereIn('et_product.sno', $service_ids)
            ->get();
          $singleLead->productsData = $product_data;
        } else {
          $singleLead->productsData = collect();
        }
      }

      // Get appointment data
      $lead = DB::table('et_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();

      $leadapp = DB::table('et_lead_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();

      $singleLead->staff_id = $lead->staff_id ?? "0"; // Fixed: changed $lead to $lead
      $singleLead->lead_appointment_status = $leadapp->appointment_status ?? "0";
      $singleLead->appointment_lead_id = $leadapp->lead_id ?? "0";
      $singleLead->appointment_status = $lead->status ?? "0";

      // Calculate alert status
      $createdAt = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      $chk1day = $createdAt->diffInHours($currentDateTime) >= 24;

      $alert_status = 0;
      if ($chk1day && !$singleLead->followup_latest_id && !$singleLead->followup_id) {
        $alert_status = 1;
      }
      $singleLead->alert_status = $alert_status;

      // Calculate date difference
      $registeredDate = Carbon::parse($singleLead->registered_date);
      $diff = $registeredDate->diff(Carbon::now());
      $years = $diff->y;
      $months = $diff->m;
      $days = $diff->d;

      $parts = [];
      if ($years > 0) $parts[] = "{$years} year" . ($years > 1 ? 's' : '');
      if ($months > 0) $parts[] = "{$months} month" . ($months > 1 ? 's' : '');
      if ($days > 0 || empty($parts)) $parts[] = "{$days} day" . ($days > 1 ? 's' : '');

      $singleLead->formattedDifference = implode(' and ', $parts);
      $singleLead->formattedDayDifference = $days;

      // Check pending appointments
      $before48Hours = Carbon::now()->subHours(48);
      $usersWithPendingAppointments = DB::table('et_appointment')
        ->join('et_post_lead', 'et_post_lead.sno', '=', 'et_appointment.lead_id')
        ->whereIn('et_post_lead.status', [0])
        ->where('et_post_lead.is_dc', 1)
        ->where('et_appointment.status', 1)
        ->where('et_appointment.branch_id', $branch_id)
        ->where('et_appointment.appointment_date', '<=', $before48Hours)
        ->distinct()
        ->pluck('et_appointment.created_by')
        ->toArray();

      $singleLead->not_closed = in_array($singleLead->created_by, $usersWithPendingAppointments) ? 1 : 0;

      // Check spam approval
      $usersWithPendingSpamApproval = DB::table('et_post_lead')
        ->select('created_by', DB::raw('COUNT(*) as total'))
        ->whereIn('status', [7])
        ->where('spam_verified', 0)
        ->where('branch_id', $branch_id)
        ->groupBy('created_by')
        ->having('total', '>=', 5)
        ->pluck('created_by')
        ->toArray();

      $singleLead->spam_not_closed = in_array($singleLead->created_by, $usersWithPendingSpamApproval) ? 1 : 0;

      // Check dead approval
      $usersWithPendingDeadApproval = DB::table('et_post_lead')
        ->select('created_by', DB::raw('COUNT(*) as total'))
        ->whereIn('status', [5])
        ->where('drop_verified', 0)
        ->where('branch_id', $branch_id)
        ->groupBy('created_by')
        ->having('total', '>=', 5)
        ->pluck('created_by')
        ->toArray();

      $singleLead->dead_not_closed = in_array($singleLead->created_by, $usersWithPendingDeadApproval) ? 1 : 0;
    }

    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    $sumAppScore = $leads->sum('total_app_score');

    $leads->getCollection()->transform(function ($item, $key) use ($sumAppScore) {
      $item->lead_initial = strtoupper(substr($item->lead_name, 0, 1));
      $item->app_score = $sumAppScore;
      return $item;
    });

    // Calculate totals
    $totalLeadCounts = PostLeadModel::whereNotIn('et_post_lead.status', [2, 6])
      ->where('et_post_lead.internal_status', '!=', 1)
      ->where('et_post_lead.spam_verified', 0)
      ->where('et_post_lead.drop_verified', 0);

    if ($branch_id != 0) {
      $totalLeadCounts->where('et_post_lead.branch_id', $branch_id)
        ->where('et_post_lead.entity_id', $entity_id);
    }

    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      $totalLeadCounts->where('et_post_lead.created_by', $user_id);
    }
    $totalLeadCount = $totalLeadCounts->count();

    // Current month lead count
    $currentMonthLeadCounts = PostLeadModel::whereNotIn('et_post_lead.status', [2, 6])
      ->where('et_post_lead.spam_verified', 0)
      ->where('et_post_lead.internal_status', 0)
      ->where('et_post_lead.drop_verified', 0);

    if ($branch_id != 0) {
      $currentMonthLeadCounts->where('et_post_lead.branch_id', $branch_id)
        ->where('et_post_lead.entity_id', $entity_id);
    }
    $currentMonthLeadCounts = $currentMonthLeadCounts
      ->whereYear('registered_date', date('Y'))
      ->whereMonth('registered_date', date('m'));

    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      $currentMonthLeadCounts->where('et_post_lead.created_by', $user_id);
    }
    $currentMonthLeadCount = $currentMonthLeadCounts->count();

    // Customer counts
    $totalCustomerCount = PostLeadModel::where('status', 4)
      ->where('et_post_lead.internal_status', '!=', 1)
      ->where('et_post_lead.registered_date', '!=', 0);

    if ($branch_id != 0) {
      $totalCustomerCount->where('et_post_lead.branch_id', $branch_id)
        ->where('et_post_lead.entity_id', $entity_id);
    }
    $totalCustomerCount = $totalCustomerCount->count();

    $currentMonthCustomerCount = PostLeadModel::where('status', 4)
      ->where('et_post_lead.internal_status', '!=', 1)
      ->where('et_post_lead.registered_date', '!=', 0);

    if ($branch_id != 0) {
      $currentMonthCustomerCount->where('et_post_lead.branch_id', $branch_id)
        ->where('et_post_lead.entity_id', $entity_id);
    }
    $currentMonthCustomerCount = $currentMonthCustomerCount
      ->whereYear('registered_date', date('Y'))
      ->whereMonth('registered_date', date('m'))
      ->count();

    // Calculate percentages
    $percentageover = $totalLeadCount > 0 ? round(($totalCustomerCount / $totalLeadCount) * 100) . '%' : '0%';
    $percentagecurrentmonth = $currentMonthLeadCount > 0 ? round(($currentMonthCustomerCount / $currentMonthLeadCount) * 100) . '%' : '0%';

    // Get filter lists
    $staff_filter_list = StaffModel::where('status', 0);
    if ($branch_id != 0) {
      $staff_filter_list = $staff_filter_list->where('branch_id', $branch_id)
        ->where('entity_id', $entity_id);
    }
    $staff_filter_list = $staff_filter_list->where('department_id', 1)
      ->orderBy('nick_name', 'ASC')
      ->get();

    $login_branch_data = BranchModel::where('status', 0)
      ->where('sno', $branch_id)
      ->first();

    $PotentialType = LeadPotentialModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $Lead_status_list = LeadStatusModel::where('status', 0)
      ->where('legend_status', 0)
      ->orderBy('lead_status_name', 'ASC')
      ->get();

    $leadOriginal = DB::table('et_post_lead')
      ->where('et_post_lead.branch_id', $branch_id)
      ->where('et_post_lead.entity_id', $entity_id)
      ->whereNotIn('et_post_lead.status', [2, 6])
      ->where('et_post_lead.internal_status', '!=', 1)
      ->where('et_post_lead.drop_verified', 0)
      ->where('et_post_lead.spam_verified', 0)
      ->where('et_post_lead.created_by', '!=', 0)
      ->distinct('et_post_lead.sno');

    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      $leadOriginal->where('et_post_lead.created_by', $user_id);
    }
    $leadOriginalCount = $leadOriginal->count();

    $categories = AppointmentCategoryModel::where('status', 0)->get();
    $CourseCategory = LeadSourceModel::where('status', 0)->orderBy('sno', 'desc')->get();


    $pageConfigs = ['myLayout' => 'default'];
    return view('content.lead_management.manage_postsale_lead.postsale_lead', [
      'leads' => $leads,
      'totalLeadCount' => $totalLeadCount,
      'leadOriginalCount' => $leadOriginalCount,
      'perpage' => $perpage,
      'CourseCategory' => $CourseCategory,
      'currentMonthLeadCount' => $currentMonthLeadCount,
      'percentageover' => $percentageover,
      'percentagecurrentmonth' => $percentagecurrentmonth,
      'pageConfigs' => $pageConfigs,
      'lead_type_fill' => $lead_type_fill,
      'lead_source_fill' => $lead_source_fill,
      'gender_fill' => $gender_fill,
      'lead_fill' => $lead_fill,
      'product_fill' => $product_fill,
      'categories' => $categories,
      'tranfer_order' => $tranfer_order,
      'filter_on' => $filter_on,
      'potential_type_fill' => $potential_type_fill,
      'PotentialType' => $PotentialType,
      'date_filter' => $date_filter,
      'lead_status_fill' => $lead_status_fill,
      'staff_filter_list' => $staff_filter_list,
      'staff_fill' => $staff_fill,
      'login_branch_data' => $login_branch_data,
      'Lead_status_list' => $Lead_status_list,
      'fin_yr_fill' => $fin_yr_fill
    ]);
  }

  public function Lead_view($id)
  {
    $data =  PostLeadModel::where('et_post_lead.status', '!=', 2)
      ->select(
        'et_post_lead.*',
        'et_countries.name',
        'et_states.name as statename',
        'et_cities.name as citiesname',
        'et_potential_type.potential_type_name as potential_type_name',
        'et_potential_type.potential_type_image',
        'et_lead_type.lead_type_name as leadtypename',
        'et_lead_source.lead_source_name as leadsourcename',
        'et_university.university_name as universityname',
        'et_product_category.product_category_name',
        'et_product.product_name'
      )
      ->leftJoin('et_countries', 'et_post_lead.country', 'et_countries.id')
      ->leftJoin('et_states', 'et_post_lead.state', 'et_states.id')
      ->leftJoin('et_cities', 'et_post_lead.city', 'et_cities.id')
      ->leftJoin('et_lead_type', 'et_post_lead.lead_type_id', 'et_lead_type.sno')
      ->leftJoin('et_lead_source', 'et_post_lead.lead_source_id', 'et_lead_source.sno')
      ->leftJoin('et_university', 'et_post_lead.university_id', 'et_university.sno')
      ->leftJoin('et_potential_type', 'et_post_lead.lead_potential_type_id', '=', 'et_potential_type.sno')
      ->leftJoin('et_product_category', 'et_post_lead.service_category_id', '=', 'et_product_category.sno')
      ->leftJoin('et_product', 'et_post_lead.service_id', '=', 'et_product.sno')
      ->orderBy('et_post_lead.sno', 'desc')->where('et_post_lead.sno', $id)->first();

    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Company not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Company fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }

  public function View($id)
  {
    // Fetch the lead data with necessary joins and fields
    $lead = PostLeadModel::select(
      'et_post_lead.*',
      'et_lead_type.lead_type_name',
      'et_lead_type.sno as lead_type_id',
      'et_lead_source.lead_source_name',
      'et_lead_source.sno as lead_source_id',
      'et_potential_type.potential_type_name',
      'et_states.name AS state_name',
      'et_cities.name AS city_name',
      'et_countries.name AS country_name'
    )
      ->leftJoin('et_course', 'et_post_lead.course_id', '=', 'et_course.sno')
      ->leftJoin('et_potential_type', 'et_post_lead.lead_potential_type_id', '=', 'et_potential_type.sno')
      ->leftJoin('et_lead_type', 'et_post_lead.lead_type_id', '=', 'et_lead_type.sno')
      ->leftJoin('et_lead_source', 'et_post_lead.lead_source_id', '=', 'et_lead_source.sno')
      ->leftJoin('et_countries', 'et_post_lead.country', '=', 'et_countries.id')
      ->leftJoin('et_states', 'et_post_lead.state', '=', 'et_states.id')
      ->leftJoin('et_cities', 'et_post_lead.city', '=', 'et_cities.id')
      ->where('et_post_lead.sno', $id)
      ->orderBy('et_post_lead.sno', 'desc')
      ->first();

    // Check if lead exists before proceeding
    if (!$lead) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found',
        'error_msg' => 'No lead data found for the given ID',
        'data'      => null,
      ], 404);
    }

    // Decode course_id if it's JSON and fetch course names
    if (!empty($lead->course_id)) {
      $courseIds = json_decode($lead->course_id, true); // Ensure we decode to an array

      if (is_array($courseIds)) {
        // Fetch course names based on IDs
        $courses = DB::table('et_course')
          ->whereIn('sno', $courseIds)
          ->pluck('course_name');

        $lead->course_names = $courses;
      } else {
        $lead->course_names = [];
      }
    }

    // return $lead;
    // Helper to format date
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

    // Format lead_dob if it exists, else use current date
    $lead->lead_dob = !empty($lead->lead_dob) ? date($common_date_format, strtotime($lead->lead_dob)) : date($common_date_format); // Fallback to current date if lead_dob is null or empty

    // Return response with the lead data
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead,
    ], 200);
  }

  // Hot lead status change
  public function HotLeadStatus($id, Request $request)
  {
    $lead = PostLeadModel::where('sno', $id)->first();
    $lead->lead_status_id = $request->status;
    if ($request->status == 3) {
      $lead->is_hot_lead = 1;
      $lead->last_hot_lead_date = date('Y-m-d');
    }
    $lead->update();
    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
  // Post Lead Import
  public function LeadImport(Request $requestData)
  {
    $validator = Validator::make($requestData->all(), [
      'file_import' => 'required|file|mimes:xls,xlsx|max:5120',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->all(),
        'data' => null,
      ], 400);
    }
    // return $requestData->user()->branch_id;

    $file_import = $requestData->file('file_import');
    $lead_source_id = $requestData->input('lead_source_id');
    $lead_group = $requestData->input('lead_group');

    // Check if the lead group already exists
    // $chk = RawLeadModel::where('lead_group', $lead_group)->where('status', '!=', 2)->first();
    // if ($chk) {
    //   return response()->json([
    //     'status' => 'error',
    //     'message' => 'Group name already exists!',
    //     'error_msg' => ['Group name already exists!'],
    //   ], 207);
    // }

    $data = Excel::toCollection(new PostLeadModel, $file_import);

    if ($data->isEmpty() || $data[0]->isEmpty()) {
      return response()->json([
        'status' => 401,
        'message' => 'The uploaded file is empty.',
        'error_msg' => ['The uploaded file is empty.'],
        'data' => null,
      ], 400);
    }

    $errors = [];
    $successfulImports = 0;
    $branch_data = BranchModel::where('sno', $requestData->user()->branch_id)->first();
    $branch_name = " ";
    if ($branch_data->branch_type == 1) {
      $branch_name = $branch_data->branch_name;
    } elseif ($branch_data->branch_type == 2) {
      $branch_name = $branch_data->franchise_name;
    }


    foreach ($data[0] as $key => $row) {
      if ($key > 0) {  // Skip the header row

        $lead_name = $row[0];
        $lead_mobile = $row[1];
        $lead_mail = $row[2];
        $lead_date = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row[3])->format('Y-m-d');
        // || empty($lead_mobile)
        if (empty($lead_name)  || empty($lead_date)) {
          $errors[] = 'Missing required field in row ' . ($key + 1);
          continue;
        }
        // if (is_numeric($lead_date)) {
        //   $lead_date = Date::excelToDateTimeObject($lead_date)->format('Y-m-d');
        // }

        if (isset($lead_date) && strtotime($lead_date)) {
          // Check if it's a valid date string before formatting
          $lead_date = date('Y-m-d', strtotime($lead_date));
        } else {
          // Default to today's date
          $lead_date = date('Y-m-d');
        }
        if (!$lead_date) {
          // Default to today's date
          $lead_date = date('Y-m-d');
        }

        // $lead_mobile = str_replace(' ', '', $lead_mobile);
        // Convert encoding to remove hidden characters
        $lead_mobile = mb_convert_encoding($lead_mobile, 'UTF-8', 'UTF-8');

        // Remove all non-numeric characters (including hidden spaces and special chars)
        $lead_mobile = preg_replace('/\D/', '', $lead_mobile);

        // Check for existing mobile number
        $chk = PostLeadModel::where('lead_mobile', $lead_mobile)->first();
        if ($chk) {
          $errors[] = 'Row ' . ($key + 1) . ': Mobile number ' . $lead_mobile . ' already exists! <br>';
          continue;
        }

        // Generate new lead ID
        $branch_check = BranchModel::where('sno', $requestData->user()->branch_id)->first();
        $branch_code = $branch_check->city_short_code;

        $category_check = PostLeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $year = date("Y");
        if (!$category_check) {
          $lead_id = $year . '/' . $branch_code . '/' . "PSL0001";
        } else {
          $data = $category_check->lead_id;
          $slice = explode("/", $data);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $lead_id = $year . '/' . $branch_code . '/' . sprintf("PSL%04d", $next_number);
        }

        $user_id = $requestData->user()->user_id;
        $branch_id = $requestData->user()->branch_id;
        $entity_id = $requestData->user()->entity_id ?? 1;

        // Create new lead
        $new_lead = new PostLeadModel();
        $new_lead->lead_id = $lead_id;
        $new_lead->is_post_sale_lead = 1;
        $new_lead->lead_name = $lead_name;
        $new_lead->lead_mobile = $lead_mobile;
        $new_lead->lead_email_id = $lead_mail;
        $new_lead->lead_source_id = $lead_source_id;
        $new_lead->lead_group = $lead_group;
        $new_lead->registered_date = $lead_date;
        $new_lead->status = 0;
        $new_lead->branch_id = $branch_id;
        $new_lead->entity_id = $entity_id;
        $new_lead->created_by = $user_id;
        $new_lead->updated_by = $user_id;

        // return $new_lead;

        if ($new_lead->save()) {
          $successfulImports++;
        } else {
          $errors[] = 'Row ' . ($key + 1) . ': Could not import the lead ' . $lead_name . '!<br>';
        }
      }
    }

    $responseMessage = $successfulImports . ' lead(s) imported successfully.';

    if (!empty($errors)) {
      return response()->json([
        'status' => 'partial_success',
        'message' => $responseMessage,
        'error_msg' => $errors,
      ], 207);
    }

    return response()->json([
      'status' => 'success',
      'message' => $responseMessage,
      'data' => null,
    ], 200);
  }

  public function Appointment(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'appointment_date' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      // return $request;
      $lead_id                  = $request->lead_id;
      // $appointment_date         = $request->appointment_date;
      $appointment_time         = $request->appointment_time;

      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);

      $user_id            = $request->user()->user_id;
      $branch_id          = $request->user()->branch_id;
      // $chk = LeadModel::where('lead_id', $lead_id)->where('status', '!=', 2)->first();

      // if ($chk) {
      //   session()->flash('toastr', [
      //     'type' => 'error',
      //     'message' => 'Name has been  already created!'
      //   ]);
      // } else {
      // return $request;

      $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


      if (!$category_check) {

        $year = substr(date("y"), -2);
        $appointment_id = "AP-0001/" . $year;
      } else {

        $data = $category_check->appointment_id;
        $slice = explode("/", $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int)$result + 1;
        $request = sprintf("AP-%04d", $next_number);

        $year = substr(date("y"), -2);
        $appointment_id = $request . '/' . $year;
      }


      $add_category = new AppointmentModel();
      $add_category->appointment_id          = $appointment_id;
      $add_category->lead_id                 = $lead_id;
      $add_category->appointment_date        = $appointment_date;
      $add_category->appointment_time        = $appointment_time;
      $add_category->branch_id               = $branch_id;
      $add_category->status                  = 1;
      $add_category->created_by              = $user_id;
      $add_category->updated_by              = $user_id;


      $add_category->save();
      if ($add_category) {
        $lead =  PostLeadModel::where('sno', $lead_id)->first();
        $lead->lead_status_id          = 2; //followup lead
        $lead->update();

        // Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        // $helper = new \App\Helpers\Helpers();
        // $pointsData = $helper->get_points_by_id(3);
        // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // // Save new points for the staff
        // $newPoints = new StaffpointsModel();
        // $newPoints->branch_id = $branch_id;
        // $newPoints->staff_id = $user_id;
        // $newPoints->points_by = $lead_id;
        // $newPoints->points_id = 3;
        // $newPoints->points = $point;
        // $newPoints->reason = $reason;
        // $newPoints->save();

        // // Update staff's available points
        // $staff_points = StaffModel::where('sno', $user_id)->first();
        // if ($staff_points) {
        //   $staff_points->avaiable_points += $point; // Increment the available points
        //   $staff_points->save();
        // }
      }

      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Appointment added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Appointment!'
        ]);
      }
      // }
      // return $result;
      return redirect('manage_lead');
    }
  }

  public function AppointmentEdit($id)
  {
    // Fetch the latest appointment details for a specific lead_id
    $latestAppointment = AppointmentModel::select('et_appointment.*', 'et_post_lead.lead_name', 'et_post_lead.sno as lead_id')
      ->join('et_post_lead', 'et_appointment.lead_id', '=', 'et_post_lead.sno')
      ->whereNotIn('et_appointment.status', [2])
      ->where('et_appointment.lead_id', $id)
      ->orderBy('et_appointment.sno', 'desc')
      ->first();

    $appointmentCount = AppointmentModel::where('lead_id', $id)
      ->whereNotIn('status', [2])
      ->count();

    // Fetch historical lead_id values excluding the current $id
    // $historicalLeadIds = AppointmentModel::select('et_appointment.*')
    //   ->where('lead_id', $id)
    //     ->whereNotIn('status', [2])
    //   ->orderBy('et_appointment.sno', 'desc')
    //   ->get();

    $historicalLeadIds = AppointmentModel::select('et_appointment.*', 'et_staff.staff_name')
      ->join('et_staff', 'et_appointment.created_by', '=', 'et_staff.sno')
      ->where('et_appointment.lead_id', $id)
      ->where('et_appointment.status', '!=', 2)
      ->orderBy('et_appointment.sno', 'desc')
      ->get();

    // Extract appointment_date and appointment_time from the latest appointment
    $appointment_date = null;
    $appointment_time = null;
    if ($latestAppointment) {
      $appointment_date = $latestAppointment->appointment_date;
      $appointment_time = $latestAppointment->appointment_time;
    }

    // Include previous appointment date and time in historicalLeadIds
    $historicalLeadIds = $historicalLeadIds->map(function ($appointment, $key) use ($id) {
      // Fetch the previous appointment by skipping the current one
      $previousAppointment = AppointmentModel::select('et_appointment.*')
        ->where('lead_id', $id)
        ->whereNotIn('status', [2])
        ->where('sno', '<', $appointment->sno)
        ->orderBy('sno', 'desc')
        ->first();

      $appointment->previous_appointment_date = $previousAppointment ? $previousAppointment->appointment_date : null;
      $appointment->previous_appointment_time = $previousAppointment ? $previousAppointment->appointment_time : null;

      return $appointment;
    });

    $lead_reschedule_count  = DB::table('et_appointment')
      ->where('lead_id', $id)
      ->where('status', 5)
      ->count();

    return response()->json([
      'status'    => 200,
      'message'   => 'Appointment details fetched successfully',
      'data'      => [
        'appointment_date' => $appointment_date,
        'appointment_time' => $appointment_time,
        'appointmentCount' => $appointmentCount,
        'latestAppointment' => $latestAppointment,
        'historicalLeadIds' => $historicalLeadIds,
        'lead_reschedule_count' => $lead_reschedule_count,
      ]
    ], 200);
  }

  public function AppointmentUpdate($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'progressed' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      //   return $request;
      $progressed       = $request->progressed;
      $reason_appt      = $request->reason;
      $appointment_time       = $request->appointment_time;
      $app_score          = $request->app_score;
      $follow_through            = $request->follow_through ?? 0;

      $hot_lead            = $request->hot_lead;
      $pb            = $request->pb ?? 0;
      $user_id            = $request->user()->user_id;
      $branch_id            = $request->user()->branch_id;
      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
      if ($progressed == 1) {
        $upd_lead =  AppointmentModel::where('lead_id', $id)->orderBy('sno', 'desc')->first();

        $upd_lead->progressed                 = $progressed;
        $upd_lead->app_score                  = $request->app_score;
        $upd_lead->follow_through                  = $request->follow_through;

        $upd_lead->convo_message              = $request->convo_message;
        $upd_lead->status                     = 4;
        // return $upd_lead;
        $upd_lead->update();

        if ($pb == 1) {
          $LeadData = LeadModel::where('sno', $upd_lead->lead_id)->first();
          if ($LeadData) {
            // $LeadData->drop_verified = 0;
            // $LeadData->drop_tl_verified = 0;
            // $LeadData->spam_verified = 0;
            // $LeadData->spam_tl_verified = 0;
            // $LeadData->internal_status  = 0;
            // $LeadData->transfer_status  = 1;
            // $LeadData->potential_verify = 0;
            // $LeadData->is_potential = 0;
            // $LeadData->created_by   = $user_id;
            // $LeadData->save();
          }
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $LeadData->sno;
          $add_history->branch_id = $LeadData->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($LeadData->created_at));
          $add_history->current_staff_id = $LeadData->created_by;
          $add_history->change_staff_id = 0;
          $add_history->transferred_from = 17; // from Bulk transfer  
          $add_history->created_by = $user_id;
          $add_history->updated_by = $user_id;
          // return $add_history;
          $add_history->save();
        }
        //****************** */ Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        // $helper = new \App\Helpers\Helpers();
        // $pointsData = $helper->get_points_by_id(4);
        // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // // Save new points for the staff
        // $newPoints = new StaffpointsModel();
        // $newPoints->branch_id = $branch_id;
        // $newPoints->staff_id = $user_id;
        // $newPoints->points_by = $id;
        // $newPoints->points_id = 4;
        // $newPoints->points = $point;
        // $newPoints->reason = $reason;
        // $newPoints->save();

        // // Update staff's available points
        // $staff_points = StaffModel::where('sno', $user_id)->first();
        // if ($staff_points) {
        //   $staff_points->avaiable_points += $point; // Increment the available points
        //   $staff_points->save();
        // }
        //****************** */ Update Staff Sales Person Points
        // if ($hot_lead == 1) {
        //   $lead =  PostLeadModel::where('sno', $id)->first();
        //   $lead->lead_status_id          = 3; //Hot lead
        //   $lead->update();
        // }
      } else {
        $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        if (!$category_check) {

          $year = substr(date("y"), -2);
          $appointment_id = "AP-0001/" . $year;
        } else {

          $data = $category_check->appointment_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("AP-%04d", $next_number);

          $year = substr(date("y"), -2);
          $appointment_id = $request . '/' . $year;
        }

        $upd_app = AppointmentModel::where('lead_id', $id)
          ->where('status', 1)
          ->where(function ($query) {
            $query->where('progressed', 0)
              ->orWhere('progressed', 2);
          })
          ->orderBy('sno', 'desc')
          ->first();

        if ($upd_app) {
          $upd_app->status = 5;
          $upd_app->update();
        }



        $upd_lead = new AppointmentModel();
        $upd_lead->appointment_id           = $appointment_id;
        $upd_lead->lead_id                  = $id;
        $upd_lead->branch_id                = $branch_id;
        $upd_lead->progressed               = $progressed;
        $upd_lead->app_score                = $app_score;
        $upd_lead->follow_through                = $follow_through;
        $upd_lead->reason                   = $reason_appt;
        $upd_lead->appointment_date         = $appointment_date;
        $upd_lead->appointment_time         = $appointment_time;
        $upd_lead->status                   = 1;
        $upd_lead->created_by               = $user_id;
        $upd_lead->updated_by               = $user_id;
        //  return $upd_lead;
        $upd_lead->save();



        // $upd_app =  AppointmentModel::where('lead_id', $id)->whereIN('progressed', [null,2])->where('status', 1)->orderBy('sno', 'desc')->first();
        // if($upd_app){
        //     $upd_app->status = 5;
        //     $upd_app->update();
        // // }

        //****************** */ Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        // $helper = new \App\Helpers\Helpers();
        // $pointsData = $helper->get_points_by_id(3);
        // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // // Save new points for the staff
        // $newPoints = new StaffpointsModel();
        // $newPoints->branch_id = $branch_id;
        // $newPoints->staff_id = $user_id;
        // $newPoints->points_by = $id;
        // $newPoints->points_id = 3;
        // $newPoints->points = $point;
        // $newPoints->reason = $reason;
        // $newPoints->save();

        // // Update staff's available points
        // $staff_points = StaffModel::where('sno', $user_id)->first();
        // if ($staff_points) {
        //   $staff_points->avaiable_points += $point; // Increment the available points
        //   $staff_points->save();
        // }
        //****************** */ Update Staff Sales Person Points

        // if ($hot_lead == 1) {
        //   $lead =  PostLeadModel::where('sno', $id)->first();
        //   $lead->lead_status_id          = 3; //Hot lead
        //   $lead->update();
        // }
      }
      //   if ($upd_lead) {
      //         // Embed the lead_name directly in notification content
      //         $notificationData = [
      //             'branch_id' => $branch_id,
      //             'notification_content' => '
      //                 <div class="d-flex align-items-center">
      //                     <div class="me-3">
      //                         <span class="badge bg-gray-300">
      //                             <i class="mdi mdi-account-multiple-outline fs-3 text-black"></i>
      //                         </span>
      //                     </div>
      //                     <div class="me-2">
      //                         <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
      //                         <div class="text-secondary fs-8 fw-semibold">' . $upd_lead->lead_name . ' - Checklist Not Completed</div>
      //                     </div>
      //                 </div>',
      //             'who' => $user_id,
      //             'created_by' => $user_id,
      //             'updated_by' => $user_id,
      //             'status' => 0
      //         ];
      //         $notificationtype = 'CheckList';
      //         $newNotification = new \App\Helpers\Helpers();

      //         $newNotification->createNotification($notificationData, $notificationtype);
      //     }
      if ($upd_lead) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }
  }

  public function AppointmentList($id)
  {
    $lead = AppointmentModel::select('et_appointment.*', 'et_post_lead.lead_name', 'et_post_lead.sno as lead_id')
      ->join('et_post_lead', 'et_appointment.lead_id', '=', 'et_post_lead.sno')
      ->where('et_appointment.status', '!=', 2)
      ->where('et_appointment.lead_id', $id)
      ->orderBy('et_appointment.sno', 'desc')
      ->first();

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead
    ], 200);
  }

  public function AppointmentHistory($id)
  {
    // Fetch the latest appointment details for a specific lead_id
    $latestAppointment = LeadAppointmentModel::select('et_lead_appointment.*', 'et_post_lead.lead_name', 'et_post_lead.sno as lead_id')
      ->join('et_post_lead', 'et_lead_appointment.lead_id', '=', 'et_post_lead.sno')
      ->where('et_lead_appointment.status', '!=', 2)
      ->where('et_lead_appointment.lead_id', $id)
      ->orderBy('et_lead_appointment.sno', 'desc')
      ->first();

    $appointmentCount = LeadAppointmentModel::where('lead_id', $id)
      ->where('status', '!=', 2)
      ->count();


    // Fetch historical lead_id values excluding the current $id
    $historicalLeadIds = LeadAppointmentModel::select('et_lead_appointment.*')
      ->where('lead_id', $id)
      ->where('status', '!=', 2)
      ->orderBy('et_lead_appointment.sno', 'desc')
      ->get();

    // Extract appointment_date and appointment_time from the latest appointment
    $appointment_date = null;
    $appointment_time = null;
    if ($latestAppointment) {
      $appointment_date = $latestAppointment->appointment_date ? date('Y-m-d', strtotime($latestAppointment->appointment_date)) : null;
      $appointment_time = $latestAppointment->appointment_date ? date('H:i:s', strtotime($latestAppointment->appointment_date)) : null;
    }

    // Include previous appointment date and time in historicalLeadIds
    $historicalLeadIds = $historicalLeadIds->map(function ($appointment, $key) use ($id) {
      // Fetch the previous appointment by skipping the current one
      $previousAppointment = LeadAppointmentModel::select('et_lead_appointment.*')
        ->where('lead_id', $id)
        ->where('status', '!=', 2)
        ->orderBy('sno', 'desc')
        ->first();

      $appointment->previous_appointment_date =  $previousAppointment ? date('Y-m-d', strtotime($previousAppointment->appointment_date)) : null;
      $appointment->previous_appointment_time =  $previousAppointment ? date('H:i:s', strtotime($previousAppointment->appointment_date)) : null;

      return $appointment;
    });

    return response()->json([
      'status'    => 200,
      'message'   => 'Appointment details fetched successfully',
      'data'      => [
        'appointment_date' => $appointment_date,
        'appointment_time' => $appointment_time,
        'appointmentCount' => $appointmentCount,
        'latestAppointment' => $latestAppointment,
        'historicalLeadIds' => $historicalLeadIds
      ]
    ], 200);
  }

  public function manage_calls(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;

    // Filters
    $department_fill  = $request->input('department_fill', '');
    $staff_fill       = $request->input('staff_fill', '');
    $date_filter      = $request->input('dt_fill_issue_rpt');
    $from_date_filter = $request->input('from_date_fillter_textbox');
    $to_date_filter   = $request->input('to_date_fillter_textbox');
    $fin_yr_fill      = $request->input('fin_yr_fill', '');

    $calls = DB::table('et_contact_book')
      ->select('et_contact_book.staff_id', 'et_staff.staff_name', 'et_staff.staff_image', 'et_staff.gender', 'et_staff.mobile_no', 'et_department.department_name')
      ->join('et_staff', 'et_staff.sno', '=', 'et_contact_book.staff_id')
      ->leftJoin('et_department', 'et_department.sno', '=', 'et_staff.department_id')
      ->distinct('et_contact_book.staff_id')
      ->where('et_staff.status', 0);

    $staff_list = $calls->get();

    // Date Filtering
    if ($date_filter === "today") {
      $calls->whereDate('et_contact_book.created_at', now()->toDateString());
    } elseif ($date_filter === "week") {
      $calls->whereBetween('et_contact_book.created_at', [now()->startOfWeek(), now()->endOfWeek()]);
    } elseif ($date_filter === "monthly") {
      $calls->whereMonth('et_contact_book.created_at', now()->month)
        ->whereYear('et_contact_book.created_at', now()->year);
    } elseif ($date_filter === "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $calls->whereBetween('et_contact_book.created_at', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]);
      } elseif ($from_date_filter) {
        $calls->where('et_contact_book.created_at', '>=', Carbon::parse($from_date_filter));
      } elseif ($to_date_filter) {
        $calls->where('et_contact_book.created_at', '<=', Carbon::parse($to_date_filter));
      }
    }

    // Financial Year Filter
    if ($fin_yr_fill) {
      $helper            = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true);
        if (is_array($monthsArray)) {
          $calls->where(function ($query) use ($monthsArray) {
            foreach ($monthsArray as $month) {
              $query->orWhereMonth('et_contact_book.created_at', $month)
                ->whereYear('et_contact_book.created_at', now()->year);
            }
          });
        }
      }
    }

    // Other Filters
    if ($department_fill) {
      $calls->where('et_staff.department_id', $department_fill);
    }

    if ($staff_fill) {
      $calls->where('et_contact_book.staff_id', $staff_fill);
    }

    $calls = $calls->orderBy('et_contact_book.contact_book_id', 'desc')->paginate($perpage);

    $department_list = DB::table('et_department')->where('status', 0)->get();

    // return $calls;
    return view('content.sales.manage_calls.call_list', [
      'calls'            => $calls,
      'perpage'          => $perpage,
      'department_list'  => $department_list,
      'staff_list'       => $staff_list,
      'date_filter'      => $date_filter,
      'department_fill'  => $department_fill,
      'staff_fill'       => $staff_fill,
      'fin_yr_fill'      => $fin_yr_fill,
      'from_date_filter' => $from_date_filter,
      'to_date_filter'   => $to_date_filter,
    ]);
  }

  public function call_history($id, Request $request)
  {
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $branch_id = $request->user()->branch_id;

    $helper          = new \App\Helpers\Helpers();
    $decryptedValue  = $helper->encrypt_decrypt($id, 'decrypt');
    $staff_id        = $decryptedValue;
    $call_start_date = date('Y-m-01'); // Start date (first day of the month)
    $call_end_date   = date('Y-m-t');

    // Filters
    $status_fill      = $request->input('status_fill', '');
    $date_filter      = $request->input('dt_fill_issue_rpt');
    $from_date_filter = $request->input('from_date_fillter_textbox');
    $to_date_filter   = $request->input('to_date_fillter_textbox');
    $fin_yr_fill      = $request->input('fin_yr_fill', '');

    // return $status_fill;

    $caller = DB::table('et_staff')->select('et_staff.*', 'et_department.department_name')
      ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
      ->where('et_staff.status', '!=', '2')
      ->where('et_staff.sno', $staff_id)
      ->first();

    $incoming_call_count = DB::table('et_call_log')
      ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
      ->where('et_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('et_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('et_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('et_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('et_call_log.status', 1)                             // Status is 1
      ->count();

    $incoming_call_count = $incoming_call_count ?? 0;

    // Get the outgoing call count excluding the phone numbers in company_cug_detail
    $outgoingcall_count = DB::table('et_call_log')
      ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
      ->where('et_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('et_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('et_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('et_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('et_call_log.status', 0)                             // Status is 0
      ->where('et_call_log.duration', '!=', '00:00:00')            // Duration is not '00:00:00'
      ->count();

    // Assign the result to a variable
    $outgoingcall_count = $outgoingcall_count ?? 0;

    // missed call
    $missedcall_count = DB::table('et_call_log')
      ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
      ->where('et_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('et_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('et_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('et_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('et_call_log.status', 2)                             // Status is 2 for missed calls
      ->where('et_call_log.missed_status', 0)                      // Missed status is 0
      ->count();

    $rejected_call_count = DB::table('et_call_log')
      ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
      ->where('et_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('et_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('et_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('et_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('et_call_log.status', 3)                             // Status is 3 for rejected calls
      ->count();

    // Assign the result to a variable
    $rejected_call_count = $rejected_call_count ?? 0;

    // Assign the result to a variable
    $missedcall_count = $missedcall_count ?? 0;

    $missed_call_ratio = 0;

    if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
      $total_calls = $incoming_call_count + $missedcall_count + $rejected_call_count;
      if ($total_calls > 0) {
        $missed_call_ratio = ($missedcall_count / $total_calls) * 100;
        $missed_call_ratio = $missed_call_ratio;
      } else {
        $missed_call_ratio = 0;
      }
    }

    $outgoing_call_ratio = 0;

    if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
      $total_calls_all = $incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count;
      if ($total_calls > 0) {
        $outgoing_call_ratio = ($outgoingcall_count / $total_calls_all) * 100;
        $outgoing_call_ratio = $outgoing_call_ratio;
      } else {
        $outgoing_call_ratio = 0;
      }
    }

    $calls = DB::table('et_call_log')->select('et_call_log.*', 'et_contact_book.contact_name', 'et_contact_book.phone_no', 'et_post_lead.lead_name')
      ->join('et_contact_book', 'et_contact_book.contact_book_id', '=', 'et_call_log.contact_book_id', 'left')
      ->leftJoin('et_post_lead', DB::raw("SUBSTRING(et_contact_book.phone_no, 4)"), '=', 'et_post_lead.lead_mobile') // Normalized phone_no
      ->where('et_call_log.staff_id', $staff_id)                                                           // Filter by user ID
      ->where('et_call_log.call_date', '>=', $call_start_date)                                             // Start date filter
      ->where('et_call_log.call_date', '<=', $call_end_date);

    // Date Filtering
    if ($date_filter === "today") {
      $calls->whereDate('et_call_log.call_date', now()->toDateString());
    } elseif ($date_filter === "week") {
      $calls->whereBetween('et_call_log.call_date', [now()->startOfWeek(), now()->endOfWeek()]);
    } elseif ($date_filter === "monthly") {
      $calls->whereMonth('et_call_log.call_date', now()->month)
        ->whereYear('et_call_log.call_date', now()->year);
    } elseif ($date_filter === "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $calls->whereBetween('et_call_log.call_date', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]);
      } elseif ($from_date_filter) {
        $calls->where('et_call_log.call_date', '>=', Carbon::parse($from_date_filter));
      } elseif ($to_date_filter) {
        $calls->where('et_call_log.call_date', '<=', Carbon::parse($to_date_filter));
      }
    }

    // Financial Year Filter
    if ($fin_yr_fill) {
      $helper            = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true);
        if (is_array($monthsArray)) {
          $calls->where(function ($query) use ($monthsArray) {
            foreach ($monthsArray as $month) {
              $query->orWhereMonth('et_call_log.call_date', $month)
                ->whereYear('et_call_log.call_date', now()->year);
            }
          });
        }
      }
    }
    // return $status_fill;
    // Other Filters
    if ($status_fill) {
      $calls->where('et_call_log.status', $status_fill);
    } elseif ($status_fill == 0) {
      $calls->where('et_call_log.status', $status_fill);
    }

    $calls  = $calls->orderBy('et_call_log.call_log_id', 'desc')->paginate($perpage);
    $filter = true;

    return view(
      'content.sales.manage_calls.indiv_call_history',
      [
        'calls'               => $calls,
        'perpage'             => $perpage,
        'caller'              => $caller,
        'incoming_call_count' => $incoming_call_count,
        'outgoingcall_count'  => $outgoingcall_count,
        'missedcall_count'    => $missedcall_count,
        'rejected_call_count' => $rejected_call_count,
        'missed_call_ratio'   => $missed_call_ratio,
        'outgoing_call_ratio' => $outgoing_call_ratio,
        'date_filter'         => $date_filter,
        'status_fill'         => $status_fill,
        'fin_yr_fill'         => $fin_yr_fill,
        'from_date_filter'    => $from_date_filter,
        'to_date_filter'      => $to_date_filter,
        'filter'              => $filter,
      ]
    );
  }

  public function lead_call_history($id, $status, Request $request)
  {
    // return $status;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $branch_id = $request->user()->branch_id;

    $helper          = new \App\Helpers\Helpers();
    $decryptedValue  = $helper->encrypt_decrypt($id, 'decrypt');
    $lead_mobile     = $decryptedValue;
    $call_start_date = date('Y-m-01'); // Start date (first day of the month)
    $call_end_date   = date('Y-m-t');

    // Filters
    $status_fill      = $request->input('status_fill', '');
    $date_filter      = $request->input('dt_fill_issue_rpt');
    $from_date_filter = $request->input('from_date_fillter_textbox');
    $to_date_filter   = $request->input('to_date_fillter_textbox');
    $fin_yr_fill      = $request->input('fin_yr_fill', '');

    $normalizedPhoneNo    = ltrim($lead_mobile, '0');   // Remove leading zero if present
    $phoneWithCountryCode = '+91' . $normalizedPhoneNo; // Add the country code

    $lead = DB::table('et_contact_book')->where('phone_no', $lead_mobile)
      ->orWhere('phone_no', $phoneWithCountryCode)->orderBy('contact_book_id', 'desc')->first();
    $staff_id = $lead->staff_id ?? "0";

    $caller = DB::table('et_staff')->select('et_staff.*', 'et_department.department_name')
      ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
      ->where('et_staff.status', '!=', '2')
      ->where('et_staff.sno', $staff_id)
      ->first();

    $incoming_call_count = DB::table('et_call_log')
      ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
      ->where('et_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('et_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('et_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('et_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('et_call_log.status', 1)                             // Status is 1
      ->count();

    $incoming_call_count = $incoming_call_count ?? 0;

    // Get the outgoing call count excluding the phone numbers in company_cug_detail
    $outgoingcall_count = DB::table('et_call_log')
      ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
      ->where('et_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('et_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('et_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('et_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('et_call_log.status', 0)                             // Status is 0
      ->where('et_call_log.duration', '!=', '00:00:00')            // Duration is not '00:00:00'
      ->count();

    // Assign the result to a variable
    $outgoingcall_count = $outgoingcall_count ?? 0;

    // missed call
    $missedcall_count = DB::table('et_call_log')
      ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
      ->where('et_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('et_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('et_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('et_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('et_call_log.status', 2)                             // Status is 2 for missed calls
      ->where('et_call_log.missed_status', 0)                      // Missed status is 0
      ->count();

    $rejected_call_count = DB::table('et_call_log')
      ->join('et_contact_book', 'et_call_log.contact_book_id', '=', 'et_contact_book.contact_book_id')
      ->where('et_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('et_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('et_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('et_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('et_call_log.status', 3)                             // Status is 3 for rejected calls
      ->count();

    // Assign the result to a variable
    $rejected_call_count = $rejected_call_count ?? 0;

    // Assign the result to a variable
    $missedcall_count = $missedcall_count ?? 0;

    $missed_call_ratio = 0;

    if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
      $total_calls = $incoming_call_count + $missedcall_count + $rejected_call_count;
      if ($total_calls > 0) {
        $missed_call_ratio = ($missedcall_count / $total_calls) * 100;
        $missed_call_ratio = $missed_call_ratio;
      } else {
        $missed_call_ratio = 0;
      }
    }

    $outgoing_call_ratio = 0;

    if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
      $total_calls_all = $incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count;
      if ($total_calls > 0) {
        $outgoing_call_ratio = ($outgoingcall_count / $total_calls_all) * 100;
        $outgoing_call_ratio = $outgoing_call_ratio;
      } else {
        $outgoing_call_ratio = 0;
      }
    }

    $calls = DB::table('et_call_log')->select('et_call_log.*', 'et_contact_book.contact_name', 'et_contact_book.phone_no', 'et_post_lead.lead_name')
      ->join('et_contact_book', 'et_contact_book.contact_book_id', '=', 'et_call_log.contact_book_id', 'left')
      ->leftJoin('et_post_lead', DB::raw("SUBSTRING(et_contact_book.phone_no, 4)"), '=', 'et_post_lead.lead_mobile')
      ->where('et_call_log.staff_id', $staff_id)               // Filter by user ID
      ->where('et_call_log.staff_id', $staff_id)               // Filter by user ID
      ->where('et_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->where('et_call_log.call_date', '<=', $call_end_date);

    // return $status;
    if (isset($status) && $status != 0) {
      if ($status == '2') {
        $calls->whereIn('et_call_log.status', [2, 3]);
      } elseif ($status == '1') {
        $calls->where('et_call_log.status', $status);
      }
    } else {
      $calls->where('et_call_log.status', 0);
    }

    $calls = $calls->orderBy('et_call_log.call_log_id', 'desc')->paginate($perpage);

    $filter = false;

    return view('content.sales.manage_calls.indiv_call_history', [
      'calls'               => $calls,
      'perpage'             => $perpage,
      'caller'              => $caller,
      'incoming_call_count' => $incoming_call_count,
      'outgoingcall_count'  => $outgoingcall_count,
      'missedcall_count'    => $missedcall_count,
      'rejected_call_count' => $rejected_call_count,
      'missed_call_ratio'   => $missed_call_ratio,
      'outgoing_call_ratio' => $outgoing_call_ratio,
      'date_filter'         => $date_filter,
      'status_fill'         => $status_fill,
      'fin_yr_fill'         => $fin_yr_fill,
      'from_date_filter'    => $from_date_filter,
      'to_date_filter'      => $to_date_filter,
      'filter'              => $filter,
    ]);
  }

  public function handleWebhookcatch(Request $request)
  {
    // Log the incoming payload for debugging
    // Log::info('Webhook received:', $request->all());
    echo "<script>console.log(" . json_encode($request->all()) . ");</script>";
    // Extract messages from the incoming payload
    $messages = $request->input('entry.0.changes.0.value.messages') ?? [];

    foreach ($messages as $message) {
      $userPhone = $message['from'] ?? null; // User's phone number
      $buttonText = $message['button']['text'] ?? null; // Button text clicked by the user

      if ($userPhone && $buttonText) {
        // Check the button response and send a corresponding reply
        if ($buttonText === 'Yes') {
          $this->sendReply($userPhone, 'Thank you for accepting the offer!');
        } elseif ($buttonText === 'No') {
          $this->sendReply($userPhone, 'No worries! Let us know if you have any questions.');
        } else {
          Log::info("Unhandled button response: $buttonText");
        }
      }
    }

    return response()->json(['status' => 'success']);
  }

  protected function sendReply($userPhone, $messageText)
  {
    $messageData = [
      'messaging_product' => 'whatsapp',
      'to' => $userPhone,
      'type' => 'text',
      'text' => [
        'body' => $messageText,
      ],
    ];

    $apiUri = "https://graph.facebook.com/v21.0/{$this->phoneNumberId}/messages";

    $response = Http::withHeaders([
      'Authorization' => 'Bearer ' . $this->accessToken,
    ])->post($apiUri, $messageData);

    if ($response->successful()) {
      Log::info('Reply sent successfully', ['response' => $response->json()]);
    } else {
      Log::error('Failed to send reply', ['error' => $response->json()]);
    }
  }

  // Proposal 

  public function CreateProposal(Request $request)
  {

    $lead_id = $request->proposal_lead_id ?? 0;

    $values = $request->input('lead_id');
    $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($values, 'encrypt');

    // Return the encrypted value as JSON
    return response()->json($encrypted_values);
  }

  public function manage_proposal_add($id, Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $lead_id = $decryptedValue;
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    //   if($user_id !=0){
    //       return view('content.working_on_progress');
    //   }
    $lead = DB::table('et_post_lead')->where('et_post_lead.sno', $decryptedValue)->first();

    $proposal = ProposalModel::orderBy('sno', 'desc')->first();
    $package_list = DB::table('et_package')->where('et_package.status', 0)->orderBy('sno', 'desc')->get();
    $additional_charges_list = DB::table('et_additional_charges')->where('et_additional_charges.status', 0)->orderBy('sno', 'desc')->get();

    $currencyList = DB::table('et_country_currencies')->where('et_country_currencies.status', 0)->get();
    $domainList = DB::table('et_domain')->where('et_domain.status', 0)->get();

    $Product_cat_list = DB::table('et_product_category')
      ->select(
        'et_product_category.sno',
        'et_product_category.product_category_name',
        DB::raw("COUNT(CASE WHEN et_product.status = 0 THEN 1 END) as product_count")
      )
      ->leftJoin('et_product', 'et_product_category.sno', '=', 'et_product.product_category_id')
      ->where('et_product_category.status', 0)
      ->where('et_product.branch_id', $branch_id)
      ->groupBy('et_product_category.sno', 'et_product_category.product_category_name') // group by primary key of category
      ->orderBy('et_product_category.product_category_name', 'ASC')
      ->get();

    $addOnProductList = DB::table('et_manage_addon')
      ->select(
        'et_manage_addon.sno',
        'et_manage_addon.addon_name'
      )
      ->where('et_manage_addon.status', 0)
      ->where('et_manage_addon.branch_id', $branch_id)
      ->get();

    foreach ($addOnProductList as $addOn) {
      $manageVarient = DB::table('et_manage_addon_variant')
        ->select(
          'et_manage_addon_variant.sno',
          'et_manage_addon_variant.amount',
          'et_manage_addon_variant.free_paid',
          'et_addon_variable.addon_variablename',
        )
        ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
        ->where('et_manage_addon_variant.addon_id', $addOn->sno)
        ->get();

      $addOn->add_varients = $manageVarient;
    }

    $branch_data = DB::table('et_branch')->where('sno', $request->user()->branch_id)->first();

    // return $addOnProductList;

    $create_chk = PreProposalModel::where('lead_id', $lead_id)->where('status', 0)->first();

    if ($create_chk) {
      $Inserted_id = $create_chk->sno;
      $proposal_id_lead = $create_chk->proposal_id;
    } else {
      $category_check = PreProposalModel::orderBy('sno', 'desc')->first();

      if (!$category_check) {
        $year = date('Y');
        $month = date('m');
        $proposal_id = 'PRO-00001/' . $month . '/' . $year;
      } else {
        $year = date('Y');
        $month = date('m');
        $Inserted_id = $category_check->sno + 1;
        $data = $category_check->proposal_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int) $result + 1;
        $request_id = sprintf('PRO-%05d', $next_number);
        $proposal_id = $request_id . '/' . $month . '/' . $year;
      }
      $new_proposal_create = new PreProposalModel();
      $new_proposal_create->proposal_id = $proposal_id;
      $new_proposal_create->lead_id = $lead_id;
      $new_proposal_create->created_by = $user_id;
      $new_proposal_create->updated_by = $user_id;
      $new_proposal_create->save();
      $Inserted_id = $new_proposal_create->sno;
      $proposal_id_lead = $new_proposal_create->proposal_id;
    }
    $packageSlot = DB::table('et_proposal_pay_slot')->where('proposal_id', $proposal_id_lead)->where('status', 0)->where('package_id', '!=', 0)->orderBy('sno', 'desc')->first();
    // return $proposal_id;
    $preProposal = DB::table('et_pre_proposal')->where('proposal_id', $proposal_id_lead)->first();

    $packageData = DB::table('et_proposal_package_cart')->where('proposal_id', $proposal_id_lead)->where('status', 0)->orderBy('sno', 'asc')->get();

    $couponCode = null;

    if ($preProposal->discount_id > 0) {
      $coupon = DB::table('et_manage_coupon')->where('sno', $preProposal->discount_id)->first();

      if ($coupon) {
        $couponCode = $coupon->coupon_code;
      }
    }

    $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)
      ->where('et_staff.role_id', 16)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();

    $referalStaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)
      ->where('et_staff.role_id', '>', 1)
      // ->where('et_staff.department_id', 3)
      // ->where('et_staff.sub_department_id', 6)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $referalStaff = $referalStaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();

    // return $preProposal;
    return view('content.lead_management.manage_proposal.proposal_add', [
      'lead' => $lead,
      'proposal' => $proposal,
      'currencyList' => $currencyList,
      'Product_cat_list' => $Product_cat_list,
      'Inserted_id' => $Inserted_id,
      'addOnProductList' => $addOnProductList,
      'branch_data' => $branch_data,
      'proposal_id' => $proposal_id_lead,
      'package_list' => $package_list,
      'additional_charges_list' => $additional_charges_list,
      'packageSlot' => $packageSlot,
      'couponCode' => $couponCode,
      'preProposal' => $preProposal,
      'domainList' => $domainList,
      'crestaff' => $crestaff,
      'referalStaff' => $referalStaff,
      'packageData' => $packageData,
    ]);
  }

  public function checkMobileExists(Request $request)
  {
    $lead_mobile = $request->input('mobile');

    $lead = PostLeadModel::where('lead_mobile', $lead_mobile)
      // ->where('status', '!=', 2)
      ->first();

    if ($lead) {
      return response()->json([
        'message' => 'Lead Mobile Number already assigned!',
        'data'    => 1,
      ], 200);
    } else {
      return response()->json([
        'message' => 'mobile no available!',
        'data'    => 0,
      ], 200);
    }
  }

  public function checkEmailExists(Request $request)
  {
    $lead_email = $request->input('email');

    $lead = PostLeadModel::where('lead_email_id', $lead_email)
      // ->where('status', '!=', 2)
      ->first();

    if ($lead) {
      return response()->json([
        'message' => 'Lead Email Id already assigned!',
        'data'    => 1,
      ], 200);
    } else {
      return response()->json([
        'message' => 'Email Id available!',
        'data'    => 0,
      ], 200);
    }
  }


  public function checkMobileExistsEdit()
  {
    $lead_mobile = request()->input('mobile');
    $id           = request()->input('id');
    // return $id;
    $lead = PostLeadModel::where('lead_mobile', $lead_mobile)
      // ->where('status', '!=', 2)
      ->where('sno', '!=', $id)
      ->first();

    if ($lead) {
      return response()->json([
        'message' => 'Lead Mobile Number already assigned!',
        'data'    => $lead,
      ], 200);
    } else {
      return response()->json([
        'message' => 'Mobile Number available!',
        'data'    => 0,
      ], 200);
    }
  }

  public function checkEmailExistsEdit()
  {
    $lead_email = request()->input('email');
    $id           = request()->input('id');
    // return $id;
    $lead = PostLeadModel::where('lead_email_id', $lead_email)
      // ->where('status', '!=', 2)
      ->where('sno', '!=', $id)
      ->first();

    if ($lead) {
      return response()->json([
        'message' => 'Lead Email Id already assigned!',
        'data'    => $lead,
      ], 200);
    } else {
      return response()->json([
        'message' => 'Email Id available!',
        'data'    => 0,
      ], 200);
    }
  }
  public function Add(Request $request)
  {

    //  return $request;
    $validator = Validator::make($request->all(), [
      'lead_name' => 'required|max:255',

    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $lead_name           = $request->lead_name;

      $inter_calls = $request->mobile_check ? $request->country_code_name : null;
      $lead_mobile         = $request->mobile_check ? $request->lead_mobile_create : null;
      $lead_alternate_mobile       = $request->lead_alternate_mobile;
      $lead_email_id       = $request->email_check ? $request->lead_email_id : null;
      $lead_gender         = $request->lead_gender;
      $lead_marital_status            = $request->lead_marital_status;
      $Know_tag = is_array($request->lead_KnowledgeTag) ? json_encode($request->lead_KnowledgeTag) : $request->lead_KnowledgeTag;

      $country              = $request->country;
      $state                = $request->state;
      $city                 = $request->city;
      $address              = $request->address;
      $door_no            = $request->door_no;
      $pincode            = $request->pincode;
      $service_id            = json_encode($request->service_id);
      $university_id            = $request->university_id ?? 0;
      $lead_potential_type_id            = $request->potential_type_id;
      $lead_type_id            = $request->lead_type_id;
      $lead_source_id            = $request->lead_source_id;
      $lead_question_id            = $request->lead_question_id;
      $lead_comments            = $request->lead_comments;
      $branch_id       = $request->user()->branch_id ?? 1;
      $entity_id       = $request->user()->entity_id ?? 1;
      $lead_dob = isset($request->lead_dob) ? date('Y-m-d', strtotime($request->lead_dob)) : null;
      $lead_reg_date = date('Y-m-d');


      $user_id            = $request->user()->user_id ?? 1;
      // dd($request);
      $chk = PostLeadModel::where('lead_mobile', ucwords($lead_mobile))->where('et_post_lead.branch_id', $branch_id)->where('et_post_lead.entity_id', $entity_id)->where('status', '!=', 2)->first();
      $chk2 = PostLeadModel::where('lead_email_id', $lead_email_id)
        ->whereNotNull('lead_email_id')
        ->where('branch_id', $branch_id)
        ->where('entity_id', $entity_id)
        ->where('status', '!=', 2)
        ->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Mobile Number already Exits!'
        ]);
      } elseif ($chk2) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'E-Mail Id already Exits!'
        ]);
      } else {
        $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

        $branch_code = $branch_check->city_short_code;

        $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $year = date("Y");
        if (!$category_check) {
          $lead_id = $year . '/' . $branch_code . '/' . "PSL0001";
        } else {
          $data = $category_check->lead_id;
          $slice = explode("/", $data);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $request_pay = sprintf("PSL%04d", $next_number);
          $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
        }

        $entity_id = $request->user()->entity_id;
        $add_category = new PostLeadModel();
        $add_category->lead_id                 = $lead_id;
        $add_category->lead_name               = $lead_name;
        $add_category->is_post_sale_lead       = 1;
        $add_category->lead_mobile             = $lead_mobile;
        $add_category->inter_calls             = $inter_calls;
        $add_category->lead_alternate_mobile   = $lead_alternate_mobile;
        $add_category->lead_email_id           = $lead_email_id;
        $add_category->lead_gender             = $lead_gender;
        $add_category->lead_dob                = $lead_dob;
        $add_category->registered_date         = $lead_reg_date;
        $add_category->lead_marital_status     = $lead_marital_status;
        $add_category->country                 = $country;
        $add_category->state                   = $state;
        $add_category->entity_id               = $entity_id;
        $add_category->city                    = $city;
        $add_category->address                 = $address;
        $add_category->door_no                 = $door_no;
        $add_category->pincode                 = $pincode;
        $add_category->service_id              = $service_id;
        $add_category->university_id           = $university_id;
        $add_category->lead_potential_type_id  = $lead_potential_type_id;
        $add_category->entity_id               = $entity_id;
        $add_category->lead_source_id          = $lead_source_id;
        $add_category->lead_type_id            = $lead_type_id;
        $add_category->lead_question_id        = $lead_question_id;
        $add_category->lead_comments           = $lead_comments;
        $add_category->lead_knowledge_tags     = $Know_tag;
        $add_category->branch_id               = $branch_id;
        $add_category->created_by              = $user_id;
        $add_category->updated_by              = $user_id;
        $add_category->lead_status_id          = 1; //new lead
        $add_category->lead_condition          = 2; //standard lead
        $add_category->save();
        if ($add_category) {
          // $add_history = new LeadTransferLogModel();
          // $add_history->lead_id = $add_category->sno;
          // $add_history->branch_id = $add_category->branch_id;
          // $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          // $add_history->current_staff_id = $add_category->created_by;
          // $add_history->change_staff_id = 0;
          // $add_history->transferred_from = 0; // from Bulk transfer  
          // $add_history->created_by = $user_id;
          // $add_history->updated_by = $user_id;
          // // return $add_history;
          // $add_history->save();

          // //****************** */ Update Staff Sales Person Points
          // // Define point category:
          // // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
          // $helper = new \App\Helpers\Helpers();
          // $pointsData = $helper->get_points_by_id(1);
          // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
          // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
          // // Save new points for the staff
          // $newPoints = new StaffpointsModel();
          // $newPoints->branch_id = $branch_id;
          // $newPoints->staff_id = $user_id;
          // $newPoints->points_by = $add_category->sno;
          // $newPoints->points_id = 1;
          // $newPoints->points = $point;
          // $newPoints->reason = $reason;
          // $newPoints->save();

          // // Update staff's available points
          // $staff_points = StaffModel::where('sno', $user_id)->first();
          // if ($staff_points) {
          //   $staff_points->avaiable_points += $point; // Increment the available points
          //   $staff_points->save();
          // }
          // //****************** */ Update Staff Sales Person Points

          // $comm_get = Communication_config_Model::where('status', 0)->where('work_flow_id', 1)->orderBy('sno', 'desc')->get();
          // if (isset($comm_get) && count($comm_get) > 0) {
          //   foreach ($comm_get as $comm) {
          //     $sourceTypeId = 1;
          //     $sourceId = $add_category->sno;
          //     $configId = $comm->sno;
          //     $branchId = $branch_id;
          //     $userId   = $user_id;
          //     $helper = new \App\Helpers\Helpers();
          //     $helper->scheduleMessages($sourceTypeId, $sourceId, $configId, $branchId, $userId);
          //   }
          // }
        }

        if ($add_category) {
          $notificationData = [
            'branch_id' => $branch_id,
            'notification_content' => ' <div class="d-flex align-items-center">
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-account-multiple-outline fs-3 text-black"></i></span>
              </div>
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
                <div class="text-secondary fs-8 fw-semibold">' . $add_category->lead_name . ' New Post Sale Lead Created</div>
              </div>
            </div>',
            'who' => $user_id,
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'status' => 0
          ];
          $notificationtype = 'Lead';
          $newNotification = new \App\Helpers\Helpers();

          $newNotification->createNotification($notificationData, $notificationtype);
        }
        // $branch_data = BranchModel::where('sno', $branch_id)->first();
        // $branch_name = " ";
        // if ($branch_data->branch_type == 1) {
        //   $branch_name = $branch_data->branch_name;
        // } elseif ($branch_data->branch_type == 2) {
        //   $branch_name = $branch_data->franchise_name;
        // }

        // $entityData = '';

        // communication Send
        // $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id', $user_id)->first();
        // $communicationStatus = DB::table('et_communication_handle')->where('module_name', 'Lead Welcome')->first();
        // if ($communicationStatus && $communicationStatus->status == 0) {
        //   // // sms thank you lead
        //   if ($communicationStatus->sms == 0) {
        //     if ($add_category && $lead_mobile) {

        //       $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', 'PhDiZone_Enquiry_Thankyou_Message')->first();
        //       $authkey = $result_sms ? $result_sms->authkey : '';
        //       $sender_id = $result_sms ? $result_sms->sender_id : '';
        //       $template_id = $result_sms ? $result_sms->template_id : '';
        //       $country_code = $result_sms ? $result_sms->country_code : '';
        //       $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
        //       $mobile_number = $country_code . $lead_mobile;

        //       $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

        //       // Replace placeholders with actual values
        //       $replacement_values = [$lead_name, $branch_name, $cre_mobile];
        //       $message_content = preg_replace_callback(
        //         '/\{#var#\}/',
        //         function () use (&$replacement_values) {
        //           return array_shift($replacement_values);
        //         },
        //         $message_content
        //       );

        //       $route = "default";
        //       $postData = array(
        //         'authkey' => $authkey,
        //         'mobiles' => $mobile_number,
        //         'message' => $message_content,
        //         'sender' => $sender_id,
        //         'route' => $route,
        //       );

        //       // API URL
        //       $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

        //       // Initialize the resource
        //       $ch = curl_init();
        //       curl_setopt_array($ch, array(
        //         CURLOPT_URL => $url,
        //         CURLOPT_RETURNTRANSFER => true,
        //         CURLOPT_POST => true,
        //         CURLOPT_POSTFIELDS => $postData,
        //         CURLOPT_SSL_VERIFYHOST => 0,
        //         CURLOPT_SSL_VERIFYPEER => 0,
        //       ));

        //       // Get response
        //       $response = curl_exec($ch);
        //       // return $response;
        //       $err = curl_error($ch);
        //       curl_close($ch);
        //     }
        //   }

        //   // // Thank you email send
        //   if ($communicationStatus->email == 0) {
        //     if ($add_category && $lead_email_id) {
        //       $email_template_id = 2; // thank you template
        //       $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
        //       $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
        //       $content = $emailTemplate->email_subject;
        //       $content = str_replace('#lead_name', $lead_name, $content);
        //       $branchNo = $branch_data->mobile;
        //       $branchemail = $branch_data->mail;
        //       $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/PhDiZone/';
        //       $instaLink = $branch_data->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
        //       $content = str_replace('#sales_mobile', $cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile, $content);
        //       $content = str_replace('#cre_mobile', $branch_data->cre_mobile ?? '8220011465', $content);
        //       $url = 'phdizone.com';
        //       $mailData = [
        //         'url'         => $url,
        //         'subject'     => $dynamicSubject,
        //         'content'     => $content,
        //         'branchNo'    => $branchNo,
        //         'branchemail' => $branchemail, // Use the message content from the request
        //         'fbLink'      => $fbLink,      // Use the message content from the request
        //         'instaLink'   => $instaLink,   // Use the message content from the request
        //         'salesMobile' => $branch_data->cre_mobile ?? '9003400111',
        //       ];

        //       $to_address = $lead_email_id;
        //       $from_address = 'elysiumtechnology@elysium.community';
        //       $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';

        //       Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
        //     }
        //   }

        //   // // Thank You whatsapp message
        //   if ($communicationStatus->whatsapp == 0) {
        //     if ($add_category && $lead_mobile) {
        //       $templateName = "welcome_msg_phdizone";

        //       $hasHeader  = false; // Example flag: set based on template
        //       $hasBody    = false; // Example flag: set based on template
        //       $hasFooter  = false; // Example flag: set based on template
        //       $hasButton  = false;
        //       $components = [];
        //       $couponCode = " ";
        //       date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
        //       $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
        //       // $currentHour = date('H'); // Get current hour in 24-hour format
        //       if ($currentHour >= 5 && $currentHour < 12) {
        //         $greeting = 'Good Morning';
        //       } elseif ($currentHour >= 12 && $currentHour < 18) {
        //         $greeting = 'Good Afternoon';
        //       } else {
        //         $greeting = 'Good Evening';
        //       }

        //       if ($templateName == 'welcome_msg_phdizone') {

        //         $headerImage = 'https://dev.erp.elysiumtechnologies.com/public/assets/phdizone_images/Thank-You.jpg';
        //         $couponCode  = 'NOOFFER';
        //         $buttonIndex = 0;
        //         $bodyText    = [
        //           [
        //             'type'           => 'text',
        //             'text'           => $lead_name,
        //             'parameter_name' => 'lead_name',
        //           ],
        //           [
        //             'type'           => 'text',
        //             'text'           => $cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile,
        //             'parameter_name' => 'sales_numbers',
        //           ]

        //         ];
        //         $hasHeader = true;
        //         $hasBody   = true;
        //       }

        //       // Add Header if required
        //       if ($hasHeader) {
        //         $components[] = [
        //           'type'       => 'header',
        //           'parameters' => [
        //             [
        //               'type'  => 'image',
        //               'image' => [
        //                 'link' => $headerImage, // Dynamically set header image
        //               ],
        //             ],
        //           ],
        //         ];
        //       }

        //       // Add Body if required
        //       if ($hasBody) {
        //         $components[] = [
        //           'type'       => 'body',
        //           'parameters' => $bodyText,
        //         ];
        //       }

        //       // Add Footer if required
        //       if ($hasFooter) {
        //         $components[] = [
        //           'type'       => 'footer',
        //           'parameters' => [
        //             [
        //               'type'           => 'text',
        //               'text'           => 'This is the footer text.',
        //               'parameter_name' => 'footer_text',
        //             ],
        //           ],
        //         ];
        //       }

        //       // Add Button if required
        //       if ($hasButton) {
        //         $components[] = [
        //           'type'       => 'button',
        //           'sub_type'   => 'copy_code',
        //           'index'      => $buttonIndex,
        //           'parameters' => [
        //             [
        //               'type'        => 'coupon_code',
        //               'coupon_code' => $couponCode,
        //             ],
        //           ],
        //         ];
        //       }

        //       $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id', $branch_data->entity_id)->orderBy('sno', 'desc')->first();
        //       $dynamicParameters         = $templateParameters[$templateName] ?? [];
        //       $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
        //       $accessToken               = $whatsappApi->access_tokken ?? '';
        //       $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';

        //       $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';


        //       $countryCode  = $inter_calls ? ($inter_calls == 0 ? '+91' : '+' . $inter_calls) : '+91';
        //       $to           = $lead_mobile;
        //       $languageCode = 'en';

        //       if (strpos($to, $countryCode) !== 0) {
        //         $to = $countryCode . $to;
        //       }

        //       $message = 'test~message';
        //       if (empty($components)) {
        //         $payload = [
        //           'messaging_product' => 'whatsapp',
        //           'to'                => $to,
        //           'type'              => 'template',
        //           'template'          => [
        //             'name'     => $templateName,
        //             'language' => [
        //               'code' => $languageCode,
        //             ],
        //           ],
        //         ];
        //       } else {
        //         $payload = [
        //           'messaging_product' => 'whatsapp',
        //           'to'                => $to,
        //           'type'              => 'template',
        //           'template'          => [
        //             'name'       => $templateName,
        //             'language'   => [
        //               'code' => $languageCode,
        //             ],
        //             'components' => $components,
        //           ],
        //         ];
        //       }

        //       $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
        //     }
        //   }
        // }

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Lead added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Lead!'
          ]);
        }
      }
      // return $result;
      return redirect('manage_post_sale_lead');
    }
  }
}