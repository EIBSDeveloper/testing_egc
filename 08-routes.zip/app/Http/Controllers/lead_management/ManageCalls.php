<?php
namespace App\Http\Controllers\lead_management;

use App\Http\Controllers\Controller;
use App\Models\ManageTeamModel;
use App\Models\LeadModel;
use App\Models\BranchModel;
use App\Models\LeadTransferLogModel;
use App\Models\SpamReasonModel;
use App\Models\CallTrackerModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use Illuminate\Support\Facades\Cache;
use Illuminate\Pagination\LengthAwarePaginator;

class ManageCalls extends Controller
{

        public function index(Request $request)
        {
            $month_filter = $request->get('month_filter', date('M-Y'));
            $parsedDate   = Carbon::createFromFormat('M-Y', $month_filter);
        
            $page      = $request->input('page', 1);
            $perpage   = (int) $request->input('sorting_filter', 25);
            $branch_id = $request->user()->branch_id;
            $user_id   = $request->user()->user_id;
        
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        
            $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
        
            // Staff list cache
            $staff_list = Cache::remember("staff_list_branch_{$branch_id}", 300, function () {
                return DB::table('et_cug_management')
                    ->select(
                        'et_cug_management.staff_id',
                        'et_staff.staff_name',
                        'et_staff.nick_name',
                        'et_staff.staff_image',
                        'et_staff.gender',
                        'et_staff.mobile_no',
                        'et_department.department_name'
                    )
                    ->join('et_staff', 'et_staff.sno', '=', 'et_cug_management.staff_id')
                    ->leftJoin('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                    ->where('et_staff.status', '!=', 2)
                    ->where('et_department.sno', 1)
                    ->distinct()
                    ->get();
            });
        
            // Filters
            $call_fill        = $request->input('call_fill', '');
            $staff_fill       = $request->input('staff_fill', '');
            $status_fill      = $request->input('status_fill', '');
            $from_date_filter = $request->input('from_date_fillter_textbox');
            $to_date_filter   = $request->input('to_date_fillter_textbox');
        
            $startTime = microtime(true);
        
            /**
             * Step 1: Query only IDs for pagination
             */
            $callIdQuery = DB::table('et_call_tracker')
                ->where('et_call_tracker.branch_id', $branch_id);
        
            // Month filter (only if no date range is given)
            if (!$from_date_filter && !$to_date_filter) {
                $callIdQuery->whereYear('et_call_tracker.call_start_date', $year)
                    ->whereMonth('et_call_tracker.call_start_date', $month);
            }
        
            // Date range filter
            if ($from_date_filter && $to_date_filter) {
                $callIdQuery->whereBetween('et_call_tracker.call_start_date', [$from_date_filter, $to_date_filter]);
            }
        
            // Permission check
            if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Calls', 'view_self_lead')) {
                $callIdQuery->where('et_call_tracker.branch_staff_id', $user_id);
            }
        
             if ($status_fill) {
                $callIdQuery->where('et_call_tracker.call_status', $status_fill);
            }elseif ($status_fill === '0') {
                $callIdQuery->where('et_call_tracker.call_status', $status_fill);
            }
            if ($staff_fill) {
                $callIdQuery->where('et_call_tracker.branch_staff_id', $staff_fill);
            }
            if ($call_fill != '') {
                $callIdQuery->join('et_staff', 'et_staff.sno', '=', 'et_call_tracker.branch_staff_id')
                    ->where(function ($query) use ($call_fill) {
                        $query->where('et_call_tracker.customer_phone_no', 'LIKE', "%{$call_fill}%")
                            ->orWhere('et_call_tracker.staff_phone_no', 'LIKE', "%{$call_fill}%")
                            ->orWhere('et_staff.staff_name', 'LIKE', "%{$call_fill}%")
                            ->orWhere('et_staff.nick_name', 'LIKE', "%{$call_fill}%")
                            ->orWhere('et_call_tracker.customer_name', 'LIKE', "%{$call_fill}%");
                    });
            }
        
            // Get paginated IDs
            $paginatedIds = $callIdQuery
                ->orderBy('et_call_tracker.call_start_date', 'desc')
                ->orderBy('et_call_tracker.call_start_time', 'desc')
                ->paginate($perpage, ['et_call_tracker.sno']);
        
            $callIds = $paginatedIds->pluck('sno')->toArray();
        
            /**
             * Step 2: Fetch full data with same filters
             */
            $calls = DB::table('et_call_tracker')
                ->select(
                    'et_call_tracker.call_status',
                    'et_call_tracker.sno',
                    'et_call_tracker.staff_phone_no',
                    'et_call_tracker.customer_name',
                    'et_call_tracker.customer_phone_no',
                    'et_call_tracker.call_start_date',
                    'et_call_tracker.call_start_time',
                    'et_call_tracker.call_end_time',
                    'et_call_tracker.call_duration',
                    'et_call_tracker.latitude',
                    'et_call_tracker.longitude',
                    'et_lead.lead_name',
                    'et_lead.drop_verified',
                    'et_lead.drop_tl_verified',
                    'et_lead.spam_verified',
                    'et_lead.spam_tl_verified',
                    'et_lead.status AS lead_status',
                    'et_staff.staff_name',
                    'sb.staff_name AS lead_staff',
                    'et_Internal_cugs.user_name as internal_user_name',
                    'et_lead.created_by'
                )
                ->join('et_staff', 'et_staff.sno', '=', 'et_call_tracker.branch_staff_id')
                ->leftJoin('et_lead', function ($join) {
                    $join->on('et_lead.lead_mobile', '=', DB::raw("RIGHT(et_call_tracker.customer_phone_no, 10)"));
                })
                ->leftJoin('et_Internal_cugs', function ($join) {
                    $join->on('et_Internal_cugs.cug_mobile_no', '=', DB::raw("RIGHT(et_call_tracker.customer_phone_no, 10)"));
                })
                ->leftJoin('et_staff as sb', 'sb.sno', '=', 'et_lead.created_by')
                ->whereIn('et_call_tracker.sno', $callIds)
                ->orderBy('et_call_tracker.call_start_date', 'desc')
                ->orderBy('et_call_tracker.call_start_time', 'desc')
                ->get();
        
            /**
             * Step 3: Aggregate counts
             */
            $call_counts = DB::table('et_call_tracker')
                ->selectRaw('
                    COUNT(CASE WHEN call_status = 1 THEN 1 END) as incoming_call_count,
                    COUNT(CASE WHEN call_status = 0 THEN 1 END) as outgoing_call_count,
                    COUNT(CASE WHEN call_status = 2 THEN 1 END) as missedcall_count,
                    COUNT(CASE WHEN call_status = 3 THEN 1 END) as rejected_call_count,
                    COUNT(CASE WHEN call_status = 4 THEN 1 END) as dialedcall_count
                ')
                ->where('branch_id', $branch_id)
                ->whereYear('call_start_date', $year)
                ->whereMonth('call_start_date', $month);
        
            if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Calls', 'view_self_lead')) {
                $call_counts->where('branch_staff_id', $user_id);
            }
            if ($staff_fill) {
                $call_counts->where('branch_staff_id', $staff_fill);
            }
            if ($status_fill !== '') {
                $call_counts->where('call_status', $status_fill);
            }
        
            $call_counts = $call_counts->first();
        
            $incoming_call_count = $call_counts->incoming_call_count ?? 0;
            $outgoingcall_count  = $call_counts->outgoing_call_count ?? 0;
            $missedcall_count    = $call_counts->missedcall_count ?? 0;
            $rejected_call_count = $call_counts->rejected_call_count ?? 0;
            $dialedcall_count    = $call_counts->dialedcall_count ?? 0;
        
            $missed_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count > 0)
                ? ($missedcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count)) * 100
                : 0;
        
            $outgoing_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count > 0)
                ? ($outgoingcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count)) * 100
                : 0;
        
            $reasonList = SpamReasonModel::where('status', 0)
                ->orderBy('sno', 'desc')
                ->get();
        
            /**
             * Step 4: Fetch loginData (mysql_secondary)
             */
            $staffPhones = $calls->pluck('staff_phone_no')->filter()->unique()->values();
        
            $loginData = DB::connection('mysql_secondary')
                ->table('user as u')
                ->select('u.phone_no', 'u.last_sync_date', 'u.last_sync_time')
                ->whereIn('u.phone_no', $staffPhones)
                ->get()
                ->keyBy('phone_no');
        
            // If you want to debug just like indexold
            // if ($user_id == 0) {
            //     return $loginData;
            // }
        
            $callsPaginator = new LengthAwarePaginator(
                $calls,
                $paginatedIds->total(),
                $paginatedIds->perPage(),
                $paginatedIds->currentPage(),
                ['path' => request()->url(), 'query' => request()->query()]
            );
        
            return view('content.lead_management.manage_calls.call_list', [
                'calls'               => $callsPaginator,
                'month_chk'           => $month_chk,
                'month'               => $month,
                'year'                => $year,
                'staff_list'          => $staff_list,
                'staff_fill'          => $staff_fill,
                'month_filter'        => $month_filter,
                'call_fill'           => $call_fill,
                'perpage'             => $perpage,
                'reasonList'          => $reasonList,
                'incoming_call_count' => $incoming_call_count,
                'outgoingcall_count'  => $outgoingcall_count,
                'missedcall_count'    => $missedcall_count,
                'rejected_call_count' => $rejected_call_count,
                'dialedcall_count'    => $dialedcall_count,
                'missed_call_ratio'   => $missed_call_ratio,
                'outgoing_call_ratio' => $outgoing_call_ratio,
                'status_fill'         => $status_fill,
                'lastLoginDataMap'    => $loginData,
            ]);
        }


   
     public function indexold(Request $request)
    {
        
       $month_filter = $request->get('month_filter', date('M-Y'));

        // Parse the date using Carbon for better reliability
        $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
        
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $branch_id = $request->user()->branch_id ;
        $user_id = $request->user()->user_id;
        
        $month = $parsedDate->month; // numeric month (1-12)
        $year = $parsedDate->year;
        
        
         

        // Check if selected month is current or future
        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
        
        
      

        // Query to get staff list
        $staff_list = DB::table('et_cug_management')
            ->select('et_cug_management.staff_id', 'et_staff.staff_name', 'et_staff.staff_image', 'et_staff.gender', 'et_staff.mobile_no', 'et_department.department_name')
            ->join('et_staff', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->leftJoin('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->distinct()
            ->where('et_staff.status', '!=', 2)
            ->where('et_department.sno', 1)
            ->get();
            
        

        // Filters
        $call_fill = $request->input('call_fill', '');
        $staff_fill = $request->input('staff_fill', '');
        $status_fill = $request->input('status_fill', '');
        $date_filter = $request->input('dt_fill_issue_rpt');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter = $request->input('to_date_fillter_textbox');
        
          $startTime = microtime(true);
        
         $calls = DB::table('et_call_tracker')
            ->select('et_call_tracker.call_status',
            'et_call_tracker.sno',
            'et_call_tracker.staff_phone_no',
            'et_call_tracker.customer_name',
            'et_call_tracker.customer_phone_no',
            'et_call_tracker.call_start_date',
            'et_call_tracker.call_start_time',
            'et_call_tracker.call_end_time',
            'et_call_tracker.call_duration',
            'et_call_tracker.latitude',
            'et_call_tracker.longitude',
            'et_lead.lead_name',
            'et_lead.drop_verified', 'et_lead.drop_tl_verified',
            'et_lead.spam_verified', 'et_lead.spam_tl_verified',
            'et_lead.status AS lead_status',
            'et_staff.staff_name',
            'sb.staff_name AS lead_staff',
            'et_Internal_cugs.user_name as internal_user_name',
            'et_lead.created_by')
            ->join('et_staff', 'et_staff.sno', '=', 'et_call_tracker.branch_staff_id')
        ->leftJoin('et_lead', function ($join) {
                            $join->on('et_lead.lead_mobile', '=', DB::raw("RIGHT(et_call_tracker.customer_phone_no, 10)"));
                        })
        ->leftJoin('et_Internal_cugs', function ($join) {
            $join->on('et_Internal_cugs.cug_mobile_no', '=', DB::raw("RIGHT(et_call_tracker.customer_phone_no, 10)"));
        })
        ->leftJoin('et_staff as sb', 'sb.sno', '=', 'et_lead.created_by') 
        ->where('et_call_tracker.branch_id', $branch_id);
        
        
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Calls', 'view_self_lead')) {
            // User can only view their own data
            $calls = $calls->where('et_staff.sno', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Calls', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        

        if ($status_fill) {
            $calls->where('et_call_tracker.call_status', $status_fill);
        } elseif ($status_fill === '0') {
            $calls->where('et_call_tracker.call_status', $status_fill);
        }

        if ($staff_fill) {
            $calls->where('et_call_tracker.branch_staff_id', $staff_fill);
        }

       
        if ($call_fill != '') {
            $calls->where(function ($query) use ($call_fill) {
                $query->where('et_call_tracker.customer_phone_no', 'LIKE', "%{$call_fill}%")
                    ->orWhere('et_call_tracker.customer_name', 'LIKE', "%{$call_fill}%")
                    ->orWhere('et_lead.lead_name', 'LIKE', "%{$call_fill}%");
            });
        }
        
         if ($call_fill == '' && !$staff_fill) {
                $calls->whereYear('et_call_tracker.call_start_date', $year)
                 ->whereMonth('et_call_tracker.call_start_date', $month);
         }
        

        // Paginate Calls
        $calls = $calls ->orderBy('et_call_tracker.call_start_date', 'desc')->orderBy('et_call_tracker.call_start_time', 'desc')
        ->paginate($perpage);
        
        //   $endTime       = microtime(true);
        // $executionTime = $endTime - $startTime;
        // return($executionTime);
        
        //  $endTime       = microtime(true);
        // $executionTime = $endTime - $startTime;
        // return($calls);

        // Aggregated Query for Calls (Incoming, Outgoing, Missed, Rejected)
        $call_counts = DB::table('et_call_tracker')
            ->selectRaw('
                COUNT(CASE WHEN call_status = 1 THEN 1 END) as incoming_call_count,
                COUNT(CASE WHEN call_status = 0 THEN 1 END) as outgoing_call_count,
                COUNT(CASE WHEN call_status = 2 THEN 1 END) as missedcall_count,
                COUNT(CASE WHEN call_status = 3 THEN 1 END) as rejected_call_count,
                COUNT(CASE WHEN call_status = 4 THEN 1 END) as dialedcall_count
            ')
            ->whereYear('call_start_date', $year)
            ->where('et_call_tracker.branch_id', $branch_id)
            ->whereMonth('call_start_date', $month);
            
             if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Calls', 'view_self_lead')) {
                // User can only view their own data
                $call_counts = $call_counts->where('branch_staff_id', $user_id);
            } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Calls', 'global_lead')) {
                // User can view all data (no additional filters needed)
    
            }

        if ($staff_fill) {
            $call_counts->where('branch_staff_id', $staff_fill);
        }

        // Execute the counts
        $call_counts = $call_counts->first();

        // Assign counts
        $incoming_call_count = $call_counts->incoming_call_count ?? 0;
        $outgoingcall_count = $call_counts->outgoing_call_count ?? 0;
        $missedcall_count = $call_counts->missedcall_count ?? 0;
        $rejected_call_count = $call_counts->rejected_call_count ?? 0;
        $dialedcall_count = $call_counts->dialedcall_count ?? 0;

        // Calculate Ratios
        $missed_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count > 0)
            ? ($missedcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count)) * 100
            : 0;

        $outgoing_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count > 0)
            ? ($outgoingcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count)) * 100
            : 0;
            
            // $endTime       = microtime(true);
            // $executionTime = $endTime - $startTime;
            // return($executionTime);
        // Query for Calls (Paginated)
        //  $startTime = microtime(true);
       
         $reasonList = SpamReasonModel::select('*')
        ->where('status', 0)
        ->orderBy('sno', 'desc')->get();   
        
        $staffPhones = $calls->pluck('staff_phone_no')->filter()->unique()->values();

        // 2. Fetch login data from mysql_secondary
        $loginData = DB::connection('mysql_secondary')
            ->table('user as u')
            ->select('u.phone_no', 'u.last_sync_date', 'u.last_sync_time')
            ->whereIn('u.phone_no', $staffPhones)
            ->get()
            ->keyBy('phone_no');
       
 

        return view('content.lead_management.manage_calls.call_list', [
            'calls' => $calls,
            'month_chk' => $month_chk,
            'month' => $month,
            'year' => $year,
            'staff_list' => $staff_list,
            'staff_fill' => $staff_fill,
            'month_filter' => $month_filter,
            'call_fill' => $call_fill,
            'perpage' => $perpage,
            'reasonList' => $reasonList,
            'incoming_call_count' => $incoming_call_count,
            'outgoingcall_count' => $outgoingcall_count,
            'missedcall_count' => $missedcall_count,
            'rejected_call_count' => $rejected_call_count,
            'dialedcall_count' => $dialedcall_count,
            'missed_call_ratio' => $missed_call_ratio,
            'outgoing_call_ratio' => $outgoing_call_ratio,
            'status_fill' => $status_fill,
             'lastLoginDataMap' => $loginData,
        ]);
    }

    public function lead_call_history($id, $status, Request $request)
    {
        // return $status;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;
        $branch_id = $request->user()->branch_id ?? 1;

        $helper          = new \App\Helpers\Helpers();
        $decryptedValue  = $helper->encrypt_decrypt($id, 'decrypt');
        $lead_id     = $decryptedValue;
        $call_start_date = date('Y-m-01'); // Start date (first day of the month)
        $call_end_date   = date('Y-m-t');

        // Filters
        $status_fill      = $request->input('status_fill', '');
        $date_filter      = $request->input('dt_fill_issue_rpt');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter   = $request->input('to_date_fillter_textbox');
        $fin_yr_fill      = $request->input('fin_yr_fill', '');



        // $lead = DB::table('et_call_tracker')->where('customer_phone_no', $lead_mobile)
        //     ->orWhere('customer_phone_no', $phoneWithCountryCode)->orderBy('sno', 'desc')->first();

        $caller = DB::table('et_lead')->select('et_lead.*')
            ->where('et_lead.sno', $lead_id)
            ->first();

            $lead_mobile =$caller->lead_mobile;
            $normalizedPhoneNo    = ltrim($lead_mobile, '0');   // Remove leading zero if present
            $phoneWithCountryCode = '+91' . $normalizedPhoneNo; // Add the country code

            // return  $caller ;


        $incoming_call_count = DB::table('et_call_tracker')
            ->where('customer_phone_no', $lead_mobile)        
            ->orWhere('customer_phone_no', $phoneWithCountryCode)       
              ->whereYear('et_call_tracker.call_start_date', $year)
        ->whereMonth('et_call_tracker.call_start_date', $month)// End date filter 
            ->where('et_call_tracker.call_status', 1)                             // Status is 1
            ->count();

        $incoming_call_count = $incoming_call_count ?? 0;

        // Get the outgoing call count excluding the phone numbers in company_cug_detail
        $outgoingcall_count = DB::table('et_call_tracker')
            ->where('customer_phone_no', $lead_mobile)        
            ->orWhere('customer_phone_no', $phoneWithCountryCode)                // Filter by user ID
            ->whereDate('et_call_tracker.call_start_date', '>=', $call_start_date) // Start date filter
            ->whereDate('et_call_tracker.call_start_date', '<=', $call_end_date)
            ->where('et_call_tracker.call_status', 0)                             // Status is 0
            // ->where('et_call_tracker.call_duration', '!=', '00:00:00')            // Duration is not '00:00:00'
            ->count();

        // Assign the result to a variable
        $outgoingcall_count = $outgoingcall_count ?? 0;

        // missed call
        $missedcall_count = DB::table('et_call_tracker')
        ->where('customer_phone_no', $lead_mobile)        
        ->orWhere('customer_phone_no', $phoneWithCountryCode)                 // Filter by user ID
              ->whereYear('et_call_tracker.call_start_date', $year)
        ->whereMonth('et_call_tracker.call_start_date', $month)// End date filter  
            ->where('et_call_tracker.call_status', 2)                             // Status is 2 for missed calls
            ->count();

        $rejected_call_count = DB::table('et_call_tracker')
            ->where('customer_phone_no', $lead_mobile)        
            ->orWhere('customer_phone_no', $phoneWithCountryCode)                   // Filter by user ID
              ->whereYear('et_call_tracker.call_start_date', $year)
        ->whereMonth('et_call_tracker.call_start_date', $month)// End date filter
            
            ->where('et_call_tracker.call_status', 3)                             // Status is 3 for rejected calls
            ->count();

        // Assign the result to a variable
        $rejected_call_count = $rejected_call_count ?? 0;

        // Assign the result to a variable
        $missedcall_count = $missedcall_count ?? 0;

        $missed_call_ratio = 0;

        if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
            $total_calls = $incoming_call_count + $missedcall_count + $rejected_call_count;
            if ($total_calls > 0) {
                $missed_call_ratio = ($missedcall_count / $total_calls) * 100;
                $missed_call_ratio = $missed_call_ratio;
            } else {
                $missed_call_ratio = 0;
            }
        }

        $outgoing_call_ratio = 0;

        if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
            $total_calls_all = $incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count;
            if ($total_calls > 0) {
                $outgoing_call_ratio = ($outgoingcall_count / $total_calls_all) * 100;
                $outgoing_call_ratio = $outgoing_call_ratio;
            } else {
                $outgoing_call_ratio = 0;
            }
        }

        $calls = DB::table('et_call_tracker')->select('et_call_tracker.*','et_staff.staff_name')
            ->join('et_staff', 'et_staff.sno', '=', 'et_call_tracker.branch_staff_id')
            ->where('customer_phone_no', $lead_mobile)        
            ->orWhere('customer_phone_no', $phoneWithCountryCode)    ;            // Filter by user ID
         

            
        // Date Filtering
        if ($date_filter === "today") {
            $calls->whereDate('et_call_tracker.call_start_date', now()->toDateString());
        } elseif ($date_filter === "week") {
            $calls->whereBetween('et_call_tracker.call_start_date', [now()->startOfWeek(), now()->endOfWeek()]);
        } elseif ($date_filter === "monthly") {
            $calls->whereMonth('et_call_tracker.call_start_date', now()->month)
                ->whereYear('et_call_tracker.call_start_date', now()->year);
        } elseif ($date_filter === "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $calls->whereBetween('et_call_tracker.call_start_date', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]);
            } elseif ($from_date_filter) {
                $calls->where('et_call_tracker.call_start_date', '>=', Carbon::parse($from_date_filter));
            } elseif ($to_date_filter) {
                $calls->where('et_call_tracker.call_start_date', '<=', Carbon::parse($to_date_filter));
            }
        }else{
            $calls->where('et_call_tracker.call_start_date', '>=', $call_start_date) // Start date filter
            ->where('et_call_tracker.call_start_date', '<=', $call_end_date);
        }

        // return $status;
        if (isset($status) && $status !='0') {
            if ($status == '2') {
                $calls->whereIn('et_call_tracker.call_status', [2, 3]);
            } elseif ($status == '1') {
                $calls->where('et_call_tracker.call_status', $status);
            }
        } else {
            $calls->where('et_call_tracker.call_status', 0);
        }

        $calls = $calls->orderBy('et_call_tracker.sno', 'desc')->paginate($perpage);

        $filter = false;
       
        return view('content.sales.manage_calls.lead_call_history', [
            'calls'               => $calls,
            'status'               => $status,
            'perpage'             => $perpage,
            'caller'              => $caller,
            'incoming_call_count' => $incoming_call_count,
            'outgoingcall_count'  => $outgoingcall_count,
            'missedcall_count'    => $missedcall_count,
            'rejected_call_count' => $rejected_call_count,
            'missed_call_ratio'   => $missed_call_ratio,
            'outgoing_call_ratio' => $outgoing_call_ratio,
            'date_filter'         => $date_filter,
            'status_fill'         => $status_fill,
            'fin_yr_fill'         => $fin_yr_fill,
            'from_date_filter'    => $from_date_filter,
            'to_date_filter'      => $to_date_filter,
            'filter'              => $filter,
        ]);
    }
    //manage team
    public function Add(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $validator = Validator::make($request->all(), [
            'head_staff_add' => 'required|max:255',
            'memb_staff_add' => 'required|array', // Ensure this is an array for proper handling
        ]);
        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {
            $team_head_id   = $request->head_staff_add;
            $team_staff_ids = $request->memb_staff_add;
            $user_id        = $request->user()->user_id;

            $team_staff_ids = json_encode($team_staff_ids);

            $team_chk = ManageTeamModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (! $team_chk) {

                $year    = substr(date('y'), -2);
                $team_id = 'TMCL-0001/' . $year;
            } else {

                $data   = $team_chk->team_id;
                $slice  = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);

                $next_number = (int) $result + 1;
                $request     = sprintf('TMCL-%04d', $next_number);

                $year    = substr(date('y'), -2);
                $team_id = $request . '/' . $year;
            }

            $add_team                = new ManageTeamModel();
            $add_team->team_id       = $team_id;
            $add_team->team_head_id  = $team_head_id;
            $add_team->team_staff_id = $team_staff_ids;
            $add_team->branch_id     = $branch_id;
            $add_team->created_by    = $user_id;
            $add_team->updated_by    = $user_id;

            $add_team->save();

            if ($add_team) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type'    => 'success',
                    'message' => 'Team added Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type'    => 'error',
                    'message' => 'Could not add the Team!',
                ]);
            }

            return redirect('manage_calls');

        }
    }
    public function Update(Request $request, $teamId)
    {
        $branchId = $request->user()->branch_id;

        $validator = Validator::make($request->all(), [
            'head_staff_edit' => 'required|max:255',
            'memb_staff_edit' => 'required|array',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }

        $teamHeadId   = $request->head_staff_edit;
        $teamStaffIds = json_encode($request->memb_staff_edit);
        $userId       = $request->user()->user_id;

        // Find the team by ID
        $team = ManageTeamModel::where('team_id', $teamId)->where('branch_id', $branchId)->first();

        if (! $team) {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Team not found!',
            ]);
            return redirect('manage_calls');
        }

        // Update team details
        $team->team_head_id  = $teamHeadId;
        $team->team_staff_id = $teamStaffIds;
        $team->updated_by    = $userId;

        if ($team->update()) {
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'Team updated successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Could not update the team!',
            ]);
        }

        return redirect('manage_calls');
    }
    //staff_list
    public function StaffList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $dept_id   = $request->input('dept_id');
        $staff     = StaffModel::where('et_staff.status', '!=', 2)->join('et_team', 'et_staff.sno', '=', 'et_team.', 'left');
        // ->where('branch_id', $branch_id)
        if ($branch_id != 0) {
            $staff->where('et_staff.branch_id', $branch_id);
        }
        $staff = $staff->orderBy('et_staff.staff_name', 'asc')
            ->distinct() // Ensure unique rows
            ->get();

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $staff,
        ], 200);
    }

    public function getCallHistory(Request $request)
    {
        $leadId = $request->lead_id;
        $status = $request->status;


        $caller = DB::table('et_lead')->select('et_lead.*')
        ->where('et_lead.sno', $leadId)
        ->first();

        $lead_mobile =$caller->lead_mobile;
        $normalizedPhoneNo    = ltrim($lead_mobile, '0');   // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;
        // return $phoneWithCountryCode ;

       $calls = DB::table('et_call_tracker')
                ->select('et_call_tracker.*', 'et_staff.staff_name')
                ->join('et_staff', 'et_staff.sno', '=', 'et_call_tracker.branch_staff_id')
                ->where(function($query) use ($lead_mobile, $phoneWithCountryCode) {
                    $query->where('customer_phone_no', $lead_mobile)
                          ->orWhere('customer_phone_no', $phoneWithCountryCode);
                })
                ->where('count_status', 1);

                if ($status == "Incoming") {
                    $calls->where('et_call_tracker.call_status', 1);
                } elseif ($status == "Outgoing") {
                    $calls->where('et_call_tracker.call_status', 0);
                } elseif ($status == "Dialed") {
                    $calls->where('et_call_tracker.call_status', 4);
                } elseif ($status == "Missed & Rejected") {
                    $calls->whereIn('et_call_tracker.call_status', [2, 3]);
                }
                
                $calls = $calls->orderBy('et_call_tracker.sno', 'desc')->get();
          

        return response()->json([
            'calls' => $calls,
            'caller' => $caller,
            'status'=> $status,
        ]);
    }

    public function staffCallHistory(Request $request)
    {
        $staff_id = $request->staff_id;
        $year = $request->year;
        $month = $request->month;
    

        $caller = DB::table('et_staff')->select('et_staff.*')
        ->where('et_staff.sno', $staff_id)
        ->first();

        $calls = DB::table('et_call_tracker')->select('et_call_tracker.*')
            ->where('et_call_tracker.branch_staff_id', $staff_id)
            ->whereYear('et_call_tracker.call_start_date', $year)
            ->whereMonth('et_call_tracker.call_start_date', $month)
            ->orderBy('et_call_tracker.sno', 'desc')->get();  

        return response()->json([
            'calls' => $calls,
            'caller' => $caller,
        ]);
    }
    
    public function spamLeadConvertCalls(Request $request)
    {
        $converted_to = $request->lead_convert_to;
        $call_tracker_id = $request->cloud_call_id;
        $created_by = $request->sales_staff_add;
        $lead_name = $request->lead_name;
        $spam_reason = $request->spam_reason;
        $reason_text = $request->reason_text;
        $spam_comments = $request->spam_comments;
        // return $request;

        $cloud_call = CallTrackerModel::select('customer_phone_no', 'call_start_date')->where('sno', $call_tracker_id)->first();
        // return $cloud_call;

        if (strpos($cloud_call->customer_phone_no, '+91') === 0) {
            $country_code = '91';
            $lead_mobile = substr($cloud_call->customer_phone_no, 3); // Remove the '+91' part
        } else {
            $country_code = '';
            $lead_mobile = $cloud_call->customer_phone_no; // No country code
        }

        $registered_date    = date('Y-m-d', strtotime($cloud_call->call_start_date));
        $user_id            = $request->user()->user_id;
        $branch_id          = $request->user()->branch_id;
    
        // return $lead_mobile;

            $chk = LeadModel::where('lead_mobile', $lead_mobile)->where('et_lead.branch_id', $branch_id)->where('status', '!=', 2)->first();
            // return $chk;
            
            if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Mobile Number already created!'
            ]);
            } else {
                $branch_check = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
        
                $branch_code = $branch_check->city_short_code;
        
                $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                $year = date("Y");
                if (!$category_check) {
                    $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
                } else {
                    $data = $category_check->lead_id;
                    $slice = explode("/", $data);
                    $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number = (int)$resultcus + 1;
                    $request_pay = sprintf("LED%04d", $next_number);
                    $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
                }
    
                if($converted_to == 1){

                    $add_category = new LeadModel();
                    $add_category->lead_id                 = $lead_id;
                    $add_category->lead_name               = Ucfirst($lead_name);
                    $add_category->lead_mobile             = $lead_mobile;
                    $add_category->inter_calls             = $country_code;
                    $add_category->registered_date         = $registered_date;
                    $add_category->branch_id               = $branch_id;
                    $add_category->lead_source_id          = 1;
                    $add_category->call_tracker_id         = $call_tracker_id;
                    $add_category->created_by              = $created_by;
                    $add_category->updated_by              = $user_id;
                    $add_category->lead_status_id          = 1; 
                    $add_category->lead_condition          = 2; 

                    // return $add_category;
                    $add_category->save();
                    
                    if ($add_category) {
                        // return $add_category;
                        $add_history = new LeadTransferLogModel();
                        $add_history->lead_id = $add_category->sno;
                        $add_history->branch_id = $add_category->branch_id;
                        $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
                        $add_history->current_staff_id = $add_category->created_by;
                        $add_history->change_staff_id = 0;
                        $add_history->end_date = null;
                        $add_history->transferred_from = 10; // from Cloud Call
                        $add_history->created_by = $user_id;
                        $add_history->updated_by = $user_id;
                        // return $add_history;
                        $add_history->save();
                        
                    }
                    if ($add_category) {
                        session()->flash('toastr', [
                          'type' => 'success',
                          'message' => 'Lead added Successfully!'
                        ]);
                      } else {
                        session()->flash('toastr', [
                          'type' => 'error',
                          'message' => 'Could not add the Lead!'
                        ]);
                      }
                } else if($converted_to == 2){
                    $add_category = new LeadModel();
                    $add_category->lead_id                 = $lead_id;
                    $add_category->lead_name               = Ucfirst($lead_name);
                    $add_category->lead_mobile             = $lead_mobile;
                    $add_category->inter_calls             = $country_code;
                    $add_category->registered_date         = $registered_date;
                    $add_category->branch_id               = $branch_id;
                    $add_category->lead_source_id          = 1;
                    $add_category->call_tracker_id         = $call_tracker_id;
                    $add_category->created_by              = $created_by;
                    $add_category->updated_by              = $user_id;
                    $add_category->status                  = 7;
                    $add_category->lead_status_id          = 6;
                    $add_category->spam_verified           = 0;
                    $add_category->spam_tl_verified        = 0;
                    $add_category->lead_condition          = 2; 
                    if ($spam_reason == 1) {
                        $add_category->spam_reason = $request->reason_text;  // Set drop_reason from drop_reason_text
                     } else {
                       $spam = SpamReasonModel::where('reason_name', $spam_reason)->first();
                      // return $spam;
                       if ($spam->comments_check == 1) {
                         $add_category->spam_comments = $request->spam_comments;
                       }
                       $add_category->spam_reason = $spam_reason;
                    }
                    // return $add_category;
                    $add_category->save();
                    
                    if ($add_category) {
                        // return $add_category;
                        $add_history = new LeadTransferLogModel();
                        $add_history->lead_id = $add_category->sno;
                        $add_history->branch_id = $add_category->branch_id;
                        $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
                        $add_history->current_staff_id = $add_category->created_by;
                        $add_history->change_staff_id = 0;
                        $add_history->end_date = null;
                        $add_history->transferred_from = 11; // from Cloud Call Spam
                        $add_history->created_by = $user_id;
                        $add_history->updated_by = $user_id;
                        // return $add_history;
                        $add_history->save();
                    }
                    if ($add_category) {
                        session()->flash('toastr', [
                          'type' => 'success',
                          'message' => 'Spam Lead added Successfully!'
                        ]);
                      } else {
                        session()->flash('toastr', [
                          'type' => 'error',
                          'message' => 'Could not add the Lead!'
                        ]);
                      }
                }
        }

        return redirect('manage_calls');
    }

public function getCallHistoryPostSale(Request $request)
    {
        $leadId = $request->lead_id;
        $status = $request->status;
 
 
        $caller = DB::table('et_post_lead')->select('et_post_lead.*')
            ->where('et_post_lead.sno', $leadId)
            ->first();
 
        $lead_mobile = $caller->lead_mobile;
        $normalizedPhoneNo    = ltrim($lead_mobile, '0');   // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;
        // return $phoneWithCountryCode ;
 
        $calls = DB::table('et_call_tracker')
            ->select('et_call_tracker.*', 'et_staff.staff_name')
            ->join('et_staff', 'et_staff.sno', '=', 'et_call_tracker.branch_staff_id')
            ->where(function ($query) use ($lead_mobile, $phoneWithCountryCode) {
                $query->where('customer_phone_no', $lead_mobile)
                    ->orWhere('customer_phone_no', $phoneWithCountryCode);
            })
            ->where('count_status', 1);
 
        if ($status == "Incoming") {
            $calls->where('et_call_tracker.call_status', 1);
        } elseif ($status == "Outgoing") {
            $calls->where('et_call_tracker.call_status', 0);
        } elseif ($status == "Dialed") {
            $calls->where('et_call_tracker.call_status', 4);
        } elseif ($status == "Missed & Rejected") {
            $calls->whereIn('et_call_tracker.call_status', [2, 3]);
        }
 
        $calls = $calls->orderBy('et_call_tracker.sno', 'desc')->get();
 
 
        return response()->json([
            'calls' => $calls,
            'caller' => $caller,
            'status' => $status,
        ]);
    }


}
