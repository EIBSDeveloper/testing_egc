<?php

namespace App\Http\Controllers\lead_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\AppointmentModel;
use App\Models\BranchModel;
use App\Models\DropReasonModel;
use App\Models\LeadExportExcel;
use App\Models\LeadExportModel;
use App\Models\LeadModel;
use App\Models\LeadTransferLogModel;
use App\Models\RawLeadModel;
use App\Models\SpamReasonModel;
use App\Models\User;

use App\Models\StaffpointsModel;
use App\Models\LeadBankReasonModel;
use App\Models\ProductModel;
use Carbon\Carbon;
use DateTime;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;

class DailyCallLead extends Controller
{


  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    $entity_id = $request->user()->entity_id;

    // Filters
    $lead_fill = $request->input('lead_fill', '');

    $leads = LeadModel::select(
      'et_lead.sno',
      'et_lead.lead_id',
      'et_lead.transfer_status',
      'et_lead.is_hot_lead',
      'et_lead.created_at',
      'et_lead.created_by',
      'et_lead.dc_staff_id',
      'et_lead.inter_calls',
      'et_lead.registered_date',
      'et_lead.lead_mobile',
      'et_lead.dialed_count',
      'et_lead.document_send_count',
      'et_lead.incoming_count',
      'et_lead.outgoing_count',
      'et_lead.missed_reject_count',
      'et_lead.spam_verified',
      'et_lead.drop_verified',
      'et_lead.spam_tl_verified',
      'et_lead.drop_tl_verified',
      'et_lead.service_id',
      'et_lead.phone_verify_status',
      'et_lead.phone_verify_content',
      'et_lead.just_dial_id',
      'et_lead.cloud_call_id',
      'et_lead.website_id',
      'et_lead.call_tracker_id',
      'et_lead.lead_email_id',
      'et_lead.lead_gender',
      'et_lead.lead_dob',
      'et_lead.lead_answer',
      'et_lead.lead_marital_status',
      'et_lead_status.lead_bg_color',
      'et_staff.staff_name',
      'et_staff.nick_name',
      'et_lead.lead_score',
      'et_lead.status',
      'et_lead.lead_condition',
      'et_lead.lead_status_id',
      'et_lead.lead_name',
      'et_lead_type.lead_type_name',
      'et_lead_type.sno as lead_type_id',
      'et_lead_source.lead_source_name',
      'et_lead_source.sno as lead_source_id',
      'et_potential_type.potential_type_name as potential_type_name',
      'et_potential_type.potential_type_image',
      'et_lead.is_potential',
      'et_lead.potential_comments',
      'et_lead.potentail_reason',
      'appointment_counts.lead_id as followup_id',
      'latest_appointment.lead_id as latest_lead_id',
      'latest_appointment.appointment_date',
      'latest_appointment.lead_id as followup_latest_id',
      DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
      DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments')

    )
      ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
          SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
          FROM et_appointment
          WHERE (lead_id, appointment_date) IN (
              SELECT lead_id, MAX(appointment_date) AS appointment_date
              FROM et_appointment              
              GROUP BY lead_id
          )) AS latest_appointment'), 'et_lead.sno', '=', 'latest_appointment.lead_id')
      ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
          FROM et_appointment
          GROUP BY lead_id) AS appointment_counts'), 'et_lead.sno', '=', 'appointment_counts.lead_id')
      ->leftJoin('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
      ->leftJoin('et_lead_status', 'et_lead.lead_status_id', '=', 'et_lead_status.sno')
      ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
      ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
      ->leftJoin('et_potential_type', 'et_lead.lead_potential_type_id', '=', 'et_potential_type.sno')
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.is_dc', 1)
      ->where('et_lead.status', 0)
      ->where('lead_bank_status', '!=', 1);

    // Add groupBy
    $leads = $leads->groupBy(
      'et_lead.sno',
      'et_lead.lead_id',
      'et_lead.transfer_status',
      'et_lead.is_hot_lead',
      'et_lead.lead_mobile',
      'et_lead.created_at',
      'et_lead.incoming_count',
      'et_lead.dialed_count',
      'et_lead.created_by',
      'et_lead.dc_staff_id',
      'et_lead.outgoing_count',
      'et_lead.missed_reject_count',
      'et_lead.spam_verified',
      'et_lead.drop_verified',
      'et_lead.spam_tl_verified',
      'et_lead.drop_tl_verified',
      'et_lead.document_send_count',
      'et_lead.phone_verify_status',
      'et_lead.phone_verify_content',
      'et_lead.just_dial_id',
      'et_lead.cloud_call_id',
      'et_lead.website_id',
      'et_lead.call_tracker_id',
      'et_lead.registered_date',
      //   'et_lead_appointment.appointment_status',
      //   'et_lead_appointment.lead_id',
      'et_lead.lead_email_id',
      'et_lead.service_id',
      'et_lead.lead_gender',
      'et_lead.lead_dob',
      'et_lead.inter_calls',
      'et_lead.lead_answer',
      'et_lead.lead_marital_status',
      'et_lead_status.lead_bg_color',
      'et_staff.staff_name',
      'et_staff.nick_name',

      // 'assignstaff.staff_name',
      // 'assignstaff.nick_name',
      'et_lead.lead_score',

      'et_lead.status',
      'et_lead.lead_condition',
      'et_lead.lead_status_id',
      'et_lead.lead_name',
      'et_lead_type.lead_type_name',
      'et_lead_type.sno',
      'et_lead_source.lead_source_name',
      'et_lead_source.sno',
      'latest_appointment.appointment_date',
      'latest_appointment.total_app_score',
      'et_potential_type.potential_type_name',
      'et_potential_type.potential_type_image',
      'et_lead.potential_comments',
      'et_lead.is_potential',
      'et_lead.potentail_reason',
      'appointment_counts.lead_id',
      'latest_appointment.lead_id',
      'appointment_counts.total_appointments'
    );
    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    $leads = $leads->orderBy('et_lead.spam_verified', 'asc')->paginate($perpage);

    $follwup_count = 0;
    $not_follow_up_ids = [];
    foreach ($leads as $singleLead) {
      $createdAt       = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      $chk1day         = $createdAt->diffInHours($currentDateTime) >= 24;

      if ($chk1day) {
        // Increment only if follow-up IDs do not exist
        if (!$singleLead->followup_latest_id && !$singleLead->followup_id) {
          $follwup_count++;
          $not_follow_up_ids[] = $singleLead->sno;
        }
      }

      $normalizedPhoneNo    = ltrim($singleLead->lead_mobile, '0'); // Remove leading zero if present
      $phoneWithCountryCode = '+91' . $normalizedPhoneNo;           // Add the country code

      $proposal_list = DB::table('et_proposal')->where('status', 0)->where('lead_id', $singleLead->sno)->orderBy('sno', 'desc')->get();
      foreach ($proposal_list as $proposal) {
        $helper = new \App\Helpers\Helpers();
        $encrypted_values = $helper->encrypt_decrypt($proposal->sno, 'encrypt');
        $proposal->encrypt_id = $encrypted_values;
      }

      $singleLead->proposal_list = $proposal_list;

      if ($singleLead->service_id) {
        $service_ids = json_decode($singleLead->service_id);

        if (is_array($service_ids) && count($service_ids) > 0) {
          $product_data = ProductModel::select('et_product.product_name', 'et_product_category.product_category_name')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->whereIn('et_product.sno', $service_ids)
            ->get();

          $singleLead->productsData = $product_data;
        } else {
          $singleLead->productsData = collect();  // empty collection if no valid service ids
        }
      }



      $singleLead->staff_id = $lead->staff_id ?? "0";
      $lead                 = DB::table('et_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $leadapp = DB::table('et_lead_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $singleLead->lead_appointment_status = $leadapp->appointment_status ?? "0";
      $singleLead->appointment_lead_id = $leadapp->lead_id ?? "0";
      $singleLead->appointment_status = $lead->status ?? "0";
      $chk1day         = false;
      $createdAt       = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      if ($createdAt->diffInHours($currentDateTime) >= 24) {
        $chk1day = true;
      } else {
        $chk1day = false;
      }
      $alert_status = 0;
      if ($chk1day) {
        if ($singleLead->followup_latest_id) {
          $alert_status = 0;
        } else if ($singleLead->followup_id) {
          $alert_status = 0;
        } else {
          $alert_status = 1;
        }
      }

      $singleLead->alert_status = $alert_status;
      $registeredDate = Carbon::parse($singleLead->registered_date);
      $diff = $registeredDate->diff(Carbon::now());

      $years = $diff->y;
      $months = $diff->m;
      $days = $diff->d;

      // Build the formatted difference string
      $parts = [];

      if ($years > 0) {
        $parts[] = "{$years} year" . ($years > 1 ? 's' : '');
      }
      if ($months > 0) {
        $parts[] = "{$months} month" . ($months > 1 ? 's' : '');
      }
      if ($days > 0 || empty($parts)) {
        // If all other parts are zero, still show "0 days"
        $parts[] = "{$days} day" . ($days > 1 ? 's' : '');
      }

      $singleLead->formattedDifference = implode(' and ', $parts);
      $singleLead->formattedDayDifference = $days;
    }

    $reasonList_lead_bank = LeadBankReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();



    // return $leads;
    return view('content.lead_management.manage_lead.daily_calls_list', compact(
      'leads',
      'perpage',
      'lead_fill',
      'reasonList_lead_bank'
    ));
  }
  public function Appointment(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'appointment_date' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      // return $request;
      $lead_id                  = $request->lead_id;
      // $appointment_date         = $request->appointment_date;
      $appointment_time         = $request->appointment_time;

      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);

      $user_id            = $request->user()->user_id;
      $branch_id          = $request->user()->branch_id;


      $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


      if (!$category_check) {

        $year = substr(date("y"), -2);
        $appointment_id = "AP-0001/" . $year;
      } else {

        $data = $category_check->appointment_id;
        $slice = explode("/", $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int)$result + 1;
        $request = sprintf("AP-%04d", $next_number);

        $year = substr(date("y"), -2);
        $appointment_id = $request . '/' . $year;
      }


      $add_category = new AppointmentModel();
      $add_category->appointment_id          = $appointment_id;
      $add_category->lead_id                 = $lead_id;
      $add_category->appointment_date        = $appointment_date;
      $add_category->appointment_time        = $appointment_time;
      $add_category->branch_id               = $branch_id;
      $add_category->status                  = 1;
      $add_category->created_by              = $user_id;
      $add_category->updated_by              = $user_id;

      $add_category->save();
      if ($add_category) {
        $LeadData =  LeadModel::where('sno', $lead_id)->first();
        $LeadData->lead_status_id   = 2; //followup lead
        // $LeadData->drop_verified    = 0;
        // $LeadData->drop_tl_verified = 0;
        // $LeadData->spam_verified    = 0;
        // $LeadData->spam_tl_verified = 0;
        // $LeadData->internal_status  = 0;
        // $LeadData->transfer_status  = 1;
        // $LeadData->potential_verify = 0;
        // $LeadData->is_potential     = 0;
        // $LeadData->is_dc            = 0;
        $LeadData->update();
      }

      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Appointment added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Appointment!'
        ]);
      }
      // }
      // return $result;
      return redirect('/daily_call_lead');
    }
  }
  public function add_appointment_daily_update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'appointment_date' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      // return $request;
      $lead_id            = $request->lead_id;
      $appointment_time   = $request->appointment_time;
      $appointment_date   = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
      $user_id            = $request->user()->user_id;
      $branch_id          = $request->user()->branch_id;
      $category_check     = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$category_check) {
        $year = substr(date("y"), -2);
        $appointment_id = "AP-0001/" . $year;
      } else {
        $data = $category_check->appointment_id;
        $slice = explode("/", $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int)$result + 1;
        $request = sprintf("AP-%04d", $next_number);
        $year = substr(date("y"), -2);
        $appointment_id = $request . '/' . $year;
      }
      $add_category = new AppointmentModel();
      $add_category->appointment_id          = $appointment_id;
      $add_category->lead_id                 = $lead_id;
      $add_category->appointment_date        = $appointment_date;
      $add_category->appointment_time        = $appointment_time;
      $add_category->branch_id               = $branch_id;
      $add_category->status                  = 1;
      $add_category->created_by              = $user_id;
      $add_category->updated_by              = $user_id;
      $add_category->save();
      if ($add_category) {
        $lead =  LeadModel::where('sno', $lead_id)->first();
        $lead->lead_status_id          = 2; //followup lead
        $lead->update();
      }

      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Appointment added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Appointment!'
        ]);
      }
      return redirect('lead_management/potential_lead');
    }
  }
}
