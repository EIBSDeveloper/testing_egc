<?php

namespace App\Http\Controllers\product_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FacilityModel;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Validator;


class Manage_facility extends Controller
{
  public function index(Request $request)
  {
    $entity_id   = $request->user()->entity_id;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $lead_grp_fill = $request->lead_grp_fill ?? '';
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
      $Facility = FacilityModel::where('status', '!=', 2)->orderBy('sno', 'desc')->where('et_facility.branch_id', $branch_id);
      if ($lead_grp_fill  != '') {
        $Facility->where(function ($query) use ($lead_grp_fill) {
          $query->where('et_facility.facility_name', 'LIKE', "%{$lead_grp_fill}%")
            ->orWhere('et_facility.duration', 'LIKE', "%{$lead_grp_fill}%")
            ->orWhere('et_facility.duration_in', 'LIKE', "%{$lead_grp_fill}%");

        });
      }
      $Facility = $Facility->orderBy('et_facility.sno', 'desc')->paginate($perpage);
      // return $Facility;
      return view('content.product_management.manage_facility.list', [
          'ListTable' => $Facility,
          'perpage' => $perpage,
          'lead_grp_fill' => $lead_grp_fill,

      ]);
  }
  public function Status($id, Request $request)
  {

      $upd_DepartmentModel = FacilityModel::where('sno', $id)->first();
      $upd_DepartmentModel->status = $request->input('status', 0);
      $upd_DepartmentModel->update();
      if ($upd_DepartmentModel) {
          return response([
              'status' => 200,
              'message' => 'Successfully Status Updated!',
              'error_msg' => null,
              'data' => null,
          ], 200);
      } else {
          return response([
              'status' => 400,
              'message' => 'Successfully Status Updated!',
              'error_msg' => null,
              'data' => null,
          ], 400);
      }
  }
  public function Add(Request $request)
  {
      //return $request;
      $validator = Validator::make($request->all(), [
          'facility_name' => 'required|max:255'
      ]);
      if ($validator->fails()) {
          return response([
              'status' => 401,
              'message' => 'Incorrect format input feilds',
              'error_msg' => $validator->messages()->get('*'),
              'data' => null,
          ], 200);
      } else {

          $company_name = $request->facility_name;
          $company_dur = $request->duration;
          $company_durin = $request->duration_in;


          $user_id   = $request->user()->user_id;
          $branch_id = $request->user()->branch_id;
          $chk = FacilityModel::where('facility_name', ucwords($company_name))->where('status', '!=', 2)->first();

          if ($chk) {

              session()->flash('toastr', [
                  'type' => 'error',
                  'message' => 'Facility Name already exists!'
              ]);
              return redirect()->back();
          } else {
              $category_check = FacilityModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

              if (!$category_check) {

                  $year = substr(date('y'), -2);
                  $company_id = 'FAC-0001/' . $year;
              } else {

                  $data = $category_check->company_id;
                  $slice = explode('/', $data);
                  $result = preg_replace('/[^0-9]/', '', $slice[0]);

                  $next_number = (int) $result + 1;
                  $request = sprintf('FAC-%04d', $next_number);

                  $year = substr(date('y'), -2);
                  $company_id = $request . '/' . $year;
              }

              $add_company = new FacilityModel();

              $add_company->facility_name = Ucfirst($company_name);
              $add_company->duration = $company_dur;
              $add_company->duration_in = $company_durin;
              $add_company->facility_id = $company_id;

             $add_company->branch_id  = $branch_id;
              $add_company->created_by = $user_id;
              $add_company->updated_by = $user_id;

              $add_company->save();

              if ($add_company) {
                  // If category added successfully, return success response and display Toastr message
                  session()->flash('toastr', [
                      'type' => 'success',
                      'message' => 'Facility added Successfully!'
                  ]);
              } else {
                  session()->flash('toastr', [
                      'type' => 'error',
                      'message' => 'Could not add the Facility!'
                  ]);
              }
          }
          return redirect()->back();
      }
  }
  public function Update(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'edit_facilityname' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->edit_facilityname;

            $company_dur = $request->edit_duration;
            $company_durin = $request->edit_durationin;
            $sno = $request->edit_id;
            $chk = FacilityModel::where('facility_name', ucwords($company_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();
            $user_id   = $request->user()->user_id;

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Facility Name already exists!'
                ]);
                return redirect()->back();
            } else {
                $upd_CompanyTypeModel = FacilityModel::where('sno', $sno)->first();
                $upd_CompanyTypeModel->facility_name = Ucfirst($company_name);
                $upd_CompanyTypeModel->duration = $company_dur;
                $upd_CompanyTypeModel->duration_in = $company_durin;
                 $upd_CompanyTypeModel->updated_by = $user_id;
                $upd_CompanyTypeModel->update();

                if ($upd_CompanyTypeModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Facility Updated Successfully !'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Facility!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Edit($id)
    {
        $knowledge = FacilityModel::where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $knowledge
        ], 200);
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = FacilityModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function checkDuplicatesFacility(Request $request)
    {
        $field = $request->field;
        $value = $request->value;
        $currentSno = $request->sno;

        $query = DB::table('et_facility')->where($field, $value);

        if (!empty($currentSno)) {
            $query->where('sno', '!=', $currentSno);
        }

        $exists = $query->exists();

        return response()->json([
            'exists' => $exists,
            'message' => $exists ? ucfirst(str_replace('_', ' ', $field)) . ' already exists.' : ''
        ]);
    }



}
//content.product_management.manage_facility.list
