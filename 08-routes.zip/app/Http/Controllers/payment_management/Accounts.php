<?php

namespace App\Http\Controllers\payment_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Razorpay\Api\Api;
use Illuminate\Support\Facades\Log;
use App\Models\CustomerModel;
use App\Models\SubLedgerModel;
use App\Models\TransactionModel;
use Illuminate\Support\Facades\Http;
use App\Models\BranchModel;
use App\Models\StaffModel;
use App\Models\ProductModel;
use App\Models\ManageProductVaiantModel;
use App\Models\ManageProductVariableModel;
use App\Mail\ETPLMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\LeadModel;
use App\Models\SmsTemplateModel;
use Carbon\Carbon;
use PDF;
use Illuminate\Pagination\LengthAwarePaginator;


class Accounts extends Controller
{
  
  protected $razorpayKey;
  protected $razorpaySecret;

  public function __construct()
  {
    $this->razorpayKey = 'rzp_live_1UWaj2nifGd7hH';
    $this->razorpaySecret = 'EK3odrpKfO9EiK7k0aRxuKBP';
    // $this->razorpayKey = 'rzp_test_cjiZ7kyueJCUGb';
    // $this->razorpaySecret = 'fG0zEeXUiJKNbggEKRhsJf0k';
  }
  
  
  
   public function manage_accounts(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $user_id   = $request->user()->user_id ;
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      
      $search_fill = $request->search_fill ?? '';
      $month_filter = $request->get('month_filter', ''); 
    // Base query for customers joined with lead, excluding status=2
    $customersQuery = DB::table('et_transaction')
        ->select('et_customer.*','et_transaction.payment_id','et_transaction.payment_status','et_transaction.daily_acc_chk','et_payment.payment_type as offline_payment_mode','et_payment.offline_transaction_id','et_transaction.total_amount_inr as paid_amount_inr','et_transaction.sno as trans_sno','et_proposal.proposal_id','et_proposal.gst_perc','et_proposal.gst_inclusive','et_transaction.invoice_id','et_payment.pay_slot_id','et_payment.payment_mode','et_payment.paid_amount','et_transaction.transaction_id','et_payment.proposal_id as proposal_sno','et_subledger.subledger_name','et_payment.transaction_date','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
        ->join('et_payment', 'et_payment.sno', '=', 'et_transaction.payment_id')
        ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
         ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->join('et_subledger', 'et_subledger.payment_sno', '=', 'et_payment.sno')
        ->join('et_customer', 'et_customer.sno', '=', 'et_transaction.customer_id')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_customer.status', '!=', 2)
        ->where('et_lead.status', '!=', 2);
        
        if($user_id != 0){
            $customersQuery=$customersQuery->where('et_lead.created_by','>',1);
        }
        
       
        
       $customersQuery=$customersQuery ->where('et_transaction.customer_type', 0)
        ->where('et_customer.branch_id', $branch_id)
        ->where('et_transaction.status', 0);

    if (!empty($search_fill)) {
        $customersQuery->where(function ($query) use ($search_fill) {
            $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
        });
    }
    
     if (!empty($month_filter)) {
            try {
                $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
                $month = $parsedDate->month;
                $year  = $parsedDate->year;
        
                $customersQuery->whereYear('et_payment.transaction_date', $year)
                               ->whereMonth('et_payment.transaction_date', $month);
            } catch (\Exception $e) {
              return redirect('/manage_accounts');
            }
        }
    
    

    $customers = $customersQuery->orderBy('et_transaction.sno', 'desc')
        ->paginate($perpage);
        // return $perpage;
        foreach($customers as $cus){
           $gst_rate= $cus->gst_perc/100;
           $tax_amount= $cus->paid_amount * $gst_rate;
           $cus->tax_amount=$tax_amount;
        }
        
        $helper = new \App\Helpers\Helpers();
        $total_collection = 0;
        $total_collection_gst = 0;
        $total_collection_net = 0;
        $verified_collection = 0;
        $verified_collection_gst = 0;
        $verified_collection_net = 0;
        
        if($user_id ==0){
            $customerPay = DB::table('et_transaction')
                ->select('et_customer.*','et_transaction.payment_id','et_transaction.payment_status','et_transaction.daily_acc_chk','et_payment.payment_type as offline_payment_mode','et_payment.offline_transaction_id','et_transaction.total_amount_inr as paid_amount_inr','et_transaction.sno as trans_sno','et_proposal.proposal_id','et_proposal.gst_perc','et_proposal.gst_inclusive','et_transaction.invoice_id','et_payment.pay_slot_id','et_payment.payment_mode','et_payment.paid_amount','et_transaction.transaction_id','et_payment.proposal_id as proposal_sno','et_subledger.subledger_name','et_payment.transaction_date','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
                ->join('et_payment', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                 ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_subledger', 'et_subledger.payment_sno', '=', 'et_payment.sno')
                ->join('et_customer', 'et_customer.sno', '=', 'et_transaction.customer_id')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->where('et_customer.status', '!=', 2)
                ->where('et_lead.created_by','>',1)
                ->where('et_lead.status', '!=', 2);
                
               $customerPay=$customerPay ->where('et_transaction.customer_type', 0)
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_transaction.status', 0);
        
                if (!empty($search_fill)) {
                    $customerPay->where(function ($query) use ($search_fill) {
                        $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                            ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                            ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                            ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
                    });
                }
                if (!empty($month_filter)) {
                    try {
                        $parsedDate = Carbon::createFromFormat('!M-Y', $month_filter);
                        $month = $parsedDate->month;
                        $year  = $parsedDate->year;
                
                        $customerPay->whereYear('et_payment.transaction_date', $year)
                                       ->whereMonth('et_payment.transaction_date', $month);
                    } catch (\Exception $e) {
                      return redirect('/manage_accounts');
                    }
                }
            $customerPay = $customerPay->orderBy('et_transaction.sno', 'desc')
                ->get();
                
                 foreach ($customerPay as $cus) {
                    $gstRate = $cus->gst_perc > 0 ? $cus->gst_perc/100 : 0;
                    $netAmount = $cus->paid_amount / (1 + $gstRate);
                    $gstAmount = $cus->paid_amount - $netAmount;
            
                    if ($cus->paid_amount_inr) {
                        $convertedPaidAmountInr = $cus->paid_amount_inr;
                        $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
                        $gstAmountInr = $convertedPaidAmountInr - $netAmountInr;
                    } else {
                        $convertedPaidAmountInr = $helper->ConvertedAmountInr($cus->currency_code, $cus->paid_amount);
                        $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
                        $gstAmountInr = $convertedPaidAmountInr - $netAmountInr;
                    }
                    // Add to totals
                    $total_collection += $convertedPaidAmountInr;
                    $total_collection_gst += $gstAmountInr;
                    $total_collection_net += $netAmountInr;
                    // Verified only
                    if ($cus->payment_status == 1) {
                        $verified_collection += $convertedPaidAmountInr;
                        $verified_collection_gst += $gstAmountInr;
                        $verified_collection_net += $netAmountInr;
                    }
                }
        }
        
    // return $customers;
    return view('content.payment_management.manage_accounts.list',[
            'customers' => $customers,
            'search_fill' => $search_fill,
            'perpage' => $perpage,
            'total_collection' => $total_collection,
            'total_collection_gst' => $total_collection_gst,
            'total_collection_net' => $total_collection_net,
            'verified_collection' => $verified_collection,
            'verified_collection_gst' => $verified_collection_gst,
            'verified_collection_net' => $verified_collection_net,
            'month_filter' => $month_filter,
        ]);
  }
    
   public function payment_accounts_status_change(Request $request)
  {
    $id = $request->sts_change_id;
    $sts = $request->sts_change_type;
    $customer_id = $request->customer_id_hidden;
    $proposal_id = $request->proposal_id_hidden;
    $slot_id = $request->slot_id_hidden;
      $payment_id = $request->payment_id_hidden;
      $user_id   = $request->user()->user_id ;
    
      //   return $request;
        $helper = new \App\Helpers\Helpers();
        // Find the record
        $OldCustomerModel = TransactionModel::where('sno', $id)->select('sno', 'payment_status')->first();
        

        if ($OldCustomerModel) {

          $OldCustomerModel->daily_acc_chk = $sts;
          $OldCustomerModel->daily_acc_chk_by = $user_id;
          $OldCustomerModel->update(); 
          
          // return $OldCustomerModel;
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Successfully Status Updated!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update Status!'
          ]);
        }
    return redirect('/manage_accounts');
  }




        public function shortenUrl($longUrl,$channelId)
        {
            $response = Http::withToken('aFLQFlykraqpANsi')
                ->post('https://chotta.link/api/url/add', [
                    'url' => $longUrl
                ]);
        
            if ($response->successful() && isset($response['shorturl'])) {
                
                $shortUrl = $response['shorturl'];
                $urlId =$response['id'];
                
                $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

                $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);
        
                if ($assignResponse->successful()) {
                    return $response; // success
                }
            }
            
        
            return null;
        }
        
        private function sendRequestToWhatsApp($url, $token, $data)
      {
        try {
          $client = new \GuzzleHttp\Client();
          $response = $client->post($url, [
            'headers' => [
              'Authorization' => 'Bearer ' . $token,
              'Content-Type' => 'application/json',
            ],
            'json' => $data,
          ]);
    
          return [
            'status' => $response->getStatusCode(),
            'data' => json_decode($response->getBody(), true),
          ];
        } catch (\Exception $e) {
          return [
            'status' => 400,
            'error' => $e->getMessage(),
          ];
        }
      }
      
      
  
 
  
  
   public function ReceiptPrint($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $slot_id_decrpt =$decryptedValue;
   
    
     $slotData = DB::table('et_proposal_pay_slot')
                 ->select('et_proposal_pay_slot.*','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id','et_transaction.transaction_id','et_transaction.payment_id as pay_sno')
                   ->join('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
                   ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_proposal_pay_slot.sno', $slot_id_decrpt)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->orderBy('et_transaction.sno','desc')
                    ->first();
    $transaction_id=$slotData->transaction_id;
    
     $paymentHistory = DB::table('et_payment')
        ->select('et_payment.paid_amount','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id','et_transaction.transaction_id','et_payment.razor_fee')
        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
        ->where('et_payment.proposal_id', $slotData->proposal_sno)
        ->where(function($q) use ($slotData) {
            $q->where('et_payment.sno', '<=', $slotData->pay_sno); // current + previous
        })
        ->orderBy('et_payment.sno', 'asc')
        ->get();
    $total_paid=0;
    foreach ($paymentHistory as $pay) {
        $amount = $pay->paid_amount;
        // if ($pay->payment_mode == 1) {
        //     $amount -= $pay->razor_fee;
        //     $pay->paid_amount=$pay->paid_amount -$pay->razor_fee;
        // }
    
        $total_paid += $amount;
    }
     
    $slotProp = DB::table('et_proposal_pay_slot')
                    ->where('proposal_sno', $slotData->proposal_sno)
                    ->where('status', 0)
                    ->get();
    $paidAmount=$slotProp->sum('paidAmount');
    $balance_amount =   $slotData->total_amount  > 0 ? $slotData->total_amount -$paidAmount : 0;
    $user_id= $request->user()->user_id ?? 0;
    // if($user_id==0){
    //   return  $slotData->total_amount;
    // }
    $slotData->due_amount =$balance_amount;
    
     $prps_id =$slotData->proposal_sno;
    

      $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol','et_payment.invoice_id','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id')
                 ->where('et_proposal.sno',$prps_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
                 
            if($proposal){
                if($proposal->post_sale_check==1){
                    $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                    $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                    $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                }
            }

           $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $proposal->branch_id)
            ->first();

        

          $proposal->door_no =$branch_data->door_no ;
          $proposal->area_street = $branch_data->area_street ;
          $proposal->city_name =  $branch_data->city_name ;
          $proposal->state_name =  $branch_data->state_name ;
          $proposal->country_name =  $branch_data->country_name ;
          $proposal->pincode =  $branch_data->pincode ;
          $proposal->branch_mail =  $branch_data->mail ;
          $proposal->branch_mobile =  $branch_data->mobile ;
          $proposal->gst_no =  $branch_data->gst_no ?? "-" ;


           $lead_data = DB::table('et_lead')
            ->select(
                'et_lead.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
            ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
            ->where('et_lead.sno', $proposal->lead_id)
            ->first();

          $customer =DB::table('et_customer')
                ->select('et_customer.*',
                 'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
                )
                 ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
                ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
                ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
                 ->where('et_customer.sno',$proposal->customer_id)
                 ->where('et_customer.status','!=',2)
                 ->orderBy('et_customer.sno', 'desc')
                 ->first();

            $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
            $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
            $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
            $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
            $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
            $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
            $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
            $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
            $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';

            
      if($proposal->discount_id >0){
        $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$proposal->discount_id)->first();

        $proposal->discount_value=$discount->coupon_value ;
        $proposal->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
      }
      
      $domain_ids = json_decode($proposal->domain_ids ?? '[]', true);

            $domain_names = DB::table('et_domain')
                ->where('et_domain.status', 0)
                ->whereIn('sno', $domain_ids)
                ->pluck('domain_name')  // Get only domain_name column
                ->toArray();            // Convert Collection to array
            
            $domain_list = implode(', ', $domain_names);
    
       
          $proposal->domain_names=$domain_list;

      // return $proposal;
      $proposal->products=[];
      $packages='';
    
    if($proposal->product_package == 1){

       $proposalProduct = DB::table('et_proposal_product_cart')
                          ->select('et_proposal_product_cart.*','et_product.product_name','et_product_category.product_category_name')
                          ->where('et_proposal_product_cart.status',0)
                          ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
                          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
                          ->where('et_proposal_product_cart.proposal_id',$proposal->proposal_id)
                          ->get();
       
         $groupedProducts = [];
            $allSlotIds = [];
            foreach ($proposalProduct as $product) {
                $product_id = $product->product_id;
                $cart_id = $product->cart_id;
            
                // Shared data fetched once per product_id
                if (!isset($groupedProducts[$product_id])) {
                    $product_data = ProductModel::select('et_product.*')
                        ->where('et_product.sno', $product_id)->first();
            
                    $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
                    $tools_ids = is_array($tools_ids) ? $tools_ids : [];
            
                    $tools = DB::table('et_product_tools')
                        ->whereIn('sno', $tools_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('product_tools_name')
                        ->toArray();
            
                    $base_product = clone $product; // Copy to modify
                    $base_product->tools_name = $tools;
                    $base_product->product_name = $product->product_name;
                    $base_product->product_category_name = $product->product_category_name;
                    $base_product->cart_variants = [];
                    $base_product->cart_slots = [];
                    $base_product->total_amount_cart = 0;
                    $base_product->product_amount = 0;
            
                    $groupedProducts[$product_id] = $base_product;
                }
            
                // Compute variant data per cart
                $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
                $variable_amount = 0;
                $variant_names = [];
                $product_variant_name = '';
                $variable_name = '';
            
                foreach ($variant_variable_ids as $pair) {
                    $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
                    $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
            
                    if ($variant_id) {
                        $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
                        $product_variant_name = $get_variant->product_variant_name ?? '';
                    }
            
                    if ($variable_id) {
                        $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
                        if ($get_variables) {
                            $variable_name = $get_variables->variable_name;
                            $variable_amount += $get_variables->variable_amount;
                        }
                    }
            
                    if ($product_variant_name && $variable_name) {
                        $variant_names[] = "{$product_variant_name} - {$variable_name}";
                    } elseif ($product_variant_name) {
                        $variant_names[] = $product_variant_name;
                    }
                }
           
                // $cart_total = $variable_amount + $product_data->base_price;
                $cart_total = $product->product_amount;
                $groupedProducts[$product_id]->total_amount_cart += $cart_total;
            
                // Add cart-specific variant names
                $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
                $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;

            
                // Fetch slots for this cart
                $slots = DB::table('et_proposal_pay_slot')
                    ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
                    ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                    ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->get();
                    
                $slotCount=count($slots);
                
                foreach ($slots as $slot) {
                    $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
                    if (!in_array($cart_id, $slot_cart_ids)) {
                        continue;
                    }
            
                    $groupedProducts[$product_id]->product_amount += $slot->slot_amount;
            
                    $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
                    $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);
            
                    $deliverable_items = $deliverables_map[$cart_id] ?? [];
                    $slot_notes_items = $slot_notes_map[$cart_id] ?? [];
            
                    $deliverable_ids = [];
                    foreach ($deliverable_items as $d) {
                        if (($d['status'] ?? '0') == '0') {
                            $deliverable_ids[] = $d['value'];
                        }
                    }
            
                    $slot_notes_ids = [];
                    foreach ($slot_notes_items as $s) {
                        if (($s['status'] ?? '0') == '0') {
                            $slot_notes_ids[] = $s['value'];
                        }
                    }
            
                     $deliverable_ids = array_filter($deliverable_ids); // Ensure no empty values

                        if (count($deliverable_ids) > 0) {
                            $deliverables = DB::table('et_product_delivarables')
                                ->whereIn('sno', $deliverable_ids)
                                ->where('status', 0)
                                ->orderByRaw('FIELD(sno, ' . implode(',', $deliverable_ids) . ')')
                                ->pluck('delivarable_name', 'sno');
                        } else {
                            // Handle case where $deliverable_ids is empty
                            $deliverables = collect(); // Return an empty collection or handle accordingly
                        }
            
                    $slot_notes = DB::table('et_slot_notes')
                        ->whereIn('sno', $slot_notes_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('slot_notes_name');
            
                    // Assign deliverables and notes for this cart
                    $slot->deliverables = $deliverables;
                    $slot->slot_notes = $slot_notes;
            
                     if (!isset($groupedProducts[$product_id]->cart_slots)) {
                            $groupedProducts[$product_id]->cart_slots = [];
                        }
                        
                        // Find if the slot already exists in the array
                        $existingIndex = null;
                        foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
                            if ($existingSlot['sno'] === $slot->sno) {
                                $existingIndex = $index;
                                break;
                            }
                        }
                        
                        if ($existingIndex === null) {
                            // Add new slot entry
                            $groupedProducts[$product_id]->cart_slots[] = [
                                'sno' => $slot->sno,
                                'propo_pay_slot_id' => $slot->propo_pay_slot_id,
                                'branch_id' => $slot->branch_id,
                                'lead_id' => $slot->lead_id,
                                'proposal_id' => $slot->proposal_id,
                                'proposal_sno' => $slot->proposal_sno,
                                'product_cart_id' => $slot->product_cart_id,
                                'package_id' => $slot->package_id,
                                'slot_id' => $slot->slot_id,
                                'slot_amount' => $slot->slot_amount,
                                'payable_amount' => $slot->payable_amount,
                                'paidAmount' => $slot->paidAmount,
                                'gst_amount' => $slot->gst_amount,
                                'balance_amount' => $slot->balance_amount,
                                'total_amount' => $slot->total_amount,
                                'slot_description' => $slot->slot_description,
                                'created_by' => $slot->created_by,
                                'created_at' => $slot->created_at,
                                'updated_by' => $slot->updated_by,
                                'updated_at' => $slot->updated_at,
                                'status' => $slot->status,
                                'due_date' => $slot->due_date,
                                'link_status' => $slot->link_status,
                                'paid_status' => $slot->paid_status,
                                'invoice_id' => $slot->invoice_id,
                                'temp_send_link' => $slot->temp_send_link,
                                'old_customer_check' => $slot->old_customer_check,
                                'send_status' => $slot->send_status,
                                'receipt_temp_link' => $slot->receipt_temp_link,
                                'receipt_send_status' => $slot->receipt_send_status,
                                'payment_slot_name' => $slot->payment_slot_name,
                                'start_deliver_work' => $slot->start_deliver_work,
                                'deliverables' => [
                                    (string)$cart_id => $deliverables->toArray()
                                ],
                                'slot_notes' => [
                                    (string)$cart_id => $slot_notes->toArray()
                                ]
                            ];
                        } else {
                            // Slot already exists — just append deliverables and slot_notes for this cart
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
                        }


                }
                
            //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

            }
            
            // Set the grouped products
            $proposal->products = array_values($groupedProducts);
            $proposal->slotCount=$slotCount;
       
    }else{

      $package_data = DB::table('et_package')
                    ->select('et_package.*')
                    ->join('et_proposal', 'et_proposal.package_id', '=', 'et_package.sno')
                    ->where('et_package.status',0)
                    ->where('et_package.sno', $proposal->package_id)
                    ->first();
    $package_cart = DB::table('et_proposal_package_cart')
            ->select('variant_variable_ids','cust_product_amount')
            ->where('status', 0)
            ->where('proposal_sno', $proposal->sno)
            ->get();
                
                    $packageTotal = 0;
                    $packageTotalCart = 0;
                    
                    foreach ($package_cart as $item) {
                        $variants = json_decode($item->variant_variable_ids, true); // decode as array
                            $packageTotalCart +=$item->cust_product_amount;
                        if (is_array($variants)) {
                            foreach ($variants as $variant) {
                                if (isset($variant['amount'])) {
                                    $packageTotal += $variant['amount'];
                                }
                            }
                        }
                    }
            
              
            $package_product_name = DB::table('et_package_product')
              ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
              ->where('et_package_product.status', 0)
              ->where('et_package_product.package_id', $proposal->package_id)
              ->pluck('et_product.product_name');
              
             $package_data->product_name = $package_product_name ;
             
            
    
            $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                            ->where('et_proposal_pay_slot.proposal_sno',$proposal->sno)
                            ->where('et_proposal_pay_slot.status',0)
                            ->get();
            $productSlot_amount =0 ;
              foreach($slots as $slot){
              $productSlot_amount += $slot->slot_amount;
                  $deliverables_ids=$slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
                  $slot_notes_ids=$slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
                  $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('delivarable_name');
                  $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
                  $slot->deliverables =$deliverables;
                  $slot->slot_notes =$slot_notes;
              }
              $package_data->slots=$slots;
              
               $package_data->package_amount= $packageTotal ;
               $package_data->packageTotalCart= $packageTotalCart ;

         $packages=$package_data;

    }

    // return  $packages;

     $proposalAddonProduct = DB::table('et_proposal_addon_product')
                          ->select('et_manage_addon.addon_name','et_proposal_addon_product.*','et_addon_variable.addon_variablename')
                          ->where('et_proposal_addon_product.status',0)
                          ->join('et_manage_addon','et_manage_addon.sno','=','et_proposal_addon_product.add_on_id')
                          ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_proposal_addon_product.addon_variant_id')
                          ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                          ->where('et_proposal_addon_product.proposal_id',$proposal->proposal_id)
                          ->get();

          $freeAddonProduct = DB::table('et_proposal_addon_product')
            ->select(
                'et_manage_addon.addon_name',
                'et_proposal_addon_product.*',
                'et_addon_variable.addon_variablename'
            )
            ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
            ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
            ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
            ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_addon_product.status', 0)
            ->where('et_proposal_addon_product.free_paid', 0)
            ->get();

            $paidAddonProduct = DB::table('et_proposal_addon_product')
                ->select(
                    'et_manage_addon.addon_name',
                    'et_proposal_addon_product.*',
                    'et_addon_variable.addon_variablename'
                )
                ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
                ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
                ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
                ->where('et_proposal_addon_product.status', 0)
                ->where('et_proposal_addon_product.free_paid', 1)
                ->get();
                  
                $proposal->freeAddonProducts = $freeAddonProduct;
                $proposal->paidAddonProducts = $paidAddonProduct;
     $proposal->productAddon =$proposalAddonProduct;
   
  
      $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();

    

    
    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();

    $proposal_terms =[];
    if($terms){
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature= $terms->signature;


    // return $proposal;

    return view('content.payment_management.manage_accounts.receipt_print',[
      'lead' =>$lead,
      'paySlots' =>$slotData,
      'proposal' =>$proposal,
      'branch_data' =>$branch_data,
      'proposal_note' =>$proposal_note,
      'proposal_terms' =>$proposal_terms,
      'signature' =>$signature,
      'packages' =>$packages,
      'transaction_id' =>$transaction_id,
      'paymentHistory' =>$paymentHistory,
      'total_paid' =>$total_paid,
    ]);
  }
  
  public function SendReceiptMessage(Request $request)
    {
      // Validate the incoming request data
      $validator = Validator::make($request->all(), [
        'proposal_id' => 'required', 
        'email'    => 'boolean',
        'sms'     => 'boolean',
        'whatsapp' => 'boolean'
      ]);
      // If validation fails, return a response with errors
      if ($validator->fails()) {
        return response([
          'status'    => 401,
          'message'   => 'Incorrect format input fields',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      }
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
      $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

      $branch_name = " ";
      if ($branchData->branch_type == 1) {
        $branch_name = $branchData->branch_name;
      } elseif ($branchData->branch_type == 2) {
        $branch_name = $branchData->franchise_name;
      }

     
      $slot_id  = $request->slot_id;
      $customer_id  = $request->customer_id;
      $old_customer_check  = $request->old_customer_check;

     $slots = DB::table('et_proposal_pay_slot')
                    ->where('sno', $slot_id)
                    ->where('status', 0)
                    ->first();

    $proposal =DB::table('et_proposal')
             ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
             ->where('et_proposal.sno',$slots->proposal_sno)
              ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
              ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
              ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
              ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
              ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->where('et_proposal.status','!=',2)
             ->where('et_lead.status','!=',2)
             ->orderBy('et_proposal.sno', 'desc')
             ->first();
            if($proposal){
                if($proposal->post_sale_check==1){
                    $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                    $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                    $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                }
            }
         $proposal_id  = $proposal->sno;
      $customer=DB::table('et_customer')->where('et_customer.sno',$customer_id)->first();
      $paymentData=DB::table('et_payment')->where('et_payment.pay_slot_id',$slot_id)->first();
      // Extract the validated data
      $lead_id=$proposal->lead_id ?? 0;
      $email     = $request->email;
      $sms      = $request->sms;
      $whatsapp = $request->whatsapp;
      $message  = $request->message;
      $user_id  = $request->user()->user_id;


      // return $request;
      // Find the lead based on lead_id
      $lead = LeadModel::where('sno', $lead_id)
        ->first();

      // If the lead is not found, return an error response
      if (!$lead) {
        return response([
          'status'    => 404,
          'message'   => 'Lead not found',
          'error_msg' => 'The lead with the given ID does not exist',
          'data'      => null,
        ], 200);
      }
      
      

      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($slot_id, 'encrypt');

      $ReceiptLink ='https://erp.elysiumtechnologies.com/receipt_print/'.$encrypted_values;
      
         //  communication Receipt
         $communicationStatus=DB::table('et_communication_handle')->where('module_name','Receipt Send')->first();
         $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
         
        if($communicationStatus && $communicationStatus->status == 0){
      
     
              // Receipt Communication 
              
                 $encrypted_values_receipt = $helper->encrypt_decrypt($slots->sno, 'encrypt');
                  $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                  $slot=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
                  
                       $lead_name =$lead->lead_name;
                       $lead_email_id =$lead->lead_email_id;
                       $lead_mobile =$lead->lead_mobile;
                  
                        $TargetCurrency = $proposal->currency_code ?? 'INR';
                        $converted_amount =$slots->paidAmount;
                        $endpoint = 'convert';
                        $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
                
                        $helper = new \App\Helpers\Helpers();
                        //   if ($TargetCurrency !== 'INR') {
                        //     $response= $helper->convertFromINR($TargetCurrency);   
                        //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
                        //     $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
                        //     $converted_amount = ($exchange_quote != 0) ? $slots->paidAmount * $exchange_quote : 0;
                        //   }else{
                        //     $converted_amount =$slots->paidAmount;
                        //   }
               $exchange_quote=1;
                $converted_amount =$slots->paidAmount;
               $slotAmount = $proposal->currency_symbol . number_format($converted_amount, 2, '.', ',');
                  
                  
                   
                 
                         if(!$slots->receipt_temp_link){
                        $channelId_receipt = 7;
                         $shortUrlData_receipt = $this->shortenUrl($ReceiptLink,$channelId_receipt);
                         $shortUrl_receipt = $shortUrlData_receipt['shorturl'];
                         $urlId_receipt =$shortUrlData_receipt['id'];
                         if($shortUrl_receipt){
                             DB::table('et_proposal_pay_slot')
                                ->where('sno', $slot->sno)
                                ->update(['receipt_temp_link' => $shortUrl_receipt]);
                                
                                  DB::table('et_chotta_links')->insert([
                                      'branch_id' => $proposal->branch_id,
                                      'chotta_link_id' => $urlId_receipt,
                                      'chotta_short_link' => $shortUrl_receipt,
                                      'large_encrypt_link' => $ReceiptLink,
                                      'link_type' => 'Receipt Send',
                                      'pay_slot_id' =>$slot->sno,
                                      'created_by' => $proposal->created_by,
                                      'updated_by' => $proposal->created_by,
                                  ]);
                         }
                    }
                    
                          $slotUrl_receipt=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slots->sno)->first();
                          $shortsendUrl_receipt = $slotUrl_receipt->receipt_temp_link ;
                          $slot_url_key_receipt = basename($shortsendUrl_receipt);
                          
                         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                         $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                          $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile;
                       
                          
                      // sms Receipt send
                      if($communicationStatus->sms ==0){
                        if ($sms == 1) {
            
                              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '7_PhDiZone_Receipt_Template')->first();
                              $authkey = $result_sms ? $result_sms->authkey : '';
                              $sender_id = $result_sms ? $result_sms->sender_id : '';
                              $template_id = $result_sms ? $result_sms->template_id : '';
                              $country_code = $result_sms ? $result_sms->country_code : '';
                              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                              $mobile_number = $country_code . $lead_mobile;
                    
                             
                           
                    
                              // Replace placeholders with actual values
                              $replacement_values = [$lead_name,$shortsendUrl_receipt,$slotAmount,$cre_mobile];
                              $message_content = preg_replace_callback(
                                '/\{#var#\}/',
                                function () use (&$replacement_values) {
                                  return array_shift($replacement_values);
                                },
                                $message_content
                              );
                    
                              $route = "default";
                              $postData = array(
                                'authkey' => $authkey,
                                'mobiles' => $mobile_number,
                                'message' => $message_content,
                                'sender' => $sender_id,
                                'route' => $route,
                              );
                    
                              // API URL
                              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                    
                              // Initialize the resource
                              $ch = curl_init();
                              curl_setopt_array($ch, array(
                                CURLOPT_URL => $url,
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_POST => true,
                                CURLOPT_POSTFIELDS => $postData,
                                CURLOPT_SSL_VERIFYHOST => 0,
                                CURLOPT_SSL_VERIFYPEER => 0,
                              ));
                    
                              // Get response
                              $response = curl_exec($ch);
                              // return $response;
                              $err = curl_error($ch);
                              curl_close($ch);
                            }
                    }
                    
                    // Email Receipt Send
                      if($communicationStatus->email ==0){ 
                           if ($email == 1) {
                        if ($lead_email_id) {
                            $emailTemplate_id =7; // proposal send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }
                        
                      
                       $transaction_date = Carbon::parse($paymentData->transaction_date)->format('d M Y');
                        
                        $content = $emailTemplate->email_subject;
                
                        $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                
                        $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead_name, $content);
                        $content = str_replace('#reciept_number', $paymentData->payment_id ?? '', $content);
                        $content = str_replace('#payment_date', $transaction_date ?? date('d-M-Y'), $content);
                        $content = str_replace('#link', $shortsendUrl_receipt, $content);
                        $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                        $content = str_replace('#payment', $slotAmount ?? '', $content);
                        $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                        $content = str_replace('#cre_number',  $cre_mobile ?? '8220011465', $content);
                        $branchNo = $branch->mobile;
                        $branchemail = $branch->mail;
                        $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $url= 'phdizone.com';
                
                        $mailData = [
                              'url'         => $url,
                              'subject'     => $dynamicSubject,
                              'content'     => $content,
                              'branchNo'    => $branchNo,
                              'branchemail' => $branchemail, // Use the message content from the request
                              'fbLink'      => $fbLink,      // Use the message content from the request
                              'instaLink'   => $instaLink,   // Use the message content from the request
                              'salesMobile' => $cre_mobile ?? '8220011465',
                          ];
                
                        $to_address = $lead_email_id;
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                
                        Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                     }
                           }
                      }
                      
                    //  Whatsapp Receipt Send
                      if($communicationStatus->whatsapp ==0){
                           
                          if ($whatsapp == 1) {
                                if ($lead_mobile) {
                          
                           
                                // $templateName  = "hello_world";
                                $templateName  = "payment_recept_phdizone";
                
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
                
                                if ($templateName == 'payment_recept_phdizone') {
                                    $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $customer ? $customer->cus_name : $lead_name,
                                            'parameter_name' => 'customer_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $paymentData->payment_id ?? '',
                                            'parameter_name' => 'recept_number',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $transaction_date ?? date('d-M-Y'),
                                            'parameter_name' => 'payment_date',
                                        ],
                                         [
                                            'type'           => 'text',
                                            'text'           => $slotAmount ?? '',
                                            'parameter_name' => 'payment',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposal->service_title ?? '',
                                            'parameter_name' => 'service_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slot_url_key_receipt,
                                            'parameter_name' => 'link_key',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $cre_mobile ?? '8220011465',
                                            'parameter_name' => 'cre_number',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                    $hasButton = true;
                                }
                
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
                
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
                
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => $slot_url_key_receipt,
                                            ],
                                        ],
                                    ];
                                }
                                
                                
                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead_mobile;
                                $languageCode = 'en';
                    
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
                
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
                
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                                
                               
                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                            
                      }
                          }
                      }
                    
                     DB::table('et_proposal_pay_slot')
                        ->where('sno', $slots->sno)
                        ->update(['receipt_send_status' => 1]);
        }
      // If the operation was successful, return a success response
      return response([
        'status'    => 200,
        'message'   => "Message sent successfully",
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
    
    public function encrypt_ids(Request $request)
  {
    // Get the values sent from JavaScript
    $values = $request->input('values');
    // Encrypt the combined values
    $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($values, 'encrypt');

    // Return the encrypted value as JSON
    return response()->json($encrypted_values);
  }
   public function DownloadReceiptPrint($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        $branch_id = $request->user()->branch_id;
         $slot_id_decrpt =$decryptedValue;
   
    
     $slotData = DB::table('et_proposal_pay_slot')
                 ->select('et_proposal_pay_slot.*','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id')
                   ->join('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
                    ->where('et_proposal_pay_slot.sno', $slot_id_decrpt)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->first();
     
    $slotProp = DB::table('et_proposal_pay_slot')
                    ->where('proposal_sno', $slotData->proposal_sno)
                    ->where('status', 0)
                    ->get();
    $paidAmount=$slotProp->sum('paidAmount');
    $balance_amount =   $slotData->total_amount  > 0 ? $slotData->total_amount -$paidAmount : 0;
    $slotData->due_amount =$balance_amount;
    
     $prps_id =$slotData->proposal_sno;
    

      $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.nick_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol','et_payment.invoice_id','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id')
                 ->where('et_proposal.sno',$prps_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
            if($proposal){
                if($proposal->post_sale_check==1){
                    $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                    $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                    $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                }
            }

           $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $proposal->branch_id)
            ->first();

        

          $proposal->door_no =$branch_data->door_no ;
          $proposal->area_street = $branch_data->area_street ;
          $proposal->city_name =  $branch_data->city_name ;
          $proposal->state_name =  $branch_data->state_name ;
          $proposal->country_name =  $branch_data->country_name ;
          $proposal->pincode =  $branch_data->pincode ;
          $proposal->branch_mail =  $branch_data->mail ;
          $proposal->branch_mobile =  $branch_data->mobile ;
          $proposal->gst_no =  $branch_data->gst_no ?? "-" ;


           $lead_data = DB::table('et_lead')
            ->select(
                'et_lead.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
            ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
            ->where('et_lead.sno', $proposal->lead_id)
            ->first();

          $customer =DB::table('et_customer')
                ->select('et_customer.*',
                 'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
                )
                 ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
                ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
                ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
                 ->where('et_customer.sno',$proposal->customer_id)
                 ->where('et_customer.status','!=',2)
                 ->orderBy('et_customer.sno', 'desc')
                 ->first();

            $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
            $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
            $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
            $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
            $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
            $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
            $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
            $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
            $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';

            
      if($proposal->discount_id >0){
        $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$proposal->discount_id)->first();

        $proposal->discount_value=$discount->coupon_value ;
        $proposal->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
      }
      
      $domain_ids = json_decode($proposal->domain_ids ?? '[]', true);

            $domain_names = DB::table('et_domain')
                ->where('et_domain.status', 0)
                ->whereIn('sno', $domain_ids)
                ->pluck('domain_name')  // Get only domain_name column
                ->toArray();            // Convert Collection to array
            
            $domain_list = implode(', ', $domain_names);
    
       
          $proposal->domain_names=$domain_list;

      // return $proposal;
      $proposal->products=[];
      $packages='';
    
    if($proposal->product_package == 1){

       $proposalProduct = DB::table('et_proposal_product_cart')
                          ->select('et_proposal_product_cart.*','et_product.product_name','et_product_category.product_category_name')
                          ->where('et_proposal_product_cart.status',0)
                          ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
                          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
                          ->where('et_proposal_product_cart.proposal_id',$proposal->proposal_id)
                          ->get();
       
         $groupedProducts = [];
            $allSlotIds = [];
            foreach ($proposalProduct as $product) {
                $product_id = $product->product_id;
                $cart_id = $product->cart_id;
            
                // Shared data fetched once per product_id
                if (!isset($groupedProducts[$product_id])) {
                    $product_data = ProductModel::select('et_product.*')
                        ->where('et_product.sno', $product_id)->first();
            
                    $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
                    $tools_ids = is_array($tools_ids) ? $tools_ids : [];
            
                    $tools = DB::table('et_product_tools')
                        ->whereIn('sno', $tools_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('product_tools_name')
                        ->toArray();
            
                    $base_product = clone $product; // Copy to modify
                    $base_product->tools_name = $tools;
                    $base_product->product_name = $product->product_name;
                    $base_product->product_category_name = $product->product_category_name;
                    $base_product->cart_variants = [];
                    $base_product->cart_slots = [];
                    $base_product->total_amount_cart = 0;
                    $base_product->product_amount = 0;
            
                    $groupedProducts[$product_id] = $base_product;
                }
            
                // Compute variant data per cart
                $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
                $variable_amount = 0;
                $variant_names = [];
                $product_variant_name = '';
                $variable_name = '';
            
                foreach ($variant_variable_ids as $pair) {
                    $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
                    $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
            
                    if ($variant_id) {
                        $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
                        $product_variant_name = $get_variant->product_variant_name ?? '';
                    }
            
                    if ($variable_id) {
                        $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
                        if ($get_variables) {
                            $variable_name = $get_variables->variable_name;
                            $variable_amount += $get_variables->variable_amount;
                        }
                    }
            
                    if ($product_variant_name && $variable_name) {
                        $variant_names[] = "{$product_variant_name} - {$variable_name}";
                    } elseif ($product_variant_name) {
                        $variant_names[] = $product_variant_name;
                    }
                }
           
                // $cart_total = $variable_amount + $product_data->base_price;
                $cart_total = $product->product_amount;
                $groupedProducts[$product_id]->total_amount_cart += $cart_total;
            
                // Add cart-specific variant names
                $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
                $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;

            
                // Fetch slots for this cart
                $slots = DB::table('et_proposal_pay_slot')
                    ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
                    ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                    ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->get();
                    
                $slotCount=count($slots);
                
                foreach ($slots as $slot) {
                    $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
                    if (!in_array($cart_id, $slot_cart_ids)) {
                        continue;
                    }
            
                    $groupedProducts[$product_id]->product_amount += $slot->slot_amount;
            
                    $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
                    $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);
            
                    $deliverable_items = $deliverables_map[$cart_id] ?? [];
                    $slot_notes_items = $slot_notes_map[$cart_id] ?? [];
            
                    $deliverable_ids = [];
                    foreach ($deliverable_items as $d) {
                        if (($d['status'] ?? '0') == '0') {
                            $deliverable_ids[] = $d['value'];
                        }
                    }
            
                    $slot_notes_ids = [];
                    foreach ($slot_notes_items as $s) {
                        if (($s['status'] ?? '0') == '0') {
                            $slot_notes_ids[] = $s['value'];
                        }
                    }
            
                     $deliverable_ids = array_filter($deliverable_ids); // Ensure no empty values

                        if (count($deliverable_ids) > 0) {
                            $deliverables = DB::table('et_product_delivarables')
                                ->whereIn('sno', $deliverable_ids)
                                ->where('status', 0)
                                ->orderByRaw('FIELD(sno, ' . implode(',', $deliverable_ids) . ')')
                                ->pluck('delivarable_name', 'sno');
                        } else {
                            // Handle case where $deliverable_ids is empty
                            $deliverables = collect(); // Return an empty collection or handle accordingly
                        }
            
                    $slot_notes = DB::table('et_slot_notes')
                        ->whereIn('sno', $slot_notes_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('slot_notes_name');
            
                    // Assign deliverables and notes for this cart
                    $slot->deliverables = $deliverables;
                    $slot->slot_notes = $slot_notes;
            
                     if (!isset($groupedProducts[$product_id]->cart_slots)) {
                            $groupedProducts[$product_id]->cart_slots = [];
                        }
                        
                        // Find if the slot already exists in the array
                        $existingIndex = null;
                        foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
                            if ($existingSlot['sno'] === $slot->sno) {
                                $existingIndex = $index;
                                break;
                            }
                        }
                        
                        if ($existingIndex === null) {
                            // Add new slot entry
                            $groupedProducts[$product_id]->cart_slots[] = [
                                'sno' => $slot->sno,
                                'propo_pay_slot_id' => $slot->propo_pay_slot_id,
                                'branch_id' => $slot->branch_id,
                                'lead_id' => $slot->lead_id,
                                'proposal_id' => $slot->proposal_id,
                                'proposal_sno' => $slot->proposal_sno,
                                'product_cart_id' => $slot->product_cart_id,
                                'package_id' => $slot->package_id,
                                'slot_id' => $slot->slot_id,
                                'slot_amount' => $slot->slot_amount,
                                'payable_amount' => $slot->payable_amount,
                                'paidAmount' => $slot->paidAmount,
                                'gst_amount' => $slot->gst_amount,
                                'balance_amount' => $slot->balance_amount,
                                'total_amount' => $slot->total_amount,
                                'slot_description' => $slot->slot_description,
                                'created_by' => $slot->created_by,
                                'created_at' => $slot->created_at,
                                'updated_by' => $slot->updated_by,
                                'updated_at' => $slot->updated_at,
                                'status' => $slot->status,
                                'due_date' => $slot->due_date,
                                'link_status' => $slot->link_status,
                                'paid_status' => $slot->paid_status,
                                'invoice_id' => $slot->invoice_id,
                                'temp_send_link' => $slot->temp_send_link,
                                'old_customer_check' => $slot->old_customer_check,
                                'send_status' => $slot->send_status,
                                'receipt_temp_link' => $slot->receipt_temp_link,
                                'receipt_send_status' => $slot->receipt_send_status,
                                'payment_slot_name' => $slot->payment_slot_name,
                                'start_deliver_work' => $slot->start_deliver_work,
                                'deliverables' => [
                                    (string)$cart_id => $deliverables->toArray()
                                ],
                                'slot_notes' => [
                                    (string)$cart_id => $slot_notes->toArray()
                                ]
                            ];
                        } else {
                            // Slot already exists — just append deliverables and slot_notes for this cart
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
                        }


                }
                
            //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

            }
            
            // Set the grouped products
            $proposal->products = array_values($groupedProducts);
            $proposal->slotCount=$slotCount;
       
    }else{

      $package_data = DB::table('et_package')
                    ->select('et_package.*')
                    ->join('et_proposal', 'et_proposal.package_id', '=', 'et_package.sno')
                    ->where('et_package.status',0)
                    ->where('et_package.sno', $proposal->package_id)
                    ->first();
    
            $package_cart = DB::table('et_proposal_package_cart')
                    ->select('variant_variable_ids')
                    ->where('status', 0)
                    ->where('proposal_sno', $proposal->sno)
                    ->get();
                
                $packageTotal = 0;
                
                foreach ($package_cart as $item) {
                    $variants = json_decode($item->variant_variable_ids, true); // decode as array
                
                    if (is_array($variants)) {
                        foreach ($variants as $variant) {
                            if (isset($variant['amount'])) {
                                $packageTotal += $variant['amount'];
                            }
                        }
                    }
                }
              
            $package_product_name = DB::table('et_package_product')
              ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
              ->where('et_package_product.status', 0)
              ->where('et_package_product.package_id', $proposal->package_id)
              ->pluck('et_product.product_name');
              
             $package_data->product_name = $package_product_name ;
             
            
    
            $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                            ->where('et_proposal_pay_slot.proposal_sno',$proposal->sno)
                            ->where('et_proposal_pay_slot.status',0)
                            ->get();
            $productSlot_amount =0 ;
              foreach($slots as $slot){
              $productSlot_amount += $slot->slot_amount;
                  $deliverables_ids=$slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
                  $slot_notes_ids=$slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
                  $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('delivarable_name');
                  $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
                  $slot->deliverables =$deliverables;
                  $slot->slot_notes =$slot_notes;
              }
              $package_data->slots=$slots;
              
               $package_data->package_amount= $packageTotal ;

         $packages=$package_data;

    }

    // return  $packages;

     $proposalAddonProduct = DB::table('et_proposal_addon_product')
                          ->select('et_manage_addon.addon_name','et_proposal_addon_product.*','et_addon_variable.addon_variablename')
                          ->where('et_proposal_addon_product.status',0)
                          ->join('et_manage_addon','et_manage_addon.sno','=','et_proposal_addon_product.add_on_id')
                          ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_proposal_addon_product.addon_variant_id')
                          ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                          ->where('et_proposal_addon_product.proposal_id',$proposal->proposal_id)
                          ->get();

          $freeAddonProduct = DB::table('et_proposal_addon_product')
            ->select(
                'et_manage_addon.addon_name',
                'et_proposal_addon_product.*',
                'et_addon_variable.addon_variablename'
            )
            ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
            ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
            ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
            ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_addon_product.status', 0)
            ->where('et_proposal_addon_product.free_paid', 0)
            ->get();

            $paidAddonProduct = DB::table('et_proposal_addon_product')
                ->select(
                    'et_manage_addon.addon_name',
                    'et_proposal_addon_product.*',
                    'et_addon_variable.addon_variablename'
                )
                ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
                ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
                ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
                ->where('et_proposal_addon_product.status', 0)
                ->where('et_proposal_addon_product.free_paid', 1)
                ->get();
                  
                $proposal->freeAddonProducts = $freeAddonProduct;
                $proposal->paidAddonProducts = $paidAddonProduct;
     $proposal->productAddon =$proposalAddonProduct;
   
  
      $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();

    

    
    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();

    $proposal_terms =[];
    if($terms){
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature= $terms->signature;
    
        // if ($interns) {
        //     $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
        //     $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
        //     $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');

        //     $qrContent = "Name         : {$interns->intern_name}\n"
        //         . "Start Date   : {$interns->start_date_formatted}\n"
        //         . "End Date     : {$interns->end_date_formatted}\n"
        //         . "Company      : {$interns->company}\n"
        //         . "Issue Date   : {$issueDateFormatted}\n"
        //         . "Certificate  : Verified";



        //     // Create QR using PHP without installation
        //     $qrImage = imagecreate(200, 200);
        //     $white = imagecolorallocate($qrImage, 255, 255, 255);
        //     $black = imagecolorallocate($qrImage, 0, 0, 0);
        //     imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);

        //     // Just a placeholder pattern (real QR not generated like this)
        //     // Since you don't want to install any package and can't rely on Google API,
        //     // we're forced to ask: are you open to use a **small local script** or CDN?

        //     // RECOMMENDED: Use API from https://api.qrserver.com/

        //     $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";

        //     // Convert to base64
        //     $qrImageData = @file_get_contents($qrServerUrl);
        //     $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
        // }

        // return $interns;
        $pdf = PDF::loadView('content.payment_management.manage_accounts.receipt_page', [
            'lead' =>$lead,
              'paySlots' =>$slotData,
              'proposal' =>$proposal,
              'branch_data' =>$branch_data,
              'proposal_note' =>$proposal_note,
              'proposal_terms' =>$proposal_terms,
              'signature' =>$signature,
              'packages' =>$packages,
        ])
            ->setPaper('a4', 'portrait')
            ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
            ->setOption('isPhpEnabled', true)
            ->setOption('isRemoteEnabled', true)  // now you can safely set false
            ->setPaper('a4');
        // return $pdf;  
        return $pdf->stream('receipt.pdf');
        // return $pdf->download('receipt.pdf');   
        // return view('content.payment_management.manage_accounts.receipt_page', [
        //     'lead' =>$lead,
        //       'paySlots' =>$slotData,
        //       'proposal' =>$proposal,
        //       'branch_data' =>$branch_data,
        //       'proposal_note' =>$proposal_note,
        //       'proposal_terms' =>$proposal_terms,
        //       'signature' =>$signature,
        //       'packages' =>$packages,
        // ]
        // );
    }
    
    public function PayLater(Request $request){
        
        $amount = $request->slot_amount;
        $slot_id = $request->slot_id;
        $prps_id = $request->proposal_id;
        $pay_mode = $request->pay_mode;
         $transaction_id = $request->reason;
        
           DB::table('et_proposal_pay_slot')
                                ->where('sno',$slot_id)
                                ->update([
                                    'paid_status' =>2,
                                    'pay_later_reason' =>$transaction_id
                                    ]);
                                
            $encrypt_id = $slot_id;
            $helper = new \App\Helpers\Helpers();
            $encrypted_values = $helper->encrypt_decrypt($encrypt_id, 'encrypt');

            return response()->json([
                'status' => 200,
                'message' => 'Payment Redirect',
                'error_msg' => null,
                'data' => $encrypted_values,
                'id' => $encrypted_values,
                'pay_mode' => $pay_mode
            ]);
                                
    }
    
     public function OfflineAccepted($id ,Request $request){
         
        

      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    //   return $decryptedValue;
     
                 
        $slotData = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                        ->where('et_proposal_pay_slot.sno',$decryptedValue)
                        ->where('et_proposal_pay_slot.status',0)
                        ->orderBy('et_proposal_pay_slot.sno', 'asc')
                        ->first();
        // return $slotData;
                        
         $proposal =DB::table('et_proposal')
             ->select('et_proposal.*','et_country_currencies.currency_symbol','et_country_currencies.currency_code')
             ->where('et_proposal.sno',$slotData->proposal_sno)
             ->where('et_proposal.status','!=',2)
             ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->orderBy('et_proposal.sno', 'desc')
             ->first();
        // return $slotData;
        $link=$slotData->temp_send_link;
        $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
      return view('content.lead_management.manage_proposal.offline_payment',[
        'proposal'=>$proposal,
        'slot'=>$slotData,
        'link'=>$link,
        'cug_mobile'=>$cug_details->staff_mobile ?? $branch->cre_mobile,
      ]);
    }
    
    
    public function PayLaterPage($id ,Request $request){
         
        

      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    //   return $decryptedValue;
     
                 
        $slotData = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                        ->where('et_proposal_pay_slot.sno',$decryptedValue)
                        ->where('et_proposal_pay_slot.status',0)
                        ->orderBy('et_proposal_pay_slot.sno', 'asc')
                        ->first();
        // return $slotData;
                        
         $proposal =DB::table('et_proposal')
             ->select('et_proposal.*','et_country_currencies.currency_symbol','et_country_currencies.currency_code')
             ->where('et_proposal.sno',$slotData->proposal_sno)
             ->where('et_proposal.status','!=',2)
             ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->orderBy('et_proposal.sno', 'desc')
             ->first();
        // return $slotData;
        $link=$slotData->temp_send_link;
        $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
         
           $endpoint = 'convert';
                $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
                $response ='';
                $helper = new \App\Helpers\Helpers();
           $TargetCurrency = $proposal->currency_code ?? 'INR';
        //  if ($TargetCurrency !== 'INR') {
        //             $response= $helper->convertFromINR($TargetCurrency);   
        //             $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
        //             $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
        //             $converted_amount = ($exchange_quote != 0) ? $slotData->payable_amount * $exchange_quote : 0;
    
        //           }else{
        //             $converted_amount =$slotData->payable_amount;
        //             $exchange_inr_rate=1;
        //             $exchange_quote=1;
        //           }
          $converted_amount =$slotData->payable_amount;
          $exchange_quote=1;
      return view('content.lead_management.manage_proposal.pay_later_page',[
        'proposal'=>$proposal,
        'slot'=>$slotData,
        'link'=>$link,
        'converted_amount'=>$converted_amount,
        'exchange_quote' =>$exchange_quote,
        'cug_mobile'=>$cug_details->staff_mobile ?? $branch->cre_mobile,
      ]);
    }
    
    public function TransactionUpdate(Request $request){
        $transaction_id = $request->input('transaction_id');
        $user_id = $request->user()->user_id;
    
        $TransactionModel = TransactionModel::where('sno', $transaction_id)->first();
    
        if($TransactionModel){
            $paymentData = DB::table('et_payment')->where('sno', $TransactionModel->payment_id)->first();
            $transaction_date = $request->input('transaction_date') ? date('Y-m-d', strtotime($request->input('transaction_date'))) : $paymentData->transaction_date;
            $slotdata = DB::table('et_proposal_pay_slot')
                        ->where('sno', $paymentData->pay_slot_id)
                        ->where('status', 0)
                        ->first();
            
            DB::table('et_payment')
                ->where('sno', $TransactionModel->payment_id)
                ->update([
                    'transaction_date' => $transaction_date,
                    'updated_by' => $user_id,
                    'updated_at' => now(),
                ]);
            
            if ($slotdata->paid_status != 2) {
                DB::table('et_proposal_pay_slot')
                    ->where('sno', $paymentData->pay_slot_id)
                    ->update([
                        'initialPayDate' => $transaction_date,
                        'updated_by' => $user_id,
                        'updated_at' => now(),
                    ]);
            }
            
            $TransactionModel->transaction_date = $transaction_date;
            $TransactionModel->save(); // Use save() instead of update() if you're saving the model instance
        }
    
        return response()->json([
            'status' => 200,
            'message' => 'Transaction Updated',
            'error_msg' => null,
        ]);
    }
    
    
public function paymentRejectChange(Request $request)
{
    $id             = $request->sts_change_id;
    $sts            = $request->sts_change_type;
    $customer_id    = $request->customer_id_hidden;
    $proposal_id    = $request->proposal_id_hidden;
    $slot_id        = $request->slot_id_hidden;
    $payment_id     = $request->payment_id_hidden;
    $user_id        = $request->user()->user_id;

    $offline_description    = $request->offline_description;
    $offline_transaction_id = $request->offline_transaction_id;
    $offline_payment_mode   = $request->offline_payment_mode;

    // Check transaction validity
    $OldCustomerModel = TransactionModel::where('sno', $id)
        ->select('sno', 'payment_status')
        ->first();

    if (!$OldCustomerModel) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update status!'
        ]);
        return redirect('/manage_accounts');
    }

    if ($sts != 1) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Invalid status change request.'
        ]);
        return redirect('/manage_accounts');
    }

    DB::beginTransaction();
    try {
        // Lock necessary rows
        $slot        = DB::table('et_proposal_pay_slot')->where('sno', $slot_id)->lockForUpdate()->first();
        $payment     = DB::table('et_payment')->where('sno', $payment_id)->lockForUpdate()->first();
        $transaction = TransactionModel::where('sno', $id)->lockForUpdate()->first();
        $proposal    = DB::table('et_proposal')->where('sno', $payment->proposal_id)->first();
        $customer    = CustomerModel::where('sno', $payment->customer_id)->first();

        if (!$slot || !$payment || !$transaction) {
            throw new \Exception("Invalid slot/payment/transaction data.");
        }

        // Check if any previous post-sale proposals exist
        $previousPostProposalExist = DB::table('et_proposal')
            ->where('sno', '!=', $payment->proposal_id)
            ->where('customer_id', $payment->customer_id)
            ->where('proposal_status', 3)
            ->where('post_sale_check', 1)
            ->exists();

        // Update payment & transaction
        DB::table('et_payment')->where('sno', $payment_id)->update([
            'status' => 2,
            'updated_by' => $user_id,
        ]);

        $transaction->payment_status = 0;
        $transaction->status = 2;
        $transaction->updated_by = $user_id;
        $transaction->save();

        // Update slot
        DB::table('et_proposal_pay_slot')->where('sno', $slot_id)->update([
            'paid_status' => 0,
            'updated_by' => $user_id,
        ]);

        // Reject last pay history
        // $lastHistory = DB::table('et_proposal_pay_history')
        //     ->where('pay_slot_id', $slot_id)
        //     ->where('status', 1)
        //     ->first();

        // if ($lastHistory) {
        //     $history = ProposalPayHistoryModel::where('sno', $lastHistory->sno)
        //         ->where('status', '!=', 2)
        //         ->first();

        //     if ($history) {
        //         $history->status = 2;
        //         $history->updated_by = $user_id;
        //         $history->save();
        //     }
        // }

        // ========================
        // FIRST MILESTONE LOGIC
        // ========================
        if ($slot->first_milestone == 1) {
            if ($proposal->post_sale_check == 1) {
                // POST SALE — detach proposal ID
                $proposalIds = json_decode($customer->proposal_ids, true) ?? [];
                $proposalIds = array_filter($proposalIds, fn($p) => $p != $payment->proposal_id);
                $customer->proposal_ids = json_encode(array_values($proposalIds));

                if (!$previousPostProposalExist) {
                    $customer->post_sale_check = 0;
                }
                $customer->save();

                // revert proposal status
                DB::table('et_proposal')->where('sno', $payment->proposal_id)->update([
                    'proposal_status' => 1,
                    'updated_by' => $user_id
                ]);
            } else {
                // PRE SALE — delete customer & revert proposal & lead
                $customer->status = 2;
                $customer->save();

                DB::table('et_proposal')->where('sno', $payment->proposal_id)->update([
                    'proposal_status' => 1,
                    'updated_by' => $user_id
                ]);

                DB::table('et_lead')->where('sno', $customer->lead_id)->update([
                    'lead_status' => 1,
                    'status' => 0,
                    'updated_by' => $user_id,
                ]);
            }
        }

        DB::commit();

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Payment rejected successfully!'
        ]);

    } catch (\Exception $e) {
        DB::rollBack();
        session()->flash('toastr', [
            'type' => 'error',
            'message' => $e->getMessage()
        ]);
    }

    return redirect('/manage_accounts');
}



 public function OfficeReceipt($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $slot_id_decrpt =$decryptedValue;
   
    
     $slotData = DB::table('et_proposal_pay_slot')
                 ->select('et_proposal_pay_slot.*',
                 'et_payment_slot.payment_slot_name',
                 'et_payment.transaction_date',
                 'et_payment.payment_mode',
                 'et_payment.payment_mode',
                 'et_transaction.credit',
                 'et_transaction.tax',
                 'et_transaction.total_amount as grand_total',
                 'et_payment.payment_method',
                 'et_payment.offline_description',
                 'et_payment.offline_transaction_id',
                 'et_payment.payment_id as pay_id',
                 'et_transaction.transaction_id',
                 'et_transaction.payment_id as pay_sno'
                 )
                   ->join('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
                   ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                   ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_proposal_pay_slot.sno', $slot_id_decrpt)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->orderBy('et_transaction.sno','desc')
                    ->first();
        $transaction_id=$slotData->transaction_id;
    
   
     
    $slotProp = DB::table('et_proposal_pay_slot')
                    ->where('proposal_sno', $slotData->proposal_sno)
                    ->where('status', 0)
                    ->get();
    $paidAmount=$slotProp->sum('paidAmount');
    $balance_amount =   $slotData->total_amount  > 0 ? $slotData->total_amount -$paidAmount : 0;
    $user_id= $request->user()->user_id ?? 0;
    // if($user_id==0){
    //   return  $slotData->total_amount;
    // }
    $slotData->due_amount =$balance_amount;
    
     $prps_id =$slotData->proposal_sno;
    

        $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol','et_payment.invoice_id','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id')
                 ->where('et_proposal.sno',$prps_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
                 
            if($proposal){
                if($proposal->post_sale_check==1){
                    $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                    $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                    $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                }
            }

           $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $proposal->branch_id)
            ->first();

        

          $proposal->door_no =$branch_data->door_no ;
          $proposal->area_street = $branch_data->area_street ;
          $proposal->city_name =  $branch_data->city_name ;
          $proposal->state_name =  $branch_data->state_name ;
          $proposal->country_name =  $branch_data->country_name ;
          $proposal->pincode =  $branch_data->pincode ;
          $proposal->branch_mail =  $branch_data->mail ;
          $proposal->branch_mobile =  $branch_data->mobile ;
          $proposal->gst_no =  $branch_data->gst_no ?? "-" ;


           $lead_data = DB::table('et_lead')
            ->select(
                'et_lead.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
            ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
            ->where('et_lead.sno', $proposal->lead_id)
            ->first();

            $customer =DB::table('et_customer')
                ->select('et_customer.*',
                 'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
                )
                 ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
                ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
                ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
                 ->where('et_customer.sno',$proposal->customer_id)
                 ->where('et_customer.status','!=',2)
                 ->orderBy('et_customer.sno', 'desc')
                 ->first();

            $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
            $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
            $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
            $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
            $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
            $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
            $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
            $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
            $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';
            $proposal->customer_id       = $customer->customer_id      ?? '';

      
    
    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();

    $proposal_terms =[];
    if($terms){
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature= $terms->signature;

    $paymentModeText = $this->getPaymentModeText(
            $slotData->payment_mode,
            $slotData->payment_method,
            $slotData->offline_description,
            $slotData->offline_transaction_id
        );
    // return $proposal;

    return view('content.payment_management.manage_accounts.office_copy_receipt',[
      'paymentModeText' =>$paymentModeText,
      'paySlots' =>$slotData,
      'proposal' =>$proposal,
      'proposal_note' =>$proposal_note,
      'proposal_terms' =>$proposal_terms,
      'signature' =>$signature,
      'transaction_id' =>$transaction_id,
    ]);
  }


    private function getPaymentModeText($paymentMode, $paymentMethod, $offlineDescription, $offlineTransactionId)
    {
        if ($paymentMode == 1) { 
            return "{$paymentMethod}";
        } elseif ($paymentMode == 2) { 
            return "{$paymentMethod}";
        } else {
            return "-";
        }
    }


     public function QrInvoice($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $slot_id_decrpt =$decryptedValue;
   
    
     $slotData = DB::table('et_proposal_pay_slot')
                 ->select('et_proposal_pay_slot.*',
                 'et_payment_slot.payment_slot_name',
                 'et_payment.transaction_date',
                 'et_payment.payment_mode',
                 'et_payment.payment_mode',
                 'et_transaction.credit',
                 'et_transaction.tax',
                 'et_transaction.total_amount as grand_total',
                 'et_payment.payment_method',
                 'et_payment.offline_description',
                 'et_payment.offline_transaction_id',
                 'et_payment.payment_id as pay_id',
                 'et_transaction.transaction_id',
                 'et_transaction.payment_id as pay_sno'
                 )
                   ->join('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
                   ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                   ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_proposal_pay_slot.sno', $slot_id_decrpt)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->orderBy('et_transaction.sno','desc')
                    ->first();
        $transaction_id=$slotData->transaction_id;
    
   
    $slotProp = DB::table('et_proposal_pay_slot')
                    ->where('proposal_sno', $slotData->proposal_sno)
                    ->where('status', 0)
                    ->get();
    $paidAmount=$slotProp->sum('paidAmount');
    $balance_amount =   $slotData->total_amount  > 0 ? $slotData->total_amount -$paidAmount : 0;
    $user_id= $request->user()->user_id ?? 0;
    // if($user_id==0){
    //   return  $slotData->total_amount;
    // }
    $slotData->due_amount =$balance_amount;
    
     $prps_id =$slotData->proposal_sno;
    

        $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol','et_payment.invoice_id','et_payment.transaction_date','et_payment.payment_mode','et_payment.payment_id as pay_id')
                 ->where('et_proposal.sno',$prps_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
                 
            if($proposal){
                if($proposal->post_sale_check==1){
                    $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                    $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                    $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                }
            }

           $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $proposal->branch_id)
            ->first();

        

          $proposal->door_no =$branch_data->door_no ;
          $proposal->area_street = $branch_data->area_street ;
          $proposal->city_name =  $branch_data->city_name ;
          $proposal->state_name =  $branch_data->state_name ;
          $proposal->country_name =  $branch_data->country_name ;
          $proposal->pincode =  $branch_data->pincode ;
          $proposal->branch_mail =  $branch_data->mail ;
          $proposal->branch_mobile =  $branch_data->mobile ;
          $proposal->gst_no =  $branch_data->gst_no ?? "-" ;


           $lead_data = DB::table('et_lead')
            ->select(
                'et_lead.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
            ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
            ->where('et_lead.sno', $proposal->lead_id)
            ->first();

            $customer =DB::table('et_customer')
                ->select('et_customer.*',
                 'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
                )
                 ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
                ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
                ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
                 ->where('et_customer.sno',$proposal->customer_id)
                 ->where('et_customer.status','!=',2)
                 ->orderBy('et_customer.sno', 'desc')
                 ->first();

            $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
            $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
            $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
            $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
            $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
            $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
            $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
            $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
            $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';
            $proposal->customer_id       = $customer->customer_id      ?? '';

    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();

    $proposal_terms =[];
    if($terms){
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature= $terms->signature;

    $paymentModeText = $this->getPaymentModeText(
            $slotData->payment_mode,
            $slotData->payment_method,
            $slotData->offline_description,
            $slotData->offline_transaction_id
        );
    // return $proposal;

    return view('content.payment_management.manage_accounts.verified_invoice',[
      'paymentModeText' =>$paymentModeText,
      'paySlots' =>$slotData,
      'proposal' =>$proposal,
      'proposal_note' =>$proposal_note,
      'proposal_terms' =>$proposal_terms,
      'signature' =>$signature,
      'transaction_id' =>$transaction_id,
    ]);
  }

}
