<?php

// app/Http/Controllers/service_management/FileController.php

namespace App\Http\Controllers\service_management;

use App\Http\Controllers\Controller;
use App\Models\Folder;
use Carbon\Carbon;
use Google\Client;
use Google\Service\Drive;
use Google\Service\Drive\DriveFile;
use Google\Service\Drive\Permission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use ZipArchive;

class FileController extends Controller
{
    private $chunkSize = 25 * 1024 * 1024; // 25MB chunks for upload
    private $driveChunkSize = 25 * 1024 * 1024; // 25MB chunks for Google Drive streaming upload
    private $zipChunkSize = 10 * 1024 * 1024; // 10MB chunks for ZIP streaming
    /**
     * Show upload form
     */
    public function index($id, Request $request)
    {
        $recentFolders = Folder::latest()->take(10)->get();

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $data = explode('~', $decryptedValue);

        if (count($data) != 2) {
            return redirect()->back()->with('error', 'Invalid Data Format');
        }

        $taskId = $data[0];
        $mile_sno = $data[1];

        $milestoneDetails = DB::table('et_milestone_mapping')
            ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
            ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
            ->select(
                'et_milestone_mapping.service_id',
                'et_milestone_mapping.sno',
                'et_milestone_mapping.milestone_status',
                'et_milestone_mapping.task_ids',
                'et_payment_slot.payment_slot_name',
                'et_proposal_pay_slot.payable_amount',
                'et_proposal_pay_slot.paidAmount'
            )
            ->where('et_milestone_mapping.sno', $mile_sno)
            ->where('et_milestone_mapping.status', '!=', 2)
            ->where('et_milestone_mapping.milestone_status', 1)
            ->first();

        $data = DB::table('et_customer_services')
            ->where('et_customer_services.sno', $taskId)
            ->where('et_customer_services.status', '!=', 2)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->select(
                'et_customer.cus_name',
                'et_customer.cus_mobile',
                'et_customer.customer_id',
                'et_product.product_name',
                'et_product_category.product_category_name',
                'et_customer_services.sno',
                'et_customer_services.variant_variable_ids'
            )
            ->first();

        if (! $data) {
            return response()->json([
                'status' => 404,
                'message' => 'No record found!',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        $items = json_decode($data->variant_variable_ids, true);

        $variantName = '';
        $variableName = '';

        if (is_array($items) && count($items) > 0) {
            $first = $items[0];

            $variant = DB::table('et_manage_product_variant')
                ->where('sno', $first['variant_id'])
                ->first();

            $variable = DB::table('et_manage_product_variable')
                ->where('sno', $first['variable_id'])
                ->first();

            $variantName = $variant->product_variant_name ?? '';
            $variableName = $variable->variable_name ?? '';
        }

        $data->variant_name = $variantName;
        $data->variable_name = $variableName;

        return view('content.service_management.upload', compact('recentFolders', 'taskId', 'mile_sno', 'milestoneDetails', 'data'));
    }

    /**
     * Fetch delivery attachment checklist
     */
    public function deliveryAttachmentList()
    {
        $DeliCheck_list = DB::table('et_delivery_attachment_checklist')
            ->where('status', 0)
            ->orderBy('delivery_attachment_checklist')
            ->get();

        return response()->json([
            'status' => 200,
            'message' => 'Delivery Checklist Fetched Successfully',
            'data' => $DeliCheck_list,
        ], 200);
    }

    /**
     * Temporarily store uploaded files (not saved to Drive yet)
     */
    public function tempUpload(Request $request)
    {
        $request->validate([
            'checklist_id' => 'required|integer',
            'checklist_name' => 'required|string',
            'files' => 'required|array',
            'files.*' => 'required|file|max:16106127360',
            'task_id' => 'required|integer',
            'milestone_mapping_id' => 'required|integer',
        ]);

        try {
            $taskId = $request->task_id;
            $milestoneId = $request->milestone_mapping_id;
            $checklistId = $request->checklist_id;
            $checklistName = $request->checklist_name;
            $files = $request->file('files');

            $tempFiles = [];
            $sessionId = session()->getId();
            $tempDir = storage_path("app/temp/uploads/{$sessionId}/{$milestoneId}/{$checklistId}");

            // Ensure directory exists
            if (! file_exists($tempDir)) {
                mkdir($tempDir, 0777, true);
            }

            foreach ($files as $file) {
                // Get file info
                $originalName = $file->getClientOriginalName();
                $mimeType = $file->getMimeType();
                $fileSize = $file->getSize();

                // Generate unique filename
                $extension = $file->getClientOriginalExtension();
                $fileName = time() . '_' . uniqid() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', pathinfo($originalName, PATHINFO_FILENAME)) . '.' . $extension;
                $filePath = $tempDir . '/' . $fileName;

                // Read file content directly and save
                $content = file_get_contents($file->getRealPath());
                if ($content === false) {
                    throw new \Exception("Failed to read file: {$originalName}");
                }

                // Write to new location
                $bytesWritten = file_put_contents($filePath, $content);
                if ($bytesWritten === false || $bytesWritten != $fileSize) {
                    throw new \Exception("Failed to save file: {$originalName}");
                }

                $tempFiles[] = [
                    'temp_path' => $filePath,
                    'original_name' => $originalName,
                    'size' => $fileSize,
                    'human_size' => $this->formatFileSize($fileSize),
                    'mime_type' => $mimeType,
                    'temp_file_name' => $fileName,
                ];
            }

            // Store in session
            $tempUploads = session()->get('temp_uploads', []);
            if (! isset($tempUploads[$milestoneId])) {
                $tempUploads[$milestoneId] = [];
            }
            if (! isset($tempUploads[$milestoneId][$checklistId])) {
                $tempUploads[$milestoneId][$checklistId] = [
                    'checklist_id' => $checklistId,
                    'checklist_name' => $checklistName,
                    'files' => [],
                ];
            }

            $tempUploads[$milestoneId][$checklistId]['files'] = array_merge(
                $tempUploads[$milestoneId][$checklistId]['files'],
                $tempFiles
            );

            session()->put('temp_uploads', $tempUploads);

            return response()->json([
                'success' => true,
                'message' => count($files) . ' file(s) uploaded temporarily',
                'data' => [
                    'files' => $tempFiles,
                    'checklist_id' => $checklistId,
                    'checklist_name' => $checklistName,
                ],
            ]);
        } catch (\Exception $e) {
            Log::error('Temp upload failed: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'Upload failed: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Remove temporary file
     */
    public function removeTempFile(Request $request)
    {
        $request->validate([
            'checklist_id' => 'required|integer',
            'file_index' => 'required|integer',
            'milestone_mapping_id' => 'required|integer',
        ]);

        try {
            $milestoneId = $request->milestone_mapping_id;
            $checklistId = $request->checklist_id;
            $fileIndex = $request->file_index;

            $tempUploads = session()->get('temp_uploads', []);

            if (isset($tempUploads[$milestoneId][$checklistId]['files'][$fileIndex])) {
                $file = $tempUploads[$milestoneId][$checklistId]['files'][$fileIndex];
                if (file_exists($file['temp_path'])) {
                    unlink($file['temp_path']);
                }
                array_splice($tempUploads[$milestoneId][$checklistId]['files'], $fileIndex, 1);

                if (empty($tempUploads[$milestoneId][$checklistId]['files'])) {
                    unset($tempUploads[$milestoneId][$checklistId]);
                }
                if (empty($tempUploads[$milestoneId])) {
                    unset($tempUploads[$milestoneId]);
                }

                session()->put('temp_uploads', $tempUploads);
            }

            return response()->json([
                'success' => true,
                'message' => 'File removed successfully',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to remove file',
            ], 500);
        }
    }

    /**
     * Initialize chunked upload for large files
     */
    public function initChunkUpload(Request $request)
    {
        $request->validate([
            'checklist_id' => 'required|integer',
            'checklist_name' => 'required|string',
            'file_name' => 'required|string',
            'file_size' => 'required|integer|max:16106127360',
            'total_chunks' => 'required|integer',
            'file_type' => 'nullable|string',
            'task_id' => 'required|integer',
            'milestone_mapping_id' => 'required|integer',
        ]);

        try {
            $uploadId = uniqid('chunk_', true);
            $sessionId = session()->getId();
            $tempDir = storage_path("app/temp/chunks/{$sessionId}/{$uploadId}");

            if (! file_exists($tempDir)) {
                mkdir($tempDir, 0777, true);
            }

            $uploadData = [
                'checklist_id' => $request->checklist_id,
                'checklist_name' => $request->checklist_name,
                'file_name' => $request->file_name,
                'file_size' => (int) $request->file_size,
                'total_chunks' => (int) $request->total_chunks,
                'received_chunks' => 0,
                'chunks' => [],
                'file_type' => $request->file_type ?? 'application/octet-stream',
                'task_id' => $request->task_id,
                'milestone_mapping_id' => $request->milestone_mapping_id,
                'start_time' => microtime(true),
            ];

            $chunkUploads = session()->get('chunk_uploads', []);
            $chunkUploads[$uploadId] = $uploadData;
            session()->put('chunk_uploads', $chunkUploads);

            return response()->json([
                'success' => true,
                'upload_id' => $uploadId,
                'chunk_size' => $this->chunkSize,
                'total_chunks' => (int) $request->total_chunks,
                'message' => 'Upload initialized',
            ]);
        } catch (\Exception $e) {
            Log::error('Init chunk upload failed: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'Failed to initialize upload: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Upload chunk for large file
     */
    public function uploadChunk(Request $request)
    {
        $request->validate([
            'upload_id' => 'required|string',
            'chunk' => 'required|file|max:' . ($this->chunkSize + 1024),
            'chunk_index' => 'required|integer',
        ]);

        try {
            $uploadId = $request->upload_id;
            $chunkUploads = session()->get('chunk_uploads', []);

            if (! isset($chunkUploads[$uploadId])) {
                return response()->json([
                    'success' => false,
                    'message' => 'Upload session expired or not found',
                ], 400);
            }

            $uploadData = $chunkUploads[$uploadId];
            $chunk = $request->file('chunk');
            $chunkIndex = (int) $request->chunk_index;

            $sessionId = session()->getId();
            $chunkDir = storage_path("app/temp/chunks/{$sessionId}/{$uploadId}");
            $chunkPath = $chunkDir . "/chunk_{$chunkIndex}.part";

            // Read chunk content and save
            $content = file_get_contents($chunk->getRealPath());
            file_put_contents($chunkPath, $content);

            $uploadData['received_chunks']++;
            $uploadData['chunks'][$chunkIndex] = $chunkPath;

            $chunkUploads[$uploadId] = $uploadData;
            session()->put('chunk_uploads', $chunkUploads);

            $progress = ($uploadData['received_chunks'] / $uploadData['total_chunks']) * 100;

            return response()->json([
                'success' => true,
                'received' => $uploadData['received_chunks'],
                'total' => $uploadData['total_chunks'],
                'progress' => round($progress, 2),
                'message' => "Chunk {$chunkIndex} uploaded",
            ]);
        } catch (\Exception $e) {
            Log::error('Chunk upload failed: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'Failed to upload chunk: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Finalize chunked upload and combine chunks
     */
    public function finalizeChunkUpload(Request $request)
    {
        $request->validate([
            'upload_id' => 'required|string',
        ]);

        try {
            $uploadId = $request->upload_id;
            $chunkUploads = session()->get('chunk_uploads', []);

            if (! isset($chunkUploads[$uploadId])) {
                return response()->json([
                    'success' => false,
                    'message' => 'Upload session expired or not found',
                ], 400);
            }

            $uploadData = $chunkUploads[$uploadId];

            if ($uploadData['received_chunks'] != $uploadData['total_chunks']) {
                return response()->json([
                    'success' => false,
                    'message' => 'Not all chunks received',
                    'received' => $uploadData['received_chunks'],
                    'expected' => $uploadData['total_chunks'],
                ], 400);
            }

            // Combine chunks
            $tempFile = $this->combineChunks($uploadData, $uploadId);

            // Store combined file info in session
            $tempUploads = session()->get('temp_uploads', []);
            $milestoneId = $uploadData['milestone_mapping_id'];
            $checklistId = $uploadData['checklist_id'];

            $fileInfo = [
                'temp_path' => $tempFile,
                'original_name' => $uploadData['file_name'],
                'size' => filesize($tempFile),
                'human_size' => $this->formatFileSize(filesize($tempFile)),
                'mime_type' => $uploadData['file_type'],
                'temp_file_name' => basename($tempFile),
            ];

            if (! isset($tempUploads[$milestoneId])) {
                $tempUploads[$milestoneId] = [];
            }
            if (! isset($tempUploads[$milestoneId][$checklistId])) {
                $tempUploads[$milestoneId][$checklistId] = [
                    'checklist_id' => $checklistId,
                    'checklist_name' => $uploadData['checklist_name'],
                    'files' => [],
                ];
            }

            $tempUploads[$milestoneId][$checklistId]['files'][] = $fileInfo;
            session()->put('temp_uploads', $tempUploads);

            // Clean up chunk data
            unset($chunkUploads[$uploadId]);
            session()->put('chunk_uploads', $chunkUploads);

            // Clean up chunk directory
            $sessionId = session()->getId();
            $chunkDir = storage_path("app/temp/chunks/{$sessionId}/{$uploadId}");
            if (is_dir($chunkDir)) {
                $this->deleteDirectory($chunkDir);
            }

            return response()->json([
                'success' => true,
                'message' => 'File uploaded successfully',
                'data' => [
                    'file' => $fileInfo,
                ],
            ]);
        } catch (\Exception $e) {
            Log::error('Finalize chunk upload failed: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'Failed to finalize upload: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Combine chunks into a single file
     */
    private function combineChunks($uploadData, $uploadId)
    {
        $sessionId = session()->getId();
        $tempFile = storage_path("app/temp/uploads/{$sessionId}/{$uploadId}_combined");
        $tempDir = dirname($tempFile);

        if (! file_exists($tempDir)) {
            mkdir($tempDir, 0777, true);
        }

        ksort($uploadData['chunks']);
        $output = fopen($tempFile, 'wb');

        if (! $output) {
            throw new \Exception('Failed to create temporary file');
        }

        try {
            foreach ($uploadData['chunks'] as $chunkPath) {
                if (! file_exists($chunkPath)) {
                    throw new \Exception("Chunk not found: {$chunkPath}");
                }

                $chunkHandle = fopen($chunkPath, 'rb');
                while (! feof($chunkHandle)) {
                    fwrite($output, fread($chunkHandle, 1024 * 1024));
                }
                fclose($chunkHandle);
            }

            fclose($output);

            return $tempFile;
        } catch (\Exception $e) {
            if (isset($output) && is_resource($output)) {
                fclose($output);
            }
            if (file_exists($tempFile)) {
                unlink($tempFile);
            }
            throw $e;
        }
    }

    /**
     * Save all attachments to Google Drive and Database using streaming upload
     */
    public function saveAllAttachmentsToDrive(Request $request)
    {
        $request->validate([
            'task_id' => 'required|integer',
            'mile_sno' => 'required|integer',
        ]);

        try {
            $taskId = $request->task_id;
            $milestoneId = $request->mile_sno;

            $tempUploads = session()->get('temp_uploads', []);

            if (! isset($tempUploads[$milestoneId]) || empty($tempUploads[$milestoneId])) {
                return response()->json([
                    'status' => 400,
                    'message' => 'No files to save. Please upload files first.',
                ], 400);
            }

            DB::beginTransaction();

            try {
                // Create or get main milestone folder in Google Drive
                $mainFolder = $this->getOrCreateMainMilestoneFolder($milestoneId, $taskId, null);

                $savedChecklists = [];

                foreach ($tempUploads[$milestoneId] as $checklistId => $checklistData) {
                    if (empty($checklistData['files'])) {
                        continue;
                    }

                    // Create or get checklist subfolder
                    $subFolder = $this->createOrGetChecklistSubfolder(
                        $mainFolder['folder_id'],
                        $checklistData['checklist_name'],
                        $checklistId,
                        $milestoneId,
                        $taskId
                    );

                    $uploadedFiles = [];
                    $totalSize = 0;

                    // Upload each file to Google Drive using streaming
                    foreach ($checklistData['files'] as $tempFile) {
                        if (! file_exists($tempFile['temp_path'])) {
                            continue;
                        }

                        $fileResult = $this->uploadFileToDriveStreaming(
                            $tempFile['temp_path'],
                            $tempFile['original_name'],
                            $tempFile['mime_type'],
                            $subFolder['folder_id']
                        );

                        $uploadedFile = [
                            'file_id' => $fileResult['file_id'],
                            'name' => $tempFile['original_name'],
                            'size' => $tempFile['size'],
                            'human_size' => $tempFile['human_size'],
                            'link' => $fileResult['link'],
                            'download_link' => $fileResult['download_link'],
                            'mime_type' => $tempFile['mime_type'],
                            'uploaded_at' => Carbon::now()->toISOString(),
                        ];

                        $uploadedFiles[] = $uploadedFile;
                        $totalSize += $tempFile['size'];

                        // Clean up temp file
                        if (file_exists($tempFile['temp_path'])) {
                            unlink($tempFile['temp_path']);
                        }
                    }

                    if (empty($uploadedFiles)) {
                        continue;
                    }

                    // Save to database
                    $existingMapping = DB::table('et_delivery_attachment_mapping')
                        ->where('milestone_mapping_id', $milestoneId)
                        ->where('task_id', $taskId)
                        ->where('checklist_id', $checklistId)
                        ->first();

                    if ($existingMapping) {
                        $existingFiles = json_decode($existingMapping->uploaded_files, true) ?: [];
                        $allFiles = array_merge($existingFiles, $uploadedFiles);

                        DB::table('et_delivery_attachment_mapping')
                            ->where('id', $existingMapping->id)
                            ->update([
                                'uploaded_files' => json_encode($allFiles),
                                'updated_at' => now(),
                            ]);
                    } else {
                        DB::table('et_delivery_attachment_mapping')->insert([
                            'task_id' => $taskId,
                            'milestone_mapping_id' => $milestoneId,
                            'checklist_id' => $checklistId,
                            'checklist_name' => $checklistData['checklist_name'],
                            'main_folder_id' => $mainFolder['folder_id'],
                            'main_folder_link' => $mainFolder['folder_link'],
                            'sub_folder_id' => $subFolder['folder_id'],
                            'sub_folder_link' => $subFolder['folder_link'],
                            'uploaded_files' => json_encode($uploadedFiles),
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);
                    }

                    $savedChecklists[] = $checklistData['checklist_name'];

                    // Update milestone folders table
                    $this->updateMilestoneFolderStats($milestoneId, $taskId, $mainFolder, $subFolder, $checklistId, $checklistData['checklist_name'], count($uploadedFiles), $totalSize);
                }

                // Clear session data for this milestone
                session()->forget("temp_uploads.{$milestoneId}");

                DB::commit();

                // Clean up empty directories
                $this->cleanupTempDirectories();

                return response()->json([
                    'status' => 200,
                    'message' => count($savedChecklists) . ' checklist(s) saved successfully!',
                    'data' => [
                        'saved_checklists' => $savedChecklists,
                        'main_folder_link' => $mainFolder['folder_link'],
                    ],
                ]);
            } catch (\Exception $e) {
                DB::rollBack();
                Log::error('Transaction failed: ' . $e->getMessage());
                throw $e;
            }
        } catch (\Exception $e) {
            Log::error('Save to Drive failed: ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Failed to save: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Upload file to Google Drive using streaming (memory efficient)
     */
    private function uploadFileToDriveStreaming($filePath, $fileName, $mimeType, $folderId = null)
    {
        try {
            $client = $this->getGoogleClient();
            $service = new Drive($client);

            $fileMetadata = new DriveFile(['name' => $fileName]);
            if ($folderId) {
                $fileMetadata->setParents([$folderId]);
            }

            // Use resumable upload with streaming
            $client->setDefer(true);
            $request = $service->files->create($fileMetadata);
            $client->setDefer(false);

            $fileSize = filesize($filePath);
            $chunkSizeBytes = $this->driveChunkSize;

            $media = new \Google\Http\MediaFileUpload(
                $client,
                $request,
                $mimeType,
                null,
                true,
                $chunkSizeBytes
            );

            $media->setFileSize($fileSize);

            $handle = fopen($filePath, 'rb');
            $status = false;

            while (! $status && ! feof($handle)) {
                $chunk = fread($handle, $chunkSizeBytes);
                $status = $media->nextChunk($chunk);
            }

            fclose($handle);

            if ($status && isset($status->id)) {
                $driveLink = $this->makeFilePublic($status->id);
                $downloadLink = 'https://drive.google.com/uc?export=download&id=' . $status->id;

                return [
                    'file_id' => $status->id,
                    'link' => $driveLink,
                    'download_link' => $downloadLink,
                ];
            }

            throw new \Exception('Upload failed - no file ID returned');
        } catch (\Exception $e) {
            Log::error('Upload to Drive failed: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Create or get main milestone folder in Google Drive
     */
    private function getOrCreateMainMilestoneFolder($milestoneId, $taskId, $milestoneName = null)
    {
        try {
            $existingMainFolder = DB::table('et_milestone_folders')
                ->where('milestone_mapping_id', $milestoneId)
                ->where('task_id', $taskId)
                ->first();

            if ($existingMainFolder && $existingMainFolder->main_folder_id) {
                return [
                    'folder_id' => $existingMainFolder->main_folder_id,
                    'folder_link' => $existingMainFolder->main_folder_link,
                    'folder_name' => $existingMainFolder->folder_name,
                ];
            }

            $folderName = $milestoneName ?: 'Milestone_' . $milestoneId . '_' . date('Ymd_His');
            $parentFolderId = env('GOOGLE_DRIVE_PARENT_FOLDER_ID');

            $client = $this->getGoogleClient();
            $service = new Drive($client);

            $folderMetadata = new DriveFile([
                'name' => $folderName,
                'mimeType' => 'application/vnd.google-apps.folder',
            ]);

            if ($parentFolderId) {
                $folderMetadata->setParents([$parentFolderId]);
            }

            $folder = $service->files->create($folderMetadata, ['fields' => 'id, name']);
            $folderId = $folder->id;
            $this->makeFolderPublic($folderId);

            DB::table('et_milestone_folders')->insert([
                'milestone_mapping_id' => $milestoneId,
                'task_id' => $taskId,
                'main_folder_id' => $folderId,
                'main_folder_link' => "https://drive.google.com/drive/folders/{$folderId}",
                'folder_name' => $folderName,
                'sub_folders' => json_encode([]),
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            return [
                'folder_id' => $folderId,
                'folder_link' => "https://drive.google.com/drive/folders/{$folderId}",
                'folder_name' => $folderName,
            ];
        } catch (\Exception $e) {
            Log::error('Get or create main folder failed: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Create or get subfolder for checklist item
     */
    private function createOrGetChecklistSubfolder($mainFolderId, $checklistName, $checklistId, $milestoneId, $taskId)
    {
        try {
            $existingMapping = DB::table('et_delivery_attachment_mapping')
                ->where('milestone_mapping_id', $milestoneId)
                ->where('task_id', $taskId)
                ->where('checklist_id', $checklistId)
                ->first();

            if ($existingMapping && $existingMapping->sub_folder_id) {
                return [
                    'folder_id' => $existingMapping->sub_folder_id,
                    'folder_link' => $existingMapping->sub_folder_link,
                ];
            }

            $client = $this->getGoogleClient();
            $service = new Drive($client);

            $folderMetadata = new DriveFile([
                'name' => $checklistName,
                'mimeType' => 'application/vnd.google-apps.folder',
                'parents' => [$mainFolderId],
            ]);

            $folder = $service->files->create($folderMetadata, ['fields' => 'id, name']);
            $folderId = $folder->id;
            $this->makeFolderPublic($folderId);

            return [
                'folder_id' => $folderId,
                'folder_link' => "https://drive.google.com/drive/folders/{$folderId}",
            ];
        } catch (\Exception $e) {
            Log::error('Create checklist subfolder failed: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Update milestone folder statistics
     */
    private function updateMilestoneFolderStats($milestoneId, $taskId, $mainFolder, $subFolder, $checklistId, $checklistName, $fileCount, $totalSize)
    {
        try {
            $allMappings = DB::table('et_delivery_attachment_mapping')
                ->where('milestone_mapping_id', $milestoneId)
                ->get();

            $totalFiles = 0;
            $totalSizeAll = 0;
            $subFolders = [];

            foreach ($allMappings as $mapping) {
                $files = json_decode($mapping->uploaded_files, true) ?: [];
                $totalFiles += count($files);
                foreach ($files as $file) {
                    $totalSizeAll += $file['size'];
                }
                $subFolders[$mapping->checklist_id] = [
                    'folder_id' => $mapping->sub_folder_id,
                    'folder_link' => $mapping->sub_folder_link,
                    'checklist_name' => $mapping->checklist_name,
                    'files_count' => count($files),
                ];
            }

            if (! isset($subFolders[$checklistId])) {
                $subFolders[$checklistId] = [
                    'folder_id' => $subFolder['folder_id'],
                    'folder_link' => $subFolder['folder_link'],
                    'checklist_name' => $checklistName,
                    'files_count' => $fileCount,
                ];
                $totalFiles += $fileCount;
                $totalSizeAll += $totalSize;
            }

            DB::table('et_milestone_folders')
                ->updateOrInsert(
                    ['milestone_mapping_id' => $milestoneId],
                    [
                        'task_id' => $taskId,
                        'main_folder_id' => $mainFolder['folder_id'],
                        'main_folder_link' => $mainFolder['folder_link'],
                        'folder_name' => $mainFolder['folder_name'],
                        'sub_folders' => json_encode($subFolders),
                        'total_files' => $totalFiles,
                        'total_size' => $totalSizeAll,
                        'updated_at' => now(),
                        'created_at' => DB::raw('COALESCE(created_at, NOW())'),
                    ]
                );
        } catch (\Exception $e) {
            Log::error('Update milestone stats failed: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Clean up temporary directories
     */
    private function cleanupTempDirectories()
    {
        $sessionId = session()->getId();
        $tempDir = storage_path("app/temp/uploads/{$sessionId}");

        if (is_dir($tempDir)) {
            $this->deleteDirectory($tempDir);
        }

        // Clean old temp files (older than 24 hours)
        $oldTempDirs = glob(storage_path('app/temp/uploads/*'));
        foreach ($oldTempDirs as $dir) {
            if (is_dir($dir) && (time() - filemtime($dir) > 86400)) {
                $this->deleteDirectory($dir);
            }
        }

        // Clean old chunk directories
        $oldChunkDirs = glob(storage_path('app/temp/chunks/*'));
        foreach ($oldChunkDirs as $dir) {
            if (is_dir($dir) && (time() - filemtime($dir) > 86400)) {
                $this->deleteDirectory($dir);
            }
        }
    }

    /**
     * Recursively delete directory
     */
    private function deleteDirectory($dir)
    {
        if (! file_exists($dir)) {
            return true;
        }

        if (! is_dir($dir)) {
            return unlink($dir);
        }

        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }

            if (! $this->deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }

        return rmdir($dir);
    }

    /**
     * Format file size
     */
    private function formatFileSize($bytes)
    {
        $bytes = (int) $bytes;
        $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return round($bytes, 2) . ' ' . $units[$i];
    }

    /**
     * Make folder PUBLIC
     */
    private function makeFolderPublic($folderId)
    {
        try {
            $client = $this->getGoogleClient();
            $service = new Drive($client);

            $permission = new Permission([
                'type' => 'anyone',
                'role' => 'reader',
                'allowFileDiscovery' => true,
            ]);

            $service->permissions->create($folderId, $permission, [
                'sendNotificationEmail' => false,
            ]);
        } catch (\Exception $e) {
            Log::warning('Failed to make folder public: ' . $e->getMessage());
        }
    }

    /**
     * Make file PUBLIC
     */
    private function makeFilePublic($fileId)
    {
        try {
            $client = $this->getGoogleClient();
            $service = new Drive($client);

            $permission = new Permission([
                'type' => 'anyone',
                'role' => 'reader',
            ]);

            $service->permissions->create($fileId, $permission);

            return "https://drive.google.com/file/d/{$fileId}/view";
        } catch (\Exception $e) {
            return "https://drive.google.com/file/d/{$fileId}/view";
        }
    }

    /**
     * Get Google Drive client
     */
    private function getGoogleClient()
    {
        $client = new Client();
        $client->setClientId(env('GOOGLE_DRIVE_CLIENT_ID'));
        $client->setClientSecret(env('GOOGLE_DRIVE_CLIENT_SECRET'));
        $client->refreshToken(env('GOOGLE_DRIVE_REFRESH_TOKEN'));
        $client->addScope(Drive::DRIVE);

        $client->setHttpClient(new \GuzzleHttp\Client([
            'verify' => false,
            'timeout' => 0,
            'read_timeout' => 0,
            'connect_timeout' => 300,
        ]));

        return $client;
    }

    /**
     * Fetch milestone data
     */
    public function fetch_milestone_data($id, $mileId)
    {
        $data = DB::table('et_customer_services')
            ->where('et_customer_services.sno', $id)
            ->where('et_customer_services.status', '!=', 2)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->select(
                'et_customer.cus_name',
                'et_customer.cus_mobile',
                'et_customer.customer_id',
                'et_product.product_name',
                'et_product_category.product_category_name',
                'et_customer_services.sno',
                'et_customer_services.variant_variable_ids'
            )
            ->first();

        if (! $data) {
            return response()->json([
                'status' => 404,
                'message' => 'No record found!',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        $items = json_decode($data->variant_variable_ids, true);

        $variantName = '';
        $variableName = '';

        if (is_array($items) && count($items) > 0) {
            $first = $items[0];

            $variant = DB::table('et_manage_product_variant')
                ->where('sno', $first['variant_id'])
                ->first();

            $variable = DB::table('et_manage_product_variable')
                ->where('sno', $first['variable_id'])
                ->first();

            $variantName = $variant->product_variant_name ?? '';
            $variableName = $variable->variable_name ?? '';
        }

        $data->variant_name = $variantName;
        $data->variable_name = $variableName;

        return response()->json([
            'status' => 200,
            'message' => 'Data fetched successfully!',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    /**
     * Show milestone folders page
     */
    public function ViewMilestoneFolders($mile_sno)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($mile_sno, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $data = explode('~', $decryptedValue);

        if (count($data) != 2) {
            return redirect()->back()->with('error', 'Invalid Data Format');
        }

        $taskId = $data[0];
        $mile_sno = $data[1];

        $milestoneFolders = DB::table('et_milestone_folders')
            ->where('milestone_mapping_id', $mile_sno)
            ->first();

        $checklistFiles = DB::table('et_delivery_attachment_mapping')
            ->where('milestone_mapping_id', $mile_sno)
            ->get();

        $milestoneDetails = DB::table('et_milestone_mapping')
            ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
            ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
            ->select(
                'et_milestone_mapping.service_id',
                'et_milestone_mapping.sno',
                'et_milestone_mapping.milestone_status',
                'et_milestone_mapping.task_ids',
                'et_payment_slot.payment_slot_name',
                'et_proposal_pay_slot.payable_amount',
                'et_proposal_pay_slot.paidAmount'
            )
            ->where('et_milestone_mapping.sno', $mile_sno)
            ->where('et_milestone_mapping.status', '!=', 2)
            ->where('et_milestone_mapping.milestone_status', 1)
            ->first();

        $servicesDetails = DB::table('et_customer_services')
            ->where('et_customer_services.sno', $taskId)
            ->where('et_customer_services.status', '!=', 2)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->select(
                'et_customer.cus_name',
                'et_customer.cus_mobile',
                'et_customer.customer_id',
                'et_product.product_name',
                'et_product_category.product_category_name',
                'et_customer_services.sno',
                'et_customer_services.variant_variable_ids'
            )
            ->first();

        if (! $servicesDetails) {
            return response()->json([
                'status' => 404,
                'message' => 'No record found!',
                'error_msg' => null,
                'services' => null,
            ], 404);
        }

        $items = json_decode($servicesDetails->variant_variable_ids, true);

        $variantName = '';
        $variableName = '';

        if (is_array($items) && count($items) > 0) {
            $first = $items[0];

            $variant = DB::table('et_manage_product_variant')
                ->where('sno', $first['variant_id'])
                ->first();

            $variable = DB::table('et_manage_product_variable')
                ->where('sno', $first['variable_id'])
                ->first();

            $variantName = $variant->product_variant_name ?? '';
            $variableName = $variable->variable_name ?? '';
        }

        $servicesDetails->variant_name = $variantName;
        $servicesDetails->variable_name = $variableName;

        return view('content.service_management.view-milestone-folders', compact('mile_sno', 'milestoneFolders', 'checklistFiles', 'milestoneDetails', 'servicesDetails'));
    }

    /**
     * Show milestone folders page (User View)
     */
    public function showMilestoneFolders($mile_sno)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($mile_sno, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $data = explode('~', $decryptedValue);

        if (count($data) != 2) {
            return redirect()->back()->with('error', 'Invalid Data Format');
        }

        $taskId = $data[0];
        $mile_sno = $data[1];

        $milestoneFolders = DB::table('et_milestone_folders')
            ->where('milestone_mapping_id', $mile_sno)
            ->first();

        $checklistFiles = DB::table('et_delivery_attachment_mapping')
            ->where('milestone_mapping_id', $mile_sno)
            ->get();

        $milestoneDetails = DB::table('et_milestone_mapping')
            ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
            ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
            ->select(
                'et_milestone_mapping.service_id',
                'et_milestone_mapping.sno',
                'et_milestone_mapping.milestone_status',
                'et_milestone_mapping.task_ids',
                'et_payment_slot.payment_slot_name',
                'et_proposal_pay_slot.payable_amount',
                'et_proposal_pay_slot.paidAmount'
            )
            ->where('et_milestone_mapping.sno', $mile_sno)
            ->where('et_milestone_mapping.status', '!=', 2)
            ->where('et_milestone_mapping.milestone_status', 1)
            ->first();

        $servicesDetails = DB::table('et_customer_services')
            ->where('et_customer_services.sno', $taskId)
            ->where('et_customer_services.status', '!=', 2)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->select(
                'et_customer.cus_name',
                'et_customer.cus_mobile',
                'et_customer.customer_id',
                'et_product.product_name',
                'et_product_category.product_category_name',
                'et_customer_services.sno',
                'et_customer_services.variant_variable_ids'
            )
            ->first();

        if (! $servicesDetails) {
            return response()->json([
                'status' => 404,
                'message' => 'No record found!',
                'error_msg' => null,
                'services' => null,
            ], 404);
        }

        $items = json_decode($servicesDetails->variant_variable_ids, true);

        $variantName = '';
        $variableName = '';

        if (is_array($items) && count($items) > 0) {
            $first = $items[0];

            $variant = DB::table('et_manage_product_variant')
                ->where('sno', $first['variant_id'])
                ->first();

            $variable = DB::table('et_manage_product_variable')
                ->where('sno', $first['variable_id'])
                ->first();

            $variantName = $variant->product_variant_name ?? '';
            $variableName = $variable->variable_name ?? '';
        }

        $servicesDetails->variant_name = $variantName;
        $servicesDetails->variable_name = $variableName;

        // Return the user view (different from admin view)
        return view('content.service_management.milestone-folders', compact('mile_sno', 'milestoneFolders', 'checklistFiles', 'milestoneDetails', 'servicesDetails'));
    }

    /**
     * Download single file with streaming to prevent memory issues
     */
    public function downloadFile($fileId)
    {
        try {
            $client = $this->getGoogleClient();
            $service = new Drive($client);

            $file = $service->files->get($fileId, ['fields' => 'name, mimeType, size']);

            // Get file size for content-length header
            $fileSize = $file->getSize();

            // Use streaming response for large files
            $response = $service->files->get($fileId, ['alt' => 'media']);
            $stream = $response->getBody();

            // Create a streamed response
            return response()->stream(function () use ($stream) {
                // Read and output in chunks
                while (!$stream->eof()) {
                    echo $stream->read(1024 * 1024); // Read 1MB chunks
                    ob_flush();
                    flush();
                }
            }, 200, [
                'Content-Type' => $file->getMimeType(),
                'Content-Disposition' => 'attachment; filename="' . $file->getName() . '"',
                'Content-Length' => $fileSize,
                'Cache-Control' => 'no-cache, must-revalidate',
            ]);
        } catch (\Exception $e) {
            Log::error('Download file failed: ' . $e->getMessage());

            if (request()->expectsJson()) {
                return response()->json(['error' => 'File not found'], 404);
            }

            return redirect()->back()->with('error', 'Failed to download file: ' . $e->getMessage());
        }
    }

    /**
     * Download checklist as ZIP - COMPLETELY FIXED
     */
    public function downloadChecklistZip($milestoneId, $checklistId)
    {
        try {
            $checklistData = DB::table('et_delivery_attachment_mapping')
                ->where('milestone_mapping_id', $milestoneId)
                ->where('checklist_id', $checklistId)
                ->first();

            if (!$checklistData || !$checklistData->uploaded_files) {
                if (request()->expectsJson()) {
                    return response()->json(['error' => 'No files found'], 404);
                }
                return redirect()->back()->with('error', 'No files found for this checklist');
            }

            $files = json_decode($checklistData->uploaded_files, true);
            if (empty($files)) {
                if (request()->expectsJson()) {
                    return response()->json(['error' => 'No files found'], 404);
                }
                return redirect()->back()->with('error', 'No files found for this checklist');
            }

            $zipFileName = preg_replace('/[^a-zA-Z0-9]/', '_', $checklistData->checklist_name) . '_' . date('Ymd_His') . '.zip';

            // Create temp directory
            $tempDir = storage_path('app/temp/zip_' . uniqid());
            if (!file_exists($tempDir)) {
                mkdir($tempDir, 0777, true);
            }

            $tempZip = $tempDir . '/archive.zip';

            // Create ZIP file
            $zip = new ZipArchive();
            if ($zip->open($tempZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
                @rmdir($tempDir);
                throw new \Exception('Cannot create ZIP file');
            }

            $client = $this->getGoogleClient();
            $service = new Drive($client);

            $addedFiles = 0;
            $tempFiles = [];

            foreach ($files as $file) {
                $tempFile = null;
                try {
                    // Stream download from Google Drive
                    $response = $service->files->get($file['file_id'], ['alt' => 'media']);
                    $stream = $response->getBody();

                    $tempFile = tempnam($tempDir, 'file_');
                    $tempFiles[] = $tempFile;

                    $handle = fopen($tempFile, 'wb');

                    while (!$stream->eof()) {
                        fwrite($handle, $stream->read(5 * 1024 * 1024));
                    }
                    fclose($handle);

                    $zip->addFile($tempFile, $file['name']);
                    $addedFiles++;
                } catch (\Exception $e) {
                    Log::error('Failed to add file: ' . $e->getMessage());
                    continue;
                }
            }

            $zip->close();

            // Clean up temp files
            foreach ($tempFiles as $tempFile) {
                if (file_exists($tempFile)) {
                    @unlink($tempFile);
                }
            }

            if ($addedFiles == 0) {
                if (file_exists($tempZip)) {
                    @unlink($tempZip);
                }
                @rmdir($tempDir);
                throw new \Exception('No files could be added to ZIP');
            }

            // Verify ZIP file exists
            if (!file_exists($tempZip) || filesize($tempZip) == 0) {
                throw new \Exception('ZIP file not created or empty');
            }

            // Return download response with auto-delete
            return response()->download($tempZip, $zipFileName, [
                'Content-Type' => 'application/zip',
                'Content-Disposition' => 'attachment; filename="' . $zipFileName . '"',
                'Cache-Control' => 'no-cache, must-revalidate',
            ])->deleteFileAfterSend(true);
        } catch (\Exception $e) {
            Log::error('Download checklist ZIP failed: ' . $e->getMessage());

            if (request()->expectsJson()) {
                return response()->json(['error' => 'Failed to create ZIP file: ' . $e->getMessage()], 500);
            }

            return redirect()->back()->with('error', 'Failed to create ZIP file: ' . $e->getMessage());
        }
    }

    /**
     * Download milestone as ZIP using streaming for large files - COMPLETELY FIXED
     */
    public function downloadMilestoneZip($milestoneId)
    {
        try {
            // Get all checklists with files
            $checklists = DB::table('et_delivery_attachment_mapping')
                ->where('milestone_mapping_id', $milestoneId)
                ->get();

            if ($checklists->isEmpty()) {
                if (request()->expectsJson()) {
                    return response()->json(['error' => 'No files found'], 404);
                }
                return redirect()->back()->with('error', 'No files found for this milestone');
            }

            // Calculate total size and file count
            $totalSize = 0;
            $totalFiles = 0;
            $fileList = [];

            foreach ($checklists as $checklist) {
                $files = json_decode($checklist->uploaded_files, true) ?: [];
                foreach ($files as $file) {
                    $totalSize += $file['size'];
                    $totalFiles++;
                    $fileList[] = [
                        'checklist_name' => $checklist->checklist_name,
                        'file' => $file
                    ];
                }
            }

            $zipFileName = 'Milestone_' . $milestoneId . '_' . date('Ymd_His') . '.zip';

            // Create temp directory outside the stream callback
            $tempDir = storage_path('app/temp/zip_' . uniqid());
            if (!file_exists($tempDir)) {
                mkdir($tempDir, 0777, true);
            }

            $tempZip = $tempDir . '/archive.zip';

            // Create ZIP file first
            $zip = new ZipArchive();
            if ($zip->open($tempZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
                @rmdir($tempDir);
                throw new \Exception('Cannot create ZIP file');
            }

            $client = $this->getGoogleClient();
            $service = new Drive($client);

            $processedFiles = 0;
            $tempFiles = [];

            foreach ($fileList as $item) {
                $file = $item['file'];
                $folderName = preg_replace('/[^a-zA-Z0-9]/', '_', $item['checklist_name']);
                $tempFile = null;

                try {
                    // Stream download from Google Drive
                    $response = $service->files->get($file['file_id'], ['alt' => 'media']);
                    $stream = $response->getBody();

                    // Create temporary file for this file
                    $tempFile = tempnam($tempDir, 'file_');
                    $tempFiles[] = $tempFile;

                    $tempHandle = fopen($tempFile, 'wb');

                    // Download file in chunks
                    while (!$stream->eof()) {
                        $chunk = $stream->read(5 * 1024 * 1024); // 5MB chunks
                        fwrite($tempHandle, $chunk);
                    }
                    fclose($tempHandle);

                    // Add to ZIP with folder structure
                    $zip->addFile($tempFile, $folderName . '/' . $file['name']);
                    $processedFiles++;
                } catch (\Exception $e) {
                    Log::error('Failed to add file to ZIP: ' . $e->getMessage(), [
                        'file' => $file['name'] ?? 'unknown',
                        'milestone_id' => $milestoneId
                    ]);
                    continue;
                }
            }

            // Close the ZIP file
            $zip->close();

            // Clean up all temporary downloaded files
            foreach ($tempFiles as $tempFile) {
                if (file_exists($tempFile)) {
                    @unlink($tempFile);
                }
            }

            // Check if any files were added
            if ($processedFiles == 0) {
                if (file_exists($tempZip)) {
                    @unlink($tempZip);
                }
                @rmdir($tempDir);
                throw new \Exception('No files could be added to ZIP');
            }

            // Verify ZIP file exists and is readable
            if (!file_exists($tempZip) || !is_readable($tempZip) || filesize($tempZip) == 0) {
                throw new \Exception('ZIP file not found or empty');
            }

            // Return the file as a download response
            return response()->download($tempZip, $zipFileName, [
                'Content-Type' => 'application/zip',
                'Content-Disposition' => 'attachment; filename="' . $zipFileName . '"',
                'Cache-Control' => 'no-cache, must-revalidate',
                'Pragma' => 'public',
                'Expires' => '0',
            ])->deleteFileAfterSend(true);
        } catch (\Exception $e) {
            Log::error('Download milestone ZIP failed: ' . $e->getMessage(), [
                'milestone_id' => $milestoneId,
                'trace' => $e->getTraceAsString()
            ]);

            if (request()->expectsJson()) {
                return response()->json(['error' => 'Failed to create ZIP file: ' . $e->getMessage()], 500);
            }

            return redirect()->back()->with('error', 'Failed to create ZIP file: ' . $e->getMessage());
        }
    }

    /**
     * Delete file from Google Drive and database
     */
    public function deleteFile($fileId, $milestoneId, $checklistId, $fileIndex, Request $request)
    {
        try {
            DB::beginTransaction();

            // Get the checklist mapping
            $mapping = DB::table('et_delivery_attachment_mapping')
                ->where('milestone_mapping_id', $milestoneId)
                ->where('checklist_id', $checklistId)
                ->first();

            if (!$mapping) {
                throw new \Exception('File record not found');
            }

            // Decode uploaded files
            $uploadedFiles = json_decode($mapping->uploaded_files, true) ?: [];

            // Check if file exists at the given index
            if (!isset($uploadedFiles[$fileIndex])) {
                throw new \Exception('File not found in records');
            }

            $fileToDelete = $uploadedFiles[$fileIndex];
            $driveFileId = $fileToDelete['file_id'];
            $fileName = $fileToDelete['name'];

            // Delete from Google Drive - WITH ERROR HANDLING
            $driveDeleted = false;
            $driveError = null;

            try {
                $client = $this->getGoogleClient();
                $service = new Drive($client);

                // First, check if the file exists in Google Drive
                try {
                    $fileExists = $service->files->get($driveFileId, ['fields' => 'id']);
                    if ($fileExists) {
                        // Remove all permissions (public access)
                        try {
                            $permissions = $service->permissions->listPermissions($driveFileId);
                            foreach ($permissions->getPermissions() as $permission) {
                                if ($permission->getType() === 'anyone') {
                                    $service->permissions->delete($driveFileId, $permission->getId());
                                }
                            }
                        } catch (\Exception $e) {
                            Log::warning('Failed to remove permissions: ' . $e->getMessage());
                        }

                        // Delete the file from Google Drive
                        $service->files->delete($driveFileId);
                        $driveDeleted = true;
                        Log::info('File deleted from Google Drive', ['file_id' => $driveFileId, 'file_name' => $fileName]);
                    }
                } catch (\Exception $e) {
                    // File doesn't exist in Drive or can't be accessed
                    $driveError = $e->getMessage();
                    Log::warning('Google Drive file not found or inaccessible: ' . $driveError);
                    // Continue - we'll still remove from database
                }
            } catch (\Exception $e) {
                $driveError = $e->getMessage();
                Log::error('Google Drive delete failed: ' . $e->getMessage());
                // Continue - we'll still remove from database
            }

            // Remove file from the array
            array_splice($uploadedFiles, $fileIndex, 1);

            // Update database
            DB::table('et_delivery_attachment_mapping')
                ->where('id', $mapping->id)
                ->update([
                    'uploaded_files' => json_encode($uploadedFiles),
                    'updated_at' => now()
                ]);

            // Update milestone folder statistics
            $this->updateMilestoneFolderStatsAfterDelete($milestoneId, $mapping->task_id, $checklistId);

            DB::commit();

            // Prepare success message
            $message = $driveDeleted
                ? "File '{$fileName}' deleted successfully from Google Drive and database."
                : ($driveError
                    ? "File '{$fileName}' removed from database. Note: Could not delete from Google Drive: {$driveError}"
                    : "File '{$fileName}' removed from database.");
            $message .= "By - " . $request->user()->user_name;
            // Log success
            Log::info('File deleted successfully', [
                'file_id' => $driveFileId,
                'file_name' => $fileName,
                'message' => $message,
                'milestone_id' => $milestoneId,
                'checklist_id' => $checklistId,
                'drive_deleted' => $driveDeleted
            ]);

            if (request()->expectsJson()) {
                return response()->json([
                    'success' => true,
                    'message' => $message,
                    'drive_deleted' => $driveDeleted
                ]);
            }

            return redirect()->back()->with('success', $message);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Delete file failed: ' . $e->getMessage());

            if (request()->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to delete file: ' . $e->getMessage()
                ], 500);
            }

            return redirect()->back()->with('error', 'Failed to delete file: ' . $e->getMessage());
        }
    }

    /**
     * Update milestone folder statistics after file deletion
     */
    private function updateMilestoneFolderStatsAfterDelete($milestoneId, $taskId, $checklistId)
    {
        try {
            $allMappings = DB::table('et_delivery_attachment_mapping')
                ->where('milestone_mapping_id', $milestoneId)
                ->get();

            $totalFiles = 0;
            $totalSizeAll = 0;
            $subFolders = [];

            foreach ($allMappings as $mapping) {
                $files = json_decode($mapping->uploaded_files, true) ?: [];
                $fileCount = count($files);
                $totalFiles += $fileCount;

                foreach ($files as $file) {
                    $totalSizeAll += $file['size'];
                }

                $subFolders[$mapping->checklist_id] = [
                    'folder_id' => $mapping->sub_folder_id,
                    'folder_link' => $mapping->sub_folder_link,
                    'checklist_name' => $mapping->checklist_name,
                    'files_count' => $fileCount,
                ];
            }

            DB::table('et_milestone_folders')
                ->where('milestone_mapping_id', $milestoneId)
                ->update([
                    'total_files' => $totalFiles,
                    'total_size' => $totalSizeAll,
                    'sub_folders' => json_encode($subFolders),
                    'updated_at' => now(),
                ]);
        } catch (\Exception $e) {
            Log::error('Update milestone stats after delete failed: ' . $e->getMessage());
            // Don't throw - we don't want to rollback the main transaction
        }
    }
    /**
     * Get milestone statistics for AJAX updates
     */
    public function getMilestoneStats($milestoneId)
    {
        try {
            $milestoneFolders = DB::table('et_milestone_folders')
                ->where('milestone_mapping_id', $milestoneId)
                ->first();

            if (!$milestoneFolders) {
                return response()->json([
                    'success' => false,
                    'message' => 'Milestone not found'
                ], 404);
            }

            return response()->json([
                'success' => true,
                'total_files' => $milestoneFolders->total_files ?? 0,
                'total_size' => $this->formatFileSize($milestoneFolders->total_size ?? 0)
            ]);
        } catch (\Exception $e) {
            Log::error('Get milestone stats failed: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to get stats'
            ], 500);
        }
    }
    /**
     * Static method to format file size (for use in Blade)
     */
    public static function formatFileSizeStatic($bytes)
    {
        $bytes = (int) $bytes;
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return round($bytes, 2) . ' ' . $units[$i];
    }
    /**
     * Delete entire checklist folder and all its files
     */
    public function deleteFolder($milestoneId, $checklistId, Request $request)
    {
        try {
            DB::beginTransaction();

            // Get the checklist mapping
            $mapping = DB::table('et_delivery_attachment_mapping')
                ->where('milestone_mapping_id', $milestoneId)
                ->where('checklist_id', $checklistId)
                ->first();

            if (!$mapping) {
                throw new \Exception('Folder not found');
            }

            $files = json_decode($mapping->uploaded_files, true) ?: [];
            $deletedFiles = 0;
            $failedFiles = 0;

            // Delete all files from Google Drive
            $client = $this->getGoogleClient();
            $service = new Drive($client);

            foreach ($files as $file) {
                try {
                    // Check if file exists in Drive
                    $driveFileId = $file['file_id'];
                    try {
                        $service->files->get($driveFileId, ['fields' => 'id']);
                        // Delete the file
                        $service->files->delete($driveFileId);
                        $deletedFiles++;
                    } catch (\Exception $e) {
                        // File doesn't exist in Drive
                        Log::warning('File not found in Drive: ' . $driveFileId);
                        $deletedFiles++; // Still count as deleted from DB
                    }
                } catch (\Exception $e) {
                    $failedFiles++;
                    Log::error('Failed to delete file from Drive: ' . $e->getMessage());
                }
            }

            // Delete the subfolder from Google Drive
            try {
                $service->files->delete($mapping->sub_folder_id);
                Log::info('Subfolder deleted from Drive', ['folder_id' => $mapping->sub_folder_id]);
            } catch (\Exception $e) {
                Log::warning('Failed to delete subfolder from Drive: ' . $e->getMessage());
            }

            // Delete from database
            DB::table('et_delivery_attachment_mapping')
                ->where('id', $mapping->id)
                ->delete();

            // Update milestone folder statistics
            $this->updateMilestoneFolderStatsAfterDelete($milestoneId, $mapping->task_id, $checklistId);

            DB::commit();

            $message = "Folder '{$mapping->checklist_name}' deleted successfully. {$deletedFiles} file(s) removed.";

            Log::info('Folder deleted successfully. By - ' . $request->user()->user_name, [
                'milestone_id' => $milestoneId,
                'checklist_id' => $checklistId,
                'deleted_files' => $deletedFiles,
                'failed_files' => $failedFiles
            ]);

            if (request()->expectsJson()) {
                return response()->json([
                    'success' => true,
                    'message' => $message,
                    'deleted_files' => $deletedFiles
                ]);
            }

            return redirect()->back()->with('success', $message);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Delete folder failed: ' . $e->getMessage());

            if (request()->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to delete folder: ' . $e->getMessage()
                ], 500);
            }

            return redirect()->back()->with('error', 'Failed to delete folder: ' . $e->getMessage());
        }
    }
}
