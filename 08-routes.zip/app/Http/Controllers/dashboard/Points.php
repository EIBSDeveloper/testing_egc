<?php
// app/Http/Controllers/dashboard/Points.php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PointsModel;
use Illuminate\Support\Facades\Validator;

class Points extends Controller
{
    public function index()
    {
        $pointsList = PointsModel::where('status', '!=', 2)->orderBy('sno', 'asc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        
        return view('content.dashboard.points', [
            'pointsList' => $pointsList,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function List()
    {
        $points = PointsModel::where('status', 0)->orderBy('points_name', 'ASC')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $points
        ], 200);
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'points_name' => 'required|string|max:255',
            'points' => 'required|integer',
            'description' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        // Check if points name already exists
        $chk = PointsModel::where('points_name', ucwords($request->points_name))
            ->where('status', '!=', 2)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Points Name Already Exists!'
            ]);
            return redirect()->back();
        }

        $user_id = $request->user()->user_id ?? 'system';

        $add_points = new PointsModel();
        $add_points->points_name = ucwords($request->points_name);
        $add_points->points = $request->points;
        $add_points->comments = $request->comments;
        $add_points->status = 0; // Active by default
        $add_points->created_by = $user_id;
        $add_points->updated_by = $user_id;
        $add_points->save();

        if ($add_points) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Points Added Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the Points!'
            ]);
        }

        return redirect()->back();
    }

    public function Edit($id)
    {
        $editPoints = PointsModel::where('sno', $id)->first();
        
        if (!$editPoints) {
            return redirect()->back()->with('error', 'Points not found!');
        }

        return response([
            'status' => 200,
            'data' => $editPoints
        ]);
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_points_name' => 'required|string|max:255',
            'edit_points' => 'required|integer',
            'edit_description' => 'nullable|string',
            'edit_id' => 'required|integer'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        // Check if points name already exists (excluding current record)
        $chk = PointsModel::where('points_name', ucwords($request->edit_points_name))
            ->where('sno', '!=', $request->edit_id)
            ->where('status', '!=', 2)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Points Name Already Exists!'
            ]);
            return redirect()->back();
        }

        $updatePoints = PointsModel::where('sno', $request->edit_id)->first();
        
        if (!$updatePoints) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Points record not found!'
            ]);
            return redirect()->back();
        }

        $updatePoints->points_name = ucwords($request->edit_points_name);
        $updatePoints->points = $request->edit_points;
        $updatePoints->comments = $request->edit_description;
        $updatePoints->updated_by = $request->user()->user_id ?? 'system';
        $updatePoints->save();

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Points Updated Successfully!'
        ]);

        return redirect()->back();
    }

    public function Status($id, Request $request)
    {
        $points = PointsModel::where('sno', $id)->first();
        
        if (!$points) {
            return response([
                'status' => 404,
                'message' => 'Points not found!',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        $points->status = $request->input('status', 0);
        $points->updated_by = $request->user()->user_id ?? 'system';
        $points->save();

        return response([
            'status' => 200,
            'message' => 'Status Updated Successfully!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}