<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use App\Http\Controllers\user_management\ManageUsers;
use App\Http\Controllers\user_management\UserRole;
use App\Models\BranchModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\NotificationModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use App\Models\IpConfigModel;
use Illuminate\Support\Facades\Cache;
use Jenssegers\Agent\Agent;
use Carbon\Carbon;

class Notification extends Controller
{

    public function getNotificationsForUser($whom)
    {
        // Step 1: Fetch notifications where 'whom' matches the specified user
        $notifications = NotificationModel::where('whom', $whom)
            ->where('status', '!=', 2) // Assuming status 0 means active
            ->orderBy('notification_date', 'desc')
            ->get();
        $count = NotificationModel::where('whom', $whom)
            ->where('status', 0) // Assuming status 0 means active
            ->orderBy('notification_date', 'desc')
            ->get();
        // Step 2: Get count of active notifications
        $notificationsCount = $count->count();

        // Step 3: Format the notifications
        $formattedNotifications = $notifications->map(function ($notification) {
            return [
                'notification_content' => $notification->notification_content,
                'status' => $notification->status,
                 'sno' => $notification->sno,
                'time_ago' => $this->formatTimeAgo($notification->notification_date),
            ];
        });

        return response()->json([
            'notifications' => $formattedNotifications,
            'count' => $notificationsCount,
        ]);
    }
    public function getNotificationsForUser_single($whom)
    {
        // Step 1: Fetch notifications where 'whom' matches the specified user
        $notifications = NotificationModel::where('whom', $whom)
            ->where('status', '!=', 2) // Assuming status 0 means active
            ->where('not_send_status', 0) // Assuming status 0 means active
            ->orderBy('notification_date', 'desc')
            ->first();
        if($notifications){
        $notifications->time_ago = $this->formatTimeAgo($notifications->notification_date);
        }

        return response()->json([
            'notifications' => $notifications,
        ]);
    }

    // Mark all notifications as read (status = 1)
    public function markAllAsRead($whom)
    {
        NotificationModel::where('whom', $whom)
            ->where('status', 0)
            ->update(['status' => 1]);

        return response()->json(['message' => 'All notifications marked as read']);
    }

    // Clear all notifications (status = 2)
    public function clearAllNotifications($whom)
    {
        NotificationModel::where('whom', $whom)
            ->where('status', '<>', 2) // Update all non-cleared notifications
            ->update(['status' => 2]);

        return response()->json(['message' => 'All notifications cleared']);
    }
    
    public function clearNotifications($whom, $id)
    {
        NotificationModel::where('whom', $whom)
            ->where('sno', $id) // Update all non-cleared notifications
            ->update(['status' => 2]);

        return response()->json(['message' => 'All notifications cleared']);
    }
    
    public function clearNotificationsnot_send($whom, $id)
    {
        NotificationModel::where('whom', $whom)
            ->where('sno', $id) // Update all non-cleared notifications
            ->update(['not_send_status' => 2]);

        return response()->json(['message' => 'All notifications cleared']);
    }

    /**
     * Format a given date to "time ago" format.
     *
     * @param string $date
     * @return string
     */
    private function formatTimeAgo($date)
    {
        $notificationDate = Carbon::parse($date);
        return $notificationDate->diffForHumans();
    }
}