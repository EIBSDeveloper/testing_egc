<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use App\Models\JustDialModel;
use App\Models\WebsiteleadModel;
// use App\Models\SulekhaModel;
use App\Models\BranchModel;
use App\Models\SmsTemplateModel;
use App\Models\EmailTemplateModel;
use App\Models\LeadModel;
use App\Models\LeadTransferLogModel;
use App\Mail\ETPLMail;
use Illuminate\Support\Facades\Mail;
// use App\Models\UrbanProModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;


class OtherSourceLead extends Controller
{
  public function justdial(Request $request)
  {
    // http://erp.elysium.academy/justdial?leadid=JD57154BC2A4E7&leadtype=category&prefix=Ms&name=HIRAL&mobile=9820097546&phone=02224100086&email=&date=2012-06-22&category=Taxi+Services&area=Dadar+West&city=Mumbai&brancharea=Andheri+East&dncmobile=1&dncphone=0&company>>

    // Extract parameters from the URL
    $lead_id = $request->query('leadid');
    $lead_type = $request->query('leadtype');
    $prefix = $request->query('prefix');
    $name = $request->query('name');
    $mobile = $request->query('mobile');
    $phone = $request->query('phone');
    $email = $request->query('email');
    $date = $request->query('date');
    $category = $request->query('category');
    $area = $request->query('area');
    $city = $request->query('city');
    $branch_area = $request->query('brancharea');
    $dncmobile = $request->query('dncmobile');
    $dncphone = $request->query('dncphone');
    $company = $request->query('company');
    $pincode = $request->query('pincode');
    $time = $request->query('time');
    $branchpin = $request->query('branchpin');
    $parentid = $request->query('parentid');
    
    $existsInLead = DB::table('et_lead')
        ->where('lead_mobile', $mobile)
        ->exists();

    if ($existsInLead) {
        return response()->json([
            'status' => 409,
            'message' => 'Mobile Number Already Exists',
        ], 409);
    }
    
    $chk = JustDialModel::where('lead_mobile', $mobile)->where('status', '!=', 2)->first();

    if ($chk) {
      return response()->json([
        'status' => 409,
        'message' => 'Mobile Number Already Exists',
      ], 409);
    } else {

      // If the lead doesn't exist, create it
      $add_category = new JustDialModel();
      $add_category->lead_id = $lead_id;
      $add_category->lead_name = ucfirst($name);
      $add_category->lead_mobile = $mobile;
      $add_category->lead_type = $lead_type;
      $add_category->lead_alternate_mobile = $phone;
      $add_category->lead_email_id = $email;
      $add_category->prefix = $prefix;
      $add_category->registered_date = $date;
      $add_category->state = $city;
      $add_category->city = $area;
      $add_category->area = $branch_area;
      $add_category->dnc_mobile = $dncmobile;
      $add_category->dnc_phone = $dncphone;
      $add_category->company = $company;
      $add_category->pincode = $pincode;
      $add_category->lead_knowledge_tags = $category;
      $add_category->time = $time;
      $add_category->branchpin = $branchpin;
      $add_category->parentid = $parentid;
      // return $add_category;
      $add_category->save();
    }
    return response()->json([
      'status' => 200,
      'message' => 'Received',
    ], 200);
  }

    public function website_lead(Request $request)
    {
        
        // https://erp.elysiumtechnologies.com/PhDiZone_website_lead?name=testuerpc&mobile=9874563210&email=test@gmail.com
        // Extract parameters from the URL
        $name = $request->query('name');
        $mobile = $request->query('mobile');
        $email = $request->query('email');
        $branchpin = 1;
    
        // Check if the mobile number already exists
        $chk = WebsiteleadModel::where('lead_mobile', $mobile)->exists();
    
        if ($chk) {
            return response()->json([
                'status' => 409,
                'message' => 'Mobile Number Already Exists',
            ], 409);
        }
        
        $lead_mob_chk  = LeadModel::where('lead_mobile', $mobile)->exists();
         if ($lead_mob_chk) {
            return response()->json([
                'status' => 409,
                'message' => 'Mobile Number Already Exists',
            ], 409);
        }
        $lead_mail = LeadModel::where('lead_email_id', $email)->exists();
        
         if ($lead_mail) {
            return response()->json([
                'status' => 409,
                'message' => 'Mail ID Already Exists',
            ], 409);
        }
    
        // If the lead doesn't exist, create it
        $add_category_web = new WebsiteleadModel();
        $add_category_web->lead_name = ucfirst($name);
        $add_category_web->lead_mobile = $mobile;
        $add_category_web->lead_mail = $email;
        $add_category_web->branch_id = $branchpin;
        $add_category_web->save();
        
        // return $add_category_web;
        
        $branch_get = BranchModel::select('sno', 'other_src_staff_id')
         ->where('sno', $branchpin)
         ->first();
        $leadstaff = DB::table('et_lead_source_mapping')->where('branch_id',$branchpin)->where('source_id',5)->first();
        if($leadstaff){
            $branch_get->other_src_staff_id = $leadstaff->staff_id;
        }
        if ($branch_get && $branch_get->other_src_staff_id) {

         $branch_sno = $branch_get->sno;
         $lead_mobile = $add_category_web->lead_mobile;
         $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 2;

         $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
         $branch_code = $branch_check->city_short_code ?? 'MDU';

         $year = date("Y");
         $category_check = LeadModel::where('status', '!=', 2)
           ->orderBy('sno', 'desc')
           ->first();

         if (!$category_check) {
           $lead_id = "{$year}/{$branch_code}/LED0001";
         } else {
           $last_lead_id = $category_check->lead_id;
           $slice = explode("/", $last_lead_id);
           $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
           $next_number = (int)$resultcus + 1;
           $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
         }

         $add_category = new LeadModel();
         $add_category->lead_id = $lead_id;
         $add_category->lead_name = ucfirst($add_category_web->lead_name);
         $add_category->lead_mobile = $lead_mobile;
         $add_category->lead_email_id = $add_category_web->lead_mail;
         $add_category->registered_date = date('Y-m-d');
         $add_category->branch_id = $branch_sno;
         $add_category->entity_id = $branch_sno;
         $add_category->lead_source_id = 5;
         $add_category->website_id = $add_category_web->sno;
         $add_category->created_by = $lead_othr_src_staff;
         $add_category->updated_by = $lead_othr_src_staff;
         $add_category->lead_status_id = 1;
         $add_category->lead_condition = 2;

         if ($add_category->save()) {
           $add_history = new LeadTransferLogModel();
           $add_history->lead_id = $add_category->sno;
           $add_history->branch_id = $add_category->branch_id;
           $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
           $add_history->current_staff_id = $add_category->created_by;
           $add_history->change_staff_id = 0;
           $add_history->end_date = null;
           $add_history->transferred_from = 13;
           $add_history->created_by = $lead_othr_src_staff;
           $add_history->updated_by = $lead_othr_src_staff;
           $add_history->save();

          $lead_update = WebsiteleadModel::where('sno', $add_category_web->sno)->first();
          $lead_update->status = 2;
          $lead_update->save();
         }

         $branch_data = BranchModel::where('sno', $branch_sno)->first();
         $branch_name = " ";
         if ($branch_data->branch_type == 1) {
           $branch_name = $branch_data->branch_name;
         } elseif ($branch_data->branch_type == 2) {
           $branch_name = $branch_data->franchise_name;
         }
         $lead_name = ucfirst($add_category->lead_name);
         $lead_email_id = $add_category->lead_email_id;
         $lead_mobile = $add_category->lead_mobile;
         
         
         $entityData='';
        // communication Send
        $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$lead_othr_src_staff)->first();
        $communicationStatus=DB::table('et_communication_handle')->where('module_name','Lead Welcome')->first();
            if($communicationStatus && $communicationStatus->status == 0){
            // // sms thank you lead
            if($communicationStatus->sms ==0){
                if ($add_category && $lead_mobile) {
    
              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', 'PhDiZone_Enquiry_Thankyou_Message')->first();
              $authkey = $result_sms ? $result_sms->authkey : '';
              $sender_id = $result_sms ? $result_sms->sender_id : '';
              $template_id = $result_sms ? $result_sms->template_id : '';
              $country_code = $result_sms ? $result_sms->country_code : '';
              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
              $mobile_number = $country_code . $lead_mobile;
    
              $cre_mobile = $branch_data->cre_mobile ?? '9677781155';
    
              // Replace placeholders with actual values
              $replacement_values = [$lead_name,$branch_name, $cre_mobile];
              $message_content = preg_replace_callback(
                '/\{#var#\}/',
                function () use (&$replacement_values) {
                  return array_shift($replacement_values);
                },
                $message_content
              );
    
              $route = "default";
              $postData = array(
                'authkey' => $authkey,
                'mobiles' => $mobile_number,
                'message' => $message_content,
                'sender' => $sender_id,
                'route' => $route,
              );
    
              // API URL
              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
    
              // Initialize the resource
              $ch = curl_init();
              curl_setopt_array($ch, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $postData,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
              ));
    
              // Get response
              $response = curl_exec($ch);
              // return $response;
              $err = curl_error($ch);
              curl_close($ch);
            }
            }
            // // Thank you email send
            if($communicationStatus->email ==0){
                if ($add_category && $lead_email_id) {
              $email_template_id = 2; // thank you template
              $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                $dynamicSubject = str_replace('#entity_name','Elysium Technology', $emailTemplate->email_name);
              $content = $emailTemplate->email_subject;
              $content = str_replace('#lead_name', $lead_name, $content);
              $branchNo = $branch_data->mobile;
              $branchemail = $branch_data->mail;
              $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/PhDiZone/';
              $instaLink = $branch_data->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
              $content = str_replace('#sales_mobile', $cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile, $content);
              $content = str_replace('#cre_mobile', $branch_data->cre_mobile ?? '8220011465', $content);
              $url= 'phdizone.com';
              $mailData = [
                          'url'         => $url,
                          'subject'     => $dynamicSubject,
                          'content'     => $content,
                          'branchNo'    => $branchNo,
                          'branchemail' => $branchemail, // Use the message content from the request
                          'fbLink'      => $fbLink,      // Use the message content from the request
                          'instaLink'   => $instaLink,   // Use the message content from the request
                          'salesMobile' => $branch_data->cre_mobile ?? '9003400111',
                      ];
    
                $to_address = $lead_email_id;
                $from_address = 'elysiumtechnology@elysium.community';
                $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
        
                Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
            }
        }
            // // Thank You whatsapp message
            if($communicationStatus->whatsapp ==0){
                if ($add_category && $lead_mobile) {
                  $templateName = "welcome_msg_phdizone";
        
                  $hasHeader  = false; // Example flag: set based on template
                  $hasBody    = false; // Example flag: set based on template
                  $hasFooter  = false; // Example flag: set based on template
                  $hasButton  = false;
                  $components = [];
                  $couponCode = " ";
                  date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                  $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                  // $currentHour = date('H'); // Get current hour in 24-hour format
                  if ($currentHour >= 5 && $currentHour < 12) {
                    $greeting = 'Good Morning';
                  } elseif ($currentHour >= 12 && $currentHour < 18) {
                    $greeting = 'Good Afternoon';
                  } else {
                    $greeting = 'Good Evening';
                  }
        
                  if ($templateName == 'welcome_msg_phdizone') {
        
                    $headerImage = 'https://dev.erp.elysiumtechnologies.com/public/assets/phdizone_images/Thank-You.jpg';
                    $couponCode  = 'NOOFFER';
                    $buttonIndex = 0;
                    $bodyText    = [
                      [
                        'type'           => 'text',
                        'text'           => $lead_name,
                        'parameter_name' => 'lead_name',
                      ],
                       [
                        'type'           => 'text',
                        'text'           => $cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile,
                        'parameter_name' => 'sales_numbers',
                      ]
                      
                    ];
                    $hasHeader = true;
                    $hasBody   = true;
                  }
        
                  // Add Header if required
                  if ($hasHeader) {
                    $components[] = [
                      'type'       => 'header',
                      'parameters' => [
                        [
                          'type'  => 'image',
                          'image' => [
                            'link' => $headerImage, // Dynamically set header image
                          ],
                        ],
                      ],
                    ];
                  }
        
                  // Add Body if required
                  if ($hasBody) {
                    $components[] = [
                      'type'       => 'body',
                      'parameters' => $bodyText,
                    ];
                  }
        
                  // Add Footer if required
                  if ($hasFooter) {
                    $components[] = [
                      'type'       => 'footer',
                      'parameters' => [
                        [
                          'type'           => 'text',
                          'text'           => 'This is the footer text.',
                          'parameter_name' => 'footer_text',
                        ],
                      ],
                    ];
                  }
        
                  // Add Button if required
                  if ($hasButton) {
                    $components[] = [
                      'type'       => 'button',
                      'sub_type'   => 'copy_code',
                      'index'      => $buttonIndex,
                      'parameters' => [
                        [
                          'type'        => 'coupon_code',
                          'coupon_code' => $couponCode,
                        ],
                      ],
                    ];
                  }
        
                  $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch_data->entity_id)->orderBy('sno', 'desc')->first();
                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                $accessToken               = $whatsappApi->access_tokken ?? '';
                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
        
                  $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
    
                    $inter_calls = '91';
                   $countryCode  = $inter_calls ? ($inter_calls == 0 ? '+91' : '+' . $inter_calls) : '+91';
                    $to           = $lead_mobile;
                    $languageCode = 'en';
        
                    if (strpos($to, $countryCode) !== 0) {
                        $to = $countryCode . $to;
                    }
        
                  $message = 'test~message';
                  if (empty($components)) {
                    $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                        'name'     => $templateName,
                        'language' => [
                          'code' => $languageCode,
                        ],
                      ],
                    ];
                  } else {
                    $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                        'name'       => $templateName,
                        'language'   => [
                          'code' => $languageCode,
                        ],
                        'components' => $components,
                      ],
                    ];
                  }
    
              $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                }
            }
        }
         
       }
    
        return response()->json([
            'status' => 200,
            'message' => 'Lead Created Successfully',
        ], 200);
    }
    
    public function website_lead_pro(Request $request)
    {
        
        // https://erp.elysiumtechnologies.com/PhDiZone_website_lead?name=testuerpc&mobile=9874563210&email=test@gmail.com
        // Extract parameters from the URL
        $name = $request->query('name');
        $mobile = $request->query('mobile');
        $email = $request->query('email');
        $branchpin = 2;
    
        // Check if the mobile number already exists
        $chk = WebsiteleadModel::where('lead_mobile', $mobile)->exists();
    
        if ($chk) {
            return response()->json([
                'status' => 409,
                'message' => 'Mobile Number Already Exists',
            ], 409);
        }
        
        $lead_mob_chk  = LeadModel::where('lead_mobile', $mobile)->exists();
         if ($lead_mob_chk) {
            return response()->json([
                'status' => 409,
                'message' => 'Mobile Number Already Exists',
            ], 409);
        }
        $lead_mail = LeadModel::where('lead_email_id', $email)->exists();
        
         if ($lead_mail) {
            return response()->json([
                'status' => 409,
                'message' => 'Mail ID Already Exists',
            ], 409);
        }
    
        // If the lead doesn't exist, create it
        $add_category_web = new WebsiteleadModel();
        $add_category_web->lead_name = ucfirst($name);
        $add_category_web->lead_mobile = $mobile;
        $add_category_web->lead_mail = $email;
        $add_category_web->branch_id = $branchpin;
        $add_category_web->save();
        
        // return $add_category_web;
        
        $branch_get = BranchModel::select('sno', 'other_src_staff_id')
         ->where('sno', $branchpin)
         ->first();
         $leadstaff = DB::table('et_lead_source_mapping')->where('branch_id',$branchpin)->where('source_id',17)->first();
        if($leadstaff){
            $branch_get->other_src_staff_id = $leadstaff->staff_id;
        }
        if ($branch_get && $branch_get->other_src_staff_id) {

         $branch_sno = $branch_get->sno;
         $lead_mobile = $add_category_web->lead_mobile;
         $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 2;

         $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
         $branch_code = $branch_check->city_short_code ?? 'MDU';

         $year = date("Y");
         $category_check = LeadModel::where('status', '!=', 2)
           ->orderBy('sno', 'desc')
           ->first();

         if (!$category_check) {
           $lead_id = "{$year}/{$branch_code}/LED0001";
         } else {
           $last_lead_id = $category_check->lead_id;
           $slice = explode("/", $last_lead_id);
           $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
           $next_number = (int)$resultcus + 1;
           $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
         }

         $add_category = new LeadModel();
         $add_category->lead_id = $lead_id;
         $add_category->lead_name = ucfirst($add_category_web->lead_name);
         $add_category->lead_mobile = $lead_mobile;
         $add_category->lead_email_id = $add_category_web->lead_mail;
         $add_category->registered_date = date('Y-m-d');
         $add_category->branch_id = $branch_sno;
         $add_category->entity_id = $branch_sno;
         $add_category->lead_source_id = 5;
         $add_category->website_id = $add_category_web->sno;
         $add_category->created_by = $lead_othr_src_staff;
         $add_category->updated_by = $lead_othr_src_staff;
         $add_category->lead_status_id = 1;
         $add_category->lead_condition = 2;
        // return $add_category;
         if ($add_category->save()) {
           $add_history = new LeadTransferLogModel();
           $add_history->lead_id = $add_category->sno;
           $add_history->branch_id = $add_category->branch_id;
           $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
           $add_history->current_staff_id = $add_category->created_by;
           $add_history->change_staff_id = 0;
           $add_history->end_date = null;
           $add_history->transferred_from = 13;
           $add_history->created_by = $lead_othr_src_staff;
           $add_history->updated_by = $lead_othr_src_staff;
           $add_history->save();

          $lead_update = WebsiteleadModel::where('sno', $add_category_web->sno)->first();
          $lead_update->status = 2;
          $lead_update->save();
         }

         $branch_data = BranchModel::where('sno', $branch_sno)->first();
         $branch_name = " ";
         if ($branch_data->branch_type == 1) {
           $branch_name = $branch_data->branch_name;
         } elseif ($branch_data->branch_type == 2) {
           $branch_name = $branch_data->franchise_name;
         }
         $lead_name = ucfirst($add_category->lead_name);
         $lead_email_id = $add_category->lead_email_id;
         $lead_mobile = $add_category->lead_mobile;
         
         
         $entityData='';
        // communication Send
        $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$lead_othr_src_staff)->first();
        $communicationStatus=DB::table('et_communication_handle')->where('module_name','Lead Welcome')->first();
            if($communicationStatus && $communicationStatus->status == 0){
            // // sms thank you lead
            if($communicationStatus->sms ==0){
                if ($add_category && $lead_mobile) {
    
              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', 'PhDiZone_Enquiry_Thankyou_Message')->first();
              $authkey = $result_sms ? $result_sms->authkey : '';
              $sender_id = $result_sms ? $result_sms->sender_id : '';
              $template_id = $result_sms ? $result_sms->template_id : '';
              $country_code = $result_sms ? $result_sms->country_code : '';
              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
              $mobile_number = $country_code . $lead_mobile;
    
              $cre_mobile = $branch_data->cre_mobile ?? '9677781155';
    
              // Replace placeholders with actual values
              $replacement_values = [$lead_name,$branch_name, $cre_mobile];
              $message_content = preg_replace_callback(
                '/\{#var#\}/',
                function () use (&$replacement_values) {
                  return array_shift($replacement_values);
                },
                $message_content
              );
    
              $route = "default";
              $postData = array(
                'authkey' => $authkey,
                'mobiles' => $mobile_number,
                'message' => $message_content,
                'sender' => $sender_id,
                'route' => $route,
              );
    
              // API URL
              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
    
              // Initialize the resource
              $ch = curl_init();
              curl_setopt_array($ch, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $postData,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
              ));
    
              // Get response
              $response = curl_exec($ch);
              // return $response;
              $err = curl_error($ch);
              curl_close($ch);
            }
            }
            // // Thank you email send
            if($communicationStatus->email ==0){
                if ($add_category && $lead_email_id) {
              $email_template_id = 2; // thank you template
              $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                $dynamicSubject = str_replace('#entity_name','Elysium Technology', $emailTemplate->email_name);
              $content = $emailTemplate->email_subject;
              $content = str_replace('#lead_name', $lead_name, $content);
              $branchNo = $branch_data->mobile;
              $branchemail = $branch_data->mail;
              $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/PhDiZone/';
              $instaLink = $branch_data->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
              $content = str_replace('#sales_mobile', $cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile, $content);
              $content = str_replace('#cre_mobile', $branch_data->cre_mobile ?? '8220011465', $content);
              $url= 'phdizone.com';
              $mailData = [
                          'url'         => $url,
                          'subject'     => $dynamicSubject,
                          'content'     => $content,
                          'branchNo'    => $branchNo,
                          'branchemail' => $branchemail, // Use the message content from the request
                          'fbLink'      => $fbLink,      // Use the message content from the request
                          'instaLink'   => $instaLink,   // Use the message content from the request
                          'salesMobile' => $branch_data->cre_mobile ?? '9003400111',
                      ];
    
                $to_address = $lead_email_id;
                $from_address = 'elysiumtechnology@elysium.community';
                $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
        
                Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
            }
        }
            // // Thank You whatsapp message
            if($communicationStatus->whatsapp ==0){
                if ($add_category && $lead_mobile) {
                  $templateName = "welcome_msg_phdizone";
        
                  $hasHeader  = false; // Example flag: set based on template
                  $hasBody    = false; // Example flag: set based on template
                  $hasFooter  = false; // Example flag: set based on template
                  $hasButton  = false;
                  $components = [];
                  $couponCode = " ";
                  date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                  $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                  // $currentHour = date('H'); // Get current hour in 24-hour format
                  if ($currentHour >= 5 && $currentHour < 12) {
                    $greeting = 'Good Morning';
                  } elseif ($currentHour >= 12 && $currentHour < 18) {
                    $greeting = 'Good Afternoon';
                  } else {
                    $greeting = 'Good Evening';
                  }
        
                  if ($templateName == 'welcome_msg_phdizone') {
        
                    $headerImage = 'https://dev.erp.elysiumtechnologies.com/public/assets/phdizone_images/Thank-You.jpg';
                    $couponCode  = 'NOOFFER';
                    $buttonIndex = 0;
                    $bodyText    = [
                      [
                        'type'           => 'text',
                        'text'           => $lead_name,
                        'parameter_name' => 'lead_name',
                      ],
                       [
                        'type'           => 'text',
                        'text'           => $cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile,
                        'parameter_name' => 'sales_numbers',
                      ]
                      
                    ];
                    $hasHeader = true;
                    $hasBody   = true;
                  }
        
                  // Add Header if required
                  if ($hasHeader) {
                    $components[] = [
                      'type'       => 'header',
                      'parameters' => [
                        [
                          'type'  => 'image',
                          'image' => [
                            'link' => $headerImage, // Dynamically set header image
                          ],
                        ],
                      ],
                    ];
                  }
        
                  // Add Body if required
                  if ($hasBody) {
                    $components[] = [
                      'type'       => 'body',
                      'parameters' => $bodyText,
                    ];
                  }
        
                  // Add Footer if required
                  if ($hasFooter) {
                    $components[] = [
                      'type'       => 'footer',
                      'parameters' => [
                        [
                          'type'           => 'text',
                          'text'           => 'This is the footer text.',
                          'parameter_name' => 'footer_text',
                        ],
                      ],
                    ];
                  }
        
                  // Add Button if required
                  if ($hasButton) {
                    $components[] = [
                      'type'       => 'button',
                      'sub_type'   => 'copy_code',
                      'index'      => $buttonIndex,
                      'parameters' => [
                        [
                          'type'        => 'coupon_code',
                          'coupon_code' => $couponCode,
                        ],
                      ],
                    ];
                  }
        
                  $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch_data->entity_id)->orderBy('sno', 'desc')->first();
                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                $accessToken               = $whatsappApi->access_tokken ?? '';
                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
        
                  $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
    
                    $inter_calls = '91';
                   $countryCode  = $inter_calls ? ($inter_calls == 0 ? '+91' : '+' . $inter_calls) : '+91';
                    $to           = $lead_mobile;
                    $languageCode = 'en';
        
                    if (strpos($to, $countryCode) !== 0) {
                        $to = $countryCode . $to;
                    }
        
                  $message = 'test~message';
                  if (empty($components)) {
                    $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                        'name'     => $templateName,
                        'language' => [
                          'code' => $languageCode,
                        ],
                      ],
                    ];
                  } else {
                    $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                        'name'       => $templateName,
                        'language'   => [
                          'code' => $languageCode,
                        ],
                        'components' => $components,
                      ],
                    ];
                  }
    
              $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                }
            }
        }
         
       }
    
        return response()->json([
            'status' => 200,
            'message' => 'Lead Created Successfully',
        ], 200);
    }

  // public function urbanpro(Request $request)
  // {

  //   // http://erp.elysium.academy/urbanpro?secretkey=1234&name=Rosini&PhoneNumber=698745123&location=SomeLocation&localityDetails=SomeArea&topicName=Maths&cityName=Madurai&created=2012-04-26&description=newlead


  //   $lead_id = $request->query('secretkey');
  //   $name = $request->query('name');
  //   $mobile = $request->query('PhoneNumber');
  //   $phone = $request->query('PhoneNumber');
  //   $date = $request->query('created');
  //   $category = $request->query('topicName');
  //   $state = $request->query('cityName');
  //   $pincode = $request->query('localityWithPinCode');
  //   $location = $request->query('localityDetails');
  //   $class_location = $request->query('classLocation');
  //   $desc = $request->query('description');

  //   // Check if lead already exists
  //   $chk = UrbanProModel::where('lead_mobile', $mobile)->where('status', '!=', 2)->first();

  //   if ($chk) {
  //     return response()->json([
  //       'status' => 409,
  //       'message' => 'Mobile Number Already Exists',
  //     ], 409);
  //   }

  //   // Create new lead
  //   $add_category = new UrbanProModel();
  //   $add_category->lead_id = $lead_id;
  //   $add_category->lead_name = ucfirst($name);
  //   $add_category->lead_mobile = $mobile;
  //   $add_category->lead_alternate_mobile = $phone;
  //   $add_category->registered_date = $date ?? now(); // Use current timestamp if not provided
  //   $add_category->state = $state;
  //   $add_category->city = $location;
  //   $add_category->category = $category;
  //   $add_category->pincode = $pincode;
  //   $add_category->classLocation = $class_location;
  //   $add_category->description = $desc;

  //   $add_category->save(); // Save the record

  //   return response()->json([
  //     'status' => 200,
  //     'message' => 'Lead Created Successfully',
  //   ], 200);
  // }

  // public function sulekha(Request $request)
  // {

  //   // http://erp.elysium.academy/sulekha?userName=Kavitha&userMobile=698745123&userEmail=kavitha@info.org&userCity=madurai&userLocalities=kknagar&userComments=surfing&keywords=digitalmarketing


  //     $name = $request->query('userName');
  //     $mobile = $request->query('userMobile');
  //     $email = $request->query('userEmail');
  //     $state = $request->query('userCity');
  //     $city = $request->query('userLocalities');
  //     $desc = $request->query('userComments');
  //     $category = $request->query('keywords');
  //     $branch_id = $request->query('branchId');

  //     // Check if lead already exists
  //     $chk = SulekhaModel::where('lead_mobile', $mobile)->where('status', '!=', 2)->first();

  //     if ($chk) {
  //         return response()->json([
  //             'status' => 409,
  //             'message' => 'Mobile Number Already Exists',
  //         ], 409);
  //     }

  //     // Create new lead
  //     $add_category = new SulekhaModel();
  //     $add_category->lead_name = ucfirst($name);
  //     $add_category->lead_mobile = $mobile;
  //     $add_category->lead_email = $email;
  //     $add_category->state = $state;
  //     $add_category->city = $city;
  //     $add_category->category = $category;
  //     $add_category->description = $desc;
  //     $add_category->branch_id = $branch_id;

  //     $add_category->save(); // Save the record

  //     return response()->json([
  //         'status' => 200,
  //         'message' => 'Lead Added Successfully',
  //     ], 200);
  // }
  
  private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }


}
