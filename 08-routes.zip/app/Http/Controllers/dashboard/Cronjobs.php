<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use App\Http\Controllers\exam_management\ManageAssessment;
use App\Mail\EAPLMail;
use App\Mail\ETPLMail;
use Illuminate\Support\Facades\File;
use App\Models\AppointmentModel;
use App\Models\AttendanceModel;
use App\Models\BatchExtensionModel;
use App\Models\BatchModel;
use App\Models\Batch_staff_swap_Model;
use App\Models\BranchModel;
use App\Models\Communication_config_Model;
use App\Models\CustomerModel;
use App\Models\GoalSetTeamModel;
use App\Models\EmailTemplateModel;
use App\Models\GoalSetStaffModel;
use App\Models\LeadModel;
use App\Models\SulekhaModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\PaymentModel;
use App\Models\Schedule_message_model;
use App\Models\SmsTemplateModel;
use App\Models\StaffAttendanceModel;
use App\Models\ManageCoursesModel;
use App\Models\StaffModel;
use App\Models\CallTrackerModel;
use App\Models\CugManagementModel;
use App\Models\StaffRescheduleModel;
use App\Models\LeadTransferLogModel;
use App\Models\JustDialModel;
use App\Models\DepartmentModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TrainingModel;
use App\Models\HotLeadModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\UserRolePermissionModel;
use App\Models\WhatsappApiConfigureModel;
use App\Models\GeneralSettingsModel;
use App\Models\CronjobMonitorModel;
use App\Models\CronjobLogModel;
use App\Models\ExamProcessModel;
use App\Services\DoubletickService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;

use App\Models\ManageQuestionBankModel;
use App\Models\ManageQuestionModel;
use App\Models\AIQuestionModel;
use App\Models\JournalHistoryModel;
use App\Services\ChatGPTService;
use App\Models\TaskLogModel;



class Cronjobs extends Controller
{

  protected $doubletickService;

  protected $client;
  protected $accessToken;
  protected $businessId;
  protected $baseUrl;
  protected $phoneNumberId;
  protected $chatGPTService;

  // public function __construct(DoubletickService $doubletickService, ChatGPTService $chatGPTService)
  // {
  //   $this->doubletickService = $doubletickService;
  //   $whatsappConfig = WhatsappApiConfigureModel::where('sno', 3)->first();
  //   $this->phoneNumberId = $whatsappConfig->phonenumber_id; // Set your access token in the environment file
  //   $this->accessToken = $whatsappConfig->access_tokken; // Set your access token in the environment file
  //   $this->baseUrl = 'https://graph.facebook.com/v17.0';
  //   $this->businessId = $whatsappConfig->waba_id;
  //   $this->chatGPTService = $chatGPTService;
  // }

  // public function Cronjob_payment_remainder(Request $request)
  // {

  //   // --- Session Cleanup ---
  //   $sessionPath = storage_path('framework/sessions');
  //   $files = File::allFiles($sessionPath);

  //   foreach ($files as $file) {
  //     try {
  //       if (File::lastModified($file) < now()->subMinutes(config('session.lifetime'))->getTimestamp()) {
  //         File::delete($file);
  //         $this->info("Deleted expired session file: {$file->getFilename()}");
  //       }
  //     } catch (\Exception $e) {
  //       // Log or ignore if the file was not found
  //       // \Log::warning("Failed to check/delete session file: {$file->getPathname()} - " . $e->getMessage());
  //     }
  //   }

  //   // Get the current date
  //   $today = now(); // Current date
  //   $lastDayOfMonth = now()->endOfMonth(); // Last day of the current month
  //   $helper = new \App\Helpers\Helpers();
  //   // return $today;
  //   // Get the number of days to send the reminder
  //   $send_message_before = $helper->general_setting_data()->payment_remainder ?? 1;
  //   $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

  //   // Calculate the date to compare with nextPayDate
  //   $reminderDate = date('Y-m-d', strtotime($today->copy()->addDays($send_message_before)));

  //   // return $reminderDate;

  //   // Fetch payments where the nextPayDate is equal to the calculated reminder date and status is 0
  //   $payments = PaymentModel::where('status', 0)
  //     ->whereDate('nextPayDate', $reminderDate)
  //     ->orderBy('nextPayDate', 'asc')
  //     ->get();

  //   // return $payments;
  //   //   Send Communication
  //   foreach ($payments as $i => $pay) {

  //     $customer         = CustomerModel::where('sno', $pay->customer_id)->first();
  //     $customer_mobiles = isset($customer->cus_mobile) ? $customer->cus_mobile : '';
  //     $customer_mails   = isset($customer->cus_email_id) ? $customer->cus_email_id : '';
  //     $customer_names   = isset($customer->cus_name) ? $customer->cus_name : 'Mr/Mrs';
  //     $cre_mobile       = isset($branch_data->cre_mobile) ? $branch_data->cre_mobile : '9677781155';
  //     $totalAmount      = $pay->amount + $pay->gst_amount;

  //     $paymentAmt       = number_format($totalAmount, 2, '.', ',');
  //     $totalAmount      = $paymentAmt . ". Rs";
  //     $duedate          = date($common_date_format, strtotime($pay->nextPayDate));
  //     $pay_course_id    = $pay->course_id ?? 1;

  //     $branch_data = BranchModel::where('sno', $pay->branch_id)->first();
  //     $branch_name = " ";
  //     if ($branch_data->branch_type == 1) {
  //       $branch_name = $branch_data->branch_name;
  //     } elseif ($branch_data->branch_type == 2) {
  //       $branch_name = $branch_data->franchise_name;
  //     }

  //     // Test Static values
  //     //   $customer_mails   = 'vetri4vijayan@gmail.com';
  //     //   $customer_mobiles = '';

  //     //sms
  //     if ($customer && $customer_mobiles) {
  //       $result_sms_pay  = SmsTemplateModel::where('status', 0)->where('template_name', '006_PaymentRemainder')->first();
  //       $authkey         = $result_sms_pay ? $result_sms_pay->authkey : '';
  //       $sender_id       = $result_sms_pay ? $result_sms_pay->sender_id : '';
  //       $template_id     = $result_sms_pay ? $result_sms_pay->template_id : '';
  //       $country_code    = $result_sms_pay ? $result_sms_pay->country_code : '';
  //       $message_content = $result_sms_pay ? $result_sms_pay->sms_template_messagecontent : '';
  //       $mobile_number   = $country_code . $customer_mobiles;
  //       $cre_no          = $branch_data->cre_mobile ?? '9677781155';

  //       // Replace placeholders with actual values
  //       $replacement_values = [$customer_names, $duedate, $cre_no];
  //       $message_content    = preg_replace_callback(
  //         '/\{#var#\}/',
  //         function () use (&$replacement_values) {
  //           return array_shift($replacement_values);
  //         },
  //         $message_content
  //       );

  //       $route    = "default";
  //       $postData = [
  //         'authkey' => $authkey,
  //         'mobiles' => $mobile_number,
  //         'message' => $message_content,
  //         'sender'  => $sender_id,
  //         'route'   => $route,
  //       ];

  //       // API URL
  //       $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

  //       // Initialize the resource
  //       $ch = curl_init();
  //       curl_setopt_array($ch, [
  //         CURLOPT_URL            => $url,
  //         CURLOPT_RETURNTRANSFER => true,
  //         CURLOPT_POST           => true,
  //         CURLOPT_POSTFIELDS     => $postData,
  //         CURLOPT_SSL_VERIFYHOST => 0,
  //         CURLOPT_SSL_VERIFYPEER => 0,
  //       ]);
  //       // Get response
  //       $response = curl_exec($ch);
  //       // return $response;
  //       $err = curl_error($ch);
  //       curl_close($ch);
  //     }
  //     // Email
  //     if ($customer && $customer_mails) {
  //       // return 'each working';
  //       $cre = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
  //       $email_template_id = 9; // thank you template
  //       $emailTemplate     = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
  //       $coursename        = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();
  //       $dynamicSubject    = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
  //       $content     = $emailTemplate->email_subject;
  //       $content     = str_replace('#name', $customer_names, $content);
  //       $content     = str_replace('#course', 'Java Full Stack', $content);
  //       $content     = str_replace('#amount', $totalAmount, $content);
  //       $content     = str_replace('#dueDate', $duedate, $content);
  //       $content     = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

  //       $branchNo           = $branch_data->mobile ?? '9677781155';
  //       $branchemail        = $branch_data->mail ?? 'info@elysiumacademy.org';
  //       $fbLink             = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
  //       $instaLink          = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
  //       $content            = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
  //       $content            = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

  //       $mailData = [
  //         'url'         => 'Eapl.com',
  //         'subject'     => $dynamicSubject,
  //         'content'     => $content,
  //         'branchNo'    => $branchNo,
  //         'branchemail' => $branchemail, // Use the message content from the request
  //         'fbLink'      => $fbLink,      // Use the message content from the request
  //         'instaLink'   => $instaLink,   // Use the message content from the request
  //         'salesMobile' => $branch_data->sales_mobile,
  //       ];

  //       $to_address   = $customer_mails;
  //       $from_address = 'elysiumacademy@elysium.community';
  //       $from_name    = 'Elysium AcademyÂ®';
  //       Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
  //     }
  //     //   $customer_mobiles = '7639093063';
  //     // Whatapp
  //     if ($customer && $customer_mobiles) {

  //       $coursename = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();
  //       $cre        = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
  //       $hasHeader  = false; // Example flag: set based on template
  //       $hasBody    = false; // Example flag: set based on template
  //       $components = [];
  //       $couponCode = " ";

  //       // Example flag: set based on template
  //       $components_trans = [];
  //       date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
  //       $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
  //       // $currentHour = date('H'); // Get current hour in 24-hour format
  //       if ($currentHour >= 5 && $currentHour < 12) {
  //         $greeting = 'Good Morning';
  //       } elseif ($currentHour >= 12 && $currentHour < 18) {
  //         $greeting = 'Good Afternoon';
  //       } else {
  //         $greeting = 'Good Evening';
  //       }
  //       $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
  //       $paymentDate        = date($common_date_format);


  //       $templateName = 'elysium_academy_pay_reminder2';
  //       $headerImage  = 'https://erp.elysium.academy/public/assets/eapl_images/Payment_success.jpg';
  //       $bodyText     = [
  //         [
  //           'type'           => 'text',
  //           'text'           => $greeting,
  //           'parameter_name' => 'greet_msg',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $customer_names,
  //           'parameter_name' => 'customer_name',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $coursename->course_name ?? 'Course',
  //           'parameter_name' => 'course_name',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $totalAmount,
  //           'parameter_name' => 'amount',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $duedate,
  //           'parameter_name' => 'due_date',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $cre->nick_name ?? 'Elsa',
  //           'parameter_name' => 'cre_name',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
  //           'parameter_name' => 'contact_email',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $branch_name ?? 'Elysium Academy',
  //           'parameter_name' => 'branch_name',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $branch_data->sales_mobile ?? '9677781155',
  //           'parameter_name' => 'contact_no',
  //         ],

  //       ];
  //       $components_trans[] = [
  //         'type'       => 'header',
  //         'parameters' => [
  //           [
  //             'type'  => 'image',
  //             'image' => [
  //               'link' => $headerImage, // Dynamically set header image
  //             ],
  //           ],
  //         ],
  //       ];

  //       $components_trans[] = [
  //         'type'       => 'body',
  //         'parameters' => $bodyText,
  //       ];
  //       $dynamicParameters         = $templateParameters[$templateName] ?? [];
  //       $WhatsAppBusinessAccountId = $this->businessId;
  //       $accessToken               = $this->accessToken;
  //       $fromPhoneNumberId         = $this->phoneNumberId;

  //       $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

  //       $to           = $customer_mobiles;
  //       $languageCode = 'en';

  //       if (strpos($to, '+91') !== 0) {
  //         $to = '+91' . $to;
  //       }

  //       $message = 'test~message';

  //       $payload = [
  //         'messaging_product' => 'whatsapp',
  //         'to'                => $to,
  //         'type'              => 'template',
  //         'template'          => [
  //           'name'       => $templateName,
  //           'language'   => [
  //             'code' => $languageCode,
  //           ],
  //           'components' => $components_trans,
  //         ],
  //       ];

  //       $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
  //     }
  //   }



  //   return $payments;
  // }

  private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }

  //  private function sendEmail($template_id, $entity, $type)
  //  {
  //    $emailTemplate = EmailTemplateModel::find($template_id);
  //    if (! $emailTemplate) {
  //      // Log::error("Email Template not found for ID: {$update->email_template_id}");
  //      return;
  //    }

  //    // Dynamically map the fields based on the type
  //    $name     = $type === 'lead' ? $entity->lead_name : $entity->cus_name;
  //    $email    = $type === 'lead' ? $entity->lead_email_id : $entity->cus_email_id;
  //    $gender   = $type === 'lead' ? $entity->lead_gender : $entity->cus_gender;
  //    $contact2 = $type === 'lead' ? $entity->phone_number : $entity->cus_phone_number;

  //    // $branchMobile = BranchModel::find($entity->branch_id)?->mobile; // Assuming branch_id exists in both tables
  //    $branch_data = BranchModel::where('sno', $entity->branch_id)->first();
  //    $branch_name = " ";
  //    if ($branch_data->branch_type == 1) {
  //      $branch_name = $branch_data->branch_name;
  //    } elseif ($branch_data->branch_type == 2) {
  //      $branch_name = $branch_data->franchise_name;
  //    }

  //    // $coursename = ManageCoursesModel::where('status', 0)->where('sno', $courseArray)->first();

  //    // $dynamicSubject = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
  //    $dynamicSubject = str_replace('#course', 'Java Full stack', $emailTemplate->email_name);

  //    // $helper             = new \App\Helpers\Helpers();
  //    // $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
  //    // $paymentDate        = date($common_date_format);
  //    // $paymentAmt         = number_format($totalAmount, 2, '.', ',');
  //    // $paymentAmount      = $paymentAmt . ". Rs";
  //    $content     = $emailTemplate->email_subject;
  //    $content     = str_replace('#name', "Raja", $content);
  //    $content     = str_replace('#course', 'Java Full Stack', $content);
  //    $content     = str_replace('#amount', "5000.Rs", $content);
  //    $content     = str_replace('#dueDate', "26-Jan-2025", $content);
  //    $content     = str_replace('#mail', 'info@elysiumacademy.org', $content);
  //    $branchNo    = $branch_data->mobile ?? "67865787545";
  //    $branchemail = $branch_data->mail ?? "hfghdgh";
  //    $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
  //    $instaLink   = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
  //    $content     = str_replace('#CRENo', $branch_data->cre_mobile ?? 'Branch Mobile', $content);
  //    $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

  //    $mailData = [
  //      'url'         => 'Eapl.com',
  //      'subject'     => $dynamicSubject,
  //      'content'     => $content,
  //      'branchNo'    => $branchNo,
  //      'branchemail' => $branchemail, // Use the message content from the request
  //      'fbLink'      => $fbLink,      // Use the message content from the request
  //      'instaLink'   => $instaLink,   // Use the message content from the request
  //      'salesMobile' => $branch_data->sales_mobile,
  //    ];

  //    $to_address   = $email;
  //    $from_address = 'elysiumacademy@elysium.community';
  //    $from_name    = 'Elysium AcademyÂ®';
  //    Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
  //  }

  public function Cronjob_staff_lead_bank_update(Request $request)
  {
    $monitor = CronjobMonitorModel::where('sno', 3)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor && $monitor->status != 0) {
      return response()->json([
        'success' => false,
        'message' => 'Cronjob status Off'
      ]);
    }

    if ($monitor) {
      $monitor->running_status = 1;
      $monitor->save();
    }

    $today = now('Asia/Kolkata');
    $lastDayOfMonth = now('Asia/Kolkata')->endOfMonth();

    $helper = new \App\Helpers\Helpers();
    $increase_count = $helper->general_setting_data()->lead_bank_count ?? 50;
    $inserted_records = 0;
    $message = '';

    if ($today->isSameDay($lastDayOfMonth)) {
      StaffModel::where('status', 0)->update([
        'lead_bank_count' => $increase_count,
        'month_lead_count' => 0
      ]);
      $message = "Updated successfully";
      $success = true;
    } else {
      $message = "Today is not the last day of the month.";
      $success = false;
    }

    // Step 1: Get the matching staff IDs
    $getaNoticePeriodInStaff = DB::table('et_staff')
      ->whereIn('status', [0, 1])
      ->where('notice_check', 1)
      ->whereDate('notice_end_date', '<=', $today)
      ->pluck('sno');

    // Step 2: Update the status to 2
    DB::table('et_staff')
      ->whereIn('sno', $getaNoticePeriodInStaff)
      ->update(['status' => 4]);

    // End time & duration
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    // Update monitor and create log
    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
        'message'           => $message
      ]);
      $monitor_log->created_by = 0;
      $monitor_log->updated_by = 0;
      $monitor_log->save();
    }

    return response()->json([
      "success" => $success,
      "message" => $message,
      "processed_records" => $inserted_records,
      "execution_time" => $duration
    ]);
  }

  public function Cronjob_otherdb()
  {
    return 'return';
    // Connect to the secondary database
    $other_db = DB::connection('mysql_secondary');

    //   return $other_db->table('user')->first();
    // Query to fetch user data and associated call logs
    $users_with_call_log_count = $other_db
      ->table('user as u')
      ->select(
        'u.user_id',
        'u.name',
        'u.nick_name',
        'u.phone_no',
        'u.user_code',
        'u.is_primary',
        'u.company_id',
        'c.company_name',
        'u.department_id',
        $other_db->raw('SUM(CASE WHEN cl.call_log_id IS NOT NULL THEN 1 ELSE 0 END) as call_log_count') // Sum the call logs
      )
      ->leftJoin('company as c', 'u.company_id', '=', 'c.company_id')  // Join company table
      ->leftJoin('call_log as cl', 'u.user_id', '=', 'cl.user_id')      // Join call_log table
      ->where('u.company_id', 1)  // Filter by company_id
      ->where('cl.count_status', 0)  // Filter by company_id
      ->groupBy(
        'u.user_id',
        'u.name',
        'u.nick_name',
        'u.phone_no',
        'u.user_code',
        'u.is_primary',
        'u.company_id',
        'c.company_name',
        'u.department_id'  // Group by user attributes and company details
      )
      ->get();
    $total = 0;
    foreach ($users_with_call_log_count as $list) {
      $total += $list->call_log_count;
    }


    return $total;
  }
  public function Cronjob_call_log()
  {
    $monitor = CronjobMonitorModel::where('sno', 1)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    //   return 'stop';
    $other_db = DB::connection('mysql_secondary');
    $branches = BranchModel::select('sno AS branch_id', 'call_tracker_branch_id')
      ->where('status', 0)
      ->where('call_tracker_branch_id', '>', 0)
      ->get();

    $all_users = []; // Array to store all users with branch_id
    $inserted_records = []; // Array to store inserted records

    foreach ($branches as $branch) {
      $getmobiles = CugManagementModel::select('staff_mobile', 'staff_id')
        ->where('branch_id', $branch->branch_id)
        ->where('status', 0)
        ->get();

      foreach ($getmobiles as $mobile) {
        $select_users = $other_db
          ->table('user as u')
          ->select('u.user_id', 'u.name', 'u.nick_name', 'u.phone_no', 'u.user_code', 'u.status', 'u.company_id', 'c.company_name', 'u.department_id')
          ->leftJoin('company as c', 'u.company_id', '=', 'c.company_id')
          ->where('u.phone_no', $mobile->staff_mobile)
          ->where('u.status', 0)
          ->where('u.company_id', $branch->call_tracker_branch_id)
          ->get();

        if (!$select_users->isEmpty()) {
          foreach ($select_users as $user) {
            $user->branch_id = $branch->branch_id; // Add branch_id to user data
            $user_logs = $other_db
              ->table('call_log as cl')
              ->select('cl.call_log_id', 'cl.count_status', 'cl.contact_book_id', 'cl.call_date', 'cl.call_end_date', 'cl.call_time', 'cl.call_end_time', 'cl.duration', 'cl.latitude', 'cl.longitude', 'cl.status AS log_status', 'cb.phone_no as customer_phone_no', 'cb.contact_name as customer_name', 'cb.reason as customer_reason', 'cb.status as customer_status')
              ->leftJoin('contact_book as cb', 'cl.contact_book_id', '=', 'cb.contact_book_id')
              ->where('cl.user_id', $user->user_id) // Assuming you have user_id in call_log
              ->whereYear('cl.call_date', '>', '2021')
              ->where('cl.count_status', 0)
              ->orderBy('cl.call_date', 'ASC')
              ->limit(10)
              ->get();

            // Add logs to user data
            $user->logs = $user_logs; // Add logs to user data
            // $all_users[] = (array) $user; // Convert object to array and store

            //   return $user_logs;

            // Check if there are logs to insert
            if (!$user_logs->isEmpty()) {
              foreach ($user_logs as $log) {
                $status = $log->log_status;
                $call_duration = $log->duration;

                if ($status === 0 && $call_duration != '00:00:00') {
                  $staus_up = $log->log_status;
                } elseif ($status === 0 && $call_duration == '00:00:00') {
                  $staus_up = 4;
                } else {
                  $staus_up = $log->log_status;
                }
                $record = CallTrackerModel::create([
                  'branch_id' => $branch->branch_id,
                  'branch_staff_id' => $mobile->staff_id ?? 51,
                  'call_tracker_staff_id' => $user->user_id,
                  'staff_phone_no' => $user->phone_no,
                  'customer_phone_no' => $log->customer_phone_no,
                  'customer_name' => $log->customer_name ?: 'Unknown',
                  'customer_status' => $log->customer_status,
                  'customer_reason' => $log->customer_reason,
                  'call_start_date' => $log->call_date,
                  'call_end_date' => $log->call_end_date ?: null,
                  'call_start_time' => $log->call_time,
                  'call_end_time' => $log->call_end_time,
                  'call_duration' => $log->duration,
                  'latitude' => $log->latitude,
                  'longitude' => $log->longitude,
                  'call_status' => $staus_up
                ]);
                $user_logs_upadte = $other_db
                  ->table('call_log')
                  ->where('call_log_id', $log->call_log_id)
                  ->update(['count_status' => 1]);
                // Store inserted record for return
                $inserted_records[] = 1; // Add a count for each inserted record
              }
            }
          }
        }
      }
    }
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds ¢ª H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => isset($inserted_records) ? count($inserted_records) : 0,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => isset($inserted_records) ? count($inserted_records) : 0,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }
  public function Cronjob_lead_calls_update()
  {
    $monitor = CronjobMonitorModel::where('sno', 2)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $genset = GeneralSettingsModel::where('sno', 1)->first();
    $call_last_fetch_id = $genset ? $genset->call_last_fetch_id : 0;
    //   $call_last_fetch_id =  489497;

    // Fetch uncounted call records
    $getmobiles = DB::table('et_call_tracker as ct')
      ->select('ct.sno', 'ct.call_status', 'ct.call_duration', 'ct.customer_phone_no')
      ->where('ct.count_status', 0)
      ->where('ct.sno', '>=', $call_last_fetch_id)
      ->limit(500)
      ->orderBy('ct.sno', 'ASC')
      ->get();
    //   return $getmobiles;
    $last_fetch_id = $call_last_fetch_id;
    $inserted_records = 0;
    foreach ($getmobiles as $ct) {
      $lead_mobile = $ct->customer_phone_no;
      $phoneWithCountryCode = '+91' . $lead_mobile;
      $phoneWithoutCountryCode = preg_replace('/^\+91/', '', $lead_mobile);

      // Fetch lead details
      $lead_update = LeadModel::where(function ($query) use ($lead_mobile, $phoneWithCountryCode, $phoneWithoutCountryCode) {
        $query->where('lead_mobile', 'LIKE', "%{$lead_mobile}%")
          ->orWhere('lead_mobile', $phoneWithCountryCode)
          ->orWhere('lead_mobile', $phoneWithoutCountryCode);
      })->first();

      // 

      if (isset($lead_update)) {
        //   return $lead_update;
        // continue; // Skip if no lead is found
        // Initialize previous counts
        $old_outgoing = $lead_update->outgoing_count ?? 0;
        $old_incoming = $lead_update->incoming_count ?? 0;
        $old_missed_reject = $lead_update->missed_reject_count ?? 0;
        $old_dialed = $lead_update->dialed_count ?? 0;

        $status = $ct->call_status;

        // Update counts based on call status
        if ($status === 0) {
          $old_outgoing += 1;
        } elseif ($status === 4) {
          $old_dialed += 1;
        } elseif ($status == 1) {
          $old_incoming += 1;
        } elseif ($status == 2 || $status == 3) {
          $old_missed_reject += 1;
        }

        // Update count_status in CallTrackerModel
        $updated = CallTrackerModel::where('sno', $ct->sno)->update(['count_status' => 1]);

        if ($updated > 0) {
          $lead_update->outgoing_count = $old_outgoing;
          $lead_update->dialed_count = $old_dialed;
          $lead_update->incoming_count = $old_incoming;
          $lead_update->missed_reject_count = $old_missed_reject;
          $lead_update->save();
          $inserted_records++;
        }
      }
      $last_fetch_id = $ct->sno;
      GeneralSettingsModel::where('sno', 1)->update(['call_last_fetch_id' => $ct->sno]);
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds ¢ª H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }
  public function Cronjob_lead_calls_update_before_days()
  {
    return 'Waiting for Lead enrty';
    $start_time = microtime(true);
    //   $call_last_fetch_id =  489497;

    // Fetch uncounted call records

    $getmobiles = DB::table('et_call_tracker as ct')
      ->select('ct.sno', 'ct.call_status', 'ct.call_duration', 'ct.customer_phone_no')
      ->where('ct.count_status', 0)
      ->whereBetween('ct.call_start_date', [Carbon::now()->subDays(500)->toDateString(), Carbon::now()->toDateString()])
      ->limit(500)
      ->orderBy('ct.sno', 'ASC')
      ->get();

    //   return count($getmobiles);

    // return $getmobiles;
    $inserted_records = 0;
    foreach ($getmobiles as $ct) {
      $lead_mobile = $ct->customer_phone_no;
      $phoneWithCountryCode = '+91' . $lead_mobile;
      $phoneWithoutCountryCode = preg_replace('/^\+91/', '', $lead_mobile);

      // Fetch lead details
      $lead_update = LeadModel::where(function ($query) use ($lead_mobile, $phoneWithCountryCode, $phoneWithoutCountryCode) {
        $query->where('lead_mobile', 'LIKE', "%{$lead_mobile}%")
          ->orWhere('lead_mobile', $phoneWithCountryCode)
          ->orWhere('lead_mobile', $phoneWithoutCountryCode);
      })->first();

      // 

      if (isset($lead_update)) {
        //   return $lead_update;
        // continue; // Skip if no lead is found
        // Initialize previous counts
        $old_outgoing = $lead_update->outgoing_count ?? 0;
        $old_incoming = $lead_update->incoming_count ?? 0;
        $old_missed_reject = $lead_update->missed_reject_count ?? 0;
        $old_dialed = $lead_update->dialed_count ?? 0;

        $status = $ct->call_status;

        // Update counts based on call status
        if ($status === 0) {
          $old_outgoing += 1;
        } elseif ($status === 4) {
          $old_dialed += 1;
        } elseif ($status == 1) {
          $old_incoming += 1;
        } elseif ($status == 2 || $status == 3) {
          $old_missed_reject += 1;
        }

        // Update count_status in CallTrackerModel
        $updated = CallTrackerModel::where('sno', $ct->sno)->update(['count_status' => 1]);

        if ($updated > 0) {
          $lead_update->outgoing_count = $old_outgoing;
          $lead_update->dialed_count = $old_dialed;
          $lead_update->incoming_count = $old_incoming;
          $lead_update->missed_reject_count = $old_missed_reject;
          $lead_update->save();
          $inserted_records++;
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    return [
      'processed_records' => $inserted_records,
      'execution_time' => $execution_time . ' seconds',
    ];
  }
  public function Cronjob_lead_phone_verify()
  {
    $monitor = CronjobMonitorModel::where('sno', 6)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    $Leads = DB::table('et_lead')
      ->select('sno', 'lead_name', 'lead_mobile', 'phone_verify_status', 'inter_calls')
      ->where('phone_verify_status', 0)
      ->limit(1000)
      ->get();

    // Check if leads exist
    if ($Leads->isEmpty()) {
      return response()->json(['message' => 'Lead not found'], 404);
    }
    $inserted_records = 0;

    foreach ($Leads as $lead) {
      $lead_id = $lead->sno;
      $lead_mobile = $lead->lead_mobile;
      if ($lead->inter_calls == 0 || $lead->inter_calls == null || $lead->inter_calls == 91) {
        $countryCode = 'IN';
      } else {
        $countries = DB::table('et_countries')->where('phonecode', $lead->inter_calls)->first();
        if ($countries) {
          $countryCode = $countries->sortname;
        } else {
          $countryCode = 'IN';
        }
      }

      // Fetch lead details
      $lead_update = LeadModel::where('sno', $lead_id)->first();
      if (!$lead_update) {
        continue; // Skip if lead not found
      }

      // API URL
      $url = 'http://apilayer.net/api/validate';
      $accessKey = '60af509a52f854bf5efbf11595874b5c';
      // Determine country code
      // $countryCode = ($lead->inter_calls == 0 || $lead->inter_calls == null) ? '+ 91' : $lead->inter_calls;


      // Set up cURL
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, "{$url}?access_key={$accessKey}&number={$lead_mobile}&country_code={$countryCode}&format=1");
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_TIMEOUT, 30);

      $response = curl_exec($ch);

      // Check for cURL errors
      if (curl_errno($ch)) {
        curl_close($ch);
        return response()->json(['error' => 'cURL error: ' . curl_error($ch)], 500);
      }

      curl_close($ch);
      $data = json_decode($response, true);
      // return $data;
      // Handle API response errors
      if (!$data || !isset($data['valid'])) {
        continue;
      }
      // Update phone verification status
      $lead_update->phone_verify_status  = $data['valid'] ? 1 : 2;
      $lead_update->phone_verify_content = json_encode($data); // Store JSON properly
      $lead_update->save();
      $inserted_records++;
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds ¢ª H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  // Justdail Lead to Lead 
  public function Cronjob_just_dial_lead()
  {
    $monitor = CronjobMonitorModel::where('sno', 7)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    $genset = GeneralSettingsModel::where('sno', 1)->first();
    $getLeads = DB::table('et_justdial_lead')
      ->select('*')
      ->where('status', 0)
      ->whereNotNull('parentid')
      ->limit(300)
      ->orderBy('sno', 'ASC')
      ->get();

    $inserted_records = 0;
    foreach ($getLeads as $jlead) {
      $parentid = $jlead->parentid;
      $branch_get = BranchModel::select('sno', 'other_src_staff_id', 'just_dial_id')
        ->where('just_dial_id', $parentid)
        ->first();
      $leadstaff = DB::table('et_lead_source_mapping')->where('branch_id', $branch_get->sno)->where('source_id', 17)->first();
      if ($leadstaff) {
        $branch_get->other_src_staff_id = $leadstaff->staff_id;
      }
      if ($branch_get && $branch_get->other_src_staff_id) {

        $branch_sno = $branch_get->sno;
        $lead_mobile = $jlead->lead_mobile;
        $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 2;
        // Check if lead already exists
        if (LeadModel::where('lead_mobile', $lead_mobile)->exists()) {

          $lead_update = JustDialModel::where('sno', $jlead->sno)->first();
          $lead_update->status = 3;
          $lead_update->save();
          continue;
        }

        $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code ?? 'MDU';

        $year = date("Y");
        $category_check = LeadModel::where('status', '!=', 2)
          ->orderBy('sno', 'desc')
          ->first();

        if (!$category_check) {
          $lead_id = "{$year}/{$branch_code}/LED0001";
        } else {
          $last_lead_id = $category_check->lead_id;
          $slice = explode("/", $last_lead_id);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
        }

        $add_category = new LeadModel();
        $add_category->lead_id = $lead_id;
        $add_category->lead_name = ucfirst($jlead->lead_name);
        $add_category->lead_mobile = $lead_mobile;
        $add_category->lead_alternate_mobile = $jlead->lead_alternate_mobile;
        $add_category->lead_email_id = $jlead->lead_email_id;
        $add_category->lead_knowledge_tags = $jlead->lead_knowledge_tags;
        $add_category->registered_date = $jlead->registered_date;
        $add_category->branch_id = $branch_sno;
        $add_category->lead_source_id = 17;
        $add_category->just_dial_id = $jlead->sno;
        $add_category->created_by = $lead_othr_src_staff;
        $add_category->updated_by = $lead_othr_src_staff;
        $add_category->lead_status_id = 1;
        $add_category->lead_condition = 2;

        if ($add_category->save()) {
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->end_date = null;
          $add_history->transferred_from = 12;
          $add_history->created_by = $lead_othr_src_staff;
          $add_history->updated_by = $lead_othr_src_staff;
          $add_history->save();

          $lead_update = JustDialModel::where('sno', $jlead->sno)->first();

          $lead_update->status = 2;
          $lead_update->save();

          $inserted_records++;
        }

        $branch_data = BranchModel::where('sno', $branch_sno)->first();
        $branch_name = " ";
        if ($branch_data->branch_type == 1) {
          $branch_name = $branch_data->branch_name;
        } elseif ($branch_data->branch_type == 2) {
          $branch_name = $branch_data->franchise_name;
        }
        $lead_name = ucfirst($jlead->lead_name);
        $lead_email_id = $jlead->lead_email_id;
        $entityData = '';
        // communication Send
        $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id', $lead_othr_src_staff)->first();
        $communicationStatus = DB::table('et_communication_handle')->where('module_name', 'Lead Welcome')->first();
        if ($communicationStatus && $communicationStatus->status == 0) {
          // // sms thank you lead
          if ($communicationStatus->sms == 0) {
            if ($add_category && $lead_mobile) {

              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', 'PhDiZone_Enquiry_Thankyou_Message')->first();
              $authkey = $result_sms ? $result_sms->authkey : '';
              $sender_id = $result_sms ? $result_sms->sender_id : '';
              $template_id = $result_sms ? $result_sms->template_id : '';
              $country_code = $result_sms ? $result_sms->country_code : '';
              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
              $mobile_number = $country_code . $lead_mobile;

              $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

              // Replace placeholders with actual values
              $replacement_values = [$lead_name, $branch_name, $cre_mobile];
              $message_content = preg_replace_callback(
                '/\{#var#\}/',
                function () use (&$replacement_values) {
                  return array_shift($replacement_values);
                },
                $message_content
              );

              $route = "default";
              $postData = array(
                'authkey' => $authkey,
                'mobiles' => $mobile_number,
                'message' => $message_content,
                'sender' => $sender_id,
                'route' => $route,
              );

              // API URL
              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

              // Initialize the resource
              $ch = curl_init();
              curl_setopt_array($ch, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $postData,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
              ));

              // Get response
              $response = curl_exec($ch);
              // return $response;
              $err = curl_error($ch);
              curl_close($ch);
            }
          }
          // // Thank you email send
          if ($communicationStatus->email == 0) {
            if ($add_category && $lead_email_id) {
              $email_template_id = 2; // thank you template
              $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
              $dynamicSubject = str_replace('#entity_name', 'Elysium Technology', $emailTemplate->email_name);
              $content = $emailTemplate->email_subject;
              $content = str_replace('#lead_name', $lead_name, $content);
              $branchNo = $branch_data->mobile;
              $branchemail = $branch_data->mail;
              $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/PhDiZone/';
              $instaLink = $branch_data->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
              $content = str_replace('#sales_mobile', $cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile, $content);
              $content = str_replace('#cre_mobile', $branch_data->cre_mobile ?? '8220011465', $content);
              $url = 'phdizone.com';
              $mailData = [
                'url'         => $url,
                'subject'     => $dynamicSubject,
                'content'     => $content,
                'branchNo'    => $branchNo,
                'branchemail' => $branchemail, // Use the message content from the request
                'fbLink'      => $fbLink,      // Use the message content from the request
                'instaLink'   => $instaLink,   // Use the message content from the request
                'salesMobile' => $branch_data->cre_mobile ?? '9003400111',
              ];

              $to_address = $lead_email_id;
              $from_address = 'elysiumtechnology@elysium.community';
              $from_name = 'PhDiZone';

              Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
            }
          }
          // // Thank You whatsapp message
          if ($communicationStatus->whatsapp == 0) {
            if ($add_category && $lead_mobile) {
              $templateName = "welcome_msg_phdizone";

              $hasHeader  = false; // Example flag: set based on template
              $hasBody    = false; // Example flag: set based on template
              $hasFooter  = false; // Example flag: set based on template
              $hasButton  = false;
              $components = [];
              $couponCode = " ";
              date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
              $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
              // $currentHour = date('H'); // Get current hour in 24-hour format
              if ($currentHour >= 5 && $currentHour < 12) {
                $greeting = 'Good Morning';
              } elseif ($currentHour >= 12 && $currentHour < 18) {
                $greeting = 'Good Afternoon';
              } else {
                $greeting = 'Good Evening';
              }

              if ($templateName == 'welcome_msg_phdizone') {

                $headerImage = 'https://dev.erp.elysiumtechnologies.com/public/assets/phdizone_images/Thank-You.jpg';
                $couponCode  = 'NOOFFER';
                $buttonIndex = 0;
                $bodyText    = [
                  [
                    'type'           => 'text',
                    'text'           => $lead_name,
                    'parameter_name' => 'lead_name',
                  ],
                  [
                    'type'           => 'text',
                    'text'           => $cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile,
                    'parameter_name' => 'sales_numbers',
                  ]

                ];
                $hasHeader = true;
                $hasBody   = true;
              }

              // Add Header if required
              if ($hasHeader) {
                $components[] = [
                  'type'       => 'header',
                  'parameters' => [
                    [
                      'type'  => 'image',
                      'image' => [
                        'link' => $headerImage, // Dynamically set header image
                      ],
                    ],
                  ],
                ];
              }

              // Add Body if required
              if ($hasBody) {
                $components[] = [
                  'type'       => 'body',
                  'parameters' => $bodyText,
                ];
              }

              // Add Footer if required
              if ($hasFooter) {
                $components[] = [
                  'type'       => 'footer',
                  'parameters' => [
                    [
                      'type'           => 'text',
                      'text'           => 'This is the footer text.',
                      'parameter_name' => 'footer_text',
                    ],
                  ],
                ];
              }

              // Add Button if required
              if ($hasButton) {
                $components[] = [
                  'type'       => 'button',
                  'sub_type'   => 'copy_code',
                  'index'      => $buttonIndex,
                  'parameters' => [
                    [
                      'type'        => 'coupon_code',
                      'coupon_code' => $couponCode,
                    ],
                  ],
                ];
              }

              $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id', $branch_data->entity_id)->orderBy('sno', 'desc')->first();
              $dynamicParameters         = $templateParameters[$templateName] ?? [];
              $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
              $accessToken               = $whatsappApi->access_tokken ?? '';
              $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';

              $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

              $inter_calls = '91';
              $countryCode  = $inter_calls ? ($inter_calls == 0 ? '+91' : '+' . $inter_calls) : '+91';
              $to           = $lead_mobile;
              $languageCode = 'en';

              if (strpos($to, $countryCode) !== 0) {
                $to = $countryCode . $to;
              }

              $message = 'test~message';
              if (empty($components)) {
                $payload = [
                  'messaging_product' => 'whatsapp',
                  'to'                => $to,
                  'type'              => 'template',
                  'template'          => [
                    'name'     => $templateName,
                    'language' => [
                      'code' => $languageCode,
                    ],
                  ],
                ];
              } else {
                $payload = [
                  'messaging_product' => 'whatsapp',
                  'to'                => $to,
                  'type'              => 'template',
                  'template'          => [
                    'name'       => $templateName,
                    'language'   => [
                      'code' => $languageCode,
                    ],
                    'components' => $components,
                  ],
                ];
              }

              $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
            }
          }
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds ¢ª H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }
  public function Cronjob_hot_lead_update()
  {
    $monitor = CronjobMonitorModel::where('sno', 9)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    $inserted_records = 0;
    $genset = GeneralSettingsModel::where('sno', 1)->first();

    if ($genset && $genset->hot_lead_days) {
      $hot_lead_day = $genset->hot_lead_days;
      $before_date  = date('Y-m-d', strtotime("-$hot_lead_day days"));

      $get_leads = DB::table('et_lead')
        ->select('sno', 'last_hot_lead_date', 'lead_status_id', 'status', 'lead_name', 'created_by', 'branch_id')
        ->where('last_hot_lead_date', '<', $before_date)  // 'last_hot_lead_date' less than $before_date
        ->where('lead_status_id', 3)
        ->get();

      foreach ($get_leads as $lead) {
        $hot = new HotLeadModel();
        $hot->branch_id = $lead->branch_id;
        $hot->lead_id = $lead->sno;
        $hot->staff_id = $lead->created_by;
        $hot->startdate = $lead->last_hot_lead_date;
        $hot->enddate = date('Y-m-d');
        $hot->created_by = $lead->created_by;
        $hot->updated_by = $lead->created_by;
        $hot->save();

        if ($hot) {
          $lead_update = LeadModel::where('sno', $lead->sno)->first();
          if ($lead_update) {
            $lead_update->lead_status_id = 2;
            $lead_update->is_hot_lead = 2;
           // $lead_update->last_hot_lead_date = null;
            $lead_update->save();
            $inserted_records++;
          }
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds ¢ª H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }
  public function Cronjob_CloseInCompleteExam()
  {
    $monitor = CronjobMonitorModel::where('sno', 16)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor) {
      if ($monitor->status != 0) {
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $processlist = DB::table('et_exam_process')->where('status', '!=', 2)->get();
    $inserted_records = 0;

    foreach ($processlist as $list) {
      $exam_data = DB::table('et_manage_exam')->where('sno', $list->exam_id)->first();
      $exam_duration_in_min = (int)($exam_data->duration ?? 0);

      if ($exam_duration_in_min > 0) {
        // ✅ DB stores IST timestamps → parse as Asia/Kolkata
        $created_time = Carbon::parse($list->created_at, 'Asia/Kolkata');
        $exam_end_time = $created_time->copy()->addMinutes($exam_duration_in_min);
        $current_time = now('Asia/Kolkata');

        // 🪵 Debug log
        // \Log::info('Exam Time Check', [
        //     'exam_id'       => $list->exam_id,
        //     'created_time'  => $created_time->toDateTimeString(),
        //     'exam_end_time' => $exam_end_time->toDateTimeString(),
        //     'current_time'  => $current_time->toDateTimeString(),
        //     'is_expired'    => $current_time->greaterThan($exam_end_time) ? 'YES' : 'NO'
        // ]);

        // ✅ Close expired exams
        if ($current_time->greaterThan($exam_end_time)) {
          $update = ExamProcessModel::find($list->sno);
          if ($update && $update->status != 2) {

            // ⏱ Calculate total attended duration
            $diffInSeconds = $created_time->diffInSeconds($current_time);
            $hours = floor($diffInSeconds / 3600);
            $minutes = floor(($diffInSeconds % 3600) / 60);
            $seconds = $diffInSeconds % 60;
            $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

            $update->completed_date = $current_time;
            $update->status = 2;
            $update->total_attended_duration = $duration;
            $update->save();

            $inserted_records++;
          }
        }
      }
    }

    // 🕒 Calculate total cron execution time
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    // Convert seconds → H:i:s
    $hours = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    // 🪵 Update monitor and create log
    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }



  // Sulekha Lead To Lead
  // public function Cronjob_sulekha_lead()
  // {
  //   $start_time = microtime(true);

  //   $genset = GeneralSettingsModel::where('sno', 1)->first();


  //   $getLeads = DB::table('et_sulekha_lead')
  //     ->select('*')
  //     ->where('status', 0)
  //     //   ->where('sno', 39)
  //     ->limit(1000)
  //     ->orderBy('sno', 'ASC')
  //     ->get();

  //   // return $getLeads;

  //   $inserted_records = 0;
  //   foreach ($getLeads as $slead) {
  //     $branch_id = 6;
  //     $branch_get = BranchModel::select('sno', 'other_src_staff_id', 'sulekha_id')
  //       ->where('sulekha_id', $branch_id)
  //       ->first();
  //     // return $branch_get;

  //     if ($branch_get && $branch_get->other_src_staff_id) {

  //       $branch_sno = $branch_get->sno;
  //       $lead_mobile = $slead->lead_mobile;
  //       $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 123;
  //       // Check if lead already exists
  //       if (LeadModel::where('lead_mobile', $lead_mobile)->exists()) {

  //         $lead_update = SulekhaModel::where('sno', $slead->sno)->first();
  //         $lead_update->status = 3;
  //         $lead_update->save();
  //         continue;
  //       }
  //       // return $lead_update;

  //       $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
  //       $branch_code = $branch_check->city_short_code ?? 'MDU';

  //       $year = date("Y");
  //       $category_check = LeadModel::where('status', '!=', 2)
  //         ->orderBy('sno', 'desc')
  //         ->first();

  //       if (!$category_check) {
  //         $lead_id = "{$year}/{$branch_code}/LED0001";
  //       } else {
  //         $last_lead_id = $category_check->lead_id;
  //         $slice = explode("/", $last_lead_id);
  //         $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
  //         $next_number = (int)$resultcus + 1;
  //         $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
  //       }

  //       // return $branch_check;
  //       $add_category = new LeadModel();
  //       $add_category->lead_id = $lead_id;
  //       $add_category->lead_name = ucfirst($slead->lead_name);
  //       $add_category->lead_mobile = $lead_mobile;
  //       // $add_category->lead_alternate_mobile = $slead->lead_alternate_mobile;
  //       $add_category->lead_email_id = $slead->lead_email;
  //       $add_category->lead_knowledge_tags = $slead->category;
  //       $add_category->registered_date = $slead->created_at;
  //       $add_category->branch_id = $branch_sno;
  //       $add_category->lead_source_id = 6;
  //       $add_category->sulekha_id = $slead->sno;
  //       $add_category->created_by = $lead_othr_src_staff;
  //       $add_category->updated_by = $lead_othr_src_staff;
  //       $add_category->lead_status_id = 1;
  //       $add_category->lead_condition = 2;



  //       if ($add_category->save()) {
  //         // return $add_category;
  //         $add_history = new LeadTransferLogModel();
  //         $add_history->lead_id = $add_category->sno;
  //         $add_history->branch_id = $add_category->branch_id;
  //         $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
  //         $add_history->current_staff_id = $add_category->created_by;
  //         $add_history->change_staff_id = 0;
  //         $add_history->end_date = null;
  //         $add_history->transferred_from = 14;
  //         $add_history->created_by = $lead_othr_src_staff;
  //         $add_history->updated_by = $lead_othr_src_staff;

  //         // return $add_history;
  //         $add_history->save();

  //         $lead_update = SulekhaModel::where('sno', $slead->sno)->first();

  //         $lead_update->status = 2;
  //         $lead_update->save();

  //         $inserted_records++;
  //       }

  //       $branch_data = BranchModel::where('sno', $branch_sno)->first();

  //       // return $branch_data;
  //       $branch_name = " ";
  //       if ($branch_data->branch_type == 1) {
  //         $branch_name = $branch_data->branch_name;
  //       } elseif ($branch_data->branch_type == 2) {
  //         $branch_name = $branch_data->franchise_name;
  //       }
  //       $lead_name = ucfirst($slead->lead_name);
  //       $lead_email_id = $slead->lead_email;

  //       // return $lead_email_id;

  //       // sms thank you lead
  //       if ($add_category && $lead_mobile) {

  //         $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
  //         $authkey = $result_sms ? $result_sms->authkey : '';
  //         $sender_id = $result_sms ? $result_sms->sender_id : '';
  //         $template_id = $result_sms ? $result_sms->template_id : '';
  //         $country_code = $result_sms ? $result_sms->country_code : '';
  //         $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
  //         $mobile_number = $country_code . $lead_mobile;

  //         $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

  //         // Replace placeholders with actual values
  //         $replacement_values = [$lead_name, $cre_mobile];
  //         $message_content = preg_replace_callback(
  //           '/\{#var#\}/',
  //           function () use (&$replacement_values) {
  //             return array_shift($replacement_values);
  //           },
  //           $message_content
  //         );

  //         $route = "default";
  //         $postData = array(
  //           'authkey' => $authkey,
  //           'mobiles' => $mobile_number,
  //           'message' => $message_content,
  //           'sender' => $sender_id,
  //           'route' => $route,
  //         );

  //         // API URL
  //         $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

  //         // Initialize the resource
  //         $ch = curl_init();
  //         curl_setopt_array($ch, array(
  //           CURLOPT_URL => $url,
  //           CURLOPT_RETURNTRANSFER => true,
  //           CURLOPT_POST => true,
  //           CURLOPT_POSTFIELDS => $postData,
  //           CURLOPT_SSL_VERIFYHOST => 0,
  //           CURLOPT_SSL_VERIFYPEER => 0,
  //         ));

  //         // Get response
  //         $response = curl_exec($ch);
  //         // return $response;
  //         $err = curl_error($ch);
  //         curl_close($ch);
  //       }
  //       // Thank you email send
  //       if ($add_category && $slead->lead_email) {
  //         $email_template_id = 6; // thank you template
  //         $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

  //         $content = $emailTemplate->email_subject;
  //         $content = str_replace('#name', $lead_name, $content);
  //         $content = str_replace('#webLink', $branch_data->website ?? 'https://elysiumacademy.org/', $content);
  //         $branchNo = $branch_data->mobile;
  //         $branchemail = $branch_data->mail;
  //         $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
  //         $instaLink = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
  //         $content = str_replace('#salesNo', $branch_data->sales_mobile ?? '9677781155', $content);
  //         $content = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
  //         $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
  //         $content = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

  //         $mailData = [
  //           'url' => 'Eapl.com',
  //           'subject' => $emailTemplate->email_name,
  //           'content' => $content,
  //           'branchNo' => $branchNo,
  //           'branchemail' => $branchemail, // Use the message content from the request
  //           'fbLink' => $fbLink, // Use the message content from the request
  //           'instaLink' => $instaLink, // Use the message content from the request
  //           'salesMobile' => $branch_data->sales_mobile,
  //         ];

  //         $to_address = $lead_email_id;
  //         $from_address = 'elysiumacademy@elysium.community';
  //         $from_name = 'Elysium AcademyÂ®';
  //         Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
  //       }
  //       // whatsapp message
  //       if ($add_category && $lead_mobile) {
  //         $templateName = "elysium_academy_welcome_message";

  //         $hasHeader  = false; // Example flag: set based on template
  //         $hasBody    = false; // Example flag: set based on template
  //         $hasFooter  = false; // Example flag: set based on template
  //         $hasButton  = false;
  //         $components = [];
  //         $couponCode = " ";
  //         date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
  //         $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
  //         // $currentHour = date('H'); // Get current hour in 24-hour format
  //         if ($currentHour >= 5 && $currentHour < 12) {
  //           $greeting = 'Good Morning';
  //         } elseif ($currentHour >= 12 && $currentHour < 18) {
  //           $greeting = 'Good Afternoon';
  //         } else {
  //           $greeting = 'Good Evening';
  //         }

  //         if ($templateName == 'elysium_academy_welcome_message') {

  //           $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
  //           $couponCode  = 'NOOFFER';
  //           $buttonIndex = 0;
  //           $bodyText    = [
  //             [
  //               'type'           => 'text',
  //               'text'           => $greeting,
  //               'parameter_name' => 'greet_msg',
  //             ],
  //             [
  //               'type'           => 'text',
  //               'text'           => $lead_name,
  //               'parameter_name' => 'customer_name',
  //             ],
  //             [
  //               'type'           => 'text',
  //               'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
  //               'parameter_name' => 'web_link',
  //             ],
  //             [
  //               'type'           => 'text',
  //               'text'           => $branch_name,
  //               'parameter_name' => 'branch_name',
  //             ],
  //             [
  //               'type'           => 'text',
  //               'text'           => $branch_data->cre_mobile ?? '7708053111',
  //               'parameter_name' => 'contact_no',
  //             ],
  //             [
  //               'type'           => 'text',
  //               'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
  //               'parameter_name' => 'contact_email',
  //             ],
  //           ];
  //           $hasHeader = true;
  //           $hasBody   = true;
  //           $hasButton = true;
  //         }

  //         // Add Header if required
  //         if ($hasHeader) {
  //           $components[] = [
  //             'type'       => 'header',
  //             'parameters' => [
  //               [
  //                 'type'  => 'image',
  //                 'image' => [
  //                   'link' => $headerImage, // Dynamically set header image
  //                 ],
  //               ],
  //             ],
  //           ];
  //         }

  //         // Add Body if required
  //         if ($hasBody) {
  //           $components[] = [
  //             'type'       => 'body',
  //             'parameters' => $bodyText,
  //           ];
  //         }

  //         // Add Footer if required
  //         if ($hasFooter) {
  //           $components[] = [
  //             'type'       => 'footer',
  //             'parameters' => [
  //               [
  //                 'type'           => 'text',
  //                 'text'           => 'This is the footer text.',
  //                 'parameter_name' => 'footer_text',
  //               ],
  //             ],
  //           ];
  //         }

  //         // Add Button if required
  //         if ($hasButton) {
  //           $components[] = [
  //             'type'       => 'button',
  //             'sub_type'   => 'copy_code',
  //             'index'      => $buttonIndex,
  //             'parameters' => [
  //               [
  //                 'type'        => 'coupon_code',
  //                 'coupon_code' => $couponCode,
  //               ],
  //             ],
  //           ];
  //         }

  //         $dynamicParameters         = $templateParameters[$templateName] ?? [];
  //         $WhatsAppBusinessAccountId = $this->businessId;
  //         $accessToken               = $this->accessToken;
  //         $fromPhoneNumberId         = $this->phoneNumberId;

  //         $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

  //         $to           = $lead_mobile;
  //         $languageCode = 'en_US';

  //         if (strpos($to, '+91') !== 0) {
  //           $to = '+91' . $to;
  //         }

  //         $message = 'test~message';
  //         if (empty($components)) {
  //           $payload = [
  //             'messaging_product' => 'whatsapp',
  //             'to'                => $to,
  //             'type'              => 'template',
  //             'template'          => [
  //               'name'     => $templateName,
  //               'language' => [
  //                 'code' => $languageCode,
  //               ],
  //             ],
  //           ];
  //         } else {
  //           $payload = [
  //             'messaging_product' => 'whatsapp',
  //             'to'                => $to,
  //             'type'              => 'template',
  //             'template'          => [
  //               'name'       => $templateName,
  //               'language'   => [
  //                 'code' => $languageCode,
  //               ],
  //               'components' => $components,
  //             ],
  //           ];
  //         }

  //         $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
  //       }
  //     }
  //   }

  //   $end_time = microtime(true);
  //   $execution_time = round($end_time - $start_time, 4);

  //   return [
  //     'processed_records' => $inserted_records,
  //     'execution_time' => "{$execution_time} seconds",
  //   ];
  // }




//   public function Cronjob_team_goal_set_update(Request $request)
//   {
//     $month = (int)($request->month_ids ?? date('m'));
//     $year  = (int)($request->year_ids ?? date('Y'));
//     $today_day = (int)($request->date_ids ?? date('d'));
//     $recalculate = (int)($request->recalculate ?? 0);
//     $inserted_records = 0;

//     // ##############################################################################################
//     // ******************************** Cronjob Monitor End ****************************************
//     // ##############################################################################################
//     // Run Which We need month Year date Link
//     // http://192.168.3.94:8090/Cronjob_team_goal_set_update?month_ids=12&date_ids=31&year_ids=2025&recalculate=1


//     $monitor = CronjobMonitorModel::where('sno', 12)->first();
//     $start_time = microtime(true);
//     $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

//     if ($monitor && $monitor->status != 0) {
//       return response()->json([
//         'success' => false,
//         'message' => 'Cronjob status Off'
//       ]);
//     }

//     if ($monitor) {
//       $monitor->running_status = 1;
//       $monitor->save();
//     }

//     $goalsetteams = GoalSetTeamModel::where('team_goal_month', $month)
//       ->where('team_goal_year', $year)
//       ->where('goal_completed', $recalculate)
//       ->orderBy('sno', 'DESC')
//       ->get();

//     foreach ($goalsetteams as $team) {

//       $branch = DB::table('et_branch')
//         ->select('sno', 'bus_closing_day_count', 'bus_closing_month_end')
//         ->where('sno', $team->branch_id)
//         ->first();

//       $close_day = $branch->bus_closing_month_end == 1 ? (int)date('t') : ($branch->bus_closing_day_count ?? 25);

//       // Skip if today is not goal close day
//       if ($today_day != $close_day) continue;

//       $staffs = StaffModel::where('branch_id', $team->branch_id)
//         ->where('department_id', $team->department_id)
//         ->where('status', 0)
//         ->select('sno', 'basic_salary')
//         ->get();

//       $staff_ids = $staffs->pluck('sno')->toArray();
//       $branch_id = $team->branch_id;

//       // Initialize local totals for this team
//       $totals = [
//         'all_lead' => 0,
//         'month_lead' => 0,
//         'hot_lead' => 0,
//         'spam_lead' => 0,
//         'dead_lead' => 0,
//         'convert_customer' => 0,
//         'total_payment' => 0,
//         'base_paid' => 0,
//         'followup' => 0,
//         'walkin' => 0,
//         'call_out' => 0,
//       ];

//       // ##############################################################################################
//       // ******************************** PRE Sale Department ****************************************
//       // ##############################################################################################
//       $totalDepartmentConvertCustomer = 0;
//       $totalDepartmentTotalPayment = 0;
//       $totalDepartmentPaidPayment = 0;
//       if ($team->department_id == 1) {
//         // Leads metrics
//         $totals['all_lead'] = DB::table('et_lead')
//           ->whereIn('created_by', $staff_ids)
//           ->where('branch_id', $branch_id)
//           ->whereNotIn('status', [2, 6])
//           ->where('spam_verified', 0)
//           ->where('drop_verified', 0)
//           ->where('internal_status', 0)
//           ->count();

//         $totals['month_lead'] = DB::table('et_lead')
//           ->whereIn('created_by', $staff_ids)
//           ->where('branch_id', $branch_id)
//           ->whereYear('registered_date', $year)
//           ->whereMonth('registered_date', $month)
//           ->whereNotIn('status', [2, 6])
//           ->where('spam_verified', 0)
//           ->where('drop_verified', 0)
//           ->where('internal_status', 0)
//           ->count();

//         $totals['hot_lead'] = DB::table('et_lead')
//           ->whereIn('created_by', $staff_ids)
//           ->where('branch_id', $branch_id)
//           ->whereYear('registered_date', $year)
//           ->whereMonth('registered_date', $month)
//           ->whereNotIn('status', [2, 6])
//           ->where('lead_status_id', 3)
//           ->where('internal_status', 0)
//           ->where('spam_verified', 0)
//           ->where('drop_verified', 0)
//           ->count();

//         $totals['spam_lead'] = DB::table('et_lead')
//           ->whereIn('created_by', $staff_ids)
//           ->where('branch_id', $branch_id)
//           ->whereYear('registered_date', $year)
//           ->whereMonth('registered_date', $month)
//           ->where('spam_verified', 1)
//           ->where('status', 7)
//           ->count();

//         $totals['dead_lead'] = DB::table('et_lead')
//           ->whereIn('created_by', $staff_ids)
//           ->where('branch_id', $branch_id)
//           ->whereYear('registered_date', $year)
//           ->whereMonth('registered_date', $month)
//           ->where('drop_verified', 1)
//           ->where('status', 5)
//           ->count();

//         // Follow-ups & Walk-ins
//         $totals['followup'] = DB::table('et_appointment')
//           ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
//           ->whereIn('et_lead.status', [0, 4])
//           ->whereIn('et_appointment.created_by', $staff_ids)
//           ->whereYear('et_appointment.appointment_date', $year)
//           ->whereMonth('et_appointment.appointment_date', $month)
//           ->count();

//         $totals['walkin'] = DB::table('et_lead_appointment')
//           ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
//           ->where('et_lead_appointment.appointment_category', 3)
//           ->whereIn('et_lead_appointment.created_by', $staff_ids) // Fixed table reference
//           ->whereYear('et_lead_appointment.appointment_date', $year)
//           ->whereMonth('et_lead_appointment.appointment_date', $month)
//           ->count();

//         // Call outs
//         $totals['call_out'] = DB::table('et_call_tracker')
//           ->whereYear('call_start_date', $year)
//           ->whereMonth('call_start_date', $month)
//           ->where('branch_id', $branch_id)
//           ->whereIn('branch_staff_id', $staff_ids)
//           ->where('call_status', 0)
//           ->count();



//         foreach ($staff_ids as $sid) {

//           // Customer conversions with payments
//           $currentMonthCustomers = DB::table('et_customer as c')
//             ->select('c.sno', 'c.proposal_ids')
//             ->join('et_lead as l', 'l.sno', '=', 'c.lead_id')
//             ->join('et_payment as p', function ($join) {
//               $join->on('p.customer_id', '=', 'c.sno')
//                 ->whereRaw('p.transaction_date = (SELECT MIN(ep.transaction_date) FROM et_payment ep WHERE ep.customer_id = c.sno)');
//             })
//             ->join('et_transaction as t', 't.payment_id', '=', 'p.sno')
//             ->where('c.branch_id', $branch_id)
//             ->where('l.created_by', $sid)
//             ->whereYear('p.transaction_date', $year)
//             ->whereMonth('p.transaction_date', $month)
//             ->where('t.payment_status', 1)
//             ->where('c.status', 0)
//             ->get();

//           $totalDepartmentConvertCustomer += $currentMonthCustomers->count();

//           $customerConvertCount = $currentMonthCustomers->count();

//           // Calculate payments and base amounts
//           $gst_percent = 18;
//           $total_payment = 0;
//           $base_amount_paid = 0;

//           $gst_percent = 18;
//           $total_payment             = 0;
//           $total_paid_payment        = 0;
//           $base_amount_paid = 0; // keep track of GST-excluded total
//           if ($customerConvertCount > 0) {
//             if ($currentMonthCustomers->isNotEmpty()) {
//               foreach ($currentMonthCustomers as $customer) {
//                 $proposal_ids = DB::table('et_proposal')
//                   ->where('et_proposal.customer_id', $customer->sno)
//                   ->where('et_proposal.status', 0)
//                   ->whereNot('et_proposal.post_sale_check', 1)
//                   ->whereNotIn('et_proposal.proposal_status', [0, 2])
//                   ->pluck('sno')
//                   ->toArray();
//                 // return $proposal_ids;

//                 $proposals = DB::table('et_proposal')
//                   ->select('et_proposal.*', 'et_country_currencies.currency_code')
//                   ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//                   ->whereIn('et_proposal.sno', $proposal_ids)
//                   ->get();

//                 foreach ($proposals as $proposal) {
//                   // Paid slots for this proposal
//                   $paidAmount = DB::table('et_proposal_pay_slot')
//                     ->where('proposal_sno', $proposal->sno)
//                     ->where('status', 0)
//                     ->sum('paidAmount');

//                   $grantAmount = $proposal->grant_total_amount;

//                   // First remove GST from paidAmount (base value in proposal's currency)
//                   $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

//                   if ($proposal->currency_id == 70) {
//                     // INR: add directly
//                     $total_paid_payment += $paidAmount;
//                     $total_payment += $grantAmount;
//                     $base_amount_paid += $basePaidLocal;
//                   } else {
//                     // Non-INR: convert both amounts and base value
//                     $helper = new \App\Helpers\Helpers();
//                     $currency_code = $proposal->currency_code;
//                     $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
//                     $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
//                     $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
//                   }
//                 }
//               }
//             }
//             // average 
//             $totalDepartmentTotalPayment += $total_payment;
//             $totalDepartmentPaidPayment += $base_amount_paid;
//           }
//         }

//         $totals['convert_customer']  = $totalDepartmentConvertCustomer;
//         //  return $totalDepartmentTotalPayment;

//         // Calculate derived metrics
//         $total_staff = count($staff_ids);
//         $startDate = Carbon::create($year, $month, 1);
//         $currentDate = Carbon::now();
//         $endDate = ($currentDate->year == $year && $currentDate->month == $month)
//           ? $currentDate
//           : $startDate->copy()->endOfMonth();
//         $dayCount = $startDate->diffInDays($endDate) + 1;

//         // Averages
//         $avg_call_out = $dayCount > 0 && $total_staff > 0
//           ? round($totals['call_out'] / ($total_staff * $dayCount), 2)
//           : 0;
//         $avg_walkin = $dayCount > 0 && $total_staff > 0
//           ? round($totals['walkin'] / ($total_staff * $dayCount), 2)
//           : 0;
//         $avg_followup = $dayCount > 0 && $total_staff > 0
//           ? round($totals['followup'] / ($total_staff * $dayCount), 2)
//           : 0;

//         // Business and Collection values
//         $business_value = $totals['convert_customer'] > 0
//           ? round($totalDepartmentTotalPayment / $totals['convert_customer'], 2)
//           : 0;

//         $collection_value = $totals['convert_customer'] > 0
//           ? round($totalDepartmentPaidPayment / $totals['convert_customer'], 2)
//           : 0;

//         // Conversion rate
//         $conversion_rate = $totals['month_lead'] > 0
//           ? round(($totals['convert_customer'] / $totals['month_lead']) * 100, 2)
//           : 0;

//         // Update team goals in transaction
//         DB::transaction(function () use ($team, $totals, $conversion_rate, $business_value, $collection_value, $avg_call_out, $avg_followup, $avg_walkin, &$inserted_records) {
//           $team->conversion_actual = $totals['convert_customer'];
//           $team->cr_actual = $conversion_rate;
//           $team->abv_actual = $business_value;
//           $team->acv_actual = $collection_value;
//           $team->avg_call_out_actual = $avg_call_out;
//           $team->no_of_walk_actual = $avg_walkin;
//           $team->no_of_followup_actual = $avg_followup;
//           $team->goal_completed = 1;
//           $team->save();
//           $inserted_records++;
//         });
//       }
//       // ##############################################################################################
//       // ******************************** Post Sale Department ****************************************
//       // ##############################################################################################

//       if ($team->department_id == 15) {
//         // return 'Post Sale Department';          
//         $total_staff = $staffs->count();
//         $salesStaff = $staffs;
//         $totalAllLead             = 0;
//         $totalMonthLead            = 0;
//         $totalHotLead        = 0;
//         $totalSpamLead      = 0;
//         $totalDeadLead    = 0;
//         $totalAllPayment             = 0;
//         $totalAllPaidPayment        = 0;
//         $helper = new \App\Helpers\Helpers();
//         foreach ($salesStaff as $staff) {
//           $allpostSaleData = DB::table('et_customer')
//             ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_proposal.post_sale_date')
//             ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//             ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
//             ->where('et_customer.status', 0)
//             ->where('et_customer.post_sale_check', 1)
//             ->where('et_proposal.post_sale_check', 1)
//             ->whereNotIn('et_proposal.proposal_status', [0, 2])
//             ->where('et_customer.branch_id', $branch_id)
//             ->where('et_proposal.created_by', $staff->sno)
//             ->orderBy('et_proposal.created_at', 'asc') // Order by creation date, ascending
//             ->get();
//           $allLeadCount = count($allpostSaleData);
//           $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
//             ->where('et_lead.created_by', $staff->sno)
//             ->where('et_lead.branch_id', $branch_id)
//             ->whereYear('et_lead.registered_date', $year)
//             ->whereMonth('et_lead.registered_date', $month)
//             ->whereNotIn('et_lead.status', [2, 6])
//             ->where('et_lead.spam_verified', 0)
//             ->where('et_lead.drop_verified', 0)
//             ->where('et_lead.internal_status', 0)
//             ->count();
//           $hotLeadCount = DB::table('et_lead')->select('et_lead.sno')
//             ->where('et_lead.created_by', $staff->sno)
//             ->where('et_lead.branch_id', $branch_id)
//             ->whereYear('et_lead.registered_date', $year)
//             ->whereMonth('et_lead.registered_date', $month)
//             ->whereNotIn('et_lead.status', [2, 6])
//             ->where('et_lead.lead_status_id', 3)
//             ->where('et_lead.internal_status', 0)
//             ->where('et_lead.spam_verified', 0)
//             ->where('et_lead.drop_verified', 0)
//             ->count();
//           $customerConvertData = DB::table('et_customer')
//             ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_customer.cus_name')
//             ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//             ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
//             ->join('et_payment', function ($join) {
//               $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
//                 ->whereRaw('et_payment.transaction_date = (
//                          SELECT MIN(ep.transaction_date)
//                          FROM et_payment ep
//                          WHERE ep.proposal_id = et_proposal.sno
//                      )');
//             })
//             ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
//             ->where('et_customer.status', 0)
//             ->where('et_customer.post_sale_check', 1)
//             ->where('et_proposal.post_sale_check', 1)
//             ->where('et_customer.branch_id', $branch_id)
//             ->where('et_proposal.created_by', $staff->sno)
//             ->whereYear('et_payment.transaction_date', $year)
//             ->whereMonth('et_payment.transaction_date', $month)
//             ->where('et_transaction.payment_status', 1)
//             ->orderBy('et_customer.sno', 'asc')
//             ->get();
//           $customerConvertCount = count($customerConvertData);
//           $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
//             ->whereYear('et_lead.registered_date', $year)
//             ->whereMonth('et_lead.registered_date', $month)
//             ->where('et_lead.created_by', $staff->sno)
//             ->where('et_lead.spam_verified', 1)
//             ->where('et_lead.branch_id', $branch_id)
//             ->where('et_lead.status', 7)->count();
//           $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
//             ->whereYear('et_lead.registered_date', $year)
//             ->whereMonth('et_lead.registered_date', $month)
//             ->where('et_lead.created_by', $staff->sno)
//             ->where('et_lead.drop_verified', 1)
//             ->where('et_lead.branch_id', $branch_id)
//             ->where('et_lead.status', 5)->count();
//           // Spam Ratio 
//           $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
//           $spam_lead_ratio = number_format($spam_lead_ratio > 100 ? 100 : $spam_lead_ratio, 2);

//           // Dead ratio
//           $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
//           $dead_lead_ratio      = number_format($dead_lead_ratio > 100 ? 100 : $dead_lead_ratio, 2);

//           // customer ratio
//           $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
//           $convertion_rate = number_format($convertion_rate, 2);

//           //acr
//           $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
//           $averager_convertion_rate =  number_format($averager_convertion_rate > 100 ? 100 : $averager_convertion_rate, 2);
//           $total_payment             = 0;
//           $total_paid_payment        = 0;

//           $base_amount_paid = 0; // keep track of GST-excluded total

//           $gst_percent = 18;


//           if ($customerConvertCount > 0) {
//             $currentMonthCustomer = $customerConvertData;
//             if ($currentMonthCustomer->isNotEmpty()) {
//               foreach ($currentMonthCustomer as $customer) {
//                 $proposal_ids = DB::table('et_proposal')
//                   ->where('et_proposal.customer_id', $customer->sno)
//                   ->where('et_proposal.status', 0)
//                   ->where('et_proposal.post_sale_check', 1)
//                   ->whereYear('et_proposal.estimate_date', $year)
//                   ->whereMonth('et_proposal.estimate_date', $month)
//                   ->whereNotIn('et_proposal.proposal_status', [0, 2])
//                   ->pluck('sno')
//                   ->toArray();

//                 $proposals = DB::table('et_proposal')
//                   ->select('et_proposal.*', 'et_country_currencies.currency_code')
//                   ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//                   ->whereIn('et_proposal.sno', $proposal_ids)
//                   ->get();

//                 foreach ($proposals as $proposal) {
//                   // Paid slots for this proposal
//                   $paidAmount = DB::table('et_proposal_pay_slot')
//                     ->where('proposal_sno', $proposal->sno)
//                     ->where('status', 0)
//                     ->sum('paidAmount');

//                   $grantAmount = $proposal->grant_total_amount;

//                   // First remove GST from paidAmount (base value in proposal's currency)
//                   $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

//                   if ($proposal->currency_id == 70) {
//                     // INR: add directly
//                     $total_paid_payment += $paidAmount;
//                     $total_payment += $grantAmount;
//                     $base_amount_paid += $basePaidLocal;
//                   } else {
//                     // Non-INR: convert both amounts and base value
//                     $currency_code = $proposal->currency_code;
//                     $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
//                     $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
//                     $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
//                   }
//                 }
//               }
//             }

//             $totalAllPayment += $total_payment;
//             $totalAllPaidPayment += $base_amount_paid;
//           }

//           // total cal
//           $totalAllLead             += $allLeadCount;
//           $totalMonthLead            += $monthLeadCount;
//           $totalHotLead        += $hotLeadCount;
//           $totalDepartmentConvertCustomer            += $customerConvertCount;
//           $totalSpamLead      += $spamLeadCount;
//           $totalDeadLead    += $deadLeadCount;
//         }

//         $totalDepartmentBusinessValue   = $totalDepartmentConvertCustomer > 0 ? $totalAllPayment / $totalDepartmentConvertCustomer : 0;
//         $totalDepartmentCollectionValue = $totalDepartmentConvertCustomer > 0 ? $totalAllPaidPayment / $totalDepartmentConvertCustomer : 0;
//         // Conversion Rate
//         $convertion_rate = $totalMonthLead > 0 ? ($totalDepartmentConvertCustomer / $totalMonthLead) * 100 : 0;
//         $totalConvertRatio = number_format($convertion_rate, 2);
//         // Prepare goal details response

//         // Update team goals in transaction
//         DB::transaction(function () use ($team, $totalDepartmentConvertCustomer, $totalConvertRatio, $totalDepartmentBusinessValue, $totalDepartmentCollectionValue, &$inserted_records) {
//           $team->conversion_actual = $totalDepartmentConvertCustomer;
//           $team->cr_actual = $totalConvertRatio;
//           $team->abv_actual = $totalDepartmentBusinessValue;
//           $team->acv_actual = $totalDepartmentCollectionValue;
//           $team->goal_completed = 1;
//           $team->save();
//           $inserted_records++;
//         });
//       }
//       // ##############################################################################################
//       // ******************************** Production Department Department ****************************
//       // ##############################################################################################
//       if ($team->department_id == 2) {
//         $working_hoursActual = 0;
//         $rework_countActual = 0;
//         $salesStaff = $staffs;
//         $helper = new \App\Helpers\Helpers();
//         foreach ($salesStaff as $member) {
//           $working_hour = DB::table('et_task_log')
//             ->where('et_task_log.branch_id', $branch_id)
//             ->whereYear('et_task_log.end_time', $year)
//             ->whereMonth('et_task_log.end_time', $month)
//             ->where('et_task_log.status', 1)
//             ->where('et_task_log.staff_id', $member->sno)
//             ->sum(DB::raw('TIME_TO_SEC(duration)'));

//           $working_hoursActual += $working_hour / 3600;

//           $rework_count = DB::table('et_daily_tasks')
//             ->whereYear('et_daily_tasks.task_date', $year)
//             ->whereMonth('et_daily_tasks.task_date', $month)
//             ->where('et_daily_tasks.rework_check', 1)
//             ->where('et_daily_tasks.staff_id', $member->sno)
//             ->count();

//           $rework_countActual += $rework_count;
//         }

//         // Update team goals in transaction
//         DB::transaction(function () use ($team, $rework_countActual, $working_hoursActual, &$inserted_records) {
//           $team->working_hours_actual = $working_hoursActual;
//           $team->rework_actual = $rework_countActual;
//           $team->goal_completed = 1;
//           $team->save();
//           $inserted_records++;
//         });
//       }
//     }

//     // ##############################################################################################
//     // ******************************** Cronjob Monitor End ****************************************
//     // ##############################################################################################

//     $end_time = microtime(true);
//     $execution_time = round($end_time - $start_time, 4);
//     $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
//     $duration = gmdate("H:i:s", $execution_time);

//     // Update monitor
//     if ($monitor) {
//       $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
//       $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
//       $monitor->sync_duration        = $duration;
//       $monitor->running_status       = 0;
//       $monitor->save();

//       CronjobLogModel::create([
//         'cronjob_id'           => $monitor->sno,
//         'sync_start_date_time' => $startDateTime->format('Y-m-d H:i:s'),
//         'sync_end_date_time'   => $endDateTime->format('Y-m-d H:i:s'),
//         'sync_duration'        => $duration,
//         'response'             => json_encode([
//           'processed_records' => $inserted_records,
//           'execution_time'    => $duration,
//         ]),
//         'created_by' => 0,
//         'updated_by' => 0,
//       ]);
//     }

//     return [
//       'processed_records' => $inserted_records,
//       'execution_time' => $execution_time . ' seconds'
//     ];
//   }



  public function JournalToHistory()
  {
    $journals = DB::table('et_manage_journal')
      ->where('status', '!=', 2)
      ->get();

    $count = 0;

    foreach ($journals as $jl) {

      // Check if this record already exists in history
      $exists = JournalHistoryModel::where([
        ['branch_id', $jl->branch_id],
        ['customer_id', $jl->customer_id],
        ['service_id', $jl->service_id],
        ['journal_id', $jl->sno],
      ])->exists();

      // If already exists → skip
      if ($exists) {
        continue;
      }

      // Insert only non-duplicate
      JournalHistoryModel::create([
        'branch_id'            => $jl->branch_id,
        'customer_id'          => $jl->customer_id,
        'service_id'           => $jl->service_id,
        'journal_id'           => $jl->sno,
        'submitted_date'       => $jl->submited_date,
        'submitted_documents'  => $jl->documents,
        'created_by'           => $jl->created_by,
        'updated_by'           => $jl->updated_by,
        'created_at'           => $jl->created_at,
        'updated_at'           => $jl->updated_at,
      ]);

      $count++;
    }

    return "Inserted $count non-duplicate records.";
  }




//   public function Cronjob_staff_goal_set_update(Request $request)
//   {
//     $month = (int)($request->month_ids ?? date('m'));
//     $year  = (int)($request->year_ids ?? date('Y'));
//     $today_day = (int)($request->date_ids ?? date('d'));
//     $recalculate = (int)($request->recalculate ?? 0);

//     $helper = new \App\Helpers\Helpers();
    

//     // ##############################################################################################
//     // ******************************** Cronjob Monitor End ****************************************
//     // ##############################################################################################
//     // Run Which We need month Year date Link
//     // http://192.168.3.94:8090/Cronjob_staff_goal_set_update?month_ids=11&date_ids=31&year_ids=2025?&recalculate=0


//     $monitor = CronjobMonitorModel::where('sno', 11)->first();
//     $start_time = microtime(true);
//     $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

//     if ($monitor && $monitor->status != 0) {
//       return response()->json([
//         'success' => false,
//         'message' => 'Cronjob status Off'
//       ]);
//     }

//     if ($monitor) {
//       $monitor->running_status = 1;
//       $monitor->save();
//     }

//     $goalsetteam = GoalSetTeamModel::where('et_goal_set_team.team_goal_month', $month)
//       ->where('et_goal_set_team.team_goal_year', $year)
//       ->first();
//     // Get goal records for the selected department and month
//     $goalsetRecords = GoalSetStaffModel::whereMonth('et_goal_set_staff.goal_date', $month)
//       ->whereYear('et_goal_set_staff.goal_date', $year)
//       ->where('et_goal_set_staff.goal_completed', $recalculate)
//       ->get();

//     foreach ($goalsetRecords as $team) {

//       $branch = DB::table('et_branch')
//         ->select('sno', 'bus_closing_day_count', 'bus_closing_month_end')
//         ->where('sno', $team->branch_id)
//         ->first();

//       $close_day = $branch->bus_closing_month_end == 1 ? (int)date('t') : ($branch->bus_closing_day_count ?? 25);

//       // Skip if today is not goal close day
//       if ($today_day != $close_day) continue;

//       $staffs = StaffModel::where('branch_id', $team->branch_id)
//         ->where('department_id', $team->department_id)
//         ->where('status', 0)
//         ->where('sno', $team->staff_id)
//         ->select('sno', 'basic_salary')
//         ->get();

//       $inserted_records = 0;
//       $staff_ids = $staffs->pluck('sno')->toArray();
//       $branch_id = $team->branch_id;
//       // ##############################################################################################
//       // ******************************** PRE Sale Department ****************************************
//       // ##############################################################################################
//       $totalAllPayment = 0;
//       $totalAllPaidPayment = 0;
//       if ($team->department_id == 1) {
//         // Attach goal details to staff members
//         $staffDetails = [];
//         $values = [];
//         foreach ($staffs as $member) {

//           $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
//             ->where('et_lead.created_by', $member->sno)
//             ->where('et_lead.branch_id', $branch_id)
//             ->whereNotIn('et_lead.status', [2, 6])
//             ->where('et_lead.spam_verified', 0)
//             ->where('et_lead.drop_verified', 0)
//             ->where('et_lead.internal_status', 0)
//             ->count();

//           $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
//             ->where('et_lead.created_by', $member->sno)
//             ->where('et_lead.branch_id', $branch_id)
//             ->whereYear('et_lead.registered_date', $year)
//             ->whereMonth('et_lead.registered_date', $month)
//             ->whereNotIn('et_lead.status', [2, 6])
//             ->where('et_lead.spam_verified', 0)
//             ->where('et_lead.drop_verified', 0)
//             ->where('et_lead.internal_status', 0)
//             ->count();

//           $customerConvertCount =  DB::table('et_customer')
//             ->select('et_customer.sno', 'et_customer.proposal_ids')
//             ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//             ->join('et_payment', function ($join) {
//               $join->on('et_payment.customer_id', '=', 'et_customer.sno')
//                 ->whereRaw('et_payment.transaction_date = (
//                      SELECT MIN(ep.transaction_date)
//                      FROM et_payment ep
//                      WHERE ep.customer_id = et_customer.sno
//                  )');
//             })
//             ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
//             // ->where('et_customer.status', 0)
//             ->where('et_customer.branch_id', $branch_id)
//             ->where('et_lead.created_by', $member->sno)
//             ->whereYear('et_payment.transaction_date', $year)
//             //  ->whereDay('et_payment.transaction_date', $day) // Use `whereDay` instead of `whereDate`
//             ->whereMonth('et_payment.transaction_date', $month)
//             ->where('et_transaction.payment_status', 1)
//             // ->orderBy('et_customer.sno', 'asc')
//             ->count();

//           $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
//             ->whereYear('et_lead.registered_date', $year)
//             ->whereMonth('et_lead.registered_date', $month)
//             ->where('et_lead.created_by', $member->sno)
//             ->where('et_lead.spam_verified', 1)
//             ->where('et_lead.branch_id', $branch_id)
//             ->where('et_lead.status', 7)->count();

//           $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
//             ->whereYear('et_lead.registered_date', $year)
//             ->whereMonth('et_lead.registered_date', $month)
//             ->where('et_lead.created_by', $member->sno)
//             ->where('et_lead.drop_verified', 1)
//             ->where('et_lead.branch_id', $branch_id)
//             ->where('et_lead.status', 5)->count();

//           $monthFollowupCount = DB::table('et_appointment')
//             ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
//             ->whereIn('et_lead.status', [0, 4])
//             ->where('et_appointment.created_by', $member->sno)
//             ->whereYear('et_appointment.appointment_date', $year)
//             ->whereMonth('et_appointment.appointment_date', $month)
//             ->count();
//           $monthwalkincount = DB::table('et_lead_appointment')
//             ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
//             ->where('et_lead_appointment.appointment_category', 3) // Fixed the table reference
//             ->where('et_lead_appointment.created_by', $member->sno)
//             ->whereYear('et_lead_appointment.appointment_date', $year)
//             ->whereMonth('et_lead_appointment.appointment_date', $month)
//             ->count();

//           $monthcall_out = DB::table('et_call_tracker')
//             ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
//             ->whereYear('call_start_date', $year)
//             ->whereMonth('call_start_date', $month)
//             ->where('et_call_tracker.branch_id', $branch_id)
//             ->where('et_call_tracker.branch_staff_id', $member->sno)
//             ->first();
//           $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;
          
//           $startDate = Carbon::create($year, $month, 1);
//           $currentDate = Carbon::now();
//           $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
//           $dayCounts3 = $startDate->diffInDays($endDate) + 1;
 
//           $monthcall_out = $dayCounts3 > 0  ? round($monthcall_out / ($dayCounts3)) : 0;
//           $monthFollowupCount = $dayCounts3 > 0  ? round($monthFollowupCount / ($dayCounts3)) : 0;
          
//           // Spam Ratio 
//           $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
//           $spam_lead_ratio = number_format($spam_lead_ratio, 2);
//           // Dead ratio
//           $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
//           $dead_lead_ratio      = number_format($dead_lead_ratio, 2);
//           // customer ratio
//           $convertion_rates = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
//           $convertion_rate = number_format($convertion_rates, 2);
//           //acr
//           $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
//           $averager_convertion_rate = number_format($averager_convertion_rate, 2);
//           $total_payment             = 0;
//           $total_paid_payment        = 0;
//           $averageBusinessValue      = 0;
//           $averageCollectionValue    = 0;


//           $base_amount_paid = 0; // keep track of GST-excluded total
//           $gst_percent = 18;

//           if ($customerConvertCount > 0) {
//             $currentMonthCustomer = DB::table('et_customer')
//               ->select('et_customer.sno', 'et_customer.proposal_ids')
//               ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//               ->join('et_payment', function ($join) {
//                 $join->on('et_payment.customer_id', '=', 'et_customer.sno')
//                   ->whereRaw('et_payment.transaction_date = (
//                          SELECT MIN(ep.transaction_date)
//                          FROM et_payment ep
//                          WHERE ep.customer_id = et_customer.sno
//                      )');
//               })
//               ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
//               ->where('et_customer.status', 0)
//               ->where('et_customer.branch_id', $branch_id)
//               ->where('et_lead.created_by', $member->sno)
//               ->whereYear('et_payment.transaction_date', $year)
//               ->whereMonth('et_payment.transaction_date', $month)
//               ->where('et_transaction.payment_status', 1)
//               ->orderBy('et_customer.sno', 'asc')
//               ->get();
//             $customerConvertCount = count($currentMonthCustomer);
//             // average 
//             $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
//             $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';
//             $totalAllPayment += $total_payment;
//             $totalAllPaidPayment += $total_paid_payment;
//           }
//           if ($customerConvertCount > 0) {
//             if ($currentMonthCustomer->isNotEmpty()) {
//               foreach ($currentMonthCustomer as $customer) {
//                 $proposal_ids = DB::table('et_proposal')
//                   ->where('et_proposal.customer_id', $customer->sno)
//                   ->where('et_proposal.status', 0)
//                   ->whereNot('et_proposal.post_sale_check', 1)
//                   ->whereNotIn('et_proposal.proposal_status', [0, 2])
//                   ->pluck('sno')
//                   ->toArray();
//                 // return $proposal_ids;

//                 $proposals = DB::table('et_proposal')
//                   ->select('et_proposal.*', 'et_country_currencies.currency_code')
//                   ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//                   ->whereIn('et_proposal.sno', $proposal_ids)
//                   ->get();

//                 foreach ($proposals as $proposal) {
//                   // Paid slots for this proposal
//                   $paidAmount = DB::table('et_proposal_pay_slot')
//                     ->where('proposal_sno', $proposal->sno)
//                     ->where('status', 0)
//                     ->sum('paidAmount');

//                   $grantAmount = $proposal->grant_total_amount;

//                   // First remove GST from paidAmount (base value in proposal's currency)
//                   $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

//                   if ($proposal->currency_id == 70) {
//                     // INR: add directly
//                     $total_paid_payment += $paidAmount;
//                     $total_payment += $grantAmount;
//                     $base_amount_paid += $basePaidLocal;
//                   } else {
//                     $currency_code = $proposal->currency_code;
//                     $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
//                     $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
//                     $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
//                   }
//                 }
//               }
//             }
//             // average 
//             $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
//             $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
//             $totalAllPayment += $total_payment;
//             $totalAllPaidPayment += $base_amount_paid;
//           }

//           $staffDetails2 = [
//             'conversion'                => $team->conversion ?? 0,
//             'conversion_actual'         => $customerConvertCount ?? 0,
//             'cr'                        => $team->CR ?? 0,
//             'cr_actual'                 => $convertion_rate ?? 0,
//             'abv'                       => isset($team->ABV) ? $team->ABV : 0,
//             'abv_actual'                => $averageBusinessValue ?? 0,
//             'acv'                       => isset($team->ACV) ? $team->ACV : 0,
//             'acv_actual'                => $averageCollectionValue ?? 0,
//             'avg_call_out'              => $team->avg_call_out ?? 0,
//             'avg_call_out_actual'       => $monthcall_out ?? 0,
//             'no_of_walk'                => $team->no_of_walk ?? 0,
//             'no_of_walk_actual'         => $monthwalkincount ?? 0,
//             'no_of_followup'            => $team->no_of_followup ?? 0,
//             'no_of_followup_actual'     => $monthFollowupCount ?? 0,
//           ];
//           $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
//           $goal_achievements = true;  // true = all 10X goals achieved
//           $staffAchieved = true;      // true = individual staff goals achieved
//           $allOverZero = true;        // true = all goals have zero target
//           $total_goal = 0;
//           $tot_actual_value = 0;
//           $actual_values = 0;
//           $values = [];

//           if (!empty($ten_x) && is_array($ten_x)) {
//             foreach ($ten_x as $key => $value) {
//               if ($value === "1") {
//                 $type2 = str_replace("_10x", "", $key);
//                 $goal_value = (float)($staffDetails2[$type2] ?? 0);
//                 $actual_value = (float)($staffDetails2[$type2 . '_actual'] ?? 0);

//                 // Track if any goal has non-zero target
//                 if ($goal_value > 0) {
//                   $allOverZero = false;
//                 }

//                 // Check individual goal achievement
//                 if ($goal_value > 0 && $actual_value < $goal_value) {
//                   $goal_achievements = false;
//                   $staffAchieved = false;
//                 }

//                 // Special case: No progress on valid goal
//                 if ($goal_value > 0 && $actual_value === 0) {
//                   $staffAchieved = false;
//                 }

//                 // Special case for rework (lower is better)
//                 if ($type2 === 'rework') {
//                   if ($goal_value > 0 && $actual_value > $goal_value) {
//                     $staffAchieved = false;
//                   }
//                 }

//                 if ($key == 'rework') {
//                   if ($actual_value >= $goal_value) {
//                     $actual_values = $goal_value;
//                   }
//                   $total_goal  += $goal_value;
//                   $tot_actual_value  += $actual_values;
//                 } else {
//                   if ($actual_value <= $goal_value) {
//                     $total_goal  += $goal_value;
//                     $tot_actual_value  += $goal_value;
//                   } else {
//                     $total_goal  += $goal_value;
//                     $tot_actual_value  += $actual_value;
//                   }
//                 }

//                 $values[] = [
//                   'type' => $type2,
//                   'goal' => $goal_value,
//                   'actual' => $actual_value,
//                   'achieved' => ($goal_value === 0 || $actual_value >= $goal_value)
//                 ];
//               }
//             }
//           }

//           // Final status determination (0=Not Assigned, 1=Achieved, 2=In Progress)
//           $goalsts = 0;

//           if ($goal_achievements && !$allOverZero) {
//             $goalsts = 1;  // All 10X goals achieved
//           } elseif (!$allOverZero) {
//             $goalsts = 2;  // In progress (some goals not met)
//           } // else: 0 (Not Assigned - all zeros)


//           // Determine final status
//           // return $values;
//           // Calculate achievement percentage (optional)
//           $achievement_percentage = $total_goal > 0 ? round(($tot_actual_value / $total_goal) * 100, 2) : 0;

//           $staffDetails = [
//             'conversion'                => $team->conversion ?? 0,
//             'conversion_actual'         => $customerConvertCount ?? 0,
//             'cr'                        => $team->CR ?? 0,
//             'cr_actual'                 => $convertion_rate ?? 0,
//             'abv'                       => isset($team->ABV) ? $team->ABV : 0,
//             'abv_actual'                => $averageBusinessValue ?? 0,
//             'acv'                       => isset($team->ACV) ? $team->ACV : 0,
//             'acv_actual'                => $averageCollectionValue ?? 0,
//             'avg_call_out'              => $team->avg_call_out ?? 0,
//             'avg_call_out_actual'       => $monthcall_out ?? 0,
//             'no_of_walk'                => $team->no_of_walk ?? 0,
//             'no_of_walk_actual'         => $monthwalkincount ?? 0,
//             'no_of_followup'            => $team->no_of_followup ?? 0,
//             'no_of_followup_actual'     => $monthFollowupCount ?? 0,
//             'goalset_percentage'        => $achievement_percentage ?? 0,
//             '10x_status'                => $goalsts ?? 0,
//           ];

//           // Update team goals in transaction
//           DB::transaction(function () use ($team, $staffDetails, &$inserted_records) {
//             $team->conversion_actual = $staffDetails['conversion_actual'];
//             $team->cr_actual = $staffDetails['cr_actual'];
//             $team->abv_actual = $staffDetails['abv_actual'];
//             $team->acv_actual = $staffDetails['acv_actual'];
//             $team->avg_call_out_actual = $staffDetails['avg_call_out_actual'];
//             $team->no_of_walk_actual = $staffDetails['no_of_walk_actual'];
//             $team->no_of_followup_actual = $staffDetails['no_of_followup_actual'];
//             $team->no_of_followup_actual = $staffDetails['no_of_followup_actual'];
//             $team->status_10x = $staffDetails['10x_status'];
//             $team->goalset_percentage = $staffDetails['goalset_percentage'];
//             $team->goal_completed = 1;
//             $team->save();
//             $inserted_records++;
//           });
//         }
//       }
//       // ##############################################################################################
//       // ******************************** Post Sale Department ****************************************
//       // ##############################################################################################
//       if ($team->department_id == 15) {
//         // return 'Post Sale Department'; 
//         $salesStaff = $staffs;
//         $totalAllPayment             = 0;
//         $totalAllPaidPayment        = 0;
//         $helper = new \App\Helpers\Helpers();
//         foreach ($salesStaff as $member) {
//           $allpostSaleData = DB::table('et_customer')
//             ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_proposal.post_sale_date')
//             ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//             ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
//             ->where('et_customer.status', 0)
//             ->where('et_customer.post_sale_check', 1)
//             ->where('et_proposal.post_sale_check', 1)
//             ->whereNotIn('et_proposal.proposal_status', [0, 2])
//             ->where('et_customer.branch_id', $branch_id)
//             ->where('et_proposal.created_by', $member->sno)
//             ->orderBy('et_proposal.created_at', 'asc') // Order by creation date, ascending
//             ->get();
//           $allLeadCount = count($allpostSaleData);
//           $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
//             ->where('et_lead.created_by', $member->sno)
//             ->where('et_lead.branch_id', $branch_id)
//             ->whereYear('et_lead.registered_date', $year)
//             ->whereMonth('et_lead.registered_date', $month)
//             ->whereNotIn('et_lead.status', [2, 6])
//             ->where('et_lead.spam_verified', 0)
//             ->where('et_lead.drop_verified', 0)
//             ->where('et_lead.internal_status', 0)
//             ->count();
//           $customerConvertData = DB::table('et_customer')
//             ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_customer.cus_name')
//             ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//             ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
//             ->join('et_payment', function ($join) {
//               $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
//                 ->whereRaw('et_payment.transaction_date = (
//                          SELECT MIN(ep.transaction_date)
//                          FROM et_payment ep
//                          WHERE ep.proposal_id = et_proposal.sno
//                      )');
//             })
//             ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
//             ->where('et_customer.status', 0)
//             ->where('et_customer.post_sale_check', 1)
//             ->where('et_proposal.post_sale_check', 1)
//             ->where('et_customer.branch_id', $branch_id)
//             ->where('et_proposal.created_by', $member->sno)
//             ->whereYear('et_payment.transaction_date', $year)
//             ->whereMonth('et_payment.transaction_date', $month)
//             ->where('et_transaction.payment_status', 1)
//             ->orderBy('et_customer.sno', 'asc')
//             ->get();
//           $customerConvertCount = count($customerConvertData);
//           $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
//             ->whereYear('et_lead.registered_date', $year)
//             ->whereMonth('et_lead.registered_date', $month)
//             ->where('et_lead.created_by', $member->sno)
//             ->where('et_lead.spam_verified', 1)
//             ->where('et_lead.branch_id', $branch_id)
//             ->where('et_lead.status', 7)->count();
//           $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
//             ->whereYear('et_lead.registered_date', $year)
//             ->whereMonth('et_lead.registered_date', $month)
//             ->where('et_lead.created_by', $member->sno)
//             ->where('et_lead.drop_verified', 1)
//             ->where('et_lead.branch_id', $branch_id)
//             ->where('et_lead.status', 5)->count();
//           // Spam Ratio 
//           $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
//           $spam_lead_ratio = number_format($spam_lead_ratio > 100 ? 100 : $spam_lead_ratio, 2);

//           // Dead ratio
//           $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
//           $dead_lead_ratio      = number_format($dead_lead_ratio > 100 ? 100 : $dead_lead_ratio, 2);

//           // customer ratio
//           $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
//           $convertion_rate = number_format($convertion_rate, 2);

//           //acr
//           $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
//           $averager_convertion_rate =  number_format($averager_convertion_rate > 100 ? 100 : $averager_convertion_rate, 2);
//           $total_payment             = 0;
//           $total_paid_payment        = 0;

//           $base_amount_paid = 0; // keep track of GST-excluded total

//           $gst_percent = 18;


//           if ($customerConvertCount > 0) {
//             $currentMonthCustomer = $customerConvertData;
//             if ($currentMonthCustomer->isNotEmpty()) {
//               foreach ($currentMonthCustomer as $customer) {
//                 $proposal_ids = DB::table('et_proposal')
//                   ->where('et_proposal.customer_id', $customer->sno)
//                   ->where('et_proposal.status', 0)
//                   ->where('et_proposal.post_sale_check', 1)
//                   ->whereYear('et_proposal.estimate_date', $year)
//                   ->whereMonth('et_proposal.estimate_date', $month)
//                   ->whereNotIn('et_proposal.proposal_status', [0, 2])
//                   ->pluck('sno')
//                   ->toArray();

//                 $proposals = DB::table('et_proposal')
//                   ->select('et_proposal.*', 'et_country_currencies.currency_code')
//                   ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//                   ->whereIn('et_proposal.sno', $proposal_ids)
//                   ->get();

//                 foreach ($proposals as $proposal) {
//                   // Paid slots for this proposal
//                   $paidAmount = DB::table('et_proposal_pay_slot')
//                     ->where('proposal_sno', $proposal->sno)
//                     ->where('status', 0)
//                     ->sum('paidAmount');

//                   $grantAmount = $proposal->grant_total_amount;

//                   // First remove GST from paidAmount (base value in proposal's currency)
//                   $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

//                   if ($proposal->currency_id == 70) {
//                     // INR: add directly
//                     $total_paid_payment += $paidAmount;
//                     $total_payment += $grantAmount;
//                     $base_amount_paid += $basePaidLocal;
//                   } else {
//                     // Non-INR: convert both amounts and base value
//                     $currency_code = $proposal->currency_code;
//                     $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
//                     $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
//                     $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
//                   }
//                 }
//               }
//             }

//             $totalAllPayment += $total_payment;
//             $totalAllPaidPayment += $base_amount_paid;
//           }

//           $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
//           $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;


//           $startDate = Carbon::create($year, $month, 1);
//           $currentDate = Carbon::now();
//           $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
//           $dayCount = $startDate->diffInDays($endDate) + 1;


//           $staffDetails2 = [
//             'conversion'                => $team->conversion ?? 0,
//             'conversion_actual'         => $customerConvertCount ?? 0,
//             'cr'                        => $team->CR ?? 0,
//             'cr_actual'                 => $convertion_rate ?? 0,
//             'abv'                       => isset($team->ABV) ? $team->ABV : 0,
//             'abv_actual'                => $averageBusinessValue ?? 0,
//             'acv'                       => isset($team->ACV) ? $team->ACV : 0,
//             'acv_actual'                => $averageCollectionValue ?? 0,
//           ];

//           $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
//           $goal_achievements = true;  // true = all 10X goals achieved
//           $staffAchieved = true;      // true = individual staff goals achieved
//           $allOverZero = true;        // true = all goals have zero target
//           $total_goal = 0;
//           $tot_actual_value = 0;
//           $actual_values = 0;
//           $values = [];

//           if (!empty($ten_x) && is_array($ten_x)) {
//             foreach ($ten_x as $key => $value) {
//               if ($value === "1") {
//                 $type2 = str_replace("_10x", "", $key);
//                 $goal_value = (float)($staffDetails2[$type2] ?? 0);
//                 $actual_value = (float)($staffDetails2[$type2 . '_actual'] ?? 0);

//                 // Track if any goal has non-zero target
//                 if ($goal_value > 0) {
//                   $allOverZero = false;
//                 }

//                 // Check individual goal achievement
//                 if ($goal_value > 0 && $actual_value < $goal_value) {
//                   $goal_achievements = false;
//                   $staffAchieved = false;
//                 }

//                 // Special case: No progress on valid goal
//                 if ($goal_value > 0 && $actual_value === 0) {
//                   $staffAchieved = false;
//                 }

//                 // Special case for rework (lower is better)
//                 if ($type2 === 'rework') {
//                   if ($goal_value > 0 && $actual_value > $goal_value) {
//                     $staffAchieved = false;
//                   }
//                 }

//                 if ($key == 'rework') {
//                   if ($actual_value >= $goal_value) {
//                     $actual_values = $goal_value;
//                   }
//                   $total_goal  += $goal_value;
//                   $tot_actual_value  += $actual_values;
//                 } else {
//                   if ($actual_value <= $goal_value) {
//                     $total_goal  += $goal_value;
//                     $tot_actual_value  += $goal_value;
//                   } else {
//                     $total_goal  += $goal_value;
//                     $tot_actual_value  += $actual_value;
//                   }
//                 }

//                 $values[] = [
//                   'type' => $type2,
//                   'goal' => $goal_value,
//                   'actual' => $actual_value,
//                   'achieved' => ($goal_value === 0 || $actual_value >= $goal_value)
//                 ];
//               }
//             }
//           }

//           // Final status determination (0=Not Assigned, 1=Achieved, 2=In Progress)
//           $goalsts = 0;

//           if ($goal_achievements && !$allOverZero) {
//             $goalsts = 1;  // All 10X goals achieved
//           } elseif (!$allOverZero) {
//             $goalsts = 2;  // In progress (some goals not met)
//           } // else: 0 (Not Assigned - all zeros)


//           // Determine final status
//           // return $values;
//           // Calculate achievement percentage (optional)
//           $achievement_percentage = $total_goal > 0 ? round(($tot_actual_value / $total_goal) * 100, 2) : 0;

//           $staffDetails = [
//             'conversion'                => $team->conversion ?? 0,
//             'conversion_actual'         => $customerConvertCount ?? 0,
//             'cr'                        => $team->CR ?? 0,
//             'cr_actual'                 => $convertion_rate ?? 0,
//             'abv'                       => isset($team->ABV) ? $team->ABV : 0,
//             'abv_actual'                => $averageBusinessValue ?? 0,
//             'abv_actual'                => $averageBusinessValue ?? 0,
//             'acv'                       => isset($team->ACV) ? $team->ACV : 0,
//             'acv_actual'                => $averageCollectionValue ?? 0,
//             'goalset_percentage'        => $achievement_percentage ?? 0,
//             '10x_status'                => $goalsts ?? 0,
//           ];

//           // Update team goals in transaction
//           DB::transaction(function () use ($team, $staffDetails, &$inserted_records) {
//             $team->conversion_actual = $staffDetails['conversion_actual'];
//             $team->cr_actual = $staffDetails['cr_actual'];
//             $team->abv_actual = $staffDetails['abv_actual'];
//             $team->acv_actual = $staffDetails['acv_actual'];
//             $team->status_10x = $staffDetails['10x_status'];
//             $team->goalset_percentage = $staffDetails['goalset_percentage'];
//             $team->goal_completed = 1;
//             $team->save();
//             $inserted_records++;
//           });
//         }
//       }

//       // ##############################################################################################
//       // ******************************** Production Department Department ****************************
//       // ##############################################################################################

//       if ($team->department_id == 2) {
//         $salesStaff = $staffs;
//         $helper = new \App\Helpers\Helpers();
//         foreach ($salesStaff as $member) {
//           $working_hour = DB::table('et_task_log')
//             ->where('et_task_log.branch_id', $branch_id)
//             ->whereYear('et_task_log.end_time', $year)
//             ->whereMonth('et_task_log.end_time', $month)
//             ->where('et_task_log.status', 1)
//             ->where('et_task_log.staff_id', $member->sno)
//             ->sum(DB::raw('TIME_TO_SEC(duration)'));

//           $working_hoursActual = $working_hour / 3600;

//           $rework_count = DB::table('et_daily_tasks')
//             ->whereYear('et_daily_tasks.task_date', $year)
//             ->whereMonth('et_daily_tasks.task_date', $month)
//             ->where('et_daily_tasks.rework_check', 1)
//             ->where('et_daily_tasks.staff_id', $member->sno)
//             ->count();


//           $staffDetails2 = [
//             'rework'                    => $team->rework ?? 0,
//             'rework_actual'             => $rework_count ?? 0,
//             'working_hours'             => $team->working_hours ?? 0,
//             'working_hours_actual'      => $working_hoursActual ?? 0,
//           ];

//           $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
//           $goal_achievements = true;  // true = all 10X goals achieved
//           $staffAchieved = true;      // true = individual staff goals achieved
//           $allOverZero = true;        // true = all goals have zero target
//           $total_goal = 0;
//           $tot_actual_value = 0;
//           $actual_values = 0;
//           $values = [];

//           if (!empty($ten_x) && is_array($ten_x)) {
//             foreach ($ten_x as $key => $value) {
//               if ($value === "1") {
//                 $type2 = str_replace("_10x", "", $key);
//                 $goal_value = (float)($staffDetails2[$type2] ?? 0);
//                 $actual_value = (float)($staffDetails2[$type2 . '_actual'] ?? 0);

//                 // Track if any goal has non-zero target
//                 if ($goal_value > 0) {
//                   $allOverZero = false;
//                 }

//                 // Check individual goal achievement
//                 if ($goal_value > 0 && $actual_value < $goal_value) {
//                   $goal_achievements = false;
//                   $staffAchieved = false;
//                 }

//                 // Special case: No progress on valid goal
//                 if ($goal_value > 0 && $actual_value === 0) {
//                   $staffAchieved = false;
//                 }

//                 // Special case for rework (lower is better)
//                 if ($type2 === 'rework') {
//                   if ($goal_value > 0 && $actual_value > $goal_value) {
//                     $staffAchieved = false;
//                   }
//                 }

//                 if ($key == 'rework') {
//                   if ($actual_value >= $goal_value) {
//                     $actual_values = $goal_value;
//                   }
//                   $total_goal  += $goal_value;
//                   $tot_actual_value  += $actual_values;
//                 } else {
//                   if ($actual_value <= $goal_value) {
//                     $total_goal  += $goal_value;
//                     $tot_actual_value  += $goal_value;
//                   } else {
//                     $total_goal  += $goal_value;
//                     $tot_actual_value  += $actual_value;
//                   }
//                 }

//                 $values[] = [
//                   'type' => $type2,
//                   'goal' => $goal_value,
//                   'actual' => $actual_value,
//                   'achieved' => ($goal_value === 0 || $actual_value >= $goal_value)
//                 ];
//               }
//             }
//           }

//           // Final status determination (0=Not Assigned, 1=Achieved, 2=In Progress)
//           $goalsts = 0;

//           if ($goal_achievements && !$allOverZero) {
//             $goalsts = 1;  // All 10X goals achieved
//           } elseif (!$allOverZero) {
//             $goalsts = 2;  // In progress (some goals not met)
//           } // else: 0 (Not Assigned - all zeros)


//           // Determine final status
//           // return $values;
//           // Calculate achievement percentage (optional)
//           $achievement_percentage = $total_goal > 0 ? round(($tot_actual_value / $total_goal) * 100, 2) : 0;

//           $staffDetails = [
//             'rework'                    => $team->rework ?? 0,
//             'rework_actual'             => $rework_count ?? 0,
//             'working_hours'             => $team->working_hours ?? 0,
//             'working_hours_actual'      => $working_hoursActual ?? 0,
//             'goalset_percentage'        => $achievement_percentage ?? 0,
//             '10x_status'                => $goalsts ?? 0,
//           ];
//           // Update team goals in transaction
//           DB::transaction(function () use ($team, $staffDetails, &$inserted_records) {
//             $team->rework_actual = $staffDetails['rework_actual'];
//             $team->working_hours_actual = $staffDetails['working_hours_actual'];
//             $team->status_10x = $staffDetails['10x_status'];
//             $team->goalset_percentage = $staffDetails['goalset_percentage'];
//             $team->goal_completed = 1;
//             $team->save();
//             $inserted_records++;
//           });
//         }
//       }

//       // ##############################################################################################
//       // ******************************** Journal Department ******************************************
//       // ##############################################################################################
//       if ($team->department_id == 14) {
//         $salesStaff = $staffs;
//         $no_of_papers_countActual = 0;
//         $helper = new \App\Helpers\Helpers();
//         foreach ($salesStaff as $member) {

//           if (in_array($member->role_id, [33, 34])) {
//             $field = $member->role_id == 33 ? 'jc_id' : 'jc_staff';

//             $pub_count = DB::table('et_customer_services')
//               ->join('et_manage_journal', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
//               ->whereYear('et_manage_journal.published_at', $year)
//               ->whereMonth('et_manage_journal.published_at', $month)
//               ->where('et_manage_journal.status', 6)
//               ->where("et_customer_services.{$field}", $member->sno)
//               ->count();

//             $acp_count = DB::table('et_customer_services')
//               ->join('et_manage_journal', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
//               ->whereYear('et_manage_journal.accepted_at', $year)
//               ->whereMonth('et_manage_journal.accepted_at', $month)
//               ->where('et_manage_journal.status', 4)
//               ->where("et_customer_services.{$field}", $member->sno)
//               ->count();

//             $no_of_papers_countActual += $pub_count + $acp_count;
//           }


//           $staffDetails2 = [
//             'no_of_papers'                    => $goalsetData[$member->sno]->no_of_papers ?? 0,
//             'no_of_papers_actual'             => $no_of_papers_countActual ?? 0,
//           ];


//           $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
//           $goal_achievements = true;  // true = all 10X goals achieved
//           $staffAchieved = true;      // true = individual staff goals achieved
//           $allOverZero = true;        // true = all goals have zero target
//           $total_goal = 0;
//           $tot_actual_value = 0;
//           $actual_values = 0;
//           $values = [];

//           if (!empty($ten_x) && is_array($ten_x)) {
//             foreach ($ten_x as $key => $value) {
//               if ($value === "1") {
//                 $type2 = str_replace("_10x", "", $key);
//                 $goal_value = (float)($staffDetails2[$type2] ?? 0);
//                 $actual_value = (float)($staffDetails2[$type2 . '_actual'] ?? 0);

//                 // Track if any goal has non-zero target
//                 if ($goal_value > 0) {
//                   $allOverZero = false;
//                 }

//                 // Check individual goal achievement
//                 if ($goal_value > 0 && $actual_value < $goal_value) {
//                   $goal_achievements = false;
//                   $staffAchieved = false;
//                 }

//                 // Special case: No progress on valid goal
//                 if ($goal_value > 0 && $actual_value === 0) {
//                   $staffAchieved = false;
//                 }

//                 // Special case for rework (lower is better)
//                 if ($type2 === 'rework') {
//                   if ($goal_value > 0 && $actual_value > $goal_value) {
//                     $staffAchieved = false;
//                   }
//                 }

//                 if ($key == 'rework') {
//                   if ($actual_value >= $goal_value) {
//                     $actual_values = $goal_value;
//                   }
//                   $total_goal  += $goal_value;
//                   $tot_actual_value  += $actual_values;
//                 } else {
//                   if ($actual_value <= $goal_value) {
//                     $total_goal  += $goal_value;
//                     $tot_actual_value  += $goal_value;
//                   } else {
//                     $total_goal  += $goal_value;
//                     $tot_actual_value  += $actual_value;
//                   }
//                 }

//                 $values[] = [
//                   'type' => $type2,
//                   'goal' => $goal_value,
//                   'actual' => $actual_value,
//                   'achieved' => ($goal_value === 0 || $actual_value >= $goal_value)
//                 ];
//               }
//             }
//           }

//           // Final status determination (0=Not Assigned, 1=Achieved, 2=In Progress)
//           $goalsts = 0;

//           if ($goal_achievements && !$allOverZero) {
//             $goalsts = 1;  // All 10X goals achieved
//           } elseif (!$allOverZero) {
//             $goalsts = 2;  // In progress (some goals not met)
//           } // else: 0 (Not Assigned - all zeros)


//           // Determine final status
//           // return $values;
//           // Calculate achievement percentage (optional)
//           $achievement_percentage = $total_goal > 0 ? round(($tot_actual_value / $total_goal) * 100, 2) : 0;

//           $staffDetails = [
//             'no_of_papers_actual'      => $no_of_papers_countActual ?? 0,
//             'goalset_percentage'        => $achievement_percentage ?? 0,
//             '10x_status'                => $goalsts ?? 0,
//           ];
//           // Update team goals in transaction
//           DB::transaction(function () use ($team, $staffDetails, &$inserted_records) {
//             $team->no_of_papers_actual = $staffDetails['no_of_papers_actual'];
//             $team->status_10x = $staffDetails['10x_status'];
//             $team->goalset_percentage = $staffDetails['goalset_percentage'];
//             $team->goal_completed = 1;
//             $team->save();
//             $inserted_records++;
//           });
//         }
//       }

//     }

//     // ##############################################################################################
//     // ******************************** Cronjob Monitor End ****************************************
//     // ##############################################################################################

//     $end_time = microtime(true);
//     $execution_time = round($end_time - $start_time, 4);
//     $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
//     $duration = gmdate("H:i:s", $execution_time);

//     // Update monitor
//     if ($monitor) {
//       $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
//       $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
//       $monitor->sync_duration        = $duration;
//       $monitor->running_status       = 0;
//       $monitor->save();

//       CronjobLogModel::create([
//         'cronjob_id'           => $monitor->sno,
//         'sync_start_date_time' => $startDateTime->format('Y-m-d H:i:s'),
//         'sync_end_date_time'   => $endDateTime->format('Y-m-d H:i:s'),
//         'sync_duration'        => $duration,
//         'response'             => json_encode([
//           'processed_records' => $inserted_records,
//           'execution_time'    => $duration,
//         ]),
//         'created_by' => 0,
//         'updated_by' => 0,
//       ]);
//     }

//     return [
//       'processed_records' => $inserted_records,
//       'execution_time' => $execution_time . ' seconds'
//     ];
//   }

  public function Cronjob_team_goal_set_update(Request $request)
  {
    $month = (int)($request->month_ids ?? date('m'));
    $year  = (int)($request->year_ids ?? date('Y'));
    $today_day = (int)($request->date_ids ?? date('d'));
    $recalculate = (int)($request->recalculate ?? 0);
    $inserted_records = 0;

    // ##############################################################################################
    // ******************************** Cronjob Monitor Start ***************************************
    // ##############################################################################################
    // Run Which We need month Year date Link
    // http://192.168.3.94:8090/Cronjob_team_goal_set_update?month_ids=12&date_ids=31&year_ids=2025&recalculate=1
    // https://erp.elysiumtechnologies.com/Cronjob_team_goal_set_update


    $monitor = CronjobMonitorModel::where('sno', 12)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor && $monitor->status != 0) {
      return response()->json([
        'success' => false,
        'message' => 'Cronjob status Off'
      ]);
    }

    if ($monitor) {
      $monitor->running_status = 1;
      $monitor->save();
    }

    $goalsetteams = GoalSetTeamModel::where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->where('goal_completed', $recalculate)
      ->orderBy('sno', 'DESC')
      ->get();

    foreach ($goalsetteams as $team) {

      $branch = DB::table('et_branch')
        ->select('sno', 'bus_closing_day_count', 'bus_closing_month_end')
        ->where('sno', $team->branch_id)
        ->first();

      $close_day = $branch->bus_closing_month_end == 1 ? (int)date('t') : ($branch->bus_closing_day_count ?? 25);

      // Skip if today is not goal close day
      if ($today_day != $close_day) continue;

      $staffs = StaffModel::where('branch_id', $team->branch_id)
        ->where('department_id', $team->department_id)
        ->where('status', 0)
        ->select('sno', 'basic_salary')
        ->get();

      $staff_ids = $staffs->pluck('sno')->toArray();
      $branch_id = $team->branch_id;

      // Initialize local totals for this team
      $totals = [
        'all_lead' => 0,
        'month_lead' => 0,
        'hot_lead' => 0,
        'spam_lead' => 0,
        'dead_lead' => 0,
        'convert_customer' => 0,
        'total_payment' => 0,
        'base_paid' => 0,
        'followup' => 0,
        'walkin' => 0,
        'call_out' => 0,
      ];

      // ##############################################################################################
      // ******************************** PRE Sale Department ****************************************
      // ##############################################################################################
      $totalDepartmentConvertCustomer = 0;
      $totalDepartmentTotalPayment = 0;
      $totalDepartmentPaidPayment = 0;
      if ($team->department_id == 1) {
        // Leads metrics
        $totals['all_lead'] = DB::table('et_lead')
          ->whereIn('created_by', $staff_ids)
          ->where('branch_id', $branch_id)
          ->whereNotIn('status', [2, 6])
          ->where('spam_verified', 0)
          ->where('drop_verified', 0)
          ->where('internal_status', 0)
          ->count();

        $totals['month_lead'] = DB::table('et_lead')
          ->whereIn('created_by', $staff_ids)
          ->where('branch_id', $branch_id)
          ->whereYear('registered_date', $year)
          ->whereMonth('registered_date', $month)
          ->whereNotIn('status', [2, 6])
          ->where('spam_verified', 0)
          ->where('drop_verified', 0)
          ->where('internal_status', 0)
          ->count();

        $totals['hot_lead'] = DB::table('et_lead')
          ->whereIn('created_by', $staff_ids)
          ->where('branch_id', $branch_id)
          ->whereYear('registered_date', $year)
          ->whereMonth('registered_date', $month)
          ->whereNotIn('status', [2, 6])
          ->where('lead_status_id', 3)
          ->where('internal_status', 0)
          ->where('spam_verified', 0)
          ->where('drop_verified', 0)
          ->count();

        $totals['spam_lead'] = DB::table('et_lead')
          ->whereIn('created_by', $staff_ids)
          ->where('branch_id', $branch_id)
          ->whereYear('registered_date', $year)
          ->whereMonth('registered_date', $month)
          ->where('spam_verified', 1)
          ->where('status', 7)
          ->count();

        $totals['dead_lead'] = DB::table('et_lead')
          ->whereIn('created_by', $staff_ids)
          ->where('branch_id', $branch_id)
          ->whereYear('registered_date', $year)
          ->whereMonth('registered_date', $month)
          ->where('drop_verified', 1)
          ->where('status', 5)
          ->count();

        // Follow-ups & Walk-ins
        $totals['followup'] = DB::table('et_appointment')
          ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
          ->whereIn('et_lead.status', [0, 4])
          ->whereIn('et_appointment.created_by', $staff_ids)
          ->whereYear('et_appointment.appointment_date', $year)
          ->whereMonth('et_appointment.appointment_date', $month)
          ->count();

        $totals['walkin'] = DB::table('et_lead_appointment')
          ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
          ->where('et_lead_appointment.appointment_category', 3)
          ->whereIn('et_lead_appointment.created_by', $staff_ids) // Fixed table reference
          ->whereYear('et_lead_appointment.appointment_date', $year)
          ->whereMonth('et_lead_appointment.appointment_date', $month)
          ->count();

        // Call outs
        $totals['call_out'] = DB::table('et_call_tracker')
          ->whereYear('call_start_date', $year)
          ->whereMonth('call_start_date', $month)
          ->where('branch_id', $branch_id)
          ->whereIn('branch_staff_id', $staff_ids)
          ->where('call_status', 0)
          ->count();



        foreach ($staff_ids as $sid) {

          // Customer conversions with payments
          $currentMonthCustomers = DB::table('et_customer as c')
            ->select('c.sno', 'c.proposal_ids')
            ->join('et_lead as l', 'l.sno', '=', 'c.lead_id')
            ->join('et_payment as p', function ($join) {
              $join->on('p.customer_id', '=', 'c.sno')
                ->whereRaw('p.transaction_date = (SELECT MIN(ep.transaction_date) FROM et_payment ep WHERE ep.customer_id = c.sno)');
            })
            ->join('et_transaction as t', 't.payment_id', '=', 'p.sno')
            ->where('c.branch_id', $branch_id)
            ->where('l.created_by', $sid)
            ->whereYear('p.transaction_date', $year)
            ->whereMonth('p.transaction_date', $month)
            ->where('t.payment_status', 1)
            ->where('c.status', 0)
            ->get();

          $totalDepartmentConvertCustomer += $currentMonthCustomers->count();

          $customerConvertCount = $currentMonthCustomers->count();

          // Calculate payments and base amounts
          $gst_percent = 18;
          $total_payment = 0;
          $base_amount_paid = 0;

          $gst_percent = 18;
          $total_payment             = 0;
          $total_paid_payment        = 0;
          $base_amount_paid = 0; // keep track of GST-excluded total
          if ($customerConvertCount > 0) {
            if ($currentMonthCustomers->isNotEmpty()) {
              foreach ($currentMonthCustomers as $customer) {
                $proposal_ids = DB::table('et_proposal')
                  ->where('et_proposal.customer_id', $customer->sno)
                  ->where('et_proposal.status', 0)
                  ->whereNot('et_proposal.post_sale_check', 1)
                  ->whereNotIn('et_proposal.proposal_status', [0, 2])
                  ->pluck('sno')
                  ->toArray();
                // return $proposal_ids;

                $proposals = DB::table('et_proposal')
                  ->select('et_proposal.*', 'et_country_currencies.currency_code')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                  ->whereIn('et_proposal.sno', $proposal_ids)
                  ->get();

                foreach ($proposals as $proposal) {
                  // Paid slots for this proposal
                  $paidAmount = DB::table('et_proposal_pay_slot')
                    ->where('proposal_sno', $proposal->sno)
                    ->where('status', 0)
                    ->sum('paidAmount');

                  $grantAmount = $proposal->grant_total_amount;

                  // First remove GST from paidAmount (base value in proposal's currency)
                  $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

                  if ($proposal->currency_id == 70) {
                    // INR: add directly
                    $total_paid_payment += $paidAmount;
                    $total_payment += $grantAmount;
                    $base_amount_paid += $basePaidLocal;
                  } else {
                    // Non-INR: convert both amounts and base value
                    $helper = new \App\Helpers\Helpers();
                    $currency_code = $proposal->currency_code;
                    $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                    $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                    $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                  }
                }
              }
            }
            // average 
            $totalDepartmentTotalPayment += $total_payment;
            $totalDepartmentPaidPayment += $base_amount_paid;
          }
        }

        $totals['convert_customer']  = $totalDepartmentConvertCustomer;
        //  return $totalDepartmentTotalPayment;

        // Calculate derived metrics
        $total_staff = count($staff_ids);
        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month)
          ? $currentDate
          : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;

        // Averages
        $avg_call_out = $dayCount > 0 && $total_staff > 0
          ? round($totals['call_out'] / ($total_staff * $dayCount), 2)
          : 0;
        $avg_walkin = $dayCount > 0 && $total_staff > 0
          ? round($totals['walkin'] / ($total_staff * $dayCount), 2)
          : 0;
        $avg_followup = $dayCount > 0 && $total_staff > 0
          ? round($totals['followup'] / ($total_staff * $dayCount), 2)
          : 0;

        // Business and Collection values
        $business_value = $totals['convert_customer'] > 0
          ? round($totalDepartmentTotalPayment / $totals['convert_customer'], 2)
          : 0;

        $collection_value = $totals['convert_customer'] > 0
          ? round($totalDepartmentPaidPayment / $totals['convert_customer'], 2)
          : 0;

        // Conversion rate
        $conversion_rate = $totals['month_lead'] > 0
          ? round(($totals['convert_customer'] / $totals['month_lead']) * 100, 2)
          : 0;

        // Update team goals in transaction
        DB::transaction(function () use ($team, $totals, $conversion_rate, $business_value, $collection_value, $avg_call_out, $avg_followup, $avg_walkin, &$inserted_records) {
          $team->conversion_actual = $totals['convert_customer'];
          $team->cr_actual = $conversion_rate;
          $team->abv_actual = $business_value;
          $team->acv_actual = $collection_value;
          $team->avg_call_out_actual = $avg_call_out;
          $team->no_of_walk_actual = $avg_walkin;
          $team->no_of_followup_actual = $avg_followup;
          $team->goal_completed = 1;
          $team->save();
          $inserted_records++;
        });
      }
      // ##############################################################################################
      // ******************************** Post Sale Department ****************************************
      // ##############################################################################################

      if ($team->department_id == 15) {
        // return 'Post Sale Department';          
        $total_staff = $staffs->count();
        $salesStaff = $staffs;
        $totalAllLead             = 0;
        $totalMonthLead            = 0;
        $totalHotLead        = 0;
        $totalSpamLead      = 0;
        $totalDeadLead    = 0;
        $totalAllPayment             = 0;
        $totalAllPaidPayment        = 0;
        $helper = new \App\Helpers\Helpers();
        foreach ($salesStaff as $staff) {
          $allpostSaleData = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_proposal.post_sale_date')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->whereNotIn('et_proposal.proposal_status', [0, 2])
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal.created_by', $staff->sno)
            ->orderBy('et_proposal.created_at', 'asc') // Order by creation date, ascending
            ->get();
          $allLeadCount = count($allpostSaleData);
          $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.branch_id', $branch_id)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();
          $hotLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.branch_id', $branch_id)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.lead_status_id', 3)
            ->where('et_lead.internal_status', 0)
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->count();
          $customerConvertData = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_customer.cus_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->join('et_payment', function ($join) {
              $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.proposal_id = et_proposal.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal.created_by', $staff->sno)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();
          $customerConvertCount = count($customerConvertData);
          $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.status', 7)->count();
          $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $staff->sno)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.status', 5)->count();
          // Spam Ratio 
          $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
          $spam_lead_ratio = number_format($spam_lead_ratio > 100 ? 100 : $spam_lead_ratio, 2);

          // Dead ratio
          $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
          $dead_lead_ratio      = number_format($dead_lead_ratio > 100 ? 100 : $dead_lead_ratio, 2);

          // customer ratio
          $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
          $convertion_rate = number_format($convertion_rate, 2);

          //acr
          $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
          $averager_convertion_rate =  number_format($averager_convertion_rate > 100 ? 100 : $averager_convertion_rate, 2);
          $total_payment             = 0;
          $total_paid_payment        = 0;

          $base_amount_paid = 0; // keep track of GST-excluded total

          $gst_percent = 18;


          if ($customerConvertCount > 0) {
            $currentMonthCustomer = $customerConvertData;
            if ($currentMonthCustomer->isNotEmpty()) {
              foreach ($currentMonthCustomer as $customer) {
                $proposal_ids = DB::table('et_proposal')
                  ->where('et_proposal.customer_id', $customer->sno)
                  ->where('et_proposal.status', 0)
                  ->where('et_proposal.post_sale_check', 1)
                  ->whereYear('et_proposal.estimate_date', $year)
                  ->whereMonth('et_proposal.estimate_date', $month)
                  ->whereNotIn('et_proposal.proposal_status', [0, 2])
                  ->pluck('sno')
                  ->toArray();

                $proposals = DB::table('et_proposal')
                  ->select('et_proposal.*', 'et_country_currencies.currency_code')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                  ->whereIn('et_proposal.sno', $proposal_ids)
                  ->get();

                foreach ($proposals as $proposal) {
                  // Paid slots for this proposal
                  $paidAmount = DB::table('et_proposal_pay_slot')
                    ->where('proposal_sno', $proposal->sno)
                    ->where('status', 0)
                    ->sum('paidAmount');

                  $grantAmount = $proposal->grant_total_amount;

                  // First remove GST from paidAmount (base value in proposal's currency)
                  $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

                  if ($proposal->currency_id == 70) {
                    // INR: add directly
                    $total_paid_payment += $paidAmount;
                    $total_payment += $grantAmount;
                    $base_amount_paid += $basePaidLocal;
                  } else {
                    // Non-INR: convert both amounts and base value
                    $currency_code = $proposal->currency_code;
                    $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                    $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                    $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                  }
                }
              }
            }

            $totalAllPayment += $total_payment;
            $totalAllPaidPayment += $base_amount_paid;
          }

          // total cal
          $totalAllLead             += $allLeadCount;
          $totalMonthLead            += $monthLeadCount;
          $totalHotLead        += $hotLeadCount;
          $totalDepartmentConvertCustomer            += $customerConvertCount;
          $totalSpamLead      += $spamLeadCount;
          $totalDeadLead    += $deadLeadCount;
        }

        $totalDepartmentBusinessValue   = $totalDepartmentConvertCustomer > 0 ? $totalAllPayment / $totalDepartmentConvertCustomer : 0;
        $totalDepartmentCollectionValue = $totalDepartmentConvertCustomer > 0 ? $totalAllPaidPayment / $totalDepartmentConvertCustomer : 0;
        // Conversion Rate
        $convertion_rate = $totalMonthLead > 0 ? ($totalDepartmentConvertCustomer / $totalMonthLead) * 100 : 0;
        $totalConvertRatio = number_format($convertion_rate, 2);
        // Prepare goal details response

        // Update team goals in transaction
        DB::transaction(function () use ($team, $totalDepartmentConvertCustomer, $totalConvertRatio, $totalDepartmentBusinessValue, $totalDepartmentCollectionValue, &$inserted_records) {
          $team->conversion_actual = $totalDepartmentConvertCustomer;
          $team->cr_actual = $totalConvertRatio;
          $team->abv_actual = $totalDepartmentBusinessValue;
          $team->acv_actual = $totalDepartmentCollectionValue;
          $team->goal_completed = 1;
          $team->save();
          $inserted_records++;
        });
      }
      // ##############################################################################################
      // ******************************** Production Department Department ****************************
      // ##############################################################################################
      if ($team->department_id == 2) {
        $working_hoursActual = 0;
        $rework_countActual = 0;
        $salesStaff = $staffs;
        $helper = new \App\Helpers\Helpers();
        foreach ($salesStaff as $member) {
          $working_hour = DB::table('et_task_log')
            ->where('et_task_log.branch_id', $branch_id)
            ->whereYear('et_task_log.end_time', $year)
            ->whereMonth('et_task_log.end_time', $month)
            ->where('et_task_log.status', 1)
            ->where('et_task_log.staff_id', $member->sno)
            ->sum(DB::raw('TIME_TO_SEC(duration)'));

          $working_hoursActual += $working_hour / 3600;

          $rework_count = DB::table('et_daily_tasks')
            ->whereYear('et_daily_tasks.task_date', $year)
            ->whereMonth('et_daily_tasks.task_date', $month)
            ->where('et_daily_tasks.rework_check', 1)
            ->where('et_daily_tasks.staff_id', $member->sno)
            ->count();

          $rework_countActual += $rework_count;
        }

        // Update team goals in transaction
        DB::transaction(function () use ($team, $rework_countActual, $working_hoursActual, &$inserted_records) {
          $team->working_hours_actual = $working_hoursActual;
          $team->rework_actual = $rework_countActual;
          $team->goal_completed = 1;
          $team->save();
          $inserted_records++;
        });
      }

      // ##############################################################################################
      // ******************************** Journal Department Department ****************************
      // ##############################################################################################
      if ($team->department_id == 14) {
        $working_hoursActual = 0;
        $rework_countActual = 0;
        $salesStaff = $staffs;
        $helper = new \App\Helpers\Helpers();
        $no_of_papers_countActual = 0;
        foreach ($salesStaff as $member) {
          if (in_array($member->role_id, [33, 36])) {
            $field = $member->role_id == 33 ? 'jc_id' : 'jc_staff';
            $no_of_papers_countActual += DB::table('et_journal_history')
              ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
              ->where('et_customer_services.jc_staff', $member->sno)
              ->whereMonth('et_journal_history.created_at', $month)
              ->whereYear('et_journal_history.created_at', $year)
              ->where('et_journal_history.status', 8)
              ->whereMonth('et_journal_history.published_date', $month)
              ->count();
          }
        }

        // Update team goals in transaction
        DB::transaction(function () use ($team, $no_of_papers_countActual, &$inserted_records) {
          $team->no_of_papers_countActual = $no_of_papers_countActual;
          $team->goal_completed = 1;
          $team->save();
          $inserted_records++;
        });
      }

      // ##############################################################################################
      // ******************************** CRE Department Department ****************************
      // ##############################################################################################
      if ($team->department_id == 14) {
        $working_hoursActual = 0;
        $rework_countActual = 0;
        $salesStaff = $staffs;
        $branchId = $team->branch_id;
        $branch = BranchModel::where('sno', $branchId)
          ->where('status', 0)
          ->latest('sno')
          ->first();

        $gstPercent = $branch ? $branch->gst_percentage : 18;

        /* FINAL TOTALS */
        $collectionHarvestingAmount = 0; // Scheduled
        $collectedHarvestingAmount  = 0; // Paid
        $totalOutstandingAmount     = 0;

        $firstIds = DB::table('et_proposal_pay_slot')
          ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
          ->where('et_proposal.status', 0)
          ->where('et_proposal_pay_slot.status', 0)
          ->whereNotIn('et_proposal.proposal_status', [0, 2])
          ->selectRaw('MIN(et_proposal_pay_slot.sno) as first_id')
          ->groupBy('et_proposal_pay_slot.proposal_sno')
          ->pluck('first_id');

        foreach ($salesStaff as $member) {

          $userId = $member->sno;

          $paidInr = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_proposal.cre_id', $userId)
            ->where('et_proposal.currency_id', 70)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
            ->sum('et_proposal_pay_slot.paidAmount');

          $paidInr = round($paidInr / (1 + ($gstPercent / 100)), 2);

          $paidNonInrRows = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_proposal.cre_id', $userId)
            ->where('et_proposal.currency_id', '!=', 70)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
            ->get();

          $paidNonInr = 0;
          foreach ($paidNonInrRows as $row) {
            $paidNonInr += $helper->ConvertedAmountInr($row->currency_code, $row->paidAmount);
          }

          $paidNonInr = round($paidNonInr / (1 + ($gstPercent / 100)), 2);

          $totalPaid = $paidInr + $paidNonInr;

          $notPaidInr = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_proposal.cre_id', $userId)
            ->where('et_proposal.currency_id', 70)
            ->where('et_proposal_pay_slot.paid_status', 0)
            ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
            ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
            ->sum('et_proposal_pay_slot.payable_amount');

          $notPaidInr = round($notPaidInr / (1 + ($gstPercent / 100)), 2);

          $notPaidNonInrRows = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_proposal.cre_id', $userId)
            ->where('et_proposal.currency_id', '!=', 70)
            ->where('et_proposal_pay_slot.paid_status', 0)
            ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
            ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
            ->get();

          $notPaidNonInr = 0;
          foreach ($notPaidNonInrRows as $row) {
            $notPaidNonInr += $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);
          }

          $notPaidNonInr = round($notPaidNonInr / (1 + ($gstPercent / 100)), 2);

          $scheduled   = $totalPaid + $notPaidInr + $notPaidNonInr;
          $outstanding = $scheduled - $totalPaid;

          $collectionHarvestingAmount += $scheduled;
          $collectedHarvestingAmount  += $totalPaid;
          $totalOutstandingAmount     += $outstanding;
        }

        $HarvestingPercentage = round(
          $collectionHarvestingAmount > 0
            ? ($collectedHarvestingAmount / $collectionHarvestingAmount) * 100
            : 0,
          1
        );

        $outstandingPercentage = round(
          $collectionHarvestingAmount > 0
            ? ($totalOutstandingAmount / $collectionHarvestingAmount) * 100
            : 0,
          1
        );

        // Update team goals in transaction
        DB::transaction(function () use ($team, $HarvestingPercentage, &$inserted_records) {
          $team->harvesting_percentage_actual = $HarvestingPercentage;
          $team->goal_completed = 1;
          $team->save();
          $inserted_records++;
        });
      }
    }


    // ##############################################################################################
    // ******************************** Cronjob Monitor End ****************************************
    // ##############################################################################################

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    $duration = gmdate("H:i:s", $execution_time);

    // Update monitor
    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      CronjobLogModel::create([
        'cronjob_id'           => $monitor->sno,
        'sync_start_date_time' => $startDateTime->format('Y-m-d H:i:s'),
        'sync_end_date_time'   => $endDateTime->format('Y-m-d H:i:s'),
        'sync_duration'        => $duration,
        'response'             => json_encode([
          'processed_records' => $inserted_records,
          'execution_time'    => $duration,
        ]),
        'created_by' => 0,
        'updated_by' => 0,
      ]);
    }

    return [
      'processed_records' => $inserted_records,
      'execution_time' => $execution_time . ' seconds'
    ];
  }

  public function Cronjob_staff_goal_set_update(Request $request)
  {
    $month = (int)($request->month_ids ?? date('m'));
    $year  = (int)($request->year_ids ?? date('Y'));
    $today_day = (int)($request->date_ids ?? date('d'));
    $recalculate = (int)($request->recalculate ?? 0);

    $helper = new \App\Helpers\Helpers();


    // ##############################################################################################
    // ******************************** Cronjob Monitor End ****************************************
    // ##############################################################################################
    // Run Which We need month Year date Link
    // http://192.168.3.94:8090/Cronjob_staff_goal_set_update?month_ids=11&date_ids=31&year_ids=2025?&recalculate=0
    // https://erp.elysiumtechnologies.com/Cronjob_staff_goal_set_update


    $monitor = CronjobMonitorModel::where('sno', 11)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor && $monitor->status != 0) {
      return response()->json([
        'success' => false,
        'message' => 'Cronjob status Off'
      ]);
    }

    if ($monitor) {
      $monitor->running_status = 1;
      $monitor->save();
    }

    $goalsetteam = GoalSetTeamModel::where('et_goal_set_team.team_goal_month', $month)
      ->where('et_goal_set_team.team_goal_year', $year)
      ->first();
    // Get goal records for the selected department and month
    $goalsetRecords = GoalSetStaffModel::whereMonth('et_goal_set_staff.goal_date', $month)
      ->whereYear('et_goal_set_staff.goal_date', $year)
      ->where('et_goal_set_staff.goal_completed', $recalculate)
      ->get();
    $inserted_records = 0;
    foreach ($goalsetRecords as $team) {

      $branch = DB::table('et_branch')
        ->select('sno', 'bus_closing_day_count', 'bus_closing_month_end')
        ->where('sno', $team->branch_id)
        ->first();

      $close_day = $branch->bus_closing_month_end == 1 ? (int)date('t') : ($branch->bus_closing_day_count ?? 25);

      // Skip if today is not goal close day
      if ($today_day != $close_day) continue;

      $staffs = StaffModel::where('branch_id', $team->branch_id)
        ->where('department_id', $team->department_id)
        ->where('status', 0)
        ->where('sno', $team->staff_id)
        ->select('sno', 'basic_salary')
        ->get();

      $staff_ids = $staffs->pluck('sno')->toArray();
      $branch_id = $team->branch_id;
      // ##############################################################################################
      // ******************************** PRE Sale Department ****************************************
      // ##############################################################################################
      $totalAllPayment = 0;
      $totalAllPaidPayment = 0;
      if ($team->department_id == 1) {
        // Attach goal details to staff members
        $staffDetails = [];
        $values = [];
        foreach ($staffs as $member) {

          $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $member->sno)
            ->where('et_lead.branch_id', $branch_id)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

          $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $member->sno)
            ->where('et_lead.branch_id', $branch_id)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

          $customerConvertCount =  DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
              $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                ->whereRaw('et_payment.transaction_date = (
                     SELECT MIN(ep.transaction_date)
                     FROM et_payment ep
                     WHERE ep.customer_id = et_customer.sno
                 )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            // ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', $member->sno)
            ->whereYear('et_payment.transaction_date', $year)
            //  ->whereDay('et_payment.transaction_date', $day) // Use `whereDay` instead of `whereDate`
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            // ->orderBy('et_customer.sno', 'asc')
            ->count();

          $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $member->sno)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.status', 7)->count();

          $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $member->sno)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.status', 5)->count();

          $monthFollowupCount = DB::table('et_appointment')
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->whereIn('et_lead.status', [0, 4])
            ->where('et_appointment.created_by', $member->sno)
            ->whereYear('et_appointment.appointment_date', $year)
            ->whereMonth('et_appointment.appointment_date', $month)
            ->count();
          $monthwalkincount = DB::table('et_lead_appointment')
            ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_lead_appointment.appointment_category', 3) // Fixed the table reference
            ->where('et_lead_appointment.created_by', $member->sno)
            ->whereYear('et_lead_appointment.appointment_date', $year)
            ->whereMonth('et_lead_appointment.appointment_date', $month)
            ->count();

          $monthcall_out = DB::table('et_call_tracker')
            ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->where('et_call_tracker.branch_id', $branch_id)
            ->where('et_call_tracker.branch_staff_id', $member->sno)
            ->first();
          $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;

          $startDate = Carbon::create($year, $month, 1);
          $currentDate = Carbon::now();
          $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
          $dayCounts3 = $startDate->diffInDays($endDate) + 1;

          $monthcall_out = $dayCounts3 > 0  ? round($monthcall_out / ($dayCounts3)) : 0;
          $monthFollowupCount = $dayCounts3 > 0  ? round($monthFollowupCount / ($dayCounts3)) : 0;
          // Spam Ratio 
          $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
          $spam_lead_ratio = number_format($spam_lead_ratio, 2);
          // Dead ratio
          $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
          $dead_lead_ratio      = number_format($dead_lead_ratio, 2);
          // customer ratio
          $convertion_rates = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
          $convertion_rate = number_format($convertion_rates, 2);
          //acr
          $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
          $averager_convertion_rate = number_format($averager_convertion_rate, 2);
          $total_payment             = 0;
          $total_paid_payment        = 0;
          $averageBusinessValue      = 0;
          $averageCollectionValue    = 0;


          $base_amount_paid = 0; // keep track of GST-excluded total
          $gst_percent = 18;

          if ($customerConvertCount > 0) {
            $currentMonthCustomer = DB::table('et_customer')
              ->select('et_customer.sno', 'et_customer.proposal_ids')
              ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
              ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                  ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.customer_id = et_customer.sno
                     )');
              })
              ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
              ->where('et_customer.status', 0)
              ->where('et_customer.branch_id', $branch_id)
              ->where('et_lead.created_by', $member->sno)
              ->whereYear('et_payment.transaction_date', $year)
              ->whereMonth('et_payment.transaction_date', $month)
              ->where('et_transaction.payment_status', 1)
              ->orderBy('et_customer.sno', 'asc')
              ->get();
            $customerConvertCount = count($currentMonthCustomer);
            // average 
            $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
            $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';
            $totalAllPayment += $total_payment;
            $totalAllPaidPayment += $total_paid_payment;
          }
          if ($customerConvertCount > 0) {
            if ($currentMonthCustomer->isNotEmpty()) {
              foreach ($currentMonthCustomer as $customer) {
                $proposal_ids = DB::table('et_proposal')
                  ->where('et_proposal.customer_id', $customer->sno)
                  ->where('et_proposal.status', 0)
                  ->whereNot('et_proposal.post_sale_check', 1)
                  ->whereNotIn('et_proposal.proposal_status', [0, 2])
                  ->pluck('sno')
                  ->toArray();
                // return $proposal_ids;

                $proposals = DB::table('et_proposal')
                  ->select('et_proposal.*', 'et_country_currencies.currency_code')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                  ->whereIn('et_proposal.sno', $proposal_ids)
                  ->get();

                foreach ($proposals as $proposal) {
                  // Paid slots for this proposal
                  $paidAmount = DB::table('et_proposal_pay_slot')
                    ->where('proposal_sno', $proposal->sno)
                    ->where('status', 0)
                    ->sum('paidAmount');

                  $grantAmount = $proposal->grant_total_amount;

                  // First remove GST from paidAmount (base value in proposal's currency)
                  $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

                  if ($proposal->currency_id == 70) {
                    // INR: add directly
                    $total_paid_payment += $paidAmount;
                    $total_payment += $grantAmount;
                    $base_amount_paid += $basePaidLocal;
                  } else {
                    $currency_code = $proposal->currency_code;
                    $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                    $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                    $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                  }
                }
              }
            }
            // average 
            $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
            $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
            $totalAllPayment += $total_payment;
            $totalAllPaidPayment += $base_amount_paid;
          }

          $staffDetails2 = [
            'conversion'                => $team->conversion ?? 0,
            'conversion_actual'         => $customerConvertCount ?? 0,
            'cr'                        => $team->CR ?? 0,
            'cr_actual'                 => $convertion_rate ?? 0,
            'abv'                       => isset($team->ABV) ? $team->ABV : 0,
            'abv_actual'                => $averageBusinessValue ?? 0,
            'acv'                       => isset($team->ACV) ? $team->ACV : 0,
            'acv_actual'                => $averageCollectionValue ?? 0,
            'avg_call_out'              => $team->avg_call_out ?? 0,
            'avg_call_out_actual'       => $monthcall_out ?? 0,
            'no_of_walk'                => $team->no_of_walk ?? 0,
            'no_of_walk_actual'         => $monthwalkincount ?? 0,
            'no_of_followup'            => $team->no_of_followup ?? 0,
            'no_of_followup_actual'     => $monthFollowupCount ?? 0,
          ];
          $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
          $goal_achievements = true;  // true = all 10X goals achieved
          $staffAchieved = true;      // true = individual staff goals achieved
          $allOverZero = true;        // true = all goals have zero target
          $total_goal = 0;
          $tot_actual_value = 0;
          $actual_values = 0;
          $values = [];

          if (!empty($ten_x) && is_array($ten_x)) {
            foreach ($ten_x as $key => $value) {
              if ($value === "1") {
                $type2 = str_replace("_10x", "", $key);
                $goal_value = (float)($staffDetails2[$type2] ?? 0);
                $actual_value = (float)($staffDetails2[$type2 . '_actual'] ?? 0);

                // Track if any goal has non-zero target
                if ($goal_value > 0) {
                  $allOverZero = false;
                }

                // Check individual goal achievement
                if ($goal_value > 0 && $actual_value < $goal_value) {
                  $goal_achievements = false;
                  $staffAchieved = false;
                }

                // Special case: No progress on valid goal
                if ($goal_value > 0 && $actual_value === 0) {
                  $staffAchieved = false;
                }

                // Special case for rework (lower is better)
                if ($type2 === 'rework') {
                  if ($goal_value > 0 && $actual_value > $goal_value) {
                    $staffAchieved = false;
                  }
                }

                if ($key == 'rework') {
                  if ($actual_value >= $goal_value) {
                    $actual_values = $goal_value;
                  }
                  $total_goal  += $goal_value;
                  $tot_actual_value  += $actual_values;
                } else {
                  if ($actual_value <= $goal_value) {
                    $total_goal  += $goal_value;
                    $tot_actual_value  += $goal_value;
                  } else {
                    $total_goal  += $goal_value;
                    $tot_actual_value  += $actual_value;
                  }
                }

                $values[] = [
                  'type' => $type2,
                  'goal' => $goal_value,
                  'actual' => $actual_value,
                  'achieved' => ($goal_value === 0 || $actual_value >= $goal_value)
                ];
              }
            }
          }

          // Final status determination (0=Not Assigned, 1=Achieved, 2=In Progress)
          $goalsts = 0;

          if ($goal_achievements && !$allOverZero) {
            $goalsts = 1;  // All 10X goals achieved
          } elseif (!$allOverZero) {
            $goalsts = 2;  // In progress (some goals not met)
          } // else: 0 (Not Assigned - all zeros)


          // Determine final status
          // return $values;
          // Calculate achievement percentage (optional)
          $achievement_percentage = $total_goal > 0 ? round(($tot_actual_value / $total_goal) * 100, 2) : 0;

          $staffDetails = [
            'conversion'                => $team->conversion ?? 0,
            'conversion_actual'         => $customerConvertCount ?? 0,
            'cr'                        => $team->CR ?? 0,
            'cr_actual'                 => $convertion_rate ?? 0,
            'abv'                       => isset($team->ABV) ? $team->ABV : 0,
            'abv_actual'                => $averageBusinessValue ?? 0,
            'acv'                       => isset($team->ACV) ? $team->ACV : 0,
            'acv_actual'                => $averageCollectionValue ?? 0,
            'avg_call_out'              => $team->avg_call_out ?? 0,
            'avg_call_out_actual'       => $monthcall_out ?? 0,
            'no_of_walk'                => $team->no_of_walk ?? 0,
            'no_of_walk_actual'         => $monthwalkincount ?? 0,
            'no_of_followup'            => $team->no_of_followup ?? 0,
            'no_of_followup_actual'     => $monthFollowupCount ?? 0,
            'goalset_percentage'        => $achievement_percentage ?? 0,
            '10x_status'                => $goalsts ?? 0,
          ];
          // Update team goals in transaction
          DB::transaction(function () use ($team, $staffDetails, &$inserted_records) {
            $team->conversion_actual = $staffDetails['conversion_actual'];
            $team->cr_actual = $staffDetails['cr_actual'];
            $team->abv_actual = $staffDetails['abv_actual'];
            $team->acv_actual = $staffDetails['acv_actual'];
            $team->avg_call_out_actual = $staffDetails['avg_call_out_actual'];
            $team->no_of_walk_actual = $staffDetails['no_of_walk_actual'];
            $team->no_of_followup_actual = $staffDetails['no_of_followup_actual'];
            $team->no_of_followup_actual = $staffDetails['no_of_followup_actual'];
            $team->status_10x = $staffDetails['10x_status'];
            $team->goalset_percentage = $staffDetails['goalset_percentage'];
            $team->goal_completed = 1;
            $team->save();
            $inserted_records++;
          });
        }
      }
      // ##############################################################################################
      // ******************************** Post Sale Department ****************************************
      // ##############################################################################################
      if ($team->department_id == 15) {
        // return 'Post Sale Department'; 
        $salesStaff = $staffs;
        $totalAllPayment             = 0;
        $totalAllPaidPayment        = 0;
        $helper = new \App\Helpers\Helpers();
        foreach ($salesStaff as $member) {
          $allpostSaleData = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_proposal.post_sale_date')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->whereNotIn('et_proposal.proposal_status', [0, 2])
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal.created_by', $member->sno)
            ->orderBy('et_proposal.created_at', 'asc') // Order by creation date, ascending
            ->get();
          $allLeadCount = count($allpostSaleData);
          $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $member->sno)
            ->where('et_lead.branch_id', $branch_id)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();
          $customerConvertData = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_customer.cus_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->join('et_payment', function ($join) {
              $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.proposal_id = et_proposal.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal.created_by', $member->sno)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();
          $customerConvertCount = count($customerConvertData);
          $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $member->sno)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.status', 7)->count();
          $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $member->sno)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.status', 5)->count();
          // Spam Ratio 
          $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
          $spam_lead_ratio = number_format($spam_lead_ratio > 100 ? 100 : $spam_lead_ratio, 2);

          // Dead ratio
          $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
          $dead_lead_ratio      = number_format($dead_lead_ratio > 100 ? 100 : $dead_lead_ratio, 2);

          // customer ratio
          $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
          $convertion_rate = number_format($convertion_rate, 2);

          //acr
          $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
          $averager_convertion_rate =  number_format($averager_convertion_rate > 100 ? 100 : $averager_convertion_rate, 2);
          $total_payment             = 0;
          $total_paid_payment        = 0;

          $base_amount_paid = 0; // keep track of GST-excluded total

          $gst_percent = 18;


          if ($customerConvertCount > 0) {
            $currentMonthCustomer = $customerConvertData;
            if ($currentMonthCustomer->isNotEmpty()) {
              foreach ($currentMonthCustomer as $customer) {
                $proposal_ids = DB::table('et_proposal')
                  ->where('et_proposal.customer_id', $customer->sno)
                  ->where('et_proposal.status', 0)
                  ->where('et_proposal.post_sale_check', 1)
                  ->whereYear('et_proposal.estimate_date', $year)
                  ->whereMonth('et_proposal.estimate_date', $month)
                  ->whereNotIn('et_proposal.proposal_status', [0, 2])
                  ->pluck('sno')
                  ->toArray();

                $proposals = DB::table('et_proposal')
                  ->select('et_proposal.*', 'et_country_currencies.currency_code')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                  ->whereIn('et_proposal.sno', $proposal_ids)
                  ->get();

                foreach ($proposals as $proposal) {
                  // Paid slots for this proposal
                  $paidAmount = DB::table('et_proposal_pay_slot')
                    ->where('proposal_sno', $proposal->sno)
                    ->where('status', 0)
                    ->sum('paidAmount');

                  $grantAmount = $proposal->grant_total_amount;

                  // First remove GST from paidAmount (base value in proposal's currency)
                  $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

                  if ($proposal->currency_id == 70) {
                    // INR: add directly
                    $total_paid_payment += $paidAmount;
                    $total_payment += $grantAmount;
                    $base_amount_paid += $basePaidLocal;
                  } else {
                    // Non-INR: convert both amounts and base value
                    $currency_code = $proposal->currency_code;
                    $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                    $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                    $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                  }
                }
              }
            }

            $totalAllPayment += $total_payment;
            $totalAllPaidPayment += $base_amount_paid;
          }

          $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
          $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;


          $startDate = Carbon::create($year, $month, 1);
          $currentDate = Carbon::now();
          $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
          $dayCount = $startDate->diffInDays($endDate) + 1;


          $staffDetails2 = [
            'conversion'                => $team->conversion ?? 0,
            'conversion_actual'         => $customerConvertCount ?? 0,
            'cr'                        => $team->CR ?? 0,
            'cr_actual'                 => $convertion_rate ?? 0,
            'abv'                       => isset($team->ABV) ? $team->ABV : 0,
            'abv_actual'                => $averageBusinessValue ?? 0,
            'acv'                       => isset($team->ACV) ? $team->ACV : 0,
            'acv_actual'                => $averageCollectionValue ?? 0,
          ];

          $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
          $goal_achievements = true;  // true = all 10X goals achieved
          $staffAchieved = true;      // true = individual staff goals achieved
          $allOverZero = true;        // true = all goals have zero target
          $total_goal = 0;
          $tot_actual_value = 0;
          $actual_values = 0;
          $values = [];

          if (!empty($ten_x) && is_array($ten_x)) {
            foreach ($ten_x as $key => $value) {
              if ($value === "1") {
                $type2 = str_replace("_10x", "", $key);
                $goal_value = (float)($staffDetails2[$type2] ?? 0);
                $actual_value = (float)($staffDetails2[$type2 . '_actual'] ?? 0);

                // Track if any goal has non-zero target
                if ($goal_value > 0) {
                  $allOverZero = false;
                }

                // Check individual goal achievement
                if ($goal_value > 0 && $actual_value < $goal_value) {
                  $goal_achievements = false;
                  $staffAchieved = false;
                }

                // Special case: No progress on valid goal
                if ($goal_value > 0 && $actual_value === 0) {
                  $staffAchieved = false;
                }

                // Special case for rework (lower is better)
                if ($type2 === 'rework') {
                  if ($goal_value > 0 && $actual_value > $goal_value) {
                    $staffAchieved = false;
                  }
                }

                if ($key == 'rework') {
                  if ($actual_value >= $goal_value) {
                    $actual_values = $goal_value;
                  }
                  $total_goal  += $goal_value;
                  $tot_actual_value  += $actual_values;
                } else {
                  if ($actual_value <= $goal_value) {
                    $total_goal  += $goal_value;
                    $tot_actual_value  += $goal_value;
                  } else {
                    $total_goal  += $goal_value;
                    $tot_actual_value  += $actual_value;
                  }
                }

                $values[] = [
                  'type' => $type2,
                  'goal' => $goal_value,
                  'actual' => $actual_value,
                  'achieved' => ($goal_value === 0 || $actual_value >= $goal_value)
                ];
              }
            }
          }

          // Final status determination (0=Not Assigned, 1=Achieved, 2=In Progress)
          $goalsts = 0;

          if ($goal_achievements && !$allOverZero) {
            $goalsts = 1;  // All 10X goals achieved
          } elseif (!$allOverZero) {
            $goalsts = 2;  // In progress (some goals not met)
          } // else: 0 (Not Assigned - all zeros)


          // Determine final status
          // return $values;
          // Calculate achievement percentage (optional)
          $achievement_percentage = $total_goal > 0 ? round(($tot_actual_value / $total_goal) * 100, 2) : 0;

          $staffDetails = [
            'conversion'                => $team->conversion ?? 0,
            'conversion_actual'         => $customerConvertCount ?? 0,
            'cr'                        => $team->CR ?? 0,
            'cr_actual'                 => $convertion_rate ?? 0,
            'abv'                       => isset($team->ABV) ? $team->ABV : 0,
            'abv_actual'                => $averageBusinessValue ?? 0,
            'abv_actual'                => $averageBusinessValue ?? 0,
            'acv'                       => isset($team->ACV) ? $team->ACV : 0,
            'acv_actual'                => $averageCollectionValue ?? 0,
            'goalset_percentage'        => $achievement_percentage ?? 0,
            '10x_status'                => $goalsts ?? 0,
          ];

          // Update team goals in transaction
          DB::transaction(function () use ($team, $staffDetails, &$inserted_records) {
            $team->conversion_actual = $staffDetails['conversion_actual'];
            $team->cr_actual = $staffDetails['cr_actual'];
            $team->abv_actual = $staffDetails['abv_actual'];
            $team->acv_actual = $staffDetails['acv_actual'];
            $team->status_10x = $staffDetails['10x_status'];
            $team->goalset_percentage = $staffDetails['goalset_percentage'];
            $team->goal_completed = 1;
            $team->save();
            $inserted_records++;
          });
        }
      }

      // ##############################################################################################
      // ******************************** Production Department Department ****************************
      // ##############################################################################################

      if ($team->department_id == 2) {
        $salesStaff = $staffs;
        $helper = new \App\Helpers\Helpers();
        foreach ($salesStaff as $member) {
          $working_hour = DB::table('et_task_log')
            ->where('et_task_log.branch_id', $branch_id)
            ->whereYear('et_task_log.end_time', $year)
            ->whereMonth('et_task_log.end_time', $month)
            ->where('et_task_log.status', 1)
            ->where('et_task_log.staff_id', $member->sno)
            ->sum(DB::raw('TIME_TO_SEC(duration)'));

          $working_hoursActual = $working_hour / 3600;

          $rework_count = DB::table('et_daily_tasks')
            ->whereYear('et_daily_tasks.task_date', $year)
            ->whereMonth('et_daily_tasks.task_date', $month)
            ->where('et_daily_tasks.rework_check', 1)
            ->where('et_daily_tasks.staff_id', $member->sno)
            ->count();


          $staffDetails2 = [
            'rework'                    => $team->rework ?? 0,
            'rework_actual'             => $rework_count ?? 0,
            'working_hours'             => $team->working_hours ?? 0,
            'working_hours_actual'      => $working_hoursActual ?? 0,
          ];

          $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
          $goal_achievements = true;  // true = all 10X goals achieved
          $staffAchieved = true;      // true = individual staff goals achieved
          $allOverZero = true;        // true = all goals have zero target
          $total_goal = 0;
          $tot_actual_value = 0;
          $actual_values = 0;
          $values = [];

          if (!empty($ten_x) && is_array($ten_x)) {
            foreach ($ten_x as $key => $value) {
              if ($value === "1") {
                $type2 = str_replace("_10x", "", $key);
                $goal_value = (float)($staffDetails2[$type2] ?? 0);
                $actual_value = (float)($staffDetails2[$type2 . '_actual'] ?? 0);

                // Track if any goal has non-zero target
                if ($goal_value > 0) {
                  $allOverZero = false;
                }

                // Check individual goal achievement
                if ($goal_value > 0 && $actual_value < $goal_value) {
                  $goal_achievements = false;
                  $staffAchieved = false;
                }

                // Special case: No progress on valid goal
                if ($goal_value > 0 && $actual_value === 0) {
                  $staffAchieved = false;
                }

                // Special case for rework (lower is better)
                if ($type2 === 'rework') {
                  if ($goal_value > 0 && $actual_value > $goal_value) {
                    $staffAchieved = false;
                  }
                }

                if ($key == 'rework') {
                  if ($actual_value >= $goal_value) {
                    $actual_values = $goal_value;
                  }
                  $total_goal  += $goal_value;
                  $tot_actual_value  += $actual_values;
                } else {
                  if ($actual_value <= $goal_value) {
                    $total_goal  += $goal_value;
                    $tot_actual_value  += $goal_value;
                  } else {
                    $total_goal  += $goal_value;
                    $tot_actual_value  += $actual_value;
                  }
                }

                $values[] = [
                  'type' => $type2,
                  'goal' => $goal_value,
                  'actual' => $actual_value,
                  'achieved' => ($goal_value === 0 || $actual_value >= $goal_value)
                ];
              }
            }
          }

          // Final status determination (0=Not Assigned, 1=Achieved, 2=In Progress)
          $goalsts = 0;

          if ($goal_achievements && !$allOverZero) {
            $goalsts = 1;  // All 10X goals achieved
          } elseif (!$allOverZero) {
            $goalsts = 2;  // In progress (some goals not met)
          } // else: 0 (Not Assigned - all zeros)


          // Determine final status
          // return $values;
          // Calculate achievement percentage (optional)
          $achievement_percentage = $total_goal > 0 ? round(($tot_actual_value / $total_goal) * 100, 2) : 0;

          $staffDetails = [
            'rework'                    => $team->rework ?? 0,
            'rework_actual'             => $rework_count ?? 0,
            'working_hours'             => $team->working_hours ?? 0,
            'working_hours_actual'      => $working_hoursActual ?? 0,
            'goalset_percentage'        => $achievement_percentage ?? 0,
            '10x_status'                => $goalsts ?? 0,
          ];
          // Update team goals in transaction
          DB::transaction(function () use ($team, $staffDetails, &$inserted_records) {
            $team->rework_actual = $staffDetails['rework_actual'];
            $team->working_hours_actual = $staffDetails['working_hours_actual'];
            $team->status_10x = $staffDetails['10x_status'];
            $team->goalset_percentage = $staffDetails['goalset_percentage'];
            $team->goal_completed = 1;
            $team->save();
            $inserted_records++;
          });
        }
      }

      // ##############################################################################################
      // ******************************** Journal Department ******************************************
      // ##############################################################################################
      if ($team->department_id == 14) {
        $salesStaff = $staffs;
        $no_of_papers_countActual = 0;
        $helper = new \App\Helpers\Helpers();
        foreach ($salesStaff as $member) {

          if (in_array($member->role_id, [33, 34])) {
            $field = $member->role_id == 33 ? 'jc_id' : 'jc_staff';

            $pub_count = DB::table('et_customer_services')
              ->join('et_manage_journal', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
              ->whereYear('et_manage_journal.published_at', $year)
              ->whereMonth('et_manage_journal.published_at', $month)
              ->where('et_manage_journal.status', 6)
              ->where("et_customer_services.{$field}", $member->sno)
              ->count();

            $acp_count = DB::table('et_customer_services')
              ->join('et_manage_journal', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
              ->whereYear('et_manage_journal.accepted_at', $year)
              ->whereMonth('et_manage_journal.accepted_at', $month)
              ->where('et_manage_journal.status', 4)
              ->where("et_customer_services.{$field}", $member->sno)
              ->count();

            $no_of_papers_countActual += $pub_count + $acp_count;
          }


          $staffDetails2 = [
            'no_of_papers'                    => $goalsetData[$member->sno]->no_of_papers ?? 0,
            'no_of_papers_actual'             => $no_of_papers_countActual ?? 0,
          ];


          $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
          $goal_achievements = true;  // true = all 10X goals achieved
          $staffAchieved = true;      // true = individual staff goals achieved
          $allOverZero = true;        // true = all goals have zero target
          $total_goal = 0;
          $tot_actual_value = 0;
          $actual_values = 0;
          $values = [];

          if (!empty($ten_x) && is_array($ten_x)) {
            foreach ($ten_x as $key => $value) {
              if ($value === "1") {
                $type2 = str_replace("_10x", "", $key);
                $goal_value = (float)($staffDetails2[$type2] ?? 0);
                $actual_value = (float)($staffDetails2[$type2 . '_actual'] ?? 0);

                // Track if any goal has non-zero target
                if ($goal_value > 0) {
                  $allOverZero = false;
                }

                // Check individual goal achievement
                if ($goal_value > 0 && $actual_value < $goal_value) {
                  $goal_achievements = false;
                  $staffAchieved = false;
                }

                // Special case: No progress on valid goal
                if ($goal_value > 0 && $actual_value === 0) {
                  $staffAchieved = false;
                }

                // Special case for rework (lower is better)
                if ($type2 === 'rework') {
                  if ($goal_value > 0 && $actual_value > $goal_value) {
                    $staffAchieved = false;
                  }
                }

                if ($key == 'rework') {
                  if ($actual_value >= $goal_value) {
                    $actual_values = $goal_value;
                  }
                  $total_goal  += $goal_value;
                  $tot_actual_value  += $actual_values;
                } else {
                  if ($actual_value <= $goal_value) {
                    $total_goal  += $goal_value;
                    $tot_actual_value  += $goal_value;
                  } else {
                    $total_goal  += $goal_value;
                    $tot_actual_value  += $actual_value;
                  }
                }

                $values[] = [
                  'type' => $type2,
                  'goal' => $goal_value,
                  'actual' => $actual_value,
                  'achieved' => ($goal_value === 0 || $actual_value >= $goal_value)
                ];
              }
            }
          }

          // Final status determination (0=Not Assigned, 1=Achieved, 2=In Progress)
          $goalsts = 0;

          if ($goal_achievements && !$allOverZero) {
            $goalsts = 1;  // All 10X goals achieved
          } elseif (!$allOverZero) {
            $goalsts = 2;  // In progress (some goals not met)
          } // else: 0 (Not Assigned - all zeros)


          // Determine final status
          // return $values;
          // Calculate achievement percentage (optional)
          $achievement_percentage = $total_goal > 0 ? round(($tot_actual_value / $total_goal) * 100, 2) : 0;

          $staffDetails = [
            'no_of_papers_actual'      => $no_of_papers_countActual ?? 0,
            'goalset_percentage'        => $achievement_percentage ?? 0,
            '10x_status'                => $goalsts ?? 0,
          ];
          // Update team goals in transaction
          DB::transaction(function () use ($team, $staffDetails, &$inserted_records) {
            $team->no_of_papers_actual = $staffDetails['no_of_papers_actual'];
            $team->status_10x = $staffDetails['10x_status'];
            $team->goalset_percentage = $staffDetails['goalset_percentage'];
            $team->goal_completed = 1;
            $team->save();
            $inserted_records++;
          });
        }
      }

      // ##############################################################################################
      // ******************************** CRE Department ******************************************
      // ##############################################################################################
      if ($team->department_id == 6) {
        $salesStaff = $staffs;
        $helper     = new \App\Helpers\Helpers();
        $branchId   = $branch_id;

        $branch = BranchModel::where('sno', $branchId)
          ->where('status', 0)
          ->latest('sno')
          ->first();

        $gstPercent = $branch ? $branch->gst_percentage : 18;

        /* FINAL TOTALS */
        $collectionHarvestingAmount = 0; // Scheduled
        $collectedHarvestingAmount  = 0; // Paid
        $totalOutstandingAmount     = 0;

        $firstIds = DB::table('et_proposal_pay_slot')
          ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
          ->where('et_proposal.status', 0)
          ->where('et_proposal_pay_slot.status', 0)
          ->whereNotIn('et_proposal.proposal_status', [0, 2])
          ->selectRaw('MIN(et_proposal_pay_slot.sno) as first_id')
          ->groupBy('et_proposal_pay_slot.proposal_sno')
          ->pluck('first_id');

        foreach ($salesStaff as $member) {

          $userId = $member->sno;

          $paidInr = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_proposal.cre_id', $userId)
            ->where('et_proposal.currency_id', 70)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
            ->sum('et_proposal_pay_slot.paidAmount');

          $paidInr = round($paidInr / (1 + ($gstPercent / 100)), 2);

          $paidNonInrRows = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_proposal.cre_id', $userId)
            ->where('et_proposal.currency_id', '!=', 70)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
            ->get();

          $paidNonInr = 0;
          foreach ($paidNonInrRows as $row) {
            $paidNonInr += $helper->ConvertedAmountInr($row->currency_code, $row->paidAmount);
          }

          $paidNonInr = round($paidNonInr / (1 + ($gstPercent / 100)), 2);

          $totalPaid = $paidInr + $paidNonInr;

          $notPaidInr = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_proposal.cre_id', $userId)
            ->where('et_proposal.currency_id', 70)
            ->where('et_proposal_pay_slot.paid_status', 0)
            ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
            ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
            ->sum('et_proposal_pay_slot.payable_amount');

          $notPaidInr = round($notPaidInr / (1 + ($gstPercent / 100)), 2);

          $notPaidNonInrRows = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->where('et_proposal.cre_id', $userId)
            ->where('et_proposal.currency_id', '!=', 70)
            ->where('et_proposal_pay_slot.paid_status', 0)
            ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
            ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
            ->get();

          $notPaidNonInr = 0;
          foreach ($notPaidNonInrRows as $row) {
            $notPaidNonInr += $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);
          }

          $notPaidNonInr = round($notPaidNonInr / (1 + ($gstPercent / 100)), 2);

          $scheduled   = $totalPaid + $notPaidInr + $notPaidNonInr;
          $outstanding = $scheduled - $totalPaid;

          $collectionHarvestingAmount = $scheduled;
          $collectedHarvestingAmount  = $totalPaid;
          $totalOutstandingAmount     = $outstanding;


          $harvesting_percentage_countActual = round(
            $collectionHarvestingAmount > 0
              ? ($collectedHarvestingAmount / $collectionHarvestingAmount) * 100
              : 0,
            1
          );

          $outstandingPercentage = round(
            $collectionHarvestingAmount > 0
              ? ($totalOutstandingAmount / $collectionHarvestingAmount) * 100
              : 0,
            1
          );

          $staffDetails2 = [
            'harvesting_percentage'                    => $goalsetData[$member->sno]->harvesting_percentage ?? 0,
            'harvesting_percentage_actual'             => $harvesting_percentage_countActual ?? 0,
          ];


          $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
          $goal_achievements = true;  // true = all 10X goals achieved
          $staffAchieved = true;      // true = individual staff goals achieved
          $allOverZero = true;        // true = all goals have zero target
          $total_goal = 0;
          $tot_actual_value = 0;
          $actual_values = 0;
          $values = [];

          if (!empty($ten_x) && is_array($ten_x)) {
            foreach ($ten_x as $key => $value) {
              if ($value === "1") {
                $type2 = str_replace("_10x", "", $key);
                $goal_value = (float)($staffDetails2[$type2] ?? 0);
                $actual_value = (float)($staffDetails2[$type2 . '_actual'] ?? 0);

                // Track if any goal has non-zero target
                if ($goal_value > 0) {
                  $allOverZero = false;
                }

                // Check individual goal achievement
                if ($goal_value > 0 && $actual_value < $goal_value) {
                  $goal_achievements = false;
                  $staffAchieved = false;
                }

                // Special case: No progress on valid goal
                if ($goal_value > 0 && $actual_value === 0) {
                  $staffAchieved = false;
                }

                // Special case for rework (lower is better)
                if ($type2 === 'rework') {
                  if ($goal_value > 0 && $actual_value > $goal_value) {
                    $staffAchieved = false;
                  }
                }

                if ($key == 'rework') {
                  if ($actual_value >= $goal_value) {
                    $actual_values = $goal_value;
                  }
                  $total_goal  += $goal_value;
                  $tot_actual_value  += $actual_values;
                } else {
                  if ($actual_value <= $goal_value) {
                    $total_goal  += $goal_value;
                    $tot_actual_value  += $goal_value;
                  } else {
                    $total_goal  += $goal_value;
                    $tot_actual_value  += $actual_value;
                  }
                }

                $values[] = [
                  'type' => $type2,
                  'goal' => $goal_value,
                  'actual' => $actual_value,
                  'achieved' => ($goal_value === 0 || $actual_value >= $goal_value)
                ];
              }
            }
          }

          // Final status determination (0=Not Assigned, 1=Achieved, 2=In Progress)
          $goalsts = 0;

          if ($goal_achievements && !$allOverZero) {
            $goalsts = 1;  // All 10X goals achieved
          } elseif (!$allOverZero) {
            $goalsts = 2;  // In progress (some goals not met)
          } // else: 0 (Not Assigned - all zeros)


          // Determine final status
          // return $values;
          // Calculate achievement percentage (optional)
          $achievement_percentage = $total_goal > 0 ? round(($tot_actual_value / $total_goal) * 100, 2) : 0;

          $staffDetails = [
            'harvesting_percentage'     => $harvesting_percentage_countActual ?? 0,
            'goalset_percentage'        => $achievement_percentage ?? 0,
            '10x_status'                => $goalsts ?? 0,
          ];
          // Update team goals in transaction
          DB::transaction(function () use ($team, $staffDetails, &$inserted_records) {
            $team->harvesting_percentage = $staffDetails['harvesting_percentage'];
            $team->status_10x = $staffDetails['10x_status'];
            $team->goalset_percentage = $staffDetails['goalset_percentage'];
            $team->goal_completed = 1;
            $team->save();
            $inserted_records++;
          });
        }
      }
    }

    // ##############################################################################################
    // ******************************** Cronjob Monitor End ****************************************
    // ##############################################################################################

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    $duration = gmdate("H:i:s", $execution_time);

    // Update monitor
    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      CronjobLogModel::create([
        'cronjob_id'           => $monitor->sno,
        'sync_start_date_time' => $startDateTime->format('Y-m-d H:i:s'),
        'sync_end_date_time'   => $endDateTime->format('Y-m-d H:i:s'),
        'sync_duration'        => $duration,
        'response'             => json_encode([
          'processed_records' => $inserted_records,
          'execution_time'    => $duration,
        ]),
        'created_by' => 0,
        'updated_by' => 0,
      ]);
    }

    return [
      'processed_records' => $inserted_records,
      'execution_time' => $execution_time . ' seconds'
    ];
  }
  
  public function Cronjob_Staff_Stop_Task_Timer()
  {
    // Get cronjob monitor
    $monitor = CronjobMonitorModel::where('sno', 17)->first();
 
    if ($monitor && $monitor->status != 0) {
      // Stop execution if cron is OFF
      return response()->json([
        'success' => false,
        'message' => 'Cronjob status Off'
      ]);
    }
 
    $start_time = microtime(true);
    $startDateTime = Carbon::now('Asia/Kolkata');
 
    if ($monitor) {
      $monitor->running_status = 1;
      $monitor->save();
    }
 
    $processed_records = 0;
    $errors = [];
 
    try {
      // Get all task logs that are not ended yet and have status 0
      $query = DB::table('et_task_log')
        ->whereNull('end_time')
        ->where('status', 0);
 
      $query->orderBy('sno')->chunkById(100, function ($taskLogs) use (&$processed_records, &$errors) {
        // Get the current hour
        $currentHour = Carbon::now('Asia/Kolkata')->hour;
 
        // Check if the current hour is greater than or equal to 20 (8 PM)
        if ($currentHour >= 20) {
          foreach ($taskLogs as $log) {
            try {
              // Retrieve the Task Log entry by its unique identifier
              $taskLog = TaskLogModel::find($log->sno);
 
              if (!$taskLog) {
                // Handle case where the task log entry is not found
                return response()->json(['error' => 'Task log not found'], 404);
              }
 
              // Get the current time in 'Asia/Kolkata' timezone
              $now = Carbon::now('Asia/Kolkata');
 
              // Ensure start_time exists in the task log, otherwise throw an error
              if (!$taskLog->start_time) {
                return response()->json(['error' => 'Start time not found in task log'], 400);
              }
 
              // Parse the start_time from the task log
              $startTime = Carbon::parse($taskLog->start_time);
 
              // Calculate the duration between start_time and now, ensuring a non-negative duration
              $durationSeconds = max(0, $now->timestamp - $startTime->timestamp);
 
              // Format the duration as HH:MM:SS
              $taskLog->duration = gmdate('H:i:s', $durationSeconds);
 
              // Update the task log with end time and set the status to "completed" (1)
              $taskLog->end_time = $now;
              $taskLog->status = 1; // Assuming 1 means completed or finished
              $taskLog->updated_by = 1; // Assuming 1 refers to an admin or system user
 
              // Save the updated task log
              $taskLog->save();
 
              // Update user's task timer status
              $getUser = User::where('user_id', $log->staff_id)->first();
              if ($getUser) {
                $getUser->task_timer = 1;
                $getUser->task_timer_pass = null;
                $getUser->task_timer_pass_time = null;
                $getUser->save();
              }
 
              $processed_records++;
            } catch (\Exception $e) {
              $errors[] = [
                'task_log_id' => $log->sno ?? 'unknown',
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
              ];
            }
          }
        }
       
      }, 'sno'); // Specify the primary key column name
 
 
    } catch (\Exception $e) {
      // Log error and set running status to 0
      if ($monitor) {
        $monitor->running_status = 0;
        $monitor->save();
      }
 
      return response()->json([
        'success' => false,
        'message' => 'Cronjob execution failed',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
      ], 500);
    }
 
    $end_time = microtime(true);
    $execution_time_seconds = round($end_time - $start_time, 4);
    $endDateTime = Carbon::now('Asia/Kolkata');
 
    // Format duration properly
    $duration = gmdate('H:i:s', (int)$execution_time_seconds);
 
    if ($monitor) {
      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration = $duration;
      $monitor->running_status = 0;
      $monitor->save();
 
      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration = $duration;
      $monitor_log->response = json_encode([
        'success' => $processed_records > 0 || count($errors) == 0,
        'processed_records' => $processed_records,
        'error_count' => count($errors),
        'errors' => array_slice($errors, 0, 10), // Only log first 10 errors to avoid huge logs
        'execution_time_seconds' => $execution_time_seconds,
        'execution_time_formatted' => $duration
      ]);
      $monitor_log->created_by = 0;
      $monitor_log->updated_by = 0;
      $monitor_log->save();
    }
 
    return response()->json([
      'success' => $processed_records > 0 || count($errors) == 0,
      'processed_records' => $processed_records,
      'error_count' => count($errors),
      'execution_time_seconds' => $execution_time_seconds,
      'execution_time_formatted' => $duration,
      'errors' => array_slice($errors, 0, 5) // Return only first 5 errors
    ]);
  }
  
   // 7days Before
  public function Cronjob_HotleadToLeadBasket()
  {
    $monitor = CronjobMonitorModel::where('sno', 19)->first();
    $start_time = microtime(true);

    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $inserted_records = 0;
    $genset = GeneralSettingsModel::where('sno', 1)->first();

    if ($genset && $genset->hotleadtoleadbasket) {
      $hot_lead_day = $genset->hotleadtoleadbasket;
      $now = Carbon::now();
      $today = Carbon::today();

      // Calculate additional hours for weekends/holidays
      $additional_days = 0;

      // Check weekends
      if ($today->isSunday() || $today->isMonday()) {
        $additional_days += 1;
      }

      // Check holidays - single optimized query
      $beforeHours = $now->copy()->subDays($hot_lead_day + $additional_days);
      $holiday_count = DB::table('et_holiday')
        ->whereBetween('hol_date', [$beforeHours->toDateString(), $today->toDateString()])
        ->count();

      $additional_days += $holiday_count;

      // Calculate final cutoff date
      $before_date = $now->copy()->subDays($hot_lead_day + $additional_days)->format('Y-m-d');

      $get_leads = DB::table('et_lead')
        ->select(
          'et_lead.sno',
          'et_lead.status',
          'et_lead.lead_name',
          'et_lead.created_by',
          'et_lead.branch_id'
        )
        ->leftJoin('et_branch', 'et_lead.branch_id', '=', 'et_branch.sno')
        ->where('et_branch.branch_type', 1)
        ->whereNotIN('et_lead.lead_status_id', [1, 3])
        ->where('et_lead.is_hot_lead', 0)
        ->where('et_lead.is_potential', 0)
        ->where('et_lead.potential_verify', 0)
        ->where('et_lead.spam_verified', 0)
        ->where('et_lead.drop_verified', 0)
        ->whereNotIn('et_lead.status', [10, 4])
        // ->limit(500)
        ->orderBy('et_lead.sno', 'desc')
        ->get();
 

      foreach ($get_leads as $lead) {
        $get_followup = DB::table('et_appointment')
          ->where('lead_id', $lead->sno)
          ->whereBetween('appointment_date', [$before_date, $today->format('Y-m-d')])
          ->first();

        if (empty($get_followup)) {
          $lead_update = LeadModel::where('sno', $lead->sno)->first();
          if ($lead_update) {
            $lead_update->internal_status = 1;
            $lead_update->potential_verify = 1;
            $lead_update->is_potential = 1;
            $lead_update->potentail_reason = 'Auto Convert 7days Unfollow-up Lead';
            $lead_update->save();
            $inserted_records++;
          }
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    // Convert seconds to H:i:s
    $hours = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {
      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration = $duration;
      $monitor->running_status = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration = $duration;
      $monitor_log->response = json_encode([
        'processed_records' => $inserted_records,
        'execution_time' => $duration,
      ]);
      $monitor_log->created_by = 0;
      $monitor_log->updated_by = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time' => "{$execution_time} seconds",
    ];
  }

  // 48hours
  public function Cronjob_UnfollowToLeadBasket()
  {
    $monitor = CronjobMonitorModel::where('sno', 20)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor) {
      if ($monitor->status != 0) {
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $inserted_records = 0;
    $genset = GeneralSettingsModel::where('sno', 1)->first();

    if ($genset && $genset->unfollowtoleadbasket) {
      $lead_hours = $genset->unfollowtoleadbasket ?? 48;
      $now = Carbon::now();
      $today = Carbon::today();

      // Calculate additional hours for weekends/holidays
      $additional_hours = 0;

      // Check weekends
      if ($today->isSunday() || $today->isMonday()) {
        $additional_hours += 32;
      }

      // Check holidays - single optimized query
      $beforeHours = $now->copy()->subHours($lead_hours + $additional_hours);
      $holiday_count = DB::table('et_holiday')
        ->whereBetween('hol_date', [$beforeHours->toDateString(), $today->toDateString()])
        ->count();

      $additional_hours += ($holiday_count * 30);

      // Calculate final cutoff time
      $beforeday = $now->subHours($lead_hours + $additional_hours);

      // Single optimized query to get all leads with their call status
      $leads_with_call_status = DB::table('et_lead as l')
        ->select([
          'l.sno',
          'l.lead_mobile',
          DB::raw('MAX(ct.call_start_date) as last_call_date'),
          DB::raw('COUNT(ct.sno) as call_count')
        ])
        ->leftJoin('et_call_tracker as ct', function ($join) use ($beforeday) {
          $join->on(DB::raw('RIGHT(ct.customer_phone_no, 10)'), '=', 'l.lead_mobile');
            // ->where('ct.call_start_date', '>=', $beforeday);
        })
        ->leftJoin('et_branch', 'l.branch_id', '=', 'et_branch.sno')
        ->where('et_branch.branch_type', 1)
        ->where('l.status', 0)
        ->where('l.lead_status_id', 1)
        ->where('l.potential_verify', 0)
        ->where('l.is_potential', 0)
        ->where('l.spam_verified', 0)
        ->where('l.drop_verified', 0)
        ->whereDate('l.registered_date', '<', $beforeday->toDateString())
        ->groupBy('l.sno', 'l.lead_mobile')
        ->having('call_count', '=', 0) // Only leads with no calls
        ->get();

      if ($leads_with_call_status->isNotEmpty()) {
        $lead_ids = $leads_with_call_status->pluck('sno')->toArray();

        // Bulk update in chunks to avoid memory issues
        $chunks = array_chunk($lead_ids, 100);
        foreach ($chunks as $chunk) {
          $updated = DB::table('et_lead')
            ->whereIn('sno', $chunk)
            ->update([
              'internal_status' => 1,
              'potential_verify' => 1,
              'is_potential' => 1,
              'potentail_reason' => 'Auto Convert 48 hours Unfollow Lead',
              'updated_at' => $now
            ]);

          $inserted_records += $updated;
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    // Format duration
    $duration = gmdate("H:i:s", floor($execution_time));

    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration = $duration;
      $monitor->running_status = 0;
      $monitor->save();

      CronjobLogModel::create([
        'cronjob_id' => $monitor->sno,
        'sync_start_date_time' => $startDateTime->format('Y-m-d H:i:s'),
        'sync_end_date_time' => $endDateTime->format('Y-m-d H:i:s'),
        'sync_duration' => $duration,
        'response' => json_encode([
          'processed_records' => $inserted_records,
          'execution_time' => $duration,
        ]),
        'created_by' => 0,
        'updated_by' => 0
      ]);
    }

    return [
      'processed_records' => $inserted_records,
      'execution_time' => "{$execution_time} seconds",
    ];
  }

  /**
   * Schedule Daily Call
   */

//   public function Cronjob_DailyCallList()
//   {
//     $monitor = CronjobMonitorModel::where('sno', 21)->where('status', 0)->first();
//     $start_time = microtime(true);
//     $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

//     // Early return checks
//     if ($monitor && $monitor->status != 0) {
//       $return = [
//         'success' => false,
//         'processed_records' => 0,
//         'message' => 'Cronjob status Off',
//         'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
//       ];
//       return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
//     }

//     if ($monitor) {
//       $monitor->running_status = 1;
//       $monitor->save();
//     }

//     $inserted_records = 0;
//     $processed_branches = 0;
//     $branch_messages = [];

//     $genset = GeneralSettingsModel::where('sno', 1)->first();

//     if (!$genset) {
//       $return = [
//         'success' => false,
//         'processed_records' => 0,
//         'message' => 'General settings not found',
//         'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
//       ];
//       return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
//     }

//     // Only proceed if nextschdate matches today
//     if ($genset->nextschdate != date('Y-m-d')) {
//       $return = [
//         'success' => true,
//         'processed_records' => 0,
//         'message' => 'Not scheduled for today',
//         'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
//       ];
//       return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
//     }

//     // Required settings check
//     if (!isset($genset->cycling_month) || !isset($genset->pb_days)) {
//       $return = [
//         'success' => false,
//         'processed_records' => 0,
//         'message' => 'Required settings missing',
//         'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
//       ];
//       return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
//     }

//     $activeBranch = DB::table('et_branch')->where('status', 0)->where('branch_type', 1)->get();

//     // Get all staff data in one query
//     $allStaff = DB::table('et_staff')
//       ->select(
//         'sno',
//         'staff_name',
//         'branch_id',
//         'call_check',
//         'call_count'
//       )
//       ->where('status', 0)
//       ->where('department_id', 1)
//       ->where('call_check', 1)
//       ->where('call_count', '>', 0)
//       ->where('inactive_status', 0)
//       ->inRandomOrder()
//       ->get()
//       ->groupBy('branch_id');

//     foreach ($activeBranch as $branch) {
//       $branch_id = $branch->sno;
//       $branch_name = $branch->branch_name ?? 'Branch ' . $branch_id;

//       // Get staff for this branch
//       $salesStaff = isset($allStaff[$branch_id]) ? $allStaff[$branch_id] : collect();
//       $salesStaffCount = $salesStaff->count();

//       if ($salesStaffCount == 0) {
//         $branch_messages[] = "Branch {$branch_name}: No active sales staff found";
//         continue;
//       }

//       $daysAgo = 5;
//       $subDate = Carbon::now()->subDays($daysAgo);

//       DB::table('et_schedule_daily_call')
//         ->where('branch_id', $branch_id)
//         ->where('sch_date', '<', $subDate)
//         ->where('status', 0)
//         ->update([
//           'status' => 3,
//           'updated_at' => now()
//         ]);
//       DB::table('et_lead')
//         ->where('branch_id', $branch_id)
//         ->where('dc_date', '<', $subDate)
//         ->where('is_dc', 1)
//         ->update([
//           'is_dc' => 0,
//           'dc_date' => null,
//           'updated_at' => now()
//         ]);

//       $now = Carbon::now('Asia/Kolkata');
//       $today = Carbon::today('Asia/Kolkata');
//       $pb_days = $genset->pb_days;

//       // Calculate additional days for weekends/holidays (these days will be skipped)
//       $additional_days = 0;

//       // Get holidays list for the upcoming period
//       $endDate = $now->copy()->addDays($pb_days * 2); // Look ahead enough days
//       $holidays = DB::table('et_holiday')
//         ->whereBetween('hol_date', [$today->toDateString(), $endDate->toDateString()])
//         ->pluck('hol_date')
//         ->map(function ($date) {
//           return Carbon::parse($date)->toDateString();
//         })
//         ->toArray();

//       $branchProcessed = false;
//       $staffMessages = [];

//       // Track assigned lead IDs to prevent duplicates across staff
//       $assignedLeadIds = [];

//       // Process each staff member individually
//       foreach ($salesStaff as $staff) {
//         $neededLeads = $staff->call_count * $pb_days;

//         // Find available leads for this specific staff
//         $monthRanges = [6, 8];
//         $workingConfig = null;
//         $selectedMonths = null;
//         $availableLeads = null;
//         $maxAvailableInAnyRange = 0;
//         $bestMonthRange = null;

//         foreach ($monthRanges as $months) {
//           $startDate = Carbon::now()->subMonths($months)->startOfMonth();
//           $currentDate = Carbon::now();
          
//           // Count available leads (not assigned to anyone yet)
//           $totalAvailable = DB::table('et_lead')
//                   ->whereBetween('registered_date', [$startDate, $currentDate])
//                   ->where('potential_verify', 1)
//                   ->where('is_potential', 1)
//                   ->where('spam_verified', 0)
//                   ->where('drop_verified', 0)
//                   ->whereNotIn('status', [10, 4])
//                   ->where('branch_id', $branch_id)
//                   ->whereNotIn('sno', $assignedLeadIds)
//                   ->where(function ($query) use ($subDate) {
//                       $query->whereDate('dc_date', '<', $subDate)
//                             ->orWhereNull('dc_date');
//                   })
//                   ->where(function ($query) {
//                       $query->whereNull('is_dc')
//                             ->orWhere('is_dc', 0);
//                   })
//                   ->count();

//           // Track the maximum available for reporting
//           if ($totalAvailable > $maxAvailableInAnyRange) {
//             $maxAvailableInAnyRange = $totalAvailable;
//             $bestMonthRange = $months;
//           }

//           if ($totalAvailable >= $neededLeads) {
//             // Get the actual leads
//             $availableLeads = DB::table('et_lead')
//               ->select('sno', 'created_by', 'registered_date')
//               ->whereBetween('registered_date', [$startDate, $currentDate])
//               ->where('potential_verify', 1)
//               ->where('is_potential', 1)
//               ->where('spam_verified', 0)
//               ->where('drop_verified', 0)
//               ->whereNotIn('status', [10, 4])
//               ->where('branch_id', $branch_id)
//               ->whereNotIn('sno', $assignedLeadIds)
//               ->where(function ($query) {
//                 $query->whereNull('is_dc')
//                   ->orWhere('is_dc', 0);
//               })
//               ->where(function ($query) use ($subDate) {
//                   $query->whereDate('dc_date', '<', $subDate)
//                         ->orWhereNull('dc_date');
//               })
//               ->orderBy('registered_date', 'asc')
//               ->inRandomOrder()  // <-- This will randomize the order
//               ->limit($neededLeads)
//               ->get();

//             $workingConfig = [
//               'months' => $months,
//               'start_date' => $startDate,
//               'end_date' => $currentDate,
//               'split' => $staff->call_count
//             ];
//             $selectedMonths = $months;
//             break;
//           }
//         }

//         if (!$workingConfig || !$availableLeads || $availableLeads->isEmpty()) {
//           $staffMessages[] = "Staff {$staff->staff_name}: Needs {$neededLeads} leads but only {$maxAvailableInAnyRange} available in best range ({$bestMonthRange} months)";
//           continue;
//         }

//         // Assign leads to this staff (skipping Sundays and holidays)
//         $insertCount = $this->assignLeadsToStaff(
//           $branch_id,
//           $staff,
//           $workingConfig,
//           $pb_days,
//           $availableLeads,
//           $holidays // Pass holidays array
//         );

//         if ($insertCount > 0) {
//           // Add assigned lead IDs to the tracking array
//           foreach ($availableLeads as $lead) {
//             $assignedLeadIds[] = $lead->sno;
//           }

//           $inserted_records += $insertCount;
//           $branchProcessed = true;
//           $staffMessages[] = "Staff {$staff->staff_name}: Successfully assigned {$insertCount} leads (skipping Sundays and holidays)";

//           // Update genset with the working configuration (use the first successful staff's config)
//           if ($selectedMonths != $genset->cycling_month) {
//             $genset->cycling_month = $selectedMonths;
//             $genset->is_posible = 0;
//             $genset->save();
//           }
//         } else {
//           $staffMessages[] = "Staff {$staff->staff_name}: Failed to assign leads";
//         }
//       }

//       if ($branchProcessed) {
//         $processed_branches++;
//       }

//       $branch_messages = array_merge($branch_messages, $staffMessages);
//     }

//     // Update next schedule date
//     if ($inserted_records > 0) {
//       $Nxtsch = Carbon::now('Asia/Kolkata')->addDays($genset->pb_days)->toDateString();
//       $genset->nextschdate = $Nxtsch;
//       $genset->save();
//     }

//     $return = [
//       'success' => true,
//       'processed_records' => $inserted_records,
//       'processed_branches' => $processed_branches,
//       'total_branches' => count($activeBranch),
//       'branch_details' => $branch_messages,
//       'message' => $inserted_records > 0 ? 'Cron job completed successfully' : 'No records were inserted',
//       'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
//     ];

//     return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
//   }

//   private function assignLeadsToStaff($branch_id, $staff, $config, $pb_days, $leads, $holidays = [])
//   {
//     $inserted = 0;
//     $schedules = [];
//     $leadUpdates = [];

//     $leadIndex = 0;
//     $leadCount = $leads->count();

//     DB::beginTransaction();

//     try {
//       $day = 0;
//       $assignedDays = 0;

//       // Keep assigning until we've assigned leads for all required working days
//       while ($assignedDays < $pb_days && $leadIndex < $leadCount) {
//         $assignmentDate = Carbon::now('Asia/Kolkata')->addDays($day)->toDateString();
//         $assignmentDayOfWeek = Carbon::parse($assignmentDate)->dayOfWeek; // 0 = Sunday, 1 = Monday, etc.

//         // Check if it's Sunday (0) or a holiday
//         $isSunday = ($assignmentDayOfWeek == 0);
//         $isHoliday = in_array($assignmentDate, $holidays);

//         // Skip if it's Sunday or holiday
//         if (!$isSunday && !$isHoliday) {
//           // This is a working day - assign leads
//           for ($i = 0; $i < $config['split']; $i++) {
//             if ($leadIndex >= $leadCount) {
//               break 2;
//             }

//             $lead = $leads[$leadIndex];

//             // Prepare lead update
//             $leadUpdates[] = [
//               'sno' => $lead->sno,
//               'is_dc' => 1,
//               'internal_status' => 1,
//               'potential_verify' => 1,
//               'is_potential' => 1,
//               'dc_date' => $assignmentDate,
//               'dc_staff_id' => $staff->sno,
//               'updated_at' => Carbon::now('Asia/Kolkata')
//             ];

//             // Prepare schedule insert
//             $schedules[] = [
//               'branch_id' => $branch_id,
//               'lead_id' => $lead->sno,
//               'previous_staff' => $lead->created_by,
//               'current_staff' => $staff->sno,
//               'sch_date' => $assignmentDate,
//               'created_at' => Carbon::now('Asia/Kolkata'),
//               'updated_at' => Carbon::now('Asia/Kolkata')
//             ];

//             $leadIndex++;
//             $inserted++;
//           }
//           $assignedDays++;
//         }

//         $day++;
//       }

//       // Batch update leads
//       if (!empty($leadUpdates)) {
//         foreach ($leadUpdates as $update) {
//           DB::table('et_lead')
//             ->where('sno', $update['sno'])
//             ->update([
//               'is_dc' => $update['is_dc'],
//               'internal_status' => $update['internal_status'],
//               'potential_verify' => $update['potential_verify'],
//               'is_potential' => $update['is_potential'],
//               'dc_date' => $update['dc_date'],
//               'dc_staff_id' => $update['dc_staff_id'],
//               'updated_at' => $update['updated_at']
//             ]);
//         }
//       }

//       // Batch insert schedules
//       if (!empty($schedules)) {
//         foreach (array_chunk($schedules, 100) as $chunk) {
//           DB::table('et_schedule_daily_call')->insert($chunk);
//         }
//       }

//       DB::commit();
//       return $inserted;
//     } catch (\Exception $e) {
//       DB::rollBack();
//       // \Log::error('Lead assignment failed for staff ' . $staff->sno . ': ' . $e->getMessage());
//       return 0;
//     }
//   }

public function Cronjob_DailyCallList()
  {
    $monitor = CronjobMonitorModel::where('sno', 21)->where('status', 0)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
 
    // Early return checks
    if ($monitor && $monitor->status != 0) {
      $return = [
        'success' => false,
        'processed_records' => 0,
        'message' => 'Cronjob status Off',
        'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
      ];
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }
 
    if ($monitor) {
      $monitor->running_status = 1;
      $monitor->save();
    }
 
    $inserted_records = 0;
    $processed_branches = 0;
    $branch_messages = [];
 
    $genset = GeneralSettingsModel::where('sno', 1)->first();
 
    if (!$genset) {
      $return = [
        'success' => false,
        'processed_records' => 0,
        'message' => 'General settings not found',
        'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
      ];
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }
 
    // Only proceed if nextschdate matches today
    if ($genset->nextschdate != date('Y-m-d')) {
      $return = [
        'success' => true,
        'processed_records' => 0,
        'message' => 'Not scheduled for today',
        'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
      ];
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }
 
    // Required settings check
    if (!isset($genset->cycling_month) || !isset($genset->pb_days)) {
      $return = [
        'success' => false,
        'processed_records' => 0,
        'message' => 'Required settings missing',
        'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
      ];
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }
 
    $activeBranch = DB::table('et_branch')->where('status', 0)->where('branch_type', 1)->get();
 
    // Get all staff data in one query
    $allStaff = DB::table('et_staff')
      ->select(
        'sno',
        'staff_name',
        'branch_id',
        'call_check',
        'call_count'
      )
      ->where('status', 0)
      ->where('department_id', 1)
      ->where('call_check', 1)
      ->where('call_count', '>', 0)
      ->where('inactive_status', 0)
      ->inRandomOrder()
      ->get()
      ->groupBy('branch_id');
 
    foreach ($activeBranch as $branch) {
      $branch_id = $branch->sno;
      $branch_name = $branch->branch_name ?? 'Branch ' . $branch_id;
 
      // Get staff for this branch
      $salesStaff = isset($allStaff[$branch_id]) ? $allStaff[$branch_id] : collect();
      $salesStaffCount = $salesStaff->count();
 
      if ($salesStaffCount == 0) {
        $branch_messages[] = "Branch {$branch_name}: No active sales staff found";
        continue;
      }
 
      $daysAgo = 3;
      $subDate = Carbon::now()->subDays($daysAgo);
 
      DB::table('et_schedule_daily_call')
        ->where('branch_id', $branch_id)
        ->where('sch_date', '<', $subDate)
        ->where('status', 0)
        ->update([
          'status' => 3,
          'updated_at' => now()
        ]);
      DB::table('et_lead')
        ->where('branch_id', $branch_id)
        ->where('dc_date', '<', $subDate)
        ->where('is_dc', 1)
        ->update([
          'is_dc' => 0,
          'dc_date' => null,
          'updated_at' => now()
        ]);
 
      $now = Carbon::now('Asia/Kolkata');
      $today = Carbon::today('Asia/Kolkata');
      $pb_days = $genset->pb_days;
 
      // Calculate additional days for weekends/holidays (these days will be skipped)
      $additional_days = 0;
 
      // Get holidays list for the upcoming period
      $endDate = $now->copy()->addDays($pb_days * 2); // Look ahead enough days
      $holidays = DB::table('et_holiday')
        ->whereBetween('hol_date', [$today->toDateString(), $endDate->toDateString()])
        ->pluck('hol_date')
        ->map(function ($date) {
          return Carbon::parse($date)->toDateString();
        })
        ->toArray();
 
      $branchProcessed = false;
      $staffMessages = [];
 
      // Track assigned lead IDs to prevent duplicates across staff
      $assignedLeadIds = [];
 
      // Process each staff member individually
      foreach ($salesStaff as $staff) {
        $neededLeads = $staff->call_count * $pb_days;
 
        // Find available leads for this specific staff
        $monthRanges = [6, 8];
        $workingConfig = null;
        $selectedMonths = null;
        $availableLeads = null;
        $maxAvailableInAnyRange = 0;
        $bestMonthRange = null;
 
        foreach ($monthRanges as $months) {
          $startDate = Carbon::now()->subMonths($months)->startOfMonth();
          $currentDate = Carbon::now();
         
          // Count available leads (not assigned to anyone yet)
          $totalAvailable = DB::table('et_lead')
                  ->whereBetween('registered_date', [$startDate, $currentDate])
                  ->where('potential_verify', 1)
                  ->where('is_potential', 1)
                  ->where('spam_verified', 0)
                  ->where('drop_verified', 0)
                  ->whereNotIn('status', [10, 4])
                  ->where('branch_id', $branch_id)
                  ->whereNotIn('sno', $assignedLeadIds)
                  ->where(function ($query) use ($subDate) {
                      $query->whereDate('dc_date', '<', $subDate)
                            ->orWhereNull('dc_date');
                  })
                  ->where(function ($query) {
                      $query->whereNull('is_dc')
                            ->orWhere('is_dc', 0);
                  })
                  ->count();
 
          // Track the maximum available for reporting
          if ($totalAvailable > $maxAvailableInAnyRange) {
            $maxAvailableInAnyRange = $totalAvailable;
            $bestMonthRange = $months;
          }
 
          if ($totalAvailable >= $neededLeads) {
            // Get the actual leads
            $availableLeads = DB::table('et_lead')
              ->select('sno', 'created_by', 'registered_date')
              ->whereBetween('registered_date', [$startDate, $currentDate])
              ->where('potential_verify', 1)
              ->where('is_potential', 1)
              ->where('spam_verified', 0)
              ->where('drop_verified', 0)
              ->whereNotIn('status', [10, 4])
              ->where('branch_id', $branch_id)
              ->whereNotIn('sno', $assignedLeadIds)
              ->where(function ($query) {
                $query->whereNull('is_dc')
                  ->orWhere('is_dc', 0);
              })
              ->where(function ($query) use ($subDate) {
                  $query->whereDate('dc_date', '<', $subDate)
                        ->orWhereNull('dc_date');
              })
              ->orderBy('registered_date', 'asc')
              ->inRandomOrder()  // <-- This will randomize the order
              ->limit($neededLeads)
              ->get();
 
            $workingConfig = [
              'months' => $months,
              'start_date' => $startDate,
              'end_date' => $currentDate,
              'split' => $staff->call_count
            ];
            $selectedMonths = $months;
            break;
          }
        }
 
        if (!$workingConfig || !$availableLeads || $availableLeads->isEmpty()) {
          $staffMessages[] = "Staff {$staff->staff_name}: Needs {$neededLeads} leads but only {$maxAvailableInAnyRange} available in best range ({$bestMonthRange} months)";
          continue;
        }
 
        // Assign leads to this staff (skipping Sundays and holidays)
        $insertCount = $this->assignLeadsToStaff(
          $branch_id,
          $staff,
          $workingConfig,
          $pb_days,
          $availableLeads,
          $holidays // Pass holidays array
        );
 
        if ($insertCount > 0) {
          // Add assigned lead IDs to the tracking array
          foreach ($availableLeads as $lead) {
            $assignedLeadIds[] = $lead->sno;
          }
 
          $inserted_records += $insertCount;
          $branchProcessed = true;
          $staffMessages[] = "Staff {$staff->staff_name}: Successfully assigned {$insertCount} leads (skipping Sundays and holidays)";
 
          // Update genset with the working configuration (use the first successful staff's config)
          if ($selectedMonths != $genset->cycling_month) {
            $genset->cycling_month = $selectedMonths;
            $genset->is_posible = 0;
            $genset->save();
          }
        } else {
          $staffMessages[] = "Staff {$staff->staff_name}: Failed to assign leads";
        }
      }
 
      if ($branchProcessed) {
        $processed_branches++;
      }
 
      $branch_messages = array_merge($branch_messages, $staffMessages);
    }
 
    // Update next schedule date
    if ($inserted_records > 0) {
      $Nxtsch = Carbon::now('Asia/Kolkata')->addDays($genset->pb_days)->toDateString();
      $genset->nextschdate = $Nxtsch;
      $genset->save();
    }
 
    $return = [
      'success' => true,
      'processed_records' => $inserted_records,
      'processed_branches' => $processed_branches,
      'total_branches' => count($activeBranch),
      'branch_details' => $branch_messages,
      'message' => $inserted_records > 0 ? 'Cron job completed successfully' : 'No records were inserted',
      'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
    ];
 
    return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
  }
 
  private function assignLeadsToStaff($branch_id, $staff, $config, $pb_days, $leads, $holidays = [])
  {
    $inserted = 0;
    $schedules = [];
    $leadUpdates = [];
 
    $leadIndex = 0;
    $leadCount = $leads->count();
 
    DB::beginTransaction();
 
    try {
      $day = 0;
      $assignedDays = 0;
      $today = Carbon::now('Asia/Kolkata')->startOfDay();
 
      // Convert holidays to proper format for comparison
      $holidaysFormatted = array_map(function ($date) {
        return Carbon::parse($date)->toDateString();
      }, $holidays);
 
      // Keep assigning until we've assigned leads for all required working days
      while ($assignedDays < $pb_days && $leadIndex < $leadCount) {
        // Start from today 
        $checkDate = $today->copy()->addDays($day); 
        $assignmentDate = $checkDate->toDateString();
        $assignmentDayOfWeek = $checkDate->dayOfWeek; // 0 = Sunday, 1 = Monday, etc.
 
        // Debug: Log the date being checked
       // \Log::info("Checking date: {$assignmentDate}, Day of week: {$assignmentDayOfWeek}");
 
        // Check if it's Sunday (0) or a holiday
        $isSunday = ($assignmentDayOfWeek == 0);
        $isHoliday = in_array($assignmentDate, $holidaysFormatted);
 
        // Skip if it's Sunday or holiday
        if (!$isSunday && !$isHoliday) {
          // Additional check: Verify this staff doesn't already have leads on this date
          $existingAssignments = DB::table('et_schedule_daily_call')
            ->where('current_staff', $staff->sno)
            ->whereDate('sch_date', $assignmentDate)
            ->where('status', 0)
            ->count();
 
          if ($existingAssignments > 0) {
          //  \Log::info("Staff {$staff->staff_name} already has {$existingAssignments} assignments on {$assignmentDate}, skipping");
            $day++;
            continue;
          }
 
         // \Log::info("Assigning for working day: {$assignmentDate}");
 
          // This is a working day - assign leads
          for ($i = 0; $i < $config['split']; $i++) {
            if ($leadIndex >= $leadCount) {
              break 2;
            }
 
            $lead = $leads[$leadIndex];
 
            // Verify lead isn't already assigned to this date
            $alreadyAssigned = DB::table('et_schedule_daily_call')
              ->where('lead_id', $lead->sno)
              ->whereDate('sch_date', $assignmentDate)
              ->exists();
 
            if ($alreadyAssigned) {
           //   \Log::info("Lead {$lead->sno} already assigned on {$assignmentDate}, skipping");
              $leadIndex++;
              $i--; // Try next lead for same slot
              continue;
            }
 
            // Prepare lead update
            $leadUpdates[] = [
              'sno' => $lead->sno,
              'is_dc' => 1,
              'internal_status' => 1,
              'potential_verify' => 1,
              'is_potential' => 1,
              'dc_date' => $assignmentDate,
              'dc_staff_id' => $staff->sno,
              'updated_at' => Carbon::now('Asia/Kolkata')
            ];
 
            // Prepare schedule insert
            $schedules[] = [
              'branch_id' => $branch_id,
              'lead_id' => $lead->sno,
              'previous_staff' => $lead->created_by,
              'current_staff' => $staff->sno,
              'sch_date' => $assignmentDate,
              'created_at' => Carbon::now('Asia/Kolkata'),
              'updated_at' => Carbon::now('Asia/Kolkata')
            ];
 
            $leadIndex++;
            $inserted++;
          }
          $assignedDays++;
        } else {
         // \Log::info("Skipping non-working day: {$assignmentDate} (Sunday: " . ($isSunday ? 'Yes' : 'No') . ", Holiday: " . ($isHoliday ? 'Yes' : 'No') . ")");
        }
 
        $day++;
      }
 
      // Batch update leads
      if (!empty($leadUpdates)) {
        foreach ($leadUpdates as $update) {
          DB::table('et_lead')
            ->where('sno', $update['sno'])
            ->update([
              'is_dc' => $update['is_dc'],
              'internal_status' => $update['internal_status'],
              'potential_verify' => $update['potential_verify'],
              'is_potential' => $update['is_potential'],
              'dc_date' => $update['dc_date'],
              'dc_staff_id' => $update['dc_staff_id'],
              'updated_at' => $update['updated_at']
            ]);
        }
      }
 
      // Batch insert schedules
      if (!empty($schedules)) {
        foreach (array_chunk($schedules, 100) as $chunk) {
          DB::table('et_schedule_daily_call')->insert($chunk);
        }
      }
 
      // Log summary
     // \Log::info("Assignment complete for staff {$staff->staff_name}: Assigned {$inserted} leads over {$assignedDays} working days");
 
      DB::commit();
      return $inserted;
    } catch (\Exception $e) {
      DB::rollBack();
      // \Log::error('Lead assignment failed for staff ' . $staff->sno . ': ' . $e->getMessage());
      return 0;
    }
  }
  

  private function updateCronMonitor($monitor, $startDateTime, $start_time, $return)
  {
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    // Convert seconds to H:i:s
    $hours = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    // Update the monitor if it exists
    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response = json_encode($return);
      $monitor_log->created_by = 0;
      $monitor_log->updated_by = 0;
      $monitor_log->save();
    }

    // Return the response
    return response()->json($return);
  }
  
     // Document Un upload files Remove
    public function Cronjob_Documents_unupload_files()
    {
        $monitor = CronjobMonitorModel::where('sno', 22)->first();
        $start_time = microtime(true);

        $startDateTime = Carbon::createFromTimestamp((int) $start_time, 'Asia/Kolkata');

        if ($monitor) {
            if ($monitor->status != 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cronjob status Off',
                ]);
            }
            $monitor->running_status = 1;
            $monitor->save();
        }

        $inserted_records = 0;

        // ✅ DELETE storage/app/temp folder
        $folderPath = storage_path('app/temp');

        if (File::exists($folderPath)) {
            File::deleteDirectory($folderPath);
        }

        // (Optional) recreate empty folder
        File::makeDirectory($folderPath, 0755, true, true);

        $end_time = microtime(true);
        $execution_time = round($end_time - $start_time, 4);

        $endDateTime = Carbon::createFromTimestamp((int) $end_time, 'Asia/Kolkata');

        $hours = floor($execution_time / 3600);
        $minutes = floor(($execution_time % 3600) / 60);
        $seconds = $execution_time % 60;
        $duration = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);

        if ($monitor) {
            $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
            $monitor->sync_duration = $duration;
            $monitor->running_status = 0;
            $monitor->save();

            $monitor_log = new CronjobLogModel();
            $monitor_log->cronjob_id = $monitor->sno;
            $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_duration = $duration;
            $monitor_log->response = json_encode([
                'execution_time' => $duration,
                'message' => 'Cron job completed successfully'
            ]);
            $monitor_log->created_by = 0;
            $monitor_log->updated_by = 0;
            $monitor_log->save();
        }

        return [
            'execution_time' => "{$execution_time} seconds",
            'message' => 'Cron job completed successfully'
        ];
    }

    // Document Expired After 14 days
    public function Cronjob_Documents_expiry()
    {
        $monitor = CronjobMonitorModel::where('sno', 22)->first();

        $start_time = microtime(true);
        $startDateTime = Carbon::now('Asia/Kolkata');

        if ($monitor) {
            if ($monitor->status != 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cronjob status Off',
                ]);
            }

            $monitor->running_status = 1;
            $monitor->save();
        }

        $daysAgo = 14;
        $subDate = Carbon::now()->subDays($daysAgo);

        // ✅ Single query update (optimized)
        $updatedRows = DB::table('et_milestone_folders')
            ->where('sync_date', '<', $subDate)
            ->where('is_sync', 0)
            ->update([
                'is_sync' => 1,
                'status'  => 2,
            ]);

        $end_time = microtime(true);
        $execution_time = $end_time - $start_time;

        $endDateTime = Carbon::now('Asia/Kolkata');

        // ✅ Proper duration formatting
        $hours = floor($execution_time / 3600);
        $minutes = floor(($execution_time % 3600) / 60);
        $seconds = floor($execution_time % 60);

        $duration = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);

        if ($monitor) {
            $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
            $monitor->sync_duration = $duration;
            $monitor->running_status = 0;
            $monitor->save();

            $monitor_log = new CronjobLogModel();
            $monitor_log->cronjob_id = $monitor->sno;
            $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_duration = $duration;
            $monitor_log->response = json_encode([
                'execution_time' => $duration,
                'updated_records' => $updatedRows,
                'message' => 'Cron job completed successfully'
            ]);
            $monitor_log->created_by = 0;
            $monitor_log->updated_by = 0;
            $monitor_log->save();
        }

        return [
            'execution_time' => round($execution_time, 4) . " seconds",
            'updated_records' => $updatedRows,
            'message' => 'Cron job completed successfully'
        ];
    }
  
}
