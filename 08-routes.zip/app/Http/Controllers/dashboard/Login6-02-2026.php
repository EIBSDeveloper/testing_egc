<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cookie;
// Model
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\UserRolePermissionModel;
use App\Models\BranchModel;
use App\Models\LeadModel;
use App\Models\LeadSourceModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;

class Login extends Controller
{
  public function index()
  {
    return view('content.dashboard.login');
  }
  public function get_staff()
  {
    return view('content.dashboard.get_staff');
  }
  public function forgot_password()
  {
    return view('content.dashboard.forgot_password');
  }
  public function new_password()
  {
    return view('content.dashboard.new_password');
  }
  public function dashboards()
  {
    // Initialize variables
    $branch_common = null;
    $role_user = null;
    $role_permission = null;
    $user = Auth::user();
    if ($user) {
      $branch_common   = BranchModel::where('sno', $user->branch_id)->first();
      $role_user       = UserRoleModel::where('sno', $user->role_id)->first();
      $role_permission = UserRolePermissionModel::where('role_id', $user->role_id)->first();
    }
    $helper = new \App\Helpers\Helpers();


    if ($user->role_id == 11) {
      return view('content.dashboard.sales_executive_dashboards', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }

    if ($user->role_id == 12) {
      return view('content.dashboard.sales_tl_dashboard_new', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }

    if ($user->role_id == 33) {
      return view('content.dashboard.journal_teamlead_dashboad', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }

    if ($user->role_id == 34) {
      return view('content.dashboard.journal_coordinator_dashbord', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }
    
    if ($user->role_id == 15) {
      return view('content.dashboard.pc_dashboard', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission
      ]);
    }
    
    return view('content.dashboard.dashboards-analytics', compact('branch_common', 'role_user', 'role_permission'));

    if ($user->role_id == 27   || $user->role_id == 13) {

      // Top 5 Sales Person
      $top_5_sales_persons = StaffModel::where('et_staff.branch_id', $user->branch_id)
        ->select(
          'et_staff.staff_name',
          'et_staff.nick_name',
          'et_staff.staff_image',
          DB::raw('COUNT(et_lead.created_by) as total_leads')
        )
        ->leftJoin('et_lead', 'et_lead.created_by', '=', 'et_staff.sno')
        ->whereMonth('et_lead.registered_date', date('m'))
        ->whereYear('et_lead.registered_date', date('Y'))
        ->where('et_staff.role_id', '!=', 12)
        ->where('et_lead.status', 4)
        ->groupBy('et_staff.staff_name', 'et_staff.nick_name', 'et_staff.staff_image')
        ->orderBy('total_leads', 'desc')
        ->limit(5)
        ->get();

      // ------------------------------------------------------------------------------------------------------

      // Lead Source

      // 1. Calculate total leads count (for same filters)
      $total_leads_overall = LeadModel::whereMonth('registered_date', date('m'))
        ->whereYear('registered_date', date('Y'))
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->count();

      // return $total_leads_overall;

      // 2. Get lead sources with counts
      $lead_sources = LeadSourceModel::where('et_lead_source.branch_id', $user->branch_id)
        ->select(
          'lead_source_name',
          DB::raw('COUNT(et_lead.lead_source_id) as total_leads')
        )
        ->leftJoin('et_lead', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
        ->where('et_lead_source.status', 0)
        ->whereMonth('et_lead.registered_date', date('m'))
        ->whereYear('et_lead.registered_date', date('Y'))
        ->where('et_lead.created_by', $user->user_id)
        ->groupBy('et_lead_source.lead_source_name')
        ->orderBy('total_leads', 'desc')
        ->get();

      // 3. Calculate percentage for each lead source
      foreach ($lead_sources as $lead_source) {
        $lead_source->percentage = $total_leads_overall > 0 ? round(($lead_source->total_leads / $total_leads_overall) * 100) : 0;
      }

      // --------------------------------------------------------------------------------------------------------------

      // Follow Up Schedule
      $todayAppointments = DB::table('et_appointment')
        ->select('et_appointment.*', 'et_lead.lead_name')
        ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
        ->whereDate('et_appointment.appointment_date', date('Y-m-d'))
        ->where('et_appointment.branch_id', $user->branch_id)
        ->where('et_appointment.created_by', $user->user_id)
        ->orderBy('et_appointment.lead_id')
        ->orderBy('et_appointment.appointment_date', 'asc')
        ->get();

      $filteredAppointments = collect();
      $seenLeads = [];

      foreach ($todayAppointments as $appointment) {
        $leadId = $appointment->lead_id;

        // Skip if this lead already has a higher-priority status recorded
        if (isset($seenLeads[$leadId])) continue;

        // Mark status flags
        $isCompleted = $appointment->status == 4;
        $isRescheduled = $appointment->status == 5;
        $isScheduled = $appointment->status == 1;

        if ($isCompleted) {
          $appointment->display_status = 'Completed';
          $seenLeads[$leadId] = true;
          $filteredAppointments->push($appointment);
        } elseif ($isRescheduled) {
          $appointment->display_status = 'Rescheduled';
          $seenLeads[$leadId] = true;
          $filteredAppointments->push($appointment);
        } elseif ($isScheduled) {
          $appointment->display_status = 'Scheduled';
          $seenLeads[$leadId] = true;
          $filteredAppointments->push($appointment);
        }
      }

      // --------------------------------------------------------------------------------------------------------------

      // Appointment Schedule
      $appointmentToday = DB::table('et_lead_appointment')
        ->select('et_lead_appointment.*', 'et_lead.lead_name')
        ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_lead_appointment.lead_id')
        ->whereDate('et_lead_appointment.appointment_date', date('Y-m-d'))
        ->where('et_lead_appointment.branch_id', $user->branch_id)
        ->where('et_lead_appointment.created_by', $user->user_id)
        ->orderBy('et_lead_appointment.lead_id')
        ->orderBy('et_lead_appointment.appointment_date', 'asc')
        ->get();

      $appointmentFilter = collect();
      $seenLeads = [];

      foreach ($appointmentToday as $app) {
        $lead_id = $app->lead_id;

        if (isset($seenLeads[$lead_id])) continue;

        $appCompleted = $app->appointment_status == 2;
        $appRescheduled = $app->appointment_status == 4;
        $appScheduled = $app->appointment_status == 1;

        if ($appCompleted) {
          $app->app_status = 'Completed';
          $seenLeads[$lead_id] = true;
          $appointmentFilter->push($app);
        } elseif ($appRescheduled) {
          $app->app_status = 'Rescheduled';
          $seenLeads[$lead_id] = true;
          $appointmentFilter->push($app);
        } elseif ($appScheduled) {
          $app->app_status = 'Scheduled';
          $seenLeads[$lead_id] = true;
          $appointmentFilter->push($app);
        }
      }

      // ---------------------------------------------------------------------------------------------------------

      // Walk In Count
      $walkInCount = $appointmentFilter->where('appointment_category', 'Walk-in')->count();

      // -----------------------------------------------------------------------------------------------------------

      $today = Carbon::now()->toDateString();
      $yesterday = Carbon::yesterday();

      $currentYear = Carbon::now()->year;
      $currentMonth = Carbon::now()->month;

      $previousMonthDate = Carbon::now()->subMonth();
      $previousMonth = $previousMonthDate->month;

      // Total Leads
      $currentMonthTotalLeads = LeadModel::where('branch_id', $user->branch_id)
        ->whereNotIn('status', [2, 6])
        ->where('internal_status', 0)
        ->where('spam_verified', 0)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $currentMonth)
        ->where('created_by', $user->user_id)
        ->count();

      $previousMonthTotalLeads = LeadModel::where('branch_id', $user->branch_id)
        ->whereNotIn('status', [2, 6])
        ->where('spam_verified', 0)
        ->where('internal_status', 0)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $previousMonth)
        ->count();


      $differenceTotalLeads = $currentMonthTotalLeads - $previousMonthTotalLeads;

      // Calculating Percentage (%)
      if ($previousMonthTotalLeads > 0) {
        $percentageTotalLeads = ($differenceTotalLeads / $previousMonthTotalLeads) * 100;

        if ($percentageTotalLeads < 0) {
          $percentageTotalLeads = 0;
        }

        if ($currentMonthTotalLeads == 0) {
          $percentageTotalLeads = 0;
        }
      } else {
        $percentageTotalLeads = $currentMonthTotalLeads > 0 ? 100 : 0;
      }

      // -------------------------------------------------------------------------------------------

      // Active Leads
      $currentMonthActiveLeads = LeadModel::where('status', 0)
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->whereNotIn('status', [2, 6])
        ->where('internal_status', 0)
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $currentMonth)
        ->count();

      $previousMonthActiveLeads = LeadModel::where('status', 0)
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->whereNotIn('status', [2, 6])
        ->where('internal_status', 0)
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $previousMonth)
        ->count();

      $differenceActiveLeads = $currentMonthActiveLeads - $previousMonthActiveLeads;

      // Calculating %
      if ($previousMonthActiveLeads > 0) {
        $percentageActiveLeads = ($differenceActiveLeads / $previousMonthActiveLeads) * 100;

        if ($percentageActiveLeads < 0) {
          $percentageActiveLeads = 0;
        }

        if ($currentMonthActiveLeads == 0) {
          $percentageActiveLeads = 0;
        }
      } else {
        $percentageActiveLeads = $currentMonthActiveLeads > 0 ? 100 : 0;
      }

      // ---------------------------------------------------------------------------------------------

      // Spam Leads
      $currentMonthSpamLeads = LeadModel::where('spam_verified', 1)
        ->where('internal_status', 0)
        ->where('drop_verified', 0)
        ->where('status', 7)
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereMonth('registered_date', $currentMonth)
        ->whereYear('registered_date', $currentYear)
        ->count();

      $perviousMonthSpamLeads = LeadModel::where('spam_verified', 1)
        ->where('internal_status', 0)
        ->where('drop_verified', 0)
        ->where('status', 7)
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $previousMonth)
        ->count();

      $differenceSpamLeads = $currentMonthSpamLeads - $perviousMonthSpamLeads;

      // Calculating %
      if ($perviousMonthSpamLeads > 0) {
        $percentageSpamLeads = ($differenceSpamLeads / $perviousMonthSpamLeads) * 100;

        if ($percentageSpamLeads < 0) {
          $percentageSpamLeads = 0;
        }

        if ($currentMonthSpamLeads == 0) {
          $percentageSpamLeads = 0;
        }
      } else {
        $percentageSpamLeads = $currentMonthSpamLeads > 0 ? 100 : 0;
      }

      // ----------------------------------------------------------------------------------------

      // Dead Leads
      $currentMonthDeadLeads = LeadModel::where('drop_verified', 1)
        ->where('spam_verified', 0)
        ->where('internal_status', 0)
        ->whereNotIn('status', [2, 6])
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $currentMonth)
        ->count();

      $previousMonthDeadLeads = LeadModel::where('drop_verified', 1)
        ->whereNotIn('status', [2, 6])
        ->where('spam_verified', 0)
        ->where('internal_status', 0)
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $previousMonth)
        ->count();

      $differenceDeadLeads = $currentMonthDeadLeads - $previousMonthDeadLeads;

      // Calculating %
      if ($previousMonthDeadLeads > 0) {
        $percentageDeadLeads = ($differenceDeadLeads / $previousMonthDeadLeads) * 100;

        if ($percentageDeadLeads < 0) {
          $percentageDeadLeads = 0;
        }

        if ($currentMonthDeadLeads == 0) {
          $percentageDeadLeads = 0;
        }
      } else {
        $percentageDeadLeads = $currentMonthDeadLeads > 0 ? 100 : 0;
      }

      // ----------------------------------------------------------------------------------

      // Convert Customer
      $CurrentMonthCustomerConvert = LeadModel::where('status', 4)
        ->where('internal_status', 0)
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $currentMonth)
        ->count();

      $previousMonthCustomerConvert = LeadModel::where('status', 4)
        ->where('internal_status', 0)
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $previousMonth)
        ->count();

      $differenceCustomerConvert = $CurrentMonthCustomerConvert - $previousMonthCustomerConvert;

      // Calculating %
      if ($previousMonthCustomerConvert > 0) {
        $percentageCustomerConvert = ($differenceCustomerConvert / $previousMonthCustomerConvert) * 100;

        if ($percentageCustomerConvert < 0) {
          $percentageCustomerConvert = 0;
        }

        if ($CurrentMonthCustomerConvert == 0) {
          $percentageCustomerConvert = 0;
        }
      } else {
        $percentageCustomerConvert = $CurrentMonthCustomerConvert > 0 ? 100 : 0;
      }

      // ---------------------------------------------------------------------------------------

      // ODC - On Day Conversion
      $odc_count = DB::table('et_lead')
        ->leftJoin('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->where('et_lead.status', 4)
        ->whereDate('et_customer.created_at', $today)
        ->whereDate('et_lead.registered_date', $today)
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->count();

      // --------------------------------------------------------------------------------------

      // MC - Month Conversion
      $mc_count = DB::table('et_lead')
        ->leftJoin('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->where('et_lead.status', 4)
        ->whereDate('et_customer.created_at', $today)
        ->whereMonth('et_lead.registered_date', $currentMonth)
        ->whereYear('et_lead.registered_date', $currentYear)
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->count();

      // ------------------------------------------------------------------------------------

      // OMC - Old Month Conversion
      $omc_count = DB::table('et_lead')
        ->join('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->where('et_customer.branch_id', $user->branch_id)
        ->whereYear('et_lead.registered_date', $currentYear)
        ->whereMonth('et_lead.registered_date', '<', $currentMonth)
        ->whereMonth('et_customer.created_at', $currentMonth)
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->count();

      // -------------------------------------------------------------------------------------

      // Today Conversion
      $todayConversion = DB::table('et_lead')
        ->leftJoin('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->where('et_lead.status', 4)
        ->whereDate('et_customer.created_at', $today)
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->count();

      // --------------------------------------------------------------------------------------

      // Month Conversion
      $currentMonthConversion = DB::table('et_lead')
        ->leftJoin('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->where('et_customer.status', 0)
        // ->where('et_lead.status', 4)
        ->whereYear('et_customer.created_at', $currentYear)
        ->whereMonth('et_customer.created_at', $currentMonth)
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->count();

      // ---------------------------------------------------------------------------------------

      // Walk In Count Today
      $todayWalkInCount = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('created_at', $today)
        ->count();

      $yesterdayWalkInCount = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('created_at', $yesterday)
        ->count();

      $differenceWalkInCountToday = $todayWalkInCount - $yesterdayWalkInCount;

      if ($yesterdayWalkInCount > 0) {
        $percentageWalkInCountToday = ($differenceWalkInCountToday / $yesterdayWalkInCount) * 100;

        if ($percentageWalkInCountToday < 0) {
          $percentageWalkInCountToday = 0;
        }

        if ($todayWalkInCount == 0) {
          $percentageWalkInCountToday = 0;
        }
      } else {
        $percentageWalkInCountToday = $todayWalkInCount > 0 ? 100 : 0;
      }

      // -------------------------------------------------------------------------------------------

      // Walk In Count This Month
      $currentMonthWalkInCount = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereYear('created_at', $currentYear)
        ->whereMonth('created_at', $currentMonth)
        ->count();

      $previousMonthWalkInCount = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('created_at', $currentYear)
        ->whereMonth('created_at', $previousMonth)
        ->count();

      $differenceWalkInCountCurrentMonth = $currentMonthWalkInCount - $previousMonthWalkInCount;

      if ($previousMonthWalkInCount > 0) {
        $percentageWalkInCountCurrentMonth = ($differenceWalkInCountCurrentMonth / $previousMonthWalkInCount) * 100;

        if ($percentageWalkInCountCurrentMonth < 0) {
          $percentageWalkInCountCurrentMonth = 0;
        }

        if ($currentMonthWalkInCount == 0) {
          $percentageWalkInCountCurrentMonth = 0;
        }
      } else {
        $percentageWalkInCountCurrentMonth = $currentMonthWalkInCount > 0 ? 100 : 0;
      }

      // --------------------------------------------------------------------------------------

      // Appointments Today
      $appointmentsToday = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('created_at', $today)
        ->count();

      $yesterdayAppointments = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('created_at', $yesterday)
        ->count();

      $differenceAppointmentsToday = $appointmentsToday - $yesterdayAppointments;


      if ($yesterdayAppointments > 0) {
        $percentageAppointmentsToday = ($differenceAppointmentsToday / $yesterdayAppointments) * 100;

        if ($percentageAppointmentsToday < 0) {
          $percentageAppointmentsToday = 0;
        }

        if ($appointmentsToday == 0) {
          $percentageAppointmentsToday = 0;
        }
      } else {
        $percentageAppointmentsToday = $appointmentsToday > 0 ? 100 : 0;
      }

      // ---------------------------------------------------------------------------------------

      // Appointments This Month
      $appointmentsCurrentMonth = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereMonth('created_at', $currentMonth)
        ->whereYear('created_at', $currentYear)
        ->count();

      $previousMonthAppointments = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereMonth('created_at', $previousMonth)
        ->whereYear('created_at', $currentYear)
        ->count();

      $differenceAppointmentsCurrentMonth = $appointmentsCurrentMonth - $previousMonthAppointments;

      if ($previousMonthAppointments > 0) {
        $percentageAppointmentsCurrentMonth = ($differenceAppointmentsCurrentMonth / $previousMonthAppointments) * 100;

        if ($percentageAppointmentsCurrentMonth < 0) {
          $percentageAppointmentsCurrentMonth = 0;
        }

        if ($appointmentsCurrentMonth == 0) {
          $percentageAppointmentsCurrentMonth = 0;
        }
      } else {
        $percentageAppointmentsCurrentMonth = $appointmentsCurrentMonth > 0 ? 100 : 0;
      }

      // -----------------------------------------------------------------------------------------------------------------------

      // FollowUps Today
      $todayFollowUps = DB::table('et_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('appointment_date', $today)
        ->count();

      $yesterdayFollowUps = DB::table('et_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('appointment_date', $yesterday)
        ->count();

      $differenceFollowUpsToday = $todayFollowUps - $yesterdayFollowUps;


      if ($yesterdayFollowUps > 0) {
        $percentageFollowUpdsToday = ($differenceFollowUpsToday / $yesterdayFollowUps) * 100;

        if ($percentageFollowUpdsToday < 0) {
          $percentageFollowUpdsToday = 0;
        }

        if ($todayFollowUps == 0) {
          $percentageFollowUpdsToday = 0;
        }
      } else {
        $percentageFollowUpdsToday = $todayFollowUps > 0 ? 100 : 0;
      }

      // ---------------------------------------------------------------------------------------------

      // FollowUps This Month
      $currentMonthFollowUps = DB::table('et_appointment')
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('created_at', $currentYear)
        ->whereMonth('created_at', $currentMonth)
        ->count();

      $previousMonthFollowUps = DB::table('et_appointment')
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('created_at', $currentYear)
        ->whereMonth('created_at', $previousMonth)
        ->count();

      $differenceFollowUpsCurrentMonth = $currentMonthFollowUps - $previousMonthFollowUps;


      if ($previousMonthFollowUps > 0) {
        $percentageFollowUpsCurrentMonth = ($differenceFollowUpsCurrentMonth / $previousMonthFollowUps) * 100;

        if ($percentageFollowUpsCurrentMonth < 0) {
          $percentageFollowUpsCurrentMonth = 0;
        }

        if ($currentMonthFollowUps == 0) {
          $percentageFollowUpsCurrentMonth = 0;
        }
      } else {
        $percentageFollowUpsCurrentMonth = $currentMonthFollowUps > 0 ? 100 : 0;
      }

      // ----------------------------------------------------------------------------------------------------------------------

      // Outgoing Calls Today
      $todayOutGoingCalls = DB::table('et_call_tracker')
        ->where('branch_id', $user->branch_id)
        ->where('branch_staff_id', $user->user_id)
        ->where('call_status', 0)
        ->whereDate('call_start_date', $today)
        ->count();


      $yesterdayOutgoingCalls = DB::table('et_call_tracker')
        ->where('branch_id', $user->branch_id)
        ->where('branch_staff_id', $user->user_id)
        ->where('call_status', 0)
        ->whereDate('call_start_date', $yesterday)
        ->count();

      $differenceOutgoingCallsToday = $todayOutGoingCalls - $yesterdayOutgoingCalls;


      if ($yesterdayOutgoingCalls > 0) {
        $percentageOutGoingCallsToday = ($differenceOutgoingCallsToday / $yesterdayOutgoingCalls) * 100;

        if ($percentageOutGoingCallsToday < 0) {
          $percentageOutGoingCallsToday = 0;
        }

        if ($todayOutGoingCalls == 0) {
          $percentageOutGoingCallsToday = 0;
        }
      } else {
        $percentageOutGoingCallsToday = $todayOutGoingCalls > 0 ? 100 : 0;
      }

      // -------------------------------------------------------------------------------------

      // Outgoing Calls This Month
      $currentMonthOutgoingCalls = DB::table('et_call_tracker')
        ->where('branch_staff_id', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->where('call_status', 0)
        ->whereYear('call_start_date', $currentYear)
        ->whereMonth('call_start_date', $currentMonth)
        ->count();

      $previousMonthOutgoingCallsSelf = DB::table('et_call_tracker')
        ->where('branch_staff_id', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->where('call_status', 0)
        ->whereYear('call_start_date', $currentYear)
        ->whereMonth('call_start_date', $currentMonth)
        ->count();

      $differenceOutGoingCallsCurrentMonth = $currentMonthOutgoingCalls - $previousMonthOutgoingCallsSelf;


      if ($previousMonthOutgoingCallsSelf > 0) {
        $percentageOutgoingCallsCurrentMonth = ($differenceOutGoingCallsCurrentMonth / $previousMonthOutgoingCallsSelf) * 100;

        if ($percentageOutgoingCallsCurrentMonth < 0) {
          $percentageOutgoingCallsCurrentMonth = 0;
        }

        if ($currentMonthOutgoingCalls == 0) {
          $percentageOutgoingCallsCurrentMonth = 0;
        }
      } else {
        $percentageOutgoingCallsCurrentMonth = $currentMonthOutgoingCalls > 0 ? 100 : 0;
      }

      // ---------------------------------------------------------------------------------------------

      // CR - Conversion Rate
      $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->whereNotIn('et_lead.status', [2, 6])
        ->where('et_lead.spam_verified', 0)
        ->where('et_lead.drop_verified', 0)
        ->where('et_lead.internal_status', 0)
        ->count();

      $customerConvertCount = DB::table('et_customer')->select('et_customer.sno')->where('et_customer.status', 0)
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_customer.branch_id', $user->branch_id)
        ->where('et_customer.status', 0)
        ->where('et_lead.created_by', $user->user_id)
        ->whereDate('et_customer.created_at', $today)
        ->count();


      // customer ratio
      $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
      $convertion_rate = number_format($convertion_rate, 2);

      // CR - Conversion Rate Month
      $customerConvertCountMonth = DB::table('et_customer')->select('et_customer.sno')->where('et_customer.status', 0)
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_lead.status', 4)
        ->where('et_customer.branch_id', $user->branch_id)
        ->where('et_customer.status', 0)
        ->where('et_lead.created_by', $user->user_id)
        ->whereYear('et_customer.created_at', $currentYear)
        ->whereMonth('et_customer.created_at', $currentMonth)
        ->count();

      // customer ratio
      $convertion_rate_month = $allLeadCount > 0 ? ($customerConvertCountMonth / $allLeadCount) * 100 : 0;
      $convertion_rate_month = number_format($convertion_rate_month, 2);

      // ABV and ACV Today
      $total_payment             = 0;
      $total_paid_payment        = 0;
      $averageBusinessValue      = 0;
      $averageCollectionValue    = 0;
      $averageBusinessValueMonth      = 0;
      $averageCollectionValueMonth    = 0;
      $totalAllPayment             = 0;
      $totalAllPaidPayment        = 0;

      if ($customerConvertCount > 0) {
        $currentMonthCustomer = DB::table('et_customer')->select('et_customer.sno', 'et_customer.proposal_ids')->where('et_customer.status', 0)
          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
          ->where('et_customer.branch_id', $user->branch_id)
          ->where('et_customer.status', 0)
          ->where('et_lead.created_by', $user->user_id)
          ->whereDate('et_customer.created_at', $today)
          ->get();

        if ($currentMonthCustomer->isNotEmpty()) {
          foreach ($currentMonthCustomer as $customer) {
            $proposal_ids = json_decode($customer->proposal_ids);
            $total_paid_payment = DB::table('et_proposal_pay_slot')
              ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
              ->where('status', 0)
              ->sum('paidAmount');
            // $total_payment=0;
            // $total_payment += $payment;


            $total_payment = DB::table('et_proposal')
              ->whereIn('sno', $proposal_ids)
              ->where('status', 0)
              ->sum('total_amount');

            // if ($latestTraining) {
            //     $total_payment += $latestTraining->overall_fees;
            // }
            // $paid_payment=0;
            // $paid_payment = DB::table('et_training')->select('et_training.course_id', 'et_training.sno','et_training.customer_id')
            //                   ->where('et_training.customer_id', $customer->sno)
            //                   ->sum('et_training.paid_amount');

            // $total_paid_payment += $paid_payment;

          }
        }


        // average 
        $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
        $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;
        $totalAllPayment += $total_payment;
        $totalAllPaidPayment += $total_paid_payment;
      }

      // ABV and ACV this month
      if ($customerConvertCountMonth > 0) {
        $currentMonthCustomer = DB::table('et_customer')->select('et_customer.sno', 'et_customer.proposal_ids')->where('et_customer.status', 0)
          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
          ->where('et_customer.branch_id', $user->branch_id)
          ->where('et_customer.status', 0)
          ->where('et_lead.created_by', $user->user_id)
          ->whereYear('et_customer.created_at', $currentYear)
          ->whereMonth('et_customer.created_at', $currentMonth)
          ->get();

        if ($currentMonthCustomer->isNotEmpty()) {
          foreach ($currentMonthCustomer as $customer) {
            $proposal_ids = json_decode($customer->proposal_ids);
            $total_paid_payment_month = DB::table('et_proposal_pay_slot')
              ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
              ->where('status', 0)
              ->sum('paidAmount');
            // $total_payment=0;
            // $total_payment += $payment;


            $total_payment_month = DB::table('et_proposal')
              ->whereIn('sno', $proposal_ids)
              ->where('status', 0)
              ->sum('total_amount');

            // if ($latestTraining) {
            //     $total_payment += $latestTraining->overall_fees;
            // }
            // $paid_payment=0;
            // $paid_payment = DB::table('et_training')->select('et_training.course_id', 'et_training.sno','et_training.customer_id')
            //                   ->where('et_training.customer_id', $customer->sno)
            //                   ->sum('et_training.paid_amount');

            // $total_paid_payment += $paid_payment;

          }
        }


        // average 
        $averageBusinessValueMonth   = $customerConvertCountMonth > 0 ? $total_payment_month / $customerConvertCountMonth : 0;
        $averageCollectionValueMonth = $customerConvertCountMonth > 0 ? $total_paid_payment_month / $customerConvertCountMonth : 0;
        $totalAllPayment += $total_payment_month;
        $totalAllPaidPayment += $total_paid_payment_month;
      }

      return view('content.dashboard.sales_executive_dashboards', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'role_permission' => $role_permission,
        'top_5_sales_persons' => $top_5_sales_persons,
        'lead_sources' => $lead_sources,
        'filteredAppointments' => $filteredAppointments,
        'appointmentFilter' => $appointmentFilter,
        'walkInCount' => $walkInCount,
        'currentMonthTotalLeads' => $currentMonthTotalLeads,
        'differenceTotalLeads' => $differenceTotalLeads,
        'percentageTotalLeads' => $percentageTotalLeads,
        'currentMonthActiveLeads' => $currentMonthActiveLeads,
        'differenceActiveLeads' => $differenceActiveLeads,
        'percentageActiveLeads' => $percentageActiveLeads,
        'currentMonthSpamLeads' => $currentMonthSpamLeads,
        'differenceSpamLeads' => $differenceSpamLeads,
        'percentageSpamLeads' => $percentageSpamLeads,
        'currentMonthDeadLeads' => $currentMonthDeadLeads,
        'differenceDeadLeads' => $differenceDeadLeads,
        'percentageDeadLeads' => $percentageDeadLeads,
        'currentMonthCustomerConvert' => $CurrentMonthCustomerConvert,
        'differenceCustomerConvert' => $differenceCustomerConvert,
        'percentageCustomerConvert' => $percentageCustomerConvert,
        'odc_count' => $odc_count,
        'mc_count' => $mc_count,
        'omc_count' => $omc_count,
        'todayConversion' => $todayConversion,
        'currentMonthConversion' => $currentMonthConversion,
        'todayWalkInCount' => $todayWalkInCount,
        'differenceWalkInCountToday' => $differenceWalkInCountToday,
        'percentageWalkInCountToday' => $percentageWalkInCountToday,
        'currentMonthWalkInCount' => $currentMonthWalkInCount,
        'differenceWalkInCountCurrentMonth' => $differenceWalkInCountCurrentMonth,
        'percentageWalkInCountCurrentMonth' => $percentageWalkInCountCurrentMonth,
        'appointmentsToday' => $appointmentsToday,
        'differenceAppointmentsToday' => $differenceAppointmentsToday,
        'percentageAppointmentsToday' => $percentageAppointmentsToday,
        'appointmentsCurrentMonth' => $appointmentsCurrentMonth,
        'differenceAppointmentsCurrentMonth' => $differenceAppointmentsCurrentMonth,
        'percentageAppointmentsCurrentMonth' => $percentageAppointmentsCurrentMonth,
        'todayFollowUps' => $todayFollowUps,
        'differenceFollowUpsToday' => $differenceFollowUpsToday,
        'percentageFollowUpdsToday' => $percentageFollowUpdsToday,
        'currentMonthFollowUps' => $currentMonthFollowUps,
        'differenceFollowUpsCurrentMonth' => $differenceFollowUpsCurrentMonth,
        'percentageFollowUpsCurrentMonth' => $percentageFollowUpsCurrentMonth,
        'todayOutGoingCalls' => $todayOutGoingCalls,
        'differenceOutgoingCallsToday' => $differenceOutgoingCallsToday,
        'percentageOutGoingCallsToday' => $percentageOutGoingCallsToday,
        'currentMonthOutgoingCalls' => $currentMonthOutgoingCalls,
        'differenceOutGoingCallsCurrentMonth' => $differenceOutGoingCallsCurrentMonth,
        'percentageOutgoingCallsCurrentMonth' => $percentageOutgoingCallsCurrentMonth,
        'convertion_rate' => $convertion_rate,
        'convertion_rate_month' => $convertion_rate_month,
        'averageBusinessValue' => $averageBusinessValue,
        'averageCollectionValue' => $averageCollectionValue,
        'averageBusinessValueMonth' => $averageBusinessValueMonth,
        'averageCollectionValueMonth' => $averageCollectionValueMonth
      ]);
    } elseif ($user->role_id == 12) {

      // Sales TL My Self

      // Top 5 Sales Person
      $top_5_sales_persons = StaffModel::where('et_staff.branch_id', $user->branch_id)
        ->select(
          'et_staff.staff_name',
          'et_staff.nick_name',
          'et_staff.staff_image',
          DB::raw('COUNT(et_lead.created_by) as total_leads')
        )
        ->leftJoin('et_lead', 'et_lead.created_by', '=', 'et_staff.sno')
        ->whereMonth('et_lead.registered_date', date('m'))
        ->whereYear('et_lead.registered_date', date('Y'))
        ->where('et_lead.status', 4)
        ->where('et_staff.role_id', '!=', 12)
        ->groupBy('et_staff.staff_name', 'et_staff.nick_name', 'et_staff.staff_image')
        ->orderBy('total_leads', 'desc')
        ->limit(5)
        ->get();

      // -----------------------------------------------------------------------------------------------------

      // Lead Source

      // 1. Calculate total leads count (for same filters)
      $total_leads_overall = LeadModel::whereMonth('registered_date', date('m'))
        ->whereYear('registered_date', date('Y'))
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->count();

      // return $total_leads_overall;

      // 2. Get lead sources with counts
      $lead_sources = LeadSourceModel::where('et_lead_source.branch_id', $user->branch_id)
        ->select(
          'lead_source_name',
          DB::raw('COUNT(et_lead.lead_source_id) as total_leads')
        )
        ->leftJoin('et_lead', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
        ->where('et_lead_source.status', 0)
        ->whereMonth('et_lead.registered_date', date('m'))
        ->whereYear('et_lead.registered_date', date('Y'))
        ->where('et_lead.created_by', $user->user_id)
        ->groupBy('et_lead_source.lead_source_name')
        ->orderBy('total_leads', 'desc')
        ->get();

      // 3. Calculate percentage for each lead source
      foreach ($lead_sources as $lead_source) {
        $lead_source->percentage = $total_leads_overall > 0 ? round(($lead_source->total_leads / $total_leads_overall) * 100) : 0;
      }

      // -------------------------------------------------------------------------------------

      // Follow Up Schedule
      $todayAppointments = DB::table('et_appointment')
        ->select('et_appointment.*', 'et_lead.lead_name')
        ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
        ->whereDate('et_appointment.appointment_date', date('Y-m-d'))
        ->where('et_appointment.branch_id', $user->branch_id)
        ->where('et_appointment.created_by', $user->user_id)
        ->orderBy('et_appointment.lead_id')
        ->orderBy('et_appointment.appointment_date', 'desc')
        ->get();

      $filteredAppointments = collect();
      $seenLeads = [];

      foreach ($todayAppointments as $appointment) {
        $leadId = $appointment->lead_id;

        // Skip if this lead already has a higher-priority status recorded
        if (isset($seenLeads[$leadId])) continue;

        // Mark status flags
        $isCompleted = $appointment->status == 4;
        $isRescheduled = $appointment->status == 5;
        $isScheduled = $appointment->status == 1;

        if ($isCompleted) {
          $appointment->display_status = 'Completed';
          $seenLeads[$leadId] = true;
          $filteredAppointments->push($appointment);
        } elseif ($isRescheduled) {
          $appointment->display_status = 'Rescheduled';
          $seenLeads[$leadId] = true;
          $filteredAppointments->push($appointment);
        } elseif ($isScheduled) {
          $appointment->display_status = 'Scheduled';
          $seenLeads[$leadId] = true;
          $filteredAppointments->push($appointment);
        }
      }

      // ---------------------------------------------------------------------------------------

      // Appointment Schedule
      $appointmentToday = DB::table('et_lead_appointment')
        ->select('et_lead_appointment.*', 'et_lead.lead_name')
        ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_lead_appointment.lead_id')
        ->whereDate('et_lead_appointment.appointment_date', date('Y-m-d'))
        ->where('et_lead_appointment.branch_id', $user->branch_id)
        ->where('et_lead_appointment.created_by', $user->user_id)
        ->orderBy('et_lead_appointment.lead_id')
        ->orderBy('et_lead_appointment.appointment_date', 'asc')
        ->get();

      $appointmentFilter = collect();
      $seenLeads = [];

      foreach ($appointmentToday as $app) {
        $lead_id = $app->lead_id;

        if (isset($seenLeads[$lead_id])) continue;

        $appCompleted = $app->appointment_status == 2;
        $appRescheduled = $app->appointment_status == 4;
        $appScheduled = $app->appointment_status == 1;

        if ($appCompleted) {
          $app->app_status = 'Completed';
          $seenLeads[$lead_id] = true;
          $appointmentFilter->push($app);
        } elseif ($appRescheduled) {
          $app->app_status = 'Rescheduled';
          $seenLeads[$lead_id] = true;
          $appointmentFilter->push($app);
        } elseif ($appScheduled) {
          $app->app_status = 'Scheduled';
          $seenLeads[$lead_id] = true;
          $appointmentFilter->push($app);
        }
      }

      // --------------------------------------------------------------------------------

      // Walk In Count
      $walkInCount = $appointmentFilter->where('appointment_category', 'Walk-in')->count();

      // ----------------------------------------------------------------------------------------------------

      $today = Carbon::now()->toDateString();
      $yesterday = Carbon::yesterday();

      $currentYear = Carbon::now()->year;
      $currentMonth = Carbon::now()->month;

      $previousMonthDate = Carbon::now()->subMonth();
      $previousMonth = $previousMonthDate->month;

      // Total Leads
      $currentMonthTotalLeadsSelf = LeadModel::where('branch_id', $user->branch_id)
        ->whereNotIn('status', [2, 6])
        ->where('internal_status', 0)
        ->where('spam_verified', 0)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $currentMonth)
        ->where('created_by', $user->user_id)
        ->count();

      $previousMonthTotalLeadsSelf = LeadModel::where('branch_id', $user->branch_id)
        ->whereNotIn('status', [2, 6])
        ->where('spam_verified', 0)
        ->where('internal_status', 0)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $previousMonth)
        ->count();


      $differenceTotalLeadsSelf = $currentMonthTotalLeadsSelf - $previousMonthTotalLeadsSelf;

      // Calculating Percentage (%)
      if ($previousMonthTotalLeadsSelf > 0) {
        $percentageTotalLeadsSelf = ($differenceTotalLeadsSelf / $previousMonthTotalLeadsSelf) * 100;

        if ($percentageTotalLeadsSelf < 0) {
          $percentageTotalLeadsSelf = 0;
        }

        if ($currentMonthTotalLeadsSelf == 0) {
          $percentageTotalLeadsSelf = 0;
        }
      } else {
        $percentageTotalLeadsSelf = $currentMonthTotalLeadsSelf > 0 ? 100 : 0;
      }

      // -------------------------------------------------------------------------------------------

      // Active Leads
      $currentMonthActiveLeadsSelf = LeadModel::where('status', 0)
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->whereNotIn('status', [2, 6])
        ->where('internal_status', 0)
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $currentMonth)
        ->count();

      $previousMonthActiveLeadsSelf = LeadModel::where('status', 0)
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->whereNotIn('status', [2, 6])
        ->where('internal_status', 0)
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $previousMonth)
        ->count();

      $differenceActiveLeadsSelf = $currentMonthActiveLeadsSelf - $previousMonthActiveLeadsSelf;

      // Calculating %
      if ($previousMonthActiveLeadsSelf > 0) {
        $percentageActiveLeadsSelf = ($differenceActiveLeadsSelf / $previousMonthActiveLeadsSelf) * 100;

        if ($percentageActiveLeadsSelf < 0) {
          $percentageActiveLeadsSelf = 0;
        }

        if ($currentMonthActiveLeadsSelf == 0) {
          $percentageActiveLeadsSelf = 0;
        }
      } else {
        $percentageActiveLeadsSelf = $currentMonthActiveLeadsSelf > 0 ? 100 : 0;
      }

      // -----------------------------------------------------------------------------------------------------------------

      // Spam Leads
      $currentMonthSpamLeadsSelf = LeadModel::where('spam_verified', 1)
        ->where('internal_status', 0)
        ->where('drop_verified', 0)
        ->where('status', 7)
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereMonth('registered_date', $currentMonth)
        ->whereYear('registered_date', $currentYear)
        ->count();

      $perviousMonthSpamLeadsSelf = LeadModel::where('spam_verified', 1)
        ->where('internal_status', 0)
        ->where('drop_verified', 0)
        ->where('status', 7)
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $previousMonth)
        ->count();

      $differenceSpamLeadsSelf = $currentMonthSpamLeadsSelf - $perviousMonthSpamLeadsSelf;

      // Calculating %
      if ($perviousMonthSpamLeadsSelf > 0) {
        $percentageSpamLeadsSelf = ($differenceSpamLeadsSelf / $perviousMonthSpamLeadsSelf) * 100;

        if ($percentageSpamLeadsSelf < 0) {
          $percentageSpamLeadsSelf = 0;
        }

        if ($currentMonthSpamLeadsSelf == 0) {
          $percentageSpamLeadsSelf = 0;
        }
      } else {
        $percentageSpamLeadsSelf = $currentMonthSpamLeadsSelf > 0 ? 100 : 0;
      }

      // -----------------------------------------------------------------------------------------------

      // Dead Leads
      $currentMonthDeadLeadsSelf = LeadModel::where('drop_verified', 1)
        ->where('spam_verified', 0)
        ->where('internal_status', 0)
        ->whereNotIn('status', [2, 6])
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $currentMonth)
        ->count();

      $previousMonthDeadLeadsSelf = LeadModel::where('drop_verified', 1)
        ->whereNotIn('status', [2, 6])
        ->where('spam_verified', 0)
        ->where('internal_status', 0)
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $previousMonth)
        ->count();

      $differenceDeadLeadsSelf = $currentMonthDeadLeadsSelf - $previousMonthDeadLeadsSelf;

      // Calculating %
      if ($previousMonthDeadLeadsSelf > 0) {
        $percentageDeadLeadsSelf = ($differenceDeadLeadsSelf / $previousMonthDeadLeadsSelf) * 100;

        if ($percentageDeadLeadsSelf < 0) {
          $percentageDeadLeadsSelf = 0;
        }

        if ($currentMonthDeadLeadsSelf == 0) {
          $percentageDeadLeadsSelf = 0;
        }
      } else {
        $percentageDeadLeadsSelf = $currentMonthDeadLeadsSelf > 0 ? 100 : 0;
      }

      // ---------------------------------------------------------------------------------------

      // Convert Customer
      $CurrentMonthCustomerConvertSelf = LeadModel::where('status', 4)
        ->where('internal_status', 0)
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $currentMonth)
        ->count();

      $previousMonthCustomerConvertSelf = LeadModel::where('status', 4)
        ->where('internal_status', 0)
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('registered_date', $currentYear)
        ->whereMonth('registered_date', $previousMonth)
        ->count();

      $differenceCustomerConvertSelf = $CurrentMonthCustomerConvertSelf - $previousMonthCustomerConvertSelf;

      // Calculating %
      if ($previousMonthCustomerConvertSelf > 0) {
        $percentageCustomerConvertSelf = ($differenceCustomerConvertSelf / $previousMonthCustomerConvertSelf) * 100;

        if ($percentageCustomerConvertSelf < 0) {
          $percentageCustomerConvertSelf = 0;
        }

        if ($CurrentMonthCustomerConvertSelf == 0) {
          $percentageCustomerConvertSelf = 0;
        }
      } else {
        $percentageCustomerConvertSelf = $CurrentMonthCustomerConvertSelf > 0 ? 100 : 0;
      }

      // -----------------------------------------------------------------------------------------------------------------------------

      // ODC - On Day Conversion
      $odc_count = DB::table('et_lead')
        ->leftJoin('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->where('et_lead.status', 4)
        ->whereDate('et_customer.created_at', $today)
        ->whereDate('et_lead.registered_date', $today)
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->count();

      // --------------------------------------------------------------------------------------

      // MC - Month Conversion
      $mc_count = DB::table('et_lead')
        ->leftJoin('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->where('et_lead.status', 4)
        ->whereDate('et_customer.created_at', $today)
        ->whereMonth('et_lead.registered_date', $currentMonth)
        ->whereYear('et_lead.registered_date', $currentYear)
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->count();

      // ------------------------------------------------------------------------------------

      // OMC - Old Month Conversion
      $omc_count = DB::table('et_lead')
        ->join('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->where('et_customer.branch_id', $user->branch_id)
        ->whereYear('et_lead.registered_date', $currentYear)
        ->whereMonth('et_lead.registered_date', '<', $currentMonth)
        ->whereMonth('et_customer.created_at', $currentMonth)
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->count();

      // -------------------------------------------------------------------------------------

      // Today Conversion
      $todayConversionSelf = DB::table('et_lead')
        ->leftJoin('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->where('et_lead.status', 4)
        ->whereDate('et_customer.created_at', $today)
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->count();

      // --------------------------------------------------------------------------------------

      // Month Conversion
      $currentMonthConversionSelf = DB::table('et_lead')
        ->leftJoin('et_customer', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->where('et_customer.status', 0)
        // ->where('et_lead.status', 4)
        ->whereYear('et_customer.created_at', $currentYear)
        ->whereMonth('et_customer.created_at', $currentMonth)
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->count();

      // ----------------------------------------------------------------------------------------------

      // Walk In Count Today
      $todayWalkInCountSelf = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('created_at', $today)
        ->count();

      $yesterdayWalkInCountSelf = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('created_at', $yesterday)
        ->count();

      $differenceWalkInCountTodaySelf = $todayWalkInCountSelf - $yesterdayWalkInCountSelf;

      if ($yesterdayWalkInCountSelf > 0) {
        $percentageWalkInCountTodaySelf = ($differenceWalkInCountTodaySelf / $yesterdayWalkInCountSelf) * 100;

        if ($percentageWalkInCountTodaySelf < 0) {
          $percentageWalkInCountTodaySelf = 0;
        }

        if ($todayWalkInCountSelf == 0) {
          $percentageWalkInCountTodaySelf = 0;
        }
      } else {
        $percentageWalkInCountTodaySelf = $todayWalkInCountSelf > 0 ? 100 : 0;
      }

      // -------------------------------------------------------------------------------------

      // Walk In Count This Month
      $currentMonthWalkInCountSelf = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereYear('created_at', $currentYear)
        ->whereMonth('created_at', $currentMonth)
        ->count();

      $previousMonthWalkInCountSelf = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('created_at', $currentYear)
        ->whereMonth('created_at', $previousMonth)
        ->count();

      $differenceWalkInCountCurrentMonthSelf = $currentMonthWalkInCountSelf - $previousMonthWalkInCountSelf;

      if ($previousMonthWalkInCountSelf > 0) {
        $percentageWalkInCountCurrentMonthSelf = ($differenceWalkInCountCurrentMonthSelf / $previousMonthWalkInCountSelf) * 100;

        if ($percentageWalkInCountCurrentMonthSelf < 0) {
          $percentageWalkInCountCurrentMonthSelf = 0;
        }

        if ($currentMonthWalkInCountSelf == 0) {
          $percentageWalkInCountCurrentMonthSelf = 0;
        }
      } else {
        $percentageWalkInCountCurrentMonthSelf = $currentMonthWalkInCountSelf > 0 ? 100 : 0;
      }

      // ---------------------------------------------------------------------------------------------

      // Appointments Today
      $appointmentsTodaySelf = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('created_at', $today)
        ->count();

      $yesterdayAppointmentsSelf = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('created_at', $yesterday)
        ->count();

      $differenceAppointmentsTodaySelf = $appointmentsTodaySelf - $yesterdayAppointmentsSelf;


      if ($yesterdayAppointmentsSelf > 0) {
        $percentageAppointmentsTodaySelf = ($differenceAppointmentsTodaySelf / $yesterdayAppointmentsSelf) * 100;

        if ($percentageAppointmentsTodaySelf < 0) {
          $percentageAppointmentsTodaySelf = 0;
        }

        if ($appointmentsTodaySelf == 0) {
          $percentageAppointmentsTodaySelf = 0;
        }
      } else {
        $percentageAppointmentsTodaySelf = $appointmentsTodaySelf > 0 ? 100 : 0;
      }

      // ------------------------------------------------------------------------------------------

      // Appointments This Month
      $appointmentsCurrentMonthSelf = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereMonth('created_at', $currentMonth)
        ->whereYear('created_at', $currentYear)
        ->count();

      $previousMonthAppointmentsSelf = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereMonth('created_at', $previousMonth)
        ->whereYear('created_at', $currentYear)
        ->count();

      $differenceAppointmentsCurrentMonthSelf = $appointmentsCurrentMonthSelf - $previousMonthAppointmentsSelf;

      if ($previousMonthAppointmentsSelf > 0) {
        $percentageAppointmentsCurrentMonthSelf = ($differenceAppointmentsCurrentMonthSelf / $previousMonthAppointmentsSelf) * 100;

        if ($percentageAppointmentsCurrentMonthSelf < 0) {
          $percentageAppointmentsCurrentMonthSelf = 0;
        }

        if ($appointmentsCurrentMonthSelf == 0) {
          $percentageAppointmentsCurrentMonthSelf = 0;
        }
      } else {
        $percentageAppointmentsCurrentMonthSelf = $appointmentsCurrentMonthSelf > 0 ? 100 : 0;
      }

      // --------------------------------------------------------------------------------

      // FollowUps Today
      $todayFollowUpsSelf = DB::table('et_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('appointment_date', $today)
        ->count();

      $yesterdayFollowUpsSelf = DB::table('et_appointment')
        ->where('branch_id', $user->branch_id)
        ->where('created_by', $user->user_id)
        ->whereDate('appointment_date', $yesterday)
        ->count();

      $differenceFollowUpsTodaySelf = $todayFollowUpsSelf - $yesterdayFollowUpsSelf;


      if ($yesterdayFollowUpsSelf > 0) {
        $percentageFollowUpdsTodaySelf = ($differenceFollowUpsTodaySelf / $yesterdayFollowUpsSelf) * 100;

        if ($percentageFollowUpdsTodaySelf < 0) {
          $percentageFollowUpdsTodaySelf = 0;
        }

        if ($todayFollowUpsSelf == 0) {
          $percentageFollowUpdsTodaySelf = 0;
        }
      } else {
        $percentageFollowUpdsTodaySelf = $todayFollowUpsSelf > 0 ? 100 : 0;
      }

      // ----------------------------------------------------------------------------

      // FollowUps This Month
      $currentMonthFollowUpsSelf = DB::table('et_appointment')
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('created_at', $currentYear)
        ->whereMonth('created_at', $currentMonth)
        ->count();

      $previousMonthFollowUpsSelf = DB::table('et_appointment')
        ->where('created_by', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->whereYear('created_at', $currentYear)
        ->whereMonth('created_at', $previousMonth)
        ->count();

      $differenceFollowUpsCurrentMonthSelf = $currentMonthFollowUpsSelf - $previousMonthFollowUpsSelf;


      if ($previousMonthFollowUpsSelf > 0) {
        $percentageFollowUpsCurrentMonthSelf = ($differenceFollowUpsCurrentMonthSelf / $previousMonthFollowUpsSelf) * 100;

        if ($percentageFollowUpsCurrentMonthSelf < 0) {
          $percentageFollowUpsCurrentMonthSelf = 0;
        }

        if ($currentMonthFollowUpsSelf == 0) {
          $percentageFollowUpsCurrentMonthSelf = 0;
        }
      } else {
        $percentageFollowUpsCurrentMonthSelf = $currentMonthFollowUpsSelf > 0 ? 100 : 0;
      }

      // ------------------------------------------------------------------------------------

      // Outgoing Calls Today
      $todayOutGoingCallsSelf = DB::table('et_call_tracker')
        ->where('branch_id', $user->branch_id)
        ->where('branch_staff_id', $user->user_id)
        ->where('call_status', 0)
        ->whereDate('call_start_date', $today)
        ->count();

      $yesterdayOutgoingCallsSelf = DB::table('et_call_tracker')
        ->where('branch_id', $user->branch_id)
        ->where('branch_staff_id', $user->user_id)
        ->where('call_status', 0)
        ->whereDate('call_start_date', $yesterday)
        ->count();

      $differenceOutgoingCallsTodaySelf = $todayOutGoingCallsSelf - $yesterdayOutgoingCallsSelf;


      if ($yesterdayOutgoingCallsSelf > 0) {
        $percentageOutGoingCallsTodaySelf = ($differenceOutgoingCallsTodaySelf / $yesterdayOutgoingCallsSelf) * 100;

        if ($percentageOutGoingCallsTodaySelf < 0) {
          $percentageOutGoingCallsTodaySelf = 0;
        }

        if ($todayOutGoingCallsSelf == 0) {
          $percentageOutGoingCallsTodaySelf = 0;
        }
      } else {
        $percentageOutGoingCallsTodaySelf = $todayOutGoingCallsSelf > 0 ? 100 : 0;
      }

      // ===================================================================================

      // Outgoing Calls This Month
      $currentMonthOutgoingCallsSelf = DB::table('et_call_tracker')
        ->where('branch_staff_id', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->where('call_status', 0)
        ->whereYear('call_start_date', $currentYear)
        ->whereMonth('call_start_date', $currentMonth)
        ->count();

      $previousMonthOutgoingCallsSelf = DB::table('et_call_tracker')
        ->where('branch_staff_id', $user->user_id)
        ->where('branch_id', $user->branch_id)
        ->where('call_status', 0)
        ->whereYear('call_start_date', $currentYear)
        ->whereMonth('call_start_date', $currentMonth)
        ->count();

      $differenceOutGoingCallsCurrentMonthSelf = $currentMonthOutgoingCallsSelf - $previousMonthOutgoingCallsSelf;


      if ($previousMonthOutgoingCallsSelf > 0) {
        $percentageOutgoingCallsCurrentMonthSelf = ($differenceOutGoingCallsCurrentMonthSelf / $previousMonthOutgoingCallsSelf) * 100;

        if ($percentageOutgoingCallsCurrentMonthSelf < 0) {
          $percentageOutgoingCallsCurrentMonthSelf = 0;
        }

        if ($currentMonthOutgoingCallsSelf == 0) {
          $percentageOutgoingCallsCurrentMonthSelf = 0;
        }
      } else {
        $percentageOutgoingCallsCurrentMonthSelf = $currentMonthOutgoingCallsSelf > 0 ? 100 : 0;
      }

      // =============================================================================================================

      // CR - Conversion Rate
      $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->whereNotIn('et_lead.status', [2, 6])
        ->where('et_lead.spam_verified', 0)
        ->where('et_lead.drop_verified', 0)
        ->where('et_lead.internal_status', 0)
        ->count();

      $customerConvertCount = DB::table('et_customer')->select('et_customer.sno')->where('et_customer.status', 0)
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_customer.branch_id', $user->branch_id)
        ->where('et_customer.status', 0)
        ->where('et_lead.created_by', $user->user_id)
        ->whereDate('et_customer.created_at', $today)
        ->count();

      // return $customerConvertCount;

      // customer ratio
      $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
      $convertion_rate = number_format($convertion_rate, 2);

      // CR - Conversion Rate Month
      $customerConvertCountMonth = DB::table('et_customer')->select('et_customer.sno')->where('et_customer.status', 0)
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_lead.status', 4)
        ->where('et_customer.branch_id', $user->branch_id)
        ->where('et_customer.status', 0)
        ->where('et_lead.created_by', $user->user_id)
        ->whereYear('et_customer.created_at', $currentYear)
        ->whereMonth('et_customer.created_at', $currentMonth)
        ->count();

      // customer ratio
      $convertion_rate_month = $allLeadCount > 0 ? ($customerConvertCountMonth / $allLeadCount) * 100 : 0;
      $convertion_rate_month = number_format($convertion_rate_month, 2);

      // ABV and ACV Today
      $total_payment             = 0;
      $total_paid_payment        = 0;
      $averageBusinessValue      = 0;
      $averageCollectionValue    = 0;
      $averageBusinessValueMonth      = 0;
      $averageCollectionValueMonth    = 0;
      $totalAllPayment             = 0;
      $totalAllPaidPayment        = 0;

      if ($customerConvertCount > 0) {
        $currentMonthCustomer = DB::table('et_customer')->select('et_customer.sno', 'et_customer.proposal_ids')->where('et_customer.status', 0)
          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
          ->where('et_customer.branch_id', $user->branch_id)
          ->where('et_customer.status', 0)
          ->where('et_lead.created_by', $user->user_id)
          ->whereDate('et_customer.created_at', $today)
          ->get();

        if ($currentMonthCustomer->isNotEmpty()) {
          foreach ($currentMonthCustomer as $customer) {
            $proposal_ids = json_decode($customer->proposal_ids);
            $total_paid_payment = DB::table('et_proposal_pay_slot')
              ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
              ->where('status', 0)
              ->sum('paidAmount');
            // $total_payment=0;
            // $total_payment += $payment;


            $total_payment = DB::table('et_proposal')
              ->whereIn('sno', $proposal_ids)
              ->where('status', 0)
              ->sum('total_amount');

            // if ($latestTraining) {
            //     $total_payment += $latestTraining->overall_fees;
            // }
            // $paid_payment=0;
            // $paid_payment = DB::table('et_training')->select('et_training.course_id', 'et_training.sno','et_training.customer_id')
            //                   ->where('et_training.customer_id', $customer->sno)
            //                   ->sum('et_training.paid_amount');

            // $total_paid_payment += $paid_payment;

          }
        }


        // average 
        $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
        $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;
        $totalAllPayment += $total_payment;
        $totalAllPaidPayment += $total_paid_payment;
      }

      // ABV and ACV this month
      if ($customerConvertCountMonth > 0) {
        $currentMonthCustomer = DB::table('et_customer')->select('et_customer.sno', 'et_customer.proposal_ids')->where('et_customer.status', 0)
          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
          ->where('et_customer.branch_id', $user->branch_id)
          ->where('et_customer.status', 0)
          ->where('et_lead.created_by', $user->user_id)
          ->whereYear('et_customer.created_at', $currentYear)
          ->whereMonth('et_customer.created_at', $currentMonth)
          ->get();

        if ($currentMonthCustomer->isNotEmpty()) {
          foreach ($currentMonthCustomer as $customer) {
            $proposal_ids_month = json_decode($customer->proposal_ids);
            $total_paid_payment_month = DB::table('et_proposal_pay_slot')
              ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
              ->where('status', 0)
              ->sum('paidAmount');
            // $total_payment=0;
            // $total_payment += $payment;


            $total_payment_month = DB::table('et_proposal')
              ->whereIn('sno', $proposal_ids_month)
              ->where('status', 0)
              ->sum('total_amount');

            // if ($latestTraining) {
            //     $total_payment += $latestTraining->overall_fees;
            // }
            // $paid_payment=0;
            // $paid_payment = DB::table('et_training')->select('et_training.course_id', 'et_training.sno','et_training.customer_id')
            //                   ->where('et_training.customer_id', $customer->sno)
            //                   ->sum('et_training.paid_amount');

            // $total_paid_payment += $paid_payment;

          }
        }


        // average 
        $averageBusinessValueMonth   = $customerConvertCountMonth > 0 ? $total_payment_month / $customerConvertCountMonth : 0;
        $averageCollectionValueMonth = $customerConvertCountMonth > 0 ? $total_paid_payment_month / $customerConvertCountMonth : 0;
        $totalAllPayment += $total_payment_month;
        $totalAllPaidPayment += $total_paid_payment_month;
      }

      // ======================================================================================================================================
      // Sales TL My Team
      // ======================================================================================================================================

      // Lead Source Today
      $total_leads_overall_team = LeadModel::whereMonth('registered_date', date('m'))
        ->whereYear('registered_date', date('Y'))
        ->where('branch_id', $user->branch_id)
        ->count();


      // 2. Get lead sources with counts
      $lead_sources_team = LeadSourceModel::where('et_lead_source.branch_id', $user->branch_id)
        ->select(
          'lead_source_name',
          DB::raw('COUNT(et_lead.lead_source_id) as total_leads')
        )
        ->leftJoin('et_lead', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
        ->where('et_lead_source.status', 0)
        ->whereMonth('et_lead.registered_date', date('m'))
        ->whereYear('et_lead.registered_date', date('Y'))
        ->groupBy('et_lead_source.lead_source_name')
        ->orderBy('total_leads', 'desc')
        ->get();

      // 3. Calculate percentage for each lead source
      foreach ($lead_sources_team as $lead_source) {
        $lead_source->percentage = $total_leads_overall_team > 0 ? round(($lead_source->total_leads / $total_leads_overall_team) * 100) : 0;
      }

      // ==================================================================================================

      // Follow Up Schedule
      $filterStaffs = StaffModel::where('status', '!=', 2)
        ->where('department_id', 1)
        ->where('branch_id', $user->branch_id)
        ->get();

      $staffIds = $filterStaffs->pluck('sno')->toArray();

      $todayAppointmentsTeam = DB::table('et_appointment')
        ->select('et_appointment.*', 'et_lead.lead_name', 'et_staff.staff_name')
        ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
        ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
        ->whereDate('et_appointment.appointment_date', date('Y-m-d'))
        ->where('et_appointment.branch_id', $user->branch_id)
        ->whereIn('et_lead.created_by', $staffIds)
        ->orderBy('et_appointment.lead_id')
        ->orderBy('et_appointment.appointment_date', 'desc')
        ->get();

      $filteredAppointmentsTeam = collect();
      $teamLeads = [];

      foreach ($todayAppointmentsTeam as $tdyapp) {
        $team_lead_id = $tdyapp->lead_id;

        if (isset($teamLeads[$team_lead_id])) continue;

        $isCom = $tdyapp->status == 4;
        $isRes = $tdyapp->status == 5;
        $isSch = $tdyapp->status == 1;

        if ($isCom) {
          $tdyapp->display_status = 'Completed';
          $teamLeads[$team_lead_id] = true;
          $filteredAppointmentsTeam->push($tdyapp);
        } elseif ($isRes) {
          $tdyapp->display_status = 'Rescheduled';
          $teamLeads[$team_lead_id] = true;
          $filteredAppointmentsTeam->push($tdyapp);
        } elseif ($isSch) {
          $tdyapp->display_status = 'Scheduled';
          $teamLeads[$team_lead_id] = true;
          $filteredAppointmentsTeam->push($tdyapp);
        }
      }

      // ==============================================================================

      // Appointment Schedule
      $appointmentTodayTeam = DB::table('et_lead_appointment')
        ->select('et_lead_appointment.*', 'et_lead.lead_name', 'et_staff.staff_name')
        ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_lead_appointment.lead_id')
        ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
        ->whereDate('et_lead_appointment.appointment_date', date('Y-m-d'))
        ->where('et_lead_appointment.branch_id', $user->branch_id)
        ->whereIn('et_lead.created_by', $staffIds)
        ->orderBy('et_lead_appointment.lead_id')
        ->orderBy('et_lead_appointment.appointment_date', 'asc')
        ->get();

      $appointmentFilterToday = collect();
      $appLeads = [];

      foreach ($appointmentTodayTeam as $app) {
        $lead_id = $app->lead_id;

        if (isset($appLeads[$lead_id])) continue;

        $appCompleted = $app->appointment_status == 2;
        $appRescheduled = $app->appointment_status == 4;
        $appScheduled = $app->appointment_status == 1;

        if ($appCompleted) {
          $app->app_status = 'Completed';
          $appLeads[$lead_id] = true;
          $appointmentFilterToday->push($app);
        } elseif ($appRescheduled) {
          $app->app_status = 'Rescheduled';
          $appLeads[$lead_id] = true;
          $appointmentFilterToday->push($app);
        } elseif ($appScheduled) {
          $app->app_status = 'Scheduled';
          $appLeads[$lead_id] = true;
          $appointmentFilterToday->push($app);
        }
      }

      // ===========================================================================================

      $walkInCountTeam = $appointmentFilterToday->where('appointment_category', 'Walk-in')->count();

      // ==============================================================================================

      // Get Team Members
      $staffFiltering = StaffModel::where('et_staff.branch_id', $user->branch_id)
        ->select('et_staff.*', 'et_job_position.job_position_name')
        ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
        ->where('et_staff.status', '!=', 2)
        ->where('et_staff.department_id', 1)
        ->get();

      // ======================================================================================

      // Convert Customer This Month
      $convertCustomerCurrentMonthTeam = DB::table('et_lead')
        ->where('created_by', $user->user_id)
        ->where('status', 4)
        ->where('internal_status', 0)
        ->whereMonth('registered_date', $currentMonth)
        ->whereYear('registered_date', $currentYear)
        ->count();

      // ===================================================================

      // Convert Customer Today
      $convertCustomerTodayTeam = DB::table('et_lead')
        ->where('created_by', $user->user_id)
        ->where('status', 4)
        ->where('internal_status', 0)
        ->whereDate('registered_date', $today)
        ->count();

      // =======================================================================

      // CR - Conversion Rate
      $allLeadCountTeamTdy = DB::table('et_lead')->select('et_lead.sno')
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->whereNotIn('et_lead.status', [2, 6])
        ->where('et_lead.spam_verified', 0)
        ->where('et_lead.drop_verified', 0)
        ->where('et_lead.internal_status', 0)
        ->where('et_lead.registered_date', $today)
        ->count();

      $customerConvertCountTeamTdy = DB::table('et_customer')->select('et_customer.sno')->where('et_customer.status', 0)
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_customer.branch_id', $user->branch_id)
        ->where('et_customer.status', 0)
        ->where('et_lead.created_by', $user->user_id)
        ->whereDate('et_customer.created_at', $today)
        ->count();

      // customer ratio
      $convertion_rate_team_tdy = $allLeadCountTeamTdy > 0 ? ($customerConvertCountTeamTdy / $allLeadCountTeamTdy) * 100 : 0;
      $convertion_rate_team_tdy = number_format($convertion_rate_team_tdy, 2);

      // =======================================================================================================================

      $allLeadCountCurrentMonthTeam = DB::table('et_lead')->select('et_lead.sno')
        ->where('et_lead.created_by', $user->user_id)
        ->where('et_lead.branch_id', $user->branch_id)
        ->whereNotIn('et_lead.status', [2, 6])
        ->where('et_lead.spam_verified', 0)
        ->where('et_lead.drop_verified', 0)
        ->where('et_lead.internal_status', 0)
        ->whereMonth('et_lead.registered_date', $currentMonth)
        ->whereYear('et_lead.registered_date', $currentYear)
        ->count();

      // CR - Conversion Rate Month
      $customerConvertCountTeamMonth = DB::table('et_customer')->select('et_customer.sno')->where('et_customer.status', 0)
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->where('et_customer.branch_id', $user->branch_id)
        ->where('et_customer.status', 0)
        ->where('et_lead.created_by', $user->user_id)
        ->whereMonth('et_customer.created_at', $currentMonth)
        ->whereYear('et_customer.created_at', $currentYear)
        ->count();

      // customer ratio
      $convertion_rate_team_month = $allLeadCountCurrentMonthTeam > 0 ? ($customerConvertCountTeamMonth / $allLeadCountTeamTdy) * 100 : 0;
      $convertion_rate_team_month = number_format($convertion_rate_team_month, 2);

      // =================================================================================================================================

      // Walk In Count Today
      $walkInCountTodayTeam = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('branch_id', $user->branch_id)
        ->whereDate('created_at', $today)
        ->count();

      $yesterdayWalkInCountTeam = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('branch_id', $user->branch_id)
        ->whereDate('created_at', $yesterday)
        ->count();

      $differenceTeamWalkInCount = $walkInCountTodayTeam - $yesterdayWalkInCountTeam;

      if ($yesterdayWalkInCountTeam > 0) {
        $percentageWalkInCountTeam = ($differenceTeamWalkInCount / $yesterdayWalkInCountTeam) * 100;

        if ($percentageWalkInCountTeam < 0) {
          $percentageWalkInCountTeam = 0;
        }

        if ($walkInCountTodayTeam == 0) {
          $percentageWalkInCountTeam = 0;
        }
      } else {
        $percentageWalkInCountTeam = $walkInCountTodayTeam > 0 ? 100 : 0;
      }

      // ===================================================================================

      // Walk In Count This Month
      $walkin_count_team_month = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('branch_id', $user->branch_id)
        ->whereMonth('created_at', $currentMonth)
        ->whereYear('created_at', $currentYear)
        ->count();

      $walkin_count_team_prev = DB::table('et_lead_appointment')
        ->where('appointment_category', 'Walk-in')
        ->where('branch_id', $user->branch_id)
        ->whereMonth('created_at', $currentMonth)
        ->whereYear('created_at', $currentYear)
        ->count();

      $diff_walk_in_count_month = $walkin_count_team_month - $walkin_count_team_prev;

      if ($walkin_count_team_prev > 0) {
        $per_walk_in_count_month = ($diff_walk_in_count_month / $walkin_count_team_prev) * 100;

        if ($per_walk_in_count_month < 0) {
          $per_walk_in_count_month = 0;
        }

        if ($walkin_count_team_month == 0) {
          $per_walk_in_count_month = 0;
        }
      } else {
        $per_walk_in_count_month = $walkin_count_team_month > 0 ? 100 : 0;
      }

      // Appointments Today
      $tdy_app_team = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->whereDate('created_at', $today)
        ->count();

      $yst_app_team = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->whereDate('created_at', $yesterday)
        ->count();

      $diff_app_team = $tdy_app_team - $yst_app_team;

      if ($yst_app_team > 0) {
        $per_app_team = ($diff_app_team / $yst_app_team) * 100;

        if ($per_app_team < 0) {
          $per_app_team = 0;
        }

        if ($tdy_app_team == 0) {
          $per_app_team = 0;
        }
      } else {
        $per_app_team = $tdy_app_team > 0 ? 100 : 0;
      }

      // Appointments This Month
      $tdy_app_month_team = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->whereMonth('created_at', $currentMonth)
        ->whereYear('created_at', $currentYear)
        ->count();

      $yst_app_month_team = DB::table('et_lead_appointment')
        ->where('branch_id', $user->branch_id)
        ->whereMonth('created_at', $currentMonth)
        ->whereYear('created_at', $currentYear)
        ->count();

      $diff_app_month_team = $tdy_app_month_team - $yst_app_month_team;

      if ($yst_app_month_team > 0) {
        $per_app_month_team = ($diff_app_month_team / $yst_app_month_team) * 100;

        if ($per_app_month_team < 0) {
          $per_app_month_team = 0;
        }

        if ($tdy_app_month_team == 0) {
          $per_app_month_team = 0;
        }
      } else {
        $per_app_month_team = $tdy_app_month_team > 0 ? 100 : 0;
      }

      // FollowUps Today
      $tdy_flwup_team = DB::table('et_appointment')
        ->where('branch_id', $user->branch_id)
        ->whereDate('appointment_date', $today)
        ->count();

      $yst_flwup_team = DB::table('et_appointment')
        ->where('branch_id', $user->branch_id)
        ->whereDate('appointment_date', $yesterday)
        ->count();

      $diff_flwup_team = $tdy_flwup_team - $yst_flwup_team;


      if ($yst_flwup_team > 0) {
        $per_flwup_team = ($diff_flwup_team / $yst_flwup_team) * 100;

        if ($per_flwup_team < 0) {
          $per_flwup_team = 0;
        }

        if ($tdy_flwup_team == 0) {
          $per_flwup_team = 0;
        }
      } else {
        $per_flwup_team = $tdy_flwup_team > 0 ? 100 : 0;
      }

      // FollowUps This Month
      $tdy_flwup_month_team = DB::table('et_appointment')
        ->where('branch_id', $user->branch_id)
        ->whereMonth('appointment_date', $currentMonth)
        ->whereYear('appointment_date', $currentYear)
        ->count();

      $yst_flwup_mnth_team = DB::table('et_appointment')
        ->where('branch_id', $user->branch_id)
        ->whereMonth('appointment_date', $currentMonth)
        ->whereYear('appointment_date', $currentYear)
        ->count();

      $diff_flwup_month_team = $tdy_flwup_month_team - $yst_flwup_mnth_team;


      if ($yst_flwup_mnth_team > 0) {
        $per_flwup_mnth_team = ($diff_flwup_month_team / $yst_flwup_mnth_team) * 100;

        if ($per_flwup_mnth_team < 0) {
          $per_flwup_mnth_team = 0;
        }

        if ($tdy_flwup_month_team == 0) {
          $per_flwup_mnth_team = 0;
        }
      } else {
        $per_flwup_mnth_team = $tdy_flwup_month_team > 0 ? 100 : 0;
      }

      // Outgoing Calls Today
      $tdy_calls_team = DB::table('et_call_tracker')
        ->where('branch_staff_id', $user->user_id)
        ->where('call_status', 0)
        ->whereDate('created_at', $today)
        ->count();

      $yst_calls_team = DB::table('et_call_tracker')
        ->where('branch_staff_id', $user->user_id)
        ->where('call_status', 0)
        ->whereDate('created_at', $yesterday)
        ->count();

      $diff_calls_team = $tdy_calls_team - $yst_calls_team;


      if ($yst_calls_team > 0) {
        $per_calls_team = ($diff_calls_team / $yst_calls_team) * 100;

        if ($per_calls_team < 0) {
          $per_calls_team = 0;
        }

        if ($tdy_calls_team == 0) {
          $per_calls_team = 0;
        }
      } else {
        $per_calls_team = $tdy_calls_team > 0 ? 100 : 0;
      }

      // Outgoing Calls This Month
      $tdy_calls_month_team = DB::table('et_call_tracker')
        ->where('branch_staff_id', $user->user_id)
        ->where('call_status', 0)
        ->whereMonth('created_at', $currentMonth)
        ->whereYear('created_at', $currentYear)
        ->count();

      $yst_calls_month_team = DB::table('et_call_tracker')
        ->where('branch_staff_id', $user->user_id)
        ->where('call_status', 0)
        ->whereMonth('created_at', $currentMonth)
        ->whereYear('created_at', $currentYear)
        ->count();

      $diff_calls_month_team = $tdy_calls_month_team - $yst_calls_month_team;


      if ($yst_calls_month_team > 0) {
        $per_calls_month_team = ($diff_calls_month_team / $yst_calls_month_team) * 100;

        if ($per_calls_month_team < 0) {
          $per_calls_month_team = 0;
        }

        if ($tdy_calls_month_team == 0) {
          $per_calls_month_team = 0;
        }
      } else {
        $per_calls_month_team = $tdy_calls_month_team > 0 ? 100 : 0;
      }


      // ABV and ACV Today
      $total_payment_team_tdy             = 0;
      $total_paid_payment_team_tdy        = 0;
      $averageBusinessValueTeamTdy      = 0;
      $averageCollectionValueTeamTdy    = 0;

      if ($customerConvertCount > 0) {
        $currentMonthCustomer = DB::table('et_customer')->select('et_customer.sno', 'et_customer.proposal_ids')->where('et_customer.status', 0)
          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
          ->where('et_customer.branch_id', $user->branch_id)
          ->where('et_customer.status', 0)
          ->where('et_lead.created_by', $user->user_id)
          ->whereDate('et_customer.created_at', $today)
          ->get();

        if ($currentMonthCustomer->isNotEmpty()) {
          foreach ($currentMonthCustomer as $customer) {
            $proposal_ids = json_decode($customer->proposal_ids);
            $total_paid_payment_team_tdy = DB::table('et_proposal_pay_slot')
              ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
              ->where('status', 0)
              ->sum('paidAmount');

            $total_payment_team_tdy = DB::table('et_proposal')
              ->whereIn('sno', $proposal_ids)
              ->where('status', 0)
              ->sum('total_amount');
          }
        }

        // average 
        $averageBusinessValueTeamTdy   = $customerConvertCount > 0 ? $total_payment_team_tdy / $customerConvertCount : 0;
        $averageCollectionValueTeamTdy = $customerConvertCount > 0 ? $total_paid_payment_team_tdy / $customerConvertCount : 0;
      }

      // ABV and ACV Today
      $total_payment_team_mnth             = 0;
      $total_paid_payment_team_mnth        = 0;
      $averageBusinessValueTeamMnth      = 0;
      $averageCollectionValueTeamMnth    = 0;

      if ($customerConvertCount > 0) {
        $currentMonthCustomer = DB::table('et_customer')->select('et_customer.sno', 'et_customer.proposal_ids')->where('et_customer.status', 0)
          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
          ->where('et_customer.branch_id', $user->branch_id)
          ->where('et_customer.status', 0)
          ->where('et_lead.created_by', $user->user_id)
          ->whereDate('et_customer.created_at', $today)
          ->get();

        if ($currentMonthCustomer->isNotEmpty()) {
          foreach ($currentMonthCustomer as $customer) {
            $proposal_ids = json_decode($customer->proposal_ids);
            $total_paid_payment_team_mnth = DB::table('et_proposal_pay_slot')
              ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
              ->where('status', 0)
              ->sum('paidAmount');

            $total_payment_team_mnth = DB::table('et_proposal')
              ->whereIn('sno', $proposal_ids)
              ->where('status', 0)
              ->sum('total_amount');
          }
        }

        // average 
        $averageBusinessValueTeamMnth   = $customerConvertCount > 0 ? $total_payment_team_mnth / $customerConvertCount : 0;
        $averageCollectionValueTeamMnth = $customerConvertCount > 0 ? $total_paid_payment_team_mnth / $customerConvertCount : 0;
      }

      return view('content.dashboard.sales_tl_dashboards', [
        'branch_common' => $branch_common,
        'role_user' => $role_user,
        'convertCustomerCurrentMonthTeam' => $convertCustomerCurrentMonthTeam,
        'convertCustomerTodayTeam' => $convertCustomerTodayTeam,
        'tdy_app_team' => $tdy_app_team,
        'diff_app_team' => $diff_app_team,
        'tdy_app_month_team' => $tdy_app_month_team,
        'diff_app_month_team' => $diff_app_month_team,
        'per_app_month_team' => $per_app_month_team,
        'averageCollectionValueTeamTdy' => $averageCollectionValueTeamTdy,
        'averageBusinessValueTeamTdy' => $averageBusinessValueTeamTdy,
        'averageCollectionValueTeamMnth' => $averageCollectionValueTeamMnth,
        'averageBusinessValueTeamMnth' => $averageBusinessValueTeamMnth,
        'per_app_team' => $per_app_team,
        'tdy_calls_month_team' => $tdy_calls_month_team,
        'diff_calls_month_team' => $diff_calls_month_team,
        'per_calls_month_team' => $per_calls_month_team,
        'role_permission' => $role_permission,
        'top_5_sales_persons' => $top_5_sales_persons,
        'convertion_rate_team_tdy' => $convertion_rate_team_tdy,
        'convertion_rate_team_month' => $convertion_rate_team_month,
        'walkInCountTodayTeam' => $walkInCountTodayTeam,
        'differenceTeamWalkInCount' => $differenceTeamWalkInCount,
        'percentageWalkInCountTeam' => $percentageWalkInCountTeam,
        'walkin_count_team_month' => $walkin_count_team_month,
        'lead_sources' => $lead_sources,
        'lead_sources_team' => $lead_sources_team,
        'filteredAppointments' => $filteredAppointments,
        'filteredAppointmentsTeam' => $filteredAppointmentsTeam,
        'appointmentFilter' => $appointmentFilter,
        'appointmentFilterToday' => $appointmentFilterToday,
        'walkInCount' => $walkInCount,
        'walkInCountTeam' => $walkInCountTeam,
        'currentMonthTotalLeadsSelf' => $currentMonthTotalLeadsSelf,
        'differenceTotalLeadsSelf' => $differenceTotalLeadsSelf,
        'percentageTotalLeadsSelf' => $percentageTotalLeadsSelf,
        'currentMonthActiveLeadsSelf' => $currentMonthActiveLeadsSelf,
        'percentageActiveLeadsSelf' => $percentageActiveLeadsSelf,
        'differenceActiveLeadsSelf' => $differenceActiveLeadsSelf,
        'currentMonthSpamLeadsSelf' => $currentMonthSpamLeadsSelf,
        'differenceSpamLeadsSelf' => $differenceSpamLeadsSelf,
        'percentageSpamLeadsSelf' => $percentageSpamLeadsSelf,
        'currentMonthDeadLeadsSelf' => $currentMonthDeadLeadsSelf,
        'differenceDeadLeadsSelf' => $differenceDeadLeadsSelf,
        'percentageDeadLeadsSelf' => $percentageDeadLeadsSelf,
        'CurrentMonthCustomerConvertSelf' => $CurrentMonthCustomerConvertSelf,
        'differenceCustomerConvertSelf' => $differenceCustomerConvertSelf,
        'percentageCustomerConvertSelf' => $percentageCustomerConvertSelf,
        'odc_count' => $odc_count,
        'mc_count' => $mc_count,
        'omc_count' => $omc_count,
        'todayConversionSelf' => $todayConversionSelf,
        'currentMonthConversionSelf' => $currentMonthConversionSelf,
        'todayWalkInCountSelf' => $todayWalkInCountSelf,
        'differenceWalkInCountTodaySelf' => $differenceWalkInCountTodaySelf,
        'percentageWalkInCountTodaySelf' => $percentageWalkInCountTodaySelf,
        'currentMonthWalkInCountSelf' => $currentMonthWalkInCountSelf,
        'differenceWalkInCountCurrentMonthSelf' => $differenceWalkInCountCurrentMonthSelf,
        'percentageWalkInCountCurrentMonthSelf' => $percentageWalkInCountCurrentMonthSelf,
        'appointmentsTodaySelf' => $appointmentsTodaySelf,
        'differenceAppointmentsTodaySelf' => $differenceAppointmentsTodaySelf,
        'percentageAppointmentsTodaySelf' => $percentageAppointmentsTodaySelf,
        'appointmentsCurrentMonthSelf' => $appointmentsCurrentMonthSelf,
        'differenceAppointmentsCurrentMonthSelf' => $differenceAppointmentsCurrentMonthSelf,
        'percentageAppointmentsCurrentMonthSelf' => $percentageAppointmentsCurrentMonthSelf,
        'todayFollowUpsSelf' => $todayFollowUpsSelf,
        'differenceFollowUpsTodaySelf' => $differenceFollowUpsTodaySelf,
        'percentageFollowUpdsTodaySelf' => $percentageFollowUpdsTodaySelf,
        'tdy_flwup_team' => $tdy_flwup_team,
        'per_flwup_team' => $per_flwup_team,
        'diff_flwup_team' => $diff_flwup_team,
        'currentMonthFollowUpsSelf' => $currentMonthFollowUpsSelf,
        'differenceFollowUpsCurrentMonthSelf' => $differenceFollowUpsCurrentMonthSelf,
        'percentageFollowUpsCurrentMonthSelf' => $percentageFollowUpsCurrentMonthSelf,
        'per_flwup_mnth_team' => $per_flwup_mnth_team,
        'per_calls_team' => $per_calls_team,
        'diff_calls_team' => $diff_calls_team,
        'tdy_calls_team' => $tdy_calls_team,
        'diff_flwup_month_team' => $diff_flwup_month_team,
        'tdy_flwup_month_team' => $tdy_flwup_month_team,
        'todayOutGoingCallsSelf' => $todayOutGoingCallsSelf,
        'differenceOutgoingCallsTodaySelf' => $differenceOutgoingCallsTodaySelf,
        'percentageOutGoingCallsTodaySelf' => $percentageOutGoingCallsTodaySelf,
        'currentMonthOutgoingCallsSelf' => $currentMonthOutgoingCallsSelf,
        'differenceOutGoingCallsCurrentMonthSelf' => $differenceOutGoingCallsCurrentMonthSelf,
        'percentageOutgoingCallsCurrentMonthSelf' => $percentageOutgoingCallsCurrentMonthSelf,
        'convertion_rate' => $convertion_rate,
        'convertion_rate_month' => $convertion_rate_month,
        'averageBusinessValue' => $averageBusinessValue,
        'averageCollectionValue' => $averageCollectionValue,
        'averageBusinessValueMonth' => $averageBusinessValueMonth,
        'averageCollectionValueMonth' => $averageCollectionValueMonth,
        'staffFiltering' => $staffFiltering
      ]);
    }
    return view('content.dashboard.dashboards-analytics', compact('branch_common', 'role_user', 'role_permission'));
  }

  public function login(Request $request)
  {

    // return Hash::make($request->password);
    // return $request;
    $validator = Validator::make($request->all(), [
      'name' => 'required|max:50',
      'password' => 'required',
    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' =>  $validator->errors(),
      ]);
      return back()->withInput();
      //   return response()->json([
      //     'status' => 422,
      //     'message' => 'Validation Error',
      //     'error_msg' => $validator->errors(),
      //     'data' => null
      //   ], 422);
    }
    $remember = $request->has('remember');
    $user = User::select('users.*', 'et_staff.status as staff_status')
      ->where('users.name', $request->name)
      ->leftJoin('et_staff', 'users.user_id', '=', 'et_staff.sno')
      ->leftJoin('et_branch', 'users.branch_id', '=', 'et_branch.sno')
      ->where('et_branch.status', 0)
      ->where('et_staff.status', 0)
      ->first();

    if (!$user) {
      DB::table('user_login_logs')->insert([
        'user_id'    => 0,
        'login_at'   => Carbon::now('Asia/Kolkata'),
        'ip_address' => $request->ip(),
        'user_agent' => $request->header('User-Agent'),
        'user_name'  => $request->name,
        'password'   => $request->password,
        'type'       => 1, // failed
        'created_at' => Carbon::now('Asia/Kolkata'),
        'updated_at' => Carbon::now('Asia/Kolkata'),
      ]);
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'User not found.'
      ]);
      return back()->withInput();
    }

    if ($user->staff_status == 1) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'This user is inactive. Please contact the administrator.'
      ]);
      return back()->withInput();
    } elseif ($user->staff_status == 2) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'This user is deactivated. Please contact the administrator.'
      ]);
      return back()->withInput();
    }
    if ($user->name !== $request->name) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Username is case-sensitive. Please enter the correct case.'
      ]);
      return back()->withInput();
    }



    if (!Hash::check($request->password, $user->password)) {

      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Invalid credentials'
      ]);
      return back()->withInput();
    }

    Auth::login($user, $remember);
    session(['user_id' => $user->id]);
    // ✅ Log login info to user_login_logs
    DB::table('user_login_logs')->insert([
      'user_id'    => $user->id,
      'login_at'   => Carbon::now('Asia/Kolkata'),
      'ip_address' => $request->ip(),
      'user_agent' => $request->header('User-Agent'),
      'user_name'  => $request->name,
      'password'   => $request->password,
      'type'       => 0, // success
      'created_at' => Carbon::now('Asia/Kolkata'),
      'updated_at' => Carbon::now('Asia/Kolkata'),
    ]);

    $permissions = UserRolePermissionModel::where('role_id', $user->role_id)->where('status', 0)->first();

    // dd($permissions);
    // Assuming you have a method in the User model to check role permissions
    if (!$permissions) {
      // Redirect to the role_permission_error page if the user doesn't have the role
      return redirect()->route('role_permission_error');
    }
    // Create a personal access token
    $token = $user->createToken('auth_token')->plainTextToken;

    // Set the cookie with the token, valid for 1 day
    // Cookie::queue('auth_token', $token, 1440);

    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'Login Successfully!'
    ]);

    if ($request->expectsJson()) {
      return response()->json([
        'status' => 200,
        'message' => 'Login Successful',
        'data' => [
          'redirect_url' => route('dashboards'),
          'token' => $token,
        ]
      ]);
    } else {
      $top_5_sales_persons = StaffModel::where('et_staff.branch_id', $user->branch_id)
        ->select(
          'et_staff.sno',  // Include sno to compare
          'et_staff.staff_name',
          'et_staff.nick_name',
          'et_staff.staff_image',
          DB::raw('COUNT(et_lead.created_by) as total_leads')
        )
        ->leftJoin('et_lead', 'et_lead.created_by', '=', 'et_staff.sno')
        ->whereMonth('et_lead.registered_date', date('m'))
        ->whereYear('et_lead.registered_date', date('Y'))
        ->where('et_staff.role_id', '!=', 12)
        ->where('et_lead.status', 4)
        ->groupBy('et_staff.sno', 'et_staff.staff_name', 'et_staff.nick_name', 'et_staff.staff_image')
        ->orderBy('total_leads', 'desc')
        ->limit(5)
        ->get();


      if ($top_5_sales_persons && $top_5_sales_persons->count() > 1) {
        $firstStaff = $top_5_sales_persons->first();
        $lastStaff = $top_5_sales_persons->last();

        // Clear both to avoid overlap
        session()->forget(['show_congrats_modal', 'show_loser_modal']);

        if ($lastStaff && $lastStaff->sno == $user->user_id) {
          session(['show_loser_modal' => true]);
        } elseif ($firstStaff && $firstStaff->sno == $user->user_id) {
          session(['show_congrats_modal' => true]);
        }
      }
      return redirect()->route('dashboards');  // Ensure correct route name

    }
  }

  public function destroy(Request $request)
  {

    // Get the current authenticated user
    $user = Auth::user();

    if ($user) {
      // Update the latest login log with logout time
      DB::table('user_login_logs')
        ->where('user_id', $user->id)
        ->whereNull('logout_at') // Ensure we only update the last active session
        ->latest('login_at')
        ->limit(1)
        ->update([
          'logout_at' => now(),
          'updated_at' => now()
        ]);
    }
    Auth::guard('web')->logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    $cookieName = config('session.cookie'); // Get the session cookie name from configuration
    Cookie::queue(Cookie::forget($cookieName));

    return redirect('/');
  }
  public function updateProfile(Request $request)
  {
    $user = Auth::user(); // Get authenticated user

    // Validate request
    $request->validate([
      'staff_password' => 'nullable|min:6', // Password is optional, must be at least 6 characters if provided
      'staff_image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048', // Image validation
    ]);

    // Update password in user table if provided
    if ($request->filled('staff_password')) {
      $user->password = Hash::make($request->staff_password); // Hash and update password
      $user->save();
    }

    // Update password in staff table if exists
    $staff = $user->staff;
    if ($staff) {
      if ($request->filled('staff_password')) {
        $staff->password = $request->staff_password; // Hash and update password
      }

      // Handle profile image upload
      if ($request->hasFile('staff_image')) {
        $image = $request->file('staff_image');
        $staff_imageName = 'staff_' . $staff->sno . '.' . $image->extension();
        $image->move(public_path('staff_images'), $staff_imageName);
        $staff->staff_image = $staff_imageName;
      }

      $staff->save(); // Save staff record after updating password and/or image
    }

    return back()->with('success', 'Profile updated successfully.');
  }

  // Egc Login handle
  public function HandleEGCLogin(Request $request)
  {
    if (!$request->token) {
      abort(400, "Missing SSO token");
    }



    // Verify with App1
    $verifyResponse = Http::get($request->token);

    if (!$verifyResponse->ok()) {
      abort(401, "SSO Verification failed");
    }

    $data = $verifyResponse->json()['data'];

    if ($data['secret_token'] != 'egcswitchportal2027') {
      abort(401, "UnAuthorized Entry");
    }

    $user_name = $data['user_name'];
    $email = $data['email'];

    // Find user in ERP database
    $user = User::where('name', $user_name)
      ->first();

    if (!$user) {
      abort(404, "User not found");
    }

    // Direct login, no password check needed
    Auth::login($user);

    return redirect()->route('dashboards');
  }
}
