<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use App\Mail\EAPLMail;
use Illuminate\Support\Facades\File;
use App\Models\AppointmentModel;
use App\Models\AttendanceModel;
use App\Models\BatchExtensionModel;
use App\Models\BatchModel;
use App\Models\Batch_staff_swap_Model;
use App\Models\BranchModel;
use App\Models\Communication_config_Model;
use App\Models\CustomerModel;
use App\Models\GoalSetTeamModel;
use App\Models\EmailTemplateModel;
use App\Models\GoalSetStaffModel;
use App\Models\LeadModel;
use App\Models\SulekhaModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\JournalHistoryModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\PaymentModel;
use App\Models\Schedule_message_model;
use App\Models\SmsTemplateModel;
use App\Models\StaffAttendanceModel;
use App\Models\ManageCoursesModel;
use App\Models\StaffModel;
use App\Models\CallTrackerModel;
use App\Models\CugManagementModel;
use App\Models\StaffRescheduleModel;
use App\Models\LeadTransferLogModel;
use App\Models\JustDialModel;
use App\Models\DepartmentModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TrainingModel;
use App\Models\HotLeadModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\UserRolePermissionModel;
use App\Models\WhatsappApiConfigureModel;
use App\Models\GeneralSettingsModel;
use App\Models\CronjobMonitorModel;
use App\Models\CronjobLogModel;
use App\Models\ExamProcessModel;
use App\Services\DoubletickService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;

use App\Models\ManageQuestionBankModel;
use App\Models\ManageQuestionModel;
use App\Models\AIQuestionModel;
use App\Services\ChatGPTService;



class Cronjobs extends Controller
{

  protected $doubletickService;

  protected $client;
  protected $accessToken;
  protected $businessId;
  protected $baseUrl;
  protected $phoneNumberId;
  protected $chatGPTService;

  // public function __construct(DoubletickService $doubletickService, ChatGPTService $chatGPTService)
  // {
  //   $this->doubletickService = $doubletickService;
  //   $whatsappConfig = WhatsappApiConfigureModel::where('sno', 3)->first();
  //   $this->phoneNumberId = $whatsappConfig->phonenumber_id; // Set your access token in the environment file
  //   $this->accessToken = $whatsappConfig->access_tokken; // Set your access token in the environment file
  //   $this->baseUrl = 'https://graph.facebook.com/v17.0';
  //   $this->businessId = $whatsappConfig->waba_id;
  //   $this->chatGPTService = $chatGPTService;
  // }
   
  // public function Cronjob_payment_remainder(Request $request)
  // {

  //   // --- Session Cleanup ---
  //   $sessionPath = storage_path('framework/sessions');
  //   $files = File::allFiles($sessionPath);

  //   foreach ($files as $file) {
  //     try {
  //       if (File::lastModified($file) < now()->subMinutes(config('session.lifetime'))->getTimestamp()) {
  //         File::delete($file);
  //         $this->info("Deleted expired session file: {$file->getFilename()}");
  //       }
  //     } catch (\Exception $e) {
  //       // Log or ignore if the file was not found
  //       // \Log::warning("Failed to check/delete session file: {$file->getPathname()} - " . $e->getMessage());
  //     }
  //   }

  //   // Get the current date
  //   $today = now(); // Current date
  //   $lastDayOfMonth = now()->endOfMonth(); // Last day of the current month
  //   $helper = new \App\Helpers\Helpers();
  //   // return $today;
  //   // Get the number of days to send the reminder
  //   $send_message_before = $helper->general_setting_data()->payment_remainder ?? 1;
  //   $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

  //   // Calculate the date to compare with nextPayDate
  //   $reminderDate = date('Y-m-d', strtotime($today->copy()->addDays($send_message_before)));

  //   // return $reminderDate;

  //   // Fetch payments where the nextPayDate is equal to the calculated reminder date and status is 0
  //   $payments = PaymentModel::where('status', 0)
  //     ->whereDate('nextPayDate', $reminderDate)
  //     ->orderBy('nextPayDate', 'asc')
  //     ->get();

  //   // return $payments;
  //   //   Send Communication
  //   foreach ($payments as $i => $pay) {

  //     $customer         = CustomerModel::where('sno', $pay->customer_id)->first();
  //     $customer_mobiles = isset($customer->cus_mobile) ? $customer->cus_mobile : '';
  //     $customer_mails   = isset($customer->cus_email_id) ? $customer->cus_email_id : '';
  //     $customer_names   = isset($customer->cus_name) ? $customer->cus_name : 'Mr/Mrs';
  //     $cre_mobile       = isset($branch_data->cre_mobile) ? $branch_data->cre_mobile : '9677781155';
  //     $totalAmount      = $pay->amount + $pay->gst_amount;

  //     $paymentAmt       = number_format($totalAmount, 2, '.', ',');
  //     $totalAmount      = $paymentAmt . ". Rs";
  //     $duedate          = date($common_date_format, strtotime($pay->nextPayDate));
  //     $pay_course_id    = $pay->course_id ?? 1;

  //     $branch_data = BranchModel::where('sno', $pay->branch_id)->first();
  //     $branch_name = " ";
  //     if ($branch_data->branch_type == 1) {
  //       $branch_name = $branch_data->branch_name;
  //     } elseif ($branch_data->branch_type == 2) {
  //       $branch_name = $branch_data->franchise_name;
  //     }

  //     // Test Static values
  //     //   $customer_mails   = 'vetri4vijayan@gmail.com';
  //     //   $customer_mobiles = '';

  //     //sms
  //     if ($customer && $customer_mobiles) {
  //       $result_sms_pay  = SmsTemplateModel::where('status', 0)->where('template_name', '006_PaymentRemainder')->first();
  //       $authkey         = $result_sms_pay ? $result_sms_pay->authkey : '';
  //       $sender_id       = $result_sms_pay ? $result_sms_pay->sender_id : '';
  //       $template_id     = $result_sms_pay ? $result_sms_pay->template_id : '';
  //       $country_code    = $result_sms_pay ? $result_sms_pay->country_code : '';
  //       $message_content = $result_sms_pay ? $result_sms_pay->sms_template_messagecontent : '';
  //       $mobile_number   = $country_code . $customer_mobiles;
  //       $cre_no          = $branch_data->cre_mobile ?? '9677781155';

  //       // Replace placeholders with actual values
  //       $replacement_values = [$customer_names, $duedate, $cre_no];
  //       $message_content    = preg_replace_callback(
  //         '/\{#var#\}/',
  //         function () use (&$replacement_values) {
  //           return array_shift($replacement_values);
  //         },
  //         $message_content
  //       );

  //       $route    = "default";
  //       $postData = [
  //         'authkey' => $authkey,
  //         'mobiles' => $mobile_number,
  //         'message' => $message_content,
  //         'sender'  => $sender_id,
  //         'route'   => $route,
  //       ];

  //       // API URL
  //       $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

  //       // Initialize the resource
  //       $ch = curl_init();
  //       curl_setopt_array($ch, [
  //         CURLOPT_URL            => $url,
  //         CURLOPT_RETURNTRANSFER => true,
  //         CURLOPT_POST           => true,
  //         CURLOPT_POSTFIELDS     => $postData,
  //         CURLOPT_SSL_VERIFYHOST => 0,
  //         CURLOPT_SSL_VERIFYPEER => 0,
  //       ]);
  //       // Get response
  //       $response = curl_exec($ch);
  //       // return $response;
  //       $err = curl_error($ch);
  //       curl_close($ch);
  //     }
  //     // Email
  //     if ($customer && $customer_mails) {
  //       // return 'each working';
  //       $cre = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
  //       $email_template_id = 9; // thank you template
  //       $emailTemplate     = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
  //       $coursename        = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();
  //       $dynamicSubject    = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
  //       $content     = $emailTemplate->email_subject;
  //       $content     = str_replace('#name', $customer_names, $content);
  //       $content     = str_replace('#course', 'Java Full Stack', $content);
  //       $content     = str_replace('#amount', $totalAmount, $content);
  //       $content     = str_replace('#dueDate', $duedate, $content);
  //       $content     = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

  //       $branchNo           = $branch_data->mobile ?? '9677781155';
  //       $branchemail        = $branch_data->mail ?? 'info@elysiumacademy.org';
  //       $fbLink             = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
  //       $instaLink          = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
  //       $content            = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
  //       $content            = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

  //       $mailData = [
  //         'url'         => 'Eapl.com',
  //         'subject'     => $dynamicSubject,
  //         'content'     => $content,
  //         'branchNo'    => $branchNo,
  //         'branchemail' => $branchemail, // Use the message content from the request
  //         'fbLink'      => $fbLink,      // Use the message content from the request
  //         'instaLink'   => $instaLink,   // Use the message content from the request
  //         'salesMobile' => $branch_data->sales_mobile,
  //       ];

  //       $to_address   = $customer_mails;
  //       $from_address = 'elysiumacademy@elysium.community';
  //       $from_name    = 'Elysium AcademyÂ®';
  //       Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
  //     }
  //     //   $customer_mobiles = '7639093063';
  //     // Whatapp
  //     if ($customer && $customer_mobiles) {

  //       $coursename = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();
  //       $cre        = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
  //       $hasHeader  = false; // Example flag: set based on template
  //       $hasBody    = false; // Example flag: set based on template
  //       $components = [];
  //       $couponCode = " ";

  //       // Example flag: set based on template
  //       $components_trans = [];
  //       date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
  //       $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
  //       // $currentHour = date('H'); // Get current hour in 24-hour format
  //       if ($currentHour >= 5 && $currentHour < 12) {
  //         $greeting = 'Good Morning';
  //       } elseif ($currentHour >= 12 && $currentHour < 18) {
  //         $greeting = 'Good Afternoon';
  //       } else {
  //         $greeting = 'Good Evening';
  //       }
  //       $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
  //       $paymentDate        = date($common_date_format);


  //       $templateName = 'elysium_academy_pay_reminder2';
  //       $headerImage  = 'https://erp.elysium.academy/public/assets/eapl_images/Payment_success.jpg';
  //       $bodyText     = [
  //         [
  //           'type'           => 'text',
  //           'text'           => $greeting,
  //           'parameter_name' => 'greet_msg',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $customer_names,
  //           'parameter_name' => 'customer_name',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $coursename->course_name ?? 'Course',
  //           'parameter_name' => 'course_name',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $totalAmount,
  //           'parameter_name' => 'amount',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $duedate,
  //           'parameter_name' => 'due_date',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $cre->nick_name ?? 'Elsa',
  //           'parameter_name' => 'cre_name',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
  //           'parameter_name' => 'contact_email',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $branch_name ?? 'Elysium Academy',
  //           'parameter_name' => 'branch_name',
  //         ],
  //         [
  //           'type'           => 'text',
  //           'text'           => $branch_data->sales_mobile ?? '9677781155',
  //           'parameter_name' => 'contact_no',
  //         ],

  //       ];
  //       $components_trans[] = [
  //         'type'       => 'header',
  //         'parameters' => [
  //           [
  //             'type'  => 'image',
  //             'image' => [
  //               'link' => $headerImage, // Dynamically set header image
  //             ],
  //           ],
  //         ],
  //       ];

  //       $components_trans[] = [
  //         'type'       => 'body',
  //         'parameters' => $bodyText,
  //       ];
  //       $dynamicParameters         = $templateParameters[$templateName] ?? [];
  //       $WhatsAppBusinessAccountId = $this->businessId;
  //       $accessToken               = $this->accessToken;
  //       $fromPhoneNumberId         = $this->phoneNumberId;

  //       $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

  //       $to           = $customer_mobiles;
  //       $languageCode = 'en';

  //       if (strpos($to, '+91') !== 0) {
  //         $to = '+91' . $to;
  //       }

  //       $message = 'test~message';

  //       $payload = [
  //         'messaging_product' => 'whatsapp',
  //         'to'                => $to,
  //         'type'              => 'template',
  //         'template'          => [
  //           'name'       => $templateName,
  //           'language'   => [
  //             'code' => $languageCode,
  //           ],
  //           'components' => $components_trans,
  //         ],
  //       ];

  //       $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
  //     }
  //   }



  //   return $payments;
  // }

   private function sendRequestToWhatsApp($url, $token, $data)
   {
     try {
       $client = new \GuzzleHttp\Client();
       $response = $client->post($url, [
         'headers' => [
           'Authorization' => 'Bearer ' . $token,
           'Content-Type' => 'application/json',
         ],
         'json' => $data,
       ]);

       return [
         'status' => $response->getStatusCode(),
         'data' => json_decode($response->getBody(), true),
       ];
     } catch (\Exception $e) {
       return [
         'status' => 400,
         'error' => $e->getMessage(),
       ];
     }
   }

   private function sendEmail($template_id, $entity, $type)
   {
     $emailTemplate = EmailTemplateModel::find($template_id);
     if (! $emailTemplate) {
       // Log::error("Email Template not found for ID: {$update->email_template_id}");
       return;
     }

     // Dynamically map the fields based on the type
     $name     = $type === 'lead' ? $entity->lead_name : $entity->cus_name;
     $email    = $type === 'lead' ? $entity->lead_email_id : $entity->cus_email_id;
     $gender   = $type === 'lead' ? $entity->lead_gender : $entity->cus_gender;
     $contact2 = $type === 'lead' ? $entity->phone_number : $entity->cus_phone_number;

     // $branchMobile = BranchModel::find($entity->branch_id)?->mobile; // Assuming branch_id exists in both tables
     $branch_data = BranchModel::where('sno', $entity->branch_id)->first();
     $branch_name = " ";
     if ($branch_data->branch_type == 1) {
       $branch_name = $branch_data->branch_name;
     } elseif ($branch_data->branch_type == 2) {
       $branch_name = $branch_data->franchise_name;
     }

     // $coursename = ManageCoursesModel::where('status', 0)->where('sno', $courseArray)->first();

     // $dynamicSubject = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
     $dynamicSubject = str_replace('#course', 'Java Full stack', $emailTemplate->email_name);

     // $helper             = new \App\Helpers\Helpers();
     // $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
     // $paymentDate        = date($common_date_format);
     // $paymentAmt         = number_format($totalAmount, 2, '.', ',');
     // $paymentAmount      = $paymentAmt . ". Rs";
     $content     = $emailTemplate->email_subject;
     $content     = str_replace('#name', "Raja", $content);
     $content     = str_replace('#course', 'Java Full Stack', $content);
     $content     = str_replace('#amount', "5000.Rs", $content);
     $content     = str_replace('#dueDate', "26-Jan-2025", $content);
     $content     = str_replace('#mail', 'info@elysiumacademy.org', $content);
     $branchNo    = $branch_data->mobile ?? "67865787545";
     $branchemail = $branch_data->mail ?? "hfghdgh";
     $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
     $instaLink   = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
     $content     = str_replace('#CRENo', $branch_data->cre_mobile ?? 'Branch Mobile', $content);
     $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

     $mailData = [
       'url'         => 'Eapl.com',
       'subject'     => $dynamicSubject,
       'content'     => $content,
       'branchNo'    => $branchNo,
       'branchemail' => $branchemail, // Use the message content from the request
       'fbLink'      => $fbLink,      // Use the message content from the request
       'instaLink'   => $instaLink,   // Use the message content from the request
       'salesMobile' => $branch_data->sales_mobile,
     ];

     $to_address   = $email;
     $from_address = 'elysiumacademy@elysium.community';
     $from_name    = 'Elysium AcademyÂ®';
     Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
   }
  
    public function Cronjob_staff_lead_bank_update(Request $request)
    {
        $monitor = CronjobMonitorModel::where('sno', 3)->first();
        $start_time = microtime(true);
        $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    
        if ($monitor && $monitor->status != 0) {
            return response()->json([
                'success' => false,
                'message' => 'Cronjob status Off'
            ]);
        }
    
        if ($monitor) {
            $monitor->running_status = 1;
            $monitor->save();
        }
    
        $today = now('Asia/Kolkata');
        $lastDayOfMonth = now('Asia/Kolkata')->endOfMonth();
    
        $helper = new \App\Helpers\Helpers();
        $increase_count = $helper->general_setting_data()->lead_bank_count ?? 50;
        $inserted_records = 0;
        $message = '';
    
        if ($today->isSameDay($lastDayOfMonth)) {
            StaffModel::where('status', 0)->update([
                'lead_bank_count' => $increase_count,
                'month_lead_count' => 0
            ]);
            $message = "Updated successfully";
            $success = true;
        } else {
            $message = "Today is not the last day of the month.";
            $success = false;
        }
        
        // Step 1: Get the matching staff IDs
        $getaNoticePeriodInStaff = DB::table('et_staff')
          ->whereIn('status', [0, 1])
          ->where('notice_check', 1)
          ->whereDate('notice_end_date', '<=', $today)
          ->pluck('sno');
    
        // Step 2: Update the status to 2
        DB::table('et_staff')
          ->whereIn('sno', $getaNoticePeriodInStaff)
          ->update(['status' => 4]);
    
        // End time & duration
        $end_time = microtime(true);
        $execution_time = round($end_time - $start_time, 4);
        $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    
        $hours   = floor($execution_time / 3600);
        $minutes = floor(($execution_time % 3600) / 60);
        $seconds = $execution_time % 60;
        $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
    
        // Update monitor and create log
        if ($monitor) {
            $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
            $monitor->sync_duration        = $duration;
            $monitor->running_status       = 0;
            $monitor->save();
    
            $monitor_log = new CronjobLogModel();
            $monitor_log->cronjob_id           = $monitor->sno;
            $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_duration        = $duration;
            $monitor_log->response             = json_encode([
                'processed_records' => $inserted_records,
                'execution_time'    => $duration,
                'message'           => $message
            ]);
            $monitor_log->created_by = 0;
            $monitor_log->updated_by = 0;
            $monitor_log->save();
        }
    
        return response()->json([
            "success" => $success,
            "message" => $message,
            "processed_records" => $inserted_records,
            "execution_time" => $duration
        ]);
    }

  public function Cronjob_otherdb()
  {
      return 'return';
    // Connect to the secondary database
   $other_db = DB::connection('mysql_secondary');
   
//   return $other_db->table('user')->first();
    // Query to fetch user data and associated call logs
    $users_with_call_log_count = $other_db
      ->table('user as u')
      ->select(
        'u.user_id',
        'u.name',
        'u.nick_name',
        'u.phone_no',
        'u.user_code',
        'u.is_primary',
        'u.company_id',
        'c.company_name',
        'u.department_id',
        $other_db->raw('SUM(CASE WHEN cl.call_log_id IS NOT NULL THEN 1 ELSE 0 END) as call_log_count') // Sum the call logs
      )
      ->leftJoin('company as c', 'u.company_id', '=', 'c.company_id')  // Join company table
      ->leftJoin('call_log as cl', 'u.user_id', '=', 'cl.user_id')      // Join call_log table
      ->where('u.company_id', 1)  // Filter by company_id
      ->where('cl.count_status', 0)  // Filter by company_id
      ->groupBy(
        'u.user_id',
        'u.name',
        'u.nick_name',
        'u.phone_no',
        'u.user_code',
        'u.is_primary',
        'u.company_id',
        'c.company_name',
        'u.department_id'  // Group by user attributes and company details
      )
      ->get();
    $total = 0;
    foreach ($users_with_call_log_count as $list) {
      $total += $list->call_log_count;
    }


    return $total;
  }
  public function Cronjob_call_log()
  {
      $monitor = CronjobMonitorModel::where('sno', 1)->first();
        $start_time = microtime(true);
        // Get start time in India time
        $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
        if ($monitor) {
          if ($monitor->status != 0) {
            // Stop execution if cron is OFF
            return response()->json([
              'success' => false,
              'message' => 'Cronjob status Off'
            ]);
          }
          $monitor->running_status = 1;
          $monitor->save();
        }
    //   return 'stop';
    $other_db = DB::connection('mysql_secondary');
    $branches = BranchModel::select('sno AS branch_id', 'call_tracker_branch_id')
      ->where('status', 0)
      ->where('call_tracker_branch_id', '>', 0)
      ->get();

    $all_users = []; // Array to store all users with branch_id
    $inserted_records = []; // Array to store inserted records

    foreach ($branches as $branch) {
      $getmobiles = CugManagementModel::select('staff_mobile', 'staff_id')
        ->where('branch_id', $branch->branch_id)
        ->where('status', 0)
        ->get();

      foreach ($getmobiles as $mobile) {
        $select_users = $other_db
          ->table('user as u')
          ->select('u.user_id', 'u.name', 'u.nick_name', 'u.phone_no', 'u.user_code', 'u.status', 'u.company_id', 'c.company_name', 'u.department_id')
          ->leftJoin('company as c', 'u.company_id', '=', 'c.company_id')
          ->where('u.phone_no', $mobile->staff_mobile)
          ->where('u.status', 0)
          ->where('u.company_id', $branch->call_tracker_branch_id)
          ->get();

        if (!$select_users->isEmpty()) {
          foreach ($select_users as $user) {
            $user->branch_id = $branch->branch_id; // Add branch_id to user data
            $user_logs = $other_db
              ->table('call_log as cl')
              ->select('cl.call_log_id', 'cl.count_status', 'cl.contact_book_id', 'cl.call_date', 'cl.call_end_date', 'cl.call_time', 'cl.call_end_time', 'cl.duration', 'cl.latitude', 'cl.longitude', 'cl.status AS log_status', 'cb.phone_no as customer_phone_no', 'cb.contact_name as customer_name', 'cb.reason as customer_reason', 'cb.status as customer_status')
              ->leftJoin('contact_book as cb', 'cl.contact_book_id', '=', 'cb.contact_book_id')
              ->where('cl.user_id', $user->user_id) // Assuming you have user_id in call_log
              ->whereYear('cl.call_date', '>', '2021')
              ->where('cl.count_status', 0)
              ->orderBy('cl.call_date', 'ASC')
              ->limit(10)
              ->get();

            // Add logs to user data
            $user->logs = $user_logs; // Add logs to user data
            // $all_users[] = (array) $user; // Convert object to array and store

            //   return $user_logs;

            // Check if there are logs to insert
            if (!$user_logs->isEmpty()) {
              foreach ($user_logs as $log) {
                $status = $log->log_status;
                $call_duration = $log->duration;

                if ($status === 0 && $call_duration != '00:00:00') {
                  $staus_up = $log->log_status;
                } elseif ($status === 0 && $call_duration == '00:00:00') {
                  $staus_up = 4;
                } else {
                  $staus_up = $log->log_status;
                }
                $record = CallTrackerModel::create([
                  'branch_id' => $branch->branch_id,
                  'branch_staff_id' => $mobile->staff_id ?? 51,
                  'call_tracker_staff_id' => $user->user_id,
                  'staff_phone_no' => $user->phone_no,
                  'customer_phone_no' => $log->customer_phone_no,
                  'customer_name' => $log->customer_name ?: 'Unknown',
                  'customer_status' => $log->customer_status,
                  'customer_reason' => $log->customer_reason,
                  'call_start_date' => $log->call_date,
                  'call_end_date' => $log->call_end_date ?: null,
                  'call_start_time' => $log->call_time,
                  'call_end_time' => $log->call_end_time,
                  'call_duration' => $log->duration,
                  'latitude' => $log->latitude,
                  'longitude' => $log->longitude,
                  'call_status' => $staus_up
                ]);
                $user_logs_upadte = $other_db
                  ->table('call_log')
                  ->where('call_log_id', $log->call_log_id)
                  ->update(['count_status' => 1]);
                // Store inserted record for return
                $inserted_records[] = 1; // Add a count for each inserted record
              }
            }
          }
        }
      }
    }
    $end_time = microtime(true);
        $execution_time = round($end_time - $start_time, 4);
    
        $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
        // Convert seconds ¢ª H:i:s
        $hours   = floor($execution_time / 3600);
        $minutes = floor(($execution_time % 3600) / 60);
        $seconds = $execution_time % 60;
        $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
    
        if ($monitor) {
    
          // Update the monitor
          $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
          $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
          $monitor->sync_duration        = $duration;
          $monitor->running_status       = 0;
          $monitor->save();
    
          // Create a log record
          $monitor_log = new CronjobLogModel();
          $monitor_log->cronjob_id           = $monitor->sno;
          $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
          $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
          $monitor_log->sync_duration        = $duration;
          $monitor_log->response             = json_encode([
            'processed_records' => isset($inserted_records) ? count($inserted_records) : 0,
            'execution_time'    => $duration,
          ]);
          $monitor_log->created_by  = 0;
          $monitor_log->updated_by  = 0;
          $monitor_log->save();
        }
    
        // Return the count of updated records
        return [
          'processed_records' => isset($inserted_records) ? count($inserted_records) : 0,
          'execution_time'    => "{$execution_time} seconds",
        ];
  }
  public function Cronjob_lead_calls_update()
  {
    $monitor = CronjobMonitorModel::where('sno', 2)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $genset = GeneralSettingsModel::where('sno', 1)->first();
    $call_last_fetch_id = $genset ? $genset->call_last_fetch_id : 0;
    //   $call_last_fetch_id =  489497;

    // Fetch uncounted call records
    $getmobiles = DB::table('et_call_tracker as ct')
      ->select('ct.sno', 'ct.call_status', 'ct.call_duration', 'ct.customer_phone_no')
      ->where('ct.count_status', 0)
      ->where('ct.sno', '>=', $call_last_fetch_id)
      ->limit(500)
      ->orderBy('ct.sno', 'ASC')
      ->get();
    //   return $getmobiles;
    $last_fetch_id = $call_last_fetch_id;
    $inserted_records = 0;
    foreach ($getmobiles as $ct) {
      $lead_mobile = $ct->customer_phone_no;
      $phoneWithCountryCode = '+91' . $lead_mobile;
      $phoneWithoutCountryCode = preg_replace('/^\+91/', '', $lead_mobile);

      // Fetch lead details
      $lead_update = LeadModel::where(function ($query) use ($lead_mobile, $phoneWithCountryCode, $phoneWithoutCountryCode) {
        $query->where('lead_mobile', 'LIKE', "%{$lead_mobile}%")
          ->orWhere('lead_mobile', $phoneWithCountryCode)
          ->orWhere('lead_mobile', $phoneWithoutCountryCode);
      })->first();

      // 

      if (isset($lead_update)) {
        //   return $lead_update;
        // continue; // Skip if no lead is found
        // Initialize previous counts
        $old_outgoing = $lead_update->outgoing_count ?? 0;
        $old_incoming = $lead_update->incoming_count ?? 0;
        $old_missed_reject = $lead_update->missed_reject_count ?? 0;
        $old_dialed = $lead_update->dialed_count ?? 0;

        $status = $ct->call_status;

        // Update counts based on call status
        if ($status === 0) {
          $old_outgoing += 1;
        } elseif ($status === 4) {
          $old_dialed += 1;
        } elseif ($status == 1) {
          $old_incoming += 1;
        } elseif ($status == 2 || $status == 3) {
          $old_missed_reject += 1;
        }

        // Update count_status in CallTrackerModel
        $updated = CallTrackerModel::where('sno', $ct->sno)->update(['count_status' => 1]);

        if ($updated > 0) {
          $lead_update->outgoing_count = $old_outgoing;
          $lead_update->dialed_count = $old_dialed;
          $lead_update->incoming_count = $old_incoming;
          $lead_update->missed_reject_count = $old_missed_reject;
          $lead_update->save();
          $inserted_records++;
        }
      }
      $last_fetch_id = $ct->sno;
      GeneralSettingsModel::where('sno', 1)->update(['call_last_fetch_id' => $ct->sno]);
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    
    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
       // Convert seconds ¢ª H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
    
    if ($monitor) {
        
        // Update the monitor
        $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
        $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
        $monitor->sync_duration        = $duration;
        $monitor->running_status       = 0;
        $monitor->save();
    
        // Create a log record
        $monitor_log = new CronjobLogModel();
        $monitor_log->cronjob_id           = $monitor->sno;
        $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
        $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
        $monitor_log->sync_duration        = $duration;
        $monitor_log->response             = json_encode([
                                                'processed_records' => $inserted_records,
                                                'execution_time'    => $duration,
                                            ]);
        $monitor_log->created_by  = 0;
        $monitor_log->updated_by  = 0;
        $monitor_log->save();
    }
    
    // Return the count of updated records
    return [
        'processed_records' => $inserted_records,
        'execution_time'    => "{$execution_time} seconds",
    ];
  }
  public function Cronjob_lead_calls_update_before_days()
  {
    return 'Waiting for Lead enrty';
    $start_time = microtime(true);
    //   $call_last_fetch_id =  489497;

    // Fetch uncounted call records

    $getmobiles = DB::table('et_call_tracker as ct')
      ->select('ct.sno', 'ct.call_status', 'ct.call_duration', 'ct.customer_phone_no')
      ->where('ct.count_status', 0)
      ->whereBetween('ct.call_start_date', [Carbon::now()->subDays(500)->toDateString(), Carbon::now()->toDateString()])
      ->limit(500)
      ->orderBy('ct.sno', 'ASC')
      ->get();

    //   return count($getmobiles);

    // return $getmobiles;
    $inserted_records = 0;
    foreach ($getmobiles as $ct) {
      $lead_mobile = $ct->customer_phone_no;
      $phoneWithCountryCode = '+91' . $lead_mobile;
      $phoneWithoutCountryCode = preg_replace('/^\+91/', '', $lead_mobile);

      // Fetch lead details
      $lead_update = LeadModel::where(function ($query) use ($lead_mobile, $phoneWithCountryCode, $phoneWithoutCountryCode) {
        $query->where('lead_mobile', 'LIKE', "%{$lead_mobile}%")
          ->orWhere('lead_mobile', $phoneWithCountryCode)
          ->orWhere('lead_mobile', $phoneWithoutCountryCode);
      })->first();

      // 

      if (isset($lead_update)) {
        //   return $lead_update;
        // continue; // Skip if no lead is found
        // Initialize previous counts
        $old_outgoing = $lead_update->outgoing_count ?? 0;
        $old_incoming = $lead_update->incoming_count ?? 0;
        $old_missed_reject = $lead_update->missed_reject_count ?? 0;
        $old_dialed = $lead_update->dialed_count ?? 0;

        $status = $ct->call_status;

        // Update counts based on call status
        if ($status === 0) {
          $old_outgoing += 1;
        } elseif ($status === 4) {
          $old_dialed += 1;
        } elseif ($status == 1) {
          $old_incoming += 1;
        } elseif ($status == 2 || $status == 3) {
          $old_missed_reject += 1;
        }

        // Update count_status in CallTrackerModel
        $updated = CallTrackerModel::where('sno', $ct->sno)->update(['count_status' => 1]);

        if ($updated > 0) {
          $lead_update->outgoing_count = $old_outgoing;
          $lead_update->dialed_count = $old_dialed;
          $lead_update->incoming_count = $old_incoming;
          $lead_update->missed_reject_count = $old_missed_reject;
          $lead_update->save();
          $inserted_records++;
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    return [
      'processed_records' => $inserted_records,
      'execution_time' => $execution_time . ' seconds',
    ];
  }
  public function Cronjob_lead_phone_verify()
  {
    $monitor = CronjobMonitorModel::where('sno', 6)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    $Leads = DB::table('et_lead')
      ->select('sno', 'lead_name', 'lead_mobile', 'phone_verify_status', 'inter_calls')
      ->where('phone_verify_status', 0)
      ->limit(1000)
      ->get();

    // Check if leads exist
    if ($Leads->isEmpty()) {
      return response()->json(['message' => 'Lead not found'], 404);
    }
    $inserted_records = 0;

    foreach ($Leads as $lead) {
      $lead_id = $lead->sno;
      $lead_mobile = $lead->lead_mobile;
      if ($lead->inter_calls == 0 || $lead->inter_calls == null || $lead->inter_calls == 91) {
        $countryCode = 'IN';
      } else {
        $countries = DB::table('et_countries')->where('phonecode', $lead->inter_calls)->first();
        if ($countries) {
          $countryCode = $countries->sortname;
        } else {
          $countryCode = 'IN';
        }
      }

      // Fetch lead details
      $lead_update = LeadModel::where('sno', $lead_id)->first();
      if (!$lead_update) {
        continue; // Skip if lead not found
      }

      // API URL
      $url = 'http://apilayer.net/api/validate';
      $accessKey = '60af509a52f854bf5efbf11595874b5c';
      // Determine country code
      // $countryCode = ($lead->inter_calls == 0 || $lead->inter_calls == null) ? '+ 91' : $lead->inter_calls;


      // Set up cURL
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, "{$url}?access_key={$accessKey}&number={$lead_mobile}&country_code={$countryCode}&format=1");
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_TIMEOUT, 30);

      $response = curl_exec($ch);

      // Check for cURL errors
      if (curl_errno($ch)) {
        curl_close($ch);
        return response()->json(['error' => 'cURL error: ' . curl_error($ch)], 500);
      }

      curl_close($ch);
      $data = json_decode($response, true);
      // return $data;
      // Handle API response errors
      if (!$data || !isset($data['valid'])) {
        continue;
      }
      // Update phone verification status
      $lead_update->phone_verify_status  = $data['valid'] ? 1 : 2;
      $lead_update->phone_verify_content = json_encode($data); // Store JSON properly
      $lead_update->save();
      $inserted_records++;
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds ¢ª H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }
  
  // Justdail Lead to Lead 
   public function Cronjob_just_dial_lead()
   {
     $monitor = CronjobMonitorModel::where('sno', 7)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
     $genset = GeneralSettingsModel::where('sno', 1)->first();
     $getLeads = DB::table('et_justdial_lead')
       ->select('*')
       ->where('status', 0)
       ->whereNotNull('parentid') 
       ->limit(300)
       ->orderBy('sno', 'ASC')
       ->get();

     $inserted_records = 0;
     foreach ($getLeads as $jlead) {
       $parentid = $jlead->parentid;
       $branch_get = BranchModel::select('sno', 'other_src_staff_id', 'just_dial_id')
         ->where('just_dial_id', $parentid)
         ->first();
         $leadstaff = DB::table('et_lead_source_mapping')->where('branch_id',$branch_get->sno)->where('source_id',17)->first();
        if($leadstaff){
            $branch_get->other_src_staff_id = $leadstaff->staff_id;
        }
       if ($branch_get && $branch_get->other_src_staff_id) {

         $branch_sno = $branch_get->sno;
         $lead_mobile = $jlead->lead_mobile;
         $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 2;
         // Check if lead already exists
         if (LeadModel::where('lead_mobile', $lead_mobile)->exists()) {

           $lead_update = JustDialModel::where('sno', $jlead->sno)->first();
           $lead_update->status = 3;
           $lead_update->save();
           continue;
         }

         $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
         $branch_code = $branch_check->city_short_code ?? 'MDU';

         $year = date("Y");
         $category_check = LeadModel::where('status', '!=', 2)
           ->orderBy('sno', 'desc')
           ->first();

         if (!$category_check) {
           $lead_id = "{$year}/{$branch_code}/LED0001";
         } else {
           $last_lead_id = $category_check->lead_id;
           $slice = explode("/", $last_lead_id);
           $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
           $next_number = (int)$resultcus + 1;
           $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
         }

         $add_category = new LeadModel();
         $add_category->lead_id = $lead_id;
         $add_category->lead_name = ucfirst($jlead->lead_name);
         $add_category->lead_mobile = $lead_mobile;
         $add_category->lead_alternate_mobile = $jlead->lead_alternate_mobile;
         $add_category->lead_email_id = $jlead->lead_email_id;
         $add_category->lead_knowledge_tags = $jlead->lead_knowledge_tags;
         $add_category->registered_date = $jlead->registered_date;
         $add_category->branch_id = $branch_sno;
         $add_category->lead_source_id = 17;
         $add_category->just_dial_id = $jlead->sno;
         $add_category->created_by = $lead_othr_src_staff;
         $add_category->updated_by = $lead_othr_src_staff;
         $add_category->lead_status_id = 1;
         $add_category->lead_condition = 2;

         if ($add_category->save()) {
           $add_history = new LeadTransferLogModel();
           $add_history->lead_id = $add_category->sno;
           $add_history->branch_id = $add_category->branch_id;
           $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
           $add_history->current_staff_id = $add_category->created_by;
           $add_history->change_staff_id = 0;
           $add_history->end_date = null;
           $add_history->transferred_from = 12;
           $add_history->created_by = $lead_othr_src_staff;
           $add_history->updated_by = $lead_othr_src_staff;
           $add_history->save();

           $lead_update = JustDialModel::where('sno', $jlead->sno)->first();

           $lead_update->status = 2;
           $lead_update->save();

           $inserted_records++;
         }

         $branch_data = BranchModel::where('sno', $branch_sno)->first();
         $branch_name = " ";
         if ($branch_data->branch_type == 1) {
           $branch_name = $branch_data->branch_name;
         } elseif ($branch_data->branch_type == 2) {
           $branch_name = $branch_data->franchise_name;
         }
         $lead_name = ucfirst($jlead->lead_name);
         $lead_email_id = $jlead->lead_email_id;
         $entityData='';
        // communication Send
        $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$lead_othr_src_staff)->first();
        $communicationStatus=DB::table('et_communication_handle')->where('module_name','Lead Welcome')->first();
            if($communicationStatus && $communicationStatus->status == 0){
            // // sms thank you lead
            if($communicationStatus->sms ==0){
                if ($add_category && $lead_mobile) {
    
              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', 'PhDiZone_Enquiry_Thankyou_Message')->first();
              $authkey = $result_sms ? $result_sms->authkey : '';
              $sender_id = $result_sms ? $result_sms->sender_id : '';
              $template_id = $result_sms ? $result_sms->template_id : '';
              $country_code = $result_sms ? $result_sms->country_code : '';
              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
              $mobile_number = $country_code . $lead_mobile;
    
              $cre_mobile = $branch_data->cre_mobile ?? '9677781155';
    
              // Replace placeholders with actual values
              $replacement_values = [$lead_name,$branch_name, $cre_mobile];
              $message_content = preg_replace_callback(
                '/\{#var#\}/',
                function () use (&$replacement_values) {
                  return array_shift($replacement_values);
                },
                $message_content
              );
    
              $route = "default";
              $postData = array(
                'authkey' => $authkey,
                'mobiles' => $mobile_number,
                'message' => $message_content,
                'sender' => $sender_id,
                'route' => $route,
              );
    
              // API URL
              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
    
              // Initialize the resource
              $ch = curl_init();
              curl_setopt_array($ch, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $postData,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
              ));
    
              // Get response
              $response = curl_exec($ch);
              // return $response;
              $err = curl_error($ch);
              curl_close($ch);
            }
            }
            // // Thank you email send
            if($communicationStatus->email ==0){
                if ($add_category && $lead_email_id) {
              $email_template_id = 2; // thank you template
              $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                $dynamicSubject = str_replace('#entity_name','Elysium Technology', $emailTemplate->email_name);
              $content = $emailTemplate->email_subject;
              $content = str_replace('#lead_name', $lead_name, $content);
              $branchNo = $branch_data->mobile;
              $branchemail = $branch_data->mail;
              $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/PhDiZone/';
              $instaLink = $branch_data->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
              $content = str_replace('#sales_mobile', $cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile, $content);
              $content = str_replace('#cre_mobile', $branch_data->cre_mobile ?? '8220011465', $content);
              $url= 'phdizone.com';
              $mailData = [
                          'url'         => $url,
                          'subject'     => $dynamicSubject,
                          'content'     => $content,
                          'branchNo'    => $branchNo,
                          'branchemail' => $branchemail, // Use the message content from the request
                          'fbLink'      => $fbLink,      // Use the message content from the request
                          'instaLink'   => $instaLink,   // Use the message content from the request
                          'salesMobile' => $branch_data->cre_mobile ?? '9003400111',
                      ];
    
                $to_address = $lead_email_id;
                $from_address = 'elysiumtechnology@elysium.community';
                $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
        
                Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
            }
        }
            // // Thank You whatsapp message
            if($communicationStatus->whatsapp ==0){
                if ($add_category && $lead_mobile) {
                  $templateName = "welcome_msg_phdizone";
        
                  $hasHeader  = false; // Example flag: set based on template
                  $hasBody    = false; // Example flag: set based on template
                  $hasFooter  = false; // Example flag: set based on template
                  $hasButton  = false;
                  $components = [];
                  $couponCode = " ";
                  date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                  $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                  // $currentHour = date('H'); // Get current hour in 24-hour format
                  if ($currentHour >= 5 && $currentHour < 12) {
                    $greeting = 'Good Morning';
                  } elseif ($currentHour >= 12 && $currentHour < 18) {
                    $greeting = 'Good Afternoon';
                  } else {
                    $greeting = 'Good Evening';
                  }
        
                  if ($templateName == 'welcome_msg_phdizone') {
        
                    $headerImage = 'https://dev.erp.elysiumtechnologies.com/public/assets/phdizone_images/Thank-You.jpg';
                    $couponCode  = 'NOOFFER';
                    $buttonIndex = 0;
                    $bodyText    = [
                      [
                        'type'           => 'text',
                        'text'           => $lead_name,
                        'parameter_name' => 'lead_name',
                      ],
                       [
                        'type'           => 'text',
                        'text'           => $cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile,
                        'parameter_name' => 'sales_numbers',
                      ]
                      
                    ];
                    $hasHeader = true;
                    $hasBody   = true;
                  }
        
                  // Add Header if required
                  if ($hasHeader) {
                    $components[] = [
                      'type'       => 'header',
                      'parameters' => [
                        [
                          'type'  => 'image',
                          'image' => [
                            'link' => $headerImage, // Dynamically set header image
                          ],
                        ],
                      ],
                    ];
                  }
        
                  // Add Body if required
                  if ($hasBody) {
                    $components[] = [
                      'type'       => 'body',
                      'parameters' => $bodyText,
                    ];
                  }
        
                  // Add Footer if required
                  if ($hasFooter) {
                    $components[] = [
                      'type'       => 'footer',
                      'parameters' => [
                        [
                          'type'           => 'text',
                          'text'           => 'This is the footer text.',
                          'parameter_name' => 'footer_text',
                        ],
                      ],
                    ];
                  }
        
                  // Add Button if required
                  if ($hasButton) {
                    $components[] = [
                      'type'       => 'button',
                      'sub_type'   => 'copy_code',
                      'index'      => $buttonIndex,
                      'parameters' => [
                        [
                          'type'        => 'coupon_code',
                          'coupon_code' => $couponCode,
                        ],
                      ],
                    ];
                  }
        
                  $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch_data->entity_id)->orderBy('sno', 'desc')->first();
                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                $accessToken               = $whatsappApi->access_tokken ?? '';
                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
        
                  $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
    
                    $inter_calls = '91';
                   $countryCode  = $inter_calls ? ($inter_calls == 0 ? '+91' : '+' . $inter_calls) : '+91';
                    $to           = $lead_mobile;
                    $languageCode = 'en';
        
                    if (strpos($to, $countryCode) !== 0) {
                        $to = $countryCode . $to;
                    }
        
                  $message = 'test~message';
                  if (empty($components)) {
                    $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                        'name'     => $templateName,
                        'language' => [
                          'code' => $languageCode,
                        ],
                      ],
                    ];
                  } else {
                    $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                        'name'       => $templateName,
                        'language'   => [
                          'code' => $languageCode,
                        ],
                        'components' => $components,
                      ],
                    ];
                  }
    
              $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                }
            }
        }
       }
     }

     $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds ¢ª H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
   }
    public function Cronjob_hot_lead_update()
    {
        $monitor = CronjobMonitorModel::where('sno', 9)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    $inserted_records = 0;
        $genset = GeneralSettingsModel::where('sno', 1)->first();
    
        if ($genset && $genset->hot_lead_days) {
            $hot_lead_day = $genset->hot_lead_days;
            $before_date  = date('Y-m-d', strtotime("-$hot_lead_day days"));
    
            $get_leads = DB::table('et_lead')
                ->select('sno', 'last_hot_lead_date', 'lead_status_id', 'status', 'lead_name', 'created_by', 'branch_id')
                ->where('last_hot_lead_date', '<', $before_date)  // 'last_hot_lead_date' less than $before_date
                ->where('lead_status_id', 3)
                ->get();

    
            foreach ($get_leads as $lead) {
                $hot = new HotLeadModel();
                $hot->branch_id = $lead->branch_id;
                $hot->lead_id = $lead->sno;
                $hot->staff_id = $lead->created_by;
                $hot->startdate = $lead->last_hot_lead_date;
                $hot->enddate = date('Y-m-d');
                $hot->created_by = $lead->created_by;
                $hot->updated_by = $lead->created_by;
                $hot->save();
    
                if ($hot) {
                    $lead_update = LeadModel::where('sno', $lead->sno)->first();
                    if ($lead_update) {
                        $lead_update->lead_status_id = 2;
                        $lead_update->is_hot_lead = 2;
                        $lead_update->last_hot_lead_date = null;
                        $lead_update->save();
                        $inserted_records++;
                    }
                }
            }
        }
    
        $end_time = microtime(true);
        $execution_time = round($end_time - $start_time, 4);
        
        $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
           // Convert seconds ¢ª H:i:s
        $hours   = floor($execution_time / 3600);
        $minutes = floor(($execution_time % 3600) / 60);
        $seconds = $execution_time % 60;
        $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
        
        if ($monitor) {
            
            // Update the monitor
            $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
            $monitor->sync_duration        = $duration;
            $monitor->running_status       = 0;
            $monitor->save();
        
            // Create a log record
            $monitor_log = new CronjobLogModel();
            $monitor_log->cronjob_id           = $monitor->sno;
            $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_duration        = $duration;
            $monitor_log->response             = json_encode([
                                                    'processed_records' => $inserted_records,
                                                    'execution_time'    => $duration,
                                                ]);
            $monitor_log->created_by  = 0;
            $monitor_log->updated_by  = 0;
            $monitor_log->save();
        }
        
        // Return the count of updated records
        return [
            'processed_records' => $inserted_records,
            'execution_time'    => "{$execution_time} seconds",
        ];
    }
    public function Cronjob_CloseInCompleteExam()
    {
        $monitor = CronjobMonitorModel::where('sno', 16)->first();
        $start_time = microtime(true);
        $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    
        if ($monitor) {
            if ($monitor->status != 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cronjob status Off'
                ]);
            }
            $monitor->running_status = 1;
            $monitor->save();
        }
    
        $processlist = DB::table('et_exam_process')->where('status', '!=', 2)->get();
        $inserted_records = 0;
    
        foreach ($processlist as $list) {
            $exam_data = DB::table('et_manage_exam')->where('sno', $list->exam_id)->first();
            $exam_duration_in_min = (int)($exam_data->duration ?? 0);
    
            if ($exam_duration_in_min > 0) {
                // ✅ DB stores IST timestamps → parse as Asia/Kolkata
                $created_time = Carbon::parse($list->created_at, 'Asia/Kolkata');
                $exam_end_time = $created_time->copy()->addMinutes($exam_duration_in_min);
                $current_time = now('Asia/Kolkata');
    
                // 🪵 Debug log
                // \Log::info('Exam Time Check', [
                //     'exam_id'       => $list->exam_id,
                //     'created_time'  => $created_time->toDateTimeString(),
                //     'exam_end_time' => $exam_end_time->toDateTimeString(),
                //     'current_time'  => $current_time->toDateTimeString(),
                //     'is_expired'    => $current_time->greaterThan($exam_end_time) ? 'YES' : 'NO'
                // ]);
    
                // ✅ Close expired exams
                if ($current_time->greaterThan($exam_end_time)) {
                    $update = ExamProcessModel::find($list->sno);
                    if ($update && $update->status != 2) {
    
                        // ⏱ Calculate total attended duration
                        $diffInSeconds = $created_time->diffInSeconds($current_time);
                        $hours = floor($diffInSeconds / 3600);
                        $minutes = floor(($diffInSeconds % 3600) / 60);
                        $seconds = $diffInSeconds % 60;
                        $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
    
                        $update->completed_date = $current_time;
                        $update->status = 2;
                        $update->total_attended_duration = $duration;
                        $update->save();
    
                        $inserted_records++;
                    }
                }
            }
        }
    
        // 🕒 Calculate total cron execution time
        $end_time = microtime(true);
        $execution_time = round($end_time - $start_time, 4);
        $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    
        // Convert seconds → H:i:s
        $hours = floor($execution_time / 3600);
        $minutes = floor(($execution_time % 3600) / 60);
        $seconds = $execution_time % 60;
        $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
    
        // 🪵 Update monitor and create log
        if ($monitor) {
            $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
            $monitor->sync_duration        = $duration;
            $monitor->running_status       = 0;
            $monitor->save();
    
            $monitor_log = new CronjobLogModel();
            $monitor_log->cronjob_id           = $monitor->sno;
            $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_duration        = $duration;
            $monitor_log->response             = json_encode([
                'processed_records' => $inserted_records,
                'execution_time'    => $duration,
            ]);
            $monitor_log->created_by  = 0;
            $monitor_log->updated_by  = 0;
            $monitor_log->save();
        }
    
        return [
            'processed_records' => $inserted_records,
            'execution_time'    => "{$execution_time} seconds",
        ];
    }



  // Sulekha Lead To Lead
  // public function Cronjob_sulekha_lead()
  // {
  //   $start_time = microtime(true);

  //   $genset = GeneralSettingsModel::where('sno', 1)->first();


  //   $getLeads = DB::table('et_sulekha_lead')
  //     ->select('*')
  //     ->where('status', 0)
  //     //   ->where('sno', 39)
  //     ->limit(1000)
  //     ->orderBy('sno', 'ASC')
  //     ->get();

  //   // return $getLeads;

  //   $inserted_records = 0;
  //   foreach ($getLeads as $slead) {
  //     $branch_id = 6;
  //     $branch_get = BranchModel::select('sno', 'other_src_staff_id', 'sulekha_id')
  //       ->where('sulekha_id', $branch_id)
  //       ->first();
  //     // return $branch_get;

  //     if ($branch_get && $branch_get->other_src_staff_id) {

  //       $branch_sno = $branch_get->sno;
  //       $lead_mobile = $slead->lead_mobile;
  //       $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 123;
  //       // Check if lead already exists
  //       if (LeadModel::where('lead_mobile', $lead_mobile)->exists()) {

  //         $lead_update = SulekhaModel::where('sno', $slead->sno)->first();
  //         $lead_update->status = 3;
  //         $lead_update->save();
  //         continue;
  //       }
  //       // return $lead_update;

  //       $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
  //       $branch_code = $branch_check->city_short_code ?? 'MDU';

  //       $year = date("Y");
  //       $category_check = LeadModel::where('status', '!=', 2)
  //         ->orderBy('sno', 'desc')
  //         ->first();

  //       if (!$category_check) {
  //         $lead_id = "{$year}/{$branch_code}/LED0001";
  //       } else {
  //         $last_lead_id = $category_check->lead_id;
  //         $slice = explode("/", $last_lead_id);
  //         $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
  //         $next_number = (int)$resultcus + 1;
  //         $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
  //       }

  //       // return $branch_check;
  //       $add_category = new LeadModel();
  //       $add_category->lead_id = $lead_id;
  //       $add_category->lead_name = ucfirst($slead->lead_name);
  //       $add_category->lead_mobile = $lead_mobile;
  //       // $add_category->lead_alternate_mobile = $slead->lead_alternate_mobile;
  //       $add_category->lead_email_id = $slead->lead_email;
  //       $add_category->lead_knowledge_tags = $slead->category;
  //       $add_category->registered_date = $slead->created_at;
  //       $add_category->branch_id = $branch_sno;
  //       $add_category->lead_source_id = 6;
  //       $add_category->sulekha_id = $slead->sno;
  //       $add_category->created_by = $lead_othr_src_staff;
  //       $add_category->updated_by = $lead_othr_src_staff;
  //       $add_category->lead_status_id = 1;
  //       $add_category->lead_condition = 2;



  //       if ($add_category->save()) {
  //         // return $add_category;
  //         $add_history = new LeadTransferLogModel();
  //         $add_history->lead_id = $add_category->sno;
  //         $add_history->branch_id = $add_category->branch_id;
  //         $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
  //         $add_history->current_staff_id = $add_category->created_by;
  //         $add_history->change_staff_id = 0;
  //         $add_history->end_date = null;
  //         $add_history->transferred_from = 14;
  //         $add_history->created_by = $lead_othr_src_staff;
  //         $add_history->updated_by = $lead_othr_src_staff;

  //         // return $add_history;
  //         $add_history->save();

  //         $lead_update = SulekhaModel::where('sno', $slead->sno)->first();

  //         $lead_update->status = 2;
  //         $lead_update->save();

  //         $inserted_records++;
  //       }

  //       $branch_data = BranchModel::where('sno', $branch_sno)->first();

  //       // return $branch_data;
  //       $branch_name = " ";
  //       if ($branch_data->branch_type == 1) {
  //         $branch_name = $branch_data->branch_name;
  //       } elseif ($branch_data->branch_type == 2) {
  //         $branch_name = $branch_data->franchise_name;
  //       }
  //       $lead_name = ucfirst($slead->lead_name);
  //       $lead_email_id = $slead->lead_email;

  //       // return $lead_email_id;

  //       // sms thank you lead
  //       if ($add_category && $lead_mobile) {

  //         $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
  //         $authkey = $result_sms ? $result_sms->authkey : '';
  //         $sender_id = $result_sms ? $result_sms->sender_id : '';
  //         $template_id = $result_sms ? $result_sms->template_id : '';
  //         $country_code = $result_sms ? $result_sms->country_code : '';
  //         $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
  //         $mobile_number = $country_code . $lead_mobile;

  //         $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

  //         // Replace placeholders with actual values
  //         $replacement_values = [$lead_name, $cre_mobile];
  //         $message_content = preg_replace_callback(
  //           '/\{#var#\}/',
  //           function () use (&$replacement_values) {
  //             return array_shift($replacement_values);
  //           },
  //           $message_content
  //         );

  //         $route = "default";
  //         $postData = array(
  //           'authkey' => $authkey,
  //           'mobiles' => $mobile_number,
  //           'message' => $message_content,
  //           'sender' => $sender_id,
  //           'route' => $route,
  //         );

  //         // API URL
  //         $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

  //         // Initialize the resource
  //         $ch = curl_init();
  //         curl_setopt_array($ch, array(
  //           CURLOPT_URL => $url,
  //           CURLOPT_RETURNTRANSFER => true,
  //           CURLOPT_POST => true,
  //           CURLOPT_POSTFIELDS => $postData,
  //           CURLOPT_SSL_VERIFYHOST => 0,
  //           CURLOPT_SSL_VERIFYPEER => 0,
  //         ));

  //         // Get response
  //         $response = curl_exec($ch);
  //         // return $response;
  //         $err = curl_error($ch);
  //         curl_close($ch);
  //       }
  //       // Thank you email send
  //       if ($add_category && $slead->lead_email) {
  //         $email_template_id = 6; // thank you template
  //         $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

  //         $content = $emailTemplate->email_subject;
  //         $content = str_replace('#name', $lead_name, $content);
  //         $content = str_replace('#webLink', $branch_data->website ?? 'https://elysiumacademy.org/', $content);
  //         $branchNo = $branch_data->mobile;
  //         $branchemail = $branch_data->mail;
  //         $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
  //         $instaLink = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
  //         $content = str_replace('#salesNo', $branch_data->sales_mobile ?? '9677781155', $content);
  //         $content = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
  //         $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
  //         $content = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

  //         $mailData = [
  //           'url' => 'Eapl.com',
  //           'subject' => $emailTemplate->email_name,
  //           'content' => $content,
  //           'branchNo' => $branchNo,
  //           'branchemail' => $branchemail, // Use the message content from the request
  //           'fbLink' => $fbLink, // Use the message content from the request
  //           'instaLink' => $instaLink, // Use the message content from the request
  //           'salesMobile' => $branch_data->sales_mobile,
  //         ];

  //         $to_address = $lead_email_id;
  //         $from_address = 'elysiumacademy@elysium.community';
  //         $from_name = 'Elysium AcademyÂ®';
  //         Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
  //       }
  //       // whatsapp message
  //       if ($add_category && $lead_mobile) {
  //         $templateName = "elysium_academy_welcome_message";

  //         $hasHeader  = false; // Example flag: set based on template
  //         $hasBody    = false; // Example flag: set based on template
  //         $hasFooter  = false; // Example flag: set based on template
  //         $hasButton  = false;
  //         $components = [];
  //         $couponCode = " ";
  //         date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
  //         $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
  //         // $currentHour = date('H'); // Get current hour in 24-hour format
  //         if ($currentHour >= 5 && $currentHour < 12) {
  //           $greeting = 'Good Morning';
  //         } elseif ($currentHour >= 12 && $currentHour < 18) {
  //           $greeting = 'Good Afternoon';
  //         } else {
  //           $greeting = 'Good Evening';
  //         }

  //         if ($templateName == 'elysium_academy_welcome_message') {

  //           $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
  //           $couponCode  = 'NOOFFER';
  //           $buttonIndex = 0;
  //           $bodyText    = [
  //             [
  //               'type'           => 'text',
  //               'text'           => $greeting,
  //               'parameter_name' => 'greet_msg',
  //             ],
  //             [
  //               'type'           => 'text',
  //               'text'           => $lead_name,
  //               'parameter_name' => 'customer_name',
  //             ],
  //             [
  //               'type'           => 'text',
  //               'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
  //               'parameter_name' => 'web_link',
  //             ],
  //             [
  //               'type'           => 'text',
  //               'text'           => $branch_name,
  //               'parameter_name' => 'branch_name',
  //             ],
  //             [
  //               'type'           => 'text',
  //               'text'           => $branch_data->cre_mobile ?? '7708053111',
  //               'parameter_name' => 'contact_no',
  //             ],
  //             [
  //               'type'           => 'text',
  //               'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
  //               'parameter_name' => 'contact_email',
  //             ],
  //           ];
  //           $hasHeader = true;
  //           $hasBody   = true;
  //           $hasButton = true;
  //         }

  //         // Add Header if required
  //         if ($hasHeader) {
  //           $components[] = [
  //             'type'       => 'header',
  //             'parameters' => [
  //               [
  //                 'type'  => 'image',
  //                 'image' => [
  //                   'link' => $headerImage, // Dynamically set header image
  //                 ],
  //               ],
  //             ],
  //           ];
  //         }

  //         // Add Body if required
  //         if ($hasBody) {
  //           $components[] = [
  //             'type'       => 'body',
  //             'parameters' => $bodyText,
  //           ];
  //         }

  //         // Add Footer if required
  //         if ($hasFooter) {
  //           $components[] = [
  //             'type'       => 'footer',
  //             'parameters' => [
  //               [
  //                 'type'           => 'text',
  //                 'text'           => 'This is the footer text.',
  //                 'parameter_name' => 'footer_text',
  //               ],
  //             ],
  //           ];
  //         }

  //         // Add Button if required
  //         if ($hasButton) {
  //           $components[] = [
  //             'type'       => 'button',
  //             'sub_type'   => 'copy_code',
  //             'index'      => $buttonIndex,
  //             'parameters' => [
  //               [
  //                 'type'        => 'coupon_code',
  //                 'coupon_code' => $couponCode,
  //               ],
  //             ],
  //           ];
  //         }

  //         $dynamicParameters         = $templateParameters[$templateName] ?? [];
  //         $WhatsAppBusinessAccountId = $this->businessId;
  //         $accessToken               = $this->accessToken;
  //         $fromPhoneNumberId         = $this->phoneNumberId;

  //         $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

  //         $to           = $lead_mobile;
  //         $languageCode = 'en_US';

  //         if (strpos($to, '+91') !== 0) {
  //           $to = '+91' . $to;
  //         }

  //         $message = 'test~message';
  //         if (empty($components)) {
  //           $payload = [
  //             'messaging_product' => 'whatsapp',
  //             'to'                => $to,
  //             'type'              => 'template',
  //             'template'          => [
  //               'name'     => $templateName,
  //               'language' => [
  //                 'code' => $languageCode,
  //               ],
  //             ],
  //           ];
  //         } else {
  //           $payload = [
  //             'messaging_product' => 'whatsapp',
  //             'to'                => $to,
  //             'type'              => 'template',
  //             'template'          => [
  //               'name'       => $templateName,
  //               'language'   => [
  //                 'code' => $languageCode,
  //               ],
  //               'components' => $components,
  //             ],
  //           ];
  //         }

  //         $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
  //       }
  //     }
  //   }

  //   $end_time = microtime(true);
  //   $execution_time = round($end_time - $start_time, 4);

  //   return [
  //     'processed_records' => $inserted_records,
  //     'execution_time' => "{$execution_time} seconds",
  //   ];
  // }
    public function JournalToHistory()
  {
    $journals = DB::table('et_manage_journal')
      ->where('status', '!=', 2)
      ->get();
 
    $count = 0;
 
    foreach ($journals as $jl) {
 
      // Check if this record already exists in history
      $exists = JournalHistoryModel::where([
        ['branch_id', $jl->branch_id],
        ['customer_id', $jl->customer_id],
        ['service_id', $jl->service_id],
        ['journal_id', $jl->sno],
      ])->exists();
 
      // If already exists → skip
      if ($exists) {
        continue;
      }
 
      // Insert only non-duplicate
      JournalHistoryModel::create([
        'branch_id'            => $jl->branch_id,
        'customer_id'          => $jl->customer_id,
        'service_id'           => $jl->service_id,
        'journal_id'           => $jl->sno,
        'submitted_date'       => $jl->submited_date,
        'submitted_documents'  => $jl->documents,
        'created_by'           => $jl->created_by,
        'updated_by'           => $jl->updated_by,
        'created_at'           => $jl->created_at,
        'updated_at'           => $jl->updated_at,
      ]);
 
      $count++;
    }
 
    return "Inserted $count non-duplicate records.";
  }
}