<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\DepartmentModel;
use App\Models\GoalSetTeamModel;
use App\Models\ManageTargetModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use stdClass;

class Dashboards extends Controller
{
    public function index()
    {
        return view('content.dashboard.dashboards');
    }
    public function getSaleExcDashboardData(Request $request)
    {
        $user = $request->user();
        $userId = $user->user_id;
        $BranchId = $user->branch_id;
        $dateFilter = $request->get('date_filter');
        $helper = new \App\Helpers\Helpers();

        try {
            $date = Carbon::createFromFormat('M-Y', $dateFilter);
            $month = $date->month;
            $year = $date->year;
        } catch (\Exception $e) {
            $date = Carbon::now();
            $month = $date->month;
            $year = $date->year;
        }

        $today = date('Y-m-d');
        $prevMonthDate = Carbon::create($year, $month, 1)->subMonth();
        $prevMonth = $prevMonthDate->month;
        $prevYear = $prevMonthDate->year;
        $yesterday = Carbon::yesterday()->format('Y-m-d');

        // Helper function for percentage calculation
        $calculatePercentage = function ($current, $previous) {
            if ($previous == 0) {
                return $current > 0 ? 100 : 0;
            }
            return (($current - $previous) / $previous) * 100;
        };

        // Helper function for color determination
        $getColor = function ($current, $previous) {
            if ($current > $previous) return 'success';
            if ($current < $previous) return 'warning';
            if ($current < 1) return 'danger';
            return 'danger';
        };

        // Helper function for GST calculation (18%)
        $calculateBaseAmount = function ($amount) {
            $gstPercent = 18;
            return $amount / (1 + ($gstPercent / 100));
        };

        // 1. TOTAL LEADS
        // $totalLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
        //   ->where('et_lead.created_by', $userId)
        //   ->whereNotIn('et_lead.status', [2, 6])
        //   ->whereYear('et_lead.registered_date', $year)
        //   ->whereMonth('et_lead.registered_date', $month)
        //   ->count();

        $totalLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $totalLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->whereNotIn('et_lead.status', [2, 6])
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->count();

        $totalLeadsPercentage = $calculatePercentage($totalLeadsCurrent, $totalLeadsPrev);
        $totalLeadsColor = $getColor($totalLeadsCurrent, $totalLeadsPrev);

        // 2. ACTIVE LEADS
        $activeLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $activeLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $activeLeadsPercentage = $calculatePercentage($activeLeadsCurrent, $activeLeadsPrev);
        $activeLeadsColor = $getColor($activeLeadsCurrent, $activeLeadsPrev);

        // 3. SPAM LEADS
        $spamLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.status', 7)
            ->count();

        $spamLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.status', 7)
            ->count();

        $spamLeadsPercentage = $calculatePercentage($spamLeadsCurrent, $spamLeadsPrev);
        $spamLeadsColor = $getColor($spamLeadsCurrent, $spamLeadsPrev);

        // 4. DEAD LEADS
        $deadLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.status', 5)
            ->count();

        $deadLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.status', 5)
            ->count();

        $deadLeadsPercentage = $calculatePercentage($deadLeadsCurrent, $deadLeadsPrev);
        $deadLeadsColor = $getColor($deadLeadsCurrent, $deadLeadsPrev);

        // 5. CONVERTED CUSTOMERS
        $convertedCustomersCurrent = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();

        $convertedCountCurrent = count($convertedCustomersCurrent);

        $convertedCustomersPrev = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_payment.transaction_date', $prevYear)
            ->whereMonth('et_payment.transaction_date', $prevMonth)
            ->where('et_transaction.payment_status', 1)
            ->count();

        $convertedPercentage = $calculatePercentage($convertedCountCurrent, $convertedCustomersPrev);
        $convertedColor = $getColor($convertedCountCurrent, $convertedCustomersPrev);

        // 6. CONVERSION RATIO
        $totalLeadsForRatio = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->count();

        $conversionRatioCurrent = $totalLeadsForRatio > 0 ?
            ($convertedCountCurrent / $totalLeadsForRatio) * 100 : 0;
        $conversionRatioCurrent = number_format($conversionRatioCurrent, 2);

        // 7. ABV & ACV Calculation
        $totalBusinessValue = 0;
        $totalCollectionValue = 0;
        $baseAmountPaid = 0;
        $total_payment = 0;
        $total_paid_payment = 0;
        $base_amount_paid = 0;
        $gst_percent = 18;

        if ($convertedCountCurrent > 0 && $convertedCustomersCurrent->isNotEmpty()) {
            foreach ($convertedCustomersCurrent as $customer) {
                $proposalIds = DB::table('et_proposal')
                    ->where('et_proposal.customer_id', $customer->sno)
                    ->where('et_proposal.status', 0)
                    ->whereNot('et_proposal.post_sale_check', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->pluck('sno')
                    ->toArray();

                if (!empty($proposalIds)) {
                    $proposals = DB::table('et_proposal')
                        ->select('et_proposal.*', 'et_country_currencies.currency_code')
                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                        ->whereIn('et_proposal.sno', $proposalIds)
                        ->get();

                    foreach ($proposals as $proposal) {
                        $paidAmount = DB::table('et_proposal_pay_slot')
                            ->where('proposal_sno', $proposal->sno)
                            ->where('status', 0)
                            ->sum('paidAmount');

                        $grantAmount = $proposal->grant_total_amount;

                        // Calculate base amount (excluding GST)
                        $basePaidLocal = $calculateBaseAmount($paidAmount);

                        if ($proposal->currency_id == 70) {
                            // INR
                            $totalBusinessValue += $grantAmount;
                            $totalCollectionValue += $paidAmount;
                            $baseAmountPaid += $basePaidLocal;

                            $total_payment += $grantAmount;
                            $total_paid_payment += $paidAmount;
                            $base_amount_paid += $basePaidLocal;
                        } else {
                            // Non-INR - You need to implement currency conversion
                            $currency_code = $proposal->currency_code;
                            $convertedPaidAmount = $helper->ConvertedAmountInr($currency_code, $paidAmount);
                            $convertedGrantAmount = $helper->ConvertedAmountInr($currency_code, $grantAmount);
                            $convertedBaseAmount = $helper->ConvertedAmountInr($currency_code, $basePaidLocal);

                            $total_paid_payment += $convertedPaidAmount;
                            $total_payment += $convertedGrantAmount;
                            $base_amount_paid += $convertedBaseAmount;
                        }
                    }
                }
            }
        }

        $averageBusinessValue = $convertedCountCurrent > 0 ?
            $totalBusinessValue / $convertedCountCurrent : 0;
        $averageCollectionValue = $convertedCountCurrent > 0 ?
            $baseAmountPaid / $convertedCountCurrent : 0;

        // 8. TODAY'S CONVERSIONS
        $convertedToday = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $userId)
            ->whereDate('et_payment.transaction_date', $today)
            ->where('et_transaction.payment_status', 1)
            ->count();

        // 9. APPOINTMENTS
        $appointmentsToday = DB::table('et_lead_appointment')
            ->where('created_by', $userId)
            ->whereYear('appointment_date', $year)
            ->whereMonth('appointment_date', $month)
            ->count();

        $appointmentsYesterday = DB::table('et_lead_appointment')
            ->where('staff_id', $userId)
            ->whereYear('appointment_date', $prevYear)
            ->whereMonth('appointment_date', $prevMonth)
            ->count();

        $appointmentsPercentage = $calculatePercentage($appointmentsToday, $appointmentsYesterday);
        $appointmentsNeg = $appointmentsPercentage < 0;
        $appointmentsPercentage = abs(round($appointmentsPercentage, 1));

        // 10. WALK-INS
        $walkInsToday = DB::table('et_lead_appointment')
            ->where('appointment_category', 3)
            ->whereDate('created_at', $today)
            ->where('staff_id', $userId)
            ->count();

        $walkInsYesterday = DB::table('et_lead_appointment')
            ->where('appointment_category', 3)
            ->whereDate('created_at', $yesterday)
            ->where('staff_id', $userId)
            ->count();

        $walkInsPercentage = $calculatePercentage($walkInsToday, $walkInsYesterday);
        $walkInsNeg = $walkInsPercentage < 0;
        $walkInsPercentage = abs(round($walkInsPercentage, 1));

        // 11. FOLLOW-UPS
        $followUpsToday = DB::table('et_appointment')
            ->whereDate('appointment_date', $today)
            ->where('created_by', $userId)
            ->count();

        $followUpsYesterday = DB::table('et_appointment')
            ->whereDate('appointment_date', $yesterday)
            ->where('created_by', $userId)
            ->count();

        $followUpsPercentage = $calculatePercentage($followUpsToday, $followUpsYesterday);
        $followUpsNeg = $followUpsPercentage < 0;
        $followUpsPercentage = abs(round($followUpsPercentage, 1));

        // 12. OUTGOING CALLS
        $outgoingCallsToday = DB::table('et_call_tracker')
            ->where('branch_staff_id', $userId)
            ->where('call_status', 0)
            ->whereDate('call_start_date', $today)
            ->count();

        $outgoingCallsYesterday = DB::table('et_call_tracker')
            ->where('branch_staff_id', $userId)
            ->where('call_status', 0)
            ->whereDate('call_start_date', $yesterday)
            ->count();

        $outgoingCallsPercentage = $calculatePercentage($outgoingCallsToday, $outgoingCallsYesterday);
        $outgoingCallsNeg = $outgoingCallsPercentage < 0;
        $outgoingCallsPercentage = abs(round($outgoingCallsPercentage, 1));

        // 13. ODC, MC, OMC Calculations
        $odcCount = $this->calculateODC($userId, $month, $year);
        $mcCount = $this->calculateMC($userId, $month, $year);
        $omcCount = $this->calculateOMC($userId, $month, $year);

        // Appointment Schedule
        $appointmentToday = DB::table('et_lead_appointment')
            ->select('et_lead_appointment.*', 'et_lead.lead_name', 'et_lead.lead_id as lead_ai_id')
            ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_lead_appointment.lead_id')
            ->whereDate('et_lead_appointment.appointment_date', date('Y-m-d'))
            ->where('et_lead_appointment.created_by', $userId)
            ->orderBy('et_lead_appointment.lead_id')
            ->orderBy('et_lead_appointment.appointment_date', 'asc')
            ->get();

        $appointmentFilter = collect();
        $seenLeads = [];

        foreach ($appointmentToday as $app) {
            $lead_id = $app->lead_id;

            if (isset($seenLeads[$lead_id])) continue;

            $appCompleted = $app->appointment_status == 2;
            $appRescheduled = $app->appointment_status == 4;
            $appScheduled = $app->appointment_status == 1;

            if ($appCompleted) {
                $app->app_status = 'Completed';
                $seenLeads[$lead_id] = true;
                $appointmentFilter->push($app);
            } elseif ($appRescheduled) {
                $app->app_status = 'Rescheduled';
                $seenLeads[$lead_id] = true;
                $appointmentFilter->push($app);
            } elseif ($appScheduled) {
                $app->app_status = 'Scheduled';
                $seenLeads[$lead_id] = true;
                $appointmentFilter->push($app);
            }
            $app->appointment_time = date('H:i A', strtotime($app->appointment_date));
            $app->appointment_date = date('d-M-Y', strtotime($app->appointment_date));
        }

        // Walk In Count
        $walkInCount = $appointmentFilter->where('appointment_category', 3)->count();

        $todayAppointmentsTeam = DB::table('et_appointment')
            ->select('et_appointment.*', 'et_lead.lead_name', 'et_lead.lead_gender', 'et_lead.lead_id as lead_ai_id', 'et_staff.staff_name')
            ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
            ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
            ->whereDate('et_appointment.appointment_date', date('Y-m-d'))
            ->where('et_appointment.created_by', $userId)
            ->orderBy('et_appointment.lead_id')
            ->orderBy('et_appointment.appointment_date', 'desc')
            ->get();

        $filteredAppointment = collect();
        $teamLeads = [];

        foreach ($todayAppointmentsTeam as $tdyapp) {
            $team_lead_id = $tdyapp->lead_id;

            $isCom = $tdyapp->status == 4;
            $isRes = $tdyapp->status == 5;
            $isSch = $tdyapp->status == 1;

            if ($isCom) {
                $tdyapp->display_status = 'Completed';
                $teamLeads[$team_lead_id] = true;
                $filteredAppointment->push($tdyapp);
            } elseif ($isRes) {
                $tdyapp->display_status = 'Rescheduled';
                $teamLeads[$team_lead_id] = true;
                $filteredAppointment->push($tdyapp);
            } elseif ($isSch) {
                $tdyapp->display_status = 'Scheduled';
                $teamLeads[$team_lead_id] = true;
                $filteredAppointment->push($tdyapp);
            }

            $tdyapp->appointment_time = date('H:i A', strtotime($tdyapp->appointment_time));
            $tdyapp->appointment_date = date('d-M-Y', strtotime($tdyapp->appointment_date));
        }
        $followup_schedule_count = count($todayAppointmentsTeam);

        $staff_details = DB::table('et_staff')
            ->where('et_staff.sno', $userId)
            ->select('et_staff.sno', 'et_staff.branch_id', 'et_staff.status', 'et_staff.staff_name', 'et_staff.staff_image', 'et_job_position.job_position_name')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->first();

        // Get branch details
        $branch = BranchModel::where('sno', $BranchId)
            ->orderBy('sno', 'desc')
            ->first();

        // Sales Retrieve payments for the given branch and group by customer and course with aggregation


        // Retrieve payments for the given branch and group by customer and course with aggregation

        $PaidUnderPayment = DB::table('et_proposal')
            ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
            ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
            ->join('et_customer', 'et_customer.sno', '=', 'et_payment.customer_id')
            ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->select(
                'et_customer.customer_id',
                'et_customer.sno as customer_sno',

                DB::raw('MAX(et_customer.cus_name) as cus_name'),
                DB::raw('MAX(et_customer.cus_gender) as cus_gender'),
                DB::raw('MAX(et_customer.cus_pic) as cus_pic'),
                DB::raw('MAX(et_customer.cus_mobile) as cus_mobile'),
                DB::raw('MAX(et_customer.cus_email_id) as cus_email_id'),

                'et_proposal.sno as proposal_primary_id',
                DB::raw('MAX(et_proposal.proposal_id) as auto_proposal_id'),
                DB::raw('MAX(et_proposal.service_title) as service_title'),
                DB::raw('MAX(et_proposal.total_amount) as total_amount'),
                DB::raw('MAX(et_proposal.currency_id) as currency_id'),

                DB::raw('MAX(et_country_currencies.currency_code) as currency_code'),
                DB::raw('MAX(et_country_currencies.currency_symbol) as currency_symbol'),

                'et_payment.payment_id',
                DB::raw('MAX(et_payment.payment_mode) as payment_mode'),
                DB::raw('MAX(et_payment.transaction_date) as transaction_date'),

                DB::raw('SUM(et_proposal_pay_slot.paidAmount) as paidAmount'),
                DB::raw('MAX(et_transaction.total_amount_inr) as total_amount_inr'),
                DB::raw('MAX(et_proposal_pay_slot.nextPayDate) as nextPayDate'),
                DB::raw('MAX(et_proposal_pay_slot.initialPayDate) as initialPayDate')
            )
            ->where('et_proposal.created_by', $userId)
            ->where('et_proposal.post_sale_check', 0)
            ->where('et_payment.branch_id', $BranchId)
            ->whereYear('et_proposal.estimate_date', $year)
            ->whereMonth('et_proposal.estimate_date', $month)
            ->where('et_customer.status', '!=', 2)
            ->where('et_lead.status', '!=', 2)
            ->where('et_lead.created_by', '>', 1)
            ->whereNotIn('et_proposal.proposal_status', [0, 2])
            ->groupBy(
                'et_customer.customer_id',
                'et_customer.sno',
                'et_proposal.sno',
                'et_payment.payment_id'
            )
            ->orderByDesc('et_payment.sno')
            ->get();


        $result = $PaidUnderPayment->filter(function ($payment) use ($branch, $helper) {

            $paid = $payment->paidAmount;

            // Convert to INR if currency is not INR (70)
            if ($payment->currency_id != 70) {
                $paid = $helper->ConvertedAmountInr(
                    $payment->currency_code,
                    $paid
                );
            }

            return $paid < $branch->min_prd_cost;
        });

        $low_mpc_list = $result
            ->groupBy('customer_id')
            ->map(function ($payments) use ($branch) {

                $payments = $payments->filter(fn($p) => $p->paidAmount > 0);

                if ($payments->isEmpty()) {
                    return null;
                }

                $first = $payments->first();

                return [
                    'customer_name' => $first->cus_name,
                    'customer_sno'  => $first->customer_sno,
                    'total_paid'    => $payments->sum('paidAmount'),
                    'min_required'  => $branch->min_prd_cost,
                    'status'        => 'Pending',

                    'payments' => $payments
                        ->sortBy('transaction_date')
                        ->map(function ($p) {
                            return [
                                'service_title'       => $p->service_title,
                                'auto_proposal_id'    => $p->auto_proposal_id,
                                'cus_gender'          => $p->cus_gender,
                                'cus_pic'             => $p->cus_pic,
                                'payment_id'          => $p->payment_id,
                                'total_amount_inr'    => $p->total_amount_inr,
                                'currency_symbol'     => $p->currency_symbol,
                                'currency_code'       => $p->currency_code,
                                'currency_id'         => $p->currency_id,
                                'cus_name'            => $p->cus_name,
                                'cus_mobile'          => $p->cus_mobile,
                                'amount'              => $p->total_amount,
                                'paidAmount'          => $p->paidAmount,
                                'nextPayDate'         => $p->nextPayDate,
                                'initialPayDate'      => $p->initialPayDate,
                                'transaction_date'    => $p->transaction_date,
                                'payment_mode_label'  => $p->payment_mode == 1 ? 'Online' : 'Offline',
                            ];
                        })
                        ->values(),
                ];
            })
            ->filter()
            ->values();

        $low_mpc_list = $low_mpc_list;

        $low_mpc_list_count = count($low_mpc_list);

        // Target Data 
        $StaffTarget = DB::table('et_goal_set_staff')
            ->where('staff_id', $userId)
            ->whereYear('goal_date', $year)
            ->whereMonth('goal_date', $month)
            ->first();

        $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.branch_id', $BranchId)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.branch_id', $BranchId)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $customerConvertCount = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $BranchId)
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->count();

        $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.branch_id', $BranchId)
            ->where('et_lead.status', 7)->count();

        $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.branch_id', $BranchId)
            ->where('et_lead.status', 5)->count();

        $monthFollowupCount = DB::table('et_appointment')
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->whereIn('et_lead.status', [0, 4])
            ->where('et_appointment.created_by', $userId)
            ->whereYear('et_appointment.appointment_date', $year)
            ->whereMonth('et_appointment.appointment_date', $month)
            ->count();

        $monthwalkincount = DB::table('et_lead_appointment')
            ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_lead_appointment.appointment_category', 3)
            ->where('et_lead_appointment.created_by', $userId)
            ->whereYear('et_lead_appointment.appointment_date', $year)
            ->whereMonth('et_lead_appointment.appointment_date', $month)
            ->count();

        $monthcall_out = DB::table('et_call_tracker')
            ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
            ->selectRaw('COUNT(CASE WHEN call_status = 2 THEN 1 ELSE NULL END) as missed_call_count')
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->where('et_call_tracker.branch_id', $BranchId)
            ->where('et_call_tracker.branch_staff_id', $userId)
            ->first();


        $monthcall_out_count = $monthcall_out->outgoing_call_count ?? 0;
        $missedcall_count = $monthcall_out->missed_call_count ?? 0;

        // Spam Ratio 
        $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
        $spam_lead_ratio = number_format($spam_lead_ratio, 2);

        // Dead ratio
        $dead_lead_ratio = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
        $dead_lead_ratio = number_format($dead_lead_ratio, 2);

        // customer ratio
        $convertion_rates = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
        $convertion_rate = number_format($convertion_rates, 2);

        //acr
        $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
        $averager_convertion_rate = number_format($averager_convertion_rate, 2);

        $staffs = DB::table('et_staff')
            ->select('et_staff.sno')
            ->leftJoin('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', 1)
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.branch_id', $BranchId)
            ->where('et_staff.status', 0)
            ->orderBy('et_staff.sno', 'desc')
            ->get();

        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;
        $total_staff = $staffs->count();

        // $total_staff = 1; // Ensure at least 1 staff
        $avg_outgoing_call_ratio = $dayCount > 0 ? round($monthcall_out_count / ($dayCount)) : 0;
        $avgmonthwalkincount = $dayCount > 0 ? round($monthwalkincount / ($dayCount)) : 0;
        $avgmonthFollowupCount = $dayCount > 0  ? round($monthFollowupCount / ($dayCount)) : 0;
        $avgMonthappointmentsCount = $dayCount > 0 ? round($appointmentsToday / ($dayCount)) : 0;
        $avgMonthMissedCallCount = $dayCount > 0 ? round($missedcall_count / ($dayCount)) : 0;

        if ($StaffTarget) {
            if ($StaffTarget->goal_completed == 0) {
                $StaffTarget->conversion_actual = $customerConvertCount ?? 0;
                $StaffTarget->CR_actual = $convertion_rate ?? 0;
                $StaffTarget->ABV_actual = $averageBusinessValue ?? 0;
                $StaffTarget->ACV_actual = $averageCollectionValue ?? 0;
                $StaffTarget->no_of_walk = $monthwalkincount ?? 0;
                $StaffTarget->avg_call_out_actual = $avg_outgoing_call_ratio ?? 0;
            }
        } else {
            $StaffTarget = new stdClass();
            $StaffTarget->conversion_actual = $customerConvertCount ?? 0;
            $StaffTarget->CR_actual = $convertion_rate ?? 0;
            $StaffTarget->ABV_actual = $averageBusinessValue ?? 0;
            $StaffTarget->ACV_actual = $averageCollectionValue ?? 0;
            $StaffTarget->no_of_walk = $monthwalkincount ?? 0;
            $StaffTarget->avg_call_out_actual = $avg_outgoing_call_ratio ?? 0;
        }

        // Return all data
        return response()->json([
            // Basic stats
            'staff_details' => $staff_details,
            'total_leads' => $totalLeadsCurrent,
            'total_leads_percentage' => round($totalLeadsPercentage, 1) . '%',
            'total_leads_color' => $totalLeadsColor,

            'active_leads' => $activeLeadsCurrent,
            'active_leads_percentage' => round($activeLeadsPercentage, 1) . '%',
            'active_leads_color' => $activeLeadsColor,

            'spam_leads' => $spamLeadsCurrent,
            'spam_leads_percentage' => round($spamLeadsPercentage, 1) . '%',
            'spam_leads_color' => $spamLeadsColor,

            'dead_leads' => $deadLeadsCurrent,
            'dead_leads_percentage' => round($deadLeadsPercentage, 1) . '%',
            'dead_leads_color' => $deadLeadsColor,

            // Conversion stats
            'converted_customers' => $convertedCountCurrent,
            'converted_customers_percentage' => round($convertedPercentage, 1) . '%',
            'converted_customers_color' => $convertedColor,

            'conversion_ratio' => $conversionRatioCurrent,
            'average_business_value' => number_format($averageBusinessValue, 2),
            'average_collection_value' => number_format($averageCollectionValue, 2),
            'converted_today' => $convertedToday,

            // Conversation stats
            'odc_count' => $odcCount,
            'mc_count' => $mcCount,
            'omc_count' => $omcCount,

            // Avg
            'avg_walk_in' => $avgmonthwalkincount,
            'avg_missed_calls' => $avgMonthMissedCallCount,
            'avg_followups' => $avgmonthFollowupCount,
            'avg_appointments' => $avgMonthappointmentsCount,

            // Dynamic lists
            'appointment_schedule' => $appointmentFilter,
            'walk_in_badge' => $walkInCount,
            'low_mpc_list' => $low_mpc_list,
            'low_mpc_list_count' => $low_mpc_list_count,
            'followup_schedule' => $filteredAppointment,
            'followup_schedule_count' => $followup_schedule_count,

            // Target
            'StaffTarget' => $StaffTarget,

            // Current month/year for reference
            'current_month' => $month,
            'current_year' => $year,
            'filter_date' => $dateFilter ?? date('M-Y')

        ]);
    }

    // Helper methods for ODC, MC, OMC
    private function calculateODC($userId, $month, $year)
    {
        $cusData = DB::table('et_customer')
            ->select('et_customer.sno', 'et_payment.transaction_date')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->get();

        $leadData = DB::table('et_customer')
            ->select('et_lead.registered_date', 'et_customer.sno as cus_sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $userId)
            ->where('et_customer.status', 0)
            ->get();

        return $cusData->filter(function ($item) use ($leadData) {
            $lead = $leadData->firstWhere('cus_sno', $item->sno);
            return $lead && $item->transaction_date == $lead->registered_date;
        })->count();
    }

    private function calculateMC($userId, $month, $year)
    {
        $mcCount = DB::table('et_customer')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->count();

        $odcCount = $this->calculateODC($userId, $month, $year);
        return max(0, $mcCount - $odcCount);
    }

    private function calculateOMC($userId, $month, $year)
    {
        return DB::table('et_customer')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->where(function ($query) use ($year, $month) {
                $query->whereYear('et_lead.registered_date', '<', $year)
                    ->orWhere(function ($query) use ($year, $month) {
                        $query->whereYear('et_lead.registered_date', $year)
                            ->whereMonth('et_lead.registered_date', '<', $month);
                    });
            })
            ->count();
    }




    ##################*************############Sale TL Dashboard#################*************************
    public function getSalesTlSelfDashboardData(Request $request)
    {
        $user = $request->user();
        $userId = $user->user_id;
        $BranchId = $user->branch_id;
        $dateFilter = $request->get('date_filter');
        $helper = new \App\Helpers\Helpers();

        try {
            $date = Carbon::createFromFormat('M-Y', $dateFilter);
            $month = $date->month;
            $year = $date->year;
        } catch (\Exception $e) {
            $date = Carbon::now();
            $month = $date->month;
            $year = $date->year;
        }

        $today = date('Y-m-d');
        $prevMonthDate = Carbon::create($year, $month, 1)->subMonth();
        $prevMonth = $prevMonthDate->month;
        $prevYear = $prevMonthDate->year;
        $yesterday = Carbon::yesterday()->format('Y-m-d');

        // Helper function for percentage calculation
        $calculatePercentage = function ($current, $previous) {
            if ($previous == 0) {
                return $current > 0 ? 100 : 0;
            }
            return (($current - $previous) / $previous) * 100;
        };

        // Helper function for color determination
        $getColor = function ($current, $previous) {
            if ($current > $previous) return 'success';
            if ($current < $previous) return 'warning';
            if ($current < 1) return 'danger';
            return 'danger';
        };

        // Helper function for GST calculation (18%)
        $calculateBaseAmount = function ($amount) {
            $gstPercent = 18;
            return $amount / (1 + ($gstPercent / 100));
        };
        // return $userId;
        // 1. TOTAL LEADS
        $totalLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->whereNotIn('et_lead.status', [2, 6])
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->count();

        $totalLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->whereNotIn('et_lead.status', [2, 6])
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->count();

        $totalLeadsPercentage = $calculatePercentage($totalLeadsCurrent, $totalLeadsPrev);
        $totalLeadsColor = $getColor($totalLeadsCurrent, $totalLeadsPrev);

        // 2. ACTIVE LEADS
        $activeLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $activeLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $activeLeadsPercentage = $calculatePercentage($activeLeadsCurrent, $activeLeadsPrev);
        $activeLeadsColor = $getColor($activeLeadsCurrent, $activeLeadsPrev);

        // 3. SPAM LEADS
        $spamLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.status', 7)
            ->count();

        $spamLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.status', 7)
            ->count();

        $spamLeadsPercentage = $calculatePercentage($spamLeadsCurrent, $spamLeadsPrev);
        $spamLeadsColor = $getColor($spamLeadsCurrent, $spamLeadsPrev);

        // 4. DEAD LEADS
        $deadLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.status', 5)
            ->count();

        $deadLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.status', 5)
            ->count();

        $deadLeadsPercentage = $calculatePercentage($deadLeadsCurrent, $deadLeadsPrev);
        $deadLeadsColor = $getColor($deadLeadsCurrent, $deadLeadsPrev);

        // 5. CONVERTED CUSTOMERS
        $convertedCustomersCurrent = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();

        $convertedCountCurrent = count($convertedCustomersCurrent);

        $convertedCustomersPrev = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_payment.transaction_date', $prevYear)
            ->whereMonth('et_payment.transaction_date', $prevMonth)
            ->where('et_transaction.payment_status', 1)
            ->count();

        $convertedPercentage = $calculatePercentage($convertedCountCurrent, $convertedCustomersPrev);
        $convertedColor = $getColor($convertedCountCurrent, $convertedCustomersPrev);

        // 6. CONVERSION RATIO
        $totalLeadsForRatio = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->count();

        $conversionRatioCurrent = $totalLeadsForRatio > 0 ?
            ($convertedCountCurrent / $totalLeadsForRatio) * 100 : 0;
        $conversionRatioCurrent = number_format($conversionRatioCurrent, 2);

        // 7. ABV & ACV Calculation
        $totalBusinessValue = 0;
        $totalCollectionValue = 0;
        $baseAmountPaid = 0;
        $total_payment = 0;
        $total_paid_payment = 0;
        $base_amount_paid = 0;
        $gst_percent = 18;

        if ($convertedCountCurrent > 0 && $convertedCustomersCurrent->isNotEmpty()) {
            foreach ($convertedCustomersCurrent as $customer) {
                $proposalIds = DB::table('et_proposal')
                    ->where('et_proposal.customer_id', $customer->sno)
                    ->where('et_proposal.status', 0)
                    ->whereNot('et_proposal.post_sale_check', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->pluck('sno')
                    ->toArray();

                if (!empty($proposalIds)) {
                    $proposals = DB::table('et_proposal')
                        ->select('et_proposal.*', 'et_country_currencies.currency_code')
                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                        ->whereIn('et_proposal.sno', $proposalIds)
                        ->get();

                    foreach ($proposals as $proposal) {
                        $paidAmount = DB::table('et_proposal_pay_slot')
                            ->where('proposal_sno', $proposal->sno)
                            ->where('status', 0)
                            ->sum('paidAmount');

                        $grantAmount = $proposal->grant_total_amount;

                        // Calculate base amount (excluding GST)
                        $basePaidLocal = $calculateBaseAmount($paidAmount);

                        if ($proposal->currency_id == 70) {
                            // INR
                            $totalBusinessValue += $grantAmount;
                            $totalCollectionValue += $paidAmount;
                            $baseAmountPaid += $basePaidLocal;

                            $total_payment += $grantAmount;
                            $total_paid_payment += $paidAmount;
                            $base_amount_paid += $basePaidLocal;
                        } else {
                            // Non-INR - You need to implement currency conversion
                            $currency_code = $proposal->currency_code;
                            $convertedPaidAmount = $helper->ConvertedAmountInr($currency_code, $paidAmount);
                            $convertedGrantAmount = $helper->ConvertedAmountInr($currency_code, $grantAmount);
                            $convertedBaseAmount = $helper->ConvertedAmountInr($currency_code, $basePaidLocal);

                            $total_paid_payment += $convertedPaidAmount;
                            $total_payment += $convertedGrantAmount;
                            $base_amount_paid += $convertedBaseAmount;
                        }
                    }
                }
            }
        }

        $averageBusinessValue = $convertedCountCurrent > 0 ?
            $totalBusinessValue / $convertedCountCurrent : 0;
        $averageCollectionValue = $convertedCountCurrent > 0 ?
            $baseAmountPaid / $convertedCountCurrent : 0;

        // 8. TODAY'S CONVERSIONS
        $convertedToday = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_lead.created_by', $userId)
            ->whereDate('et_payment.transaction_date', $today)
            ->where('et_transaction.payment_status', 1)
            ->count();

        // 9. APPOINTMENTS
        $appointmentsToday = DB::table('et_lead_appointment')
            ->where('created_by', $userId)
            ->whereYear('appointment_date', $year)
            ->whereMonth('appointment_date', $month)
            ->count();

        $appointmentsYesterday = DB::table('et_lead_appointment')
            ->where('staff_id', $userId)
            ->whereYear('appointment_date', $prevYear)
            ->whereMonth('appointment_date', $prevMonth)
            ->count();

        $appointmentsPercentage = $calculatePercentage($appointmentsToday, $appointmentsYesterday);
        $appointmentsNeg = $appointmentsPercentage < 0;
        $appointmentsPercentage = abs(round($appointmentsPercentage, 1));

        // 10. WALK-INS
        $walkInsToday = DB::table('et_lead_appointment')
            ->where('appointment_category', 3)
            ->whereDate('created_at', $today)
            ->where('staff_id', $userId)
            ->count();

        $walkInsYesterday = DB::table('et_lead_appointment')
            ->where('appointment_category', 3)
            ->whereDate('created_at', $yesterday)
            ->where('staff_id', $userId)
            ->count();

        $walkInsPercentage = $calculatePercentage($walkInsToday, $walkInsYesterday);
        $walkInsNeg = $walkInsPercentage < 0;
        $walkInsPercentage = abs(round($walkInsPercentage, 1));

        // 11. FOLLOW-UPS
        $followUpsToday = DB::table('et_appointment')
            ->whereDate('appointment_date', $today)
            ->where('created_by', $userId)
            ->count();

        $followUpsYesterday = DB::table('et_appointment')
            ->whereDate('appointment_date', $yesterday)
            ->where('created_by', $userId)
            ->count();

        $followUpsPercentage = $calculatePercentage($followUpsToday, $followUpsYesterday);
        $followUpsNeg = $followUpsPercentage < 0;
        $followUpsPercentage = abs(round($followUpsPercentage, 1));

        // 12. OUTGOING CALLS
        $outgoingCallsToday = DB::table('et_call_tracker')
            ->where('branch_staff_id', $userId)
            ->where('call_status', 0)
            ->whereDate('call_start_date', $today)
            ->count();

        $outgoingCallsYesterday = DB::table('et_call_tracker')
            ->where('branch_staff_id', $userId)
            ->where('call_status', 0)
            ->whereDate('call_start_date', $yesterday)
            ->count();

        $outgoingCallsPercentage = $calculatePercentage($outgoingCallsToday, $outgoingCallsYesterday);
        $outgoingCallsNeg = $outgoingCallsPercentage < 0;
        $outgoingCallsPercentage = abs(round($outgoingCallsPercentage, 1));

        // 13. ODC, MC, OMC Calculations
        $odcCount = $this->calculateODC($userId, $month, $year);
        $mcCount = $this->calculateMC($userId, $month, $year);
        $omcCount = $this->calculateOMC($userId, $month, $year);

        // Appointment Schedule
        $appointmentToday = DB::table('et_lead_appointment')
            ->select('et_lead_appointment.*', 'et_lead.lead_name', 'et_lead.lead_id as lead_ai_id')
            ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_lead_appointment.lead_id')
            ->whereDate('et_lead_appointment.appointment_date', date('Y-m-d'))
            ->where('et_lead_appointment.created_by', $userId)
            ->orderBy('et_lead_appointment.lead_id')
            ->orderBy('et_lead_appointment.appointment_date', 'asc')
            ->get();

        $appointmentFilter = collect();
        $seenLeads = [];

        foreach ($appointmentToday as $app) {
            $lead_id = $app->lead_id;

            if (isset($seenLeads[$lead_id])) continue;

            $appCompleted = $app->appointment_status == 2;
            $appRescheduled = $app->appointment_status == 4;
            $appScheduled = $app->appointment_status == 1;

            if ($appCompleted) {
                $app->app_status = 'Completed';
                $seenLeads[$lead_id] = true;
                $appointmentFilter->push($app);
            } elseif ($appRescheduled) {
                $app->app_status = 'Rescheduled';
                $seenLeads[$lead_id] = true;
                $appointmentFilter->push($app);
            } elseif ($appScheduled) {
                $app->app_status = 'Scheduled';
                $seenLeads[$lead_id] = true;
                $appointmentFilter->push($app);
            }
            $app->appointment_time = date('H:i A', strtotime($app->appointment_date));
            $app->appointment_date = date('d-M-Y', strtotime($app->appointment_date));
        }


        $todayAppointmentsTeam = DB::table('et_appointment')
            ->select('et_appointment.*', 'et_lead.lead_name', 'et_lead.lead_gender', 'et_lead.lead_id as lead_ai_id', 'et_staff.staff_name')
            ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
            ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
            ->whereDate('et_appointment.appointment_date', date('Y-m-d'))
            ->where('et_appointment.created_by', $userId)
            ->orderBy('et_appointment.lead_id')
            ->orderBy('et_appointment.appointment_date', 'desc')
            ->get();

        $filteredAppointment = collect();
        $teamLeads = [];

        foreach ($todayAppointmentsTeam as $tdyapp) {
            $team_lead_id = $tdyapp->lead_id;

            $isCom = $tdyapp->status == 4;
            $isRes = $tdyapp->status == 5;
            $isSch = $tdyapp->status == 1;

            if ($isCom) {
                $tdyapp->display_status = 'Completed';
                $teamLeads[$team_lead_id] = true;
                $filteredAppointment->push($tdyapp);
            } elseif ($isRes) {
                $tdyapp->display_status = 'Rescheduled';
                $teamLeads[$team_lead_id] = true;
                $filteredAppointment->push($tdyapp);
            } elseif ($isSch) {
                $tdyapp->display_status = 'Scheduled';
                $teamLeads[$team_lead_id] = true;
                $filteredAppointment->push($tdyapp);
            }

            $tdyapp->appointment_time = date('H:i A', strtotime($tdyapp->appointment_time));
            $tdyapp->appointment_date = date('d-M-Y', strtotime($tdyapp->appointment_date));
        }
        $followup_schedule_count = count($todayAppointmentsTeam);

        $staff_details = DB::table('et_staff')
            ->where('et_staff.sno', $userId)
            ->select('et_staff.sno', 'et_staff.branch_id', 'et_staff.status', 'et_staff.staff_name', 'et_staff.staff_image', 'et_job_position.job_position_name')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->first();

        // Get branch details
        $branch = BranchModel::where('sno', $BranchId)
            ->orderBy('sno', 'desc')
            ->first();

        //TL self Retrieve payments for the given branch and group by customer and course with aggregation

        $PaidUnderPayment = DB::table('et_proposal')
            ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
            ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
            ->join('et_customer', 'et_customer.sno', '=', 'et_payment.customer_id')
            ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->select(
                'et_customer.customer_id',
                'et_customer.sno as customer_sno',

                DB::raw('MAX(et_customer.cus_name) as cus_name'),
                DB::raw('MAX(et_customer.cus_gender) as cus_gender'),
                DB::raw('MAX(et_customer.cus_pic) as cus_pic'),
                DB::raw('MAX(et_customer.cus_mobile) as cus_mobile'),
                DB::raw('MAX(et_customer.cus_email_id) as cus_email_id'),

                'et_proposal.sno as proposal_primary_id',
                DB::raw('MAX(et_proposal.proposal_id) as auto_proposal_id'),
                DB::raw('MAX(et_proposal.service_title) as service_title'),
                DB::raw('MAX(et_proposal.total_amount) as total_amount'),
                DB::raw('MAX(et_proposal.currency_id) as currency_id'),

                DB::raw('MAX(et_country_currencies.currency_code) as currency_code'),
                DB::raw('MAX(et_country_currencies.currency_symbol) as currency_symbol'),

                'et_payment.payment_id',
                DB::raw('MAX(et_payment.payment_mode) as payment_mode'),
                DB::raw('MAX(et_payment.transaction_date) as transaction_date'),

                DB::raw('SUM(et_proposal_pay_slot.paidAmount) as paidAmount'),
                DB::raw('MAX(et_transaction.total_amount_inr) as total_amount_inr'),
                DB::raw('MAX(et_proposal_pay_slot.nextPayDate) as nextPayDate'),
                DB::raw('MAX(et_proposal_pay_slot.initialPayDate) as initialPayDate')
            )
            ->where('et_proposal.created_by', $userId)
            ->where('et_proposal.post_sale_check', 0)
            ->where('et_payment.branch_id', $BranchId)
            ->whereYear('et_proposal.estimate_date', $year)
            ->whereMonth('et_proposal.estimate_date', $month)
            ->where('et_customer.status', '!=', 2)
            ->where('et_lead.status', '!=', 2)
            ->where('et_lead.created_by', '>', 1)
            ->whereNotIn('et_proposal.proposal_status', [0, 2])
            ->groupBy(
                'et_customer.customer_id',
                'et_customer.sno',
                'et_proposal.sno',
                'et_payment.payment_id'
            )
            ->orderByDesc('et_payment.sno')
            ->get();


        $result = $PaidUnderPayment->filter(function ($payment) use ($branch, $helper) {

            $paid = $payment->paidAmount;

            // Convert to INR if currency is not INR (70)
            if ($payment->currency_id != 70) {
                $paid = $helper->ConvertedAmountInr(
                    $payment->currency_code,
                    $paid
                );
            }

            return $paid < $branch->min_prd_cost;
        });

        $low_mpc_list = $result
            ->groupBy('customer_id')
            ->map(function ($payments) use ($branch) {

                $payments = $payments->filter(fn($p) => $p->paidAmount > 0);

                if ($payments->isEmpty()) {
                    return null;
                }

                $first = $payments->first();

                return [
                    'customer_name' => $first->cus_name,
                    'customer_sno'  => $first->customer_sno,
                    'total_paid'    => $payments->sum('paidAmount'),
                    'min_required'  => $branch->min_prd_cost,
                    'status'        => 'Pending',

                    'payments' => $payments
                        ->sortBy('transaction_date')
                        ->map(function ($p) {
                            return [
                                'service_title'       => $p->service_title,
                                'auto_proposal_id'    => $p->auto_proposal_id,
                                'cus_gender'          => $p->cus_gender,
                                'cus_pic'             => $p->cus_pic,
                                'payment_id'          => $p->payment_id,
                                'total_amount_inr'    => $p->total_amount_inr,
                                'currency_symbol'     => $p->currency_symbol,
                                'currency_code'       => $p->currency_code,
                                'currency_id'         => $p->currency_id,
                                'cus_name'            => $p->cus_name,
                                'cus_mobile'          => $p->cus_mobile,
                                'amount'              => $p->total_amount,
                                'paidAmount'          => $p->paidAmount,
                                'nextPayDate'         => $p->nextPayDate,
                                'initialPayDate'      => $p->initialPayDate,
                                'transaction_date'    => $p->transaction_date,
                                'payment_mode_label'  => $p->payment_mode == 1 ? 'Online' : 'Offline',
                            ];
                        })
                        ->values(),
                ];
            })
            ->filter()
            ->values();

        $low_mpc_list = $low_mpc_list;



        $low_mpc_list_count = count($low_mpc_list);

        // Target Data 
        $StaffTarget = DB::table('et_goal_set_staff')
            ->where('staff_id', $userId)
            ->whereYear('goal_date', $year)
            ->whereMonth('goal_date', $month)
            ->first();

        $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.branch_id', $BranchId)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.branch_id', $BranchId)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $customerConvertCount = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $BranchId)
            ->where('et_lead.created_by', $userId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->count();

        $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.branch_id', $BranchId)
            ->where('et_lead.status', 7)->count();

        $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->where('et_lead.created_by', $userId)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.branch_id', $BranchId)
            ->where('et_lead.status', 5)->count();

        $monthFollowupCount = DB::table('et_appointment')
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->whereIn('et_lead.status', [0, 4])
            ->where('et_appointment.created_by', $userId)
            ->whereYear('et_appointment.appointment_date', $year)
            ->whereMonth('et_appointment.appointment_date', $month)
            ->count();

        $monthwalkincount = DB::table('et_lead_appointment')
            ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_lead_appointment.appointment_category', 3)
            ->where('et_lead_appointment.created_by', $userId)
            ->whereYear('et_lead_appointment.appointment_date', $year)
            ->whereMonth('et_lead_appointment.appointment_date', $month)
            ->count();

        $monthcall_out = DB::table('et_call_tracker')
            ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
            ->selectRaw('COUNT(CASE WHEN call_status = 2 THEN 1 ELSE NULL END) as missed_call_count')
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->where('et_call_tracker.branch_id', $BranchId)
            ->where('et_call_tracker.branch_staff_id', $userId)
            ->first();

        $PremonthFollowupCount = DB::table('et_appointment')
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->whereIn('et_lead.status', [0, 4])
            ->where('et_appointment.created_by', $userId)
            ->whereYear('et_appointment.appointment_date', $prevYear)
            ->whereMonth('et_appointment.appointment_date', $prevMonth)
            ->count();

        $Premonthwalkincount = DB::table('et_lead_appointment')
            ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_lead_appointment.appointment_category', 3)
            ->where('et_lead_appointment.created_by', $userId)
            ->whereYear('et_lead_appointment.appointment_date', $prevYear)
            ->whereMonth('et_lead_appointment.appointment_date', $prevMonth)
            ->count();

        $Premonthcall_out = DB::table('et_call_tracker')
            ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
            ->selectRaw('COUNT(CASE WHEN call_status = 2 THEN 1 ELSE NULL END) as missed_call_count')
            ->whereYear('call_start_date', $prevYear)
            ->whereMonth('call_start_date', $prevMonth)
            ->where('et_call_tracker.branch_id', $BranchId)
            ->where('et_call_tracker.branch_staff_id', $userId)
            ->first();

        $Premonthcall_out_count = $Premonthcall_out->outgoing_call_count ?? 0;

        $monthcall_out_count = $monthcall_out->outgoing_call_count ?? 0;
        $missedcall_count = $monthcall_out->missed_call_count ?? 0;

        // Spam Ratio 
        $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
        $spam_lead_ratio = number_format($spam_lead_ratio, 2);

        // Dead ratio
        $dead_lead_ratio = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
        $dead_lead_ratio = number_format($dead_lead_ratio, 2);

        // customer ratio
        $convertion_rates = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
        $convertion_rate = number_format($convertion_rates, 2);

        //acr
        $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
        $averager_convertion_rate = number_format($averager_convertion_rate, 2);

        $staffs = DB::table('et_staff')
            ->select('et_staff.sno')
            ->leftJoin('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', 1)
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.branch_id', $BranchId)
            ->where('et_staff.status', 0)
            ->orderBy('et_staff.sno', 'desc')
            ->get();

        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;
        $total_staff = $staffs->count();

        $total_staff = max($total_staff, 1); // Ensure at least 1 staff
        $avg_outgoing_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($monthcall_out_count / ($total_staff * $dayCount)) : 0;
        $avgmonthwalkincount = $dayCount > 0 && $total_staff > 0 ? round($monthwalkincount / ($total_staff * $dayCount)) : 0;
        $avgmonthFollowupCount = $dayCount > 0 && $total_staff > 0 ? round($monthFollowupCount / ($total_staff * $dayCount)) : 0;
        $avgMonthappointmentsCount = $dayCount > 0 && $total_staff > 0 ? round($appointmentsToday / ($total_staff * $dayCount)) : 0;
        $avgMonthMissedCallCount = $dayCount > 0 && $total_staff > 0 ? round($missedcall_count / ($total_staff * $dayCount)) : 0;

        if ($StaffTarget) {
            if ($StaffTarget->goal_completed == 0) {
                $StaffTarget->conversion_actual = $customerConvertCount ?? 0;
                $StaffTarget->CR_actual = $convertion_rate ?? 0;
                $StaffTarget->ABV_actual = $averageBusinessValue ?? 0;
                $StaffTarget->ACV_actual = $averageCollectionValue ?? 0;
                $StaffTarget->no_of_walk = $monthwalkincount ?? 0;
                $StaffTarget->avg_call_out_actual = $avgMonthappointmentsCount ?? 0;
            }
        } else {
            $StaffTarget = new stdClass();
            $StaffTarget->conversion_actual = $customerConvertCount ?? 0;
            $StaffTarget->CR_actual = $convertion_rate ?? 0;
            $StaffTarget->ABV_actual = $averageBusinessValue ?? 0;
            $StaffTarget->ACV_actual = $averageCollectionValue ?? 0;
            $StaffTarget->no_of_walk = $monthwalkincount ?? 0;
            $StaffTarget->avg_call_out_actual = $avgMonthappointmentsCount ?? 0;
        }

        // Return all data
        return response()->json([
            // Basic stats
            'staff_details' => $staff_details,
            'total_leads' => $totalLeadsCurrent,
            'total_leads_percentage' => round($totalLeadsPercentage, 1) . '%',
            'total_leads_prev' => $totalLeadsPrev,
            'total_leads_color' => $totalLeadsColor,

            'active_leads' => $activeLeadsCurrent,
            'active_leads_percentage' => round($activeLeadsPercentage, 1) . '%',
            'active_leads_color' => $activeLeadsColor,
            'active_leads_prev' => $activeLeadsPrev,

            'spam_leads' => $spamLeadsCurrent,
            'spam_leads_percentage' => round($spamLeadsPercentage, 1) . '%',
            'spam_leads_color' => $spamLeadsColor,
            'spam_leads_prev' => $spamLeadsPrev,

            'dead_leads' => $deadLeadsCurrent,
            'dead_leads_percentage' => round($deadLeadsPercentage, 1) . '%',
            'dead_leads_color' => $deadLeadsColor,
            'dead_leads_prev' => $deadLeadsPrev,

            // Conversion stats
            'converted_customers' => $convertedCountCurrent,
            'converted_customers_percentage' => round($convertedPercentage, 1) . '%',
            'converted_customers_color' => $convertedColor,

            'conversion_ratio' => $conversionRatioCurrent,
            'average_business_value' => number_format($averageBusinessValue, 2),
            'average_collection_value' => number_format($averageCollectionValue, 2),
            'converted_today' => $convertedToday,

            // Conversation stats
            'odc_count' => $odcCount,
            'mc_count' => $mcCount,
            'omc_count' => $omcCount,

            // Avg
            'avg_walk_in' => $avgmonthwalkincount,
            'avg_missed_calls' => $avgMonthMissedCallCount,
            'avg_followups' => $avgmonthFollowupCount,
            'avg_appointments' => $avgMonthappointmentsCount,

            // Dynamic lists
            'appointment_schedule' => $appointmentFilter,
            'low_mpc_list' => $low_mpc_list,
            'followup_schedule' => $filteredAppointment,

            // Appointment
            'monthFollowupCount' => $monthFollowupCount,
            'PremonthFollowupCount' => $PremonthFollowupCount,
            'monthwalkincount' => $monthwalkincount,
            'Premonthwalkincount' => $Premonthwalkincount,
            'monthcall_out' => $monthcall_out_count,
            'Premonthcall_out' => $Premonthcall_out_count,
            'appointmentsToday' => $appointmentsToday,
            'appointmentsYesterday' => $appointmentsYesterday,

            // Target
            'StaffTarget' => $StaffTarget,

            // Current month/year for reference
            'current_month' => $month,
            'current_year' => $year,
            'filter_date' => $dateFilter ?? date('M-Y')

        ]);
    }

    public function getSalesTlTeamDashboardData(Request $request)
    {
        $user = $request->user();
        $userId = $user->user_id;
        $BranchId = $user->branch_id;
        $dateFilter = $request->get('date_filter');
        $helper = new \App\Helpers\Helpers();

        try {
            $date = Carbon::createFromFormat('M-Y', $dateFilter);
            $month = $date->month;
            $year = $date->year;
        } catch (\Exception $e) {
            $date = Carbon::now();
            $month = $date->month;
            $year = $date->year;
        }

        $today = date('Y-m-d');
        $prevMonthDate = Carbon::create($year, $month, 1)->subMonth();
        $prevMonth = $prevMonthDate->month;
        $prevYear = $prevMonthDate->year;
        $yesterday = Carbon::yesterday()->format('Y-m-d');

        $salesStaff = DB::table('et_staff')
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.gender',
                'et_staff.mobile_no',
                'et_staff.lead_bank_count',
                'et_staff.status as staff_status',
                'et_job_position.job_position_name',
                'et_cug_management.staff_mobile as cug_mobile'
            )
            ->leftJoin('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.department_id', 1)
            ->where('et_staff.sno', '>', 1)
            // ->where('et_staff.sno', 10)
            ->where('et_staff.branch_id', $BranchId)
            ->where(function ($query) use ($year, $month) {
                // Add conditions for status 4
                $query->where(function ($query) use ($year, $month) {
                    $query->where('et_staff.status', 4)
                        ->whereYear('et_staff.notice_end_date', '>=', $year)
                        ->whereMonth('et_staff.notice_end_date', '>=', $month);
                })
                    // Add conditions for status 5
                    ->orWhere(function ($query) use ($year, $month) {
                        $query->where('et_staff.status', 5)
                            ->whereYear('et_staff.updated_at', '>=', $year)
                            ->whereMonth('et_staff.updated_at', '>=', $month);
                    })
                    // Add conditions for status 6
                    ->orWhere(function ($query) use ($year, $month) {
                        $query->where('et_staff.status', 6)
                            ->whereYear('et_staff.staff_last_date', '>=', $year)
                            ->whereMonth('et_staff.staff_last_date', '>=', $month);
                    })
                    // Add conditions for status 7
                    ->orWhere(function ($query) use ($year, $month) {
                        $query->where('et_staff.status', 7)
                            ->whereYear('et_staff.updated_at', '>=', $year)
                            ->whereMonth('et_staff.updated_at', '>=', $month);
                    })
                    // Include status 0 regardless of date
                    ->orWhere('et_staff.status', 0);
            })->get();

        $staffIds = $salesStaff->pluck('sno');

        // Helper function for percentage calculation
        $calculatePercentage = function ($current, $previous) {
            if ($previous == 0) {
                return $current > 0 ? 100 : 0;
            }
            return (($current - $previous) / $previous) * 100;
        };

        // Helper function for color determination
        $getColor = function ($current, $previous) {
            if ($current > $previous) return 'success';
            if ($current < $previous) return 'warning';
            if ($current < 1) return 'danger';
            return 'danger';
        };

        // Helper function for GST calculation (18%)
        $calculateBaseAmount = function ($amount) {
            $gstPercent = 18;
            return $amount / (1 + ($gstPercent / 100));
        };
        // return $userId;
        // 1. TOTAL LEADS
        $totalLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereNotIn('et_lead.status', [2, 6])
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->count();

        $totalLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereNotIn('et_lead.status', [2, 6])
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->count();

        $totalLeadsPercentage = $calculatePercentage($totalLeadsCurrent, $totalLeadsPrev);
        $totalLeadsColor = $getColor($totalLeadsCurrent, $totalLeadsPrev);

        // 2. ACTIVE LEADS
        $activeLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $activeLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $activeLeadsPercentage = $calculatePercentage($activeLeadsCurrent, $activeLeadsPrev);
        $activeLeadsColor = $getColor($activeLeadsCurrent, $activeLeadsPrev);

        // 3. SPAM LEADS
        $spamLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereIn('et_lead.created_by', $staffIds)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.status', 7)
            ->count();

        $spamLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->whereIn('et_lead.created_by', $staffIds)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.status', 7)
            ->count();

        $spamLeadsPercentage = $calculatePercentage($spamLeadsCurrent, $spamLeadsPrev);
        $spamLeadsColor = $getColor($spamLeadsCurrent, $spamLeadsPrev);

        // 4. DEAD LEADS
        $deadLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereIn('et_lead.created_by', $staffIds)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.status', 5)
            ->count();

        $deadLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $prevYear)
            ->whereMonth('et_lead.registered_date', $prevMonth)
            ->whereIn('et_lead.created_by', $staffIds)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.status', 5)
            ->count();

        $deadLeadsPercentage = $calculatePercentage($deadLeadsCurrent, $deadLeadsPrev);
        $deadLeadsColor = $getColor($deadLeadsCurrent, $deadLeadsPrev);

        // 5. CONVERTED CUSTOMERS
        $convertedCustomersCurrent = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();

        $convertedCountCurrent = count($convertedCustomersCurrent);

        $convertedCustomersPrev = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereYear('et_payment.transaction_date', $prevYear)
            ->whereMonth('et_payment.transaction_date', $prevMonth)
            ->where('et_transaction.payment_status', 1)
            ->count();

        $convertedPercentage = $calculatePercentage($convertedCountCurrent, $convertedCustomersPrev);
        $convertedColor = $getColor($convertedCountCurrent, $convertedCustomersPrev);

        // 6. CONVERSION RATIO
        $totalLeadsForRatio = DB::table('et_lead')->select('et_lead.sno')
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->count();

        $conversionRatioCurrent = $totalLeadsForRatio > 0 ?
            ($convertedCountCurrent / $totalLeadsForRatio) * 100 : 0;
        $conversionRatioCurrent = number_format($conversionRatioCurrent, 2);

        // 7. ABV & ACV Calculation
        $totalBusinessValue = 0;
        $totalCollectionValue = 0;
        $baseAmountPaid = 0;
        $total_payment = 0;
        $total_paid_payment = 0;
        $base_amount_paid = 0;
        $gst_percent = 18;

        if ($convertedCountCurrent > 0 && $convertedCustomersCurrent->isNotEmpty()) {
            foreach ($convertedCustomersCurrent as $customer) {
                $proposalIds = DB::table('et_proposal')
                    ->where('et_proposal.customer_id', $customer->sno)
                    ->where('et_proposal.status', 0)
                    ->whereNot('et_proposal.post_sale_check', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->pluck('sno')
                    ->toArray();

                if (!empty($proposalIds)) {
                    $proposals = DB::table('et_proposal')
                        ->select('et_proposal.*', 'et_country_currencies.currency_code')
                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                        ->whereIn('et_proposal.sno', $proposalIds)
                        ->get();



                    foreach ($proposals as $proposal) {

                        // Paid slots for this proposal
                        $paidAmount = DB::table('et_proposal_pay_slot')
                            ->where('proposal_sno', $proposal->sno)
                            ->where('status', 0)
                            ->sum('paidAmount');

                        $grantAmount = $proposal->grant_total_amount;

                        // Calculate base amount (excluding GST)
                        $basePaidLocal = $calculateBaseAmount($paidAmount);

                        if ($proposal->currency_id == 70) {
                            // INR
                            $totalBusinessValue += $grantAmount;
                            $totalCollectionValue += $paidAmount;
                            $baseAmountPaid += $basePaidLocal;

                            $total_payment += $grantAmount;
                            $total_paid_payment += $paidAmount;
                            $base_amount_paid += $basePaidLocal;
                        } else {
                            // Non-INR - You need to implement currency conversion
                            $currency_code = $proposal->currency_code;
                            $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                            $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                            $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                        }
                    }
                }
            }
        }
        // average 
        $averageBusinessValue = $convertedCountCurrent > 0 ?
            $totalBusinessValue / $convertedCountCurrent : 0;
        $averageCollectionValue = $convertedCountCurrent > 0 ?
            $baseAmountPaid / $convertedCountCurrent : 0;

        // 8. TODAY'S CONVERSIONS
        $convertedToday = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereDate('et_payment.transaction_date', $today)
            ->where('et_transaction.payment_status', 1)
            ->count();

        // 9. APPOINTMENTS
        $appointmentsToday = DB::table('et_lead_appointment')
            ->whereIn('created_by', $staffIds)
            ->whereYear('appointment_date', $year)
            ->whereMonth('appointment_date', $month)
            ->count();

        $appointmentsYesterday = DB::table('et_lead_appointment')
            ->whereIn('staff_id', $staffIds)
            ->whereYear('appointment_date', $prevYear)
            ->whereMonth('appointment_date', $prevMonth)
            ->count();

        $appointmentsPercentage = $calculatePercentage($appointmentsToday, $appointmentsYesterday);
        $appointmentsNeg = $appointmentsPercentage < 0;
        $appointmentsPercentage = abs(round($appointmentsPercentage, 1));

        // 10. WALK-INS
        $walkInsToday = DB::table('et_lead_appointment')
            ->where('appointment_category', 3)
            ->whereDate('created_at', $today)
            ->whereIn('staff_id', $staffIds)
            ->count();

        $walkInsYesterday = DB::table('et_lead_appointment')
            ->where('appointment_category', 3)
            ->whereDate('created_at', $yesterday)
            ->whereIn('staff_id', $staffIds)
            ->count();

        $walkInsPercentage = $calculatePercentage($walkInsToday, $walkInsYesterday);
        $walkInsNeg = $walkInsPercentage < 0;
        $walkInsPercentage = abs(round($walkInsPercentage, 1));

        // 11. FOLLOW-UPS
        $followUpsToday = DB::table('et_appointment')
            ->whereDate('appointment_date', $today)
            ->whereIn('created_by', $staffIds)
            ->count();

        $followUpsYesterday = DB::table('et_appointment')
            ->whereDate('appointment_date', $yesterday)
            ->whereIn('created_by', $staffIds)
            ->count();

        $followUpsPercentage = $calculatePercentage($followUpsToday, $followUpsYesterday);
        $followUpsNeg = $followUpsPercentage < 0;
        $followUpsPercentage = abs(round($followUpsPercentage, 1));

        // 12. OUTGOING CALLS
        $outgoingCallsToday = DB::table('et_call_tracker')
            ->whereIn('branch_staff_id', $staffIds)
            ->where('call_status', 0)
            ->whereDate('call_start_date', $today)
            ->count();

        $outgoingCallsYesterday = DB::table('et_call_tracker')
            ->whereIn('branch_staff_id', $staffIds)
            ->where('call_status', 0)
            ->whereDate('call_start_date', $yesterday)
            ->count();

        $outgoingCallsPercentage = $calculatePercentage($outgoingCallsToday, $outgoingCallsYesterday);
        $outgoingCallsNeg = $outgoingCallsPercentage < 0;
        $outgoingCallsPercentage = abs(round($outgoingCallsPercentage, 1));

        // 13. ODC, MC, OMC Calculations
        $odcCount = $this->calculateODCMulti($staffIds, $month, $year);
        $mcCount = $this->calculateMCMulti($staffIds, $month, $year);
        $omcCount = $this->calculateOMCMulti($staffIds, $month, $year);

        // Appointment Schedule
        $appointmentToday = DB::table('et_lead_appointment')
            ->select('et_lead_appointment.*', 'et_lead.lead_name', 'et_lead.lead_id as lead_ai_id')
            ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_lead_appointment.lead_id')
            ->whereDate('et_lead_appointment.appointment_date', date('Y-m-d'))
            ->whereIn('et_lead_appointment.created_by', $staffIds)
            ->orderBy('et_lead_appointment.lead_id')
            ->orderBy('et_lead_appointment.appointment_date', 'asc')
            ->get();

        $appointmentFilter = collect();
        $seenLeads = [];

        foreach ($appointmentToday as $app) {
            $lead_id = $app->lead_id;

            if (isset($seenLeads[$lead_id])) continue;

            $appCompleted = $app->appointment_status == 2;
            $appRescheduled = $app->appointment_status == 4;
            $appScheduled = $app->appointment_status == 1;

            if ($appCompleted) {
                $app->app_status = 'Completed';
                $seenLeads[$lead_id] = true;
                $appointmentFilter->push($app);
            } elseif ($appRescheduled) {
                $app->app_status = 'Rescheduled';
                $seenLeads[$lead_id] = true;
                $appointmentFilter->push($app);
            } elseif ($appScheduled) {
                $app->app_status = 'Scheduled';
                $seenLeads[$lead_id] = true;
                $appointmentFilter->push($app);
            }
            $app->appointment_time = date('H:i A', strtotime($app->appointment_date));
            $app->appointment_date = date('d-M-Y', strtotime($app->appointment_date));
        }


        $todayAppointmentsTeam = DB::table('et_appointment')
            ->select('et_appointment.*', 'et_lead.lead_name', 'et_lead.lead_gender', 'et_lead.lead_id as lead_ai_id', 'et_staff.staff_name')
            ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
            ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
            ->whereDate('et_appointment.appointment_date', date('Y-m-d'))
            ->whereIn('et_appointment.created_by', $staffIds)
            ->orderBy('et_appointment.lead_id')
            ->orderBy('et_appointment.appointment_date', 'desc')
            ->get();

        $filteredAppointment = collect();
        $teamLeads = [];

        foreach ($todayAppointmentsTeam as $tdyapp) {
            $team_lead_id = $tdyapp->lead_id;

            $isCom = $tdyapp->status == 4;
            $isRes = $tdyapp->status == 5;
            $isSch = $tdyapp->status == 1;

            if ($isCom) {
                $tdyapp->display_status = 'Completed';
                $teamLeads[$team_lead_id] = true;
                $filteredAppointment->push($tdyapp);
            } elseif ($isRes) {
                $tdyapp->display_status = 'Rescheduled';
                $teamLeads[$team_lead_id] = true;
                $filteredAppointment->push($tdyapp);
            } elseif ($isSch) {
                $tdyapp->display_status = 'Scheduled';
                $teamLeads[$team_lead_id] = true;
                $filteredAppointment->push($tdyapp);
            }

            $tdyapp->appointment_time = date('H:i A', strtotime($tdyapp->appointment_time));
            $tdyapp->appointment_date = date('d-M-Y', strtotime($tdyapp->appointment_date));
        }
        $followup_schedule_count = count($todayAppointmentsTeam);

        $staff_details = DB::table('et_staff')
            ->whereIn('et_staff.sno', $staffIds)
            ->select('et_staff.sno', 'et_staff.branch_id', 'et_staff.status', 'et_staff.staff_name', 'et_staff.staff_image', 'et_job_position.job_position_name')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->first();

        // Get branch details
        $branch = BranchModel::where('sno', $BranchId)
            ->orderBy('sno', 'desc')
            ->first();

        // TL Team Retrieve payments for the given branch and group by customer and course with aggregation

        $PaidUnderPayment = DB::table('et_proposal')
            ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
            ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
            ->join('et_customer', 'et_customer.sno', '=', 'et_payment.customer_id')
            ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->select(
                'et_customer.customer_id',
                'et_customer.sno as customer_sno',

                DB::raw('MAX(et_customer.cus_name) as cus_name'),
                DB::raw('MAX(et_customer.cus_gender) as cus_gender'),
                DB::raw('MAX(et_customer.cus_pic) as cus_pic'),
                DB::raw('MAX(et_customer.cus_mobile) as cus_mobile'),
                DB::raw('MAX(et_customer.cus_email_id) as cus_email_id'),

                'et_proposal.sno as proposal_primary_id',
                DB::raw('MAX(et_proposal.proposal_id) as auto_proposal_id'),
                DB::raw('MAX(et_proposal.service_title) as service_title'),
                DB::raw('MAX(et_proposal.total_amount) as total_amount'),
                DB::raw('MAX(et_proposal.currency_id) as currency_id'),

                DB::raw('MAX(et_country_currencies.currency_code) as currency_code'),
                DB::raw('MAX(et_country_currencies.currency_symbol) as currency_symbol'),

                'et_payment.payment_id',
                DB::raw('MAX(et_payment.payment_mode) as payment_mode'),
                DB::raw('MAX(et_payment.transaction_date) as transaction_date'),

                DB::raw('SUM(et_proposal_pay_slot.paidAmount) as paidAmount'),
                DB::raw('MAX(et_transaction.total_amount_inr) as total_amount_inr'),
                DB::raw('MAX(et_proposal_pay_slot.nextPayDate) as nextPayDate'),
                DB::raw('MAX(et_proposal_pay_slot.initialPayDate) as initialPayDate')
            )
            ->whereIn('et_proposal.created_by', $staffIds)
            ->where('et_proposal.post_sale_check', 0)
            ->where('et_payment.branch_id', $BranchId)
            ->whereYear('et_proposal.estimate_date', $year)
            ->whereMonth('et_proposal.estimate_date', $month)
            ->where('et_customer.status', '!=', 2)
            ->where('et_lead.status', '!=', 2)
            ->where('et_lead.created_by', '>', 1)
            ->whereNotIn('et_proposal.proposal_status', [0, 2])
            ->groupBy(
                'et_customer.customer_id',
                'et_customer.sno',
                'et_proposal.sno',
                'et_payment.payment_id'
            )
            ->orderByDesc('et_payment.sno')
            ->get();


        $result = $PaidUnderPayment->filter(function ($payment) use ($branch, $helper) {

            $paid = $payment->paidAmount;

            // Convert to INR if currency is not INR (70)
            if ($payment->currency_id != 70) {
                $paid = $helper->ConvertedAmountInr(
                    $payment->currency_code,
                    $paid
                );
            }

            return $paid < $branch->min_prd_cost;
        });

        $low_mpc_list = $result
            ->groupBy('customer_id')
            ->map(function ($payments) use ($branch) {

                $payments = $payments->filter(fn($p) => $p->paidAmount > 0);

                if ($payments->isEmpty()) {
                    return null;
                }

                $first = $payments->first();

                return [
                    'customer_name' => $first->cus_name,
                    'customer_sno'  => $first->customer_sno,
                    'total_paid'    => $payments->sum('paidAmount'),
                    'min_required'  => $branch->min_prd_cost,
                    'status'        => 'Pending',

                    'payments' => $payments
                        ->sortBy('transaction_date')
                        ->map(function ($p) {
                            return [
                                'service_title'       => $p->service_title,
                                'auto_proposal_id'    => $p->auto_proposal_id,
                                'cus_gender'          => $p->cus_gender,
                                'cus_pic'             => $p->cus_pic,
                                'payment_id'          => $p->payment_id,
                                'total_amount_inr'    => $p->total_amount_inr,
                                'currency_symbol'     => $p->currency_symbol,
                                'currency_code'       => $p->currency_code,
                                'currency_id'         => $p->currency_id,
                                'cus_name'            => $p->cus_name,
                                'cus_mobile'          => $p->cus_mobile,
                                'amount'              => $p->total_amount,
                                'paidAmount'          => $p->paidAmount,
                                'nextPayDate'         => $p->nextPayDate,
                                'initialPayDate'      => $p->initialPayDate,
                                'transaction_date'    => $p->transaction_date,
                                'payment_mode_label'  => $p->payment_mode == 1 ? 'Online' : 'Offline',
                            ];
                        })
                        ->values(),
                ];
            })
            ->filter()
            ->values();

        $low_mpc_list = $low_mpc_list;



        $low_mpc_list_count = count($low_mpc_list);

        // Target Data 
        $StaffTarget = DB::table('et_goal_set_staff')
            ->whereIn('staff_id', $staffIds)
            ->whereYear('goal_date', $year)
            ->whereMonth('goal_date', $month)
            ->first();

        $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereIn('et_lead.created_by', $staffIds)
            ->where('et_lead.branch_id', $BranchId)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereIn('et_lead.created_by', $staffIds)
            ->where('et_lead.branch_id', $BranchId)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereNotIn('et_lead.status', [2, 6])
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.drop_verified', 0)
            ->where('et_lead.internal_status', 0)
            ->count();

        $customerConvertCount = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $BranchId)
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->count();

        $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereIn('et_lead.created_by', $staffIds)
            ->where('et_lead.spam_verified', 1)
            ->where('et_lead.branch_id', $BranchId)
            ->where('et_lead.status', 7)->count();

        $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereIn('et_lead.created_by', $staffIds)
            ->where('et_lead.drop_verified', 1)
            ->where('et_lead.branch_id', $BranchId)
            ->where('et_lead.status', 5)->count();

        $monthFollowupCount = DB::table('et_appointment')
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->whereIn('et_lead.status', [0, 4])
            ->whereIn('et_appointment.created_by', $staffIds)
            ->whereYear('et_appointment.appointment_date', $year)
            ->whereMonth('et_appointment.appointment_date', $month)
            ->count();

        $monthwalkincount = DB::table('et_lead_appointment')
            ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_lead_appointment.appointment_category', 3)
            ->whereIn('et_lead_appointment.created_by', $staffIds)
            ->whereYear('et_lead_appointment.appointment_date', $year)
            ->whereMonth('et_lead_appointment.appointment_date', $month)
            ->count();

        $monthcall_out = DB::table('et_call_tracker')
            ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
            ->selectRaw('COUNT(CASE WHEN call_status = 2 THEN 1 ELSE NULL END) as missed_call_count')
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->where('et_call_tracker.branch_id', $BranchId)
            ->whereIn('et_call_tracker.branch_staff_id', $staffIds)
            ->first();

        $monthcall_out_count = $monthcall_out->outgoing_call_count ?? 0;
        $missedcall_count = $monthcall_out->missed_call_count ?? 0;

        // Spam Ratio 
        $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
        $spam_lead_ratio = number_format($spam_lead_ratio, 2);

        // Dead ratio
        $dead_lead_ratio = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
        $dead_lead_ratio = number_format($dead_lead_ratio, 2);

        // customer ratio
        $convertion_rates = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
        $convertion_rate = number_format($convertion_rates, 2);

        //acr
        $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
        $averager_convertion_rate = number_format($averager_convertion_rate, 2);



        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;
        $total_staff = $salesStaff->count();
        $total_staff = max($total_staff, 1); // Ensure at least 1 staff
        $avg_outgoing_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($monthcall_out_count / ($total_staff * $dayCount)) : 0;
        $avgmonthwalkincount = $dayCount > 0 && $total_staff > 0 ? round($monthwalkincount / ($total_staff * $dayCount)) : 0;
        $avgmonthFollowupCount = $dayCount > 0 && $total_staff > 0 ? round($monthFollowupCount / ($total_staff * $dayCount)) : 0;
        $avgMonthappointmentsCount = $dayCount > 0 && $total_staff > 0 ? round($appointmentsToday / ($total_staff * $dayCount)) : 0;
        $avgMonthMissedCallCount = $dayCount > 0 && $total_staff > 0 ? round($missedcall_count / ($total_staff * $dayCount)) : 0;




        // ============ INDIVIDUAL STAFF STATISTICS ============
        $individualStaffStats = [];
        $teamMembersData = [];
        $teamLeadReportsData = [];

        foreach ($salesStaff as $staff) {
            $staffId = $staff->sno;

            // 1. Total Leads for this staff
            $staffTotalLeads = DB::table('et_lead')->select('et_lead.sno')
                ->where('et_lead.created_by', $staffId)
                ->whereNotIn('et_lead.status', [2, 6])
                ->whereYear('et_lead.registered_date', $year)
                ->whereMonth('et_lead.registered_date', $month)
                ->count();

            // 2. Active Leads for this staff
            $staffActiveLeads = DB::table('et_lead')->select('et_lead.sno')
                ->where('et_lead.created_by', $staffId)
                ->whereYear('et_lead.registered_date', $year)
                ->whereMonth('et_lead.registered_date', $month)
                ->whereNotIn('et_lead.status', [2, 6])
                ->where('et_lead.spam_verified', 0)
                ->where('et_lead.drop_verified', 0)
                ->where('et_lead.internal_status', 0)
                ->count();

            // 3. Spam Leads for this staff
            $staffSpamLeads = DB::table('et_lead')->select('et_lead.sno')
                ->whereYear('et_lead.registered_date', $year)
                ->whereMonth('et_lead.registered_date', $month)
                ->where('et_lead.created_by', $staffId)
                ->where('et_lead.spam_verified', 1)
                ->where('et_lead.status', 7)
                ->count();

            // 4. Dead Leads for this staff
            $staffDeadLeads = DB::table('et_lead')->select('et_lead.sno')
                ->whereYear('et_lead.registered_date', $year)
                ->whereMonth('et_lead.registered_date', $month)
                ->where('et_lead.created_by', $staffId)
                ->where('et_lead.drop_verified', 1)
                ->where('et_lead.status', 5)
                ->count();

            // 5. Converted Customers for this staff
            $staffConvertedCustomers = DB::table('et_customer')
                ->select('et_customer.sno', 'et_customer.proposal_ids')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_payment', function ($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereRaw('et_payment.transaction_date = (
                        SELECT MIN(ep.transaction_date)
                        FROM et_payment ep
                        WHERE ep.customer_id = et_customer.sno
                    )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->where('et_lead.created_by', $staffId)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->count();

            // 6. Conversion Rate for this staff
            $staffConversionRate = $staffActiveLeads > 0 ?
                ($staffConvertedCustomers / $staffActiveLeads) * 100 : 0;
            $staffConversionRate = number_format($staffConversionRate, 2);

            // 7. ABV & ACV for this staff
            $staffABV = 0;
            $staffACV = 0;

            if ($staffConvertedCustomers > 0) {
                $convertedCustomers = DB::table('et_customer')
                    ->select('et_customer.sno')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                            SELECT MIN(ep.transaction_date)
                            FROM et_payment ep
                            WHERE ep.customer_id = et_customer.sno
                        )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    ->where('et_lead.created_by', $staffId)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->get();

                foreach ($convertedCustomers as $customer) {
                    $proposalIds = DB::table('et_proposal')
                        ->where('et_proposal.customer_id', $customer->sno)
                        ->where('et_proposal.status', 0)
                        ->whereNot('et_proposal.post_sale_check', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->pluck('sno')
                        ->toArray();

                    if (!empty($proposalIds)) {
                        $proposals = DB::table('et_proposal')
                            ->select('et_proposal.*', 'et_country_currencies.currency_code')
                            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                            ->whereIn('et_proposal.sno', $proposalIds)
                            ->get();

                        foreach ($proposals as $proposal) {
                            $paidAmount = DB::table('et_proposal_pay_slot')
                                ->where('proposal_sno', $proposal->sno)
                                ->where('status', 0)
                                ->sum('paidAmount');

                            $grantAmount = $proposal->grant_total_amount;
                            $basePaidLocal = $calculateBaseAmount($paidAmount);

                            if ($proposal->currency_id == 70) {
                                $staffABV += $grantAmount;
                                $staffACV += $basePaidLocal;
                            } else {
                                $currency_code = $proposal->currency_code;
                                $staffABV += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                $staffACV += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                            }
                        }
                    }
                }

                $staffABV = $staffConvertedCustomers > 0 ? $staffABV / $staffConvertedCustomers : 0;
                $staffACV = $staffConvertedCustomers > 0 ? $staffACV / $staffConvertedCustomers : 0;
            }

            // 8. Walk-ins for this staff
            $staffWalkIns = DB::table('et_lead_appointment')
                ->where('appointment_category', 3)
                ->whereYear('appointment_date', $year)
                ->whereMonth('appointment_date', $month)
                ->where('created_by', $staffId)
                ->count();

            // 9. Outgoing calls for this staff
            $staffOutgoingCalls = DB::table('et_call_tracker')
                ->where('branch_staff_id', $staffId)
                ->where('call_status', 0)
                ->whereYear('call_start_date', $year)
                ->whereMonth('call_start_date', $month)
                ->count();

            // 10. One Day Conversion (ODC), Monthly Conversion (MC), Old Month Conversion (OMC)
            $staffODC = $this->calculateODCMulti([$staffId], $month, $year);
            $staffMC = $this->calculateMCMulti([$staffId], $month, $year);
            $staffOMC = $this->calculateOMCMulti([$staffId], $month, $year);

            $staff_img = '';
            if ($staff->staff_image && file_exists(public_path('staff_images/' . $staff->staff_image))) {
                $staff_img = asset('staff_images/' . $staff->staff_image);
            }
            // Prepare data for team members table
            $teamMembersData[] = [
                'id' => $staff->sno,
                'name' => $staff->staff_name,
                'avatar' => $staff_img,
                'role' => $staff->job_position_name,
                'active_leads' => $staffActiveLeads,
                'conversion' => $staffConvertedCustomers,
                'conversion_rate' => $staffConversionRate,
                'avg_business_value' => number_format($staffABV, 2),
                'avg_collection_value' => number_format($staffACV, 2),
                'walk_in' => $staffWalkIns,
                'outgoing_call_rate' => $staffOutgoingCalls, // You might want to calculate a rate here
            ];

            $staff_img = '';
            if ($staff->staff_image && file_exists(public_path('staff_images/' . $staff->staff_image))) {
                $staff_img = asset('staff_images/' . $staff->staff_image);
            }

            // Prepare data for team lead reports table
            $teamLeadReportsData[] = [
                'id' => $staff->sno,
                'name' => $staff->staff_name,
                'avatar' => $staff_img,
                'role' => $staff->job_position_name,
                'total_leads' => $staffTotalLeads,
                'active_leads' => $staffActiveLeads,
                'spam_leads' => $staffSpamLeads,
                'dead_leads' => $staffDeadLeads,
                'converted_customers' => $staffConvertedCustomers,
                'one_day_conversion' => $staffODC,
                'on_month_conversion' => $staffMC,
                'old_month_conversion' => $staffOMC,
            ];

            // Store individual stats
            $individualStaffStats[$staffId] = [
                'total_leads' => $staffTotalLeads,
                'active_leads' => $staffActiveLeads,
                'spam_leads' => $staffSpamLeads,
                'dead_leads' => $staffDeadLeads,
                'converted_customers' => $staffConvertedCustomers,
                'conversion_rate' => $staffConversionRate,
                'avg_business_value' => $staffABV,
                'avg_collection_value' => $staffACV,
                'walk_ins' => $staffWalkIns,
                'outgoing_calls' => $staffOutgoingCalls,
                'odc' => $staffODC,
                'mc' => $staffMC,
                'omc' => $staffOMC,
            ];
        }

        // ============ EXISTING TEAM-LEVEL CALCULATIONS (from your original code) ============
        // ... [Keep all your existing team-level calculations here]
        // 1. TOTAL LEADS
        // $totalLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
        //   ->whereIn('et_lead.created_by', $staffIds)
        //   ->whereNotIn('et_lead.status', [2, 6])
        //   ->whereYear('et_lead.registered_date', $year)
        //   ->whereMonth('et_lead.registered_date', $month)
        //   ->count();

        // $totalLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
        //   ->whereIn('et_lead.created_by', $staffIds)
        //   ->whereNotIn('et_lead.status', [2, 6])
        //   ->whereYear('et_lead.registered_date', $prevYear)
        //   ->whereMonth('et_lead.registered_date', $prevMonth)
        //   ->count();

        // $totalLeadsPercentage = $calculatePercentage($totalLeadsCurrent, $totalLeadsPrev);
        // $totalLeadsColor = $getColor($totalLeadsCurrent, $totalLeadsPrev);

        // // 2. ACTIVE LEADS
        // $activeLeadsCurrent = DB::table('et_lead')->select('et_lead.sno')
        //   ->whereIn('et_lead.created_by', $staffIds)
        //   ->whereYear('et_lead.registered_date', $year)
        //   ->whereMonth('et_lead.registered_date', $month)
        //   ->whereNotIn('et_lead.status', [2, 6])
        //   ->where('et_lead.spam_verified', 0)
        //   ->where('et_lead.drop_verified', 0)
        //   ->where('et_lead.internal_status', 0)
        //   ->count();

        // $activeLeadsPrev = DB::table('et_lead')->select('et_lead.sno')
        //   ->whereIn('et_lead.created_by', $staffIds)
        //   ->whereYear('et_lead.registered_date', $prevYear)
        //   ->whereMonth('et_lead.registered_date', $prevMonth)
        //   ->whereNotIn('et_lead.status', [2, 6])
        //   ->where('et_lead.spam_verified', 0)
        //   ->where('et_lead.drop_verified', 0)
        //   ->where('et_lead.internal_status', 0)
        //   ->count();

        // $activeLeadsPercentage = $calculatePercentage($activeLeadsCurrent, $activeLeadsPrev);
        // $activeLeadsColor = $getColor($activeLeadsCurrent, $activeLeadsPrev);

        // ... [Continue with all your existing team-level calculations]

        // ============ RETURN DATA WITH INDIVIDUAL STAFF STATS ============

        // Return all data
        return response()->json([
            // Basic stats
            'staff_details' => $staff_details,
            'total_leads' => $totalLeadsCurrent,
            'total_leads_percentage' => round($totalLeadsPercentage, 1) . '%',
            'total_leads_prev' => $totalLeadsPrev,
            'total_leads_color' => $totalLeadsColor,

            // INDIVIDUAL STAFF DATA
            'team_members' => $teamMembersData,
            'team_lead_reports' => $teamLeadReportsData,
            'individual_stats' => $individualStaffStats,

            'active_leads' => $activeLeadsCurrent,
            'active_leads_percentage' => round($activeLeadsPercentage, 1) . '%',
            'active_leads_color' => $activeLeadsColor,
            'active_leads_prev' => $activeLeadsPrev,

            'spam_leads' => $spamLeadsCurrent,
            'spam_leads_percentage' => round($spamLeadsPercentage, 1) . '%',
            'spam_leads_color' => $spamLeadsColor,
            'spam_leads_prev' => $spamLeadsPrev,

            'dead_leads' => $deadLeadsCurrent,
            'dead_leads_percentage' => round($deadLeadsPercentage, 1) . '%',
            'dead_leads_color' => $deadLeadsColor,
            'dead_leads_prev' => $deadLeadsPrev,

            // Conversion stats
            'converted_customers' => $convertedCountCurrent,
            'converted_customers_percentage' => round($convertedPercentage, 1) . '%',
            'converted_customers_color' => $convertedColor,

            'conversion_ratio' => $conversionRatioCurrent,
            'average_business_value' => number_format($averageBusinessValue, 2),
            'average_collection_value' => number_format($averageCollectionValue, 2),
            'converted_today' => $convertedToday,

            // Conversation stats
            'odc_count' => $odcCount,
            'mc_count' => $mcCount,
            'omc_count' => $omcCount,

            // Avg
            'avg_walk_in' => $avgmonthwalkincount,
            'avg_missed_calls' => $avgMonthMissedCallCount,
            'avg_followups' => $avgmonthFollowupCount,
            'avg_appointments' => $avgMonthappointmentsCount,

            // Dynamic lists
            'appointment_schedule' => $todayAppointmentsTeam,
            'low_mpc_list' => $low_mpc_list,
            'followup_schedule' => $filteredAppointment,

            // Target
            'StaffTarget' => $StaffTarget,

            // Current month/year for reference
            'current_month' => $month,
            'current_year' => $year,
            'filter_date' => $dateFilter ?? date('M-Y')

        ]);
    }

    private function calculateODCMulti($staffIds, $month, $year)
    {
        $cusData = DB::table('et_customer')
            ->select('et_customer.sno', 'et_payment.transaction_date')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->get();

        $leadData = DB::table('et_customer')
            ->select('et_lead.registered_date', 'et_customer.sno as cus_sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->whereIn('et_lead.created_by', $staffIds)
            ->where('et_customer.status', 0)
            ->get();

        return $cusData->filter(function ($item) use ($leadData) {
            $lead = $leadData->firstWhere('cus_sno', $item->sno);
            return $lead && $item->transaction_date == $lead->registered_date;
        })->count();
    }

    private function calculateMCMulti($staffIds, $month, $year)
    {
        $mcCount = DB::table('et_customer')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->whereYear('et_lead.registered_date', $year)
            ->whereMonth('et_lead.registered_date', $month)
            ->count();

        $odcCount = $this->calculateODCMulti($staffIds, $month, $year);
        return max(0, $mcCount - $odcCount);
    }

    private function calculateOMCMulti($staffIds, $month, $year)
    {
        return DB::table('et_customer')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                    SELECT MIN(ep.transaction_date)
                    FROM et_payment ep
                    WHERE ep.customer_id = et_customer.sno
                )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->whereIn('et_lead.created_by', $staffIds)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->where(function ($query) use ($year, $month) {
                $query->whereYear('et_lead.registered_date', '<', $year)
                    ->orWhere(function ($query) use ($year, $month) {
                        $query->whereYear('et_lead.registered_date', $year)
                            ->whereMonth('et_lead.registered_date', '<', $month);
                    });
            })
            ->count();
    }
    ##################*************############ Journal Coordinator Dashboard#################*************************
    public function getJournalDashboard(Request $request)
    {
        $user = $request->user();
        $userId = $user->user_id;
        $dateFilter = $request->input('date', date('M-Y'));

        try {
            $date = Carbon::createFromFormat('M-Y', $dateFilter);
            $month = $date->month;
            $year = $date->year;
        } catch (\Exception $e) {
            $date = Carbon::now();
            $month = $date->month;
            $year = $date->year;
        }

        $currentMonth = date('m');
        $currentYear = date('Y');

        // Get the total present days (attendance = 'P')

        $startDate   = Carbon::create($currentYear, $currentMonth, 1);
        $currentDate = Carbon::now();

        $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth)
            ? $currentDate
            : $startDate->copy()->endOfMonth();

        // Count working days (exclude Sundays)
        $workingDays = 0;
        $loopDate = $startDate->copy();

        while ($loopDate->lte($endDate)) {
            if (!$loopDate->isSunday()) {
                $workingDays++;
            }
            $loopDate->addDay();
        }

        // Present days count
        $presentDaysCOUNT = DB::table('et_staff_attendance')
            ->where('staff_id', $userId)
            ->where('attendance', 'P')
            ->whereMonth('date', $currentMonth)
            ->whereYear('date', $currentYear)
            ->count();

        // Attendance percentage
        $presentDays = $workingDays > 0
            ? ($presentDaysCOUNT / $workingDays) * 100
            : 0;

        $staff_details = DB::table('et_staff')
            ->where('et_staff.sno', $userId)
            ->select('et_staff.sno', 'et_staff.branch_id', 'et_staff.status', 'et_staff.staff_name', 'et_staff.staff_image', 'et_job_position.job_position_name')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->first();

        // Get previous month for comparison
        $prevMonthDate = Carbon::create($year, $month, 1)->subMonth();
        $prevMonth = $prevMonthDate->month;
        $prevYear = $prevMonthDate->year;

        // Fetch all counts
        $publishedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 8)
            ->whereMonth('et_journal_history.published_date', $month)
            ->whereYear('et_journal_history.published_date', $year)
            ->count();

        $publishedPrevMonth = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 8)
            ->whereMonth('et_journal_history.published_date', $prevMonth)
            ->whereYear('et_journal_history.published_date', $prevYear)
            ->count();

        $submittedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 0)
            ->whereMonth('et_journal_history.submitted_date', $month)
            ->whereYear('et_journal_history.submitted_date', $year)
            ->count();

        $submittedPrevMonth = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 0)
            ->whereMonth('et_journal_history.submitted_date', $prevMonth)
            ->whereYear('et_journal_history.submitted_date', $prevYear)
            ->count();

        $withEditorCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 1)
            ->whereMonth('et_journal_history.with_editor_date', $month)
            ->whereYear('et_journal_history.with_editor_date', $year)
            ->count();

        $withEditorPrevMonth = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 1)
            ->whereMonth('et_journal_history.with_editor_date', $prevMonth)
            ->whereYear('et_journal_history.with_editor_date', $prevYear)
            ->count();

        $underReviewerCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 3)
            ->whereMonth('et_journal_history.under_reviewer_date', $month)
            ->whereYear('et_journal_history.under_reviewer_date', $year)
            ->count();

        $underReviewerPrevMonth = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 3)
            ->whereMonth('et_journal_history.under_reviewer_date', $prevMonth)
            ->whereYear('et_journal_history.under_reviewer_date', $prevYear)
            ->count();

        $rejectedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 6)
            ->whereMonth('et_journal_history.rejected_date', $month)
            ->whereYear('et_journal_history.rejected_date', $year)
            ->count();

        $rejectedPrevMonth = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 6)
            ->whereMonth('et_journal_history.rejected_date', $prevMonth)
            ->whereYear('et_journal_history.rejected_date', $prevYear)
            ->count();

        $revisionCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 4)
            ->whereMonth('et_journal_history.reviewed_date', $month)
            ->whereYear('et_journal_history.reviewed_date', $year)
            ->count();

        $revisionPrevMonth = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 4)
            ->whereMonth('et_journal_history.reviewed_date', $prevMonth)
            ->whereYear('et_journal_history.reviewed_date', $prevYear)
            ->count();

        $acceptedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 5)
            ->whereMonth('et_journal_history.accepted_date', $month)
            ->whereYear('et_journal_history.accepted_date', $year)
            ->count();

        $acceptedPrevMonth = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 5)
            ->whereMonth('et_journal_history.accepted_date', $prevMonth)
            ->whereYear('et_journal_history.accepted_date', $prevYear)
            ->count();

        $eproofingCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 7) // Assuming 7 is eproofing status
            ->whereMonth('et_journal_history.e_proofing_date', $month)
            ->whereYear('et_journal_history.e_proofing_date', $year)
            ->count();

        $eproofingPrevMonth = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 7)
            ->whereMonth('et_journal_history.e_proofing_date', $prevMonth)
            ->whereYear('et_journal_history.e_proofing_date', $prevYear)
            ->count();

        $allocatedPaper = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', '!=', 2)
            ->where('et_customer_services.jc_staff', $userId)
            ->whereMonth('et_manage_journal.created_at', $month)
            ->whereYear('et_manage_journal.created_at', $year)
            ->count();

        $allocatedPaperPrevMonth = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->where('et_manage_journal.status', '!=', 2)
            ->where('et_customer_services.jc_staff', $userId)
            ->whereMonth('et_manage_journal.created_at', $prevMonth)
            ->whereYear('et_manage_journal.created_at', $prevYear)
            ->count();

        $pendingPublication = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->whereNotIn('et_manage_journal.status', [0, 2, 8])
            ->where('et_customer_services.jc_staff', $userId)
            ->whereMonth('et_manage_journal.created_at', $month)
            ->whereYear('et_manage_journal.created_at', $year)
            ->count();

        $pendingPublicationPrevMonth = DB::table('et_manage_journal')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
            ->whereNotIn('et_manage_journal.status', [0, 2, 8])
            ->where('et_customer_services.jc_staff', $userId)
            ->whereMonth('et_manage_journal.created_at', $prevMonth)
            ->whereYear('et_manage_journal.created_at', $prevYear)
            ->count();

        $overallClients = DB::table('et_customer_services')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_customer_services.journal_check', 1)
            ->distinct('customer_id')
            ->count('customer_id');

        $targetData = DB::table('et_goal_set_staff')
            ->where('staff_id', $userId)
            ->whereMonth('goal_date', $month)
            ->whereYear('goal_date', $year)
            // ->select('no_of_papers')
            ->first();
        $PBtarget = $targetData->no_of_papers ?? 0;

        // Monthly published data for chart
        $monthlyPublished = DB::table('et_journal_history')
            ->join('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 8)
            ->whereYear('et_journal_history.published_date', $year)
            ->selectRaw('MONTH(et_journal_history.published_date) as month, COUNT(*) as count')
            ->groupByRaw('MONTH(et_journal_history.published_date)')
            ->orderByRaw('MONTH(et_journal_history.published_date)')
            ->get()
            ->keyBy('month');

        $chartData = [];
        for ($m = 1; $m <= 12; $m++) {
            $chartData[] = $monthlyPublished[$m]->count ?? 0;
        }

        // Return JSON data instead of HTML
        return response()->json([
            'status' => 200,
            'data' => [
                'userName' => $staff_details->staff_name ?? 'User',
                'avatar' => $staff_details->staff_image ?? '',
                'publishedCount' => $publishedCount,
                'publishedPrevMonth' => $publishedPrevMonth,
                'submittedCount' => $submittedCount,
                'submittedPrevMonth' => $submittedPrevMonth,
                'withEditorCount' => $withEditorCount,
                'withEditorPrevMonth' => $withEditorPrevMonth,
                'underReviewerCount' => $underReviewerCount,
                'underReviewerPrevMonth' => $underReviewerPrevMonth,
                'rejectedCount' => $rejectedCount,
                'rejectedPrevMonth' => $rejectedPrevMonth,
                'revisionCount' => $revisionCount,
                'revisionPrevMonth' => $revisionPrevMonth,
                'acceptedCount' => $acceptedCount,
                'acceptedPrevMonth' => $acceptedPrevMonth,
                'eproofingCount' => $eproofingCount,
                'eproofingPrevMonth' => $eproofingPrevMonth,
                'allocatedPaper' => $allocatedPaper,
                'allocatedPaperPrevMonth' => $allocatedPaperPrevMonth,
                'pendingPublication' => $pendingPublication,
                'pendingPublicationPrevMonth' => $pendingPublicationPrevMonth,
                'overallClients' => $overallClients,
                'PBtarget' => $PBtarget,
                'presentDays' => $presentDays,
            ],
            'chartData' => $chartData
        ]);
    }
    public function getJournalTeamLeadDashboard(Request $request)
    {
        $user = $request->user();
        $userId = $user->user_id;
        $branchId = $user->branch_id;
        $dateFilter = $request->input('date', date('M-Y'));
        $helper = new \App\Helpers\Helpers();
        try {
            $date = Carbon::createFromFormat('M-Y', $dateFilter);
            $month = $date->month;
            $year = $date->year;
        } catch (\Exception $e) {
            $date = Carbon::now();
            $month = $date->month;
            $year = $date->year;
        }

        $currentMonth = date('m');
        $currentYear  = date('Y');

        $startDate   = Carbon::create($currentYear, $currentMonth, 1);
        $currentDate = Carbon::now();

        $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth)
            ? $currentDate
            : $startDate->copy()->endOfMonth();

        // Count working days (exclude Sundays)
        $workingDays = 0;
        $loopDate = $startDate->copy();

        while ($loopDate->lte($endDate)) {
            if (!$loopDate->isSunday()) {
                $workingDays++;
            }
            $loopDate->addDay();
        }

        // Present days count
        $presentDaysCOUNT = DB::table('et_staff_attendance')
            ->where('staff_id', $userId)
            ->where('attendance', 'P')
            ->whereMonth('date', $currentMonth)
            ->whereYear('date', $currentYear)
            ->count();

        // Attendance percentage
        $presentDays = $workingDays > 0 ? ($presentDaysCOUNT / $workingDays) * 100 : 0;
        $staff_details = DB::table('et_staff')
            ->where('et_staff.sno', $userId)
            ->select('et_staff.sno', 'et_staff.branch_id', 'et_staff.status', 'et_staff.staff_name', 'et_staff.staff_image', 'et_job_position.job_position_name')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->first();

        // Get previous month for comparison
        $prevMonthDate = Carbon::create($year, $month, 1)->subMonth();
        $prevMonth = $prevMonthDate->month;
        $prevYear = $prevMonthDate->year;

        // Journal Staffs
        $Jcstaff = DB::table('et_staff')->where('et_staff.branch_id', $branchId)
            ->whereIn('et_staff.role_id', [34])
            ->where('et_staff.status', 0)
            // ->where('et_staff.sno', 66)
            ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
            ->join('et_user_role', 'et_staff.role_id', '=', 'et_user_role.sno')
            ->orderBy('staff_name', 'ASC')
            ->get([
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.nick_name',
                'et_staff.gender',
                'et_staff.role_id',
                'et_staff.avaiable_points',
                'et_staff.staff_image',
                'et_department.department_name',
                'et_user_role.role_name'
            ]);


        foreach ($Jcstaff as $jstaff) {

            $jstaffId = $jstaff->sno;

            if ($jstaff->staff_image != '' && file_exists(public_path('staff_images/' . $jstaff->staff_image))) {
                $staff_image = '<img src="' . asset('staff_images/' . $jstaff->staff_image) . '" alt="Staff" class="rounded-circle img-fluid" style="width: 40px; height: 40px; object-fit: cover;" />';
            } else {
                $initial = strtoupper(substr($jstaff->staff_name, 0, 1)); // Gets the first letter
                $staff_image = $helper->name_image($initial, $jstaff->gender);
            }

            $jstaff->staff_avatar = $staff_image;
            $jstaff->publishedCount = DB::table('et_journal_history')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
                ->where('et_customer_services.jc_staff', $jstaffId)
                ->whereMonth('et_journal_history.created_at', $month)
                ->whereYear('et_journal_history.created_at', $year)
                ->where('et_journal_history.status', 8)
                ->whereMonth('et_journal_history.published_date', $month)
                ->count();

            $jstaff->submittedCount = DB::table('et_journal_history')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
                ->where('et_customer_services.jc_staff', $jstaffId)
                ->whereMonth('et_journal_history.created_at', $month)
                ->whereYear('et_journal_history.created_at', $year)
                ->where('et_journal_history.status', 0)
                ->whereMonth('et_journal_history.submitted_date', $month)
                ->count();

            $jstaff->withEditorCount = DB::table('et_journal_history')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
                ->where('et_customer_services.jc_staff', $jstaffId)
                ->whereMonth('et_journal_history.created_at', $month)
                ->whereYear('et_journal_history.created_at', $year)
                ->where('et_journal_history.status', 1)
                ->whereMonth('et_journal_history.with_editor_date', $month)
                ->count();

            $jstaff->underReviewerCount = DB::table('et_journal_history')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
                ->where('et_customer_services.jc_staff', $jstaffId)
                ->whereMonth('et_journal_history.created_at', $month)
                ->whereYear('et_journal_history.created_at', $year)
                ->where('et_journal_history.status', 3)
                ->whereMonth('et_journal_history.under_reviewer_date', $month)
                ->count();

            $jstaff->rejectedCount = DB::table('et_journal_history')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
                ->where('et_customer_services.jc_staff', $jstaffId)
                ->whereMonth('et_journal_history.created_at', $month)
                ->whereYear('et_journal_history.created_at', $year)
                ->where('et_journal_history.status', 6)
                ->whereMonth('et_journal_history.rejected_date', $month)
                ->count();

            $jstaff->revisionCount = DB::table('et_journal_history')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
                ->where('et_customer_services.jc_staff', $jstaffId)
                ->whereMonth('et_journal_history.created_at', $month)
                ->whereYear('et_journal_history.created_at', $year)
                ->where('et_journal_history.status', 4)
                ->whereMonth('et_journal_history.reviewed_date', $month)
                ->count();

            $jstaff->acceptedCount = DB::table('et_journal_history')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
                ->where('et_customer_services.jc_staff', $jstaffId)
                ->whereMonth('et_journal_history.created_at', $month)
                ->whereYear('et_journal_history.created_at', $year)
                ->where('et_journal_history.status', 5)
                ->whereMonth('et_journal_history.accepted_date', $month)
                ->count();

            $jstaff->eproofingCount = DB::table('et_journal_history')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
                ->where('et_customer_services.jc_staff', $jstaffId)
                ->whereMonth('et_journal_history.created_at', $month)
                ->whereYear('et_journal_history.created_at', $year)
                ->where('et_journal_history.status', 7)
                ->whereMonth('et_journal_history.e_proofing_date', $month)
                ->count();

            $jstaff->allocatedPaper = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->where('et_customer_services.jc_staff', $jstaffId)
                ->where('et_manage_journal.status', '!=', 2)
                ->whereMonth('et_manage_journal.created_at', $month)
                ->whereYear('et_manage_journal.created_at', $year)
                ->count();

            $jstaff->pendingPublication = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->where('et_customer_services.jc_staff', $jstaffId)
                ->whereNotIn('et_manage_journal.status', [0, 2, 8])
                ->whereMonth('et_manage_journal.created_at', $month)
                ->whereYear('et_manage_journal.created_at', $year)
                ->count();

            $jstaff->total_journals = DB::table('et_manage_journal')
                ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->where('et_customer_services.jc_staff', $jstaffId)
                ->whereNotIn('et_manage_journal.status', [2])
                ->whereMonth('et_manage_journal.created_at', $month)
                ->whereYear('et_manage_journal.created_at', $year)
                ->count();



            $jstaff->overallClients = DB::table('et_customer_services')
                ->where('jc_staff', $jstaffId)
                ->where('journal_check', 1)
                ->distinct()
                ->count('customer_id');

            $targetData = DB::table('et_goal_set_staff')
                ->where('staff_id', $jstaffId)
                ->whereMonth('goal_date', $month)
                ->whereYear('goal_date', $year)
                // ->select('no_of_papers')
                ->first();
            $jstaff->target = $targetData->no_of_papers ?? 0;

            $jstaff->pc_not_assign = DB::table('et_journal_revision')
                ->where('jc_id', $jstaffId)
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', '<', 2)
                ->whereNull('pc_id')
                ->count();

            $jstaff->pending_verification = DB::table('et_journal_revision')
                ->where('jc_id', $jstaffId)
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', 5)
                ->count();
        }

        // Return JSON data instead of HTML
        return response()->json([
            'status' => 200,
            'data' => [
                'userName' => $staff_details->staff_name ?? 'User',
                'avatar' => $staff_details->staff_image ?? '',
                'presentDays' => $presentDays,
                'JcStaffList' => $Jcstaff,
            ]
        ]);
    }

    ##################*************############ Project Coordinator Dashboard#################*************************
    public function getProjectCoordinatorDashboard(Request $request)
    {
        $helper = new \App\Helpers\Helpers();

        // Get authenticated user
        $user = $request->user();
        $branchId = $request->user()->branch_id;
        // Get month filter from request (default to current month)
        $monthFilter = $request->input('date_filter', Carbon::now()->format('M-Y'));

        // Parse the month-year string
        try {
            $date = Carbon::createFromFormat('M-Y', $monthFilter);
        } catch (\Exception $e) {
            $date = Carbon::now();
        }


        $startDate = $date->copy()->startOfMonth();
        $endDate = $date->copy()->endOfMonth();

        $year = $date->year;
        $month = $date->month;
        $daysInMonth = $date->daysInMonth;
        $displayMonthYear = $date->format('M-Y');
        $userID = $user->user_id;

        try {

            $summary = [
                'total_services' => DB::table('et_customer_services')
                    ->whereMonth('created_at', $month)
                    ->whereYear('created_at', $year)
                    ->where('pc_id', $userID)
                    ->count(),

                'total_journals' => DB::table('et_customer_services')
                    ->whereMonth('created_at', $month)
                    ->whereYear('created_at', $year)
                    ->where('pc_id', $userID)
                    ->where('journal_check', 1)
                    ->count(),

                'qc_verification' => DB::table('et_daily_tasks')
                    ->join('et_customer_services', 'et_daily_tasks.service_id', '=', 'et_customer_services.sno')
                    ->where('et_customer_services.pc_id', $userID)
                    ->whereMonth('et_daily_tasks.task_date', $month)
                    ->whereYear('et_daily_tasks.task_date', $year)
                    ->where('et_daily_tasks.status', 3)
                    ->count(),

                'new_requests' => DB::table('et_manage_requirement')
                    ->whereMonth('created_at', $month)
                    ->whereYear('created_at', $year)
                    ->where('pc_id', $userID)
                    ->count(),

                'rework_tasks' => DB::table('et_daily_tasks')
                    ->join('et_customer_services', 'et_daily_tasks.service_id', '=', 'et_customer_services.sno')
                    ->where('et_customer_services.pc_id', $userID)
                    ->whereMonth('et_daily_tasks.task_date', $month)
                    ->whereYear('et_daily_tasks.task_date', $year)
                    ->where('et_daily_tasks.rework_check', 1)
                    ->count(),

                'total_tasks' => DB::table('et_daily_tasks')
                    ->join('et_customer_services', 'et_daily_tasks.service_id', '=', 'et_customer_services.sno')
                    ->where('et_customer_services.pc_id', $userID)
                    ->whereMonth('et_daily_tasks.task_date', $month)
                    ->whereYear('et_daily_tasks.task_date', $year)
                    ->count(),
            ];

            // 3. PENDING & APPROVALS
            $pendings = [
                'unassigned_requirements' => DB::table('et_manage_requirement')
                    ->whereMonth('created_at', $month)
                    ->whereYear('created_at', $year)
                    ->where('pc_id', $userID)
                    ->where(function ($query) {
                        $query->whereNull('staff_id')
                            ->orWhere('staff_id', 0);
                    })
                    ->count(),

                'awaiting_approvals' => DB::table('et_manage_requirement')
                    ->whereMonth('created_at', $month)
                    ->whereYear('created_at', $year)
                    ->where('pc_id', $userID)
                    ->where('staff_approval', '>', 0)
                    ->count(),
                'unassigned_appointments' => DB::table('et_lead_appointment')
                    ->whereMonth('appointment_date', $month)
                    ->whereYear('appointment_date', $year)
                    ->where('pc_id', $userID)
                    ->where(function ($query) {
                        $query->whereNull('staff_id')
                            ->orWhere('staff_id', 0);
                    })
                    ->count(),
                'unassigned_revisions' => DB::table('et_journal_revision')
                    ->whereMonth('created_at', $month)
                    ->whereYear('created_at', $year)
                    ->where('pc_id', $userID)
                    ->where(function ($query) {
                        $query->whereNull('staff_id')
                            ->orWhere('staff_id', 0);
                    })
                    ->count(),
            ];

            // 4. MONTHLY TASK COUNT FOR STAFF
            $monthlyTasks = [];

            // // Get all active staff members
            $staffMembers =  DB::table('et_staff')
                ->where('et_staff.branch_id', $branchId)
                ->whereIn('et_staff.role_id', [32, 36])
                ->where('et_staff.status', 0)
                // ->where('et_staff.sno', 66)
                ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
                ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
                ->join('et_user_role', 'et_staff.role_id', '=', 'et_user_role.sno')
                ->orderBy('staff_name', 'ASC')
                ->get([
                    'et_staff.sno',
                    'et_staff.staff_id',
                    'et_staff.staff_name',
                    'et_staff.nick_name',
                    'et_staff.gender',
                    'et_staff.role_id',
                    'et_staff.avaiable_points',
                    'et_staff.staff_image',
                    'et_department.department_name',
                    'et_job_position.job_position_name',
                    'et_user_role.role_name'
                ]);

            // // If no real staff members, create sample data
            if ($staffMembers->isEmpty()) {
            } else {
                foreach ($staffMembers as $staff) {
                    $dailyTasks = array_fill(1, $daysInMonth, 0);

                    $staffTasks = DB::table('et_daily_tasks')
                        ->select(
                            DB::raw('DAY(task_date) as day'),
                            DB::raw('COUNT(*) as task_count')
                        )
                        ->where('staff_id', $staff->sno)
                        ->whereYear('task_date', $year)
                        ->whereMonth('task_date', $month)
                        ->groupBy(DB::raw('DAY(task_date)'))
                        ->get();

                    foreach ($staffTasks as $task) {
                        if ($task->day >= 1 && $task->day <= $daysInMonth) {
                            $dailyTasks[$task->day] = $task->task_count;
                        }
                    }


                    if ($staff->staff_image != '' && file_exists(public_path('staff_images/' . $staff->staff_image))) {
                        $staff_image = asset('staff_images/' . $staff->staff_image);
                    } else {
                        $staff_image = '';
                    }

                    $avatar = $staff_image;

                    $monthlyTasks[] = [
                        'id' => $staff->staff_id,
                        'name' => $staff->staff_name,
                        'role' => $staff->job_position_name,
                        'avatar' => $avatar,
                        'daily_tasks' => $dailyTasks
                    ];
                }
            }

            // Prepare final response
            $response = [
                'success' => true,
                'summary' => $summary,
                'pendings' => $pendings,
                'monthly_tasks' => $monthlyTasks,
                'month_info' => [
                    'user_id' => $userID,
                    'month_name' => $date->format('F'),
                    'year' => $year,
                    'month' => $month,
                    'days_in_month' => $daysInMonth,
                    'display_month' => $displayMonthYear,
                ],
                'filters' => [
                    'selected_month' => $displayMonthYear,
                    'date_range' => [
                        'start' => $startDate->format('Y-m-d'),
                        'end' => $endDate->format('Y-m-d'),
                    ],
                ],
                'timestamp' => Carbon::now()->toDateTimeString(),
            ];

            return response()->json($response);
        } catch (\Exception $e) {
            // \Log::error('Dashboard Error: ' . $e->getMessage(), [
            //   'trace' => $e->getTraceAsString(),
            //   'request' => $request->all(),
            //   'user_id' => Auth::id(),
            // ]);

            // Return sample data in case of error
            $response = [
                'Error' => $e->getMessage(),
                'month_info' => [
                    'user_id' => $userID,
                    'month_name' => $date->format('F'),
                    'year' => $year,
                    'month' => $month,
                    'days_in_month' => $daysInMonth,
                    'display_month' => $displayMonthYear,
                ],
                'filters' => [
                    'selected_month' => $displayMonthYear,
                    'date_range' => [
                        'start' => $startDate->format('Y-m-d'),
                        'end' => $endDate->format('Y-m-d'),
                    ],
                ],
                'timestamp' => Carbon::now()->toDateTimeString(),
            ];

            return response()->json($response);
        }
    }

    public function getAvailableMonths()
    {
        try {
            $months = DB::table('tasks')
                ->select(
                    DB::raw('YEAR(created_at) as year'),
                    DB::raw('MONTH(created_at) as month'),
                    DB::raw('DATE_FORMAT(created_at, "%b-%Y") as display')
                )
                ->groupBy('year', 'month', 'display')
                ->orderByDesc('year')
                ->orderByDesc('month')
                ->limit(12)
                ->get()
                ->map(function ($item) {
                    return [
                        'value' => $item->display,
                        'label' => Carbon::create($item->year, $item->month, 1)->format('F Y'),
                    ];
                });

            $currentMonth = Carbon::now()->format('M-Y');
            $currentMonthLabel = Carbon::now()->format('F Y');

            if (!$months->contains('value', $currentMonth)) {
                $months->prepend([
                    'value' => $currentMonth,
                    'label' => $currentMonthLabel,
                ]);
            }

            return response()->json([
                'success' => true,
                'months' => $months,
                'current_month' => $currentMonth,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'months' => [
                    ['value' => Carbon::now()->format('M-Y'), 'label' => Carbon::now()->format('F Y')],
                    ['value' => Carbon::now()->subMonth()->format('M-Y'), 'label' => Carbon::now()->subMonth()->format('F Y')],
                    ['value' => Carbon::now()->subMonths(2)->format('M-Y'), 'label' => Carbon::now()->subMonths(2)->format('F Y')],
                ],
                'current_month' => Carbon::now()->format('M-Y'),
                'error' => config('app.debug') ? $e->getMessage() : null,
            ]);
        }
    }
    ##################*************############ CRE Coordinator Dashboard#################*************************
    public function getcreDashboard(Request $request)
    {
        $helper = new \App\Helpers\Helpers();

        // Get authenticated user
        $user = $request->user();
        $branchId = $request->user()->branch_id;

        // Get month filter from request (default to current month)
        $monthFilter = $request->input('date_filter', Carbon::now()->format('M-Y'));

        // Parse the month-year string
        try {
            $date = Carbon::createFromFormat('M-Y', $monthFilter);
        } catch (\Exception $e) {
            $date = Carbon::now();
        }
        $year = $date->year;
        $month = $date->month;
        $displayMonthYear = $date->format('M-Y');
        $userID = $user->user_id;
        $staffId = $userID;

        // 1. Get PreSale Customers assigned to this CRE for the selected month
        $presale_customers = DB::table('et_customer')
            ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.customer_id = et_customer.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->whereNotIn('et_proposal.proposal_status', [0, 1, 2])
            ->where('et_proposal.status', 0)
            ->where('et_proposal.cre_id', $staffId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_proposal.post_sale_check', 0)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->count();

        // 2. Get PostSale Customers (customers after sale completion)
        $postSaleCustomers = DB::table('et_customer')
            ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.customer_id = et_customer.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->whereNotIn('et_proposal.proposal_status', [0, 1, 2])
            ->where('et_proposal.status', 0)
            ->where('et_proposal.cre_id', $staffId)
            ->whereYear('et_proposal.post_sale_date', $year)
            ->whereMonth('et_proposal.post_sale_date', $month)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->count();

        // 3. Get Total Customers provided to customers
        $totalCustomers = $presale_customers + $postSaleCustomers;

        // 4. Get Dropped Customers
        $droppedCustomers = DB::table('et_drop_refund')->where('type', 0)
            ->where('created_by', $staffId)
            ->where('bh_status', 1)
            ->whereMonth('bh_status_date', $month)
            ->whereYear('bh_status_date', $year)
            ->count();


        // 5. Get Refunded Customers
        $refundedCustomers = DB::table('et_drop_refund')->where('type', 0)
            ->where('created_by', $staffId)
            ->where('bh_status', 2)
            ->whereMonth('bh_status_date', $month)
            ->whereYear('bh_status_date', $year)
            ->count();

        // 6. Get Not Yet Started Customers
        $notYetStarted = DB::table('et_customer_services')
            ->where('cre_id', $staffId)
            ->whereMonth('created_at', $month)
            ->whereYear('created_at', $year)
            // ->where('status', 0)
            ->count();

        // // 7. Harvest Details (Payment collections)
        // $payments = \App\Models\Payment::whereHas('customer', function ($query) use ($staffId) {
        //   $query->where('cre_id', $staffId);
        // })
        //   ->whereBetween('payment_date', [$startDate, $endDate])
        //   ->get();

        // $totalAmount = $payments->sum('amount');
        // $paidAmount = $payments->where('status', 'paid')->sum('amount');
        // $balanceAmount = $payments->where('status', 'pending')->sum('amount');
        // $paymentsLeft = $payments->where('status', 'pending')->count();

        // $balancePercentage = $totalAmount > 0 ? ($balanceAmount / $totalAmount) * 100 : 0;

        // // 8. Outstanding Details
        // $outstandingPayments = \App\Models\Payment::whereHas('customer', function ($query) use ($staffId) {
        //   $query->where('cre_id', $staffId);
        // })
        //   ->where('status', 'pending')
        //   ->get();

        // // Categorize outstanding payments
        // $currentMonth = Carbon::now()->month;
        // $currentYear = Carbon::now()->year;
        // $nextMonth = Carbon::now()->addMonth()->month;
        // $nextYear = Carbon::now()->addMonth()->year;

        // $outstandingThisMonth = $outstandingPayments
        //   ->filter(function ($payment) use ($currentMonth, $currentYear) {
        //     $paymentDate = Carbon::parse($payment->due_date);
        //     return $paymentDate->month == $currentMonth &&
        //       $paymentDate->year == $currentYear;
        //   })
        //   ->sum('amount');

        // $outstandingNextMonth = $outstandingPayments
        //   ->filter(function ($payment) use ($nextMonth, $nextYear) {
        //     $paymentDate = Carbon::parse($payment->due_date);
        //     return $paymentDate->month == $nextMonth &&
        //       $paymentDate->year == $nextYear;
        //   })
        //   ->sum('amount');

        // $outstandingUpcoming = $outstandingPayments
        //   ->filter(function ($payment) use ($nextMonth, $nextYear) {
        //     $paymentDate = Carbon::parse($payment->due_date);
        //     return $paymentDate->month > $nextMonth ||
        //       ($paymentDate->month == $nextMonth && $paymentDate->year > $nextYear);
        //   })
        //   ->sum('amount');

        // $outstandingOverall = $outstandingPayments->sum('amount');
        // $outstandingPaymentsLeft = $outstandingPayments->count();

        // // 9. Appointment Details
        $appointments = DB::table('et_manage_appointments')
            ->where('created_by', $staffId)
            ->whereMonth('appointment_date', $month)
            ->whereYear('appointment_date', $year)
            ->where('status', '!=', 2)
            ->selectRaw('
        COUNT(*) as totalAppointments,
        SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) as scheduledAppointments,
        SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as completedAppointments,
        SUM(CASE WHEN status = 3 THEN 1 ELSE 0 END) as cancelledAppointments
    ')
            ->first();

        $totalAppointments     = $appointments->totalAppointments;
        $scheduledAppointments = $appointments->scheduledAppointments;
        $completedAppointments = $appointments->completedAppointments;
        $cancelledAppointments = $appointments->cancelledAppointments;



        // 10. Review Details
        $reviews = DB::table('et_manage_review')
            ->where('created_by', $staffId)
            ->whereMonth('created_at', $month)
            ->whereYear('created_at', $year)
            ->get();

        $totalReviews = $reviews->count();

        // Get review distribution by rating
        $reviewDistribution = [
            '1_star' => $reviews->where('ratings', 1)->count(),
            '2_star' => $reviews->where('ratings', 2)->count(),
            '3_star' => $reviews->where('ratings', 3)->count(),
            '4_star' => $reviews->where('ratings', 4)->count(),
            '5_star' => $reviews->where('ratings', 5)->count(),
        ];

        // Prepare the response data
        $dashboardData = [
            'total_customers' => $totalCustomers,
            'postsale_customers' => $postSaleCustomers,
            'presale_customers' => $presale_customers,
            'dropped_customers' => $droppedCustomers,
            'refunded_customers' => $refundedCustomers,
            'not_yet_started' => $notYetStarted,

            'harvest' => [
                'payments_left' => $paymentsLeft ?? 0,
                'total_amount' => $totalAmount ?? 0,
                'paid_amount' => $paidAmount ?? 0,
                'balance_amount' => $balanceAmount ?? 0,
                'balance_percentage' => round($balancePercentage ?? 0, 2)
            ],

            'outstanding' => [
                'payments_left' => $outstandingPaymentsLeft ?? 0,
                'this_month' => $outstandingThisMonth ?? 0,
                'next_month' => $outstandingNextMonth ?? 0,
                'upcoming' => $outstandingUpcoming ?? 0,
                'overall' => $outstandingOverall ?? 0,
            ],

            'appointments' => [
                'total' => $totalAppointments ?? 0,
                'scheduled' => $scheduledAppointments ?? 0,
                'cancelled' => $cancelledAppointments ?? 0,
                'completed' => $completedAppointments ?? 0,
            ],

            'reviews' => [
                'total' => $totalReviews,
                'distribution' => $reviewDistribution,
                'chart_data' => [
                    $reviewDistribution['1_star'],
                    $reviewDistribution['2_star'],
                    $reviewDistribution['3_star'],
                    $reviewDistribution['4_star'],
                    $reviewDistribution['5_star']
                ]
            ],

            'meta' => [
                'month_year' => $displayMonthYear,
                'month' => $month,
                'year' => $year,
                'staff_name' => $user->staff->staff_name ?? 'CRE',
                'branch' => $user->branch->branch_name ?? 'Unknown'
            ]
        ];

        return response()->json([
            'success' => true,
            'data' => $dashboardData,
            'message' => 'Dashboard data fetched successfully'
        ]);
    }

    /**
     * Get CEO Dashboard Data - Single Function
     */
    public function getCeoDashboardData(Request $request)
    {
        // 1. INITIALIZATION
        $user = $request->user();
        $branchId = $user->branch_id ?? 1;
        $branch_id = $branchId;
        $dateFilter = $request->get('date_filter', date('M-Y'));
        $today = date('Y-m-d');
        $helper = new \App\Helpers\Helpers();

        // Parse date
        try {
            $date = Carbon::createFromFormat('M-Y', $dateFilter);
            $month = $date->month;
            $year = $date->year;
        } catch (\Exception $e) {
            $date = Carbon::now();
            $month = $date->month;
            $year = $date->year;
        }

        // Previous month for comparison
        $prevMonthDate = Carbon::create($year, $month, 1)->subMonth();
        $prevMonth = $prevMonthDate->month;
        $prevYear = $prevMonthDate->year;

        // Helper functions
        $formatCurrency = function ($amount) {
            return '₹ ' . number_format($amount, 2);
        };

        // 2. BUSINESS GOAL SET
        $targetDate = $year . '-' . $month . '-01';
        // Fetch target
        $targets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
            ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
            ->where('branch_target.date', $targetDate)
            ->select('branch_target.*') // Ensure you're returning only target column
            ->first();

        $branch = BranchModel::where('sno', $branch_id)
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->first();

        $gstPercentage = $branch ? $branch->gst_percentage  : 18;

        $transactionTotalNet = 0; // final net after GST

        // 1. INR transactions
        $transactionInr = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_lead.status', '!=', 2)
            ->where('et_customer.status', 0)
            ->where('et_transaction.payment_status', 1)
            ->where('et_payment.currency', 'INR')
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->select('et_payment.paid_amount as paidAmount', 'et_proposal.gst_perc')
            ->get();

        foreach ($transactionInr as $row) {
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc / 100 : ($branch ? $branch->gst_percentage / 100 : 0.18);
            $net = $row->paidAmount / (1 + $gstRate);
            $transactionTotalNet += $net;
        }

        // 2. Non-INR with already converted INR total
        $transactionNonInrConvert = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_lead.status', '!=', 2)
            ->where('et_customer.status', 0)
            ->where('et_transaction.payment_status', 1)
            ->whereNot('et_payment.currency', 'INR')
            ->where('et_transaction.total_amount_inr', '>', 0)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->select('et_transaction.total_amount_inr', 'et_proposal.gst_perc')
            ->get();

        foreach ($transactionNonInrConvert as $row) {
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc / 100 : ($branch ? $branch->gst_percentage / 100 : 0.18);
            $net = $row->total_amount_inr / (1 + $gstRate);
            $transactionTotalNet += $net;
        }

        // 3. Non-INR need conversion
        $transactionNonInr = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_lead.status', '!=', 2)
            ->where('et_customer.status', 0)
            ->where('et_transaction.payment_status', 1)
            ->whereNot('et_payment.currency', 'INR')
            ->where(function ($q) {
                $q->where('et_transaction.total_amount_inr', '<', 0)
                    ->orWhereNull('et_transaction.total_amount_inr');
            })
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->select('et_payment.paid_amount as paidAmount', 'et_proposal.gst_perc', 'et_country_currencies.currency_code')
            ->get();

        foreach ($transactionNonInr as $row) {
            $convertedInr = $helper->ConvertedAmountInr($row->currency_code, $row->paidAmount);
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc / 100 : ($branch ? $branch->gst_percentage / 100 : 0.18);
            $net = $convertedInr / (1 + $gstRate);
            $transactionTotalNet += $net;
        }

        // Final net collection (matches verified_collection_net style)
        $targetActual = round($transactionTotalNet, 2);

        $customerConvertDataPost = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_customer.cus_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                    ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.proposal_id = et_proposal.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', '>', 1)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();

        $postSaleActual = count($customerConvertDataPost);

        $customerConvertData = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                             SELECT MIN(ep.transaction_date)
                             FROM et_payment ep
                             WHERE ep.customer_id = et_customer.sno
                         )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', '>', 1)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();

        $preSaleActual = count($customerConvertData);

        // 3. SALES TARGETS & ACHIEVED
        $salesTargets =  $this->getSalesTeamTargets($branch_id, $month, $year);

        $currentDate = now()->toDateString();

        $drop_ids = DB::table('et_customer')
            ->where('et_customer.drop_refund_id', '!=', 0)
            ->where('et_customer.drop_verified', 1)
            ->pluck('et_customer.sno');

        $OutstandingPayment = DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->leftJoin('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->whereNotIn('et_proposal.proposal_status', [0, 2])
            ->select(
                'et_proposal_pay_slot.sno',
                DB::raw('MAX(et_proposal.currency_id) AS currency_id'),
                DB::raw('MAX(et_country_currencies.currency_code) AS currency_code'),
                DB::raw('MAX(et_country_currencies.currency_symbol) AS currency_symbol'),
                DB::raw('MAX(et_proposal_pay_slot.propo_pay_slot_id) AS payment_id'),
                DB::raw('MAX(et_payment.sno) AS payment_sno'),
                DB::raw('MAX(et_customer.jumper_skiper) AS jumper_skiper'),
                DB::raw('MAX(et_payment.branch_id) AS branch_id'),
                DB::raw('MAX(et_customer.customer_id) AS customer_id'),
                DB::raw('MAX(et_customer.sno) AS customer_sno'),
                DB::raw('MAX(et_proposal_pay_slot.initialPayDate) AS initialPayDate'),
                DB::raw('MAX(et_proposal_pay_slot.nextPayDate) AS nextPayDate'),
                DB::raw('MAX(et_proposal_pay_slot.payable_amount) AS amount'),
                DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS paidAmount'),
                DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS gst_amount'),
                DB::raw('MAX(et_proposal_pay_slot.total_amount) AS total_amount'),
                DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS balanceFee'),
                DB::raw('MAX(et_payment.payment_mode) AS payment_mode_label'),
                DB::raw('MAX(et_proposal_pay_slot.paid_status) AS payment_status'),
                DB::raw('MIN(et_customer.cus_name) AS cus_name'),
                DB::raw('MAX(et_customer.cus_pic) AS cus_pic'),
                DB::raw('MAX(et_customer.cus_gender) AS cus_gender'),
                DB::raw('MAX(et_customer.cus_mobile) AS cus_mobile'),
                DB::raw('MAX(et_customer.cus_email_id) AS cus_email_id'),
                DB::raw('MAX(et_customer.status) AS cus_status'),
                DB::raw('MAX(et_proposal.service_title) AS service_title'),
                DB::raw('MAX(et_proposal.sno) AS proposal_sno'),
                DB::raw('MAX(et_proposal.proposal_id) AS proposal_id')
            )
            ->where('et_proposal_pay_slot.paid_status', 0)
            ->where('et_proposal_pay_slot.status', 0)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->where('et_customer.status', '!=', 2)
            ->where('et_lead.status', '!=', 2)
            ->whereNotIn('et_customer.sno', $drop_ids)
            ->where('et_lead.created_by', '>', 1)
            ->whereDate('et_proposal_pay_slot.nextPayDate', '<=', $currentDate)
            ->orderBy('et_proposal_pay_slot.nextPayDate', 'ASC')
            ->groupBy('et_proposal_pay_slot.sno')
            ->get();

        $OutstandingPaymentCount =   count($OutstandingPayment);

        $paymentNotVerifyCount = DB::table('et_transaction')
            ->join('et_customer', 'et_customer.sno', '=', 'et_transaction.customer_id')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_customer.status', '!=', 2)
            ->where('et_lead.status', '!=', 2)
            ->where('et_transaction.status', 0)
            ->where('et_transaction.customer_type', 0)
            ->where('et_transaction.payment_status', 0)
            ->where('et_transaction.branch_id', $branchId)
            ->count();

        // Fetch Branch details once and use it efficiently
        // Get the current date
        $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

        // Get branch details
        $branch = BranchModel::where('sno', $branch_id)
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->first();

        // Handle case where no branch is found
        if (!$branch) {
            return redirect()->back()->with('error', 'Branch not found.');
        }

        // Sum of the amounts
        $sumScheduleAmount = DB::table('et_proposal_pay_slot')
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.proposal_sno', '>', 0)
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->whereNotIn('et_proposal.proposal_status', [0, 2])
            ->where('et_proposal.status', 0)
            ->where('et_customer.status', '!=', 2)
            ->sum('et_proposal_pay_slot.payable_amount');

        $sumPaidAmount = DB::table('et_proposal_pay_slot')
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.proposal_sno', '>', 0)
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->whereNotIn('et_proposal.proposal_status', [0, 2])
            ->where('et_proposal.status', 0)
            ->where('et_customer.status', '!=', 2)
            ->sum('et_proposal_pay_slot.paidAmount');

        $sumBalanceFee = $sumScheduleAmount - $sumPaidAmount;
        $helper = new \App\Helpers\Helpers();

        // Retrieve payments for the given branch and group by customer and course with aggregation
        $PaidUnderPayment = DB::table('et_proposal')
            ->join('et_payment', 'et_proposal.sno', '=', 'et_payment.proposal_id')
            ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
            ->join('et_customer', 'et_customer.sno', '=', 'et_payment.customer_id')
            ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->select(
                'et_customer.customer_id',
                'et_payment.proposal_id',
                'et_proposal.currency_id',
                'et_country_currencies.currency_code',
                'et_country_currencies.currency_symbol',
                'et_payment.payment_mode',
                'et_payment.payment_id',
                'et_transaction.total_amount_inr',
                'et_customer.sno as customer_sno',
                'et_customer.cus_name',
                'et_customer.cus_gender',
                'et_customer.cus_pic',
                'et_customer.cus_mobile',
                'et_customer.cus_email_id',
                'et_proposal.service_title',
                'et_proposal.total_amount',
                'et_proposal.proposal_id as auto_proposal_id',
                'et_proposal.sno as proposal_primary_id',
                'et_payment.transaction_date',
                'et_proposal_pay_slot.paidAmount',
                'et_proposal_pay_slot.nextPayDate',
                'et_proposal_pay_slot.initialPayDate'
            )
            ->where('et_payment.branch_id', $branch_id)
            ->where('et_customer.status', '!=', 2)
            ->where('et_lead.status', '!=', 2)
            ->where('et_lead.created_by', '>', 1)
            ->whereNotIn('et_proposal.proposal_status', [0, 2])
            ->groupBy(
                'et_customer.customer_id',
                'et_customer.sno',
                'et_payment.payment_id',
                'et_proposal.currency_id',
                'et_country_currencies.currency_code',
                'et_country_currencies.currency_symbol',
                'et_transaction.total_amount_inr',
                'et_payment.payment_mode',
                'et_customer.cus_name',
                'et_customer.cus_mobile',
                'et_customer.cus_pic',
                'et_customer.cus_gender',
                'et_customer.cus_email_id',
                'et_proposal.service_title',
                'et_proposal.proposal_id',
                'et_proposal.sno',
                'et_proposal.total_amount',
                'et_payment.transaction_date',
                'et_payment.proposal_id',
                'et_proposal_pay_slot.paidAmount',
                'et_proposal_pay_slot.nextPayDate',
                'et_proposal_pay_slot.initialPayDate'
            )
            ->orderByDesc('et_payment.sno')
            ->get()
            ->unique('proposal_id'); // Keep only unique customer records;

        foreach ($PaidUnderPayment as $pay) {
            $sumPaidAmount = DB::table('et_proposal_pay_slot')
                ->where('et_proposal_pay_slot.branch_id', $branch_id)
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->whereNotIn('et_proposal.proposal_status', [0, 2])
                ->where('et_proposal.status', 0)
                ->where('et_proposal_pay_slot.proposal_sno', $pay->proposal_primary_id)
                ->where('et_customer.status', '!=', 2)
                ->sum('et_proposal_pay_slot.paidAmount');

            $pay->paidAmount = $sumPaidAmount;
        }

        // return $PaidUnderPayment;
        // Filter the results for customers with unpaid or insufficient amounts (below min_required)
        $result = $PaidUnderPayment->filter(function ($payment) use ($branch, $helper) {

            $paid = $payment->paidAmount;

            // Convert to INR only when not INR
            if ($payment->currency_id != 70) {

                if (!empty($payment->total_amount_inr) && $payment->total_amount_inr > 0) {
                    $paid = $payment->total_amount_inr;
                } else {
                    $paid = $helper->ConvertedAmountInr($payment->currency_code, $paid);
                }
            }

            return $paid < $branch->min_prd_cost;
        });

        // Group by customer_id
        // Apply the filter to the result set first
        $filteredResult = $result->groupBy('customer_id')->map(function ($payments) use ($branch) {
            // Filter payments where paidAmount is greater than 0
            $filteredPayments = $payments->filter(function ($payment) {
                return $payment->paidAmount > 0;
            });

            // If no valid payments exist after filtering, exclude this customer
            if ($filteredPayments->isEmpty()) {
                return null;
            }

            $payment = $payments->first();

            // Return structured data for each customer
            return [
                'customer_name' => $payment->cus_name,
                'customer_sno' => $payment->customer_sno,
                'total_paid' => $payment->paidAmount,
                'min_required' => $branch->min_prd_cost,
                'status' => 'Pending',
                'payments' => $filteredPayments->sortBy('transaction_date')->map(function ($payment) {
                    return [
                        'service_title' => $payment->service_title,
                        'auto_proposal_id' => $payment->auto_proposal_id,
                        'cus_gender' => $payment->cus_gender,
                        'cus_pic' => $payment->cus_pic,
                        'payment_id' => $payment->payment_id,
                        'total_amount_inr' => $payment->total_amount_inr,
                        'currency_symbol' => $payment->currency_symbol,
                        'currency_code' => $payment->currency_code,
                        'currency_id' => $payment->currency_id,
                        'cus_name' => $payment->cus_name,
                        'cus_mobile' => $payment->cus_mobile,
                        'amount' => $payment->total_amount,
                        'paidAmount' => $payment->paidAmount,
                        'balanceFee' => $payment->total_balance_fee ?? 0,
                        'gst_amount' => $payment->total_gst_amount ?? 0,
                        'nextPayDate' => $payment->nextPayDate,
                        'initialPayDate' => $payment->initialPayDate,
                        'transaction_date' => $payment->transaction_date,
                        'payment_mode_label' => $payment->payment_mode == 1 ? 'Online' : 'Offline',
                    ];
                })->values(), // Reset array keys
            ];
        })->filter();

        // Now, calculate the total count based on the filtered result
        $totalItems = $filteredResult->count();

        // Get the count of low_mpc_list
        $low_mpc_list_count = $totalItems ?? 0;


        // // 4. ALERT SYSTEM
        $alerts = [
            // Staff Attendance
            'attendance_target' => DB::table('et_staff')
                ->where('branch_id', $branchId)
                ->where('status', 0)
                ->where('sno', '>', 1)
                ->count(),
            'attendance_actual' => DB::table('et_staff_attendance')
                ->whereDate('date', $today)
                ->where('branch_id', $branchId)
                ->where('attendance', 'P')
                ->count(),

            // Outstanding Count
            'outstanding_count' => $OutstandingPaymentCount,

            // // Low MPC Count
            'low_mpc_count' => $low_mpc_list_count,

            // Customer Not Yet Started
            'customer_not_started' => $paymentNotVerifyCount
        ];

        // // 5. APPROVAL PENDING ALERT



        $approvalPending = [

            'drop_waiting' => DB::table('et_drop_refund')
                ->where('branch_id', $branchId)
                ->where('type', 0)
                ->where('bh_status', 0)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count(),

            'refund_waiting' => DB::table('et_drop_refund')
                ->where('branch_id', $branchId)
                ->where('type', 1)
                ->where('bh_status', 0)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count(),

            'accounts_confirmation' =>  0,

            'login_approval' => DB::table('users')
                ->where('branch_id', $branchId)
                ->where('task_timer', 1)
                ->count(),
        ];

        // // 6. LEAD STATUS
        $salesstaffIds = DB::table('et_staff')
            // ->where('status', 0)
            ->where('department_id', 1)
            ->pluck('sno');

        $allLeadCount = DB::table('et_lead')->whereIn('created_by', $salesstaffIds)
            ->where('branch_id', $branchId)
            ->whereNotIn('status', [2, 6])
            ->where('spam_verified', 0)
            ->where('drop_verified', 0)
            ->where('internal_status', 0)
            ->count();

        $monthLeadCount = DB::table('et_lead')->whereIn('created_by', $salesstaffIds)
            ->where('branch_id', $branchId)
            ->whereYear('registered_date', $year)
            ->whereMonth('registered_date', $month)
            ->whereNotIn('status', [2, 6])
            ->where('spam_verified', 0)
            ->where('drop_verified', 0)
            ->where('internal_status', 0)
            ->count();

        $customerConvertCount =  DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                          SELECT MIN(ep.transaction_date)
                          FROM et_payment ep
                          WHERE ep.customer_id = et_customer.sno
                      )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.branch_id', $branchId)
            ->whereIn('et_lead.created_by', $salesstaffIds)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->count();

        $spamLeadCount = DB::table('et_lead')->whereIn('created_by', $salesstaffIds)
            ->where('branch_id', $branchId)
            ->whereYear('registered_date', $year)
            ->whereMonth('registered_date', $month)
            ->where('spam_verified', 1)
            ->where('status', 7)
            ->count();

        $deadLeadCount = DB::table('et_lead')->whereIn('created_by', $salesstaffIds)
            ->where('branch_id', $branchId)
            ->whereYear('registered_date', $year)
            ->whereMonth('registered_date', $month)
            ->where('drop_verified', 1)
            ->where('status', 5)
            ->count();

        $leadStatus = (object)[
            'allLeadCount' => $allLeadCount,
            'monthLeadCount' => $monthLeadCount,
            'customerConvertCount' => $customerConvertCount,
            'spamLeadCount' => $spamLeadCount,
            'deadLeadCount' => $deadLeadCount,
        ];

        // // 7. SERVICE STATUS
        $milequery = DB::table('et_milestone_mapping')
            ->where('et_milestone_mapping.status', '!=', 2)
            ->where('et_milestone_mapping.bh_verfication', 0)
            ->where('et_milestone_mapping.is_completed', '!=', 1)
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer_services.sno',
            )
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_milestone_mapping.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_milestone_mapping.service_id')
            ->groupBy([
                'et_customer_services.sno',
                'et_customer.cus_name',
                'et_customer.customer_id',
            ])->orderBy('et_milestone_mapping.sno', 'desc')->get();
        $serviceStatus = [

            'total' => DB::table('et_customer_services')
                ->where('branch_id', $branchId)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count(),

            'staff_allocated' => DB::table('et_customer_services')
                ->where('branch_id', $branchId)
                ->whereNull('production_staffs_id')
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count(),

            'milestone_pending' => $milequery ? count($milequery) : 0,

            'unmapped_milestone' => DB::table('et_milestone_mapping')
                ->where('branch_id', $branchId)
                ->where('status', 0)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count()
        ];

        // // 8. JOURNAL STATUS
        // Get previous month for comparison

        // Fetch all counts
        $publishedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            // ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 8)
            ->whereMonth('et_journal_history.published_date', $month)
            ->whereYear('et_journal_history.published_date', $year)
            ->count();

        $submittedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            // ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 0)
            ->whereMonth('et_journal_history.submitted_date', $month)
            ->whereYear('et_journal_history.submitted_date', $year)
            ->count();

        $withEditorCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            // ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 1)
            ->whereMonth('et_journal_history.with_editor_date', $month)
            ->whereYear('et_journal_history.with_editor_date', $year)
            ->count();

        $underReviewerCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            // ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 3)
            ->whereMonth('et_journal_history.under_reviewer_date', $month)
            ->whereYear('et_journal_history.under_reviewer_date', $year)
            ->count();

        $rejectedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            // ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 6)
            ->whereMonth('et_journal_history.rejected_date', $month)
            ->whereYear('et_journal_history.rejected_date', $year)
            ->count();

        $revisionCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            // ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 4)
            ->whereMonth('et_journal_history.reviewed_date', $month)
            ->whereYear('et_journal_history.reviewed_date', $year)
            ->count();

        $acceptedCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            // ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 5)
            ->whereMonth('et_journal_history.accepted_date', $month)
            ->whereYear('et_journal_history.accepted_date', $year)
            ->count();

        $eproofingCount = DB::table('et_journal_history')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
            // ->where('et_customer_services.jc_staff', $userId)
            ->where('et_journal_history.status', 7) // Assuming 7 is eproofing status
            ->whereMonth('et_journal_history.e_proofing_date', $month)
            ->whereYear('et_journal_history.e_proofing_date', $year)
            ->count();

        $journalStatus = [
            'published' => $publishedCount,
            'submitted' => $submittedCount,
            'with_editor' => $withEditorCount,
            'under_review' => $underReviewerCount,
            'rejected' => $rejectedCount,
            'revision' => $revisionCount,
            'accepted' => $acceptedCount,
            'eproofing' => $eproofingCount
        ];

        // 9. REVISION STATUS
        $revisionStatus = [

            'jtl_verification' =>  DB::table('et_journal_revision')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', 0)
                ->count(),

            'staff_assigned' => DB::table('et_journal_revision')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', 4)
                ->count(),

            'inprogress' => DB::table('et_journal_revision')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', 5)
                ->count(),

            'completed' => DB::table('et_journal_revision')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', 9)
                ->count(),

            'waiting_documentation' => DB::table('et_journal_revision')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', 6)
                ->count(),

            'pc_not_assign' => DB::table('et_journal_revision')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', 1)
                ->count(),

            'rework' => DB::table('et_journal_revision')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', '>', 9)
                ->count(),

            'staff_not_assign' => DB::table('et_journal_revision')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', 3)
                ->count(),

            'pc_pending_verification' => DB::table('et_journal_revision')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', 7)
                ->count(),

            'jtl_pending_verification' => DB::table('et_journal_revision')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->where('status', 8)
                ->count()
        ];

        // 13. FINAL RESPONSE
        return response()->json([
            'success' => true,
            'data' => [
                'month' => date('F', strtotime("$year-$month-01")),
                'year' => $year,
                'current_month' => $dateFilter,
                'business_goal' => [
                    'target' => (float)($targets->monthly_target ?? 0),
                    'actual' => (float)($targetActual ?? 0),
                    'post_sale_target' => (int)($targets->post_sale ?? 0),
                    'post_sale_actual' => (int)($postSaleActual ?? 0),
                    'pre_sale_target' => (int)($targets->no_of_registrations ?? 0),
                    'pre_sale_actual' => (int)($preSaleActual ?? 0)
                ],
                'sales_targets' => [
                    'conversion_target' => (int)($salesTargets->conversion_over_all ?? 0),
                    'conversion_actual' => (int)($salesTargets->conversion_actual ?? 0),
                    'conversion_rate_target' => round((float)($salesTargets->cr_over_all ?? 0), 2),
                    'conversion_rate_actual' => round((float)($salesTargets->cr_actual ?? 0), 2),
                    'avg_business_target' => (float)($salesTargets->abv_over_all ?? 0),
                    'avg_business_actual' => (float)($salesTargets->abv_actual ?? 0),
                    'avg_conversion_target' => (float)($salesTargets->acv_over_all ?? 0),
                    'avg_conversion_actual' => (float)($salesTargets->acv_actual ?? 0)
                ],
                'alerts' => $alerts,
                'approval_pending' => $approvalPending,
                'lead_status' => [
                    'total' => (int)($leadStatus->allLeadCount ?? 0),
                    'active' => (int)($leadStatus->monthLeadCount ?? 0),
                    'spam' => (int)($leadStatus->spamLeadCount ?? 0),
                    'dead' => (int)($leadStatus->deadLeadCount ?? 0),
                    'converted' => (int)($leadStatus->customerConvertCount ?? 0)
                ],
                'service_status' => $serviceStatus,
                'journal_status' => $journalStatus,
                'revision_status' => $revisionStatus
            ]
        ]);
    }

    // =================== HELPER FUNCTIONS ===================

    private function getSalesTeamTargets($branchId, $month, $year)
    {
        $departmentId = 1;
        // Fetch the department details
        $department = DepartmentModel::where('status', 0)->where('sno', $departmentId)->first(['sno', 'department_name']);

        // Get goal records for the selected department and month
        $goalteam = GoalSetTeamModel::where('department_id', $departmentId)
            ->where('branch_id', $branchId)
            ->where('team_goal_month', $month)
            ->first();

        if (!$goalteam) {
            return response()->json([
                'status' => 402,
                'data'   => []
            ]);
        }


        $staff = DB::table('et_staff')
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.gender',
                'et_staff.mobile_no',
                'et_staff.role_id',
                'et_staff.lead_bank_count',
                'et_staff.status as staff_status',
                'et_cug_management.staff_mobile as cug_mobile'
            )
            ->leftJoin('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', $departmentId)
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.branch_id', $branchId)
            ->where('et_staff.status', 0)
            ->orderBy('et_staff.sno', 'desc')->get();
        // Initialize Totals



        $totalDepartmentAllLead = 0;
        $totalDepartmentMonthLead = 0;
        $totalDepartmentHotLead = 0;
        $totalDepartmentSpamLead = 0;
        $totalDepartmentDeadLead = 0;
        $totalDepartmentConvertCustomer = 0;
        $totalDepartmentBusinessValue = 0;
        $totalDepartmentCollectionValue = 0;
        $totalDepartmentPaidPayment = 0;
        $totalDepartmentTotalPayment = 0;
        $totalmonthFollowupCount = 0;
        $totalmonthwalkincount = 0;
        $totalmonthcall_outcount = 0;

        $working_hoursActual   = 0;
        $rework_countActual   = 0;

        // return $departmentId;
        // Goal Completed
        if (isset($goalteam)) {
            // return $goalteam->goal_completed;
            if ($goalteam->goal_completed == 1) {
                // PRE & Post Sales
                $totalDepartmentConvertCustomer =  $goalteam->conversion_actual;
                $totalConvertRatio =  $goalteam->cr_actual;
                $totalDepartmentBusinessValue =  $goalteam->abv_actual;
                $totalDepartmentCollectionValue =  $goalteam->acv_actual;
                $total_outgoing_call_ratio =  $goalteam->avg_call_out_actual;
                $totalmonthwalkincount =  $goalteam->no_of_walk_actual;
                $totalmonthFollowupCount =  $goalteam->no_of_followup_actual;
                // PRODUCTION
                $working_hoursActual =  $goalteam->working_hours_actual;
                $rework_countActual =  $goalteam->rework_actual;


                $goalteamDetails = (object)[
                    'department_name' => optional($department)->department_name ?? '',
                    'department_id'   => optional($department)->sno ?? '',
                    'team_id'         => optional($goalteam)->sno ?? '',
                    'ten_x'           => json_decode(optional($goalteam)->ten_x ?? '{}', true),
                    'status'          => optional($goalteam)->status == 1 ? true : false,
                    'month'           => $month,

                    'conversion_over_all'           => optional($goalteam)->conversion_over_all ?? 0,
                    'conversion_check'              => optional($goalteam)->conversion_check ?? 0,
                    'conversion_type'               => optional($goalteam)->conversion_type ?? 0,
                    'conversion_actual'             => $totalDepartmentConvertCustomer ?? 0,

                    'cr_over_all'                   => optional($goalteam)->cr_over_all ?? 0,
                    'cr_check'                      => optional($goalteam)->cr_check ?? 0,
                    'cr_type'                       => optional($goalteam)->cr_type ?? 0,
                    'cr_actual'                     => $totalConvertRatio ?? 'N/A',


                    'abv_over_all'                  => optional($goalteam)->abv_over_all ?? 0,
                    'abv_check'                     => optional($goalteam)->abv_check ?? 0,
                    'abv_type'                      => optional($goalteam)->abv_type ?? 0,
                    'abv_actual'                    => $totalDepartmentBusinessValue ?? 0,

                    'acv_over_all'                  => optional($goalteam)->acv_over_all ?? 0,
                    'acv_check'                     => optional($goalteam)->acv_check ?? 0,
                    'acv_type'                      => optional($goalteam)->acv_type ?? 0,
                    'acv_actual'                    => $totalDepartmentCollectionValue ?? 0,

                    // 'avg_call_out_over_all'         => optional($goalteam)->avg_call_out_over_all ?? 0,
                    // 'avg_call_out_check'            => optional($goalteam)->avg_call_out_check ?? 0,
                    // 'avg_call_out_type'             => optional($goalteam)->avg_call_out_type ?? 0,
                    // 'avg_call_out_actual'           => $total_outgoing_call_ratio ?? 0,

                    // 'no_of_walk_over_all'           => optional($goalteam)->no_of_walk_over_all ?? 0,
                    // 'no_of_walk_check'              => optional($goalteam)->no_of_walk_check ?? 0,
                    // 'no_of_walk_type'               => optional($goalteam)->no_of_walk_type ?? 0,
                    // 'no_of_walk_actual'             => $totalmonthwalkincount ?? 0,

                    // 'no_of_followup_over_all'       => optional($goalteam)->no_of_followup_over_all ?? 0,
                    // 'no_of_followup_check'          => optional($goalteam)->no_of_followup_check ?? 0,
                    // 'no_of_followup_type'           => optional($goalteam)->no_of_followup_type ?? 0,
                    // 'no_of_followup_actual'         => $totalmonthFollowupCount ?? 0,

                    // 'working_hours_over_all'        => optional($goalteam)->working_hours_over_all ?? 0,
                    // 'working_hours_check'           => optional($goalteam)->working_hours_check ?? 0,
                    // 'working_hours_type'            => optional($goalteam)->working_hours_type ?? 0,
                    // 'working_hours_actual'          => $working_hoursActual ?? 0,

                    // 'rework_over_all'   => optional($goalteam)->rework_over_all ?? 0,
                    // 'rework_check'      => optional($goalteam)->rework_check ?? 0,
                    // 'rework_type'       => optional($goalteam)->rework_type ?? 0,
                    // 'rework_actual'     => $rework_countActual ?? 0,

                ];
            } else {

                // ##############################################################################################
                // ******************************** Pre Sales Department ****************************************
                // ##############################################################################################
                if ($departmentId == 1) {

                    foreach ($staff as $member) {
                        // Leads Count
                        $allLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
                            ->where('branch_id', $branchId)
                            ->whereNotIn('status', [2, 6])
                            ->where('spam_verified', 0)
                            ->where('drop_verified', 0)
                            ->where('internal_status', 0)
                            ->count();
                        $monthLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
                            ->where('branch_id', $branchId)
                            ->whereYear('registered_date', $year)
                            ->whereMonth('registered_date', $month)
                            ->whereNotIn('status', [2, 6])
                            ->where('spam_verified', 0)
                            ->where('drop_verified', 0)
                            ->where('internal_status', 0)
                            ->count();
                        $hotLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
                            ->where('branch_id', $branchId)
                            ->whereYear('registered_date', $year)
                            ->whereMonth('registered_date', $month)
                            ->whereNotIn('status', [2, 6])
                            ->where('lead_status_id', 3)
                            ->where('internal_status', 0)
                            ->where('spam_verified', 0)
                            ->where('drop_verified', 0)
                            ->count();
                        $customerConvertCount =  DB::table('et_customer')
                            ->select('et_customer.sno', 'et_customer.proposal_ids')
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_payment', function ($join) {
                                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                    ->whereRaw('et_payment.transaction_date = (
                                  SELECT MIN(ep.transaction_date)
                                  FROM et_payment ep
                                  WHERE ep.customer_id = et_customer.sno
                              )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.branch_id', $branchId)
                            ->where('et_lead.created_by', $member->sno)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->count();

                        $spamLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
                            ->where('branch_id', $branchId)
                            ->whereYear('registered_date', $year)
                            ->whereMonth('registered_date', $month)
                            ->where('spam_verified', 1)
                            ->where('status', 7)
                            ->count();

                        $deadLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
                            ->where('branch_id', $branchId)
                            ->whereYear('registered_date', $year)
                            ->whereMonth('registered_date', $month)
                            ->where('drop_verified', 1)
                            ->where('status', 5)
                            ->count();

                        // Follow-ups & Walk-ins
                        $monthFollowupCount = DB::table('et_appointment')
                            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
                            ->whereIn('et_lead.status', [0, 4])
                            ->where('et_appointment.created_by', $member->sno)
                            ->whereYear('et_appointment.appointment_date', $year)
                            ->whereMonth('et_appointment.appointment_date', $month)
                            ->count();

                        $monthwalkincount = DB::table('et_lead_appointment')
                            ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
                            ->where('et_lead_appointment.appointment_category', 3)
                            ->where('et_lead_appointment.created_by', $member->sno)
                            ->whereYear('et_lead_appointment.appointment_date', $year)
                            ->whereMonth('et_lead_appointment.appointment_date', $month)
                            ->count();

                        // Call Out Count
                        $monthcall_out = DB::table('et_call_tracker')
                            ->whereYear('call_start_date', $year)
                            ->whereMonth('call_start_date', $month)
                            ->where('et_call_tracker.branch_id', $branchId)
                            ->where('et_call_tracker.branch_staff_id', $member->sno)
                            ->where('call_status', 0)
                            ->count();

                        // Update Department Totals
                        $totalDepartmentAllLead += $allLeadCount;
                        $totalDepartmentMonthLead += $monthLeadCount;
                        $totalDepartmentHotLead += $hotLeadCount;
                        $totalDepartmentSpamLead += $spamLeadCount;
                        $totalDepartmentDeadLead += $deadLeadCount;
                        $totalDepartmentConvertCustomer += $customerConvertCount;
                        $totalmonthFollowupCount += $monthFollowupCount;
                        $totalmonthwalkincount += $monthwalkincount;
                        $totalmonthcall_outcount += $monthcall_out;

                        // Payments Calculation
                        $totalPayment = 0;
                        $totalPaidPayment = 0;

                        if ($customerConvertCount > 0) {
                            $currentMonthCustomer = DB::table('et_customer')
                                ->select('et_customer.sno', 'et_customer.proposal_ids')
                                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                ->join('et_payment', function ($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                          SELECT MIN(ep.transaction_date)
                          FROM et_payment ep
                          WHERE ep.customer_id = et_customer.sno
                      )');
                                })
                                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                                ->where('et_customer.status', 0)
                                ->where('et_customer.branch_id', $branchId)
                                ->where('et_lead.created_by', $member->sno)
                                ->whereYear('et_payment.transaction_date', $year)
                                ->whereMonth('et_payment.transaction_date', $month)
                                ->where('et_transaction.payment_status', 1)
                                ->orderBy('et_customer.sno', 'asc')
                                ->get();



                            $customerConvertCount = count($currentMonthCustomer);
                        }

                        $gst_percent = 18;
                        $total_payment             = 0;
                        $total_paid_payment        = 0;
                        $base_amount_paid = 0; // keep track of GST-excluded total
                        if ($customerConvertCount > 0) {
                            if ($currentMonthCustomer->isNotEmpty()) {
                                foreach ($currentMonthCustomer as $customer) {
                                    $proposal_ids = DB::table('et_proposal')
                                        ->where('et_proposal.customer_id', $customer->sno)
                                        ->where('et_proposal.status', 0)
                                        ->whereNot('et_proposal.post_sale_check', 1)
                                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                        ->pluck('sno')
                                        ->toArray();
                                    // return $proposal_ids;

                                    $proposals = DB::table('et_proposal')
                                        ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                        ->whereIn('et_proposal.sno', $proposal_ids)
                                        ->get();

                                    foreach ($proposals as $proposal) {
                                        // Paid slots for this proposal
                                        $paidAmount = DB::table('et_proposal_pay_slot')
                                            ->where('proposal_sno', $proposal->sno)
                                            ->where('status', 0)
                                            ->sum('paidAmount');

                                        $grantAmount = $proposal->grant_total_amount;

                                        // First remove GST from paidAmount (base value in proposal's currency)
                                        $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

                                        if ($proposal->currency_id == 70) {
                                            // INR: add directly
                                            $total_paid_payment += $paidAmount;
                                            $total_payment += $grantAmount;
                                            $base_amount_paid += $basePaidLocal;
                                        } else {
                                            // Non-INR: convert both amounts and base value
                                            $helper = new \App\Helpers\Helpers();
                                            $currency_code = $proposal->currency_code;
                                            $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                            $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                            $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                        }
                                    }
                                }
                            }
                            // average 
                            $totalDepartmentTotalPayment += $total_payment;
                            $totalDepartmentPaidPayment += $base_amount_paid;
                        }


                        // Sales Exc *****************************************************
                        $drop_ids = DB::table('et_drop_refund')
                            ->where('et_drop_refund.bh_status', 1)
                            ->where('et_drop_refund.branch_id', $branchId);
                    }

                    // Business and Collection Value Calculation
                    $totalDepartmentBusinessValue  = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentTotalPayment / $totalDepartmentConvertCustomer, 2) : 0;

                    $totalDepartmentCollectionValue = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentPaidPayment / $totalDepartmentConvertCustomer, 2) : 0;

                    // Conversion Rate
                    $convertion_rate = $totalDepartmentMonthLead > 0 ? ($totalDepartmentConvertCustomer / $totalDepartmentMonthLead) * 100 : 0;

                    $totalConvertRatio = number_format($convertion_rate, 2);


                    $startDate = Carbon::create($year, $month, 1);
                    $currentDate = Carbon::now();
                    $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
                    $dayCount = $startDate->diffInDays($endDate) + 1;
                    $total_staff = count($staff) ?? 0;
                    $total_outgoing_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($totalmonthcall_outcount / ($total_staff * $dayCount)) : 0;
                    $totalmonthwalkincount     = $dayCount > 0 && $total_staff > 0 ? round($totalmonthwalkincount / ($total_staff * $dayCount)) : 0;
                    $totalmonthFollowupCount   = $dayCount > 0 && $total_staff > 0 ? round($totalmonthFollowupCount / ($total_staff * $dayCount)) : 0;
                    // Prepare goal details response
                    $goalteamDetails = (object)[
                        'department_name' => optional($department)->department_name ?? '',
                        'department_id'   => optional($department)->sno ?? '',
                        'team_id'         => optional($goalteam)->sno ?? '',
                        'ten_x'           => json_decode(optional($goalteam)->ten_x ?? '{}', true),
                        'status'          => optional($goalteam)->status == 1 ? true : false,
                        'month'           => $month,

                        'conversion_over_all'           => optional($goalteam)->conversion_over_all ?? 0,
                        'conversion_check'              => optional($goalteam)->conversion_check ?? 0,
                        'conversion_type'               => optional($goalteam)->conversion_type ?? 0,
                        'conversion_actual'             => $totalDepartmentConvertCustomer ?? 0,

                        'cr_over_all'                   => optional($goalteam)->cr_over_all ?? 0,
                        'cr_check'                      => optional($goalteam)->cr_check ?? 0,
                        'cr_type'                       => optional($goalteam)->cr_type ?? 0,
                        'cr_actual'                     => $totalConvertRatio ?? 'N/A',

                        'abv_over_all'                  => optional($goalteam)->abv_over_all ?? 0,
                        'abv_check'                     => optional($goalteam)->abv_check ?? 0,
                        'abv_type'                      => optional($goalteam)->abv_type ?? 0,
                        'abv_actual'                    => $totalDepartmentBusinessValue ?? 0,

                        'acv_over_all'                  => optional($goalteam)->acv_over_all ?? 0,
                        'acv_check'                     => optional($goalteam)->acv_check ?? 0,
                        'acv_type'                      => optional($goalteam)->acv_type ?? 0,
                        'acv_actual'                    => $totalDepartmentCollectionValue ?? 0,
                    ];
                }
            }
            return $goalteamDetails;
        }
    }
}