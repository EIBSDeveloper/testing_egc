<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use App\Models\LoginApprovalModel;
use App\Models\User;
use App\Models\UserRolePermissionModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class LoginApprovalController extends Controller
{
    // Display login approvals list with pagination
    public function index(Request $request)
    {
        $entity_id   = $request->user()->entity_id;
        $user_id     = $request->user()->user_id;
        $branch_id   = $request->user()->branch_id;

        $search_fill = $request->search_fill ?? '';
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);

        // Using Model with relationships
        $ListTable = LoginApprovalModel::select('et_login_approval.*', 'et_staff.staff_name', 'et_job_position.job_position_name')
            ->leftJoin('et_staff', 'et_login_approval.staff_id', '=', 'et_staff.sno')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role');

        // Apply search filter if present
        if ($search_fill) {
            $ListTable->where(function ($query) use ($search_fill) {
                    $query->where('staff_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('job_position_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('login_code', 'LIKE', "%{$search_fill}%");
            });
        }

        // Order by `sno` and paginate
        $ListTable = $ListTable->orderBy('sno', 'desc')->paginate($perpage);

        // Add remaining time calculation to each approval
        foreach ($ListTable as $approval) {
            // Ensure created_at is properly parsed using Carbon
            $createdAt = \Carbon\Carbon::parse($approval->created_at);
            $expiryMinutes = $approval->expiry_time;
            $expiryTime = $createdAt->addMinutes($expiryMinutes);
            $remaining = now()->diffInMinutes($expiryTime, false);
            // Assign remaining time, ensuring it's not negative
            $approval->remaining_time = max($remaining, 0);
        }

        // return $ListTable;

        $staffIds = DB::table('users')->where('task_timer', 1)->pluck('user_id');
        // Get staff list for dropdown
        $staffList = DB::table('et_staff')
            ->select('et_staff.sno', 'et_staff.branch_id', 'et_staff.status', 'et_staff.staff_name', 'et_job_position.job_position_name')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->where('et_staff.department_id', 2)
            ->where('et_staff.branch_id', $branch_id)
            ->whereIn('et_staff.sno', $staffIds)
            ->orderBy('et_staff.staff_name', "ASC")
            ->get();

        // Return the view with required data
        return view('content.dashboard.login_approval_list', [
            'ListTable' => $ListTable,
            'perpage'   => $perpage,
            'search_fill' => $search_fill,
            'staffList' => $staffList
        ]);
    }

    public function store(Request $request)
    {
        DB::beginTransaction();

        try {
            // Get current user details
            $entity_id = $request->user()->entity_id;
            $branch_id = $request->user()->branch_id;

            // Check if staff exists and belongs to same branch
            $staff = DB::table('et_staff')
                ->where('sno', $request->staff_id)
                ->where('branch_id', $branch_id)
                ->where('status', 0)
                ->first();

            if (!$staff) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid staff selection or staff not found.'
                ], 404);
            }

            // Check if the code already exists (very unlikely but just in case)
            $existingCode = LoginApprovalModel::where('login_code', $request->login_code)
                ->where('status', 0)
                ->first();

            if ($existingCode) {
                return response()->json([
                    'success' => false,
                    'message' => 'This code already exists. Please generate a new one.'
                ], 409);
            }

            // Create new login approval
            $loginApproval = LoginApprovalModel::create([
                'staff_id' => $request->staff_id,
                'login_code' => strtoupper($request->login_code), // Ensure uppercase
                'expiry_time' => $request->expiry_time,
                'branch_id' => $branch_id,
                'entity_id' => $entity_id,
                'created_by' => $request->user()->user_id,
                'updated_by' => $request->user()->user_id,
                'created_at' => now(),
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Login approval code generated successfully.',
                'data' => [
                    'sno' => $loginApproval->sno,
                    'login_code' => $loginApproval->login_code,
                    'expiry_time' => $loginApproval->expiry_time,
                    'created_at' => $loginApproval->created_at->format('d-M-Y H:i'),
                ]
            ]);
        } catch (\Exception $e) {
            DB::rollBack();


            return response()->json([
                'success' => false,
                'message' => 'Failed to generate login approval code. Please try again.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function verifyAuthenticationCode(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|string',
                'otp_code' => 'required|string|size:6'
            ]);

            $userId = $request->input('user_id');
            $otpCode = $request->input('otp_code');

            // Check if OTP exists and is valid
            $authRecord = DB::table('et_login_approval')
                ->where('staff_id', $userId)
                ->where('login_code', $otpCode)
                ->where('status', 0)
                ->first();

            if (!$authRecord) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid or expired authentication code'
                ], 400);
            }

            // Check if OTP is expired
            $createdAt = \Carbon\Carbon::parse($authRecord->created_at);
            $expiryMinutes = $authRecord->expiry_time ?? 10;
            $expiryTime = $createdAt->addMinutes($expiryMinutes);

            if (now()->gt($expiryTime)) {
                // Mark as expired
                DB::table('et_login_approval')
                    ->where('sno', $authRecord->sno)
                    ->update(['status' => 2]);

                return response()->json([
                    'success' => false,
                    'message' => 'Authentication code has expired'
                ], 400);
            }

            // Mark OTP as used
            DB::table('et_login_approval')
                ->where('sno', $authRecord->sno)
                ->update([
                    'status' => 1,
                    'updated_at' => now()
                ]);

            // Get user details
            $user = User::select('users.*', 'et_staff.status as staff_status')
                ->where('users.user_id', $userId) // Changed from $request->name to $userId
                ->leftJoin('et_staff', 'users.user_id', '=', 'et_staff.sno')
                ->leftJoin('et_branch', 'users.branch_id', '=', 'et_branch.sno')
                ->where('et_branch.status', 0)
                ->where('et_staff.status', 0)
                ->first();

            
            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found or inactive'
                ], 400);
            }

            $user->task_timer = 0;
            $user->save();

            Auth::login($user, 0);
            session(['user_id' => $user->id]);
            // Check permissions
            $permissions = UserRolePermissionModel::where('role_id', $user->role_id)
                ->where('status', 0)
                ->first();

            if (!$permissions) {
                // Clear session if no permissions
                Auth::logout();

                return response()->json([
                    'success' => false,
                    'message' => 'No permissions assigned',
                    'redirect' => route('role_permission_error')
                ], 403);
            }

            // Create a personal access token (if using API)
            $token = $user->createToken('auth_token')->plainTextToken;

            // Clear the authentication toastr from session
            // if (Session::has('toastr')) {
            //     $toastr = Session::get('toastr');
            //     if (isset($toastr['authentication'])) {
            //         unset($toastr['authentication']);
            //         Session::put('toastr', $toastr);
            //     }
            // }

            return response()->json([
                'success' => true,
                'message' => 'Authentication successful',
                'redirect' => route('dashboards'), // Make sure this route exists
                'token' => $token // Only if needed for API
            ]);
        } catch (\Exception $e) {
            Log::error('Authentication code verification failed', [
                'user_id' => $request->input('user_id'),
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Verification failed. Please try again.' . $e->getMessage()
            ], 500);
        }
    }
}
