<?php

namespace App\Http\Controllers\settings\customer_settings;

use App\Http\Controllers\Controller;
use App\Models\AppointmentModeModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class Appointment_mode extends Controller
{
    public function index(){
        $modes = AppointmentModeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.customer_settings.appointment_mode', compact('modes'));
    }

    public function Create(Request $request){
        $validator = Validator::make($request->all(), [
            'appointment_name' => 'required|string|max:255',
        ]);

        if($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 401);
        }

        $user_id = $request->user()->user_id;
        $name = $request->appointment_name;
        $desc = $request->appointment_desc;

        // Check if the name is already exists
        $checks = AppointmentModeModel::where('appointment_mode_name', ucwords($name))->where('status', '!=', 2)->first();

        if($checks){
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists',
            ]);

            return redirect()->back();
        } else {
            $Create = new AppointmentModeModel();
            $Create->appointment_mode_name = ucwords($name);
            $Create->appointment_mode_desc = $desc;
            $Create->created_by = $user_id;
            $Create->updated_by = $user_id;
            $Create->save();

            if($Create){
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Appointment Mode Created Successfully !',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Appointment Mode Creation Failed !',
                ]);
            }

            return redirect()->back();
        }
    }

    public function Update(Request $request){
        $validator = Validator::make($request->all(), [
            'edit_appointment_name' => 'required|string|max:255',
        ]);

        if($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 401);
        }

        $sno = $request->edit_id;
        $edit_name = $request->edit_appointment_name;
        $edit_desc = $request->edit_appointment_desc;
        $user_id = $request->user()->user_id;

        // Check if the name is already exists
        $checks = AppointmentModeModel::where('appointment_mode_name', ucwords($edit_name))
                    ->where('sno', '!=', $sno)
                    ->where('status', '!=', 2)
                    ->first();

        if($checks){
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists !',
            ]);

            return redirect()->back();
        } else {
            $Update = AppointmentModeModel::where('sno', $sno)->where('status', '!=', 2)->first();
            $Update->appointment_mode_name = $edit_name;
            $Update->appointment_mode_desc = $edit_desc;
            $Update->updated_by = $user_id;
            $Update->update();

            if($Update){
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Appointment Mode Updated Successfully !',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Appointment Mode Updation Failed !',
                ]);
            }

            return redirect()->back();
        }
    }

    public function Status($id, Request $request){
        $Status = AppointmentModeModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Status->status = $request->input('status', 0);
        $Status->update();

        if($Status){
            return response([
                'status' => 200,
                'message' => 'Status Updated Successfully',
                'error_msg' => 'Status Updation Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 401,
                'message' => 'Status Updation Failed',
                'error_msg' => 'Status Updation Failed !',
                'data' => null,
            ], 401);
        }
    }

    public function Delete($id){
        $Delete = AppointmentModeModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Delete->status = 2;
        $Delete->update();

        return response([
            'status' => 200,
            'message' => 'Appointment Mode Deleted Successfully !',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
