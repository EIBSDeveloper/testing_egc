<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LeadSettings extends Controller
{
  public function index()
  {
    return view('content.settings.lead_settings');
  }
  public function lead_questions_add()
  {
    return view('content.settings.lead_questions.lead_questions_add');
  }
  public function lead_questions_edit()
  {
    return view('content.settings.lead_questions.lead_questions_edit');
  }
  public function customer_type_option_add()
  {
    return view('content.settings.customer_type_option.add');
  }
  public function customer_type_option_edit()
  {
    return view('content.settings.customer_type_option.edit');
  }
  public function payment_mode_option_add()
  {
    return view('content.settings.payment_mode_option.add');
  }
  public function payment_mode_option_edit()
  {
    return view('content.settings.payment_mode_option.edit');
  }
}
