<?php

namespace App\Http\Controllers\settings\events;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\EventTypeModel;
use Illuminate\Support\Facades\Validator;

class EventType extends Controller
{
    protected static $branch_id = 1;
    public function index()
    {

        $EventType = EventTypeModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.placements.event_type.event_type', [
            'EventType' => $EventType,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function List()
    {
        $EventType = EventTypeModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $EventType
        ], 200);
    }
    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'event_type_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {


            $event_type_name = $request->event_type_name;
            $event_type_desc = $request->event_type_desc;
            $user_id = $request->user()->user_id;
            $chk = EventTypeModel::where('event_type_name', ucwords($event_type_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Event type is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = EventTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $event_type_id = "ET-0001/" . $year;
                } else {

                    $data = $category_check->event_type_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf("ET-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $event_type_id = $request . '/' . $year;
                }


                $add_event_type = new EventTypeModel();
                $add_event_type->event_type_id = $event_type_id;
                $add_event_type->event_type_name = Ucfirst($event_type_name);
                $add_event_type->event_type_desc = $event_type_desc;
                $add_event_type->branch_id = self::$branch_id;
                $add_event_type->created_by = $user_id;
                $add_event_type->updated_by = $user_id;

                $add_event_type->save();

                if ($add_event_type) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Event Type added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Event Type!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Edit($id)
    {
        $editevent_type = EventTypeModel::where('sno', $id)->first();

        return view('content.settings.placements.event_type.event_type', [
            'editevent_type' => $editevent_type,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'event_type_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $event_type_name = $request->event_type_name;
            $event_type_desc = $request->event_type_desc;
            $event_type_id = $request->event_type_id;

            $upd_EventTypeModel = EventTypeModel::where('sno', $event_type_id)->first();

            $chk = EventTypeModel::where('event_type_name', ucwords($event_type_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $event_type_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Event type is exist!'
                ]);
                return redirect()->back();
            } else {

                $upd_EventTypeModel->event_type_name = Ucfirst($event_type_name);
                $upd_EventTypeModel->event_type_desc = $event_type_desc;
                $upd_EventTypeModel->update();


                if ($upd_EventTypeModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Event Type Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Event Type!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_EventTypeModel = EventTypeModel::where('sno', $id)->first();
        $upd_EventTypeModel->status = 2;
        $upd_EventTypeModel->Update();


        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {

        $upd_EventTypeModel = EventTypeModel::where('sno', $id)->first();
        $upd_EventTypeModel->status = $request->input('status', 0);
        $upd_EventTypeModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}