<?php

namespace App\Http\Controllers\settings\events;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\EventCategoryModel;
use Illuminate\Support\Facades\Validator;

class EventCategory extends Controller
{
    protected static $branch_id = 1;
    public function index()
    {

        $EventCategory = EventCategoryModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.placements.event_category.event_category', [
            'EventCategory' => $EventCategory,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function List()
    {
        $EventCategory = EventCategoryModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $EventCategory
        ], 200);
    }
    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'event_category_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {


            $event_category_name = $request->event_category_name;
            $event_category_desc = $request->event_category_desc;
            $user_id = $request->user()->user_id;
            $chk = EventCategoryModel::where('event_category_name', ucwords($event_category_name))->where('status', '!=', 2)->where('branch_id', self::$branch_id)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Event Category is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = EventCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $event_category_id = "EC-0001/" . $year;
                } else {

                    $data = $category_check->event_category_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf("EC-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $event_category_id = $request . '/' . $year;
                }


                $add_event_category = new EventCategoryModel();
                $add_event_category->event_category_id = $event_category_id;
                $add_event_category->event_category_name = Ucfirst($event_category_name);
                $add_event_category->event_category_desc = $event_category_desc;
                $add_event_category->branch_id = self::$branch_id;
                $add_event_category->created_by = $user_id;
                $add_event_category->updated_by = $user_id;

                $add_event_category->save();

                if ($add_event_category) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Event Category added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Event Category!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Edit($id)
    {
        $editevent_category = EventCategoryModel::where('sno', $id)->first();

        return view('content.settings.placements.event_category.event_category', [
            'editevent_category' => $editevent_category,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'event_category_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $event_category_name = $request->event_category_name;
            $event_category_desc = $request->event_category_desc;
            $event_category_id = $request->event_category_id;

            $upd_EventCategoryModel = EventCategoryModel::where('sno', $event_category_id)->first();

            $chk = EventCategoryModel::where('event_category_name', ucwords($event_category_name))->where('sno', '!=', $event_category_id)->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Event Category is exist!'
                ]);
                return redirect()->back();
            } else {
                $upd_EventCategoryModel->event_category_name = Ucfirst($event_category_name);
                $upd_EventCategoryModel->event_category_desc = $event_category_desc;
                $upd_EventCategoryModel->update();


                if ($upd_EventCategoryModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Event Category Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Event Category!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_EventCategoryModel = EventCategoryModel::where('sno', $id)->first();
        $upd_EventCategoryModel->status = 2;
        $upd_EventCategoryModel->Update();


        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {

        $upd_EventCategoryModel = EventCategoryModel::where('sno', $id)->first();
        $upd_EventCategoryModel->status = $request->input('status', 0);
        $upd_EventCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}