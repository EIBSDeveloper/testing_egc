<?php

namespace App\Http\Controllers\settings\journal_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DomainModel;
use Illuminate\Support\Facades\Validator;

class Domain extends Controller
{
    public function index()
    {
        $domains = DomainModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.journal.domain', compact('domains'));
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'domain_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $name = $request->domain_name;
        $desc = $request->domain_desc;

        $category_check = DomainModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

            $year = substr(date('y'), -2);
            $domain_id = 'SLD-0001/' . $year;
        } else {

            $data = $category_check->domain_id;
            $slice = explode('/', $data);
            $result = preg_replace('/[^0-9]/', '', $slice[0]);

            $next_number = (int) $result + 1;
            $request = sprintf('SLD-%04d', $next_number);

            $year = substr(date('y'), -2);
            $domain_id = $request . '/' . $year;
        }

        // Check if the name is already exists
        $checks = DomainModel::where('domain_name', ucwords($name))->where('status', '!=', 2)->first();

        if ($checks) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists',
            ]);

            return redirect()->back();
        } else {
            $create = new DomainModel();
            $create->domain_name = $name;
            $create->domain_id = $domain_id;
            $create->domain_des = $desc;
            $create->created_by = $user_id;
            $create->updated_by = $user_id;
            $create->save();

            if ($create) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Domain Created Succesfully !',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Domain Creation Failed !',
                ]);
            }

            return redirect()->back();
        }
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_domain_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $sno = $request->edit_id;
        $edit_name = $request->edit_domain_name;
        $edit_desc = $request->edit_desc;

        // Check if the name is already exist
        $checks = DomainModel::where('domain_name', ucwords($edit_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

        if ($checks) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Alredy Exixts',
            ]);

            return redirect()->back();
        } else {
            $update = DomainModel::where('sno', $sno)->first();
            $update->domain_name = $edit_name;
            $update->domain_des = $edit_desc;
            $update->updated_by = $user_id;
            $update->update();

            if ($update) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Domain Updated Succesfully !',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Domain Updation Failed !',
                ]);
            }

            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {
        $status = DomainModel::where('sno', $id)->first();
        $status->status = $request->input('status', 0);
        $status->update();

        if ($status) {
            return response([
                'status' => 200,
                'message' => 'Status Changed Succesfully',
                'error_msg' => 'Status Changing Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Changing Failed',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = DomainModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->update();

        return response([
            'status' => 200,
            'message' => 'Domain Deleted Succesfully',
            'error_msg' => 'Domain Deletion Failed !',
            'data' => null,
        ]);
    }
}
