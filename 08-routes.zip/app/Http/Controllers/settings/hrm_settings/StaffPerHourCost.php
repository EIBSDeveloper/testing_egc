<?php

namespace App\Http\Controllers\settings\hrm_settings;

use App\Http\Controllers\Controller;
use App\Models\JobpositionModel;
use App\Models\StaffPerHourCostModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class StaffPerHourCost extends Controller
{
    public function index()
    {
        $salaries = StaffPerHourCostModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return view('content.settings.hrm_settings.staff_per_hour_cost', compact('salaries'));
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'per_hour_cost' => 'required',

        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $min_salary = $request->min_salary;
        $max_salary = $request->max_salary;
        $user_id = $request->user()->user_id;

        $check = StaffPerHourCostModel::where('min_salary', $min_salary)
            ->where('max_salary', $max_salary)
            ->where('status', '!=', 2)
            ->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Per Hour Cost Already Calculated!',
            ]);

            return redirect()->back();
        }
            
        $add_phc = new StaffPerHourCostModel();
        $add_phc->min_salary = $min_salary;
        $add_phc->max_salary = $max_salary;
        $add_phc->working_days = $request->working_days;
        $add_phc->working_hours = $request->working_hours;
        $add_phc->per_hour_cost = $request->per_hour_cost;
        $add_phc->created_by = $user_id;
        $add_phc->updated_by = $user_id;
        $add_phc->save();

        if ($add_phc) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Per Hour Cost added Successfully!',
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the per hour cost!',
            ]);

            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $per_hour_cost = StaffPerHourCostModel::where('sno', $id)->where('status', '!=', 2)->first();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $per_hour_cost,
        ], 200);
    }


    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'edit_per_hour_cost' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $min_salary = $request->edit_min_salary;
        $max_salary = $request->edit_max_salary;
        $sno = $request->edit_id;
        $user_id = $request->user()->user_id;

        $chk = StaffPerHourCostModel::where('min_salary', $max_salary)->where('max_salary', $max_salary)->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Per Hour Cost already created!'
            ]);

            return redirect()->back();
        } 

        $upd_per_hour_cost = StaffPerHourCostModel::where('sno', $sno)->where('status', '!=', 2)->first();
        $upd_per_hour_cost->min_salary = $min_salary;
        $upd_per_hour_cost->max_salary = $max_salary;
        $upd_per_hour_cost->working_days = $request->edit_working_days;
        $upd_per_hour_cost->working_hours = $request->edit_working_hours;
        $upd_per_hour_cost->per_hour_cost = $request->edit_per_hour_cost;
        $upd_per_hour_cost->updated_by = $user_id;
        $upd_per_hour_cost->update();

        if ($upd_per_hour_cost) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Per Hour Cost Updated Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Per Hour Cost Updation Failed!'
            ]);
        }
    }

    public function Delete($id)
    {
        $upd_per_hour_cost = StaffPerHourCostModel::where('sno', $id)->first();
        $upd_per_hour_cost->status = 2;
        $upd_per_hour_cost->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_per_hour_cost = StaffPerHourCostModel::where('sno', $id)->first();

        $upd_per_hour_cost->status = $request->input('status', 0);
        $upd_per_hour_cost->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
