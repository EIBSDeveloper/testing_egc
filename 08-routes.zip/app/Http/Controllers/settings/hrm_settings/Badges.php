<?php

namespace App\Http\Controllers\settings\hrm_settings;

use App\Http\Controllers\Controller;
use App\Models\BadgeModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class Badges extends Controller
{
    public function index()
    {
        $lists = BadgeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.hrm_settings.badges', compact('lists'));
    }

    public function Create(Request $request) {
        $validator = Validator::make($request->all(), [
            'badge_name' => 'required'
        ]);

        if($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $badge_name = $request->badge_name;
        $check = BadgeModel::where('badge_name', $badge_name)->where('status', '!=', 2)->first();

        if($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Badge Name Already Exists!'
            ]);

            return redirect()->back();
        }

        $CREATE = new BadgeModel();
        $CREATE->badge_name = $badge_name;
        $CREATE->award_type = $request->award_type;
        $CREATE->eligibility_count = $request->eligibility_count;
        $CREATE->eligibility_period = $request->eligibility_period;
        
        if($request->eligibility_period == 1) {
            $CREATE->st_date = $request->badge_st_date;
            $CREATE->end_date = $request->badge_end_date;
        } elseif($request->eligibility_period == 2) {
            $CREATE->st_month = $request->badge_st_month;
            $CREATE->end_month = $request->badge_end_month;
        } elseif($request->eligibility_period == 3) {
            $CREATE->st_year = $request->badge_st_yr;
            $CREATE->end_year = $request->badge_end_yr;
        }

        if ($request->hasFile('attachment_img')) {
            $pdf = $request->file('attachment_img');
            $pdfName = 'doc_' . time() . '_' . Str::random(10) . '.' . $pdf->getClientOriginalExtension();
            $pdf->move(public_path('badges'), $pdfName);
        }

        $CREATE->image = $pdfName;
        $CREATE->description = $request->badge_desc;
        $CREATE->created_by = $request->user()->user_id;
        $CREATE->updated_by = $request->user()->user_id;
        $CREATE->save();

        if($CREATE) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Badge Created Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Badge Creation Failed!'
            ]);
        }

        return redirect()->back();
    }

    public function Edit ($id) {
        $data = BadgeModel::where('status', '!=', 2)->where('sno', $id)->first();
        return response([
            'status' => 200,
            'message' => 'Data Fethced Successfully!',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function Update (Request $request) {
        $validator = Validator::make($request->all(), [
            'badge_name_edit' => 'required'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $sno = $request->edit_id;
        $name = $request->badge_name_edit;
        $user_id = $request->user()->user_id;

        $Check = BadgeModel::where('sno', '!=', $sno)->where('status', '!=', 2)->where('badge_name', $name)->first();

        if($Check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Badge Name Already Exists.'
            ]);
        }

        $Update = BadgeModel::where('sno', $sno)->where('status', '!=', 2)->first();
        $Update->badge_name = $name;
        $Update->award_type = $request->award_type_edit;
        $Update->eligibility_count = $request->eligibility_count_edit;
        $Update->eligibility_period = $request->eligibility_period_edit;
        $Update->description = $request->badge_desc_edit;
        
        if($request->eligibility_period_edit == 1) {
            $Update->st_date = $request->st_date_edit;
            $Update->end_date = $request->end_date_edit;
        } else if($request->eligibility_period_edit == 2) {
            $Update->st_month = $request->st_month_edit;
            $Update->end_month = $request->end_date_month;        
        } else if($request->eligibility_period_edit == 3) {
            $Update->st_year = $request->st_year;
            $Update->end_year = $request->end_year;
        }

        if ($request->hasFile('attachment_img_edit')) {

            // Upload new PDF
            $pdf = $request->file('attachment_img_edit');
            $pdfName = 'doc_' . time() . '_' . Str::random(10) . '.' . $pdf->getClientOriginalExtension();

            if (!$pdf->move(public_path('badges'), $pdfName)) {
                throw new \Exception('Failed to upload Image');
            }

            $Update->image = $pdfName;
        }

        $Update->created_by = $user_id;
        $Update->updated_by = $user_id;
        $Update->save();

        if($Update) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Badge Updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Badge Updation Failed!'
            ]);
        }

        return redirect()->back();
    }

    public function Status($id, Request $request)
    {

        $status = BadgeModel::where('sno', $id)->first();

        $status->status = $request->input('status', 0);
        $status->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Delete($id)
    {
        $delete = BadgeModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
