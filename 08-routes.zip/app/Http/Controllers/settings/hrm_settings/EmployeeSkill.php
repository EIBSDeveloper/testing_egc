<?php

namespace App\Http\Controllers\settings\hrm_settings;

use App\Http\Controllers\Controller;
use App\Models\EmployeeSkillModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class EmployeeSkill extends Controller
{
    public function index() {
        $ListTables = EmployeeSkillModel::where('status', '!=', 2)->get();
        return view('content.settings.hrm_settings.employee_skill', compact('ListTables'));
    }

    public function Update(Request $request) {
        $validator = Validator::make($request->all(), [
            'emp_skill' => 'required'
        ]);

        if($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $sno = $request->edit_id;
        $name = $request->emp_skill;
        $user_id = $request->user()->user_id;

        $check = EmployeeSkillModel::where('status', '!=', 2)->where('employee_skill', $name)->where('sno', '!=', $sno)->first();

        if($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists!'
            ]);

            return redirect()->back();
        }

        $update = EmployeeSkillModel::where('sno', $sno)->where('status', '!=', 2)->first();
        $update->employee_skill = $name;
        $update->created_by = $user_id;
        $update->updated_by = $user_id;
        $update->save();

        if($update) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Employee Skill Updated Successfully!'
            ]);
        }
    }
}
