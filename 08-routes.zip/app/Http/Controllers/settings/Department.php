<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\DepartmentModel;
use Carbon\Carbon;

class Department extends Controller
{
  public function index()
  {
    $Department = DepartmentModel::where('et_department.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('et_department.*', 'et_entity.entity_name as entityname', 'et_branch.branch_name', 'et_branch.franchise_name', 'et_branch.branch_type')
      ->leftJoin('et_entity', 'et_department.entity_id', 'et_entity.sno')
      ->leftJoin('et_branch', 'et_department.branch_id', 'et_branch.sno')
      ->orderBy('et_department.sno', 'desc')->get();
    // return $Department;
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.base_settings.department', [
      'ListTable' => $Department,
      'pageConfigs' => $pageConfigs
    ]);
  }

  public function List(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $Department = DepartmentModel::where('status', 0)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }

  public function BranchDepartList(Request $request)
  {

    $branch_id = $request->branch_id;
    $Department = DepartmentModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $staff =  DepartmentModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Department Status Updated Successfully!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Company  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_DepartmentModel = DepartmentModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'departmentName' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $department_name = $request->departmentName;
      $department_desc = $request->departDesc;
      $branch_id = $request->branchId;
      $user_id = $request->user()->user_id;
      $chk = DepartmentModel::where('department_name', ucwords($department_name))->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Department Name Already Exists!'
        ]);
        return redirect()->back();
      } else {
        $category_check = DepartmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date('y'), -2);
          $department_id = 'DP-0001/' . $year;
        } else {

          $data = $category_check->department_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $requestID = sprintf('DP-%04d', $next_number);

          $year = substr(date('y'), -2);
          $department_id = $requestID . '/' . $year;
        }

        $add_department = new DepartmentModel();
        $add_department->department_id = $department_id;
        $add_department->department_name = Ucfirst($department_name);
        $add_department->entity_id = 1;
        $add_department->department_desc = $department_desc;
        $add_department->branch_id  = 1;
        $add_department->created_by = $user_id;
        $add_department->updated_by = $user_id;

        $add_department->save();

        if ($add_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'department added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the department!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editdepartment = DepartmentModel::where('sno', $id)->first();
    if (!$editdepartment) {
      return response([
        'status' => 404,
        'message' => 'Department not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Department fetched successfully',
      'error_msg' => null,
      'data' => $editdepartment,
    ], 200);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'departmentName' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      // return $request;
      $sno = $request->edit_id;
      $department_name = $request->departmentName;
      $department_desc = $request->departDesc;
      $user_id = $request->user()->user_id;
      $chk = DepartmentModel::where('department_name', ucwords($department_name))->where('sno', '!=', $sno)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Department Name Already Exists!'
        ]);
        return redirect()->back();
      } else {


        $up_department = DepartmentModel::where('sno', $sno)->first();
        $up_department->department_name = Ucfirst($department_name);
        $up_department->entity_id = 1;
        $up_department->department_desc = $department_desc;
        $up_department->branch_id  = 1;
        $up_department->created_by = $user_id;
        $up_department->updated_by = $user_id;

        $up_department->save();

        if ($up_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Department updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the department!'
          ]);
        }
      }
      return redirect()->back();
    }
  }
}
