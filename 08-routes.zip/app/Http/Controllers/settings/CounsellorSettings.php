<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CounsellorSettings extends Controller
{
  public function index()
  {
    return view('content.settings.counsellor_settings');
  }
  public function category_analysis_questions_add()
  {
    return view('content.settings.category_analysis_questions.add');
  }
  public function category_analysis_questions_edit()
  {
    return view('content.settings.category_analysis_questions.edit');
  }
  public function course_analysis_questions_add()
  {
    return view('content.settings.course_analysis_questions.add');
  }
  public function course_analysis_questions_edit()
  {
    return view('content.settings.course_analysis_questions.edit');
  }
  public function feedback_analysis_questions_add()
  {
    return view('content.settings.feedback_analysis_questions.add');
  }
  public function feedback_analysis_questions_edit()
  {
    return view('content.settings.feedback_analysis_questions.edit');
  }
}
