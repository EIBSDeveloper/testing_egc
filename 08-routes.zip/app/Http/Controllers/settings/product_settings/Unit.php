<?php

namespace App\Http\Controllers\settings\product_settings;

use App\Http\Controllers\Controller;
use App\Models\UnitModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class Unit extends Controller
{
    public function index() {

        $ListTable = UnitModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.product_settings.unit', compact('ListTable'));
    }

    public function Add(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'unit_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->unit_name;
            $company_des = $request->unit_desc;


            $user_id = 1;
            $chk = UnitModel::where('unit_name', ucwords($company_name))->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Unit is exist!'
                ]);
                return redirect()->back();
            } else {

                $add_company = new UnitModel();

                $add_company->unit_name = Ucfirst($company_name);
                $add_company->unit_desc = $company_des;

                $add_company->created_by = $user_id;
                $add_company->updated_by = $user_id;

                $add_company->save();

                if ($add_company) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Unit added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Unit!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Update(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'edit_unit_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->edit_unit_name;

            $company_type_desc = $request->edit_des;
            $sno = $request->edit_id;
            $chk = UnitModel::where('unit_name', ucwords($company_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Varient is exist!'
                ]);
                return redirect()->back();
            } else {
                $upd_CompanyTypeModel = UnitModel::where('sno', $sno)->first();
                $upd_CompanyTypeModel->unit_name = Ucfirst($company_name);

                $upd_CompanyTypeModel->unit_desc = $company_type_desc;


                $upd_CompanyTypeModel->update();

                if ($upd_CompanyTypeModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Unit successfully updated !'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Unit!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = UnitModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $upd_DepartmentModel = UnitModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
