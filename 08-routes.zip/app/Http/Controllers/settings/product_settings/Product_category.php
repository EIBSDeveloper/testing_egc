<?php

namespace App\Http\Controllers\settings\product_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ServiceCategoryModel;
use Illuminate\Support\Facades\Validator;

class Product_category extends Controller
{
  public function index()
  {
    $University = ServiceCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
      //return $University;
      $pageConfigs = ['myLayout' => 'default'];
      return view('content.settings.product_settings.product_category', [
          'ListTable' => $University,
          'pageConfigs' => $pageConfigs
      ]);
  }
   public function List()
  {
    $University = ServiceCategoryModel::where('status', 0)->orderBy('product_category_name', 'ASC')->get();
    
      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $University
      ], 200);
  }
   public function NavList()
  {
    $University = ServiceCategoryModel::where('status', 0)->orderBy('product_category_name', 'ASC')->get();
    
      return  response([
          'success'    => true,
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $University
      ], 200);
  }
  public function Add(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'product_category_name' => 'required'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->product_category_name;
            $journal_chk = $request->journal_chk;
            $company_des = $request->cat_desc;


            $user_id = $request->user()->user_id;
            $chk = ServiceCategoryModel::where('product_category_name', ucwords($company_name))->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Product Category Already Exists!'
                ]);
                return redirect()->back();
            } else {
                $category_check = ServiceCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $company_id = 'SC-0001/' . $year;
                } else {

                    $data = $category_check->company_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('SC-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $company_id = $request . '/' . $year;
                }

                $add_company = new ServiceCategoryModel();

                $add_company->product_category_name = Ucfirst($company_name);
                $add_company->jouranal_check = $journal_chk;
                $add_company->cat_desc = $company_des;
                $add_company->service_category_id = $company_id;

                $add_company->created_by = $user_id;
                $add_company->updated_by = $user_id;

                $add_company->save();

                if ($add_company) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Product Category Added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Service Category!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Edit($id)
    {
        $editcompany = ServiceCategoryModel::where('sno', $id)->first();

        return view('content.settings.product_settings.product_category', [
            'editcompany' => $editcompany,
            'id' => $id,
        ]);
    }
    public function Update(Request $request)
    {
         //return $request;
        $validator = Validator::make($request->all(), [
            'edit_service_category' => 'required'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->edit_service_category;
            $journal_chk = $request->journal_chk;
            $company_type_desc = $request->edit_des;
            $sno = $request->edit_id;
            $chk = ServiceCategoryModel::where('product_category_name', ucwords($company_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Product Category Already Exists!'
                ]);
                return redirect()->back();
            } else {
                $upd_CompanyTypeModel = ServiceCategoryModel::where('sno', $sno)->first();
                $upd_CompanyTypeModel->product_category_name = Ucfirst($company_name);
                $upd_CompanyTypeModel->jouranal_check = $journal_chk;
                $upd_CompanyTypeModel->cat_desc = $company_type_desc;


                $upd_CompanyTypeModel->update();

                if ($upd_CompanyTypeModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Product category Updated Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Service Category!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = ServiceCategoryModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = ServiceCategoryModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
