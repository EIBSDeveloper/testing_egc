<?php

namespace App\Http\Controllers\settings\product_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\TermsConditionsModel;
use Illuminate\Support\Facades\Validator;




Class TermsConditions extends Controller
{
    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';

        $query=DB::table('et_terms_conditions')
          ->select('et_terms_conditions.*','et_entity.entity_name')
          ->Join('et_entity', 'et_entity.sno', '=', 'et_terms_conditions.entity_id')
          ->where('et_terms_conditions.status','!=',2);

          // Search Filter
          if($search_filter != '') {
            $query->where(function ($list) use ($search_filter) {
              $list->where('et_terms_conditions.terms_condition_name', 'LIKE', "%{$search_filter}%")
                ->orWhere('et_entity.entity_name', 'LIKE', "%{$search_filter}%");
            });
          }

        $notes_list = $query->paginate($perpage);
        return view('content.settings.product_settings.terms_conditions',[
            'notes_list' => $notes_list,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

     public function List(Request $request)
  {


      $entity_id = $request->input('entity_id');

      $notes = TermsConditionsModel::where('status', 0)->where('entity_id', $entity_id)
          ->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $notes
      ], 200);
  }

    public function Edit($id){

        $notes = TermsConditionsModel::where('sno', $id)->where('status', '!=', 2)->first();

       $notes->terms_condition_list=json_decode($notes->terms_condition_list);
        return  response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $notes
        ], 200);


    }

  public function Add(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'terms_condition_name' => 'required|max:255',
      'terms_condition_list' => 'required|array'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {
      $terms_condition_name                   = $request->terms_condition_name;
      $terms_condition_list                   = $request->terms_condition_list;
      $entity_id                 = $request->entity_id;

      $signature_image = $request->file('signature_image');
      $signature = '';
      if ($signature_image) {
        $imageName = idate('B') . rand(1, 50) . '.' . $signature_image->extension();
        $destinationPath = public_path('terms_condition_signature');
        $signature_image->move($destinationPath, $imageName);
        $signature = $imageName;
      }

      $nda_signature = $request->file('nda_signature');
      $nda_signature_sign = '';
      if($nda_signature) {
        $ndaImageName = idate('B') . rand(1, 50) . '.' . $nda_signature->extension();
        $finalPath = public_path('terms_condition_signature');
        $nda_signature->move($finalPath, $ndaImageName);
        $nda_signature_sign = $ndaImageName;
      }

      $user_id                    = $request->user()->user_id ?? 1;
      $branch_id                    = $request->user()->branch_id ?? 1;
      $chk = TermsConditionsModel::where('entity_id', $entity_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Terms and Conditions has been already created!'
        ]);
      } else {
        $category_check = TermsConditionsModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date("y"), -2);
          $terms_condition_id = "TC-0001/" . $year;
        } else {

          $data = $category_check->terms_condition_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $request = sprintf("TC-%04d", $next_number);

          $year = substr(date("y"), -2);
          $terms_condition_id = $request . '/' . $year;
        }

        $add_category = new TermsConditionsModel();
        $add_category->terms_condition_id  = $terms_condition_id;
        $add_category->terms_condition_name = $terms_condition_name;
        $add_category->terms_condition_list = json_encode($terms_condition_list);
        $add_category->signature = $signature;
        $add_category->nda_signature = $nda_signature_sign;
        $add_category->branch_id = $branch_id;
        $add_category->entity_id = $entity_id;
        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Terms & Condition added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Terms & Condition!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Terms & Condition Created successfully!');
    }
  }

  public function Update(Request $request)
  {
    // Validate input fields
    $validator = Validator::make($request->all(), [
      'terms_condition_name' => 'required|max:255',
      'terms_condition_list' => 'required|array'
    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    }

    $id = $request->edit_id;
    $terms_condition_name = $request->terms_condition_name;
    $terms_condition_list = $request->terms_condition_list;
    $entity_id = $request->entity_id;

    // Handle signature image upload
    $signature_image = $request->file('signature_image');
    $signature = '';

    if ($signature_image) {
      $extension = strtolower($signature_image->getClientOriginalExtension());

      // Validate allowed extensions
      if (!in_array($extension, ['jpg', 'jpeg', 'png'])) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Invalid file type for signature. Allowed types: jpg, jpeg, png'
        ]);
        return redirect()->back();
      }

      $imageName = time() . '_' . rand(1, 50) . '.' . $extension;
      $destinationPath = public_path('terms_condition_signature');

      if (!file_exists($destinationPath)) {
        mkdir($destinationPath, 0777, true);
      }

      try {
        $signature_image->move($destinationPath, $imageName);
        $signature = $imageName;
      } catch (\Exception $e) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Failed to upload signature image: ' . $e->getMessage()
        ]);
        return redirect()->back();
      }
    } else {
      $signature = $request->terms_old_sign;
    }

    // Handle NDA signature upload
    $nda_signature = $request->file('nda_signature_image');
    $nda_signature_sign = '';

    if ($nda_signature) {
      $extension = strtolower($nda_signature->getClientOriginalExtension());

      if (!in_array($extension, ['jpg', 'jpeg', 'png'])) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Invalid file type for NDA signature. Allowed types: jpg, jpeg, png'
        ]);
        return redirect()->back();
      }

      $ndaImageName = time() . '_' . rand(1, 50) . '.' . $extension;
      $finalPath = public_path('terms_condition_signature');

      if (!file_exists($finalPath)) {
        mkdir($finalPath, 0777, true);
      }

      try {
        $nda_signature->move($finalPath, $ndaImageName);
        $nda_signature_sign = $ndaImageName;
      } catch (\Exception $e) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Failed to upload NDA signature image: ' . $e->getMessage()
        ]);
        return redirect()->back();
      }
    } else {
      $nda_signature_sign = $request->terms_old_nda_sign;
    }

    // Check for existing terms assigned to the entity (excluding current record)
    $chk = TermsConditionsModel::where('entity_id', $entity_id)
      ->where('sno', '!=', $id)
      ->where('status', '!=', 2)
      ->first();

    if ($chk) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Terms and Conditions has been already assigned!'
      ]);
      return redirect()->back();
    }

    // Update the Terms and Conditions record
    $upd_CourseCategoryModel = TermsConditionsModel::where('sno', $id)->first();

    if (!$upd_CourseCategoryModel) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Terms and Conditions record not found!'
      ]);
      return redirect()->back();
    }

    $upd_CourseCategoryModel->terms_condition_name = $terms_condition_name;
    $upd_CourseCategoryModel->terms_condition_list = json_encode($terms_condition_list);
    $upd_CourseCategoryModel->entity_id = $entity_id;
    $upd_CourseCategoryModel->signature = $signature;
    $upd_CourseCategoryModel->nda_signature = $nda_signature_sign;

    $updated = $upd_CourseCategoryModel->update();

    if ($updated) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Terms and Condition updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Terms and Condition!'
      ]);
    }

    return redirect()->back();
  }


  public function Delete($id)
  {
    $upd_CourseCategoryModel =  TermsConditionsModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  TermsConditionsModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}