<?php

namespace App\Http\Controllers\settings\product_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Addon_product_VariantModel;
use Illuminate\Support\Facades\Validator;
use App\Models\AddonVariableModel;

class AddonVariable extends Controller
{
    public function index()
    {
      $varient = Addon_product_VariantModel::where('status', 0)->get();
      $University = AddonVariableModel::where('et_addon_variable.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('et_addon_variable.*','et_addon_varient.addon_varientname as varientname')
      ->leftJoin('et_addon_varient','et_addon_variable.addon_varientid','et_addon_varient.sno')
      ->orderBy('et_addon_variable.sno', 'desc')->get();
        //return $University;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.product_settings.addon_variable', [
            'ListTable' => $University,
            'VarientList' => $varient,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function Get_list()
    {
      // Retrieve the category ID from the POST request
      $dept_id = $_GET['id'] ?? '';

      $sub_department_list = AddonVariableModel::
        where('status', 0)
        ->where('addon_varientid', $dept_id)
        ->orderBy('addon_variablename', 'ASC')
        ->get();
      // Prepare and return the response
      return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $sub_department_list
      ], 200);
    }
     public function Get_list_by_id()
    {
      $id = $_GET['id'] ?? '';
      $sub_department_list = AddonVariableModel::where('sno', $id)->first();
      // Prepare and return the response
      return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $sub_department_list
      ], 200);
    }
    public function Add(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'Addon_variablename' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->Addon_variablename;
            $company_des = $request->service_des;
            $servicevarient = $request->addonvarientid;
            $mincost = $request->mincost;
            $maxcost = $request->maxcost;


            $user_id = 1;
            $chk = AddonVariableModel::where('addon_variablename', ucwords($company_name))->where('addon_varientid',$servicevarient)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Variable is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = AddonVariableModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $company_id = 'ASV-0001/' . $year;
                } else {

                    $data = $category_check->company_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('ASV-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $company_id = $request . '/' . $year;
                }

                $add_company = new AddonVariableModel();

                $add_company->addon_variablename = Ucfirst($company_name);
                $add_company->addon_des = $company_des;
                $add_company->addon_variableid = $company_id;
                $add_company->addon_varientid = $servicevarient;
                $add_company->min_cost = $mincost;
                $add_company->max_cost = $maxcost;
                $add_company->created_by = $user_id;
                $add_company->updated_by = $user_id;

                $add_company->save();

                if ($add_company) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Add-On Variable added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Add-On Variable!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = AddonVariableModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = AddonVariableModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Update(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'edit_service_categoryname' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->edit_service_categoryname;
            $service_id = $request->edit_servicevarientid;
            $maxcost = $request->edit_maxcost;
            $mincost = $request->edit_mincost;

            $company_type_desc = $request->edit_des;
            $sno = $request->edit_id;
            $chk = AddonVariableModel::where('addon_variablename', ucwords($company_name))->where('addon_varientid',$service_id)->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Variable is exist!'
                ]);
                return redirect()->back();
            } else {
                $upd_CompanyTypeModel = AddonVariableModel::where('sno', $sno)->first();
                $upd_CompanyTypeModel->addon_variablename = Ucfirst($company_name);

                $upd_CompanyTypeModel->addon_des = $company_type_desc;
                $upd_CompanyTypeModel->addon_varientid =  $service_id;
                $upd_CompanyTypeModel->max_cost =   $maxcost;
                $upd_CompanyTypeModel->min_cost =   $mincost;


                $upd_CompanyTypeModel->update();

                if ($upd_CompanyTypeModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Add-On Variable successfull updated !'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Add-On Variable!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
}
