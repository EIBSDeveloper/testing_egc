<?php

namespace App\Http\Controllers\settings\marketing;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\MarketingTypeModel;
use App\Models\LeadSourceModel;

class MarketingType extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $marketing_type = MarketingTypeModel::select('et_marketing_type.*', 'et_marketing_category.marketing_category_name')
            ->join('et_marketing_category', 'et_marketing_type.marketing_category_id', '=', 'et_marketing_category.sno')
            ->where('et_marketing_type.status', '!=', 2)
            ->orderBy('et_marketing_type.sno', 'desc')->get();
        return view('content.settings.marketing.marketing_type', [
            'marketing_type' => $marketing_type
        ]);
    }

    public function Status($id, Request $request)
    {

        $upd_MarketingTypeModel =  MarketingTypeModel::where('sno', $id)->first();
        $upd_MarketingTypeModel->status = $request->input('status', 0);
        $upd_MarketingTypeModel->update();
        if ($upd_MarketingTypeModel) {
            return response([
                'status'    => 200,
                'message'   => 'Marketing Type Status Successfully Updated!',
                'error_msg' => 'Could not update  Marketing Type Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Marketing Type Status!',
                'error_msg' => 'Could not update  Marketing Type Status!',
                'data'      => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $MarketingTypeModel =  MarketingTypeModel::where('sno', $id)->first();
        $MarketingTypeModel->status  = 2;
        $MarketingTypeModel->Update();
        if ($MarketingTypeModel) {
            return response([
                'status'    => 200,
                'message'   => 'Marketing Type  Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Marketing Type !',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function List()
    {
        // Retrieve the category ID from the POST request
        $type_id = $_GET['id'] ?? '';

        $MarType = MarketingTypeModel::where('branch_id', self::$branch_id)->where('status', 0)
            ->where('marketing_category_id', $type_id)
            ->orderBy('sno', 'desc')
            ->get();
        // Prepare and return the response
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $MarType
        ], 200);
    }
    public function Listdropdown(Request $request)
    {
        // Retrieve the category ID from the GET request
        // dd($request);
        $id = $request->id;
        $MarType = MarketingTypeModel::where('branch_id', self::$branch_id)->where('status', 0)
            ->where('marketing_category_id', $id)
            ->orderBy('sno', 'desc')
            ->get();
        if ($MarType) {
            return response([
                'status'    => 200,
                'message'   => null,
                'error_msg' => null,
                'data'      => $MarType
            ], 200);
        }
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'type_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $mar_cat_select = $request->mar_cat_select;
        $marketing_type_id = $request->marketing_type_id;
        $type_name = $request->type_name;
        $type_desc = $request->type_desc;
        $vendor_chk = $request->vendor_chk;
        $zone_chk = $request->zone_chk;
        $area_chk = $request->area_chk;
        $count_chk = $request->count_chk;
        $payment_chk = $request->payment_chk;
        $schdl_chk = $request->schdl_chk;
        $gst_chk = $request->gst_chk;
        $lead_source_chk = $request->lead_source_chk;
        $user_id = $request->user()->user_id;

        // Check if the category already exists
        $chk = MarketingTypeModel::where('marketing_type_name', ucwords($type_name))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Marketing Type has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $category_check = MarketingTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = substr(date('y'), -2);
                $marketing_type_id = 'MAT-0001/' . $year;
            } else {
                $data = $category_check->marketing_type_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('MAT-%04d', $next_number);
                $year = substr(date('y'), -2);
                $marketing_type_id = $requestId . '/' . $year;
            }



            // Add the category to the database
            $add = new MarketingTypeModel();
            $add->marketing_type_id = $marketing_type_id;
            $add->marketing_type_name = ucfirst($type_name);
            $add->marketing_type_desc = $type_desc;
            $add->vendor_chk = $vendor_chk;
            $add->zone_chk = $zone_chk;
            $add->count_chk = $count_chk;
            $add->payment_chk = $payment_chk;
            $add->schedule_chk = $schdl_chk;
            $add->gst_chk = $gst_chk;
            $add->lead_source_chk = $lead_source_chk;
            $add->marketing_category_id = $mar_cat_select;
            $add->branch_id = self::$branch_id;
            $add->created_by =  $request->user()->user_id;;
            $add->updated_by =  $request->user()->user_id;

            $add->save();

            if ($add) {
                if ($lead_source_chk == 1) {
                    $add_lead_source = new LeadSourceModel();
                    $add_lead_source->lead_source_id         = $marketing_type_id;
                    $add_lead_source->lead_source_name       = Ucfirst($type_name);
                    $add_lead_source->lead_source_desc       = $type_desc;
                    $add_lead_source->branch_id = self::$branch_id;
                    $add_lead_source->created_by                 =  $request->user()->user_id;
                    $add_lead_source->updated_by                 =  $request->user()->user_id;

                    $add_lead_source->save();
                }

                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Marketing Type added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Marketing Type!'
                ]);
            }
        }


        return redirect()->back();
    }


    public function Edit($id)
    {
        $MarketingType = MarketingTypeModel::select(
            'et_marketing_type.*',
            'et_marketing_category.marketing_category_name',
            'et_marketing_category.sno as marketing_category_id'
        )
            ->join('et_marketing_category', 'et_marketing_type.marketing_category_id', '=', 'et_marketing_category.sno')
            ->where('et_marketing_type.sno', $id)
            ->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $MarketingType
        ], 200);
    }


    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'type_name_edit' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $mar_cat_select = $request->mar_cat_select_edit;
        $sno = $request->edit_sno;
        $marketing_type_id = $request->marketing_type_id;
        $type_name = $request->type_name_edit;
        $type_desc = $request->type_desc_edit;
        $vendor_chk = $request->vendor_chk_edit;
        $zone_chk = $request->zone_chk_edit;
        $count_chk = $request->count_chk_edit;
        $payment_chk = $request->payment_chk_edit;
        $schdl_chk = $request->schdl_chk_edit;
        $gst_chk = $request->gst_chk_edit;
        $lead_source_chk = $request->lead_source_chk_edit;
        $user_id = $request->user()->user_id;

        $upd_marketing_type = MarketingTypeModel::find($sno);

        if (!$upd_marketing_type) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Marketing Type not found!'
            ]);
            return redirect()->back();
        }

        $chk = MarketingTypeModel::where('marketing_type_name', ucwords($type_name))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $sno)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Marketing Type has already been created!'
            ]);
            return redirect()->back();
        }

        $upd_marketing_type->marketing_type_name = ucfirst($type_name);
        $upd_marketing_type->marketing_type_desc = $type_desc;
        $upd_marketing_type->marketing_category_id = $mar_cat_select;
        $upd_marketing_type->vendor_chk = $vendor_chk;
        $upd_marketing_type->zone_chk = $zone_chk;
        $upd_marketing_type->count_chk = $count_chk;
        $upd_marketing_type->payment_chk = $payment_chk;
        $upd_marketing_type->schedule_chk = $schdl_chk;
        $upd_marketing_type->gst_chk = $gst_chk;
        $upd_marketing_type->lead_source_chk = $lead_source_chk;
        $upd_marketing_type->created_by =  $request->user()->user_id;
        $upd_marketing_type->updated_by = $request->user()->user_id;
        $upd_marketing_type->save();

        // return $marketing_type_id;

        if ($upd_marketing_type) {
            if ($lead_source_chk == 1) {

                $user = LeadSourceModel::where('lead_source_id', $marketing_type_id)->first();

                if ($user) {
                    // Update the user
                    $user->update([
                        'lead_source_name' => $request->type_name_edit,
                        'lead_source_desc' => $request->type_desc_edit,
                        'status' => 0,
                        'updated_by' => $request->user()->user_id,
                    ]);
                } else {
                    // Create a new user if it doesn't exist
                    LeadSourceModel::create([
                        'lead_source_id' =>  $marketing_type_id,
                        'lead_source_name' => $request->type_name_edit,
                        'lead_source_desc' => $request->type_desc_edit,
                        'branch_id' => self::$branch_id,

                        'created_by' => $request->user()->user_id,
                        'updated_by' => $request->user()->user_id,
                    ]);
                }
            } elseif ($request->lead_source_chk == 0) {
                // Update status for staff_type 2
                LeadSourceModel::where('lead_source_id', $marketing_type_id)
                    ->update([
                        'status' => 2,
                    ]);
            }
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Marketing Type updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Marketing Type !'
            ]);
        }

        return redirect()->back();
    }
}
