<?php

namespace App\Http\Controllers\settings\marketing;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\VariableModel;
use App\Models\User;

class Variable extends Controller
{
    protected static $branch_id = 1;
    public function index()
    {
        $Variable = VariableModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno')->get();
        $pageConfigs = ['myLayout' => 'default'];
        // return $MarketingKitcategory;
        return view('content.settings.marketing.variable', [
            'Variable' => $Variable,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function List()
    {
        $Variable = VariableModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Variable
        ], 200);
    }

    public function Add(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'selection'  => 'required|in:color,size', // Only allows 'color' or 'size'

        ]);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages(),
                'data'      => null,
            ], 200);
        }

        // Retrieve the input values
        $variable    = $request->selection;
        $color_name  = $request->color_name;
        $color_code  = $request->color_code;
        $height      = $request->height;
        $width       = $request->width;
        $user_id     = $request->user()->user_id;

        // Create a new Variable record
        $add_category = new VariableModel();
        $add_category->variable     = ucfirst($variable); // Capitalize the first letter
        $add_category->color_name   = $color_name;
        $add_category->color_code   = $color_code;
        $add_category->height       = $height;
        $add_category->width        = $width;
        $add_category->branch_id    = self::$branch_id;
        $add_category->created_by   = $user_id;
        $add_category->updated_by   = $user_id;

        // Save the new category
        $add_category->save();

        // Check if the category was saved successfully
        if ($add_category) {
            return redirect()->back()->with('toastr', [
                'type'    => 'success',
                'message' => 'Variable successfully added!'
            ]);
        } else {
            return redirect()->back()->with('toastr', [
                'type'    => 'error',
                'message' => 'Could not add the variable!'
            ]);
        }
    }



    public function Edit($id)
    {

        $editcategory = VariableModel::where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $editcategory
        ], 200);
    }

    public function Update($id, Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'selection' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 401);
        } else {
            $variable    = $request->selection;
            $color_name  = $request->color_name;
            $color_code  = $request->color_code;
            $height      = $request->height;
            $width       = $request->width;
            $user_id     = $request->user()->user_id;

            $upd_CategoryModel =  VariableModel::where('sno', $id)->first();

            if (!$upd_CategoryModel) {
                return response([
                    'status'    => 404,
                    'message'   => ' category not found',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);
            }

            $chk = VariableModel::where('variable', ucwords($variable))
                ->where('status', '!=', 2)
                ->where('sno', '!=', $id)
                ->first();

            // if ($chk) {
            //   session()->flash('toastr', [
            //     'status'    => 401,
            //     'type' => 'error',
            //     'message' => 'Name has been  already created!'
            //   ]);
            // } else {

            $upd_CategoryModel->variable = ucfirst($variable);
            $upd_CategoryModel->color_name = $color_name;
            $upd_CategoryModel->color_code = $color_code;
            $upd_CategoryModel->height = $height;
            $upd_CategoryModel->width = $width;

            $upd_CategoryModel->update();


            if ($upd_CategoryModel) {
                $result = response([
                    'status'    => 200,
                    'message'   => 'Successfully Updated!',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);
            } else {
                $result = response([
                    'status'    => 401,
                    'message'   => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data'      => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CategoryModel =  VariableModel::where('sno', $id)->first();
        $upd_CategoryModel->status  = 2;
        $upd_CategoryModel->Update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CategoryModel =  VariableModel::where('sno', $id)->first();
        $upd_CategoryModel->status = $request->input('status', 0);
        $upd_CategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
