<?php
namespace App\Http\Controllers\settings\common_settings;

use App\Http\Controllers\Controller;
use App\Models\SmsTemplateModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class ChottaApi extends Controller
{
  

    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $branch_id = $request->user()->branch_id;
        $chottaApiList = DB::table('et_chotta_links')
            ->select('et_chotta_links.*','et_staff.staff_name')
            ->leftJoin('et_staff','et_chotta_links.created_by','=','et_staff.sno')
             ->where('et_chotta_links.branch_id', $branch_id)
            ->where('et_chotta_links.status', '!=', 2);
            if (!empty($search_filter)) {
                $chottaApiList->where(function ($query) use ($search_filter) {
                    $query->where('et_chotta_links.link_type', 'LIKE', "%{$search_filter}%");
                });
            }
      $chottaApiList=      $chottaApiList->orderBy('et_chotta_links.sno', 'desc')
            ->paginate($perpage);
 
        return view('content.settings.common_setting.chotta_link_list', [
            'chottaApiList' => $chottaApiList, 
            'perpage' => $perpage,
            'search_filter' => $search_filter,
        ]);

    }
    
    public function ApiRefresh(Request $request)
    {
            $branch_id = $request->user()->branch_id;
        
            $chottaApiList = DB::table('et_chotta_links')
                ->select('et_chotta_links.*')
                ->where('et_chotta_links.status', '!=', 2)
                ->where('et_chotta_links.branch_id', $branch_id)
                ->orderBy('et_chotta_links.sno', 'desc')
                ->get();
                
            foreach ($chottaApiList as $link) {
                $response = $this->UrlData($link->chotta_link_id);
        
                if (isset($response)) {
                    $clicks = $response['data']['clicks'] ?? 0;
                    $uniqueClicks = $response['data']['uniqueClicks'] ?? 0;
        
                   DB::table('et_chotta_links')
                    ->where('sno', $link->sno) // ✅ Correct key used here
                    ->update([
                        'click_count' => $clicks,
                        'unique_clicks' => $uniqueClicks
                    ]);
                }
            }
        
        
            return redirect('settings/common/chotta_links');
        }
        
        public function UrlData($id)
        {
            $assignUrl = "https://chotta.link/api/url/{$id}";
        
            $assignResponse = Http::withToken('aFLQFlykraqpANsi')
                ->withHeaders(['Content-Type' => 'application/json'])
                ->get($assignUrl);
        
            return $assignResponse->json();
        }



}
