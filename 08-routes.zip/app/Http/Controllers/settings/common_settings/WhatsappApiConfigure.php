<?php

namespace App\Http\Controllers\settings\common_settings;

use App\Http\Controllers\Controller;
use App\Models\WhatsappApiConfigureModel;
use App\Models\BranchModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class WhatsappApiConfigure extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {

        $whatsappConfig = WhatsappApiConfigureModel::select('et_whatsapp_api_configure.*','et_company.company_name','et_entity.entity_name')->join('et_company','et_company.sno','=','et_whatsapp_api_configure.company_id')->join('et_entity','et_entity.sno','=','et_whatsapp_api_configure.entity_id')->where('et_whatsapp_api_configure.status', '!=', 2)->orderBy('et_whatsapp_api_configure.sno', 'desc')->get();
        $branch_list = BranchModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        // $branches = BranchModel::select('sno','branch_name','branch_type','franchise_name')->where('status', 0)
        //   ->where('branch_type', 1)
        //   ->get();

        // $franchises = BranchModel::select('sno','branch_name','branch_type','franchise_name')->where('status', 0)
        //   ->where('branch_type', 2)
        //   ->get();

        // return ['branches' => $branches, 'franchises' => $franchises];

        return view('content.settings.common_setting.whatsapp_api_configure', [
            'whatsappConfig' => $whatsappConfig,
            'branch_list' => $branch_list,
            'pageConfigs' => $pageConfigs,
        ]);
    }

    public function list()
    {
        $whatsappTemplate = WhatsappApiConfigureModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $whatsappTemplate,
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'waba_id_add' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $entity_id = $request->entity_id;
            $company_id = $request->company_id;
            $whatsapp_config_name = $request->api_name_add;
            $access_tokken = $request->access_tokken_add;
            $waba_id = $request->waba_id_add;
            $phonenumber_id = $request->from_phone_no_id_add;
            $user_id = $request->user()->user_id ?? 1;

            
            $chk_entity = WhatsappApiConfigureModel::where('entity_id',$entity_id)->where('status', '!=', 2)->first();

            if ($chk_entity) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Entity is exist!',
                ]);
                return redirect()->back();
            }

            $chk = WhatsappApiConfigureModel::where('waba_id', $waba_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already waba_id is exist!',
                ]);
                return redirect('settings/common/whatsapp_api');
            } else {
                $category_check = WhatsappApiConfigureModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $whatsapp_config_id = 'WC-0001/' . $year;
                } else {

                    $data = $category_check->whatsapp_config_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('WC-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $whatsapp_config_id = $request . '/' . $year;
                }

                $add_wTemplate = new WhatsappApiConfigureModel();
                $add_wTemplate->whatsapp_config_id = $whatsapp_config_id;
                $add_wTemplate->whatsapp_config_name = $whatsapp_config_name;
                $add_wTemplate->waba_id = $waba_id;
                $add_wTemplate->access_tokken = $access_tokken;
                $add_wTemplate->branch_id = 1;
                $add_wTemplate->phonenumber_id = $phonenumber_id;
                $add_wTemplate->created_by = $user_id;
                $add_wTemplate->updated_by = $user_id;

                $add_wTemplate->save();

                if ($add_wTemplate) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Whatsapp Api Config added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Whatsapp Api Config!',
                    ]);
                }
            }
            return redirect('settings/common/whatsapp_api');
        }
    }

    public function Update(Request $request)
    {

        // return $request;

        $validator = Validator::make($request->all(), [
            'waba_id_edit' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $entity_id = $request->entity_id;
            $company_id = $request->company_id;
            $whatsapp_config_name = $request->api_name_edit;
            $access_tokken = $request->access_tokken_edit;
            $waba_id = $request->waba_id_edit;
            $phonenumber_id = $request->from_phone_no_id_edit;
            $edit_id = $request->edit_id;
              $user_id = $request->user()->user_id ?? 1;

            $upd_wTemplate = WhatsappApiConfigureModel::where('sno', $edit_id)->first();

            $chk_entity = WhatsappApiConfigureModel::where('entity_id',$entity_id)->where('sno', '!=', $edit_id)->where('status', '!=', 2)->first();

            if ($chk_entity) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Entity is exist!',
                ]);
                return redirect()->back();
            }

            $chk = WhatsappApiConfigureModel::where('waba_id',$waba_id)->where('sno', '!=', $edit_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Waba ID is exist!',
                ]);
                return redirect()->back();
            } else {

                $upd_wTemplate->company_id = $company_id;
                $upd_wTemplate->entity_id = $entity_id;
                $upd_wTemplate->whatsapp_config_name = $whatsapp_config_name;
                $upd_wTemplate->access_tokken = $access_tokken;
                $upd_wTemplate->waba_id = $waba_id;
                $upd_wTemplate->phonenumber_id = $phonenumber_id;
                $upd_wTemplate->updated_by = $user_id;
                $upd_wTemplate->update();

                if ($upd_wTemplate) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Whatsapp Api Config Update Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not update the Whatsapp Api Config!',
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_wTemplate = WhatsappApiConfigureModel::where('sno', $id)->first();
        $upd_wTemplate->status = 2;
        $upd_wTemplate->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_wTemplate = WhatsappApiConfigureModel::where('sno', $id)->first();
        $upd_wTemplate->status = $request->input('status', 0);
        $upd_wTemplate->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

}
