<?php

namespace App\Http\Controllers\settings\base_settings;

use App\Http\Controllers\Controller;
use App\Models\CloudCallApiSetupModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class CloudCallApiSetup extends Controller
{
    public function index()
    {
        $tasks  = CloudCallApiSetupModel::where('et_cloudcall_api_setup.status', '!=', 2)
                                          ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_cloudcall_api_setup.branch_id')
                                          ->select(
                                            'et_cloudcall_api_setup.*',
                                            'et_branch.branch_name',
                                            'et_branch.franchise_name',
                                            'et_branch.branch_type',
                                          )
                                          ->orderBy('et_cloudcall_api_setup.sno', 'desc')
                                          ->get();
        $branch_list = DB::table('et_branch')->where('status', 0)->get();
        return view('content.settings.base_settings.cloudcall_api_setup', compact('tasks', 'branch_list'));
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'task_checklist' => 'required|array',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format !',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $branchID = $request->branchID;
        $task_checklist = $request->input('task_checklist');

        foreach ($task_checklist as $task) {
            $checks = CloudCallApiSetupModel::where('api_key', ucwords($task))->where('status', '!=', 2)->first();

            if ($checks) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Cloud Call Api Key Already Exists',
                ]);
            } else {

                $create = new CloudCallApiSetupModel();
                $create->api_key = ucwords($task);
                $create->branch_id = $branchID;
                $create->created_by = $user_id;
                $create->updated_by = $user_id;
                $create->save();

                if ($create) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Cloud Call Api Key Created Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Cloud Call Api Key Creation Failed',
                    ]);
                }
            }
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_task_checklist' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 422,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 422);
        }

        $user_id = $request->user()->user_id;
        $sno = $request->edit_id;
        $edit_name = $request->edit_task_checklist;

        $checks = CloudCallApiSetupModel::where('api_key', $edit_name)->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

        if ($checks) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Cloud Call Api Key Already Exists!',
            ]);

            return  redirect()->back();
        } else {
            $update = CloudCallApiSetupModel::where('sno', $sno)->first();
            // $update->branch_id = 1;
            $update->api_key = $edit_name;
            $update->created_by = $user_id;
            $update->updated_by = $user_id;
            $update->update();

            if ($update) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Cloud Call Api Key updated Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Error Updating Cloud Call Api Key',
                ]);
            }

            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {
        $update = CloudCallApiSetupModel::where('sno', $id)->first();
        $update->status = $request->input('status', 0);
        $update->update();

        if ($update) {
            return response([
                'status' => 200,
                'message' => 'Status Updated Succesfully',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Updation Failed !',
                'error_msg' => 'Failed Updating Status',
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = CloudCallApiSetupModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->Update();

        return response([
            'status' => 200,
            'message' => 'Cloud Call Api Key Deleted Succesfully',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Edit($id)
    {
        $data = CloudCallApiSetupModel::where('sno', $id)->first();

        if (!$data) {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function deleteData($id)
    {
        $data = CloudCallApiSetupModel::where('sno', $id)->first();

        if (!$data) {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function list()
    {
        $data = CloudCallApiSetupModel::where('status', 0)->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data,
            ], 200);
        } else {
            return response([
                'status' => 200,
                'message' => 'No Such Records',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }
    }
}