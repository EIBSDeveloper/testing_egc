<?php

namespace App\Http\Controllers\settings\base_settings;

use App\Http\Controllers\Controller;
use App\Models\AdditionalChargesModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class AdditionalCharges extends Controller{
    public function index(){
        $charges = AdditionalChargesModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.base_settings.additional_charges', compact('charges'));
    }

    public function store(Request $request){
        $validator = Validator::make($request->all(), [
            'adc_name' => 'required|string',
        ]);

        if($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect input field format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);

            return redirect()->back();
        } else {
            $name = $request->adc_name;
            $percentage = $request->adc_percentage;
            $desc = $request->adc_desc;
            $user_id = $request->user()->user_id;

            $check = AdditionalChargesModel::where('adc_name', ucwords($name))->where('status', '!=', 2)->first();
            if($check){
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name already exists',
                ]);
            } else {
                $store = new AdditionalChargesModel();
                $store->adc_name = ucwords($name);
                $store->adc_percentage = $percentage;
                $store->adc_desc = $desc;
                $store->created_by = $user_id;
                $store->updated_by = $user_id;
                $store->save();

                if($store){
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Additional charges created successfully !',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Additional charges creation failed !',
                    ]);
                }
            }

            return redirect()->back();
        }
    }

    public function Update(Request $request){
        $validator = Validator::make($request->all(), [
            'edit_adc_name' => 'required|string',
            'edit_adc_percentage' => 'required',
        ]);

        if($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect input field format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ]);
            
            return redirect()->back();
        } else {
            $sno = $request->edit_id;
            $edit_name = $request->edit_adc_name;
            $edit_percentage = $request->edit_adc_percentage;
            $edit_desc = $request->edit_adc_desc;
            $user_id = $request->user()->user_id;

            $check = AdditionalChargesModel::where('adc_name', ucwords($edit_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

            if($check){
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name already exists',
                ]);
            } else {
                $upgrade = AdditionalChargesModel::where('sno', $sno)->first();
                $upgrade->adc_name = $edit_name;
                $upgrade->adc_percentage = $edit_percentage;
                $upgrade->adc_desc = $edit_desc;
                $upgrade->created_by = $user_id;
                $upgrade->updated_by = $user_id;
                $upgrade->update();

                if($upgrade){
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Additional Charges Updated successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Additional Charges Update failed !',
                    ]);
                }
            }

            return redirect()->back();
        }
    }

    public function status($id, Request $request){
        $updChargeModel = AdditionalChargesModel::where('sno', $id)->first();
        $updChargeModel->status = $request->input('status', 0);
        $updChargeModel->update();

        if($updChargeModel){
            return response([
                'status' => 200,
                'message' => 'Status Updated Succesfully !',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Updation failed',
                'error_msg' => 'Status Updation failed',
                'data' => null,
            ], 400);
        }
    }

    public function delete($id){
        $updChargeModel = AdditionalChargesModel::where('sno', $id)->first();
        $updChargeModel->status = 2;
        $updChargeModel->update();

        if ($updChargeModel) {
            return response([
                'status' => 200,
                'message' => 'Additional Charges deleted Succesfully !',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }
    }
}