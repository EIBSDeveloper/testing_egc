<?php

namespace App\Http\Controllers\settings\exam_settings;

use App\Http\Controllers\Controller;
use App\Models\QuestionBankCategoryModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class QuestionBankCategory extends Controller
{
    public function index() {
        $lists = QuestionBankCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.exam_settings.question_bank_category', compact('lists'));
    }

    public function Create(Request $request) 
    {
        $validator = Validator::make($request->all(), [
            'question_bank' => 'required|string'
        ]);

        if($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->question_bank;

        $check = QuestionBankCategoryModel::where('status', '!=', 2)->where('question_bank_category', $name)->first();

        if($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Category Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = new QuestionBankCategoryModel();
        $create->question_bank_category = $name;
        $create->desc = $request->desc;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->save();

        if($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Question Bank Category Created Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Category Creation Failed!'
            ]);
        }
    }

    public function Status($id, Request $request)
    {
        $status = QuestionBankCategoryModel::where('sno', $id)->first();
        $status->status = $request->input('status', 0);
        $status->update();

        if ($status) {
            return response([
                'status' => 200,
                'message' => 'Status Changed Succesfully',
                'error_msg' => 'Status Changing Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Changing Failed',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = QuestionBankCategoryModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->update();

        return response([
            'status' => 200,
            'message' => 'Domain Deleted Succesfully',
            'error_msg' => 'Domain Deletion Failed !',
            'data' => null,
        ]);
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_bank' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->edit_bank;
        $sno = $request->edit_id;

        $check = QuestionBankCategoryModel::where('status', '!=', 2)->where('sno', '!=', $sno)->where('question_bank_category', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Category Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = QuestionBankCategoryModel::where('status', '!=', 2)->where('sno', $sno)->first();
        $create->question_bank_category = $name;
        $create->desc = $request->edit_desc;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->update();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Question Bank Category Updated Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Category Updation Failed!'
            ]);
        }
    }
}
