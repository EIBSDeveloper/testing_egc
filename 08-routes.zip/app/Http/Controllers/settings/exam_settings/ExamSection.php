<?php

namespace App\Http\Controllers\settings\exam_settings;

use App\Http\Controllers\Controller;
use App\Models\ExamSectionModel;
use App\Models\QuestionBankTypeModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ExamSection extends Controller
{
    public function index()
    {
        $lists = ExamSectionModel::where('et_exam_section.status', '!=', 2)
        ->select('et_exam_section.*','et_question_bank.bank_name')
        ->leftJoin('et_question_bank' ,'et_exam_section.question_bank_id','=','et_question_bank.sno')
        ->orderBy('et_exam_section.sno', 'desc')
        ->get();
        return view('content.settings.exam_settings.exam_section', compact('lists'));
    }


    public function Create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'section_id' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->section_id;
        $bankId = $request->question_bank_id;

        $check = ExamSectionModel::where('status', '!=', 2)->where('section_name', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Section Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = new ExamSectionModel();
        $create->section_name = $name;
        $create->question_bank_id = $bankId;
        $create->section_desc = $request->exam_desc ?? '-';
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->save();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Exam Section Created Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Section Creation Failed!'
            ]);
        }
    }


    public function Status($id, Request $request)
    {
        $status = ExamSectionModel::where('sno', $id)->first();
        $status->status = $request->input('status', 0);
        $status->update();

        if ($status) {
            return response([
                'status' => 200,
                'message' => 'Status Changed Succesfully',
                'error_msg' => 'Status Changing Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Changing Failed',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = ExamSectionModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->update();

        return response([
            'status' => 200,
            'message' => 'Exam Section Deleted Succesfully',
            'error_msg' => 'Exam Section Deletion Failed !',
            'data' => null,
        ]);
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_section' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->edit_section;
        $sno = $request->edit_id;

        $check = ExamSectionModel::where('status', '!=', 2)->where('sno', '!=', $sno)->where('section_name', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Section Type Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = ExamSectionModel::where('status', '!=', 2)->where('sno', $sno)->first();
        $create->section_name = $name;
        $create->section_desc = $request->edit_desc;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->update();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Exam Section Updated Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Section Updation Failed!'
            ]);
        }
    }
}
