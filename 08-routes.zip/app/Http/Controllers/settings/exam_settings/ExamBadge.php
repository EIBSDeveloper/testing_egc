<?php

namespace App\Http\Controllers\settings\exam_settings;

use App\Http\Controllers\Controller;
use App\Models\ExamBadgeModel;
use App\Models\ExamCategoryModel;
use App\Models\JobpositionModel;
use App\Models\UserRoleModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ExamBadge extends Controller
{
    public function index(Request $request)
    {

        $branch_id = $request->user()->branch_id;

        $roles = UserRoleModel::where('status', 0)->get();
        $job_position = JobpositionModel::where('status', 0)->where('sno', '!=', 46)->orderBy('job_position_name', 'ASC')->get();
        $lists = ExamBadgeModel::select(
            'et_exam_badge.*',
            'et_user_role.role_name',
            'et_exam_category.category_name'
        )
            ->leftJoin('et_user_role', 'et_user_role.sno', '=', 'et_exam_badge.job_id')
            ->leftJoin('et_exam_category', 'et_exam_category.sno', '=', 'et_exam_badge.exam_cat_id')
            ->where('et_exam_badge.status', '!=', 2)->orderBy('et_exam_badge.sno', 'desc')->get();
        return view('content.settings.exam_settings.exam_badge', compact('lists', 'roles', 'job_position'));
    }

    public function Create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'exam_badge_name' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->exam_badge_name;
        $cat_id = $request->exam_cat_id;
        $prize_type = $request->prize_id;

        $check = ExamBadgeModel::where('status', '!=', 2)->where('badge_name', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Badge Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = new ExamBadgeModel();
        $create->badge_name = $name;
        $create->badge_desc = $request->badge_desc;
        $create->job_id = $request->role_id ?? 0;
        $create->prize_id = $prize_type;

        // Badge Image Upload
        if ($request->hasFile('logo')) {
            // Generate a unique filename
            $imageName = time() . '_' . uniqid() . '.' . $request->file('logo')->extension();

            // Define destination path
            $destinationPath = public_path('exam/badges');

            // Move file
            $request->file('logo')->move($destinationPath, $imageName);

            $logo = $imageName;
        } else {
            $logo = $create->badge_image ?? null;
        }

        if ($prize_type == 1) {
            $create->gift = $request->exam_gift;
        } else if ($prize_type == 2) {
            $create->points = $request->exam_points;
        } else if ($prize_type == 3) {
            $create->promotion_id = $request->promotion_id;
        }
        $create->badge_image = $logo;
        $create->exam_cat_id = $cat_id;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->save();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Exam Badge Created Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Badge Creation Failed!'
            ]);

            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {
        $status = ExamBadgeModel::where('sno', $id)->first();
        $status->status = $request->input('status', 0);
        $status->update();

        if ($status) {
            return response([
                'status' => 200,
                'message' => 'Status Changed Succesfully',
                'error_msg' => 'Status Changing Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Changing Failed',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = ExamBadgeModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->update();

        return response([
            'status' => 200,
            'message' => 'Exam Category Deleted Succesfully',
            'error_msg' => 'Exam Category Deletion Failed !',
            'data' => null,
        ]);
    }

    public function Edit($id)
    {
        $data = ExamBadgeModel::where('status', '!=', 2)
            ->where('sno', $id)
            ->first();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => 'No Such Records!',
                'data' => null
            ], 402);
        }
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'exam_badge_name_edit' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $sno = $request->edit_id;
        $user_id = $request->user()->user_id;
        $name = $request->exam_badge_name_edit;
        $cat_id = $request->exam_cat_id_edit;
        $prize_type = $request->edit_prize_id;

        $check = ExamBadgeModel::where('status', '!=', 2)->where('sno', '!=', $sno)->where('badge_name', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Badge Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = ExamBadgeModel::where('sno', $sno)->where('status', '!=', 2)->first();
        $create->badge_name = $name;
        $create->badge_desc = $request->badge_desc_edit;
        $create->job_id = $request->role_id_edit ?? 0;
        $create->exam_cat_id = $cat_id;
        $create->prize_id = $prize_type;

        if ($prize_type == 1) {
            $create->gift = $request->exam_gift_edit;
        } else if ($prize_type == 2) {
            $create->points = $request->exam_points_edit;
        } else if ($prize_type == 3) {
            $create->promotion_id = $request->promotion_id_edit;
        }

        // Badge Image Upload
        if ($request->hasFile('logo_edit')) {
            // Generate a unique filename
            $imageName = time() . '_' . uniqid() . '.' . $request->file('logo_edit')->extension();

            // Define destination path
            $destinationPath = public_path('exam/badges');

            // Move file
            $request->file('logo_edit')->move($destinationPath, $imageName);

            $logo = $imageName;
        } else {
            $logo = $create->badge_image ?? null;
        }

        $create->badge_image = $logo;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->update();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Exam Badge Updated Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Badge Updation Failed!'
            ]);

            return redirect()->back();
        }
    }

    public function list()
    {
        $data = ExamBadgeModel::where('status', 0)->orderBy('sno', 'desc')->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => 'No Such Records!',
                'data' => null
            ], 402);
        }
    }
}
