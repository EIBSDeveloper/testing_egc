<?php

namespace App\Http\Controllers\settings\lead_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UniversityModel;
use Illuminate\Support\Facades\Validator;

class University extends Controller
{
     public function index()
    {
        $University = UniversityModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        //return $University;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.lead_settings.university', [
            'ListTable' => $University,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function Add(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'university_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->university_name;
            $company_des = $request->description_add;


            $user_id = 1;
            $chk = UniversityModel::where('university_name', ucwords($company_name))->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Company is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = UniversityModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $company_id = 'UT-0001/' . $year;
                } else {

                    $data = $category_check->company_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('UT-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $company_id = $request . '/' . $year;
                }

                $add_company = new UniversityModel();

                $add_company->university_name = Ucfirst($company_name);
                $add_company->university_des = $company_des;
                $add_company->university_id = $company_id;

                $add_company->created_by = $user_id;
                $add_company->updated_by = $user_id;

                $add_company->save();

                if ($add_company) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Company type added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Company type!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Edit($id)
    {
        $editcompany = UniversityModel::where('sno', $id)->first();

        return view('content.settings.lead_settings.university', [
            'editcompany' => $editcompany,
            'id' => $id,
        ]);
    }
    public function Update(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'university_name_edit' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->university_name_edit;

            $company_type_desc = $request->description_name_edit;
            $sno = $request->edit_id;
            $chk = UniversityModel::where('university_name', ucwords($company_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Department is exist!'
                ]);
                return redirect()->back();
            } else {
                $upd_CompanyTypeModel = UniversityModel::where('sno', $sno)->first();
                $upd_CompanyTypeModel->university_name = Ucfirst($company_name);

                $upd_CompanyTypeModel->university_des = $company_type_desc;


                $upd_CompanyTypeModel->update();

                if ($upd_CompanyTypeModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'University updated Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the University!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
       
  public function List(Request $request)
  {

      $entity = UniversityModel::where('status', 0)->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $entity
      ], 200);
  }
    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = UniversityModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = UniversityModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
