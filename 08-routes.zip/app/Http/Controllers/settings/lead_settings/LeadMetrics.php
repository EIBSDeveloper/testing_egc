<?php
namespace App\Http\Controllers\settings\lead_settings;

use App\Http\Controllers\Controller;
use App\Models\LeadMetricsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LeadMetrics extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        // return view( 'content.settings.course.knowledge_type.knowledge_type_list' );
        $leadMetric  = LeadMetricsModel::where('status', 0)->first();
        $pageConfigs = ['myLayout' => 'default'];
        if ($leadMetric) {
            $minimum_cr        = $leadMetric->minimum_cr;
            $minimum_cr_color  = $leadMetric->minimum_cr_color;
            $minimum_abv       = $leadMetric->minimum_abv;
            $maximum_cr_color  = $leadMetric->maximum_cr_color;
            $minimum_abv_color = $leadMetric->minimum_abv_color;
            $maximum_abv_color = $leadMetric->maximum_abv_color;
            $minimum_acv       = $leadMetric->minimum_acv;
            $minimum_acv_color = $leadMetric->minimum_acv_color;
            $maximum_acv_color = $leadMetric->maximum_acv_color;

        }

        // Pass the logo URL to the view
        return view('content.settings.lead_settings.lead_metrics', [
            'minimum_cr'        => $minimum_cr ?? '',
            'minimum_cr_color'  => $minimum_cr_color ?? "",
            'maximum_cr_color'  => $maximum_cr_color ?? "",
            'minimum_abv'       => $minimum_abv ?? "",
            'minimum_abv_color' => $minimum_abv_color,
            'maximum_abv_color' => $maximum_abv_color,
            'minimum_acv'       => $minimum_acv,
            'minimum_acv_color' => $minimum_acv_color,
            'maximum_acv_color' => $maximum_acv_color,
            'pageConfigs'       => $pageConfigs,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'minimum_cr' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {
            $minimum_cr        = $request->minimum_cr;
            $minimum_cr_color  = $request->minimum_cr_color;
            $minimum_abv       = $request->minimum_abv;
            $maximum_cr_color  = $request->maximum_cr_color;
            $minimum_abv_color = $request->minimum_abv_color;
            $maximum_abv_color = $request->maximum_abv_color;
            $minimum_acv       = $request->minimum_acv;
            $minimum_acv_color = $request->minimum_acv_color;
            $maximum_acv_color = $request->maximum_acv_color;

            $user_id = $request->user()->user_id ?? 1;
            // $user_id           = 1;

            $leadMetricsCheck = LeadMetricsModel::first();

            if ($leadMetricsCheck) {

                $ld_metric = LeadMetricsModel::find(1);

                $ld_metric->minimum_cr        = $minimum_cr;
                $ld_metric->minimum_cr_color  = $minimum_cr_color;
                $ld_metric->maximum_cr_color  = $maximum_cr_color;
                $ld_metric->minimum_abv       = $minimum_abv;
                $ld_metric->minimum_abv_color = $minimum_abv_color;
                $ld_metric->maximum_abv_color = $maximum_abv_color;
                $ld_metric->minimum_acv       = $minimum_acv;
                $ld_metric->minimum_acv_color = $minimum_acv_color;
                $ld_metric->maximum_acv_color = $maximum_acv_color;
                $ld_metric->created_by        = $user_id;
                $ld_metric->updated_by        = $user_id;
                // return  $ld_metric;
                $ld_metric->update();

                if ($ld_metric) {

                    if ($ld_metric) {
                        session()->flash('toastr', [
                            'type'    => 'success',
                            'message' => 'Lead Metrics Updated Successfully!',
                        ]);
                    } else {
                        session()->flash('toastr', [
                            'type'    => 'error',
                            'message' => 'Could not Update the Lead Metrics!',
                        ]);
                    }

                    $result = response([
                        'status'    => 200,
                        'message'   => 'Lead Metrics has been Updated successfully',
                        'error_msg' => null,
                        'data'      => $ld_metric,
                    ], 200);
                } else {

                    $result = response([
                        'status'    => 401,
                        'message'   => 'Lead Metrics can not be updated',
                        'error_msg' => 'Lead Metrics information is worng please try again',
                        'data'      => null,
                    ], 401);
                }
                return redirect('/settings/lead/lead_metrics');

            } else {

                $add_ld_metric = new LeadMetricsModel;

                $add_ld_metric->minimum_cr        = $minimum_cr;
                $add_ld_metric->minimum_cr_color  = $minimum_cr_color;
                $add_ld_metric->maximum_cr_color  = $maximum_cr_color;
                $add_ld_metric->minimum_abv       = $minimum_abv;
                $add_ld_metric->minimum_abv_color = $minimum_abv_color;
                $add_ld_metric->maximum_abv_color = $maximum_abv_color;
                $add_ld_metric->minimum_acv       = $minimum_acv;
                $add_ld_metric->minimum_acv_color = $minimum_acv_color;
                $add_ld_metric->maximum_acv_color = $maximum_acv_color;
                $add_ld_metric->created_by        = $user_id;
                $add_ld_metric->updated_by        = $user_id;
                // return  $add_general;
                $add_ld_metric->save();
                if ($add_ld_metric) {
                    session()->flash('toastr', [
                        'type'    => 'success',
                        'message' => 'Lead Metrics added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type'    => 'error',
                        'message' => 'Could not add the Lead Metrics!',
                    ]);
                }

                return redirect('/settings/common/lead_metrics');
            }
        }
    }
}
