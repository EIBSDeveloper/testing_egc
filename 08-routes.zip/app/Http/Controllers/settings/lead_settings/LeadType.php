<?php

namespace App\Http\Controllers\settings\lead_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LeadTypeModel;
use Illuminate\Support\Facades\Validator;

class LeadType extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $CourseCategory = LeadTypeModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.lead_settings.lead_type', [
            'CourseCategory' => $CourseCategory,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function List()
    {
        $CourseCategory = LeadTypeModel::where('status', 0)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseCategory
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_type_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $lead_type_name       = $request->lead_type_name;
            $lead_type_desc   = $request->lead_type_desc;
            $user_id                    = $request->user()->user_id;
            $chk = LeadTypeModel::where('lead_type_name', ucwords($lead_type_name))->where('status', '!=', 2)->first();

            if ($chk) {

                $result = response([
                    'status'    => 401,
                    'message'   => 'Error',
                    'error_msg' => 'Lead Type Already Exists!',
                    'data'      => null,
                ], 200);
            } else {
                $category_check = LeadTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $lead_type_id = 'LT-0001/' . $year;
                } else {

                    $data = $category_check->lead_type_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf('LT-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $lead_type_id = $request . '/' . $year;
                }

                $add_category = new LeadTypeModel();
                $add_category->lead_type_id         = $lead_type_id;
                $add_category->lead_type_name       = Ucfirst($lead_type_name);
                $add_category->lead_type_desc       = $lead_type_desc;
                $add_category->created_by           = $user_id;
                $add_category->updated_by           = $user_id;

                $add_category->save();

                if ($add_category) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Lead Type Added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Add the Lead Type!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Edit($id)
    {
        $editcategory = LeadTypeModel::where('sno', $id)->first();

        return view('content.settings.sales.lead_type.lead_type_list', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_type_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $lead_type_name       = $request->lead_type_name;
            $lead_type_desc       = $request->lead_type_desc;
            $lead_type_id         = $request->lead_type_id;

            $upd_CourseCategoryModel =  LeadTypeModel::where('sno', $lead_type_id)->first();

            $chk = LeadTypeModel::where('lead_type_name', ucwords($lead_type_name))->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $lead_type_id) {
                    $result = response([
                        'status'    => 401,
                        'message'   => 'Error',
                        'error_msg' => 'Lead Type Already Exists!',
                        'data'      => null,

                    ], 200);
                } else {
                }
            }
            $upd_CourseCategoryModel->lead_type_name  = Ucfirst($lead_type_name);
            $upd_CourseCategoryModel->lead_type_desc  = $lead_type_desc;
            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Lead Type Updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Lead Type!'
                ]);
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel =  LeadTypeModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        if ($upd_CourseCategoryModel) {
            return response([
                'status'    => 200,
                'message'   => 'Lead Type Deleted Successfully!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Lead Type !',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  LeadTypeModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
