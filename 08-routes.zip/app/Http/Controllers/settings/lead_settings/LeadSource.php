<?php

namespace App\Http\Controllers\settings\lead_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LeadSourceModel;
use Illuminate\Support\Facades\Validator;

class LeadSource extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $lead_source = LeadSourceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.lead_settings.lead_source', [
            'lead_source' => $lead_source,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function List()
    {
        $CourseCategory = LeadSourceModel::where('status', 0)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseCategory
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_source_name' => 'required'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $lead_source_name       = $request->lead_source_name;
            $lead_source_desc          = $request->lead_source_desc;
            $user_id                    = $request->user()->user_id;
            $chk = LeadSourceModel::where('lead_source_name', ucwords($lead_source_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                $result = response([
                    'status'    => 401,
                    'message'   => 'Error',
                    'error_msg' => 'Lead Source Already Exists!',
                    'data'      => null,
                ], 200);
            } else {
                $category_check = LeadSourceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $lead_source_id = 'LS-0001/' . $year;
                } else {

                    $data = $category_check->lead_source_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf('LS-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $lead_source_id = $request . '/' . $year;
                }

                $add_lead_source = new LeadSourceModel();
                $add_lead_source->lead_source_id         = $lead_source_id;
                $add_lead_source->lead_source_name       = Ucfirst($lead_source_name);
                $add_lead_source->lead_source_desc       = $lead_source_desc;
                $add_lead_source->branch_id = self::$branch_id;
                $add_lead_source->created_by                 = $user_id;
                $add_lead_source->updated_by                 = $user_id;

                $add_lead_source->save();

                if ($add_lead_source) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Lead Source added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Lead Source!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $editcategory = LeadSourceModel::where('sno', $id)->first();

        return view('content.settings.sales.lead_source.lead_source_list', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_source_name' => 'required',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $lead_source_name       = $request->lead_source_name;
            $lead_source_desc       = $request->lead_source_desc;
            $lead_source_id        = $request->lead_source_id;

            $upd_CourseCategoryModel =  LeadSourceModel::where('sno', $lead_source_id)->first();

            $chk = LeadSourceModel::where('lead_source_name', ucwords($lead_source_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $lead_source_id) {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Lead Source Already Exists!'
                    ]);
                } else {
                }
            }

            $upd_CourseCategoryModel->lead_source_name  = Ucfirst($lead_source_name);
            $upd_CourseCategoryModel->lead_source_desc  = $lead_source_desc;

            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Lead Source Updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Lead Source!'
                ]);
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel =  LeadSourceModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Lead Source Deleted Successfully!',
            'error_msg' => 'Could not Delete Lead Source!',
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  LeadSourceModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
