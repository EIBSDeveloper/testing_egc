<?php

namespace App\Http\Controllers\settings\lead_settings;

use App\Http\Controllers\Controller;
use App\Models\AppointmentCategoryModel;
use Illuminate\Http\Request;
use App\Models\LeadSourceModel;
use Illuminate\Support\Facades\Validator;

class AppointmentCategory extends Controller
{
    public function index()
    {
        $lead_source = AppointmentCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.lead_settings.appointment_category', [
            'lead_source' => $lead_source,
        ]);
    }

    public function List($id)
    {
        $CourseCategory = AppointmentCategoryModel::where('status', 0)->where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseCategory
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_source_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $lead_source_name       = $request->lead_source_name;
            $lead_source_desc          = $request->lead_source_desc;
            $user_id                    = $request->user()->user_id;
            $chk = AppointmentCategoryModel::where('appointment_category', ucwords($lead_source_name))->where('status', '!=', 2)->first();

            if ($chk) {

                $result = response([
                    'status'    => 401,
                    'message'   => 'Error',
                    'error_msg' => 'Name has been  already created!',
                    'data'      => null,
                ], 200);
            } else {

                $add_lead_source = new AppointmentCategoryModel();
                $add_lead_source->appointment_category       = Ucfirst($lead_source_name);
                $add_lead_source->description       = $lead_source_desc;
                $add_lead_source->link_check = $request->link_check ?? 0;
                $add_lead_source->created_by                 = $user_id;
                $add_lead_source->updated_by                 = $user_id;
                $add_lead_source->save();

                if ($add_lead_source) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Appointment Category added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Appointment Category!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $editcategory = LeadSourceModel::where('sno', $id)->first();

        return view('content.settings.sales.lead_source.lead_source_list', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_source_name' => 'required|max:255',

        ]);

        $user_id = $request->user()->user_id;

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $lead_source_name       = $request->lead_source_name;
            $lead_source_desc       = $request->lead_source_desc;
            $lead_source_id        = $request->lead_source_id;

            $upd_CourseCategoryModel =  AppointmentCategoryModel::where('sno', $lead_source_id)->first();

            $chk = AppointmentCategoryModel::where('appointment_category', ucwords($lead_source_name))->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $lead_source_id) {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Name has been  already assigned!'
                    ]);
                } else {
                }
            }

            $upd_CourseCategoryModel->appointment_category  = Ucfirst($lead_source_name);
            $upd_CourseCategoryModel->description  = $lead_source_desc;
            $upd_CourseCategoryModel->link_check = $request->edit_link_check ?? 0;
            $upd_CourseCategoryModel->updated_by = $user_id;
            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Appointment Category Update Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Appointment Category!'
                ]);
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel =  AppointmentCategoryModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Appointment Category Successfully Deleted!',
            'error_msg' => 'Could not Delete Lead Source!',
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  AppointmentCategoryModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Appointment Category Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
