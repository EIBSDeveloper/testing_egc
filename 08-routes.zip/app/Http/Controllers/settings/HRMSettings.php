<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class HRMSettings extends Controller
{
  public function index()
  {
    return view('content.settings.hrm_settings');
  }
}
