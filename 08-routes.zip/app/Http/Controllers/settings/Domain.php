<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DomainModel;
use Illuminate\Support\Facades\Validator;

class Domain extends Controller
{
    public function index()
    {
        $Domain = DomainModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        //return $University;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.journal.domain', [
            'domains' => $Domain,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function Add(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'domain_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->domain_name;
            $company_des = $request->domain_des;


            $user_id = 1;
            $chk = DomainModel::where('domain_name', ucwords($company_name))->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Company is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = DomainModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $company_id = 'DM-0001/' . $year;
                } else {

                    $data = $category_check->company_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('DM-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $company_id = $request . '/' . $year;
                }

                $add_company = new DomainModel();

                $add_company->domain_name = Ucfirst($company_name);
                $add_company->domain_des = $company_des;
                $add_company->domain_id = $company_id;

                $add_company->created_by = $user_id;
                $add_company->updated_by = $user_id;

                $add_company->save();

                if ($add_company) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Domain added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Domain!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = DomainModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }
    public function Update(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'edit_domainname' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->edit_domainname;

            $company_type_desc = $request->edit_des;
            $sno = $request->edit_id;
            $chk = DomainModel::where('domain_name', ucwords($company_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Domain is exist!'
                ]);
                return redirect()->back();
            } else {
                $upd_CompanyTypeModel = DomainModel::where('sno', $sno)->first();
                $upd_CompanyTypeModel->domain_name = Ucfirst($company_name);

                $upd_CompanyTypeModel->domain_des = $company_type_desc;


                $upd_CompanyTypeModel->update();

                if ($upd_CompanyTypeModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Domain successfull updated !'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Domain!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = DomainModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
