<?php

namespace App\Http\Controllers\mobile_apps;

use App\Http\Controllers\Controller;
use App\Mail\ETPLMail;
use App\Models\ChatModel;
use App\Models\CustomerModel;
use App\Models\EmailTemplateModel;
use App\Models\ManageTickickModel;
use App\Models\OtpModel;
use App\Models\SmsTemplateModel;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class CustomerAppController extends Controller
{
    public function customerLogin(Request $request)
    {
        $mobile_no = $request->mobile_no;
        $email_id = $request->email_id;
        $check = $request->check;

        $validator = Validator::make($request->all(), [
            'check' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => $validator->errors()->first(),
            ]);
        } else {

            if ($check == 0) {
                $customer = DB::table('et_customer')
                    ->where('status', 0)
                    ->where('cus_mobile', $mobile_no)
                    ->whereNotNull('cus_mobile')
                    ->first();

                if (! $customer) {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Customer Not Found !',
                        'status_code' => 404,
                    ], 404);
                }

                $branch_data = DB::table('et_branch')
                    ->where('sno', $customer->branch_id)
                    ->where('status', 0)
                    ->first();

                if ($customer) {
                    if ($mobile_no == '9677482114') {
                        $otp_value = 123456;
                    } else {
                        $otp_value = rand(100000, 999999);
                    }

                    $otp = new OtpModel;

                    $otp->user_id = $customer->sno;
                    $otp->otp_check = $check;
                    $otp->user_from = $mobile_no;
                    $otp->otp_number = $otp_value;
                    $otp->created_by = $customer->sno;
                    $otp->updated_by = $customer->sno;
                    $otp->save();

                    // if ($mobile_no !== '9677482114') {
                    if ($otp_value) {
                        $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                        $authkey = $result_sms ? $result_sms->authkey : '';
                        $sender_id = $result_sms ? $result_sms->sender_id : '';
                        $template_id = $result_sms ? $result_sms->template_id : '';
                        $country_code = $result_sms ? $result_sms->country_code : '';
                        $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                        $mobile_number = $country_code . $mobile_no;

                        $app_name = 'PhdIzone';
                        // $app_link = 'https://elysiumacademy.org/';
                        $app_code = 'yDWtn76svb8';
                        // Replace placeholders with actual values
                        $replacement_values = [$customer->cus_name, $app_name, $otp_value, $app_code];
                        $message_content = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                                return array_shift($replacement_values);
                            },
                            $message_content
                        );

                        $route = 'default';
                        $postData = [
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender' => $sender_id,
                            'route' => $route,
                        ];

                        $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

                        // Initialize the resource
                        $ch = curl_init();
                        curl_setopt_array($ch, [
                            CURLOPT_URL => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST => true,
                            CURLOPT_POSTFIELDS => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                        ]);

                        // Get response
                        $response = curl_exec($ch);
                        // return $response;
                        $err = curl_error($ch);
                        curl_close($ch);
                    }
                    // }

                    return response()->json([
                        'status' => '1',
                        'otp' => $otp_value,
                        //  'otp'                => 123456,
                        'user_name' => $customer->cus_name,
                        'customer_id' => $customer->customer_id,
                        'phone_no' => $customer->cus_mobile,
                        'email_id' => $customer->cus_email_id,

                        'message' => 'Successfully Login',
                        'error_msg' => null,
                        'data' => null,
                        'status_code' => 200,
                        // 'api_token'          => $token,
                    ], 200);
                }
            } elseif ($check == 1) {
                $customer = DB::table('et_customer')
                    ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.cus_email_id', $email_id)
                    ->whereNotNull('et_customer.cus_email_id')
                    ->select('et_customer.*', 'et_lead.created_by as created_by')
                    ->first();

                if (! $customer) {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Customer Not Found !',
                        'status_code' => 404,
                    ], 404);
                }

                $branch_data = DB::table('et_branch')
                    ->where('sno', $customer->branch_id)
                    ->where('status', 0)
                    ->first();

                $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id', $customer->created_by)->first();

                if ($customer) {
                    if ($email_id == 'vetri4vijayan@gmail.com') {
                        $otp_value = 123456;
                    } else {
                        $otp_value = rand(100000, 999999);
                    }

                    $otp = new OtpModel;

                    $otp->user_id = $customer->sno;
                    $otp->otp_number = $otp_value;
                    $otp->otp_check = $check;
                    $otp->user_from = $email_id;
                    $otp->created_by = $customer->sno;
                    $otp->updated_by = $customer->sno;
                    $otp->save();

                    if ($otp_value) {
                        if ($customer && $email_id) {
                            $email_template_id = 12; // thank you template
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                            $dynamicSubject = str_replace('#entity_name', 'PhdIzone', $emailTemplate->email_name);
                            $content = $emailTemplate->email_subject;
                            $content = str_replace('#user_name', $customer->cus_name, $content);
                            $content = str_replace('#entity_name', 'PhdIzone', $content);
                            $content = str_replace('#otp_code', $otp_value, $content);
                            $branchNo = $branch_data->mobile;
                            $branchemail = $branch_data->mail;
                            $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/PhDiZone/';
                            $instaLink = $branch_data->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
                            $content = str_replace('#sales_mobile', $cug_details ? $cug_details->staff_mobile : $branch_data->cre_mobile, $content);
                            $content = str_replace('#cre_mobile', $branch_data->cre_mobile ?? '8220011465', $content);
                            $url = 'phdizone.com';
                            $mailData = [
                                'url' => $url,
                                'subject' => $dynamicSubject,
                                'content' => $content,
                                'branchNo' => $branchNo,
                                'branchemail' => $branchemail, // Use the message content from the request
                                'fbLink' => $fbLink,      // Use the message content from the request
                                'instaLink' => $instaLink,   // Use the message content from the request
                                'salesMobile' => $branch_data->cre_mobile ?? '9003400111',
                            ];

                            $to_address = $email_id;
                            $from_address = 'elysiumtechnology@elysium.community';
                            $from_name = 'PhdIzone';

                            Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                        }
                    }

                    return response()->json([
                        'status' => '1',
                        'otp' => $otp_value,
                        //  'otp'                => 123456,
                        'user_name' => $customer->cus_name,
                        'customer_id' => $customer->customer_id,
                        'phone_no' => $customer->cus_mobile,
                        'email_id' => $customer->cus_email_id,

                        'message' => 'Successfully Login',
                        'error_msg' => null,
                        'data' => null,
                        'status_code' => 200,
                        // 'api_token'          => $token,
                    ], 200);
                }
            } else {
                $response = [
                    'status' => '2',
                    'message' => 'Customer does not exists',
                    'error_msg' => null,
                    'data' => null,
                    'status_code' => 404,
                ];

                return response($response, 200);
            }
        }
    }

    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'otp' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => $validator->errors()->first(),
                'status_code' => 410,
            ], 410);
        }

        $check = $request->check;
        $mobile_no = $request->mobile_no;
        $email_id = $request->email_id;
        $otpInput = $request->otp;

        if ($check == 0) {
            $otpRecord = OtpModel::where('user_from', $mobile_no)
                ->where('otp_number', $otpInput)
                ->where('status', 0)
                ->orderBy('sno', 'desc')
                ->first();

            if (! $otpRecord) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No OTP found for this number.',
                    'status_code' => 404,
                ], 404);
            }

            $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
            $expiryTime = $createdAt->copy()->addMinutes(2);
            $currentTime = Carbon::now('UTC');

            if ($currentTime->greaterThan($expiryTime)) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'OTP expired. Please request a new one.',
                    'status_code' => 410,
                ], 410);
            }

            if ($otpRecord->otp_number != $otpInput) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Invalid OTP.',
                    'status_code' => 401,
                ], 401);
            }
        } else {
            $otpRecord = OtpModel::where('user_from', $email_id)
                ->where('otp_number', $otpInput)
                ->where('status', 0)
                ->first();

            if (! $otpRecord) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'No OTP found for this email.',
                    'status_code' => 404,
                ], 404);
            }

            $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
            $expiryTime = $createdAt->copy()->addMinutes(10);
            $currentTime = Carbon::now('UTC');

            if ($currentTime->greaterThan($expiryTime)) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'OTP expired. Please request a new one.',
                    'status_code' => 410,
                ], 410);
            }

            if ($otpRecord->otp_number != $otpInput) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Invalid OTP.',
                    'status_code' => 401,
                ], 401);
            }
        }

        if ($otpRecord->otp_number == $otpInput) {
            DB::table('et_otp')
                ->where('otp_number', $otpInput)
                ->where('status', 0)
                ->update([
                    'status' => 2,
                ]);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'OTP verified successfully!',
            'user_id' => $otpRecord->user_id,
            'status_code' => 200,
        ], 200);
    }

    public function customerDetails(Request $request)
    {
        $id = $request->user_id;

        if (! $id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404,
            ], 404);
        }

        $customer = DB::table('et_customer')
            ->leftJoin('et_countries', 'et_countries.id', '=', 'et_customer.country')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
            ->where('et_customer.sno', $id)
            ->where('et_customer.status', 0)
            ->select(
                'et_customer.*',
                'et_countries.name as country_name',
                'et_states.name as state_name',
                'et_cities.name as city_name'
            )
            ->first();

        if (! $customer) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Not Found !',
                'status_code' => 404,
            ], 404);
        }

        if ($customer) {
            if ($customer->cus_pic != '' && file_exists(public_path('customer_images/' . $customer->cus_pic))) {
                $customer->cus_pic = asset('customer_images/' . $customer->cus_pic);
            } else {
                $customer->cus_pic = '';
            }
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Customer Data Fetched Successfully !',
            'data' => [
                'name' => $customer->cus_name,
                'customer_id' => $customer->customer_id,
                'customer_img' => $customer->cus_pic,
                'customer_dob' => $customer->cus_dob,
                'mobile_no' => $customer->cus_mobile,
                'email_id' => $customer->cus_email_id,
                'country' => $customer->country_name,
                'state' => $customer->state_name,
                'city' => $customer->city_name,
                'country_id' => $customer->country,
                'state_id' => $customer->state,
                'city_id' => $customer->city,
                'door_no' => $customer->door_no,
                'area' => $customer->address,
                'pincode' => $customer->pincode,
            ],
            'status_code' => 200,
        ], 200);
    }

    public function proposalData(Request $request)
    {
        $id = $request->user_id;

        if (! $id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404,
            ], 404);
        }

        $proposals = DB::table('et_proposal')
            ->where('customer_id', $id)
            ->select('service_title', 'proposal_id', 'sno')
            ->get();

        if ($proposals->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Proposal Found For This Customer !',
                'status_code' => 404,
            ], 404);
        }

        $data = [];

        foreach ($proposals as $pro) {
            $pro->service_count = DB::table('et_customer_services')
                ->where('proposal_id', $pro->sno)
                ->count();

            $data[] = [
                'id' => $pro->sno,
                'title' => $pro->service_title,
                'proposal_id' => $pro->proposal_id,
                'service_count' => $pro->service_count,
            ];
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Proposal Data Fetched Successfully !',
            'data' => $data,
            'status_code' => 200,
        ], 200);
    }

    public function serviceData(Request $request)
    {
        $id = $request->user_id;
        $proposal_id = $request->proposal_id;

        if (! $id || ! $proposal_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Id Not Found !',
                'status_code' => 404,
            ], 404);
        }

        $services = DB::table('et_customer_services')
            ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->where('et_customer_services.customer_id', $id)
            ->where('et_customer_services.proposal_id', $proposal_id)
            ->select(
                'et_customer_services.sno',
                'et_customer_services.created_at',
                'et_customer_services.variant_variable_ids',
                'et_product.product_name',
                'et_product_category.product_category_name'
            )
            ->get();

        if ($services->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Services Found For This Proposal !',
                'status_code' => 404,
            ], 404);
        }

        $data = [];
        foreach ($services as $service) {
            $variantVariableIds = json_decode($service->variant_variable_ids, true);

            $variantName = '';
            $variableName = '';

            if (is_array($variantVariableIds)) {
                foreach ($variantVariableIds as $variantVariable) {
                    $variant = DB::table('et_manage_product_variant')->where('sno', $variantVariable['variant_id'])->first();
                    $variable = DB::table('et_manage_product_variable')->where('sno', $variantVariable['variable_id'])->first();

                    if ($variant) {
                        $variantName = $variant->product_variant_name ?? '';
                    }

                    if ($variable) {
                        $variableName = $variable->variable_name ?? '';
                    }
                }
            }

            $year = date('Y', strtotime($service->created_at));
            $tempid = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
            $service->service_id = "SR-{$tempid}/{$year}";

            $service->variant_name = $variantName;
            $service->variable_name = $variableName;

            $milestoneCount = DB::table('et_milestone_mapping')
                ->where('service_id', $service->sno)
                ->where('customer_id', $id)
                ->where('proposal_id', $proposal_id)
                ->where('status', 0)
                ->count();

            $data[] = [
                'id' => $service->sno,
                'service_id' => $service->service_id,
                'name' => $service->product_name,
                'category' => $service->product_category_name,
                'variant' => $service->variant_name,
                'variable' => $service->variable_name,
                'milestone_count' => $milestoneCount,
            ];
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Service Data Fetched Successfully !',
            'data' => $data,
            'status_code' => 200,
        ], 200);
    }

    public function milestoneData(Request $request)
    {
        $id = $request->user_id;
        $proposal_id = $request->proposal_id;
        $service_id = $request->service_id;

        if (! $id || ! $service_id || ! $proposal_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Id Not Found !',
            ], 404);
        }

        $service = DB::table('et_customer_services')
            ->where('sno', $service_id)
            ->first();

        if (! $service) {
            return response([
                'status' => 404,
                'message' => 'No Service Found',
                'status_code' => 404,
                'data' => null,
            ], 404);
        }

        $service_product = DB::table('et_product')
            ->where('sno', $service->product_id)
            ->first();

        $year = date('Y', strtotime($service->created_at));
        $serviceFormatId = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
        $formatted_service_id = "SR-{$serviceFormatId}/{$year}";

        $service_dates = DB::table('et_work_order')
            ->where('proposal_id', $proposal_id)
            ->select(
                'development_date',
                'deliverable_date',
                'customer_end_date'
            )
            ->where('status', 0)
            ->first();

        // 1️⃣ Get milestones
        $milestones = DB::table('et_milestone_mapping')
            ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
            ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_milestone_mapping.customer_id', $id)
            ->where('et_milestone_mapping.service_id', $service_id)
            ->where('et_milestone_mapping.proposal_id', $proposal_id)
            ->select(
                'et_milestone_mapping.sno',
                'et_milestone_mapping.task_ids',
                'et_milestone_mapping.status',
                'et_payment_slot.payment_slot_name',
                'et_proposal_pay_slot.payable_amount',
                'et_proposal_pay_slot.proposal_sno',
                'et_proposal_pay_slot.paidAmount',
                'et_proposal.service_title as proposal_title',
                'et_country_currencies.currency_code',
                'et_country_currencies.currency_symbol'
            )
            ->get();

        if ($milestones->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Milestones Found',
            ], 404);
        }

        // 2️⃣ Collect all task IDs
        $allTaskIds = [];
        foreach ($milestones as $mile) {
            $taskIds = json_decode($mile->task_ids, true);
            if (is_array($taskIds)) {
                $allTaskIds = array_merge($allTaskIds, $taskIds);
            }
        }
        $allTaskIds = array_unique($allTaskIds);

        // 3️⃣ Fetch task names
        $taskNames = [];
        if (! empty($allTaskIds)) {
            $taskNames = DB::table('et_product_task')
                ->whereIn('sno', $allTaskIds)
                ->pluck('task_name', 'sno')
                ->toArray();
        }

        // 4️⃣ Build final response
        $finalMilestones = [];
        $totalTaskIds = [];
        $paid_milestone = 0;
        foreach ($milestones as $mile) {
            $taskIds = json_decode($mile->task_ids, true) ?? [];
            $taskNameList = [];

            foreach ($taskIds as $taskId) {
                if (isset($taskNames[$taskId])) {
                    $taskNameList[] = $taskNames[$taskId];
                }
            }

            $totalTaskIds = array_merge($totalTaskIds, $taskIds);

            $milestoneProgress = 0;
            if ($mile->payable_amount > 0) {
                $milestoneProgress = round(($mile->paidAmount / $mile->payable_amount) * 100, 2);
            }
            if ($mile->paidAmount != 0) {
                $paid_milestone++;
            }
            $milestoneFolders = DB::table('et_milestone_folders')
                ->where('milestone_mapping_id', $mile->sno)
                ->first();

            $IsHaveDocuments = $milestoneFolders ? 0 : 1;

            $IsHaveDocuments = ($milestoneFolders && $milestoneFolders->status == 2) ? 3 : $IsHaveDocuments;

            $finalMilestones[] = [
                'sno' => $mile->sno,
                'IsHaveDocuments' => $IsHaveDocuments,
                'proposal_sno' => $mile->proposal_sno,
                'payment_slot_name' => $mile->payment_slot_name,
                'proposal_title' => $mile->proposal_title,
                'currency_symbol' => $mile->currency_symbol,
                'payable_amount' => $mile->payable_amount,
                'paidAmount' => $mile->paidAmount,
                'progress' => $milestoneProgress,
                'status' => $mile->status,
                'task_ids' => $taskIds,
                'task_names' => $taskNameList,
                'task_count' => count($taskNameList),
            ];
        }

        $overallPayable = $milestones->sum(function ($item) {
            return (float) $item->payable_amount;
        });

        $overallPaid = $milestones->sum(function ($item) {
            return (float) $item->paidAmount;
        });

        $overallBalance = $overallPayable - $overallPaid;

        $paymentProgress = 0;

        if ($overallPayable > 0) {
            $paymentProgress = round(($overallPaid / $overallPayable) * 100, 2);
        }

        // $PaidMileStone = $milestones->where('')



        return response()->json([
            'status' => 200,
            'message' => 'Milestone Data Fetched Successfully!',
            'total_task_count' => count(array_unique($totalTaskIds)),
            'service_id' => $formatted_service_id,
            'service_sno' => $service_id,
            'proposal_sno' => $proposal_id,
            'proposal_title' => $milestones[0]->proposal_title ?? '',
            'service_title' => $service_product->product_name ?? '',
            'currency_symbol' => $milestones[0]->currency_symbol ?? '₹',
            'total_costing' => $overallPayable,
            'paid_cost' => $overallPaid,
            'due_cost' => $overallBalance,
            'total_milestone' => $milestones ? count($milestones) : 0,
            'paid_milestone' => $paid_milestone,
            'due_cost' => $overallBalance,
            'payment_progress' => $paymentProgress,
            'estimated_date' => $service_dates->deliverable_date ?? null,
            'validity_date' => $service_dates->customer_end_date ?? null,
            'data' => $finalMilestones
        ]);
    }

    public function GenerateDocuments(Request $request)
    {
        $mile_sno = $request->mile_sno;

        if (!$mile_sno) {
            return response()->json([
                'status' => 'error',
                'message' => 'Milestone Id Not Found !',
            ], 404);
        }

        $milestoneFolders = DB::table('et_milestone_folders')
            ->where('milestone_mapping_id', $mile_sno)
            ->first();

        if (! $milestoneFolders) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Milestones Found',
            ], 404);
        }

        if ($milestoneFolders->status == 2) {
            DB::table('et_milestone_folders')
                ->where('milestone_mapping_id', $mile_sno)
                ->update([
                    'status' => 1,
                    'is_sync' => 0,
                    'sync_date' => date('Y-m-d'),
                ]);
        }

        return response()->json([
            'status' => 200,
            'message' => 'Milestone Document Generated Successfully !',
            'status_code' => 200,
        ], 200);
    }

    public function getJournalServices(Request $request)
    {
        $id = $request->user_id;

        if (! $id) {
            return response()->json([
                'status' => 404,
                'message' => 'Please Login...',
                'status_code' => 404,
            ], 404);
        }

        $services = DB::table('et_customer_services')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->where('et_customer_services.status', '!=', 2)
            ->where('et_customer_services.customer_id', $id)
            ->where('et_customer_services.journal_check', 1)
            ->select(
                'et_product.product_name',
                'et_customer_services.sno',
                'et_customer_services.created_at'
            )
            ->get();

        if ($services->isEmpty()) {
            return response()->json([
                'status' => 404,
                'message' => 'No Services Found !',
                'status_code' => 404,
            ], 404);
        }

        $data = [];

        foreach ($services as $service) {
            $year = date('Y', strtotime($service->created_at));
            $tempid = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
            $service->service_id = "SR-{$tempid}/{$year}";

            $service->journal_count = DB::table('et_manage_journal')
                ->where('service_id', $service->sno)
                ->where('customer_id', $id)
                ->where('status', '!=', 2)
                ->count();

            $data[] = [
                'sno' => $service->sno,
                'name' => $service->product_name,
                'service_id' => $service->service_id,
                'journal_count' => $service->journal_count,
            ];
        }

        return response()->json([
            'status' => 200,
            'message' => 'Service Data Fetched Successfully !',
            'status_code' => 200,
            'data' => $data,
        ], 200);
    }

    public function getJournalList(Request $request)
    {
        $id = $request->user_id;
        $serviceId = $request->service_id;
        $helper = new \App\Helpers\Helpers;

        if (! $id || ! $serviceId) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'Id Not Found !',
            ], 404);
        }

        $service = DB::table('et_customer_services')
            ->select(
                'et_product.product_name',
                'et_customer_services.*'
            )
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->where('et_customer_services.customer_id', $id)
            ->where('et_customer_services.sno', $serviceId)
            ->first();

        if (! $service) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'No Service Found !',
            ], 404);
        }

        $journals = DB::table('et_manage_journal')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->where('et_manage_journal.status', '!=', 2)
            ->where('et_manage_journal.customer_id', $id)
            ->where('et_manage_journal.service_id', $serviceId)
            ->select(
                'et_manage_journal.sno',
                'et_manage_journal.paper_name',
                'et_manage_journal.submited_date',
                'et_manage_journal.status',
                'et_manage_journal.journal_id',
                'et_manage_journal.publish_author',
                'et_journal_booklet.journal_name'
            )
            ->get();

        if ($journals->isEmpty()) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'No Journals Found For the Customer !',
            ], 404);
        }

        $submittedCount = DB::table('et_manage_journal')
            ->where('status', 0)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $withEditorCount = DB::table('et_manage_journal')
            ->where('status', 1)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $underReviewerCount = DB::table('et_manage_journal')
            ->where('status', 3)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $revisionCount = DB::table('et_manage_journal')
            ->where('status', 4)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $acceptedCount = DB::table('et_manage_journal')
            ->where('status', 5)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $rejectedCount = DB::table('et_manage_journal')
            ->where('status', 6)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $eProofingCount = DB::table('et_manage_journal')
            ->where('status', 7)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $publichedCount = DB::table('et_manage_journal')
            ->where('status', 8)
            ->where('customer_id', $id)
            ->where('service_id', $serviceId)
            ->count();

        $data = [];
        foreach ($journals as $journal) {

            $domain_names = $helper->get_domain_by_proposalId($service->proposal_id);

            $data[] = [
                'sno' => $journal->sno,
                'journal_name' => $journal->paper_name,
                'status' => $journal->status,
                'booklet' => $journal->journal_name,
                'author' => $journal->publish_author ?? '-',
                'domains' => $domain_names,
                'submited_date' => $journal->submited_date,
                'journal_id' => $journal->journal_id,
            ];
        }

        return response()->json([
            'status' => 200,
            'status_code' => 200,
            'message' => 'Journal Data Fetched Successfully !',
            'title' => $service->product_name,
            'total_count' => $submittedCount + $withEditorCount + $publichedCount + $eProofingCount + $rejectedCount + $acceptedCount + $underReviewerCount + $revisionCount + $publichedCount,
            'submitted_count' => $submittedCount,
            'with_editor_count' => $withEditorCount,
            'under_reviewer_count' => $underReviewerCount,
            'revision_count' => $revisionCount,
            'accepted_count' => $acceptedCount,
            'rejected_count' => $rejectedCount,
            'e_proofing_count' => $eProofingCount,
            'published_count' => $publichedCount,
            'journal_data' => $data,
        ], 200);
    }

    public function getJournalHistory(Request $request)
    {
        $id = $request->user_id;
        $service_id = $request->service_id;
        $journal_id = $request->journal_id;

        if (! $id || ! $service_id || ! $journal_id) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'ID Not Found !',
            ], 404);
        }

        $histories = DB::table('et_journal_history')
            ->where('customer_id', $id)
            ->where('service_id', $service_id)
            ->where('journal_id', $journal_id)
            ->where('status', '!=', 2)
            ->orderBy('sno', 'asc')
            ->get();

        if ($histories->isEmpty()) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'No History Found !',
            ], 404);
        }

        foreach ($histories as $history) {
            $history->submitteddocuments = json_decode($history->submitted_documents, true);
            $history->with_editordocuments = json_decode($history->with_editor_documents, true);
            $history->under_reviewerdocuments = json_decode($history->under_reviewer_documents, true);
            $history->reviewerdocument = json_decode($history->reviewer_document, true);
            $history->accepteddocument = json_decode($history->accepted_document, true);
            $history->e_proofingdocuments = json_decode($history->e_proofing_documents, true);
            $history->publishedfiles = json_decode($history->published_files, true);
        }

        $journals = DB::table('et_manage_journal')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->where('et_manage_journal.status', '!=', 2)
            ->where('et_manage_journal.customer_id', $id)
            ->where('et_manage_journal.service_id', $service_id)
            ->select(
                'et_manage_journal.sno',
                'et_manage_journal.paper_name',
                'et_manage_journal.submited_date',
                'et_manage_journal.status',
                'et_manage_journal.journal_id',
                'et_manage_journal.publish_author',
                'et_journal_booklet.journal_name'
            )
            ->first();

        return response()->json([
            'status' => 200,
            'status_code' => 200,
            'journal_name' => $journals->paper_name,
            'message' => 'Journal Histories Fetched Successfully !',
            'data' => $histories,
        ], 200);
    }

    public function PaymentData(Request $request)
    {
        $id = $request->user_id;

        if (! $id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404,
            ], 404);
        }

        $proposals = DB::table('et_proposal')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_proposal.customer_id', $id)
            ->select('et_proposal.service_title', 'et_proposal.proposal_id', 'et_proposal.sno', 'et_proposal.total_amount', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
            ->get();

        if ($proposals->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Proposal Found For This Customer !',
                'status_code' => 404,
            ], 404);
        }

        $data = [];

        foreach ($proposals as $pro) {

            // $pay_slot

            $pro->service_count = DB::table('et_customer_services')
                ->where('proposal_id', $pro->sno)
                ->count();

            $data[] = [
                'id' => $pro->sno,
                'title' => $pro->service_title,
                'proposal_id' => $pro->proposal_id,
                'currency_symbol' => $pro->currency_symbol,
                'proposal_total_amount' => round($pro->total_amount),
                'service_count' => $pro->service_count,
            ];
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Payment Data Fetched Successfully !',
            'status_code' => 200,
            'data' => $data,
        ], 200);
    }

    public function PaymentDetails(Request $request)
    {
        $id = $request->user_id;
        $proposal_id = $request->proposal_id;

        if (! $id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404,
            ], 404);
        }

        $proposal = DB::table('et_proposal')
            ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
            ->where('et_proposal.sno', $proposal_id)
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_proposal.status', '!=', 2)
            ->orderBy('et_proposal.sno', 'desc')
            ->first();

        if (! $proposal) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Proposal Found For This Customer !',
                'status_code' => 404,
            ], 404);
        }

        $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name', 'et_transaction.payment_status')
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->leftJoin('et_payment', function ($join) {
                $join->on('et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->where('et_payment.status', 0);
            })
            ->leftJoin('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_proposal_pay_slot.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_pay_slot.status', 0)
            ->get();

        $slot_total = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->where('et_proposal_pay_slot.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_pay_slot.status', 0)
            ->first();

        $PaidAmount = $slots->sum('paidAmount');
        $total_balance = $slot_total->total_amount ? $slot_total->total_amount - $PaidAmount : 0;
        $data = [];
        $list = [];
        $paidCount = 0;
        foreach ($slots as $li) {
            $payment_status = 'Waiting';
            if (isset($li->temp_send_link)) {
                $payment_status = 'Pay Now';
            }
            if ($li->payment_status == 1) {
                $payment_status = 'Paid';
                $paidCount++;
                $li->temp_send_link = '';
            }

            $list[] = [
                'payment_slot_id' => $li->sno,
                'slot_amount' => $li->slot_amount,
                'payment_slot_name' => $li->payment_slot_name,
                'payment_status' => $payment_status,
                'payment_link' => $li->temp_send_link,
            ];
        }
        $total_payments = $slots->isNotEmpty() ? count($slots) : 0;

        $data[] = [
            'id' => $proposal->sno,
            'title' => $proposal->service_title,
            'proposal_id' => $proposal->proposal_id,
            'currency_symbol' => $proposal->currency_symbol,
            'total_amount' => round($slot_total->total_amount),
            'total_paid' => round($PaidAmount),
            'total_balance' => round($total_balance),
            'total_payment_count' => $total_payments,
            'paid_payments_count' => $paidCount,
            'payment_list' => $list,
        ];

        return response()->json([
            'status' => 'success',
            'message' => 'Payment Details Fetched Successfully !',
            'status_code' => 200,
            'data' => $data,
        ], 200);
    }

    public function PaymentSlotDetails(Request $request)
    {
        $id = $request->user_id;
        $proposal_slot_id = $request->payment_slot_id;

        if (! $id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404,
            ], 404);
        }

        $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name', 'et_transaction.payment_status')
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->leftJoin('et_payment', function ($join) {
                $join->on('et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->where('et_payment.status', 0);  // Adding the status condition here
            })
            ->leftJoin('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_proposal_pay_slot.sno', $proposal_slot_id)
            ->where('et_proposal_pay_slot.status', 0)
            ->first();

        $slot_total = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->where('et_proposal_pay_slot.sno', $proposal_slot_id)
            ->where('et_proposal_pay_slot.status', 0)
            ->first();

        $PaidAmount = $slots->paidAmount;
        $total_balance = $slot_total->slot_amount ? $slot_total->slot_amount - $PaidAmount : 0;

        $proposal = DB::table('et_proposal')
            ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
            ->where('et_proposal.sno', $slots->proposal_sno)
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_proposal.status', '!=', 2)
            ->orderBy('et_proposal.sno', 'desc')
            ->first();

        if (! $proposal) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Proposal Found For This Customer !',
                'status_code' => 404,
            ], 404);
        }

        $payment = DB::table('et_payment')
            ->where('pay_slot_id', $proposal_slot_id)
            ->first();
        $helper = new \App\Helpers\Helpers;

        $encryptedValue = $helper->encrypt_decrypt($proposal_slot_id, 'encrypt');
        $print_url = url('/receipt_print/' . $encryptedValue);

        $data = [];

        $data[] = [
            'id' => $proposal->sno,
            'title' => $proposal->service_title,
            'proposal_id' => $proposal->proposal_id,
            'currency_symbol' => $proposal->currency_symbol,
            'total_amount' => round($slot_total->slot_amount),
            'total_paid' => round($PaidAmount),
            'total_balance' => round($total_balance),
            'payment_slot_name' => $slots->payment_slot_name,
            'payment_date' => $payment->transaction_date ? date('d-M-Y', strtotime($payment->transaction_date)) : '',
            'print_url' => $print_url,
        ];

        return response()->json([
            'status' => 'success',
            'message' => 'Payment Slot Details Fetched Successfully !',
            'status_code' => 200,
            'data' => $data,
        ], 200);
    }

    // Chat
    public function ChatProposalPublicationList(Request $request)
    {
        $id = $request->user_id;
        if (! $id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found!',
                'status_code' => 404,
            ], 404);
        }

        // Helper function to fetch service data and chat details
        $fetchServiceData = function ($journalCheck, $chatType) use ($id) {
            return DB::table('et_customer_services')
                ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
                ->where('et_customer_services.status', '!=', 2)
                ->where('et_customer_services.customer_id', $id)
                ->where('et_customer_services.journal_check', $journalCheck)
                ->select(
                    'et_product.product_name',
                    'et_customer_services.sno',
                    'et_customer_services.created_at'
                )
                ->get()
                ->map(function ($service) use ($chatType) {
                    $year = date('Y', strtotime($service->created_at));
                    $tempid = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
                    $service->service_id = "SR-{$tempid}/{$year}";

                    // Get chat count
                    $chatcount = DB::table('et_chat')
                        ->where('service_id', $service->sno)
                        ->where('who', 1)
                        ->where('type', $chatType)
                        ->where('status', 0)
                        ->count('sno');

                    // Get last time stamp
                    $last_time_stamp = DB::table('et_chat')
                        ->where('service_id', $service->sno)
                        ->where('type', $chatType)
                        ->first('created_at');

                    $service->chatcount = $chatcount;
                    $service->last_time_stamp = $last_time_stamp && $last_time_stamp->created_at
                        ? Carbon::parse($last_time_stamp->created_at)->format('d M Y, h:i A')
                        : '';

                    return $service;
                });
        };

        // Fetch Proposal and Publication data
        $Proposal = $fetchServiceData(0, 0);  // journal_check = 0 and type = 0
        $Publication = $fetchServiceData(1, 1);  // journal_check = 1 and type = 1

        return response()->json([
            'status' => 200,
            'message' => 'Service Data Fetched Successfully!',
            'status_code' => 200,
            'Proposal' => $Proposal,
            'Publication' => $Publication,
        ], 200);
    }

    public function getChatList(Request $request)
    {
        $id = $request->user_id;
        $service_id = $request->service_id;
        $type = $request->type;

        if (! $id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404,
            ], 404);
        }

        $services = DB::table('et_customer_services')
            ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->where('et_customer_services.customer_id', $id)
            ->where('et_customer_services.sno', $service_id)
            ->select(
                'et_customer_services.sno',
                'et_product.product_name',
                'et_product_category.product_category_name'
            )
            ->first();

        $chat_list = DB::table('et_chat')
            ->where('customer_id', $id)
            ->where('service_id', $service_id)
            ->where('type', $type)
            ->where('status', '!=', 2)
            ->orderBy('sno', 'ASC')
            ->get();
        $data = [];

        foreach ($chat_list as $li) {
            $staffDetails = [];
            if ($li->who == 1) {
                $staffDetails = DB::table('et_staff')
                    ->select('staff_name', 'nick_name', 'staff_image')
                    ->where('sno', $li->staff_id)
                    ->where('sno', '>', 0)
                    ->first();
                if ($staffDetails) {
                    if ($staffDetails->staff_image != '' && file_exists(public_path('staff_images/' . $staffDetails->staff_image))) {
                        $staffDetails->staff_image = asset('staff_images/' . $staffDetails->staff_image);
                    } else {
                        $staffDetails->staff_image = '';
                    }
                }
            }
            $data[] = [
                'id' => $li->sno,
                'who' => $li->who,
                'message_content' => $li->message_content,
                'staffDetails' => $staffDetails,
                'timestamp' => $li->created_at
                    ? Carbon::parse($li->created_at)->format('d M Y, h:i A')
                    : '',
            ];
        }

        return response()->json([
            'status' => 200,
            'message' => 'Chat Details Fetched Successfully !',
            'services_name' => $services->product_name,
            'services_category' => $services->product_category_name,
            'data' => $data,
        ], 200);
    }

    public function CreateChat(Request $request)
    {
        // Validate the request
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            'type' => 'required|integer',
            'service_id' => 'required|integer',
            'message_content' => 'required|string',
            'who' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors(),
            ], 422);
        }

        // Assign the validated input to variables
        $customer_id = $request->user_id;
        $service_id = $request->service_id;
        $type = $request->type;

        // Check if customer exists
        $customer = DB::table('et_customer')->where('sno', $customer_id)->first('sno');
        if (! $customer) {
            return response()->json([
                'status' => 404,
                'message' => 'Customer not found',
            ]);
        }

        // Handle attachment if available
        // $attachment = null;
        // if ($request->has('attachment')) {
        //     $base64 = explode(',', $request->attachment)[1] ?? null;
        //     if ($base64) {
        //         $decoded = base64_decode($base64);
        //         if ($decoded) {
        //             $imageName = 'issue_' . time() . '_' . rand(1000, 9999) . '.png';
        //             $dir = public_path('issue_attachment');
        //             if (!file_exists($dir)) {
        //                 mkdir($dir, 0777, true);
        //             }
        //             file_put_contents($dir . '/' . $imageName, $decoded);
        //             $attachment = $imageName;
        //         }
        //     }
        // }

        // Save the chat message
        $chat = new ChatModel;
        $chat->type = $type;
        $chat->customer_id = $customer_id;
        $chat->service_id = $service_id;
        $chat->who = $request->who;
        $chat->staff_id = $request->staff_id ?? 0;
        // $chat->attachment = $attachment; // Save attachment if available
        $chat->message_content = $request->message_content;
        $chat->created_at = Carbon::now('Asia/Kolkata');
        $chat->updated_at = Carbon::now('Asia/Kolkata');
        $chat->save();

        return response()->json([
            'status' => 200,
            'message' => 'Chat Message saved successfully',
        ]);
    }

    public function markSeen(Request $request)
    {
        $customer_id = $request->customer_id;
        $who = $request->who;
        $service_id = $request->service_id;

        ChatModel::where('customer_id', $customer_id)
            ->where('who', $who)
            ->where('service_id', $service_id)
            ->where('status', 0)
            ->update(['status' => 1]);

        return response()->json([
            'status' => 200,
            'message' => 'Marked as seen',
        ]);
    }

    // Ticket
    public function CreateTicket(Request $request)
    {
        // Validate the incoming data
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            'proposal_id' => 'required|integer',
            'service_id' => 'required|integer',
            'priority' => 'required|integer',
            'subject' => 'required|string',
            'department_id' => 'required|integer',
            'relevant_id' => 'required|integer',
            'description' => 'nullable|string',
            'attachment' => 'nullable|array',
            'attachment.*.file_name' => 'nullable|string',
            'attachment.*.base64' => 'nullable|string',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors(),
            ], 422);
        }

        $attachments = [];

        // Process the attachments
        if ($request->has('attachment') && count($request->attachment) > 0) {
            // Ensure the directory exists
            $directory = public_path('ticket_attachments');
            if (! file_exists($directory)) {
                mkdir($directory, 0777, true); // Create the directory if not exists
            }

            foreach ($request->attachment as $file) {
                // Decode the base64 image data
                $base64_image = substr($file['base64'], strpos($file['base64'], ',') + 1);
                $decoded_image = base64_decode($base64_image);

                // Generate a unique file name
                $fileName = uniqid() . '-' . $file['file_name'];

                // Define the path to store the file
                $filePath = $directory . '/' . $fileName;

                // Save the image to the file system
                file_put_contents($filePath, $decoded_image);

                // Prepare the attachment data
                $attachments[] = [
                    'file_name' => $file['file_name'],
                    'file_path' => 'ticket_attachments/' . $fileName, // Relative path for storage
                ];
            }
        }

        // return $attachments;

        // Handle ticket ID generation
        $category_check = ManageTickickModel::orderBy('sno', 'desc')->first();
        if (! $category_check) {
            $year = substr(date('y'), -2);
            $ticket_id = 'TCK-0001/' . $year;
        } else {
            $data = $category_check->ticket_id;
            $slice = explode('/', $data);
            $result = preg_replace('/[^0-9]/', '', $slice[0]);
            $next_number = (int) $result + 1;
            $request_id = sprintf('TCK-%04d', $next_number);
            $year = substr(date('y'), -2);
            $ticket_id = $request_id . '/' . $year;
        }

        // Save the ticket data
        $ticket = ManageTickickModel::create([
            'ticket_id' => $ticket_id,
            'service_id' => $request->service_id,
            'proposal_id' => $request->proposal_id,
            'department_id' => $request->department_id,
            'relevant_id' => $request->relevant_id,
            'customer_id' => $request->user_id,
            'priority' => $request->priority,
            'subject' => $request->subject,
            'description' => $request->description ?? '',
            'attachments' => json_encode($attachments),
            'created_by' => $request->user_id,
            'updated_by' => $request->user_id,
        ]);

        if ($ticket) {
            // Insert into history table
            DB::table('et_manage_ticket_history')->insert([
                'ticket_id' => $ticket->sno,
                'who' => 1,
                'message' => 'Created',
                'status' => 0,
                'created_by' => $ticket->customer_id,
                'updated_by' => $ticket->customer_id,
            ]);
        }

        // Response structure for mobile API
        return response()->json([
            'status' => 200,
            'message' => 'Ticket successfully created.',
            'data' => $ticket,
        ], 200);
    }

    // ==============================
    // Ticket Relavant LIST
    // ==============================
    public function TicketRelavantList(Request $request)
    {
        try {
            $data = DB::table('et_ticket_relevant')
                ->where('status', 0)
                ->orderBy('relevant_name')
                ->select(
                    'sno',
                    'relevant_name',
                    'status',
                )
                ->get();

            return response()->json([
                'status' => 'success',
                'status_code' => 200,

                'message' => 'Ticket Relavant list loaded successfully',
                'data' => $data,
            ], 200);
        } catch (Exception $e) {

            return response()->json([
                'status' => 'false',
                'status_code' => 500,
                'message' => 'Failed to load Ticket Relavant list',
                'error_msg' => $e->getMessage(),
            ], 500);
        }
    }
    // ==============================
    // Ticket Relavant LIST
    // ==============================
    public function TicketDepartmentList(Request $request)
    {
        try {
            $data = DB::table('et_user_role')
                ->where('status', 0)
                ->orderBy('role_name')
                ->whereIn('sno', [15, 16, 33])
                ->select(
                    'sno',
                    'role_name AS name',
                    'status',
                )
                ->get();

            return response()->json([
                'status' => 'success',
                'status_code' => 200,

                'message' => 'Ticket Department list loaded successfully',
                'data' => $data,
            ], 200);
        } catch (Exception $e) {

            return response()->json([
                'status' => 'false',
                'status_code' => 500,
                'message' => 'Failed to load Ticket Department list',
                'error_msg' => $e->getMessage(),
            ], 500);
        }
    }


    public function TicketproposalData(Request $request)
    {
        $id = $request->user_id;

        if (! $id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404,
            ], 404);
        }

        $proposals = DB::table('et_proposal')
            ->where('customer_id', $id)
            ->select('service_title', 'proposal_id', 'sno')
            ->get();

        if ($proposals->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Proposal Found For This Customer !',
                'status_code' => 404,
            ], 404);
        }

        $data = [];

        foreach ($proposals as $pro) {
            $pro->service_count = DB::table('et_customer_services')
                ->where('proposal_id', $pro->sno)
                ->count();

            $data[] = [
                'id' => $pro->sno,
                'title' => $pro->service_title,
                'proposal_id' => $pro->proposal_id,
                'service_count' => $pro->service_count,
            ];
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Proposal Data Fetched Successfully !',
            'data' => $data,
            'status_code' => 200,
        ], 200);
    }


    public function TicketproposalServicesData(Request $request)
    {
        $id = $request->user_id;

        if (! $id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Customer Id Not Found !',
                'status_code' => 404,
            ], 404);
        }

        $proposal_id = $request->proposal_sno;

        if (!$proposal_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Proposal Id Not Found !',
                'status_code' => 404,
            ], 404);
        }

        $services = DB::table('et_customer_services')
            ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->where('et_customer_services.customer_id', $id)
            ->where('et_customer_services.proposal_id', $proposal_id)
            ->select(
                'et_customer_services.sno',
                'et_customer_services.created_at',
                'et_customer_services.variant_variable_ids',
                'et_product.product_name',
                'et_product_category.product_category_name'
            )
            ->get();

        if ($services->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'No Services Found For This Proposal !',
                'status_code' => 404,
            ], 404);
        }

        $data = [];
        foreach ($services as $service) {
            // $variantVariableIds = json_decode($service->variant_variable_ids, true);

            // $variantName = '';
            // $variableName = '';

            // if (is_array($variantVariableIds)) {
            //     foreach ($variantVariableIds as $variantVariable) {
            //         $variant = DB::table('et_manage_product_variant')->where('sno', $variantVariable['variant_id'])->first();
            //         $variable = DB::table('et_manage_product_variable')->where('sno', $variantVariable['variable_id'])->first();

            //         if ($variant) {
            //             $variantName = $variant->product_variant_name ?? '';
            //         }

            //         if ($variable) {
            //             $variableName = $variable->variable_name ?? '';
            //         }
            //     }
            // }

            $year = date('Y', strtotime($service->created_at));
            $tempid = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
            $service->service_id = "SR-{$tempid}/{$year}";

            // $service->variant_name = $variantName;
            // $service->variable_name = $variableName;

            // $milestoneCount = DB::table('et_milestone_mapping')
            //     ->where('service_id', $service->sno)
            //     ->where('customer_id', $id)
            //     ->where('proposal_id', $proposal_id)
            //     ->where('status', 0)
            //     ->count();

            $data[] = [
                'id' => $service->sno,
                'name' => $service->product_name,
                'service_id' => $service->service_id,
                // 'category' => $service->product_category_name,
                // 'variant' => $service->variant_name,
                // 'variable' => $service->variable_name,
                // 'milestone_count' => $milestoneCount,
            ];
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Proposal Data Fetched Successfully !',
            'data' => $data,
            'status_code' => 200,
        ], 200);
    }

    // Ticket List
    public function TicketList(Request $request)
    {
        // Validate the incoming data
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            // 'proposal_id' => 'required|integer',
            // 'service_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'  => 422,
                'message' => 'Incorrect format input fields',
                'errors'  => $validator->errors(),
            ], 422);
        }
        // return $request;

        // Query to fetch the ticket list
        $tickets = ManageTickickModel::select(
            'et_product.product_name as service_name',
            'et_proposal.service_title as proposal_name',
            'et_manage_ticket.sno as ticket_sno',
            'et_manage_ticket.*'
        )
            // ->where('et_manage_ticket.status', '!=', 2)
            ->where('et_manage_ticket.customer_id', $request->user_id)
            // ->where('et_manage_ticket.proposal_id', $request->proposal_id)
            // ->where('et_manage_ticket.service_id', $request->service_id)
            ->leftJoin('et_proposal', 'et_manage_ticket.proposal_id', '=', 'et_proposal.sno')
            ->leftJoin('et_customer_services', 'et_manage_ticket.service_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
            ->get();

        // Format created_at and return formatted data with Asia/Kolkata timezone
        $formattedTickets = $tickets->map(function ($ticket) {
            // Set timezone to Asia/Kolkata
            $ticket->created_date = Carbon::parse($ticket->created_at, 'UTC')
                ->timezone('Asia/Kolkata')
                ->format('d-M-Y');  // Format date as 16-Feb-2026

            $ticket->created_time = Carbon::parse($ticket->created_at, 'UTC')
                ->timezone('Asia/Kolkata')
                ->format('h:i A');  // Format time as 05:29 AM

            return $ticket;
        });

        // Return the result
        return response()->json([
            'status' => 200,
            'message' => 'Tickets fetched successfully',
            'data' => $formattedTickets,
        ], 200);
    }

    // Ticket Status Update
    public function updateticket(Request $request)
    {

        // Validate the incoming data
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            'status' => 'required|integer',
            'ticket_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors(),
            ], 422);
        }

        $user_id = $request->user_id;
        $status  = $request->status;
        $id = $request->ticket_id;

        // Get main ticket details with joins
        $ticket = DB::table('et_manage_ticket')
            ->where('customer_id', $user_id)
            ->where('sno', $id)
            ->first();

        if (! $ticket) {
            return response()->json([
                'status' => 404,
                'message' => 'Ticket not found',
            ], 404);
        }

        $message = '';
        if ($status == 4) {
            $message = $request->message;
        } elseif ($status == 5) {
            $message = 'Completed';
        }
        $who = 1;
        // Update the main ticket
        $ticket = DB::table('et_manage_ticket')
            ->where('sno', $id)
            ->update([
                'status' => $status,
                'updated_at' => now(),
                'updated_by' => $user_id,
            ]);

        if ($ticket) {
            // Insert into history table
            DB::table('et_manage_ticket_history')->insert([
                'ticket_id' => $id,
                'who' => $who,
                'message' => $message,
                'status' => $status,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
        }

        return response([
            'status' => 200,
            'message' => 'Ticket updated successfully!',
        ], 200);
    }

    // Ticket History
    public function getTicketHistory(Request $request)
    {
        // Validate the incoming data
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            'ticket_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors(),
            ], 422);
        }

        $user_id = $request->user_id;
        $id = $request->ticket_id;

        // Get main ticket details with joins
        $ticket = DB::table('et_manage_ticket')
            ->select(
                'et_manage_ticket.*',
                // 'et_customer.cus_name',
                // 'et_customer.customer_id AS cus_ai_id',
                // 'et_customer.cus_mobile',
                'et_customer_services.cre_id',
                'et_product.product_name as service_name',
                'et_manage_ticket.sno as ticket_sno',
                'et_manage_ticket.description as ticket_description',
                'et_customer_services.created_at as service_created_at',
                DB::raw("
                    CASE et_manage_ticket.status
                        WHEN 0 THEN 'Open'
                        WHEN 1 THEN 'Accepted'
                        WHEN 2 THEN 'Rejected'
                        WHEN 3 THEN 'Closed'
                        WHEN 4 THEN 'Reopened'
                        WHEN 5 THEN 'Completed'
                        ELSE 'Unknown'
                    END as status_text
                ")
            )
            // ->leftJoin('et_customer', 'et_manage_ticket.customer_id', '=', 'et_customer.sno')
            ->leftJoin('et_customer_services', 'et_manage_ticket.service_id', '=', 'et_customer_services.sno')
            ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
            ->where('et_manage_ticket.customer_id', $user_id)
            ->where('et_manage_ticket.sno', $id)
            ->first();

        if (! $ticket) {
            return response()->json([
                'status' => 404,
                'message' => 'Ticket not found',
            ], 404);
        }

        // $year = date('Y', strtotime($ticket->service_created_at));
        // $id = str_pad($ticket->sno, 5, '0', STR_PAD_LEFT);
        // $service_id = "SR-{$id}/{$year}";

        // $ticket->services_id = $service_id;

        $ticket->created_date = $ticket->created_at ? date('d-M-Y', strtotime($ticket->created_at)) : '';
        $ticket->updated_date = $ticket->updated_at ? date('d-M-Y', strtotime($ticket->updated_at)) : '';

        $history = DB::table('et_manage_ticket_history')
            ->where('ticket_id', $id)
            ->orderBy('created_at', 'desc')
            ->get();

        $statusMap = [
            0 => 'Open',
            1 => 'Accepted',
            2 => 'Rejected',
            3 => 'Closed',
            4 => 'Reopened',
            5 => 'Completed',
        ];

        $history = $history->map(function ($row) use ($statusMap) {
            $row->created_date = date('d-M-Y', strtotime($row->created_at));
            $row->created_date_time = date('d-M-Y H:i:s', strtotime($row->created_at));
            $row->history_status_text = $statusMap[$row->status] ?? 'Unknown'; // ✅ Correct way

            return $row;
        });

        // Get CRE details if needed
        // $cre = null;
        // if ($ticket->cre_id) {
        //     $cre = DB::table('et_staff')
        //         ->where('sno', $ticket->cre_id)
        //         ->select('staff_name as user_name')
        //         ->first();
        // }

        // Get attachments
        $attachments = [];
        $isDocuments = json_decode($ticket->attachments, true) ?? [];
        if ($isDocuments && ! empty($isDocuments)) {
            foreach ($isDocuments as $index => $document) {
                $attachments[] = [
                    'file_name' => $document['file_name'] ?? 'document_' . ($index + 1),
                    'link' => asset($document['file_path']),
                ];
            }
        }

        $staff_attachments = [];
        $staffisDocuments = json_decode($ticket->staff_attachments, true) ?? [];
        if ($staffisDocuments && ! empty($staffisDocuments)) {
            foreach ($staffisDocuments as $index => $document) {
                $staff_attachments[] = [
                    'file_name' => $document['file_name'] ?? 'document_' . ($index + 1),
                    'link' => asset($document['file_path']),
                ];
            }
        }

        return response()->json([
            'status' => 200,
            'data' => [
                'ticket' => $ticket,
                'attachments_files' => $attachments,
                'staff_files' => $staff_attachments,
                'history' => $history,
                // 'customer' => [
                //     'name' => $ticket->cus_name,
                //     'mobile' => $ticket->cus_mobile,
                //     'id' => $ticket->cus_ai_id
                // ],
                // 'cre' => $cre,
            ],
        ]);
    }

    // ==============================
    // COUNTRY LIST
    // ==============================
    public function CountryList()
    {
        try {
            $data = DB::table('et_countries')
                ->where('status', 0)
                ->orderBy('name')
                ->get();

            return response()->json([
                'status' => 'success',
                'status_code' => 200,
                'message' => 'Country list loaded successfully',
                'data' => $data,
            ], 200);
        } catch (Exception $e) {

            return response()->json([
                'status' => 'false',
                'status_code' => 500,
                'message' => 'Failed to load country list',
                'error_msg' => $e->getMessage(),
            ], 500);
        }
    }

    // ==============================
    // STATE LIST
    // ==============================
    public function StateList(Request $request)
    {
        $countryId = $request->countryId;
        try {
            $data = DB::table('et_states')
                ->where('status', 0)
                ->where('country_id', $countryId)
                ->orderBy('name')
                ->get();

            return response()->json([
                'status' => 'success',
                'status_code' => 200,
                'message' => 'State list loaded successfully',
                'data' => $data,
            ], 200);
        } catch (Exception $e) {

            return response()->json([
                'status' => 'false',
                'status_code' => 500,
                'message' => 'Failed to load state list',
                'error_msg' => $e->getMessage(),
            ], 500);
        }
    }

    // ==============================
    // CITY LIST
    // ==============================
    public function CityList(Request $request)
    {
        $stateId = $request->stateId;
        try {
            $data = DB::table('et_cities')
                ->where('status', 0)
                ->where('state_id', $stateId)
                ->orderBy('name')
                ->get();

            return response()->json([
                'status' => 'success',
                'status_code' => 200,

                'message' => 'City list loaded successfully',
                'data' => $data,
            ], 200);
        } catch (Exception $e) {

            return response()->json([
                'status' => 'false',
                'status_code' => 500,
                'message' => 'Failed to load city list',
                'error_msg' => $e->getMessage(),
            ], 500);
        }
    }

    public function ProfileUpload(Request $request)
    {
        // Validate the incoming data
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            'dob' => 'required|string',
            'country_id' => 'required|integer',
            'state_id' => 'required|integer',
            'city_id' => 'required|integer',
            'area' => 'required|string',
            'profile_image' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors(),
            ], 422);
        }
        // return $request;

        // Get the user data from the request
        $userId = $request->user_id;
        $dob = $request->dob;
        $countryId = $request->country_id;
        $stateId = $request->state_id;
        $cityId = $request->city_id;
        $area = $request->area;
        $fileName = '';

        // Handle the profile image upload if provided
        if ($request->has('profile_image')) {
            // Get the base64 encoded image string
            $base64_image = $request->profile_image;

            // Ensure the base64 data is valid
            if (strpos($base64_image, 'data:image/') !== 0) {
                return response()->json(['error' => 'Invalid image data'], 400);
            }

            // Extract the base64 string (remove the data:image/... part)
            $base64_image = substr($base64_image, strpos($base64_image, ',') + 1);
            $decoded_image = base64_decode($base64_image);

            // Check if the image decoding was successful
            if ($decoded_image === false) {
                return response()->json(['error' => 'Failed to decode the image'], 400);
            }

            // Create a directory for the images if it doesn't exist
            $directory = public_path('customer_images');
            if (! file_exists($directory)) {
                mkdir($directory, 0777, true); // Create the directory if not exists
            }

            // Generate a unique filename
            $fileName = uniqid() . '-' . time() . '.jpg'; // Add extension

            // Define the path to store the file
            $filePath = $directory . '/' . $fileName;

            // Save the image to the storage
            $success = file_put_contents($filePath, $decoded_image);

            // Check if the file was successfully saved
            if (! $success) {
                return response()->json(['error' => 'Failed to save the image'], 500);
            }
        }
        // return $fileName;

        // Save the user data to the CustomerModel
        $customer = CustomerModel::where('sno', $userId)
            ->update([
                'cus_dob' => $dob ? date('Y-m-d', strtotime($dob)) : null,
                'country' => $countryId,
                'state' => $stateId,
                'city' => $cityId,
                'address' => $area,

            ]);

        if ($fileName) {
            $customer = CustomerModel::where('sno', $userId)
                ->update([
                    'cus_pic' => $fileName,
                ]);
        }

        // Return success response
        return response()->json([
            'status' => 'success',
            'status_code' => 200,
            'message' => 'Profile updated successfully',
            'data' => $customer,
        ], 200);
    }

    // public function DashboardData(Request $request)
    // {

    //     // Validate the incoming data
    //     $validator = Validator::make($request->all(), [
    //         'user_id' => 'required|integer',
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json([
    //             'status_code' => 422,
    //             'message' => 'Incorrect format input fields',
    //             'errors' => $validator->errors(),
    //         ], 422);
    //     }

    //     $proposal = DB::table('et_proposal')
    //         ->where('customer_id', $request->user_id)
    //         ->where('status', '!=', 2)
    //         ->pluck('sno');

    //     $proposal_count = count($proposal);

    //     $service_count = DB::table('et_customer_services')
    //         ->whereIn('proposal_id', $proposal)
    //         ->count();

    //     $upcoming_payment = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name', 'et_transaction.payment_status')
    //         ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
    //         ->leftJoin('et_payment', function ($join) {
    //             $join->on('et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
    //                 ->where('et_payment.status', 0);
    //         })

    //         ->leftJoin('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //         ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    //         ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
    //         ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal)
    //         ->whereNotNull('et_proposal_pay_slot.nextPayDate')
    //         ->where('et_proposal_pay_slot.status', 0)
    //         ->orderBy('et_proposal_pay_slot.sno', 'desc')
    //         ->select(
    //             'et_proposal_pay_slot.payable_amount',
    //             'et_proposal_pay_slot.nextPayDate',
    //             'et_country_currencies.currency_code',
    //             'et_country_currencies.currency_symbol'
    //         )
    //         ->first();

    //     $serviceId = DB::table('et_customer_services')
    //         ->where('status', '!=', 2)
    //         ->whereIn('proposal_id', $proposal)
    //         ->where('journal_check', 1)
    //         ->pluck('sno');

    //     $submittedCount = DB::table('et_manage_journal')
    //         ->where('status', 0)
    //         ->where('customer_id', $request->user_id)
    //         ->whereIn('service_id', $serviceId)
    //         ->count();

    //     $withEditorCount = DB::table('et_manage_journal')
    //         ->where('status', 1)
    //         ->where('customer_id', $request->user_id)
    //         ->whereIn('service_id', $serviceId)
    //         ->count();

    //     $underReviewerCount = DB::table('et_manage_journal')
    //         ->where('status', 3)
    //         ->where('customer_id', $request->user_id)
    //         ->whereIn('service_id', $serviceId)
    //         ->count();

    //     $revisionCount = DB::table('et_manage_journal')
    //         ->where('status', 4)
    //         ->where('customer_id', $request->user_id)
    //         ->whereIn('service_id', $serviceId)
    //         ->count();

    //     $acceptedCount = DB::table('et_manage_journal')
    //         ->where('status', 5)
    //         ->where('customer_id', $request->user_id)
    //         ->whereIn('service_id', $serviceId)
    //         ->count();

    //     $rejectedCount = DB::table('et_manage_journal')
    //         ->where('status', 6)
    //         ->where('customer_id', $request->user_id)
    //         ->whereIn('service_id', $serviceId)
    //         ->count();

    //     $eProofingCount = DB::table('et_manage_journal')
    //         ->where('status', 7)
    //         ->where('customer_id', $request->user_id)
    //         ->whereIn('service_id', $serviceId)
    //         ->count();

    //     $publichedCount = DB::table('et_manage_journal')
    //         ->where('status', 8)
    //         ->where('customer_id', $request->user_id)
    //         ->whereIn('service_id', $serviceId)
    //         ->count();

    //     $data = [
    //         'proposal_count' => $proposal_count,
    //         'service_count' => $service_count,
    //         'upcoming_payment_status' => $upcoming_payment ? 1 : 0,
    //         'currency_symbol' => $upcoming_payment && $upcoming_payment->currency_symbol ? $upcoming_payment->currency_symbol : '',
    //         'upcoming_payment_amount' => $upcoming_payment ? $upcoming_payment->payable_amount : 0,
    //         'upcoming_payment_date' => $upcoming_payment && $upcoming_payment->nextPayDate ? date('d-M-Y', strtotime($upcoming_payment->nextPayDate)) : '',
    //         'submitted_count' => $submittedCount,
    //         'with_editor_count' => $withEditorCount,
    //         'under_reviewer_count' => $underReviewerCount,
    //         'revision_count' => $revisionCount,
    //         'accepted_count' => $acceptedCount,
    //         'rejected_count' => $rejectedCount,
    //         'e_proofing_count' => $eProofingCount,
    //         'published_count' => $publichedCount,
    //         'total_count' => $submittedCount + $withEditorCount + $publichedCount + $eProofingCount + $rejectedCount + $acceptedCount + $underReviewerCount + $revisionCount + $publichedCount,
    //     ];

    //     // Return success response
    //     return response()->json([
    //         'status' => 'success',
    //         'status_code' => 200,
    //         'message' => 'successfully get Dashboard data',
    //         'data' => $data,
    //     ], 200);
    // }
    
     public function DashboardData(Request $request)
    {
 
        // Validate the incoming data
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
        ]);
 
        if ($validator->fails()) {
            return response()->json([
                'status_code' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors(),
            ], 422);
        }
 
        $proposal = DB::table('et_proposal')
            ->where('customer_id', $request->user_id)
            ->where('status', '!=', 2)
            ->pluck('sno');
 
        $proposal_count = count($proposal);
 
        $service_count = DB::table('et_customer_services')
            ->whereIn('proposal_id', $proposal)
            ->count();
 
          $upcoming_payment = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name', 'et_transaction.payment_status')
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->leftJoin('et_payment', function ($join) {
                $join->on('et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->where('et_payment.status', 0);
            })
 
            ->leftJoin('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal)
            ->whereNotNull('et_proposal_pay_slot.nextPayDate')
            ->where('et_proposal_pay_slot.status', 0)
            ->where('et_proposal_pay_slot.paid_status', '!=', 1)
            ->orderBy('et_proposal_pay_slot.sno', 'desc')
            ->select(
                'et_proposal_pay_slot.payable_amount',
                'et_proposal_pay_slot.nextPayDate',
            'et_proposal_pay_slot.paid_status',
                'et_country_currencies.currency_code',
                'et_country_currencies.currency_symbol'
            )
            ->first();
 
        $serviceId = DB::table('et_customer_services')
            ->where('status', '!=', 2)
            ->whereIn('proposal_id', $proposal)
            ->where('journal_check', 1)
            ->pluck('sno');
 
        $submittedCount = DB::table('et_manage_journal')
            ->where('status', 0)
            ->where('customer_id', $request->user_id)
            ->whereIn('service_id', $serviceId)
            ->count();
 
        $withEditorCount = DB::table('et_manage_journal')
            ->where('status', 1)
            ->where('customer_id', $request->user_id)
            ->whereIn('service_id', $serviceId)
            ->count();
 
        $underReviewerCount = DB::table('et_manage_journal')
            ->where('status', 3)
            ->where('customer_id', $request->user_id)
            ->whereIn('service_id', $serviceId)
            ->count();
 
        $revisionCount = DB::table('et_manage_journal')
            ->where('status', 4)
            ->where('customer_id', $request->user_id)
            ->whereIn('service_id', $serviceId)
            ->count();
 
        $acceptedCount = DB::table('et_manage_journal')
            ->where('status', 5)
            ->where('customer_id', $request->user_id)
            ->whereIn('service_id', $serviceId)
            ->count();
 
        $rejectedCount = DB::table('et_manage_journal')
            ->where('status', 6)
            ->where('customer_id', $request->user_id)
            ->whereIn('service_id', $serviceId)
            ->count();
 
        $eProofingCount = DB::table('et_manage_journal')
            ->where('status', 7)
            ->where('customer_id', $request->user_id)
            ->whereIn('service_id', $serviceId)
            ->count();
 
        $publichedCount = DB::table('et_manage_journal')
            ->where('status', 8)
            ->where('customer_id', $request->user_id)
            ->whereIn('service_id', $serviceId)
            ->count();
 
        $data = [
            'proposal_count' => $proposal_count,
            'service_count' => $service_count,
            'upcoming_payment_status' => $upcoming_payment ? 1 : 0,
            'currency_symbol' => $upcoming_payment && $upcoming_payment->currency_symbol ? $upcoming_payment->currency_symbol : '',
            'paid_status' => $upcoming_payment ? $upcoming_payment->paid_status : 0,
            'upcoming_payment_amount' => $upcoming_payment ? $upcoming_payment->payable_amount : 0,
            'upcoming_payment_date' => $upcoming_payment && $upcoming_payment->nextPayDate ? date('d-M-Y', strtotime($upcoming_payment->nextPayDate)) : '',
            'submitted_count' => $submittedCount,
            'with_editor_count' => $withEditorCount,
            'under_reviewer_count' => $underReviewerCount,
            'revision_count' => $revisionCount,
            'accepted_count' => $acceptedCount,
            'rejected_count' => $rejectedCount,
            'e_proofing_count' => $eProofingCount,
            'published_count' => $publichedCount,
            'total_count' => $submittedCount + $withEditorCount + $publichedCount + $eProofingCount + $rejectedCount + $acceptedCount + $underReviewerCount + $revisionCount + $publichedCount,
        ];
 
        // Return success response
        return response()->json([
            'status' => 'success',
            'status_code' => 200,
            'message' => 'successfully get Dashboard data',
            'data' => $data,
        ], 200);
    }


    // Customer Notification
    public function CustomerNotification(Request $request)
    {
        // Validate the incoming data
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status_code' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors(),
            ], 422);
        }
        $user_id = $request->user_id;
        $notification = DB::table('et_notification_customer_app')
            ->where('whom', $user_id)
            ->where('status', '!=', 2)
            ->get();

        $notification = $notification->map(function ($row) {
            $row->message_date = date('d-M-Y', strtotime($row->message_date));

            // $row->notification_dates = date('d-M-Y', strtotime($row->notification_date));
            // $row->notification_date_time = date('d-M-Y H:i:s', strtotime($row->notification_date));
            return $row;
        });

        // Return success response
        return response()->json([
            'status' => 'success',
            'status_code' => 200,
            'message' => 'successfully get Notification data',
            'data' => $notification,
        ], 200);
    }

    public function CustomerNotificationCount(Request $request)
    {
        // Validate the incoming data
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status_code' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors(),
            ], 422);
        }
        $user_id = $request->user_id;
        $notification = DB::table('et_notification_customer_app')
            ->where('whom', $user_id)
            ->where('status', 0)
            ->count();

        // Return success response
        return response()->json([
            'status' => 'success',
            'status_code' => 200,
            'message' => 'successfully get Notification data',
            'notification_count' => $notification,
        ], 200);
    }

    public function CustomerNotificationReadAll(Request $request)
    {
        // Validate the incoming data
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status_code' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors(),
            ], 422);
        }
        $user_id = $request->user_id;

        DB::table('et_notification_customer_app')
            ->where('whom', $user_id)
            ->where('status', 0)
            ->update([
                'status' => 1,
                'updated_at' => now(),
                'updated_by' => $user_id,
            ]);

        // Return success response
        return response()->json([
            'status' => 'success',
            'status_code' => 200,
            'message' => 'Marked as seen',
        ], 200);
    }

    public function CustomerNotificationDelete(Request $request)
    {
        // Validate the incoming data
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            'notification_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status_code' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors(),
            ], 422);
        }
        $user_id = $request->user_id;
        $notification_id = $request->notification_id;

        DB::table('et_notification_customer_app')
            ->where('whom', $user_id)
            ->where('sno', $notification_id)
            ->update([
                'status' => 2,
                'updated_at' => now(),
                'updated_by' => $user_id,
            ]);

        // Return success response
        return response()->json([
            'status' => 'success',
            'status_code' => 200,
            'message' => 'Successfully Notification Deleted',
        ], 200);
    }

    /**
     * Show milestone folders page (User View)
     */
    public function MilestoneDocuments(Request $request)
    {

        // Validate the incoming data
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            'service_sno' => 'required|integer',
            'milestone_sno' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status_code' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors(),
            ], 422);
        }
        $user_id = $request->user_id;
        $mile_sno = $request->milestone_sno;
        $service_sno = $request->service_sno;

        $milestoneFolders = DB::table('et_milestone_folders')
            ->select('milestone_mapping_id', 'main_folder_id', 'folder_name', 'total_files', 'total_size')
            ->where('milestone_mapping_id', $mile_sno)
            ->first();


        function formatSize($bytes)
        {
            $units = ['B', 'KB', 'MB', 'GB', 'TB'];
            $bytes = max($bytes, 0);
            $power = floor(($bytes ? log($bytes) : 0) / log(1024));
            $power = min($power, count($units) - 1);
            $bytes /= pow(1024, $power);
            return number_format($bytes, 2) . ' ' . $units[$power];
        }
        if ($milestoneFolders) {
            $milestoneFolders->total_size = formatSize($milestoneFolders->total_size);
            $milestoneFolders->download_all_link = route('milestone.download.zip', $mile_sno);
        }

        $checklistFiles = DB::table('et_delivery_attachment_mapping')
            ->where('milestone_mapping_id', $mile_sno)
            ->get();

        $result = [];

        foreach ($checklistFiles as $checklist) {

            $uploadedFiles = json_decode($checklist->uploaded_files, true) ?: [];

            if (!empty($uploadedFiles)) {
                foreach ($uploadedFiles as $file) {

                    $file_download_file_link = route('file.download', $file['file_id']);

                    $result[$checklist->checklist_name][] = [
                        'file_id' => $file['file_id'],
                        'file_name' => $file['name'],
                        'human_size' => $file['human_size'],
                        'download_link' => $file_download_file_link,
                    ];
                }
            }
        }

        $checklistFiles = $result;


        $milestoneDetails = DB::table('et_milestone_mapping')
            ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
            ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
            ->select(
                'et_milestone_mapping.service_id',
                'et_milestone_mapping.sno',
                'et_payment_slot.payment_slot_name  AS milestone_name',
                // 'et_milestone_mapping.milestone_status',
                // 'et_milestone_mapping.task_ids',
                // 'et_proposal_pay_slot.payable_amount',
                // 'et_proposal_pay_slot.paidAmount'
            )
            ->where('et_milestone_mapping.sno', $mile_sno)
            ->where('et_milestone_mapping.status', '!=', 2)
            ->where('et_milestone_mapping.milestone_status', 1)
            ->first();



        $servicesDetails = DB::table('et_customer_services')
            ->where('et_customer_services.sno', $service_sno)
            ->where('et_customer_services.status', '!=', 2)
            // ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->select(
                // 'et_customer.cus_name',
                // 'et_customer.cus_mobile',
                // 'et_customer.customer_id',
                // 'et_customer_services.sno',
                'et_product.product_name',
                'et_product_category.product_category_name',
                'et_customer_services.variant_variable_ids'
            )
            ->first();

        if (! $servicesDetails) {
            return response()->json([
                'status' => 404,
                'message' => 'No record found!',
                'error_msg' => null,
                'services' => null,
            ], 404);
        }

        $items = json_decode($servicesDetails->variant_variable_ids, true);

        $variantName = '';
        $variableName = '';

        if (is_array($items) && count($items) > 0) {
            $first = $items[0];

            $variant = DB::table('et_manage_product_variant')
                ->where('sno', $first['variant_id'])
                ->first();

            $variable = DB::table('et_manage_product_variable')
                ->where('sno', $first['variable_id'])
                ->first();

            $variantName = $variant->product_variant_name ?? '';
            $variableName = $variable->variable_name ?? '';
        }

        $servicesDetails->variant_name = $variantName;
        $servicesDetails->variable_name = $variableName;

        // Return success response
        return response()->json([
            'status' => 'success',
            'status_code' => 200,
            'message' => 'successfully get milestone data',
            'mile_sno' => $mile_sno,
            'milestone_name' => $milestoneDetails->milestone_name ?? 'Milestone ',
            'milestoneFolders' => $milestoneFolders,
            'checklistFiles' => $checklistFiles,
            // 'milestoneDetails' => $milestoneDetails,
            'servicesDetails' => $servicesDetails,
        ], 200);
    }
}