<?php

namespace App\Http\Controllers\mobile_apps;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\Request;

class MobileAppLandingPage extends Controller
{
    public function index(Request $request)
    {
        return view('content.mobile_app.scholar_guide');
    }
}