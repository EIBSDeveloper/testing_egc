<?php

namespace App\Http\Controllers\team_management;

use App\Http\Controllers\Controller;
use App\Models\ManageTeamModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ManageTeam extends Controller
{

    public function sales_team_index (Request $request) {

        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_fill = $request->search_fill ?? '';

        $query = DB::table('et_manage_team')
            ->where('et_manage_team.team_type', 0)
            ->where('et_manage_team.status', '!=', 2)
            ->where('et_manage_team.branch_id', $branch_id)
            ->leftJoin('et_staff as tl', 'tl.sno', '=', 'et_manage_team.team_lead_id')
            ->select(
                'et_manage_team.sno',
                'et_manage_team.team_name',
                'et_manage_team.team_members_id',
                'tl.staff_name as tl_name',
                'tl.staff_image as tl_image',
                'tl.gender as tl_gender',
            )
            ->orderBy('et_manage_team.sno', 'desc');

        if ($search_fill != '') {
            $query->where(function ($list) use ($search_fill) {
                $list->where('et_manage_team.team_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('tl.staff_name', 'LIKE', "%{$search_fill}%");
            });
        } 
        
        $lists = $query->paginate($perpage);

        foreach($lists as $list) {
            $membersId = json_decode($list->team_members_id, true) ?? [];

            $list->members = DB::table('et_staff')
                ->whereIn('sno', $membersId)
                ->select('staff_name', 'staff_image', 'gender')
                ->get();
        }

        return view('content.team_management.manage_team.sales_list', [
            'lists' => $lists,
            'perpage' => $perpage,
            'search_fill' => $search_fill
        ]);
    }

    public function get_sales_tl(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $team_id = $request->input('team_id');

        $query = DB::table('et_staff')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->leftJoin('et_manage_team', 'et_manage_team.team_lead_id', '=', 'et_staff.sno')
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.status', 0)
            ->where('et_staff.role_id', 12)
            ->where('et_staff.branch_id', $branch_id);

        // Exclude TLs already assigned, except the current one when editing
        if ($team_id) {
            $current_tl = DB::table('et_manage_team')
                ->where('sno', $team_id)
                ->value('team_lead_id');

            $query->where(function($q) use ($current_tl) {
                $q->whereNull('et_manage_team.team_lead_id')
                ->orWhere('et_staff.sno', $current_tl);
            });
        } else {
            $query->whereNull('et_manage_team.team_lead_id');
        }

        $data = $query
            ->select(
                'et_staff.staff_name',
                'et_staff.sno',
                'et_job_position.job_position_name'
            )
            ->distinct()
            ->get();

        return response([
            'status' => 200,
            'message' => 'TL fetched...',
            'error_msg' => null,
            'data' => $data
        ], 200);
    }

    public function get_sales_team(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $team_id = $request->input('team_id');
        
        $allocatedStaff = DB::table('et_manage_team')
            ->where('branch_id', $branch_id)
            ->get()
            ->flatMap(function ($team) {
                $staff = json_decode($team->team_members_id, true);
                return is_array($staff) ? $staff : [];
            })
            ->unique()
            ->values()
            ->toArray();
            
        $currentTeamStaff = [];
        if ($team_id) {
            $team = DB::table('et_manage_team')
                ->where('sno', $team_id)
                ->first();

            if ($team && $team->team_members_id) {
                $currentTeamStaff = json_decode($team->team_members_id, true) ?? [];
            }
        }
        
        $query = DB::table('et_staff')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.status', 0)
            ->whereIn('et_staff.role_id', [11, 31])
            ->where('et_staff.branch_id', $branch_id);

        if ($team_id) {
            $query->where(function ($q) use ($allocatedStaff, $currentTeamStaff) {
                $exclude = array_diff($allocatedStaff, $currentTeamStaff);
                if (!empty($exclude)) {
                    $q->whereNotIn('et_staff.sno', $exclude);
                }
            });
        } else {
            if (!empty($allocatedStaff)) {
                $query->whereNotIn('et_staff.sno', $allocatedStaff);
            }
        }
        
        $data = $query
            ->select(
                'et_staff.staff_name',
                'et_staff.sno',
                'et_job_position.job_position_name'
            )
            ->get();

        return response([
            'status' => 200,
            'message' => 'Sales team fetched successfully',
            'error_msg' => null,
            'data' => $data
        ], 200);
    }

    public function create(Request $request) {
        try {
            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $team_name = $request->team_name;
            $team_lead = $request->team_lead;
            $team_staff = $request->team_staff;
            $team_type = $request->team_type;

            // Validate if team_staff is array
            if (!is_array($team_staff)) {
                return response([
                    'status' => 400,
                    'message' => 'Team staff must be an array.',
                    'error_msg' => null,
                    'data' => null
                ], 400);
            }
            
            $existing_team_name = DB::table('et_manage_team')
                ->where('team_name', $team_name)
                ->first();

            if($existing_team_name) {
                return response([
                    'status' => 302,
                    'message' => 'Team Name Already Exists.',
                    'error_msg' => null,
                    'data' => null
                ], 200);
            }
            
            $existing_tl = DB::table('et_manage_team')
                ->where('team_lead_id', $team_lead)
                ->first();

            if($existing_tl) {
                return response([
                    'status' => 302,
                    'message' => 'Team Lead Already Allocated.',
                    'error_msg' => null,
                    'data' => null
                ], 200);
            }

            // Check if team members are already allocated
            $existing_members = DB::table('et_manage_team')
                ->where(function($query) use ($team_staff) {
                    foreach ($team_staff as $staff_id) {
                        $query->orWhereJsonContains('team_members_id', $staff_id);
                    }
                })
                ->first();

            if($existing_members) {
                return response([
                    'status' => 302,
                    'message' => 'One or more team members are already allocated to another team.',
                    'error_msg' => null,
                    'data' => null
                ], 200);
            }

            // Create new team
            $create = new ManageTeamModel();
            $create->team_name = $team_name;
            $create->team_lead_id = $team_lead;
            $create->team_type = $team_type;
            $create->team_members_id = json_encode($team_staff); // Changed to json_encode
            $create->branch_id = $branch_id;
            $create->created_by = $user_id;
            $create->updated_by = $user_id;
            $create->save();

            // Return success response
            return response([
                'status' => 200,
                'message' => 'Sales Team Created Successfully!',
                'error_msg' => null,
                'data' => $create
            ], 200);

        } catch (\Exception $e) {
            return response([
                'status' => 500,
                'message' => 'Something went wrong.',
                'error_msg' => $e->getMessage(),
                'data' => null
            ], 500);
        }
    }

    public function edit_sales_team($id){
        $data = ManageTeamModel::where('sno', $id)->where('team_type', 0)->where('status', '!=', 2)->first();

        if(!$data){
            return response([
                'status' => 404,
                'message' => 'No Such Records',
                'error_msg' => 'No Such Records !',
                'data' => null
            ], 404);
        } else {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        }
    }

    public function Update(Request $request){
        try {
            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $team_name = $request->team_name;
            $team_lead = $request->team_lead;
            $team_staff = $request->team_staff;
            $sno = $request->sno;
            
            if (!is_array($team_staff)) {
                return response([
                    'status' => 400,
                    'message' => 'Team staff must be an array.',
                    'error_msg' => null,
                    'data' => null
                ], 400);
            }
            
            $existing_team_name = DB::table('et_manage_team')
                ->where('team_name', $team_name)
                ->where('sno', '!=', $sno)
                ->first();

            if($existing_team_name) {
                return response([
                    'status' => 302,
                    'message' => 'Team Name Already Exists.',
                    'error_msg' => null,
                    'data' => null
                ], 200);
            }
            
            $existing_tl = DB::table('et_manage_team')
                ->where('team_lead_id', $team_lead)
                ->where('sno', '!=', $sno)
                ->first();

            if($existing_tl) {
                return response([
                    'status' => 302,
                    'message' => 'Team Lead Already Allocated.',
                    'error_msg' => null,
                    'data' => null
                ], 200);
            }
            
            $existing_members = DB::table('et_manage_team')
                ->where(function($query) use ($team_staff) {
                    foreach ($team_staff as $staff_id) {
                        $query->orWhereJsonContains('team_members_id', $staff_id);
                    }
                })
                ->where('sno', '!=', $sno)
                ->first();

            if($existing_members) {
                return response([
                    'status' => 302,
                    'message' => 'One or more team members are already allocated to another team.',
                    'error_msg' => null,
                    'data' => null
                ], 200);
            }

            // Create new team
            $create = ManageTeamModel::where('status', '!=', 2)->where('sno', $sno)->first();
            $create->team_name = $team_name;
            $create->team_lead_id = $team_lead;
            $create->team_members_id = json_encode($team_staff); // Changed to json_encode
            $create->branch_id = $branch_id;
            $create->updated_by = $user_id;
            $create->update();

            // Return success response
            return response([
                'status' => 200,
                'message' => 'Sales Team Updated Successfully!',
                'error_msg' => null,
                'data' => $create
            ], 200);

        } catch (\Exception $e) {
            return response([
                'status' => 500,
                'message' => 'Something went wrong.',
                'error_msg' => $e->getMessage(),
                'data' => null
            ], 500);
        }
    }
    
    public function production_team_index (Request $request) {

        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_fill = $request->search_fill ?? '';

        $query = DB::table('et_manage_team')
            ->where('et_manage_team.team_type', 1)
            ->where('et_manage_team.status', '!=', 2)
            ->where('et_manage_team.branch_id', $branch_id)
            ->leftJoin('et_staff as tl', 'tl.sno', '=', 'et_manage_team.team_lead_id')
            ->select(
                'et_manage_team.sno',
                'et_manage_team.team_name',
                'et_manage_team.team_members_id',
                'tl.staff_name as tl_name',
                'tl.staff_image as tl_image',
                'tl.gender as tl_gender',
            )
            ->orderBy('et_manage_team.sno', 'desc');

        if ($search_fill != '') {
            $query->where(function ($list) use ($search_fill) {
                $list->where('et_manage_team.team_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('tl.staff_name', 'LIKE', "%{$search_fill}%");
            });
        } 
        
        $lists = $query->paginate($perpage);

        foreach($lists as $list) {
            $membersId = json_decode($list->team_members_id, true) ?? [];

            $list->members = DB::table('et_staff')
                ->whereIn('sno', $membersId)
                ->select('staff_name', 'staff_image', 'gender')
                ->get();
        }

        return view('content.team_management.manage_team.production_list', [
            'lists' => $lists,
            'perpage' => $perpage,
            'search_fill' => $search_fill
        ]);
    }

    public function get_production_tl(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $team_id = $request->input('team_id');

        $query = DB::table('et_staff')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->leftJoin('et_manage_team', 'et_manage_team.team_lead_id', '=', 'et_staff.sno')
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.status', 0)
            ->where('et_staff.role_id', 15)
            ->where('et_staff.branch_id', $branch_id);

        // Exclude TLs already assigned, except the current one when editing
        if ($team_id) {
            $current_tl = DB::table('et_manage_team')
                ->where('sno', $team_id)
                ->value('team_lead_id');

            $query->where(function($q) use ($current_tl) {
                $q->whereNull('et_manage_team.team_lead_id')
                ->orWhere('et_staff.sno', $current_tl);
            });
        } else {
            $query->whereNull('et_manage_team.team_lead_id');
        }

        $data = $query
            ->select(
                'et_staff.staff_name',
                'et_staff.sno',
                'et_job_position.job_position_name'
            )
            ->distinct()
            ->get();

        return response([
            'status' => 200,
            'message' => 'TL fetched...',
            'error_msg' => null,
            'data' => $data
        ], 200);
    }

    public function get_production_team(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $team_id = $request->input('team_id');
        
        $allocatedStaff = DB::table('et_manage_team')
            ->where('branch_id', $branch_id)
            ->get()
            ->flatMap(function ($team) {
                $staff = json_decode($team->team_members_id, true);
                return is_array($staff) ? $staff : [];
            })
            ->unique()
            ->values()
            ->toArray();
            
        $currentTeamStaff = [];
        if ($team_id) {
            $team = DB::table('et_manage_team')
                ->where('sno', $team_id)
                ->first();

            if ($team && $team->team_members_id) {
                $currentTeamStaff = json_decode($team->team_members_id, true) ?? [];
            }
        }
        
        $query = DB::table('et_staff')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.status', 0)
            ->whereIn('et_staff.role_id', [32, 36])
            ->where('et_staff.branch_id', $branch_id);

        if ($team_id) {
            $query->where(function ($q) use ($allocatedStaff, $currentTeamStaff) {
                $exclude = array_diff($allocatedStaff, $currentTeamStaff);
                if (!empty($exclude)) {
                    $q->whereNotIn('et_staff.sno', $exclude);
                }
            });
        } else {
            if (!empty($allocatedStaff)) {
                $query->whereNotIn('et_staff.sno', $allocatedStaff);
            }
        }
        
        $data = $query
            ->select(
                'et_staff.staff_name',
                'et_staff.sno',
                'et_job_position.job_position_name'
            )
            ->get();

        return response([
            'status' => 200,
            'message' => 'Sales team fetched successfully',
            'error_msg' => null,
            'data' => $data
        ], 200);
    }

    public function edit_production_team($id){
        $data = ManageTeamModel::where('sno', $id)->where('team_type', 1)->where('status', '!=', 2)->first();

        if(!$data){
            return response([
                'status' => 404,
                'message' => 'No Such Records',
                'error_msg' => 'No Such Records !',
                'data' => null
            ], 404);
        } else {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        }
    }

    public function journal_team_index (Request $request) {

        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_fill = $request->search_fill ?? '';

        $query = DB::table('et_manage_team')
            ->where('et_manage_team.team_type', 2)
            ->where('et_manage_team.status', '!=', 2)
            ->where('et_manage_team.branch_id', $branch_id)
            ->leftJoin('et_staff as tl', 'tl.sno', '=', 'et_manage_team.team_lead_id')
            ->select(
                'et_manage_team.sno',
                'et_manage_team.team_name',
                'et_manage_team.team_members_id',
                'tl.staff_name as tl_name',
                'tl.staff_image as tl_image',
                'tl.gender as tl_gender',
            )
            ->orderBy('et_manage_team.sno', 'desc');

        if ($search_fill != '') {
            $query->where(function ($list) use ($search_fill) {
                $list->where('et_manage_team.team_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('tl.staff_name', 'LIKE', "%{$search_fill}%");
            });
        } 
        
        $lists = $query->paginate($perpage);

        foreach($lists as $list) {
            $membersId = json_decode($list->team_members_id, true) ?? [];

            $list->members = DB::table('et_staff')
                ->whereIn('sno', $membersId)
                ->select('staff_name', 'staff_image', 'gender')
                ->get();
        }

        return view('content.team_management.manage_team.journal_list', [
            'lists' => $lists,
            'perpage' => $perpage,
            'search_fill' => $search_fill
        ]);
    }

    public function get_journal_tl(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $team_id = $request->input('team_id');

        $query = DB::table('et_staff')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->leftJoin('et_manage_team', 'et_manage_team.team_lead_id', '=', 'et_staff.sno')
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.status', 0)
            ->where('et_staff.role_id', 33)
            ->where('et_staff.branch_id', $branch_id);

        // Exclude TLs already assigned, except the current one when editing
        if ($team_id) {
            $current_tl = DB::table('et_manage_team')
                ->where('sno', $team_id)
                ->value('team_lead_id');

            $query->where(function($q) use ($current_tl) {
                $q->whereNull('et_manage_team.team_lead_id')
                ->orWhere('et_staff.sno', $current_tl);
            });
        } else {
            $query->whereNull('et_manage_team.team_lead_id');
        }

        $data = $query
            ->select(
                'et_staff.staff_name',
                'et_staff.sno',
                'et_job_position.job_position_name'
            )
            ->distinct()
            ->get();

        return response([
            'status' => 200,
            'message' => 'TL fetched...',
            'error_msg' => null,
            'data' => $data
        ], 200);
    }

    public function get_journal_team(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $team_id = $request->input('team_id');
        
        $allocatedStaff = DB::table('et_manage_team')
            ->where('branch_id', $branch_id)
            ->get()
            ->flatMap(function ($team) {
                $staff = json_decode($team->team_members_id, true);
                return is_array($staff) ? $staff : [];
            })
            ->unique()
            ->values()
            ->toArray();
            
        $currentTeamStaff = [];
        if ($team_id) {
            $team = DB::table('et_manage_team')
                ->where('sno', $team_id)
                ->first();

            if ($team && $team->team_members_id) {
                $currentTeamStaff = json_decode($team->team_members_id, true) ?? [];
            }
        }
        
        $query = DB::table('et_staff')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.status', 0)
            ->where('et_staff.role_id', 34)
            ->where('et_staff.branch_id', $branch_id);

        if ($team_id) {
            $query->where(function ($q) use ($allocatedStaff, $currentTeamStaff) {
                $exclude = array_diff($allocatedStaff, $currentTeamStaff);
                if (!empty($exclude)) {
                    $q->whereNotIn('et_staff.sno', $exclude);
                }
            });
        } else {
            if (!empty($allocatedStaff)) {
                $query->whereNotIn('et_staff.sno', $allocatedStaff);
            }
        }
        
        $data = $query
            ->select(
                'et_staff.staff_name',
                'et_staff.sno',
                'et_job_position.job_position_name'
            )
            ->get();

        return response([
            'status' => 200,
            'message' => 'Sales team fetched successfully',
            'error_msg' => null,
            'data' => $data
        ], 200);
    }

    public function edit_journal_team($id){
        $data = ManageTeamModel::where('sno', $id)->where('team_type', 2)->where('status', '!=', 2)->first();

        if(!$data){
            return response([
                'status' => 404,
                'message' => 'No Such Records',
                'error_msg' => 'No Such Records !',
                'data' => null
            ], 404);
        } else {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        }
    }
}
