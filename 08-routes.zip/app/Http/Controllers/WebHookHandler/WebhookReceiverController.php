<?php
namespace App\Http\Controllers\WebHookHandler;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\NewsBroadcastModel; // sub-epr model (set primaryKey sno)
use App\Models\DepartmentModel; 
use App\Models\DivisionModel; 
use App\Models\JobpositionModel; 
use App\Models\StaffModel; 
use App\Models\StaffAttendanceModel;
use App\Models\User; 
use App\Models\StaffWorkInfoModel; 
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\UserRolePermissionModel;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\IncentiveModel;
use App\Models\CustomerModel;
use App\Models\BranchModel;


class WebhookReceiverController extends Controller
{

   public function broadcastMessage(Request $request)
        {
           
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }
 
                // Log the decoded payload
                \Log::info('Decoded Payload:', $payload);
 
                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }
               
            $updateBroadcast = NewsBroadcastModel::updateOrCreate(
                ['external_uuid' => $payload['sno']],
                [
 
                    'template_name' => $payload['template_name'] ?? NULL,
                    'broadcast_message' => $payload['broadcast_message'] ?? NULL,
                    'branch_id' => $payload['branch_id'] ?? NULL,
                    'role_ids' => $payload['role_ids'] ?? NULL,
                    'start_date' => $payload['start_date'] ?? NULL,
                    'end_date' => $payload['end_date'] ?? NULL,
                    'information' => $payload['information'] ?? NULL,
                    'theme_id' => $payload['theme_id'] ?? 0,
                    'theme_style' => $payload['theme_style'] ?? NULL,
                    'created_by' => $request->user()->user_id ?? 0,
                    'updated_by' => $request->user()->user_id ?? 0,
                ]
            );
 
           
 
            return response()->json([
                'ok' => true,
                'sno' => $updateBroadcast->sno,
            ], 200);
        }
    
   
    
    // Deparment Webhook Start
    public function DepartmentList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
       $departmentList=DB::table('et_department')
       ->select('et_department.*')
       ->where('et_department.entity_id',1)
       ->where('et_department.status',0)
       ->get();
       $lastId = DB::table('et_department')
        ->orderBy('sno', 'desc')   
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1; 
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

    public function DepartmentHook(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $department = DepartmentModel::updateOrCreate(
            ['external_uuid' => $uuid],  
            [
                'department_id'    => $payload['department_id'] ?? null,
                'entity_id'        => 1,
                'branch_id'        =>  1,
                'department_name'  => $payload['department_name'],
                'department_desc'  => $payload['department_desc'] ?? null,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );

        return response()->json([
            'ok'  => true,
            'sno' => $department->sno,
            'uuid' => $uuid,
        ], 200);
    }

    public function UpdateDepartmentUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_department_id'];
        if($erpId){
            $department = DepartmentModel::where('sno', $erpId)->first();

            if ($department) {
                $department->external_uuid = $uuid;
                $department->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'department Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'department id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }
    
    // Deparment Webhook End


    
     // Division Webhook Start
    public function DivisionList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
        
        $depart_id = $request->department_id;
        // return $depart_id;
       $departmentList=DB::table('et_division')
       ->select('et_division.*');
       if($depart_id){
         $departmentList->where('et_division.department_id',$depart_id);
       }
       
       $departmentList=$departmentList->where('et_division.status',0)
       ->get();
       $lastId = DB::table('et_division')
        ->orderBy('sno', 'desc')   
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1; 
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

     public function DivisionHook(Request $request)
    {
        // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();

         $payload = $request->all();

        $department = DivisionModel::updateOrCreate(
            ['external_uuid' => $uuid],  // ✅ match by UUID, not ERP id
            [
                'department_id'    => $payload['erp_department_id'], 
                'entity_id'        => 1,
                'branch_id'        => 1,
                'division_name'  => $payload['division_name'],
                'division_desc'  => $payload['division_desc'] ?? null,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );
    
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }

     public function UpdateDivisionUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_division_id'];
        if($erpId){
            $division = DivisionModel::where('sno', $erpId)->first();

            if ($division) {
                $division->external_uuid = $uuid;
                $division->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'Division Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'Division id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $division->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }

     // Division Webhook End

    // Job Position Webhook Start
    public function JobPostionList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
        
        $division_id = $request->division_id;
        // return $depart_id;
       $departmentList=DB::table('et_job_position')
       ->select('et_job_position.*');
       if($division_id){
         $departmentList->where('et_job_position.division_id',$division_id);
       }
       $departmentList=$departmentList->where('et_job_position.status',0)
       ->get();
       $lastId = DB::table('et_job_position')
        ->orderBy('sno', 'desc')   
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1; 
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

    public function JobPositionHook(Request $request)
    {
        // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();

         $payload = $request->all();
         
         $category_check = JobpositionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
    
              $year = substr(date("y"), -2);
              $job_position_id = "JP-0001/" . $year;
            } else {
    
              $data = $category_check->job_position_id;
              $slice = explode("/", $data);
              $result = preg_replace('/[^0-9]/', '', $slice[0]);
    
              $next_number = (int) $result + 1;
              $request = sprintf("JP-%04d", $next_number);
    
              $year = substr(date("y"), -2);
              $job_position_id = $request . '/' . $year;
            }

        $department = JobpositionModel::updateOrCreate(
            ['external_uuid' => $uuid],  // ✅ match by UUID, not ERP id
            [
                'job_position_id'    => $job_position_id, 
                'department_id'    => $payload['erp_department_id'], 
                'division_id'    => $payload['erp_division_id'], 
                'branch_id'        => 1,
                'job_position_name'  => $payload['job_position_name'],
                'job_position_desc'  => $payload['job_position_desc'] ?? null,
                'per_hour_cost'  => $payload['per_hour_cost'] ?? 0,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );
    
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }
    public function UpdateJobPositionUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_job_role_id'];
        if($erpId){
            $jobPosition = JobpositionModel::where('sno', $erpId)->first();

            if ($jobPosition) {
                $jobPosition->external_uuid = $uuid;
                $jobPosition->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'Job Position Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'Job Position id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $jobPosition->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }

    // Job Position Webhook End

    

    // UserRole Webhook Start
    public function userRoleList(Request $request)
    {
        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }

        $departmentList = DB::table('et_user_role')
            ->select('et_user_role.*')
            ->where('et_user_role.entity_id', 1)
            ->where('et_user_role.status', 0)
            ->get();

        $lastId = DB::table('et_user_role')
            ->orderBy('sno', 'desc')
            ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1;

        return response()->json([
            'status' => 200,
            'data' => $departmentList,
            'nextId' => $nextId
        ], 200);
    }

    public function UpdateUserRoleUUID(Request $request)
    {
        // Get UUID (idempotency key or generate a new UUID if not provided)
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        // Get the erp_role_id from the payload
        $erpId = $payload['erp_role_id'] ?? null;

        if ($erpId) {
            // Find the user role by erp_role_id
            $userRole = DB::table('et_user_role')->where('sno', $erpId)->first();

            if ($userRole) {
                // Update the external_uuid for the found user role
                DB::table('et_user_role')
                    ->where('sno', $erpId)
                    ->update(['external_uuid' => $uuid]);

                return response()->json([
                    'ok' => true,
                    'sno' => $userRole->sno,
                    'message' => 'External UUID updated successfully',
                    'uuid' => $uuid,
                ], 200);
            } else {
                // If user role is not found
                return response()->json([
                    'ok' => false,
                    'message' => 'User Role not found',
                    'uuid' => $uuid,
                ], 200); // Use 404 for not found error
            }
        } else {
            // If erp_role_id is not provided
            return response()->json([
                'ok' => false,
                'message' => 'User Role ID not provided',
                'uuid' => $uuid,
            ], 200); // Use 400 for bad request error
        }
    }
    // UserRole Webhook End
  
    // Staff Webhook Start 

        public function StaffData(Request $request){

            $auth_key = $request->auth_key;
            $verify_key = 'egcsecret2030datagetapierp';

            if ($auth_key !== $verify_key) {
                return response()->json([
                    'status' => 410,
                    'data' => null,
                    'message' => 'Unauthorized Entry'
                ], 410);
            }

            $staffdata=DB::table('et_staff')
                ->select('et_staff.*','et_department.department_name','et_division.division_name','et_user_role.role_name')
                ->where('et_staff.branch_id',1)
                ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
                ->join('et_division', 'et_division.sno', '=', 'et_staff.sub_department_id')
                ->join('et_user_role', 'et_user_role.sno', '=', 'et_staff.role_id')
                ->where('et_staff.status',0)
                ->where('et_staff.sno','>',1)
                ->where('et_staff.department_id','!=',10)
                ->get();
            
            foreach($staffdata as $staff){
                if($staff->staff_image){
                    $staff->staff_image= url('staff_images/' . $staff->staff_image);
                }else{
                    $staff->staff_image='';
                }
                $staff->staff_work_info=[];
                if($staff->exp_type == 2){
                    $WorkDetails = StaffWorkInfoModel::where('staff_id', $staff->sno)->where('status',0)
                            ->get();
                    $staff->staff_work_info = $WorkDetails ?? [];
                }
                
            }
            
            return response()->json(['status' => 200, 'data' => $staffdata], 200);
        }
    
        public function StaffAddHook(Request $request)
        {
            
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }

                // Log the decoded payload
                \Log::info('Decoded Payload:', $payload);

                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }

                // Check if mobile number exists
                if (empty($payload['mobile_no'])) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile number is missing'
                    ], 400);
                }

                $existingExternalStaff = StaffModel::where('external_uuid', $uuid)->first();

                if ($existingExternalStaff) {
                    $existingExternalStaff->status = 0;
                    $existingExternalStaff->update();
                    return response()->json([
                        'ok' => true,
                        'message' => 'Staff already exists'
                    ], 200);
                }

                // Check if mobile number already exists
                $existingStaff = StaffModel::where('mobile_no', $payload['mobile_no'])->first();

                
                if ($existingStaff) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile Number already exists'
                    ], 200);
                }


                


                // Handle staff image upload (if any)
                $staff_image_url = $payload['staff_image'] ?? null;
                $staff_image = null;

                if ($staff_image_url) {
                    $ext = pathinfo(parse_url($staff_image_url, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'jpg';
                    $folderPath = public_path("staff_images");

                    // Create directory if it doesn't exist
                    if (!File::exists($folderPath)) {
                        File::makeDirectory($folderPath, 0777, true, true);
                    }

                    // Find the next available image number
                    $existingFiles = File::files($folderPath);
                    $maxNumber = 0;
                    foreach ($existingFiles as $file) {
                        if (preg_match('/staff_image_(\d+)\./', $file->getFilename(), $matches)) {
                            $num = (int) $matches[1];
                            if ($num > $maxNumber) $maxNumber = $num;
                        }
                    }
                    $nextNumber = $maxNumber + 1;
                    $staff_image_name = "staff_image_{$nextNumber}.{$ext}";
                    $savePath = $folderPath . '/' . $staff_image_name;

                    // Save image
                    try {
                        $imageData = @file_get_contents($staff_image_url);
                        if ($imageData !== false) {
                            file_put_contents($savePath, $imageData);
                            $staff_image = $staff_image_name;
                        }
                    } catch (\Exception $e) {
                        $staff_image = null;
                    }
                }

            // Create or update staff record based on UUID
            $add_staff = StaffModel::updateOrCreate(
                ['external_uuid' => $uuid],
                [
                    'staff_id' => $payload['staff_id'],
                    'branch_id' => 1,
                    'entity_id' => 1,
                    'shift_time_id' => 1,
                    'multi_branch_access' => null,
                    'sub_department_id' => $payload['sub_department_id'] ?? 0,
                    'department_id' => $payload['department_id'] ?? 0,
                    'role_id' => $payload['role_id'],
                    'exp_type' => $payload['exp_type'],
                    'staff_name' => $payload['staff_name'],
                    'mobile_no' => $payload['mobile_no'],
                    'alternative_no' => $payload['alternative_no'] ?? null,
                    'email_id' => $payload['email_id'],
                    'gender' => $payload['gender'],
                    'dob' => $payload['dob'],
                    'date_of_joining' => $payload['date_of_joining'],
                    'contact_person_name' => $payload['contact_person_name'] ?? null,
                    'contact_person_no' => $payload['contact_person_no'] ?? null,
                    'martial_status' => $payload['martial_status'],
                    'address' => $payload['address'] ?? null,
                    'staff_image' => $staff_image ?? null,
                    'attachment' => !empty($payload['attachment'])? json_encode($payload['attachment']): null,
                    'nick_name' => $payload['nick_name'] ?? null,
                    'position_role' => $payload['position_role'] ?? null,
                    'description' => $payload['description'] ?? null,
                    'basic_salary' => $payload['basic_salary'] ?? null,
                    'per_hour_cost' => $payload['per_hour_cost'] ?? null,
                    'login_access' => $payload['login_access'] ?? 0,
                    'employee_skill_id' => 1, // Default value for now
                    'user_name' => $payload['user_name'],
                    'password' => $payload['password'],
                    'created_by' => $request->user()->user_id ?? 1,
                    'updated_by' => $request->user()->user_id ?? 1,
                ]
            );

            if ($add_staff) {
                // Create user credentials if not exists
                $existingUser = User::where('user_id', $add_staff->sno)->first();
                if (!$existingUser) {
                    if($payload['login_access'] == 1){
                    User::create([
                        'user_id' => $add_staff->sno,
                        'role_id' => $add_staff->role_id ?? 0,
                        'branch_id' => $add_staff->branch_id,
                        'entity_id' => $add_staff->entity_id,
                        'name' => $add_staff->user_name,
                        'password' => Hash::make($add_staff->password),
                        'email' => $add_staff->email_id,
                        'created_by' => $request->user()->user_id ?? 1,
                        'updated_by' => $request->user()->user_id ?? 1,
                    ]);
                    }
                }

                // Handle work experience (if applicable)
                if ($payload['exp_type'] == 2 && !empty($payload['work_company_name'])) {
                    foreach ($payload['work_company_name'] as $key => $company) {
                        // Avoid duplicate work entries for same staff
                        $existingWork = StaffWorkInfoModel::where('staff_id', $add_staff->sno)
                            ->where('company_name', $company)
                            ->where('position', $payload['work_position'][$key] ?? '')
                            ->first();

                        if (!$existingWork) {
                            StaffWorkInfoModel::create([
                                'staff_id' => $add_staff->sno,
                                'staff_type' => $payload['exp_type'],
                                'position' => $payload['work_position'][$key] ?? null,
                                'year_of_experience' => $payload['work_exp_yrs'][$key] ?? 0,
                                'company_name' => $company,
                                'work_start_date' => isset($payload['work_st_date'][$key]) ? date('Y-m-d', strtotime($payload['work_st_date'][$key])) : null,
                                'work_end_date' => isset($payload['work_end_date'][$key]) ? date('Y-m-d', strtotime($payload['work_end_date'][$key])) : null,
                                'created_by' => $request->user()->user_id ?? 1,
                                'updated_by' => $request->user()->user_id ?? 1,
                            ]);
                        }
                    }
                }
            }

            return response()->json([
                'ok' => true,
                'sno' => $add_staff->sno,
            ], 200);
        }

        public function UpdateStaffUUID(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY') 
                ?? $request->input('uuid') 
                ?? (string) Str::uuid();

            $payload = $request->all();

            $erpId = $payload['erp_staff_id'];
            if($erpId){
                $staff = StaffModel::where('sno', $erpId)->first();

                if ($staff) {
                    $staff->external_uuid = $uuid;
                    $staff->save();
                }else{
                    return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff Not Found',
                    'uuid' => $uuid,
                ], 200);
                }
            }else{
                return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff id Not Found',
                    'uuid' => $uuid,
                ], 200);
            }
            return response()->json([
                'ok'  => true,
                'sno' => $staff->sno,
                'meassage'=>'external uuid updated',
                'uuid' => $uuid,
            ], 200);
        }
     


    // Staff Webhook End 

     // Staff Attendance Webhook Start
        public function StaffAddAttendanceHook(Request $request)
        {
            
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }


                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }
                $staffData = StaffModel::where('external_uuid', $payload['staff_id'])
                             ->first();
                
                 $alreadyExists = StaffAttendanceModel::where([
                    ['staff_id', '=', $staffData->sno],
                    ['date', '=', $payload['date']],
                    ['status', '!=', 2], 
                ])->first();
            $year = date("Y");
            $month = date("m");
            if ($alreadyExists) {
                $alreadyExists->attendance = $payload['attendance'];
                $alreadyExists->time_start = $payload['time_start'] ?? null;
                $alreadyExists->time_end = $payload['time_end'] ?? null;
                $alreadyExists->reason = $payload['reason'] ?? null;
                $alreadyExists->external_uuid = $uuid ;
                $alreadyExists->update();
                $addStaff=$alreadyExists;
            }else{
                // Generate a new staff attendance ID
                    $category_check = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                    $staff_attendance_id = $this->generateStaffAttendanceId($category_check, $year, $month);

                    // Save new attendance record
                $addStaff= StaffAttendanceModel::updateOrCreate(
                        ['external_uuid' => $uuid],
                        [
                        'staff_attendance_id' => $staff_attendance_id,
                        'branch_id'           => $staffData->branch_id ?? 1,
                        'staff_id'            => $staffData->sno,
                        'date'                => $payload['date'],
                        'attendance'          => $payload['attendance'],
                        'type'                => $payload['type'] ?? null,
                        'time_start'          => $payload['time_start'] ?? null,
                        'time_end'            => $payload['time_end'] ?? null,
                        'reason'              => $payload['reason'] ?? null,
                        'created_by'          => 0,
                        'updated_by'          => 0,
                        ]
                );
            }  

            return response()->json([
                'ok' => true,
                'sno' => $addStaff->sno,
            ], 200);
        }

        public function StaffAddAttendanceHookEssl(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY')
                ?? $request->input('batch_uuid')
                ?? (string) Str::uuid();
 
           $rawContent = $request->getContent();

                $payload = json_decode($rawContent, true);

                // If double encoded JSON string
                if (is_string($payload)) {
                    $payload = json_decode($payload, true);
                }

                // Final fallback
                if (!$payload || !is_array($payload)) {
                    $payload = $request->all();
                }

            if (empty($payload['records']) || !is_array($payload['records'])) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Attendance records required',
                    "data" => $payload ?? "-"
                ], 400);
            }


 
            DB::beginTransaction();
 
            try {
 
                foreach ($payload['records'] as $record) {
 
                    $staffData = StaffModel::where('external_uuid', $record['staff_id'])->first();
 
                    if (!$staffData) {
                        continue; // skip if staff not found
                    }
 
                    $alreadyExists = StaffAttendanceModel::where([
                        ['staff_id', '=', $staffData->sno],
                        ['date', '=', $record['date']],
                        ['status', '!=', 2],
                    ])->first();
 
                    if ($alreadyExists) {
 
                        if (in_array($alreadyExists, ['OD', 'PR', 'L','P'])) {
                                $alreadyExists->update([
                                    'in_time'    => $record['in_time'] ?? null,
                                    'out_time'   => $record['out_time'] ?? null,
                                ]);
                        }else{
                            $alreadyExists->update([
                                'attendance' => $record['attendance'],
                                'in_time'    => $record['in_time'] ?? null,
                                'out_time'   => $record['out_time'] ?? null,
                                'reason'     => $record['reason'] ?? null,
                                'external_uuid' => $record['sno'],
                            ]);
                        }
 
                    } else {
 
                        $category_check = StaffAttendanceModel::where('status','!=',2)
                            ->orderBy('sno','desc')
                            ->first();
 
                        $staff_attendance_id = $this->generateStaffAttendanceId(
                            $category_check,
                            date("m"),
                            date("Y")
                        );
 
                        StaffAttendanceModel::create([
                            'staff_attendance_id' => $staff_attendance_id,
                            'branch_id'           => $staffData->branch_id ?? 1,
                            'staff_id'            => $staffData->sno,
                            'date'                => $record['date'],
                            'attendance'          => $record['attendance'],
                            'in_time'             => $record['in_time'] ?? null,
                            'out_time'            => $record['out_time'] ?? null,
                            'reason'              => $record['reason'] ?? null,
                            'external_uuid'       => $record['sno'],
                            'created_by'          => 0,
                            'updated_by'          => 0,
                        ]);
                    }
                }
 
                DB::commit();
 
                return response()->json([
                    'ok' => true,
                    'message' => 'Attendance processed successfully'
                ], 200);
 
            } catch (\Throwable $e) {
 
                DB::rollBack();
 
                return response()->json([
                    'ok' => false,
                    'message' => $e->getMessage()
                ], 500);
            }
        }
        
        private function generateStaffAttendanceId($category_check, $month, $year)
        {
            if (!$category_check) {
                return 'ATT0001/' . $month . '/' . $year;
            }

            // Extract the current staff attendance ID (e.g., "ATT0001/11/2025")
            $data = $category_check->staff_attendance_id;
            $slice = explode("/", $data);

            // Extract the numeric part of the attendance ID (e.g., 0001 from "ATT0001")
            $resultcus = preg_replace('/[^0-9]/', '', $slice[0]);
            $next_number = (int)$resultcus + 1;

            // Return the formatted ID (e.g., "ATT0002/11/2025")
            return 'ATT' . sprintf("%04d", $next_number) . '/' . $month . '/' . $year;
        }
    // Staff Attendance Webhook End

// user Credential Check Api
    public function userCrendentialCheck(Request $request)
    {
       
        $validator = Validator::make($request->all(), [
        'name' => 'required|max:255',
        'password' => 'required|min:4',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
        $user = User::select('users.*', 'et_staff.status as staff_status')
        ->where('users.name', $request->name)
        ->leftJoin('et_staff', 'users.user_id', '=', 'et_staff.sno')
        ->leftJoin('et_branch', 'users.branch_id', '=', 'et_branch.sno')
        // ->where('et_staff.status', 0)
        ->where('et_branch.status', 0)
        ->first();
        
        if (!$user) {
            return response()->json([
                'type' => 'error',
                'message' => 'User not found.'
            ]);
        }

        if ($user->staff_status == 1) {

            return response()->json([
                'type' => 'error',
                'message' => 'This user is inactive. Please contact the administrator.'
            ], 200);

        } elseif ($user->staff_status == 2) {
            return response()->json([
                'type' => 'error',
                'message' => 'This user is deactivated. Please contact the administrator.'
            ], 200);
        }
        if ($user->name !== $request->name) {
            return response()->json([
                'type' => 'error',
                'message' => 'Username is case-sensitive. Please enter the correct case.'
            ], 200);
        }

        // if (!Hash::check($request->password, $user->password)) {
        //     return response()->json([
        //         'type' => 'error',
        //         'message' => 'Invalid credentials'
        //     ], 200);
        // }

        $permissions = UserRolePermissionModel::where('role_id', $user->role_id)->where('status', 0)->first();
    
        if (!$permissions) {
            return response()->json([
                'type' => 'error',
                'message' => 'Role Permission Not Set in EAPL ERP'
            ], 200);
        }

        return response()->json([
        'type' => 'Success',
        'message' => 'User Found'
        ], 200);
        
    }


      public function updateTargets(Request $request)
    {
        DB::beginTransaction();

        try {

            //  Idempotency
            $uuid = $request->header('X-IDEMPOTENCY-KEY') 
                ?? $request->input('uuid') 
                ?? (string) \Str::uuid();

            $payload = $request->all();

            // Handle string payload
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);
            }

            \Log::info('Decoded Payload:', $payload);

            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }

            $targets = $payload['targets'] ?? [];

            foreach ($targets as $target) {

                DB::table('branch_target')->updateOrInsert(
                    [
                        'branch_id' => $target['branch_id'],
                        'date'      => $target['date'],
                    ],
                    [
                        'quarter' => $target['quarter'],
                        'no_of_registrations' => $target['pre_sale'],
                        'post_sale' => $target['post_sale'],
                        'monthly_target' => $target['monthly_target'],
                        'updated_by' => 1,
                        'created_by' => 1,
                        'updated_at' => now(),
                    ]
                );

                $targetId = DB::table('branch_target')
                    ->where('branch_id', $target['branch_id'])
                    ->where('date', $target['date'])
                    ->value('sno');

                foreach ($target['weeks'] as $week) {

                    // [$startDay, $endDay] = $this->getWeekRange($week['week'], $target['date']);

                    DB::table('et_weekly_metrics')->updateOrInsert(
                        [
                            'target_id' => $targetId,
                            'week_name' => 'Week ' . $week['week'],
                        ],
                        [
                            'start_day' => \Carbon\Carbon::parse($week['start_day'])->format('d'),
                            'end_day'   => \Carbon\Carbon::parse($week['end_day'])->format('d'),
                            'percentage' => $week['percentage'],
                            'target_amount' => $week['target_amount'],
                            'pre_sale' => $week['pre_sale'],
                            'post_sale' => $week['post_sale'],
                            'updated_by' => 1,
                            'created_by' => 1,
                            'updated_at' => now(),
                        ]
                    );
                }
            }
            DB::commit();

            return response()->json([
                'ok' => true,
                'message' => 'Target synced successfully'
            ], 200);

        } catch (\Exception $e) {

            DB::rollBack();

            \Log::error('Target Sync Failed: ' . $e->getMessage());

            return response()->json([
                'ok' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    //  public function getAchieveData(Request $request)
    // {
    //     try {

    //         $verify_key = 'egcsecret2030datagetapierp';

    //         if ($request->verify_key !== $verify_key) {
    //             return response()->json([
    //                 'status' => false,
    //                 'message' => 'Unauthorized'
    //             ], 401);
    //         }

    //         $branchId = $request->branch_id;
    //         $date = $request->date ? date('Y-m-d',strtotime($request->date)) : date('Y-m-d');

    //         //  SALES AMOUNT
    //         $amount = DB::table('et_transaction')->where('branch_id', $branchId)
    //             ->whereDate('transaction_date', $date)
    //             ->where('payment_status',1)
    //             ->sum('total_amount_inr');

    //         //  PRESALE
    //         $preSale = DB::table('et_customer')
    //             ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //             ->join('et_payment', function($join) {
    //                 $join->on('et_payment.customer_id', '=', 'et_customer.sno')
    //                      ->whereRaw('et_payment.transaction_date = (
    //                          SELECT MIN(ep.transaction_date)
    //                          FROM et_payment ep
    //                          WHERE ep.customer_id = et_customer.sno
    //                      )');
    //             })
    //             ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //             ->where('et_customer.status', 0)
    //              ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
    //              ->where('et_proposal.post_sale_check', 0)
    //             ->where('et_customer.branch_id', $branchId)
    //             ->where('et_lead.created_by','>',1)
    //             ->whereDate('et_payment.transaction_date', $date)
    //             ->where('et_transaction.payment_status', 1)
    //             ->orderBy('et_customer.sno', 'asc')
    //             ->count();
    //         // return  $branchId ;

    //         //  POSTSALE
    //         $postSale = DB::table('et_customer')
    //         ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //         ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
    //         ->join('et_payment', function($join) {
    //             $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
    //                  ->whereRaw('et_payment.transaction_date = (
    //                      SELECT MIN(ep.transaction_date)
    //                      FROM et_payment ep
    //                      WHERE ep.proposal_id = et_proposal.sno
    //                  )');
    //         })
    //         ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //         ->where('et_customer.status', 0)
    //         ->where('et_customer.post_sale_check', 1)
    //         ->where('et_proposal.post_sale_check', 1)
    //         ->where('et_customer.branch_id', $branchId)
    //         ->where('et_lead.created_by', '>',1)
    //         ->whereDate('et_payment.transaction_date', $date)
    //         ->where('et_transaction.payment_status', 1)
    //         ->orderBy('et_customer.sno', 'asc')
    //         ->distinct('et_customer.sno')
    //         ->count();

    //         return response()->json([
    //             'status' => true,
    //             'data' => [[
    //                 'amount' => $amount,
    //                 'pre_sale' => $preSale,
    //                 'post_sale' => $postSale,
    //                 'date' => $date
    //             ]]
    //         ]);
    //     } catch (\Exception $e) {

    //         \Log::error('Achieve API Error: ' . $e->getMessage());

    //         return response()->json([
    //             'status' => false,
    //             'message' => 'Server Error'
    //         ]);
    //     }
    // } 

    public function getAchieveData(Request $request)
    {
        try {

            $verify_key = 'egcsecret2030datagetapierp';

            if ($request->verify_key !== $verify_key) {

                return response()->json([
                    'status' => false,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $branchId = $request->branch_id;

            $fromDate = Carbon::parse($request->from_date)->format('Y-m-d');
            $toDate   = Carbon::parse($request->to_date)->format('Y-m-d');

            $dates = [];

            $period = CarbonPeriod::create($fromDate, $toDate);
            $helper = new \App\Helpers\Helpers();

            $branch_common = DB::table('et_branch')->select('et_branch.*')
            ->where('et_branch.sno', $branchId)
            ->first();

            $processedCustomers = [];

            foreach ($period as $dateObj) {

                $date = $dateObj->format('Y-m-d');

                // SALES AMOUNT
              

                $total_collection_value = 0;
          
                $allVerified = DB::table('et_transaction')
                    ->join('et_payment','et_payment.sno','=','et_transaction.payment_id')
                    ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->where('et_transaction.payment_status',1)
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->where('et_lead.created_by','>',1)
                    ->where('et_lead.status','!=',2)
                    ->where('et_customer.status',0)
                    ->where('et_customer.branch_id', $branchId)
                    ->whereDate('et_payment.transaction_date', $date)
                    ->select('et_payment.paid_amount','et_transaction.total_amount_inr',
                            'et_proposal.gst_perc','et_country_currencies.currency_code')
                    ->get();
                
                foreach ($allVerified as $row) {
                    // Determine INR value
                    if ($row->total_amount_inr > 0) {
                        $convertedPaidAmountInr = $row->total_amount_inr;
                    } else {
                        $convertedPaidAmountInr = $helper->ConvertedAmountInr($row->currency_code, $row->paid_amount);
                    }
                
                    // Use transaction GST%
                    $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($branch_common->gst_percentage/100);
                    $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
                
                    $total_collection_value += $netAmountInr;
                }
            
           

                $total_collection_value = round($total_collection_value);

                // PRE SALE
                $preSale = DB::table('et_customer')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')

                    ->join('et_payment', function ($join) {

                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                            )');
                    })

                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')

                    ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')

                    ->where('et_customer.status', 0)
                    ->where('et_proposal.post_sale_check', 0)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', '>', 1)
                    ->whereDate('et_payment.transaction_date', $date)
                    ->where('et_transaction.payment_status', 1)
                    ->count();

                // POST SALE
                $postSaleData = DB::table('et_customer')
                    ->select('et_customer.sno','et_payment.transaction_date')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.proposal_id = et_proposal.sno
                            )');
                    })

                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', '>', 1)
                    ->whereDate('et_payment.transaction_date', $date)
                    ->where('et_transaction.payment_status', 1)
                    ->distinct('et_customer.sno')
                    ->get();
                $customerConvertDataPostRaw = DB::table('et_customer')
                ->select(
                    'et_customer.sno',
                    'et_customer.proposal_ids',
                    'et_customer.cus_name',
                    'et_payment.transaction_date'
                )
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')

                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')

                ->join('et_payment', function($join) {

                    $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                        ->whereRaw('et_payment.transaction_date = (
                            SELECT MIN(ep.transaction_date)
                            FROM et_payment ep
                            WHERE ep.proposal_id = et_proposal.sno
                        )');
                })

                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')

                ->where('et_customer.status', 0)
                ->where('et_customer.post_sale_check', 1)
                ->where('et_proposal.post_sale_check', 1)
                ->where('et_customer.branch_id', $branchId)
                ->where('et_lead.created_by', '>', 1)

                ->whereDate('et_payment.transaction_date', $date)

                ->whereYear('et_payment.transaction_date', Carbon::parse($date)->year)
                ->whereMonth('et_payment.transaction_date', Carbon::parse($date)->month)

                ->where('et_transaction.payment_status', 1)

                ->orderBy('et_payment.transaction_date', 'asc')
                ->orderBy('et_customer.sno', 'asc')

                ->get();

                $customerConvertDataPost = collect();

                foreach ($customerConvertDataPostRaw as $customer) {

                    // Ignore duplicate customer in same month
                    if (in_array($customer->sno, $processedCustomers)) {
                        continue;
                    }

                    $processedCustomers[] = $customer->sno;

                    $customerConvertDataPost->push($customer);
                }

               $postSale = $customerConvertDataPost->count();

                $dates[] = [
                    'date' => $date,
                    'amount' => $total_collection_value,
                    'pre_sale' => (int)$preSale,
                    'post_sale' => $postSale,
                    //  'customerConvertDataPost' => $customerConvertDataPost->values(),
                ];
            }

            return response()->json([
                'status' => true,
                'data' => $dates
            ]);

        } catch (\Exception $e) {

            \Log::error('Achieve API Error : ' . $e->getMessage());

            return response()->json([
                'status' => false,
                'message' => 'Server Error' . $e->getMessage()
            ]);
        }
    }

    public function GetIncentive(Request $request)
{
    try {

        if ($request->verify_key !== 'egcsecret2030datagetapierp') {

            return response()->json([
                'status'  => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        $request->validate([
            'branch_id' => 'required|integer',
            'role_id'   => 'required',
            'month_year'=> 'nullable|string'
        ]);

        $branchId = (int) $request->branch_id;
        $roleId   = trim($request->role_id);

        $monthFilter = $request->get('month_year', date('M-Y'));
        try {

            $parsedDate = Carbon::createFromFormat('M-Y', $monthFilter);

        } catch (\Exception $e) {

            $parsedDate = now();
        }

        $month = (int) $parsedDate->month;
        $year  = (int) $parsedDate->year;

        $cacheVersion = 'v2';

        $cacheKey = implode('_', [
            'incentive',
            $cacheVersion,
            'branch', $branchId,
            'role', $roleId,
            'year', $year,
            'month', $month
        ]);

        $responseData = Cache::remember(
            $cacheKey,
            now()->addMinutes(30),
            function () use (
                $branchId,
                $roleId,
                $year,
                $month
            ) {
                $staffs = DB::table('et_staff')
                    ->select([
                        'sno',
                        'staff_name',
                        'role_id'
                    ])
                    ->where('role_id', $roleId)
                    ->where('branch_id', $branchId)
                    ->where('status', 0)
                    ->orderBy('staff_name')
                    ->get();

                if ($staffs->isEmpty()) {

                    return [
                        'generated_at' => now()->format('Y-m-d H:i:s'),
                        'next_refresh' => now()->addMinutes(30)->format('Y-m-d H:i:s'),
                        'count'        => 0,
                        'data'         => []
                    ];
                }

                $incentiveData = [];

                foreach ($staffs as $staff) {
                    try {
                        $result = self::calculateIncentiveValue(
                            $staff->sno,
                            $branchId,
                            $roleId,
                            $year,
                            $month
                        );
                        $totalAward = (float) ($result['total_award'] ?? 0);
                        $breakdown = $result['breakdown'] ?? [];

                        foreach ($breakdown as $key => $value) {
                            $breakdown[$key] = (float) $value;
                        }

                        $incentiveData[] = [
                            'staff_id' => (int) $staff->sno,
                            'staff_name' => $result['staff_name']
                                ?? $staff->staff_name,
                            'role_id' => $result['role_id']
                                ?? $staff->role_id,
                            'total_award' => round($totalAward, 2),
                            'currency' => 'INR',
                            'breakdown' => $breakdown,
                            'last_updated' => now()
                                ->format('Y-m-d H:i:s'),
                            'next_update' => now()
                                ->addMinutes(30)
                                ->format('Y-m-d H:i:s'),
                        ];

                    } catch (\Throwable $e) {
                        Log::error('Incentive Staff Error', [
                            'staff_id' => $staff->sno,
                            'message'  => $e->getMessage()
                        ]);

                        $incentiveData[] = [
                            'staff_id'      => (int) $staff->sno,
                            'staff_name'    => $staff->staff_name,
                            'role_id'       => $staff->role_id,
                            'total_award'   => 0,
                            'currency'      => 'INR',
                            'breakdown'     => [],
                            'last_updated'  => now()->format('Y-m-d H:i:s'),
                            'next_update'   => now()->addMinutes(30)
                                ->format('Y-m-d H:i:s'),
                        ];
                    }
                }
                usort($incentiveData, function ($a, $b) {
                    return $b['total_award'] <=> $a['total_award'];
                });
                return [
                    'generated_at' => now()
                        ->format('Y-m-d H:i:s'),
                    'next_refresh' => now()
                        ->addMinutes(30)
                        ->format('Y-m-d H:i:s'),
                    'count' => count($incentiveData),
                    'data' => $incentiveData
                ];
            }
        );
        return response()->json([
            'status'  => true,
            'message' => 'Incentive data fetched successfully',
            'cached' => true,
            'cache_expires_in_minutes' => 30,
            'generated_at' => $responseData['generated_at'] ?? null,
            'next_refresh' => $responseData['next_refresh'] ?? null,
            'total_staff' => $responseData['count'] ?? 0,
            'data' => $responseData['data'] ?? []
        ]);

    } catch (\Throwable $e) {
        Log::error('Get Incentive API Error', [
            'message' => $e->getMessage(),
            'line'    => $e->getLine(),
            'file'    => $e->getFile(),
        ]);
        return response()->json([

            'status'  => false,
            'message' => 'Server Error'
        ], 500);
    }
}

  /**
   * Calculate incentive value for floating bar
   */
  private static function calculateIncentiveValue($userId, $branchId, $roleId, $year, $month)
  {
    $staff = StaffModel::find($userId);
    if (!$staff) {
      return self::getEmptyResponse();
    }

    // Get incentive settings
    $incentive = IncentiveModel::where('role_id', $roleId)
      ->where('branch_id', $branchId)
      ->whereMonth('incentive_month', $month)
      ->whereYear('incentive_month', $year)
      ->where('status', 0)
      ->first();

    if (!$incentive) {
      // Try fallback date
      $fallbackDate = '2025-06-01';
      $incentive = IncentiveModel::where('role_id', $roleId)
        ->where('branch_id', $branchId)
        ->whereMonth('incentive_month', date('m', strtotime($fallbackDate)))
        ->whereYear('incentive_month', date('Y', strtotime($fallbackDate)))
        ->where('status', 0)
        ->first();
    }

    if (!$incentive) {
      return self::getEmptyResponse();
    }

    // Get goal data
    $goalData = GoalSetStaffModel::where('staff_id', $userId)
      ->whereMonth('goal_date', $month)
      ->whereYear('goal_date', $year)
      ->first();
    // return $goalData;

    // Calculate based on role
    $totalReward = 0;
    $breakdown = [];
   
    switch ($roleId) {
      case 11: // Sales Executive
        $result = self::calculateSalesExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      case 35: // Sales Executive
        $result = self::calculatePostSaleExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
       
        // $totalReward = $result;
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      case 12: // Team Lead
        $result = self::calculateTeamLeadReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      case 34: // Collection
        $result = self::calculateJournalExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      // case 15: // PC
      //   $result = self::calculatePCReward($staff, $incentive, $goalData, $branchId, $year, $month);
      //   $totalReward = $result['total'];
      //   $breakdown = $result['breakdown'];
      //   break;
      case 16: // CRE
        $result = self::calculateCREReward($staff, $incentive, $goalData, $branchId, $year, $month);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        break;
      // case 22: // Production
      //   $result = self::calculateProductionReward($staff, $incentive, $goalData, $branchId, $year, $month);
      //   $totalReward = $result['total'];
      //   $breakdown = $result['breakdown'];
      //   break;
      // case 17: // Production
      //   $result = self::calculatePlacementExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
      //   $totalReward = $result['total'];
      //   $breakdown = $result['breakdown'];
      //   break;
      // case 19: // Production
      //   $result = self::calculatePlacementLeadReward($staff, $incentive, $goalData, $branchId, $year, $month);
      //   $totalReward = $result['total'];
      //   $breakdown = $result['breakdown'];
      //   break;
      default:
        return self::getEmptyResponse();
    }
    // return  $totalReward ;

    return [
      'total_award' => $totalReward,
      'breakdown' => $breakdown,
      'currency' => 'INR',
      'last_updated' => now()->toDateTimeString(),
      'next_update' => now()->addHours(2)->toDateTimeString(),
      'staff_name' => $staff->staff_name,
      'staff_id' => $staff->sno,
      'role_id' => $roleId
    ];
  }

  /**
   * Calculate Sales Executive Reward (Exact logic from your code)
   */
  private static function calculateSalesExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];
    

    // Get previous month for calculations
    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
    $prevYear = Carbon::createFromDate($year, $month, 1)->subMonth()->year;

    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();


    $dates = [];
        $currentDate = $startDate->copy();
        while ($currentDate->lte($endDate)) {
            $dates[] = $currentDate->toDateString();
            $currentDate->addDay();
        }

    // 1. Get customer conversion count for the month
    

      $customerConvertCountthismonth = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->whereIn('et_customer.status',[0,6])
            ->join('et_payment', function($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                      ->whereRaw('et_payment.transaction_date = (
                          SELECT MIN(ep.transaction_date)
                          FROM et_payment ep
                          WHERE ep.customer_id = et_customer.sno
                      )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', $staff->sno)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->count();

    // 2. Get previous month converted customers for bad customer deduction
      $prevMonthConvertedCustomers = CustomerModel::select('et_customer.sno')
          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function($join) {
              $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                        SELECT MIN(ep.transaction_date)
                        FROM et_payment ep
                        WHERE ep.customer_id = et_customer.sno
                    )');
          })
          ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
          ->whereIn('et_customer.status', [0, 6])
          ->where('et_customer.branch_id', $branchId)
          ->where('et_lead.created_by', $staff->sno)
          ->whereYear('et_payment.transaction_date', $prevYear)
          ->whereMonth('et_payment.transaction_date', $prevMonth)
          ->where('et_transaction.payment_status', 1)
          // ->count();
          ->pluck('et_customer.sno')
          ->toArray(); 

    // 3. Calculate bad customers (dropouts, low payment, no second payment)
    $dropoutCustomers = DB::table('et_customer')
      ->where('et_customer.drop_refund_id', '!=' ,0)
      ->whereIn('et_customer.sno', $prevMonthConvertedCustomers)
      ->where('et_customer.drop_verified' ,1)
      ->pluck('et_customer.sno')
      ->toArray();

    // Fully paid customers
    $fullPaidCustomerIds = DB::table('et_proposal_pay_slot')
        ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
        ->select('et_payment.customer_id')
        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
        ->where('et_proposal_pay_slot.paid_status', 1)
        ->groupBy('et_payment.customer_id')
        ->havingRaw('SUM(et_proposal_pay_slot.paidAmount) = MAX(total_amount)')
        ->pluck('et_payment.customer_id')
        ->toArray();

    // Second payment customers
    $secondPaymentCustomersmulti = DB::table('et_proposal_pay_slot')
        ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
        ->where('et_proposal_pay_slot.paid_status', 1)
        ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
        ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
        ->pluck('et_payment.customer_id')
        ->unique()
        ->values() // this reindexes!
        ->toArray();

    $secondPaymentCustomers = array_values(array_unique(array_merge(
      $secondPaymentCustomersmulti,
      $fullPaidCustomerIds
    )));

    // Low payment customers
    $branch = BranchModel::where('sno', $branchId)->where('status', 0)->first();

    $drop_ids = DB::table('et_customer')
      ->where('et_customer.drop_refund_id', '!=' ,0)
      ->where('et_customer.drop_verified' ,1)
      ->pluck('et_customer.sno');

    $PaidUnderPayment = DB::table('et_proposal')
          ->whereIn('et_proposal.customer_id', $prevMonthConvertedCustomers)
          ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
          ->join('et_proposal_pay_slot', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
          ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
          ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
          ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
          ->select(
              'et_customer.customer_id',
              'et_payment.proposal_id',
              'et_customer.sno as customer_sno',
              'et_customer.cus_name',
              'et_customer.cus_gender',
              'et_customer.cus_pic',
              'et_customer.cus_mobile',
              'et_customer.cus_email_id',
              'et_staff.staff_name',
              'et_proposal_pay_slot.initialPayDate',
              'et_proposal_pay_slot.paidAmount as total_paid_amount',
              'et_proposal_pay_slot.balance_amount as total_balance_fee',
              'et_proposal_pay_slot.total_amount as total_amount',
              DB::raw('SUM(et_proposal_pay_slot.gst_amount) as total_gst_amount'),
              'et_payment.payment_mode',
              'et_proposal_pay_slot.nextPayDate'
          )
          ->where('et_payment.branch_id', $branchId)
        //   ->whereNotIn('et_customer.sno', $drop_ids)
          ->whereNotIn('et_proposal.status', [0,2])
          ->where('et_proposal_pay_slot.balance_amount', '!=',0)
          ->groupBy(
              'et_customer.customer_id',
              'et_customer.sno',
                'et_payment.proposal_id',
              'et_customer.cus_name',
              'et_customer.cus_mobile',
              'et_customer.cus_pic',
              'et_customer.cus_gender',
              'et_customer.cus_email_id',
                'et_staff.staff_name',
                'et_proposal_pay_slot.paidAmount',
              'et_proposal_pay_slot.balance_amount',
              'et_proposal_pay_slot.total_amount',
              'et_payment.payment_mode',
              'et_proposal_pay_slot.nextPayDate',
              'et_proposal_pay_slot.initialPayDate'
          )
        //   ->orderByDesc('et_payment.sno')
        ->orderBy('et_proposal_pay_slot.nextPayDate', 'asc')
          ->get()
          ->unique('customer_id'); // Keep only unique customer records;
      //   return $PaidUnderPayment;
      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
      $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
          return $payment->total_paid_amount < $branch->min_prd_cost;
      });
      $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
                          // Filter payments where paidAmount is greater than 0
                          $filteredPayments = $payments->filter(function ($payment) {
                              return $payment->total_paid_amount > 0;
                          });
                    
                          // If no valid payments exist after filtering, exclude this customer
                          if ($filteredPayments->isEmpty()) {
                              return null;
                          }
                    
                          $payment = $payments->first();
                          // Return structured data for each customer
                          return [
                              'customer_name' => $payment->cus_name,
                              'customer_sno' => $payment->customer_sno,
                              'total_paid' => $payment->total_paid_amount,
                              'min_required' => $branch->min_prd_cost,
                              'status' => 'Pending',
                              'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                                  return [
                                      'course_name' => $payment->course_name,
                                      'cus_gender' => $payment->cus_gender,
                                      'cus_pic' => $payment->cus_pic,
                                      'staff_name' => $payment->staff_name,
                                      'batch_id' => $payment->batch_id,
                                      'training_id' => $payment->training_id,
                                      'payment_id' => $payment->payment_id,
                                      'cus_name' => $payment->cus_name,
                                      'cus_mobile' => $payment->cus_mobile,
                                      'amount' => $payment->total_amount,
                                      'paidAmount' => $payment->total_paid_amount,
                                      'balanceFee' => $payment->total_balance_fee,
                                      'gst_amount' => $payment->total_gst_amount,
                                      'nextPayDate' => $payment->nextPayDate,
                                      'initialPayDate' => $payment->initialPayDate,
                                      'payment_mode_label' => $payment->payment_mode_label,
                                  ];
                              })->values(), // Reset array keys
                          ];
                        })->filter();
                  
                        // Paginate the results
                        //   $paginatedResult = $finalResult->slice(($page - 1) * $perPage, $perPage);
                    
                        // Calculate the total number of pages
                        $totalItems = $finalResult->count();
                        
                        $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();

    $badCustomerIds = array_unique(array_merge(
      $dropoutCustomers,
      $lowMbcCustomerIds,
      array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
    ));

    $actualConversion = max(0, $customerConvertCountthismonth - count($badCustomerIds));
    $customerConvertCount =$actualConversion;

    // 4. Get target from goal data
    $targetConversion = $goalData->conversion ?? 0;
    $targetABV = $goalData->ABV ?? 0;
    $targetACV = $goalData->ACV ?? 0;

    // 5. Calculate business values
    $total_payment = 0;
    $total_paid_payment = 0;

    if ($actualConversion > 0) {
      $currentMonthCustomer = DB::table('et_customer')
          ->select('et_customer.sno', 'et_customer.proposal_ids')
          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
          ->join('et_payment', function($join) {
              $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                        SELECT MIN(ep.transaction_date)
                        FROM et_payment ep
                        WHERE ep.customer_id = et_customer.sno
                    )');
          })
          ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
          ->where('et_customer.status', 0)
          ->where('et_customer.branch_id', $branchId)
          ->where('et_lead.created_by', $staff->sno)
          ->whereYear('et_payment.transaction_date', $year)
          ->whereMonth('et_payment.transaction_date', $month)
          ->where('et_transaction.payment_status', 1)
          ->orderBy('et_customer.sno', 'asc')
          ->get();
        $base_amount_paid=0;
        $gst_percent = 18;
        $helper = new \App\Helpers\Helpers();

          foreach ($currentMonthCustomer as $customer) {
              $proposal_ids = DB::table('et_proposal')
                  ->where('et_proposal.customer_id', $customer->sno)
                  ->where('et_proposal.status', 0)
                  ->whereNot('et_proposal.post_sale_check', 1)
                  ->whereNotIn('et_proposal.proposal_status', [0, 2])
                  ->pluck('sno')
                  ->toArray();
                  // return $proposal_ids;
      
              $proposals = DB::table('et_proposal')
                  ->select('et_proposal.*', 'et_country_currencies.currency_code')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                  ->whereIn('et_proposal.sno', $proposal_ids)
                  ->get();
      
              foreach ($proposals as $proposal) {
                  // Paid slots for this proposal
                  $paidAmount = DB::table('et_proposal_pay_slot')
                      ->where('proposal_sno', $proposal->sno)
                      ->where('status', 0)
                      ->sum('paidAmount');
      
                  $grantAmount = $proposal->grant_total_amount;
      
                  // First remove GST from paidAmount (base value in proposal's currency)
                  $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
      
                  if ($proposal->currency_id == 70) {
                      // INR: add directly
                      $total_paid_payment += $paidAmount;
                      $total_payment += $grantAmount;
                      $base_amount_paid += $basePaidLocal;
                  } else {
                      // Non-INR: convert both amounts and base value
                      $currency_code = $proposal->currency_code;
                      $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                      $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                      $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                  }
              }
          }
    }

    $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
    $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;

    // 6. Check 10X Award status
    $tenxStatus = (
      $targetConversion > 0 &&
      $targetABV > 0 &&
      $targetACV > 0 &&
      $actualConversion >= $targetConversion
    );

    if ($tenxStatus) {
      $tenxReward = $incentive->tenx_award ?? 0;
      $totalReward += $tenxReward;
      $breakdown['10X Award'] = $tenxReward;
    }

    // 7. ECI Award (Early Conversion before 15th)
    $eciCustomerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->join('et_payment', function($join) {
            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                  ->whereRaw('et_payment.sno = (
                      SELECT ep.sno
                      FROM et_payment ep
                      WHERE ep.customer_id = et_customer.sno
                      ORDER BY ep.transaction_date ASC, ep.sno ASC
                      LIMIT 1
                  )');
        })
        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
        ->where('et_customer.branch_id', $branchId)
        ->whereIn('et_customer.status', [0, 6])
        ->where('et_lead.created_by', $staff->sno)
          ->whereYear('et_payment.transaction_date', $year)
        ->whereMonth('et_payment.transaction_date', $month)
        ->where('et_transaction.payment_status', 1)
        ->whereDay('et_payment.transaction_date', '<=', 15)
        ->count();

    $eciTargetPercentage = $incentive->eci_count ?? 0;
    $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
    $eciStatus = $tenxStatus && ($eciActualPercentage >= $eciTargetPercentage);

    if ($eciStatus) {
      $eciReward = $incentive->eci_reward ?? 0;
      $totalReward += $eciReward;
      $breakdown['ECI Award'] = $eciReward;
    }

    // 8. BI Award (Beyond Incentive)
    $biPerConversion = $incentive->bi_amount ?? 0;
    $biAchievedCount = max(0, $actualConversion - $targetConversion);
    $biReward = $biAchievedCount * $biPerConversion;
    $biStatus = $tenxStatus && ($biAchievedCount > 0);

    if ($biStatus) {
      $totalReward += $biReward;
      $breakdown['BI Award'] = $biReward;
    }

    // 9. SI Award (Spot Incentive)
    $crashCount = 0;
    $professionCount = 0;
    $tesboCount = 0;

    if ($actualConversion > 0) {
      // $currentMonthCustomer = CustomerModel::select('za_customer.sno')
      //   ->whereIn('za_customer.status', [0, 6])
      //   ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      //   ->where('za_customer.branch_id', $branchId)
      //   ->where('za_lead.created_by', $staff->sno)
      //   ->whereYear('za_customer.created_at', $year)
      //   ->whereMonth('za_customer.created_at', $month)
      //   ->get();

      // foreach ($currentMonthCustomer as $customer) {
      //   $hasTesbo = DB::table('za_training')
      //     ->where('customer_id', $customer->sno)
      //     ->where('branch_id', $branchId)
      //     ->whereMonth('created_at', $month)
      //     ->whereYear('created_at', $year)
      //     ->where('tesbo_check', 2)
      //     ->where('post_sale_check', '!=', 1)
      //     ->exists();

      //   if ($hasTesbo) {
      //     $tesboCount++;
      //     continue;
      //   }

      //   $nonTesboTrainings = DB::table('za_training')
      //     ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
      //     ->where('za_training.customer_id', $customer->sno)
      //     ->where('za_training.branch_id', $branchId)
      //     ->whereMonth('za_training.created_at', $month)
      //     ->whereYear('za_training.created_at', $year)
      //     ->where('za_training.post_sale_check', '!=', 1)
      //     ->where('za_training.tesbo_check', '!=', 2)
      //     ->whereIn('za_course.course_type_id', [3, 4])
      //     ->get();

      //   $hasCrash = false;
      //   $hasProfession = false;

      //   foreach ($nonTesboTrainings as $training) {
      //     if ($training->course_type_id == 3) $hasProfession = true;
      //     if ($training->course_type_id == 4) $hasCrash = true;
      //   }

      //   if ($hasCrash) $crashCount++;
      //   if ($hasProfession) $professionCount++;
      // }
    }

    $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / max(1, $customerConvertCountthismonth)) * 100 : 0;

    $siStatus = false;
    if ($customerConvertCountthismonth >= 20) {
      $siStatus = true;
      if ($incentive->si_crash_course > 0) {
        $siStatus = $siStatus && ($crashPercent >= $incentive->si_crash_course);
      }
      if ($incentive->si_profession_course > 0) {
        $siStatus = $siStatus && ($professionPercent >= $incentive->si_profession_course);
      }
      if ($incentive->si_tesbo_course > 0) {
        $siStatus = $siStatus && ($tesboPercent <= $incentive->si_tesbo_course);
      }
    }

    if ($tenxStatus && $siStatus) {
      $siReward = 3000;
      $totalReward += $siReward;
      $breakdown['SI Award'] = $siReward;
    }

    // 10. SP Award (Spot Award)

    $startOfMonth = Carbon::create($year, $month, 1)->startOfMonth();
    $endOfMonth   = Carbon::create($year, $month, 1)->endOfMonth();

    $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staff->sno)
                        ->join('et_payment', function($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.sno = (
                                            SELECT ep.sno
                                            FROM et_payment ep
                                            WHERE ep.customer_id = et_customer.sno
                                            ORDER BY ep.transaction_date ASC, ep.sno ASC
                                            LIMIT 1
                                        )');
                                })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_transaction.payment_status', 1)
                        ->whereRaw('DATE(et_payment.transaction_date) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
                        ->select(
                            'et_payment.transaction_date as customer_created_at',
                            'et_lead.registered_date as lead_created_at',
                            'et_lead.lead_mobile as lead_mobile'
                        )
                        ->get();

                      foreach ($allConverted as $row) {
                
                        $mobile = $row->lead_mobile;
                          // Get the latest call
                          $lastCall = DB::table('et_call_tracker')
                              ->where('branch_id', $branchId)
                              ->where('branch_staff_id', $staff->sno)
                              ->where('customer_phone_no', 'like', "%{$mobile}")
                              ->orderByDesc('call_start_date')
                              ->first();
                      
                              
                          $totalCallCount = DB::table('et_call_tracker')->select('sno')
                              ->where('branch_id', $branchId)
                              ->where('branch_staff_id', $staff->sno)
                              ->where('customer_phone_no', 'like', "%{$mobile}")
                              ->orderByDesc('call_start_date')
                              ->count();
                          // Attach values to row
                          $row->call_created_at = $lastCall->call_start_date ?? null;
                          $row->customer_phone_no = $lastCall->customer_phone_no ?? null;
                          $row->call_count = $totalCallCount;
                      }

                  $convertedToday = 0;
                  $convertedMonth = 0;
                  $convertedOldMonth = 0;
                  $customerDetails=[];
                  foreach ($allConverted as $row) {
                        $mobile = $row->lead_mobile;
                        $totalCalldata = DB::table('et_call_tracker')
                          ->where('branch_id', $branchId)
                          ->where('branch_staff_id', $staff->sno)
                          ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->select(
                              'et_call_tracker.call_start_date'
                          )
                          ->get();
                          
                      $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
                      $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
                      $callDate = Carbon::parse($row->call_created_at)->format('Y-m-d');
                      $call_count = $row->call_count;
                      
                      $customerData = [
                          'customerDate' => $customerDate,
                          'leadDate'     => $leadDate,
                          'mobile'       => $mobile
                      ];
                      if ($customerDate ===  $leadDate) {
                          $convertedToday++;
                          //   $customerDetails[] = $customerData; 
                      } elseif (
                          $customerDate >= $startOfMonth && $customerDate <= $dates &&
                          $leadDate >= $startOfMonth && $leadDate <= $dates
                      ) {
                          $convertedMonth++;
                          
                      } elseif (
                          $customerDate >= $startOfMonth && $customerDate <= $dates &&
                          ($leadDate < $startOfMonth || $leadDate > $dates)
                      ) {
                          $convertedOldMonth++;
                      }
                  }

    $spotIncentiveDayAmount   = $convertedToday * ($incentive->spot_incentive_day ?? 0);
    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
    $spotTotalReward          = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;

    if ($tenxStatus && $spotTotalReward > 0) {
      $totalReward += $spotTotalReward;
      $breakdown['SP Award'] = $spotTotalReward;
    }


    // 11. PI Award (Profit Incentive)
    $pi_slabs = json_decode($incentive->pi_slab_json ?? '[]', true);
    $originalAmount = 0;
    $slabPercentage = 0;

    // if ($actualConversion > 0) {
    //   $currentMonthCustomer = CustomerModel::select('za_customer.sno')
    //     ->whereIn('za_customer.status', [0, 6])
    //     ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
    //     ->where('za_customer.branch_id', $branchId)
    //     ->where('za_lead.created_by', $staff->sno)
    //     ->whereYear('za_customer.created_at', $year)
    //     ->whereMonth('za_customer.created_at', $month)
    //     ->get();

    //   foreach ($currentMonthCustomer as $customer) {
    //     $trainings = DB::table('za_training as t1')
    //       ->join(DB::raw('(SELECT MIN(sno) as min_sno FROM za_training WHERE post_sale_check = 0 GROUP BY customer_id) as t2'), 't1.sno', '=', 't2.min_sno')
    //       ->where('t1.customer_id', $customer->sno)
    //       ->get();

    //     foreach ($trainings as $training) {
    //       $course_id = $training->tesbo_check > 0
    //         ? optional(PaymentModel::where('payment_id', $training->payment_id)->first())->course_id
    //         : $training->course_id;

    //       if (!$course_id) continue;

    //       $course = ManageCoursesModel::where('sno', $course_id)
    //         ->whereIn('course_type_id', [2, 3])
    //         ->first();

    //       if ($course) {
    //         $profitAmount = $training->overall_fees - $course->course_min_price;
    //         $originalAmount += $profitAmount;

    //         $profitPercent = ($course->course_min_price != 0) ? ($profitAmount / $course->course_min_price) * 100 : 0;

    //         foreach ($pi_slabs as $slab) {
    //           if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
    //             $slabPercentage = $slab['percentage'];
    //             break;
    //           }
    //         }
    //       }
    //     }
    //   }
    // }

    $piReward = $slabPercentage > 0 ? ($originalAmount * $slabPercentage) / 100 : 0;

    if ($tenxStatus && $piReward > 0) {
      $totalReward += $piReward;
      $breakdown['PI Award'] = $piReward;
    }

    // 12. LI Award (Luxury Incentive)
    $luxury = json_decode($incentive->luxury_incentive ?? '{}', true);
    $allIncentivesAchieved = ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward > 0);

    if ($allIncentivesAchieved) {
      $liReward = $luxury['reward'] ?? 0;
      $totalReward += $liReward;
      $breakdown['LI Award'] = $liReward;
    }

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'conversion_rate' => $actualConversion,
        'target_conversion' => $targetConversion,
        'tenx_status' => $tenxStatus
      ]
    ];
  }

  /**
   * Calculate Post Sales Executive Reward (Exact logic from your code)
   */
  private static function calculatePostSaleExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];
    

    // Get previous month for calculations
    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
    $prevYear = Carbon::createFromDate($year, $month, 1)->subMonth()->year;

    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();


    $dates = [];
        $currentDate = $startDate->copy();
        while ($currentDate->lte($endDate)) {
            $dates[] = $currentDate->toDateString();
            $currentDate->addDay();
        }

    // 1. Get customer conversion count for the month
    

      $customerConvertCountthismonth = DB::table('et_customer')
                        ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', $staff->sno)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->distinct('et_customer.sno')
                         ->count();

    // 2. Get previous month converted customers for bad customer deduction
      $prevMonthConvertedCustomers = DB::table('et_customer')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', $staff->sno)
                        ->whereYear('et_payment.transaction_date', $prevYear)
                        ->whereMonth('et_payment.transaction_date', $prevMonth)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->distinct('et_customer.sno')
                        ->pluck('et_customer.sno')
                        ->toArray();

    // 3. Calculate bad customers (dropouts, low payment, no second payment)
    $dropoutCustomers = DB::table('et_customer')
      ->where('et_customer.drop_refund_id', '!=' ,0)
      ->whereIn('et_customer.sno', $prevMonthConvertedCustomers)
      ->where('et_customer.drop_verified' ,1)
      ->pluck('et_customer.sno')
      ->toArray();

    // Fully paid customers
    $fullPaidCustomerIds = DB::table('et_proposal_pay_slot')
              ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
              ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
              ->select('et_payment.customer_id')
              ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
              ->where('et_proposal_pay_slot.paid_status', 1)
              ->groupBy('et_payment.customer_id')
              ->havingRaw('SUM(et_proposal_pay_slot.paidAmount) = MAX(total_amount)')
              ->pluck('et_payment.customer_id')
              ->toArray();

    // Second payment customers
     $secondPaymentCustomersmulti = DB::table('et_proposal_pay_slot')
                       ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
                        ->where('et_proposal_pay_slot.paid_status', 1)
                        ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                        ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                        ->pluck('et_payment.customer_id')
                        ->unique()
                        ->values() // this reindexes!
                        ->toArray();

    $secondPaymentCustomers = array_values(array_unique(array_merge(
      $secondPaymentCustomersmulti,
      $fullPaidCustomerIds
    )));

    // Low payment customers
    $branch = BranchModel::where('sno', $branchId)->where('status', 0)->first();

    $drop_ids = DB::table('et_customer')
      ->where('et_customer.drop_refund_id', '!=' ,0)
      ->where('et_customer.drop_verified' ,1)
      ->pluck('et_customer.sno');

    $PaidUnderPayment = DB::table('et_proposal')
                          ->whereIn('et_proposal.customer_id', $prevMonthConvertedCustomers)
                          ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                          ->join('et_proposal_pay_slot', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                          ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                          ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                          ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                          ->select(
                              'et_customer.customer_id',
                              'et_payment.proposal_id',
                              'et_customer.sno as customer_sno',
                              'et_customer.cus_name',
                              'et_customer.cus_gender',
                              'et_customer.cus_pic',
                              'et_customer.cus_mobile',
                              'et_customer.cus_email_id',
                              'et_staff.staff_name',
                              'et_proposal_pay_slot.initialPayDate',
                              'et_proposal_pay_slot.paidAmount as total_paid_amount',
                             'et_proposal_pay_slot.balance_amount as total_balance_fee',
                             'et_proposal_pay_slot.total_amount as total_amount',
                              DB::raw('SUM(et_proposal_pay_slot.gst_amount) as total_gst_amount'),
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate'
                          )
                          ->where('et_payment.branch_id', $branchId)
                        //   ->whereNotIn('et_customer.sno', $drop_ids)
                          ->whereNotIn('et_proposal.status', [0,2])
                          ->where('et_proposal_pay_slot.balance_amount', '!=',0)
                          ->groupBy(
                              'et_customer.customer_id',
                              'et_customer.sno',
                               'et_payment.proposal_id',
                              'et_customer.cus_name',
                              'et_customer.cus_mobile',
                              'et_customer.cus_pic',
                              'et_customer.cus_gender',
                              'et_customer.cus_email_id',
                               'et_staff.staff_name',
                               'et_proposal_pay_slot.paidAmount',
                             'et_proposal_pay_slot.balance_amount',
                             'et_proposal_pay_slot.total_amount',
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate',
                              'et_proposal_pay_slot.initialPayDate'
                          )
                        //   ->orderByDesc('et_payment.sno')
                        ->orderBy('et_proposal_pay_slot.nextPayDate', 'asc')
                          ->get()
                          ->unique('customer_id'); // Keep only unique customer records;
                      //   return $PaidUnderPayment;
                      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
                      $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
                          return $payment->total_paid_amount < $branch->min_prd_cost;
                      });
                   
                    
                      // Group by customer_id
                      $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
                          // Filter payments where paidAmount is greater than 0
                          $filteredPayments = $payments->filter(function ($payment) {
                              return $payment->total_paid_amount > 0;
                          });
                    
                          // If no valid payments exist after filtering, exclude this customer
                          if ($filteredPayments->isEmpty()) {
                              return null;
                          }
                    
                          $payment = $payments->first();
                          // Return structured data for each customer
                          return [
                              'customer_name' => $payment->cus_name,
                              'customer_sno' => $payment->customer_sno,
                              'total_paid' => $payment->total_paid_amount,
                              'min_required' => $branch->min_prd_cost,
                              'status' => 'Pending',
                              'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                                  return [
                                      'course_name' => $payment->course_name,
                                      'cus_gender' => $payment->cus_gender,
                                      'cus_pic' => $payment->cus_pic,
                                      'staff_name' => $payment->staff_name,
                                      'batch_id' => $payment->batch_id,
                                      'training_id' => $payment->training_id,
                                      'payment_id' => $payment->payment_id,
                                      'cus_name' => $payment->cus_name,
                                      'cus_mobile' => $payment->cus_mobile,
                                      'amount' => $payment->total_amount,
                                      'paidAmount' => $payment->total_paid_amount,
                                      'balanceFee' => $payment->total_balance_fee,
                                      'gst_amount' => $payment->total_gst_amount,
                                      'nextPayDate' => $payment->nextPayDate,
                                      'initialPayDate' => $payment->initialPayDate,
                                      'payment_mode_label' => $payment->payment_mode_label,
                                  ];
                              })->values(), // Reset array keys
                          ];
                        })->filter();
                  
                        // Paginate the results
                        //   $paginatedResult = $finalResult->slice(($page - 1) * $perPage, $perPage);
                    
                        // Calculate the total number of pages
                        $totalItems = $finalResult->count();
                        
                        $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();

    $badCustomerIds = array_unique(array_merge(
      $dropoutCustomers,
      $lowMbcCustomerIds,
      array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
    ));

    // 
    
    
    if($incentive->second_payment_check == 1){
          $actualConversion = max(0, $customerConvertCountthismonth - count($badCustomerIds));
      }else{
          $actualConversion = max(0, $customerConvertCountthismonth );
      }
      $customerConvertCount =$actualConversion;
    
     

    // 4. Get target from goal data
    $targetConversion = $goalData->conversion ?? 0;
    $targetABV = $goalData->ABV ?? 0;
    $targetACV = $goalData->ACV ?? 0;

    // 5. Calculate business values
    $total_payment = 0;
    $total_paid_payment = 0;

    if ($actualConversion > 0) {

     $currentMonthCustomer = DB::table('et_customer')
                        ->select('et_customer.sno', 'et_customer.proposal_ids')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', $staff->sno)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->distinct('et_customer.sno')
                        ->orderBy('et_payment.transaction_date', 'asc')
                        ->get();
     
        $base_amount_paid=0;
        $gst_percent = 18;
        $helper = new \App\Helpers\Helpers();

          foreach ($currentMonthCustomer as $customer) {
              $proposal_ids = DB::table('et_proposal')
                  ->where('et_proposal.customer_id', $customer->sno)
                  ->where('et_proposal.status', 0)
                  ->whereNot('et_proposal.post_sale_check', 1)
                  ->whereNotIn('et_proposal.proposal_status', [0, 2])
                  ->pluck('sno')
                  ->toArray();
                  // return $proposal_ids;
      
              $proposals = DB::table('et_proposal')
                  ->select('et_proposal.*', 'et_country_currencies.currency_code')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                  ->whereIn('et_proposal.sno', $proposal_ids)
                  ->get();
      
              foreach ($proposals as $proposal) {
                  // Paid slots for this proposal
                  $paidAmount = DB::table('et_proposal_pay_slot')
                      ->where('proposal_sno', $proposal->sno)
                      ->where('status', 0)
                      ->sum('paidAmount');
      
                  $grantAmount = $proposal->grant_total_amount;
      
                  // First remove GST from paidAmount (base value in proposal's currency)
                  $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
      
                  if ($proposal->currency_id == 70) {
                      // INR: add directly
                      $total_paid_payment += $paidAmount;
                      $total_payment += $grantAmount;
                      $base_amount_paid += $basePaidLocal;
                  } else {
                      // Non-INR: convert both amounts and base value
                      $currency_code = $proposal->currency_code;
                      $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                      $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                      $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                  }
              }
          }
    }

    $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
    $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;

    // 6. Check 10X Award status
    $tenxStatus = (
      $targetConversion > 0 &&
      $targetABV > 0 &&
      $targetACV > 0 &&
      $actualConversion >= $targetConversion
    );
    // return $actualConversion >= $targetConversion;
 
    if ($tenxStatus) {
      $tenxReward = $incentive->tenx_award ?? 0;
      $totalReward += $tenxReward;
      $breakdown['10X Award'] = $tenxReward;
    }

    // 7. ECI Award (Early Conversion before 15th)
    $eciCustomerConvertCount = DB::table('et_customer')
                                ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                                ->join('et_payment', function($join) {
                                    $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                                            SELECT MIN(ep.transaction_date)
                                            FROM et_payment ep
                                            WHERE ep.proposal_id = et_proposal.sno
                                        )');
                                })
                                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                                ->where('et_customer.status', 0)
                                ->where('et_customer.post_sale_check', 1)
                                ->where('et_proposal.post_sale_check', 1)
                                ->where('et_customer.branch_id', $branchId)
                                ->where('et_proposal.created_by', $staff->sno)
                                ->whereYear('et_payment.transaction_date', $year)
                                ->whereMonth('et_payment.transaction_date', $month)
                                ->where('et_transaction.payment_status', 1)
                                ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                                ->where('et_proposal.status',0)
                                ->orderBy('et_proposal.sno', 'asc')
                                ->whereDay('et_payment.transaction_date', '<=', 15)
                                ->distinct('et_customer.sno')
                                ->count();

    $eciTargetPercentage = $incentive->eci_count ?? 0;
    $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
    $eciStatus = $tenxStatus && ($eciActualPercentage >= $eciTargetPercentage);

    if ($eciStatus) {
      $eciReward = $incentive->eci_reward ?? 0;
      $totalReward += $eciReward;
      $breakdown['ECI Award'] = $eciReward;
    }

    // 8. BI Award (Beyond Incentive)
    $biPerConversion = $incentive->bi_amount ?? 0;
    $biAchievedCount = max(0, $actualConversion - $targetConversion);
    $biReward = $biAchievedCount * $biPerConversion;
    $biStatus = $tenxStatus && ($biAchievedCount > 0);

    if ($biStatus) {
      $totalReward += $biReward;
      $breakdown['BI Award'] = $biReward;
    }

    // 9. SI Award (Spot Incentive)
    $crashCount = 0;
    $professionCount = 0;
    $tesboCount = 0;

    if ($actualConversion > 0) {
      // $currentMonthCustomer = CustomerModel::select('za_customer.sno')
      //   ->whereIn('za_customer.status', [0, 6])
      //   ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      //   ->where('za_customer.branch_id', $branchId)
      //   ->where('za_lead.created_by', $staff->sno)
      //   ->whereYear('za_customer.created_at', $year)
      //   ->whereMonth('za_customer.created_at', $month)
      //   ->get();

      // foreach ($currentMonthCustomer as $customer) {
      //   $hasTesbo = DB::table('za_training')
      //     ->where('customer_id', $customer->sno)
      //     ->where('branch_id', $branchId)
      //     ->whereMonth('created_at', $month)
      //     ->whereYear('created_at', $year)
      //     ->where('tesbo_check', 2)
      //     ->where('post_sale_check', '!=', 1)
      //     ->exists();

      //   if ($hasTesbo) {
      //     $tesboCount++;
      //     continue;
      //   }

      //   $nonTesboTrainings = DB::table('za_training')
      //     ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
      //     ->where('za_training.customer_id', $customer->sno)
      //     ->where('za_training.branch_id', $branchId)
      //     ->whereMonth('za_training.created_at', $month)
      //     ->whereYear('za_training.created_at', $year)
      //     ->where('za_training.post_sale_check', '!=', 1)
      //     ->where('za_training.tesbo_check', '!=', 2)
      //     ->whereIn('za_course.course_type_id', [3, 4])
      //     ->get();

      //   $hasCrash = false;
      //   $hasProfession = false;

      //   foreach ($nonTesboTrainings as $training) {
      //     if ($training->course_type_id == 3) $hasProfession = true;
      //     if ($training->course_type_id == 4) $hasCrash = true;
      //   }

      //   if ($hasCrash) $crashCount++;
      //   if ($hasProfession) $professionCount++;
      // }
    }

    $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / max(1, $customerConvertCountthismonth)) * 100 : 0;

    $siStatus = false;
    if ($customerConvertCountthismonth >= 20) {
      $siStatus = true;
      if ($incentive->si_crash_course > 0) {
        $siStatus = $siStatus && ($crashPercent >= $incentive->si_crash_course);
      }
      if ($incentive->si_profession_course > 0) {
        $siStatus = $siStatus && ($professionPercent >= $incentive->si_profession_course);
      }
      if ($incentive->si_tesbo_course > 0) {
        $siStatus = $siStatus && ($tesboPercent <= $incentive->si_tesbo_course);
      }
    }

    if ($tenxStatus && $siStatus) {
      $siReward = 3000;
      $totalReward += $siReward;
      $breakdown['SI Award'] = $siReward;
    }

    // 10. SP Award (Spot Award)

    $startOfMonth = Carbon::create($year, $month, 1)->startOfMonth();
    $endOfMonth   = Carbon::create($year, $month, 1)->endOfMonth();

    $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staff->sno)
                        ->join('et_payment', function($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.sno = (
                                            SELECT ep.sno
                                            FROM et_payment ep
                                            WHERE ep.customer_id = et_customer.sno
                                            ORDER BY ep.transaction_date ASC, ep.sno ASC
                                            LIMIT 1
                                        )');
                                })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_transaction.payment_status', 1)
                        ->whereRaw('DATE(et_payment.transaction_date) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
                        ->select(
                            'et_payment.transaction_date as customer_created_at',
                            'et_lead.registered_date as lead_created_at',
                            'et_lead.lead_mobile as lead_mobile'
                        )
                        ->get();

                      foreach ($allConverted as $row) {
                
                        $mobile = $row->lead_mobile;
                          // Get the latest call
                          $lastCall = DB::table('et_call_tracker')
                              ->where('branch_id', $branchId)
                              ->where('branch_staff_id', $staff->sno)
                              ->where('customer_phone_no', 'like', "%{$mobile}")
                              ->orderByDesc('call_start_date')
                              ->first();
                      
                              
                          $totalCallCount = DB::table('et_call_tracker')->select('sno')
                              ->where('branch_id', $branchId)
                              ->where('branch_staff_id', $staff->sno)
                              ->where('customer_phone_no', 'like', "%{$mobile}")
                              ->orderByDesc('call_start_date')
                              ->count();
                          // Attach values to row
                          $row->call_created_at = $lastCall->call_start_date ?? null;
                          $row->customer_phone_no = $lastCall->customer_phone_no ?? null;
                          $row->call_count = $totalCallCount;
                      }

                  $convertedToday = 0;
                  $convertedMonth = 0;
                  $convertedOldMonth = 0;
                  $customerDetails=[];
                  foreach ($allConverted as $row) {
                        $mobile = $row->lead_mobile;
                        $totalCalldata = DB::table('et_call_tracker')
                          ->where('branch_id', $branchId)
                          ->where('branch_staff_id', $staff->sno)
                          ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->select(
                              'et_call_tracker.call_start_date'
                          )
                          ->get();
                          
                      $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
                      $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
                      $callDate = Carbon::parse($row->call_created_at)->format('Y-m-d');
                      $call_count = $row->call_count;
                      
                      $customerData = [
                          'customerDate' => $customerDate,
                          'leadDate'     => $leadDate,
                          'mobile'       => $mobile
                      ];
                      if ($customerDate ===  $leadDate) {
                          $convertedToday++;
                          //   $customerDetails[] = $customerData; 
                      } elseif (
                          $customerDate >= $startOfMonth && $customerDate <= $dates &&
                          $leadDate >= $startOfMonth && $leadDate <= $dates
                      ) {
                          $convertedMonth++;
                          
                      } elseif (
                          $customerDate >= $startOfMonth && $customerDate <= $dates &&
                          ($leadDate < $startOfMonth || $leadDate > $dates)
                      ) {
                          $convertedOldMonth++;
                      }
                  }

    $spotIncentiveDayAmount   = $convertedToday * ($incentive->spot_incentive_day ?? 0);
    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
    $spotTotalReward          = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;

    if ($tenxStatus && $spotTotalReward > 0) {
      $totalReward += $spotTotalReward;
      $breakdown['SP Award'] = $spotTotalReward;
    }


    // 11. PI Award (Profit Incentive)
    $pi_slabs = json_decode($incentive->pi_slab_json ?? '[]', true);
    $originalAmount = 0;
    $slabPercentage = 0;

    // if ($actualConversion > 0) {
    //   $currentMonthCustomer = CustomerModel::select('za_customer.sno')
    //     ->whereIn('za_customer.status', [0, 6])
    //     ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
    //     ->where('za_customer.branch_id', $branchId)
    //     ->where('za_lead.created_by', $staff->sno)
    //     ->whereYear('za_customer.created_at', $year)
    //     ->whereMonth('za_customer.created_at', $month)
    //     ->get();

    //   foreach ($currentMonthCustomer as $customer) {
    //     $trainings = DB::table('za_training as t1')
    //       ->join(DB::raw('(SELECT MIN(sno) as min_sno FROM za_training WHERE post_sale_check = 0 GROUP BY customer_id) as t2'), 't1.sno', '=', 't2.min_sno')
    //       ->where('t1.customer_id', $customer->sno)
    //       ->get();

    //     foreach ($trainings as $training) {
    //       $course_id = $training->tesbo_check > 0
    //         ? optional(PaymentModel::where('payment_id', $training->payment_id)->first())->course_id
    //         : $training->course_id;

    //       if (!$course_id) continue;

    //       $course = ManageCoursesModel::where('sno', $course_id)
    //         ->whereIn('course_type_id', [2, 3])
    //         ->first();

    //       if ($course) {
    //         $profitAmount = $training->overall_fees - $course->course_min_price;
    //         $originalAmount += $profitAmount;

    //         $profitPercent = ($course->course_min_price != 0) ? ($profitAmount / $course->course_min_price) * 100 : 0;

    //         foreach ($pi_slabs as $slab) {
    //           if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
    //             $slabPercentage = $slab['percentage'];
    //             break;
    //           }
    //         }
    //       }
    //     }
    //   }
    // }

    $piReward = $slabPercentage > 0 ? ($originalAmount * $slabPercentage) / 100 : 0;

    if ($tenxStatus && $piReward > 0) {
      $totalReward += $piReward;
      $breakdown['PI Award'] = $piReward;
    }

    // 12. LI Award (Luxury Incentive)
    $luxury = json_decode($incentive->luxury_incentive ?? '{}', true);
    $allIncentivesAchieved = ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward > 0);

    if ($allIncentivesAchieved) {
      $liReward = $luxury['reward'] ?? 0;
      $totalReward += $liReward;
      $breakdown['LI Award'] = $liReward;
    }

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'conversion_rate' => $actualConversion,
        'target_conversion' => $targetConversion,
        'tenx_status' => $tenxStatus
      ]
    ];
  }

  /**
   * Calculate Team Lead Reward
   */
  private static function calculateTeamLeadReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    // Check if sales lead check is enabled
    $checkRecord = GoalSetStaffModel::where('branch_id', $branchId)
      ->where('goal_month', $month)
      ->whereMonth('goal_date', $month)
      ->whereYear('goal_date', $year)
      ->where('staff_id', $staff->sno)
      ->first();

    if ($checkRecord && $checkRecord->sales_lead_check == 1) {
      // Sales Team Lead - use sales executive logic but aggregated for team
      return self::calculateSalesExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month);
    } else {
      // Regular Team Lead - aggregate from executives
      $executives = StaffModel::where('branch_id', $branchId)
        ->where('department_id', $staff->department_id)
        ->where('role_id', 11)
        ->where('status', 0)
        ->get();

      $totalTeamReward = 0;
      $teamBreakdown = [];

      foreach ($executives as $executive) {
        $executiveGoalData = GoalSetStaffModel::where('staff_id', $executive->sno)
          ->where('goal_month', $month)
          ->whereYear('goal_date', $year)
          ->first();

        if ($executiveGoalData && ($executiveGoalData->conversion ?? 0) > 0) {
          $result = self::calculateSalesExecutiveReward($executive, $incentive, $executiveGoalData, $branchId, $year, $month);

          if ($result['metrics']['tenx_status'] ?? false) {
            $totalTeamReward += $incentive->tenx_award ?? 0;
            $teamBreakdown[$executive->staff_name] = $incentive->tenx_award ?? 0;
          }
        }
      }

      return [
        'total' => $totalTeamReward,
        'breakdown' => $teamBreakdown,
        'metrics' => ['team_size' => count($executives)]
      ];
    }
  }

  /**
   * Calculate Collection Reward
   */
  private static function calculateJournalExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

  

    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth();

      $currentMonthJournal = Carbon::createFromDate($year, $month, 1);
      $lastTwoMonths = [
          $currentMonthJournal->copy()->subMonth(1),
          $currentMonthJournal->copy()->subMonth(2),
      ];
    

      $goalsetteamLast = GoalSetStaffModel::where('staff_id', $staff->sno)
          ->where('status_10x', 1)
          ->where(function ($query) use ($lastTwoMonths) {
              foreach ($lastTwoMonths as $date) {
                  $query->orWhere(function ($q) use ($date) {
                      $q->whereMonth('goal_date', $date->month)
                      ->whereYear('goal_date', $date->year);
                  });
              }
          })
          ->get();

      $isConsistent = $goalsetteamLast->count() == 2;
             
        $branch = BranchModel::where('sno', $branchId)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();
        

      $publish_target= $goalData->no_of_papers ?? 8;

        if( $incentive ){
            $check_accepted_paper=$incentive->check_accepted_paper ?? 0;
            $tenx_amount = $incentive->tenx_award ?? 0;
            $exiTarget = $publish_target ?? 0;
            $exiAcheiveAmount = $incentive->extra_acheive_award ?? 0;
            $doubleXITarget = $publish_target ? $publish_target*2 : 0;
            $doubleXIAmount= $incentive->doublex_award ?? 0;
            $perform_attend_percent= $incentive->perform_incent_attend ?? 0;
            $performance_incentive_reward = $incentive->performance_incentive_reward ?? 0;
        }else{
            $check_accepted_paper=1;
            $tenx_amount =  0;
            $exiTarget = 0;
            $exiAcheiveAmount =  0;
            $doubleXITarget =  0;
            $doubleXIAmount=  0;
            $perform_attend_percent=  0;
            $performance_incentive_reward =  0;
        }
            $publicationCurrentMonthCount = 0;
            
            $tenxStatus = false;
            $exiStatus = false;
            $doubleXIncent = false;
            $permformJCIncent = false;
            $priviousGoalsetAwared = $isConsistent ? true:false;



            $publicationCurrentMonthCount = DB::table('et_manage_journal as mj')
                ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                ->leftJoin('et_journal_history as jh', function ($join) {
                    $join->on('mj.sno', '=', 'jh.journal_id')
                        ->where('jh.status', 5);
                });

            if ($check_accepted_paper == 1) {
                //  Added 7 here
                $publicationCurrentMonthCount = $publicationCurrentMonthCount->whereIn('mj.status', [5, 7, 8]);
            } else {
                $publicationCurrentMonthCount = $publicationCurrentMonthCount->where('mj.status', 8);
            }

            $publicationCurrentMonthCount = $publicationCurrentMonthCount
                ->where('cs.jc_staff', $staff->sno)
                ->where(function ($query) use ($year, $month) {

                    $query->where(function ($q) use ($year, $month) {
                        $q->where('mj.status', 8)
                        ->whereYear('mj.publish_date', $year)
                        ->whereMonth('mj.publish_date', $month);
                    })

                    ->orWhere(function ($q) use ($year, $month) {
                        $q->whereIn('mj.status', [5, 7]) //  include 7 here also
                        ->whereYear('jh.accepted_date', $year)
                        ->whereMonth('jh.accepted_date', $month);
                    });

                })
                ->count();

            $publicationCurrentMonthData = DB::table('et_manage_journal as mj')
                ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                ->leftJoin('et_journal_history as jh', function ($join) {
                    $join->on('mj.sno', '=', 'jh.journal_id')
                        ->where('jh.status', 5);
                });

            if ($check_accepted_paper == 1) {
                $publicationCurrentMonthData = $publicationCurrentMonthData->whereIn('mj.status', [5, 7, 8]);
            } else {
                $publicationCurrentMonthData = $publicationCurrentMonthData->where('mj.status', 8);
            }

            $publicationCurrentMonthData = $publicationCurrentMonthData
                ->where('cs.jc_staff', $staff->sno)
                ->where(function ($query) use ($year, $month) {

                    $query->where(function ($q) use ($year, $month) {
                        $q->where('mj.status', 8)
                        ->whereYear('mj.publish_date', $year)
                        ->whereMonth('mj.publish_date', $month);
                    })

                    ->orWhere(function ($q) use ($year, $month) {
                        $q->whereIn('mj.status', [5, 7])
                        ->whereYear('jh.accepted_date', $year)
                        ->whereMonth('jh.accepted_date', $month);
                    });

                })
                  ->orderByRaw("
                    CASE 
                        WHEN mj.status IN (5, 7) THEN jh.accepted_date
                        ELSE mj.publish_date
                    END ASC
                ")
                ->limit($exiTarget)
                ->pluck('mj.sno');
                        
        $publicationAfter15thCount = DB::table('et_manage_journal as mj')
            ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
            ->leftJoin('et_journal_history as jh', function ($join) {
                $join->on('mj.sno', '=', 'jh.journal_id')
                    ->where('jh.status', 5);
            });
              if ($check_accepted_paper == 1) {
                $publicationAfter15thCount = $publicationAfter15thCount->whereIn('mj.status', [5, 7, 8]);
            } else {
                $publicationAfter15thCount = $publicationAfter15thCount->where('mj.status', 8);
            }

            $publicationAfter15thCount = $publicationAfter15thCount
                ->where('cs.jc_staff', $staff->sno)
                ->whereNotIn('mj.sno',$publicationCurrentMonthData)
                ->where(function ($query) use ($year, $month) {

                    $query->where(function ($q) use ($year, $month) {
                        $q->where('mj.status', 8)
                        ->whereYear('mj.publish_date', $year)
                        ->whereMonth('mj.publish_date', $month)
                        ->whereDay('mj.publish_date', '<=', 15);
                    })

                    ->orWhere(function ($q) use ($year, $month) {
                          $q->whereIn('mj.status', [5, 7])
                        ->whereYear('jh.accepted_date', $year)
                        ->whereMonth('jh.accepted_date', $month)
                        ->whereDay('jh.accepted_date', '<=', 15);
                    });

                })
                ->count();
                        
            
            $tenxStatus = ($publicationCurrentMonthCount >=$publish_target);
            $exiStatus = ($publicationCurrentMonthCount >=$exiTarget);
            $exiAmountAward = $publicationAfter15thCount > 0 ? $publicationAfter15thCount *$exiAcheiveAmount : 0;
            $doubleXIncent = ($publicationCurrentMonthCount >=$doubleXITarget);

              $startDate = Carbon::create($year, $month, 1);
            $currentDate = Carbon::now();
            $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();

            $dayCounts = 0;
            $dateSrt = $startDate->copy();
            while ($dateSrt->lte($endDate)) {
                if (!$dateSrt->isSunday()) {
                    $dayCounts++;
                }
                $dateSrt->addDay();
            }
            
          
            $presentDays = DB::table('et_staff_attendance')
                ->whereIn('et_staff_attendance.attendance', ['P','HD','PR','OD'])
                ->where('et_staff_attendance.staff_id', $staff->sno) 
                // ->where('et_staff_attendance.staff_id', 62) 
                ->whereYear('et_staff_attendance.date', $year)
                ->whereMonth('et_staff_attendance.date', $month)
                ->count();
            
            $attendance_percent= $dayCounts >0 ? round(($presentDays / $dayCounts) * 100, 1) :0;
          
          $permformJCIncent = (
                $attendance_percent > 0 && 
                $attendance_percent >= $perform_attend_percent && $priviousGoalsetAwared
            );

            $breakdown['10X Award'] = $tenxStatus ? ($tenx_amount ?? 0) : 0;
            $totalReward +=  $tenxStatus ? ($tenx_amount ?? 0) : 0;
            $breakdown['Bonus Award'] = ($tenxStatus && $exiStatus) ? ($exiAmountAward ?? 0) : 0;
            $totalReward += ($tenxStatus && $exiStatus) ? ($exiAmountAward ?? 0) : 0;
            $breakdown['2X Award'] =  ($tenxStatus && $doubleXIncent) ? $doubleXIAmount : 0;
            $totalReward +=  ($tenxStatus && $doubleXIncent) ? $doubleXIAmount : 0;
            $breakdown['Performance'] =  ($tenxStatus && $permformJCIncent)? ($performance_incentive_reward) : 0;
            $totalReward +=  ($tenxStatus && $permformJCIncent)? ($performance_incentive_reward) : 0;
           
    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'published_amount' => $tenxStatus ? ($tenx_amount ?? 0) : 0,
        'bonus_amount' => ($tenxStatus && $exiStatus) ? ($exiAmountAward ?? 0) : 0,
      ]
    ];
  }

  /**
   * Calculate PC (Process Coordinator) Reward
   */
  private static function calculatePCReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    return self::calculateProductionReward($staff, $incentive, $goalData, $branchId, $year, $month);
  }

  /**
   * Calculate CRE (Customer Relationship Executive) Reward
   */
  private static function calculateCREReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

        $helper = new \App\Helpers\Helpers();

        $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

        $targetTenx = $goalData->harvesting_percentage ?? 0;
        if($incentive){
            $eci_target = $incentive->eci_count ?? 0;
            $bi_target_percent = $incentive->bi_amount ?? 0;
            $bi_target = $targetTenx ?? 0;
            $spot_cre_incentive_target = $incentive->spot_incentive_percent ?? 0;
            $spot_cre_incentive_reward = $incentive->spot_incentive_month ?? 0;
            $ri_reward = $incentive->ri_amount ?? 0;
        }else{
              $eci_target = 0;
              $bi_target = $targetTenx ;
              $bi_target_percent =0;
              $spot_cre_incentive_target = 0;
              $spot_cre_incentive_reward = 0;
              $ri_reward = 0;
        }
                
        $firstPayIds = DB::table('et_proposal_pay_slot')
          ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
          ->where('et_proposal.status', 0)
          ->where('et_proposal_pay_slot.status', 0)
          ->where('et_proposal.cre_id', $staff->sno)
          ->whereNotIn('et_proposal.proposal_status', [0,1,2])
          ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
          ->groupBy('et_proposal_pay_slot.proposal_sno')
          ->orderBy('first_id', 'asc')
          ->pluck('first_id');

        $cutoffDate = Carbon::create($year, $month, 15)->format('Y-m-d');
        $tenxStatus = false;
        $actaulTenx = 0;
        $gstPercentage=18;

      $tragetHarvestingIds = DB::table('et_proposal_pay_slot')
                ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                ->where('et_customer.status', 0)
                ->where('et_proposal.cre_id', $staff->sno)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as pay_slot_id'))
                ->groupBy('et_proposal_pay_slot.proposal_sno')
                ->orderBy('pay_slot_id', 'asc')
                ->pluck('pay_slot_id');

        $tragetHarvesting = DB::table('et_proposal_pay_slot')
                ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                ->where('et_customer.status', 0)
                ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                ->where('et_proposal.cre_id', $staff->sno)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(
                    "et_proposal_pay_slot.payable_amount as payable_amount",
                    "et_transaction.payment_status",
                    "et_transaction.total_amount_inr",
                    "et_payment.paid_amount",
                    "et_proposal.gst_perc",
                    "et_country_currencies.currency_code as currency_code"
                )
                ->get()
                ->map(function ($row) use ($gstPercentage, $helper,$branch) {
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($branch ? $gstPercentage / 100 : 0.18);
            
                    // Calculate the converted amount based on the payment status and currency
                    if ($row->payment_status == 1) {
                        if ($row->currency_code != "INR") {
                            $converted = ($row->total_amount_inr && $row->total_amount_inr > 0)
                                ? $row->total_amount_inr
                                : $row->paid_amount;
                        } else {
                            $converted = $row->paid_amount;
                        }
                        $netAmount = $converted / (1 + $gstRate);
                    } else if ($row->currency_code != "INR") {
                        $converted = $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);
                        $netAmount = $converted / (1 + $gstRate);
                    } else {
                        $converted = $row->payable_amount;
                        $netAmount = $converted / (1 + $gstRate);
                    }
            
                    return $netAmount;
                })
                ->reduce(function ($carry, $item) {
                    // Sum the values and round to 1 decimal place
                    return $carry + $item;
                }, 0);
            
     
                $tragetHarvesting = round($tragetHarvesting);
            $collectionHarvesting = DB::table('et_proposal_pay_slot')
                ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                ->where('et_customer.status', 0)
                ->where('et_transaction.payment_status', 1)
                ->where('et_proposal.cre_id', $staff->sno)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(
                    "et_proposal_pay_slot.payable_amount as payable_amount",
                    "et_transaction.payment_status",
                    "et_transaction.total_amount_inr",
                    "et_payment.paid_amount",
                    "et_proposal.gst_perc",
                    "et_country_currencies.currency_code as currency_code"
                )
                ->get()
                ->map(function ($row) use ($gstPercentage, $helper) {
                    // ✅ Prefer INR amount from transaction if available
                    $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                        ? $row->total_amount_inr
                        : $row->paid_amount;
            
                    // ✅ Use proposal-specific GST, fallback to branch GST
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);
            
                    // ✅ Net without GST
                    $netAmount = $amountInr / (1 + $gstRate);
            
                    // Round the net amount to two decimal places
                    return round($netAmount, 2);
                })
                ->reduce(function ($carry, $item) {
                    // Sum the values and round to 2 decimal places
                    return round($carry + $item, 2);
                }, 0);

                $collectionHarvesting = round($collectionHarvesting, 1);
                
                
                
                 $collectionEci = DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                    ->where('et_customer.status', 0)
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_proposal.cre_id', $staff->sno)
                    ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                    ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                    ->select(
                        "et_proposal_pay_slot.payable_amount as payable_amount",
                        "et_transaction.payment_status",
                        "et_transaction.total_amount_inr",
                        "et_payment.paid_amount",
                        "et_proposal.gst_perc",
                        "et_country_currencies.currency_code as currency_code"
                    )
                    ->get()
                    ->map(function ($row) use ($gstPercentage, $helper) {
                        // ✅ Prefer INR amount from transaction if available
                        $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                            ? $row->total_amount_inr
                            : $row->paid_amount;
                
                        // ✅ Use proposal-specific GST, fallback to branch GST
                        $gstRate = $row->gst_perc > 0
                            ? $row->gst_perc / 100
                            : ($gstPercentage ? $gstPercentage / 100 : 0.18);
                
                        // ✅ Net without GST
                        $netAmount = $amountInr / (1 + $gstRate);
                
                        // Round the net amount to two decimal places
                        return round($netAmount, 2);
                    })
                    ->reduce(function ($carry, $item) {
                        // Sum the values and round to 2 decimal places
                        return round($carry + $item, 2);
                    }, 0);

                $collectionEci = round($collectionEci, 1);
                
                 $collectionSpot = DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                    ->where('et_customer.status', 0)
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_proposal.cre_id', $staff->sno)
                    ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                    ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->select(
                        "et_proposal_pay_slot.payable_amount as payable_amount",
                        "et_transaction.payment_status",
                        "et_transaction.total_amount_inr",
                        "et_payment.paid_amount",
                        "et_proposal.gst_perc",
                        "et_country_currencies.currency_code as currency_code"
                    )
                    ->get()
                    ->map(function ($row) use ($gstPercentage, $helper) {
                        // ✅ Prefer INR amount from transaction if available
                        $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                            ? $row->total_amount_inr
                            : $row->paid_amount;
                
                        // ✅ Use proposal-specific GST, fallback to branch GST
                        $gstRate = $row->gst_perc > 0
                            ? $row->gst_perc / 100
                            : ($gstPercentage ? $gstPercentage / 100 : 0.18);
                
                        // ✅ Net without GST
                        $netAmount = $amountInr / (1 + $gstRate);
                
                        // Round the net amount to two decimal places
                        return round($netAmount, 2);
                    })
                    ->reduce(function ($carry, $item) {
                        // Sum the values and round to 2 decimal places
                        return round($carry + $item, 2);
                    }, 0);

                $collectionSpot = round($collectionSpot, 1);
                
                $monthlyTargets = [];
            

                // ! 10x Award
                $monthlyCollectionsINR = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection')
                    )
                    ->get()
                    ->keyBy('staff_id');

                $monthlyCollectionsOther = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', '!=', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id', 'et_country_currencies.currency_code')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        'et_country_currencies.currency_code',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection')
                    )
                    ->get()
                    ->keyBy('staff_id');

                $convertedCollections = [];
                foreach ($monthlyCollectionsOther as $staffId => $target1) {
                    $convertedAmount = $helper->ConvertedAmountInr($target1->currency_code, $target1->monthly_collection);
                    if (!isset($convertedCollections[$staffId])) {
                        $convertedCollections[$staffId] = 0;
                    }
                    $convertedCollections[$staffId] += $convertedAmount;
                }

                $monthlyCollections = [];
                foreach ($monthlyCollectionsINR as $staffId => $inrCollection) {
                    $monthlyCollections[$staffId] = [
                        'total_collection_inr' => $inrCollection->monthly_collection,
                    ];
                }

                // Add converted non-INR amounts to the collection array
                foreach ($convertedCollections as $staffId => $convertedAmount) {
                    if (isset($monthlyCollections[$staffId])) {
                        $monthlyCollections[$staffId]['total_collection_inr'] += $convertedAmount;
                    } else {
                        $monthlyCollections[$staffId] = [
                            'total_collection_inr' => $convertedAmount,
                        ];
                    }
                }

                // ! Early Cash Incentive
                $cre_eci_inr = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as collection_by_15th')
                    )
                    ->get()
                    ->keyBy('staff_id');

                $cre_eci_other = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', '!=', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id', 'et_country_currencies.currency_code')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        'et_country_currencies.currency_code',
                        DB::raw('SUM(et_payment.paid_amount) as collection_by_15th')
                    )
                    ->get()
                    ->keyBy('staff_id');

                $convertedCollectionsBy15th = [];
                foreach ($cre_eci_other as $staffId => $target2) {
                    $convertedAmount = $helper->ConvertedAmountInr($target2->currency_code, $target2->collection_by_15th);

                    if (!isset($convertedCollectionsBy15th[$staffId])) {
                        $convertedCollectionsBy15th[$staffId] = 0;
                    }

                    $convertedCollectionsBy15th[$staffId] += $convertedAmount;
                }

                $collectionsBy15th = [];
                foreach ($cre_eci_inr as $staffId => $inrCollection) {
                    $collectionsBy15th[$staffId] = [
                        'total_collection_eci' => $inrCollection->collection_by_15th,
                    ];
                }

                // Add converted foreign currency collections
                foreach ($convertedCollectionsBy15th as $staffId => $convertedAmount) {
                    if (isset($collectionsBy15th[$staffId])) {
                        $collectionsBy15th[$staffId]['total_collection_eci'] += $convertedAmount;
                    } else {
                        $collectionsBy15th[$staffId] = [
                            'total_collection_eci' => $convertedAmount,
                        ];
                    }
                }

                // ! Spot Incentive
                $cre_spot_INR = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection_before_next_paydate')
                    )
                    ->get()
                    ->keyBy('staff_id');

                $cre_spot_Other = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection_before_next_paydate')
                    )
                    ->get()
                    ->keyBy('staff_id');

                // Convert foreign currency collections to INR
                $convertedCollectionsSpotOther = [];
                foreach ($cre_spot_Other as $staffId => $collection) {
                    $convertedAmount = $helper->ConvertedAmountInr($collection->currency_code ?? 'default_currency_code', $collection->monthly_collection_before_next_paydate);

                    if (!isset($convertedCollectionsSpotOther[$staffId])) {
                        $convertedCollectionsSpotOther[$staffId] = 0;
                    }

                    $convertedCollectionsSpotOther[$staffId] += $convertedAmount;
                }

                // Prepare INR collections
                $collectionsSpotINR = [];
                foreach ($cre_spot_INR as $staffId => $collection) {
                    $collectionsSpotINR[$staffId] = [
                        'total_collection_spot' => $collection->monthly_collection_before_next_paydate,
                    ];
                }

                // Combine converted foreign collections into INR collections
                foreach ($convertedCollectionsSpotOther as $staffId => $convertedAmount) {
                    if (isset($collectionsSpotINR[$staffId])) {
                        $collectionsSpotINR[$staffId]['total_collection_spot'] += $convertedAmount;
                    } else {
                        $collectionsSpotINR[$staffId] = [
                            'total_collection_spot' => $convertedAmount,
                        ];
                    }
                }


                // Referal Incentive
                $cre_ref_count =  DB::table('et_proposal')
                ->select(
                    'et_proposal.service_title',
                    'et_customer.sno',
                    'et_customer.cus_name',
                    'et_customer.country_code',
                    'et_customer.cus_mobile',
                    'et_payment.transaction_date as created_date',
                    'et_payment.transaction_date as created_at',
                    'et_transaction.payment_id',
                    'et_transaction.sno as transaction_id',
                    'et_payment.paid_amount'
                )
                ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
                ->where('et_proposal.branch_id', $branchId)
                ->where('et_proposal.referral_id', $staff->sno)
                ->where('et_proposal.status', 0)
                ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->where('et_payment.status', 0)
                ->orderBy('et_proposal.sno', 'asc')
                ->count();

               $collection = 0;

                $collection = $collectionHarvesting ?? 0;
                $collectionPercentage = $tragetHarvesting > 0 ? ($collection / $tragetHarvesting) * 100 : 0;
                $collectionPercentage=round($collectionPercentage);
                $tenxStatus = $targetTenx > 0 ? $collectionPercentage >= $targetTenx : false;
                
               
                // ! Early Cash Incentive
                $eci_collection = $collectionEci ?? 0;
                $eci_percentage = $tragetHarvesting > 0 ? ($eci_collection / $tragetHarvesting) * 100 : 0;
                $eci_achieved = ($eci_target && $eci_percentage >= $eci_target) ? $eci_target : 0;

                //    return $collectionSpot;
                //  ! Spot Incentive
                $spot_collection = $collectionSpot ??  0;
                $spot_percentage = $collection > 0 ? ($spot_collection / $collection) * 100 : 0;
                $spot_achieved = $spot_percentage >= ($spot_cre_incentive_target ?? 0);
                
                $bi_value =0;
                $bonusAmount =0;
                $excessValue =0;
                if ($collectionPercentage > $bi_target) {
                    $excessPercentage = $collectionPercentage - $bi_target;
                   
                    $excessValue = ($excessPercentage / 100) * $tragetHarvesting;
                    $bi_value =($bi_target_percent / 100);
                    
                    $bonusAmount = round($excessValue * $bi_value); 
                }
                // ! Bonus Incentive
                
               
                $bi_achieved = (($bi_target) && $collectionPercentage > $bi_target) ? true : false;
                $bi_reward = $bi_achieved ? $bonusAmount : 0;

                // ! Referal Incentive
                $ri_amount = ($cre_ref_count ?? 0) * $ri_reward;
                $ri_achieved = $ri_amount > 0;

                // ! Luxury Incentive
                $luxuryData = $incentive && isset($incentive->luxury_incentive) ? json_decode($incentive->luxury_incentive, true) : [];
                $early_cash_incentive = $luxuryData['early_cash_incentive'] ?? 0;
                $tenx_award_luxury = $luxuryData['tenx_award'] ?? 0;
                $bonus_incentive = $luxuryData['bonus_incentive'] ?? 0;
                $spot_incentive = $luxuryData['spot_incentive'] ?? 0;
                $referral_incentive = $luxuryData['referral_incentive'] ?? 0;
                $reward = $luxuryData['reward'] ?? '0';
                // $tenxStatus=false;
                $tenx_luxury_achieved = $tenx_award_luxury ? ($tenxStatus ? true : false) : true ;
                $bi_luxury_achieved = $bonus_incentive ? ($bi_achieved ? true : false) : true ;
                $spi_luxury_achieved = $spot_incentive ? ($spot_achieved ? true : false) : true ;
                $ri_luxury_achieved = $referral_incentive ? ($ri_achieved ? true : false) : true ;
                // $luxury_achieved = ($tenxStatus && $early_cash_incentive && $eci_achieved && $bonus_incentive && $bi_achieved && $spot_incentive && $spot_achieved&& $referral_incentive && $ri_achieved);
                $luxury_achieved = ($tenx_luxury_achieved && $bi_luxury_achieved && $spi_luxury_achieved && $ri_luxury_achieved);;


   

    

    

    
    $totalReward  += $tenxStatus ? $incentive->tenx_award : 0;
    $totalReward  += ($tenxStatus && $eci_achieved) ? $incentive->eci_reward : 0 ;
    $totalReward  += ($tenxStatus && $bi_achieved) ? $bi_reward : 0 ;
    $totalReward  += ($tenxStatus && $spot_achieved) ? ($spot_cre_incentive_reward ?? 0) : 0 ;
    $totalReward  += ( $ri_achieved) ? $ri_amount : 0;
    $totalReward  += $luxury_achieved ? $reward : 0;
    $breakdown['10X Award'] = $tenxStatus ? $incentive->tenx_award : 0;
    $breakdown['ECI Award'] =($tenxStatus && $eci_achieved) ? $incentive->eci_reward : 0 ;
    $breakdown['BI Award'] = ($tenxStatus && $bi_achieved) ? $bi_reward : 0 ;
    $breakdown['SP Award'] =($tenxStatus && $spot_achieved) ? ($spot_cre_incentive_reward ?? 0) : 0 ;
    $breakdown['REI Award'] = ( $ri_achieved) ? $ri_amount : 0;
    $breakdown['REI Award'] = $luxury_achieved ? $reward : 0;
 

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'collection' => round($collectionPercentage),
        'eci' => round($eci_percentage),
        'bonus' => $excessValue > 0 ? round($excessValue) : 0 ,
        'Spot' => $spot_achieved? round($spot_percentage) : 0 ,
        'referrals' => $cre_ref_count
      ]
    ];
  }

  /**
   * Calculate Production Reward
   */
  private static function calculateProductionReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

    // Calculate earned amount from attendance
    $earned_amount = 0;
    $batchIds = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $staff->sno)
      ->distinct()
      ->pluck('batch_id')
      ->toArray();

    foreach ($batchIds as $batchId) {
      $batch = DB::table('za_batch')->find($batchId);
      if ($batch) {
        $startTime = Carbon::parse($batch->start_time);
        $endTime = Carbon::parse($batch->end_time);
        $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

        $attendanceRecords = DB::table('za_attendance')
          ->where('batch_id', $batchId)
          ->where('staff_id', $staff->sno)
          ->where('attendance', 'P')
          ->whereMonth('att_date', $month)
          ->whereYear('att_date', $year)
          ->get();

        foreach ($attendanceRecords as $attendance) {
          $earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
        }
      }
    }

    // Student count
    $studentCount = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $staff->sno)
      ->whereMonth('start_date', '<=', $month)
      ->whereYear('start_date', '<=', $year)
      ->whereMonth('end_date', '>=', $month)
      ->whereYear('end_date', '>=', $year)
      ->distinct('customer_id')
      ->count('customer_id');

    // Get referrals
    $refferal_count = DB::table('za_referral_persons')
      ->where('branch_id', $branchId)
      ->where('referral_id', $staff->sno)
      ->where('status', 0)
      ->where('referral_type', 2)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Get team goals
    $goalsetteam = GoalSetTeamModel::where('branch_id', $branchId)
      ->where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->first();

    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isProductionCostingRequired = ($ten_x['production_costing_10x'] ?? '0') == "1";

    if ($isProductionCostingRequired) {
      $basic_pay = ($staff->basic_salary ?? 0) * 10;
      $costing_amount_asign = $goalData->production_costing ?? 0;
      $costing_amount = $basic_pay > 0 ? ($earned_amount / $basic_pay) * $costing_amount_asign : 0;

      $targetTenx = $costing_amount_asign;
      $actaulTenx = $costing_amount;
      $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;
    } else {
      $targetTenx = $goalData->reference_sales ?? 0;
      $actaulTenx = $refferal_count;
      $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;
    }

    if ($tenxStatus) {
      $tenxReward = $incentive->tenx_award ?? 0;
      $totalReward += $tenxReward;
      $breakdown['10X Award'] = $tenxReward;
    }

    // PDI Award (Production Incentive)
    $slabs = json_decode($incentive->pdi_slab_json ?? '[]', true);
    $slabPercentage = 0;

    foreach ($slabs as $slab) {
      if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    if ($tenxStatus && $slabPercentage > 0) {
      $totalReward += $slabPercentage;
      $breakdown['PDI Award'] = $slabPercentage;
    }

    // Reference Incentive
    $targetREI = $goalData->reference_sales ?? 0;
    $REIStatus = $targetREI != 0 && $refferal_count >= $targetREI;

    if ($REIStatus) {
      $reiReward = $refferal_count * ($incentive->reference_incentive ?? 0);
      $totalReward += $reiReward;
      $breakdown['REI Award'] = $reiReward;
    }

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'earned_amount' => $earned_amount,
        'student_count' => $studentCount,
        'referral_count' => $refferal_count
      ]
    ];
  }

  /**
   * Calculate PE (Placement Executive) Reward
   */
  private static function calculatePlacementExecutiveReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

    // Get team goals with validation
    $goalsetteam = GoalSetTeamModel::where('branch_id', $branchId)
      ->where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->first();

    if (!$goalsetteam) {
      return ['total' => 0, 'breakdown' => [], 'metrics' => []];
    }

    // Optimize queries - get counts in one go if possible
    $tesboCount = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staff->sno)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    $othersSlab = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', '!=', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staff->sno)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    $referralCount = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staff->sno)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // 10X Award
    if ($goalsetteam->no_of_placements_check == 1) {
      $targetTenx = $goalData->no_of_reviews ?? 0;
      $actualTenx = $tesboCount;

      if ($targetTenx > 0 && $actualTenx >= $targetTenx) {
        $tenxReward = $incentive->tenx_award ?? 0;
        $totalReward += $tenxReward;
        $breakdown['10X Award'] = $tenxReward;
      }
    }

    // REI Award (Reference Incentive)
    $targetREI = $goalData->reference_sales ?? 0;
    $reiReward = $referralCount * ($incentive->reference_incentive ?? 0);
    $totalReward += $reiReward;
    $breakdown['REI Award'] = $reiReward;

    // PDI Award (Tesbo students)
    $pieSlabs = json_decode($incentive->pie_slab_json ?? '[]', true);
    $slabPercentage = 0;

    foreach ($pieSlabs as $slab) {
      if ($tesboCount >= $slab['min'] && $tesboCount <= $slab['max']) {
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    // Calculate PDI reward - FIX: Need proper calculation based on your business logic
    $pdiReward = $tesboCount * ($slabPercentage / 100); // Example: percentage of count
    // Or if it's a fixed amount based on slab: $pdiReward = $slabPercentage;
    $totalReward += $pdiReward;
    $breakdown['PDI Award'] = $pdiReward;

    // Others Award (Non-Tesbo students)
    $oieSlabs = json_decode($incentive->oie_slab_json ?? '[]', true);
    $slabPercentageOi = 0;

    foreach ($oieSlabs as $slab) {
      if ($othersSlab >= $slab['min'] && $othersSlab <= $slab['max']) {
        $slabPercentageOi = $slab['percentage'];
        break;
      }
    }

    // Calculate Others reward - FIX: Need proper calculation
    $othersReward = $othersSlab * ($slabPercentageOi / 100); // Example calculation
    $totalReward += $othersReward;
    $breakdown['Others Award'] = $othersReward;

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'placement' => $tenxReward,
        'referrals' => $reiReward,
        'pdi'       => $pdiReward,      // Fixed: show actual reward or count?
        'others'    => $othersSlab,   // Fixed: show actual count
      ]
    ];
  }


  /**
   * Calculate PL (Placement Lead) Reward
   */
  private static function calculatePlacementLeadReward($staff, $incentive, $goalData, $branchId, $year, $month)
  {
    $totalReward = 0;
    $breakdown = [];

    // Get reviews count
    $review_count = DB::table('za_review')
      ->where('branch_id', $branchId)
      ->where('created_by', $staff->sno)
      ->where('status', 0)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Get referrals count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staff->sno)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Get team goals
    $goalsetteam = GoalSetTeamModel::where('branch_id', $branchId)
      ->where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->first();

    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isNoOfReviewsRequired = ($ten_x['no_of_reviews_10x'] ?? '0') == "1";

    if ($isNoOfReviewsRequired) {
      $targetTenx = $goalData->no_of_reviews ?? 0;
      $actaulTenx = $review_count;
      $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;

      if ($tenxStatus) {
        $tenxReward = $incentive->tenx_award ?? 0;
        $totalReward += $tenxReward;
        $breakdown['10X Award'] = $tenxReward;
      }
    } else {
      $targetTenx = $goalData->reference_sales ?? 0;
      $actaulTenx = $refferal_count;
      $tenxStatus = $targetTenx != 0 && $actaulTenx >= $targetTenx;

      if ($tenxStatus) {
        $tenxReward = $incentive->tenx_award ?? 0;
        $totalReward += $tenxReward;
        $breakdown['10X Award'] = $tenxReward;
      }
    }

    // Reference Incentive
    $targetREI = $goalData->reference_sales ?? 0;
    $REIStatus = $targetREI != 0 && $refferal_count >= $targetREI;

    // if ($REIStatus) {
    $reiReward = $refferal_count * ($incentive->reference_incentive ?? 0);
    $totalReward += $reiReward;
    $breakdown['REI Award'] = $reiReward;
    // }

    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'reviews' => $review_count,
        'referrals' => $refferal_count
      ]
    ];
  }

  /**
   * Get empty response
   */
  private static function getEmptyResponse()
  {
    return [
      'total_award' => 0,
      'breakdown' => [],
      'currency' => 'INR',
      'last_updated' => now()->toDateTimeString(),
      'next_update' => now()->addHours(2)->toDateTimeString(),
      'error' => 'No incentive configuration found'
    ];
  }

    
}