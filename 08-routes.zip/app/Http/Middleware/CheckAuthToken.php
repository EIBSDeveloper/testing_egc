<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Laravel\Sanctum\PersonalAccessToken;

class CheckAuthToken
{
    public function handle(Request $request, Closure $next)
    {
        if ($token = Cookie::get('auth_token')) {
            $tokenModel = PersonalAccessToken::findToken($token);

            if ($tokenModel && $tokenModel->tokenable) {
                Auth::login($tokenModel->tokenable);
            }
        }

        return $next($request);
    }
}