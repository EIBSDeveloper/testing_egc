<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class SetTimeZone
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */

     public function handle($request, Closure $next)
    {
            // Check if user is authenticated
        if (!Auth::guard('web')->check()) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $user = $request->user();
        // dd($user);
        if (!$user) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $branchId = $user->branch_id;
        $branch = DB::table('et_branch')
            ->where('et_branch.sno', $branchId)
            ->join('et_countrytimezones', 'et_branch.time_zone_id', '=', 'et_countrytimezones.sno')
            ->select('et_countrytimezones.time_zone')
            ->first();

        if ($branch && $branch->time_zone) {
            Config::set('app.timezone', $branch->time_zone);
            date_default_timezone_set($branch->time_zone);
        }
        // if ($branch) {
        //     $timeZone = $branch->time_zone;

        //     // If a time zone is set, update the application configuration
        //     if ($timeZone) {
        //         Config::set('app.timezone', $timeZone);
        //         date_default_timezone_set($timeZone);
        //     }
        // }
        

        return $next($request);
    }
    // public function handle($request, Closure $next)
    // {
    //     if (Auth::check()) {
    //         $branchId = Auth::user()->branch_id;

    //         $generalSetting = DB::table('et_general_settings')
    //             ->join('et_countrytimezones', 'et_general_settings.time_zone', '=', 'et_countrytimezones.sno')
    //             ->where('et_general_settings.branch_id', $branchId)
    //             ->select('et_countrytimezones.time_zone')
    //             ->first();

    //         if ($generalSetting) {
    //             $timeZone = $generalSetting->time_zone;

    //             if ($timeZone) {
    //                 Config::set('app.timezone', $timeZone);
    //                 date_default_timezone_set($timeZone);
    //             }
    //         }
    //     } else {
    //         return redirect()->route('login');
    //     }

    //     return $next($request);
    // }
}