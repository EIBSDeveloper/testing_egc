<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GeneralSettingsModel extends Model
{
    use HasFactory;
    public $table      = "et_general_settings";
    public $primaryKey = 'sno';


    protected $fillable = [
        'title',
        'logo',
        'fav_icon',
        'url',
        'email_id',
        'phone_number',
        'whatsapp_number',
        'date_format',
        'registered_name',
        'tax_no',
        'language',
        'country',
        'state',
        'city',
        'address',
        'pincode',
        'currency_format',
        'created_by',
        'created_at',
        'max_document_send_limit',
        'hot_lead_days',
        'hot_lead_limit',
        'status',
    ];
}
