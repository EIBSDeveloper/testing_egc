<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Folder extends Model
{
    protected $fillable = [
        'google_drive_folder_id',
        'google_drive_folder_name',
        'folder_link',
        'total_files',
        'total_size',
        'files',
        'user_folder_name',
        'upload_time',
        'upload_start_time',
        'upload_end_time',
        'total_upload_duration',
        'milestone_mapping_id',
        'view_count',
    ];

    protected $casts = [
        'files' => 'array',
        'total_size' => 'integer',
        'upload_start_time' => 'datetime',
        'upload_end_time' => 'datetime',
        'total_upload_duration' => 'integer',
        'milestone_mapping_id' => 'integer',
        'view_count' => 'integer',
    ];

    public function getDisplayNameAttribute()
    {
        return $this->user_folder_name ?? $this->google_drive_folder_name;
    }

    public function getHumanTotalSizeAttribute()
    {
        $bytes = $this->total_size;
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }

        return round($bytes, 2).' '.$units[$i];
    }

    public function getFormattedDurationAttribute()
    {
        if (! $this->total_upload_duration) {
            return 'N/A';
        }

        $seconds = $this->total_upload_duration;
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $secs = $seconds % 60;

        if ($hours > 0) {
            return sprintf('%02d:%02d:%02d', $hours, $minutes, $secs);
        } elseif ($minutes > 0) {
            return sprintf('%02d:%02d', $minutes, $secs);
        } else {
            return sprintf('%d seconds', $secs);
        }
    }
}
