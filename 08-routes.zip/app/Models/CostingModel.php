<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CostingModel extends Model
{
    use HasFactory;
    public $table = 'et_costing';
    public $primaryKey = 'sno';

    protected $fillable = [
        'costing_id',
        'customer_id',
        'course_id',
        'batch_id',
        'slot_id',
        'staff_id',
        'free_split_count',
        'payment_id',
        'created_by',
        'updated_by',
        'updated_at',
        'created_at',
        'status',
    ];
}
