<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChatModel extends Model
{
  use HasFactory;
  public $table      = 'et_chat';
  public $primaryKey = 'sno';

  protected $fillable = [
    'type',
    'customer_id',
    'service_id',
    'who',
    'staff_id',
    'message_content',
    'created_by',
    'updated_at',
    'status',
  ];
}
