<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DefaultGoalSetModel extends Model
{

    use HasFactory;
    public $table = 'et_default_goalset';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'department_id',
        'conversion',
        'conversion_check',
        'CR',
        'CR_check',
        'ABV',
        'ABV_check',
        'ACV',
        'ACV_check',
        'avg_call_out',
        'avg_call_out_check',
        'no_of_walk',
        'no_of_walk_check',
        'no_of_followup',
        'no_of_followup_check',
        'working_hours',
        'working_hours_check',
        'min_no_of_students',
        'min_no_of_students_check',
        'no_of_post_sale',
        'no_of_post_sale_check',
        'harvesting_percentage',
        'harvesting_percentage_check',
        'rework',
        'rework_check',
        'no_of_papers',
        'no_of_papers_check',
        'productions',
        'productions_check',
        'no_of_reviews',
        'no_of_reviews_check',
        'given_links',
        'given_links_check',
        'no_of_placements',
        'no_of_placements_check',
        'mou',
        'mou_check',
        'reference_sales',
        'reference_sales_check',
        'created_by',
        'created_at',
        'updated_by',
        'status',
    ];
}
