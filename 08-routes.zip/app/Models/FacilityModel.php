<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FacilityModel extends Model
{
    use HasFactory;
    public $table      = "et_facility";
    public $primaryKey = 'sno';


    protected $fillable = [
        'facility_id',
        'branch_id',
        'facility_name',
        'duration',
        'duration_in',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
