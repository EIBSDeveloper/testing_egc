<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CugManagementModel extends Model
{
    use HasFactory;
    public $table      = "et_cug_management";
    public $primaryKey = 'sno';

    protected $fillable = [
        'cre_id',
        'sales_id',
        'cre_mobile',
        'sales_mobile',
        'job_position_id',
        'staff_id',
        'staff_mobile',
        'staff_email',
        'created_by',
        'updated_by',
        'status',
    ];
}
