<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EventCategoryModel extends Model
{
    use HasFactory;
    public $table = "et_event_category";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'event_category_id',
        'event_category_name',
        'event_category_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
