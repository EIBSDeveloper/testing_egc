<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AddonVariableModel extends Model
{
    use HasFactory;

    public $table = "et_addon_variable"; // Replace with your actual table name
    public $primaryKey = 'sno';
    public $timestamps = false; // Because you're manually handling created_at & updated_at

    protected $fillable = [
        'sno',
        'addon_variableid',
        'addon_varientid',
        'addon_variablename',
        'min_cost',
        'max_cost',
        'addon_des',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
