<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DepartmentModel extends Model
{
    use HasFactory;
    public $table      = 'et_department';
    public $primaryKey = 'sno';

    protected $fillable = [
        'department_id',
        'branch_id',
        'external_uuid',
        'department_name',
        'department_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
