<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamStaffBadgeModel extends Model
{
    use HasFactory;
    public $table      = "et_exam_staff_badges";
    public $primaryKey = 'sno';


    protected $fillable = [
        'exam_id',
        'branch_id',
        'staff_id',
        'pin_sts',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status,'
    ];
}
