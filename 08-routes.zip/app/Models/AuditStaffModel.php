<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AuditStaffModel extends Model
{
    use HasFactory;
    public $table      = 'et_audit_staff';
    public $primaryKey = 'sno';

    protected $fillable = [
        'audit_staff_id',
        'branch_id',
        'audit_staff_name',
        'audit_staff_mobile',
        'alternative_no',
        'staff_image',
        'email_id',
        'gender',
        'audit_staff_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
