<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CallTrackerModel extends Model
{
  use HasFactory;
  protected $table = 'et_call_tracker'; // Table name
  protected $primaryKey = 'sno'; // Primary key
  protected $fillable = [
    'branch_id',
    'branch_staff_id',
    'call_tracker_staff_id',
    'staff_phone_no',
    'customer_phone_no',
    'customer_name',
    'customer_status',
    'customer_reason',
    'call_start_date',
    'call_end_date',
    'call_start_time',
    'call_end_time',
    'call_duration',
    'latitude',
    'longitude',
    'call_status',
    'count_status',
    'call_start_date',
    'call_end_date',
    'call_start_time',
    'call_end_time',
    'call_duration',
    'updated_at',
    'created_at'
  ];
}
