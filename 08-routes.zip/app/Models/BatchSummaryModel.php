<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BatchSummaryModel extends Model
{
    use HasFactory;
    public $table      = "et_batch_summary";
    public $primaryKey = 'sno';


    protected $fillable = [
        'summary_id',
        'branch_id',
        'summary_date',
        'batch_id',
        'staff_id',
        'course_id',
        'summary',
        'summary_desc',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];
}
