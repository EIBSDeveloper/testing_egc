<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamQuestionsModel extends Model
{
    use HasFactory;
    public $table      = 'et_exam_questions';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'bank_id',
        'case_study_check',
        'case_study',
        'option_type',
        'question',
        'option',
        'option_answer',
        'tips',
        'explanation',
        'created_by',
        'created_at',
        'updated_by',
        'status',
    ];
}
