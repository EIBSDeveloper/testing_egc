<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EventTypeModel extends Model
{
    use HasFactory;
    public $table = "et_event_type";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'event_type_id',
        'event_type_name',
        'event_type_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
