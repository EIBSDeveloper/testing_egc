<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CertificateAuthorityStatusModel extends Model
{
    use HasFactory;
    public $table = "et_certificate_authority_status";
    public $primaryKey = 'sno';


    protected $fillable = [
        'certificate_authority_status_id',
        'certificate_authority_status_name',
        'bg_color',
        'text_color',
        'certificate_authority_status_desc',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
