<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseSubCategoryModel extends Model
{
    use HasFactory;
    public $table      = "et_course_subcategory";
    public $primaryKey = 'sno';
    //public $timestamps = false;


    protected $fillable = [
        'course_category_id',
        'course_subcategory_id',
        'course_subcategory_name',
        'course_category_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
