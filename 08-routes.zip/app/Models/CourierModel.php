<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourierModel extends Model
{
    use HasFactory;
    public $table      = 'et_courier';
    public $primaryKey = 'sno';

    protected $fillable = [
        'courier_id',
        'branch_id',
        'courier_name',
        'courier_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
