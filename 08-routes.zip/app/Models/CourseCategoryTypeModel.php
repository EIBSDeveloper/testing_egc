<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseCategoryTypeModel extends Model
{
    use HasFactory;
    public $table      = "et_course_category_type";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'course_category_type_id',
        'course_category_name',
        'course_category_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
