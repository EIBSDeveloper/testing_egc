<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CronjobLogModel extends Model
{
    use HasFactory;
    public $table      = "et_cronjob_logs";
    public $primaryKey = 'sno';

    protected $fillable = [
        'cronjob_id',
        'sync_start_date_time',
        'sync_end_date_time',
        'sync_duration',
        'response',
        'created_by',
        'updated_by',
        'status',
    ];
    
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_at = now()->timezone('Asia/Kolkata')->format('Y-m-d H:i:s');
            $model->updated_at = now()->timezone('Asia/Kolkata')->format('Y-m-d H:i:s');
        });

        static::updating(function ($model) {
            $model->updated_at = now()->timezone('Asia/Kolkata')->format('Y-m-d H:i:s');
        });
    }
}


