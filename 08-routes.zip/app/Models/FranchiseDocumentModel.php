<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FranchiseDocumentModel extends Model
{
    use HasFactory;
    public $table      = 'et_franchise_document';
    public $primaryKey = 'sno';

    protected $fillable = [
        'franchise_id',
        'documenttype_id',
        'document',
        'created_by',
        'updated_by',
        'status'
    ];
}
