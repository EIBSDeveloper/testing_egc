<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BranchAuditModel extends Model
{
    use HasFactory;
    public $table      = "et_branch_audit";
    public $primaryKey = 'sno';


    protected $fillable = [
        'branch_audit_id',
        'branch_id',
        'audit_date',
        'staff_id',
        'department_ids',
        'audit_comments',
        'audit_status',
        'updated_at',
        'updated_by',
        'created_at',
        'created_by',
        'status',
    ];
}
