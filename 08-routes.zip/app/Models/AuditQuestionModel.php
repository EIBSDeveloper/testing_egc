<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AuditQuestionModel extends Model
{
    use HasFactory;
    public $table      = "et_audit_question";
    public $primaryKey = 'sno';
    // public $timestamps = false;

    protected $fillable = [
        'audit_question_name',
        'audit_category_id',
        'audit_question_type',
        'audit_question_option',
        'created_by',
        'created_at',
        'status',
    ];
}
