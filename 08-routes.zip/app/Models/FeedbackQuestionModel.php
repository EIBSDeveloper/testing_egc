<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FeedbackQuestionModel extends Model
{
    use HasFactory;
    public $table      = "et_feedback_questions";
    public $primaryKey = 'sno';

    protected $fillable = [
        'feedback_question_name',
        'feedback_id',
        'feedback_question_type',
        'feedback_question_option',
        'created_by',
        'created_at',
        'status',
    ];
}
