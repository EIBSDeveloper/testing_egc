<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EventPosterModel extends Model {
    use HasFactory;
    public $table      = 'et_event_posters';
    public $primaryKey = 'sno';

   protected $fillable = [
        'poster_type_id',
        'poster_template',
        'poster_image',
        'created_by',
        'updated_by',
        'created_at',
        'status',
    ];
}