<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CategoryQuestionModel extends Model
{
    use HasFactory;
    public $table      = "et_category_question";
    public $primaryKey = 'sno';
    // public $timestamps = false;

    protected $fillable = [
        'category_question_name',
        'category_id',
        'category_question_type',
        'category_question_option',
        'created_by',
        'created_at',
        'status',
    ];
}
