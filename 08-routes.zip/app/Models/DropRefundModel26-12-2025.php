<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DropRefundModel extends Model
{
  use HasFactory;
  public $table      = "et_drop_refund";
  public $primaryKey = 'sno';


  protected $fillable = [
    'type',
    'branch_id',
    'customer_id',
    'training_id',
    'batch_id',
    'course_id',
    'bh_id',
    'bh_status',
    'bh_status_date',
    'bh_reject_reason',
    'acc_id',
    'ac_status',
    'ac_reject_reason',
    'ac_status_date',
    'refund_amount',
    'paid_amount',
    'min_deducted_amount',
    'costing_amount',
    'costing_hours',
    'posible_eligible_amount',
    'refunded_reason',
    'refunded_payment_mode_id',
    'refunded_date',
    'max_refund_date',
    'check_list',
    'drop_refund_reason',
    'created_by',
    'updated_by',
    'status',
  ];
}
