<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BatchHistoryModel extends Model
{
    use HasFactory;
    public $table      = "et_batch_history";
    public $primaryKey = 'sno';


    protected $fillable = [
        'batch_id',
        'batch_his_id',
        'branch_id',
        'batch_name',
        'sno',
        'attendance',
        'att_date',
        'updated_at',
        'updated_by',
        'created_at',
        'created_by',
        'status',
    ];
}
