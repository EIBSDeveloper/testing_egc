'use strict';

(function () {
  // Full Toolbar Configuration
  // --------------------------------------------------------------------
  const fullToolbarConfig = [
    [
      { font: [] },
      { size: ['small', 'medium', 'large', 'huge'] }
      // { size: ['8px', '9px', '10px', '11px', '12px', '14px', '16px', '18px', '20px', '22px', '24px', '26px', '28px', '36px', '48px', '72px'] }
    ],
    ['bold', 'italic', 'underline', 'strike'],
    [
      { color: [] },
      { background: [] }
    ],
    [
      { script: 'super' },
      { script: 'sub' }
    ],
    [
      { header: '1' },
      { header: '2' },
      'blockquote',
      'code-block'
    ],
    [
      { list: 'ordered' },
      { list: 'bullet' },
      { indent: '-1' },
      { indent: '+1' }
    ],
    [{ direction: 'rtl' }],
    ['link', 'image', 'video', 'formula'],
    ['clean']
  ];

  const createQuillEditor = (selector) => {
    return new Quill(selector, {
      bounds: selector,
      modules: {
        formula: true,
        toolbar: fullToolbarConfig
      },
      theme: 'snow'
    });
  };

 // Expose editor instances to global scope for access outside
 window.thankswindowAdd = createQuillEditor('#thanks_window_add');
 window.thankswindowEdit = createQuillEditor('#thanks_window_edit');

 // Attach Form Submit Listener To Copy Content (Add Form)
 const addForm = document.getElementById('add_thanks_form');
 addForm.addEventListener('submit', function(e){
   const html = window.thankswindowAdd.root.innerHTML.trim();
   document.getElementById('thanks_window_input').value = html;

   const plainText = window.thankswindowAdd.getText().trim();
   if (plainText === '') {
     e.preventDefault();
     document.getElementById('desc-err').textContent = "Thanks window message is required.";
   }
 });

 // Attach Form Submit Listener To Copy Content (Edit Form)
 const editForm = document.getElementById('edit_thanks_form');
 editForm.addEventListener('submit', function(e){
   const html = window.thankswindowEdit.root.innerHTML.trim();
   document.getElementById('thanks_window_edit_input').value = html;

   const plainText = window.thankswindowEdit.getText().trim();
   if (plainText === '') {
     e.preventDefault();
     document.getElementById('edit-desc-err').textContent = "Thanks window message is required.";
     // You can add an error message somewhere for edit form as well
   }
 });

  
})();
