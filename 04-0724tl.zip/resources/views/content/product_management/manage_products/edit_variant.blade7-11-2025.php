@php
    $helper = new \App\Helpers\Helpers();
@endphp

<input type="hidden" name="edit_variant_sno" id="edit_variant_sno" value="{{ $product->sno }}">
<div class="form-repeater_upd_prod_vart">
    <div data-repeater-list="group-a_sec_edit">
        @foreach ($variants as $index => $pv_list)
            <div data-repeater-item-sec-edit id="variant_div_{{ $index }}">
                <div class="row mb-4">
                    <div class="col-lg-11">
                        <div class="card rounded">
                            <div class="card-action">
                                <div class="card-header section_edit bg-gray-200 px-3 py-2 collapsed">
                                    <div class="card-action-title w-100">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Variant Name<span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control variant_name_input_edit"
                                            placeholder="Enter Variant Name"
                                            name="variant_name_edit[{{ $index }}][]" maxlength="80"
                                            id="variant_name_edit_{{ $index }}_0"
                                            value="{{ $pv_list->product_variant_name }}" />
                                        <input type="hidden" id="variant_id_edit_{{ $index }}"
                                            name="variant_id_edit[{{ $index }}]" value="{{ $pv_list->sno }}">
                                    </div>
                                    <div class="card-action-element d-flex align-items-center">
                                        <ul class="list-inline mb-0">
                                            <li class="list-inline-item">
                                                <a href="javascriptr:;" class="syll_section_edit toggle-variant-update">
                                                    <i class="mdi mdi-chevron-down fs-3 rotate-icon"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="collapse section_edit border show">
                                <div class="card-body">
                                    <div class="form-repeater_topic">
                                        <div data-repeater-list-top-edit>

                                            @php
                                                $get_variable_list = $helper->get_variable_data($pv_list->sno);
                                                // print_r($get_variable_list);
                                            @endphp
                                            @if (!$get_variable_list->isEmpty())
                                                @foreach ($get_variable_list as $index2 => $v_list)
                                                    <div data-repeater-item-top-edit  id="variable_div_{{ $index }}_{{ $index2 }}">
                                                        <div class="mt-1">
                                                            <input type="hidden"
                                                                id="variable_id_edit_{{ $index }}"
                                                                name="variable_id_edit[{{ $index }}][{{ $index2 }}]"
                                                                value="{{ $v_list->sno }}">
                                                            <div class="row mb-2">
                                                                <div class="border border-secondary rounded ps-2 pe-4 px-0 py-2">
                                                                    <div class="row">
                                                                        <div class="col-lg-11">
                                                                            <div class="row">
                                                                                <div class="col-lg-5">
                                                                                    <label class="text-black mb-1 fs-6 fw-semibold" >Variable Name<span class="text-danger">*</span></label>
                                                                                    <input type="text"
                                                                                        class="form-control variable_name_input_edit"
                                                                                        placeholder="Enter Variable Name"
                                                                                        name="variable_name_edit[{{ $index }}][]"
                                                                                        maxlength="80"
                                                                                        id="variable_name_edit_{{ $index }}_{{ $index2 }}"
                                                                                        value="{{ $v_list->variable_name }}" />
                                                                                </div>
                                                                                <div class="col-lg-5">
                                                                                    <label class="text-black mb-1 fs-6 fw-semibold" maxlength="10">Amount<span class="text-danger">*</span></label>
                                                                                    <input type="text"
                                                                                        class="form-control amount_input_edit"
                                                                                        placeholder="Enter Amount"
                                                                                        name="amount_edit[{{ $index }}][]"
                                                                                        maxlength="10"
                                                                                        id="amount_edit_{{ $index }}_{{ $index2 }}"
                                                                                        value="{{ $v_list->variable_amount }}"
                                                                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                                                                                </div>
                                                                                <div class="col-lg-2 px-2 text-center mb-3">
                                                                                    <label
                                                                                        class="text-black mb-1 fs-6 fw-semibold">Status</label>
                                                                                    <div class="d-block ms-n4">
                                                                                        <label class="switch switch-square">
                                                                                            <input type="checkbox" class="switch-input"
                                                                                                {{ $v_list->status == 0 ? 'checked' : '' }}
                                                                                                onchange="SwitchStatus_variable('{{ $v_list->sno }}', this.checked)" />
                                                                                            <span class="switch-toggle-slider">
                                                                                                <span class="switch-on"></span>
                                                                                                <span class="switch-off"></span>
                                                                                            </span>
                                                                                        </label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="row edit_pages_row" style="display:flex !important;">
                                                                                <div class="col-lg-5">
                                                                                <label class="text-black mb-1 fs-6 fw-semibold" >Minimum Pages <span class="text-danger">*</span></label>
                                                                                <input type="text" class="form-control edit_min_input" name="edit_min_pages[{{ $index }}][]" id="edit_min_pages_{{ $index }}_{{ $index2 }}" placeholder="Enter Minimum Pages" value="{{ $v_list->min_pages ?? 0 }}" maxlength="5" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                                                                                </div>
                                                                                <div class="col-lg-5">
                                                                                <label class="text-black mb-1 fs-6 fw-semibold">Maximum Pages <span class="text-danger">*</span></label>
                                                                                <input type="text" class="form-control edit_max_input" placeholder="Enter Maximum Pages" name="edit_max_pages[{{ $index }}][]"id="edit_max_pages_{{ $index }}_{{ $index2 }}" value="{{ $v_list->max_pages ?? 0 }}" maxlength="5" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                                                                                    
                                                                        <div class="col-lg-1 mb-3">
                                                                            @if ($index2 > 0)
                                                                                <a href="javascript:;"
                                                                                    class="btn btn-outline-danger mt-6 px-0 py-1"
                                                                                    style="display:none;"
                                                                                    onclick="deletevariable(this,'{{ $index }}','{{ $index2 }}','{{ $v_list->sno }}')">
                                                                                    <i class="mdi mdi-delete fs-4"></i>
                                                                                </a>
                                                                            @endif
                                                                        </div>
                                                                    </div>  
                                                                </div>
                                                            </div>   
                                                        </div>
                                                    </div>
                                                @endforeach
                                            @else
                                                <div class="row">
                                                    <div class="col-lg-5">
                                                        <label class="text-black mb-1 fs-6 fw-semibold"
                                                            for="variable_name_0_0">Variable Name<span
                                                                class="text-danger">*</span></label>
                                                        <input type="text"
                                                            class="form-control variable_name_input_edit"
                                                            placeholder="Enter Variable Name"
                                                            name="variable_name_edit[0][]" maxlength="80"
                                                            id="variable_name_edit_0_0" />
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label class="text-black mb-1 fs-6 fw-semibold"
                                                            for="amount_0_0">Amount<span
                                                                class="text-danger">*</span></label>
                                                        <input type="text" class="form-control amount_input_edit"
                                                            placeholder="Enter Amount" name="amount_edit[0][]"
                                                            maxlength="10" id="amount_edit_0_0"
                                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                                                    </div>
                                                    <div class="col-lg-1 mb-3">
                                                        {{-- <a
                                                    href="javascript:;"
                                                    class="btn btn-outline-danger mt-6 px-0 py-1 topic_butt_del"
                                                    style="display:none;"
                                                    >
                                                    <i class="mdi mdi-delete fs-4"></i>
                                                    </a> --}}
                                                    </div>
                                                </div>
                                            @endif

                                        </div>
                                    </div>
                                    <div class="mb-1 mt-3">
                                        <button type="button"
                                            class="btn btn-sm btn-primary topic_butt_edit fs-8 px-2 py-1">
                                            <i class="mdi mdi-plus me-1"></i>Add More
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1 mb-3 d-flex align-items-start justify-content-end">
                        @if ($index > 0)
                            <button type="button" class="btn btn-outline-danger mt-6 px-0 py-1 topic_butt_del"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"
                                onclick="deletevariant(this,'{{ $index }}','{{ $pv_list->sno }}')">
                                <i class="mdi mdi-delete fs-4"></i>
                            </button>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
<div class="mb-1 mt-1">
    <button type="button" class="btn btn-sm btn-primary section_butt_edit fs-8 px-2 py-1" id="main_add_more_edit">
        <i class="mdi mdi-plus me-1"></i>Add More
    </button>
</div>


<input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_variant_delete" id="variant_delete">
<!--begin::Modal - Delete variant-->
<div class="modal fade" id="kt_modal_variant_delete" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                <span id="variant_delete_message"></span>
            </div>
            <input type="hidden" id="variant_delete_id">
            <div class="row" id="variant_delete_button">

            </div>
            <br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete variant-->



<input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_variable_delete" id="variable_delete">
<!--begin::Modal - Delete variable-->
<div class="modal fade" id="kt_modal_variable_delete" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                <span id="variable_delete_message"></span>
            </div>
            <input type="hidden" id="variable_delete_id">
            <div class="row" id="variable_delete_button">

            </div>
            <br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete variable-->

<script>
    function deletevariant(element, id, del_id) {
        if (del_id !== '') {
            $('#variant_delete').click();

            const name = $('#variant_name_edit_' + id + '_0').val() || '';
            $('#variant_delete_id').val(del_id);
            $('#variant_delete_message').html(
                'Are you sure you want to delete Product Variant <br> <b class="text-danger">' + name + '</b> ?'
            );

            $('#variant_delete_button').html(`
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="button" class="btn btn-danger me-3" onclick="delete_confirm('${del_id}', '${id}')">Yes, delete!</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, cancel</button>
                </div>
            `);
        }
    }

    function delete_confirm(delid, row_id) {
        const delete_id = delid;

        fetch('/product_variant_delete/' + delete_id, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    $("#variant_div_" + row_id).remove();
                    // Safely find and remove the section
                    toastr.success('Product Variant Deleted successfully!');
                    $('#variant_delete').click();

                } else {
                    // console.error(data.error_msg || 'Unknown error');
                }
            })
            .catch(error => {
                // console.error('Error:', error);
            });
    }
</script>



<script>
    function deletevariable(element, id, id2, del_id) {
        if (del_id !== '') {
            $('#variable_delete').click();
            // alert(del_id)
            const name = $('#variable_name_edit_' + id + '_' + id2).val() || '';
            $('#variable_delete_id').val(del_id);
            $('#variable_delete_message').html(
                'Are you sure you want to delete Product Variable <br> <b class="text-danger">' + name + '</b> ?'
            );

            $('#variable_delete_button').html(`
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="button" class="btn btn-danger me-3" onclick="delete_variable_confirm('${del_id}', '${id}',${id2})">Yes, delete!</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, cancel</button>
                </div>
            `);
        }
    }

    function delete_variable_confirm(delid, row_id, row_id2) {
        const delete_id = delid;

        fetch('/product_variable_delete/' + delete_id, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    $("#variable_div_" + row_id + '_' + row_id2).remove();
                    // Safely find and remove the section
                    toastr.success('Product Variable Deleted successfully!');
                    $('#variable_delete').click();

                } else {
                    // console.error(data.error_msg || 'Unknown error');
                }
            })
            .catch(error => {
                // console.error('Error:', error);
            });
    }
</script>


<script>
    $(document).ready(function() {

        // Update all IDs and names after DOM changes
        function updateIds_edit() {
            // $('[data-repeater-item-sec-edit]').each(function (secIndex) {
            // $(this).find('.variant_name_input_edit').attr({
            //     id: `variant_name_edit_${secIndex}_0`,
            //     name: `variant_name_edit[${secIndex}][]`
            // });

            // $(this).find('[data-repeater-item-top-edit]').each(function (varIndex) {
            //     $(this).find('.variable_name_input_edit').attr({
            //         id: `variable_name_edit_${secIndex}_${varIndex}`,
            //         name: `variable_name_edit[${secIndex}][]`
            //     });
            //     $(this).find('.amount_input_edit').attr({
            //         id: `amount_edit_${secIndex}_${varIndex}`,
            //         name: `amount_edit[${secIndex}][]`
            //     });
            // });
            // });
        }

        // HTML for new section
        function getNewSectionHtml_edit(secIndex) {
            return `
    <div data-repeater-item-sec-edit>
        <div class="row mb-4">
            <div class="col-lg-11">
                <div class="card rounded">
                    <div class="card-action">
                        <div class="card-header section_edit bg-gray-200 px-3 py-2 collapsed">
                            <div class="card-action-title w-100">
                                <label class="text-black mb-1 fs-6 fw-semibold" for="variant_name_edit_${secIndex}_0">
                                    Variant Name<span class="text-danger">*</span>
                                </label>
                                 <input type="hidden" id="variant_id_edit_{${secIndex}" name="variant_id_edit[${secIndex}]" value="0">
                                <input type="text" class="form-control variant_name_input_edit"
                                    placeholder="Enter Variant Name"
                                    name="variant_name_edit[${secIndex}][]" maxlength="80"
                                    id="variant_name_edit_${secIndex}_0" />
                            </div>
                            <div class="card-action-element d-flex align-items-center">
                                <ul class="list-inline mb-0">
                                    <li class="list-inline-item">
                                        <a href="javascript:;" class="syll_section_edit toggle-variant-update">
                                            <i class="mdi mdi-chevron-down fs-3 rotate-icon"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="collapse section_edit border show">
                        <div class="card-body">
                            <div class="form-repeater_topic">
                                <div data-repeater-list-top-edit>
                                    ${getNewVariableHtml_edit(secIndex, 0)}
                                </div>
                            </div>
                            <div class="mb-1 mt-3">
                                <button type="button" class="btn btn-sm btn-primary topic_butt_edit fs-8 px-2 py-1">
                                    <i class="mdi mdi-plus me-1"></i>Add More
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-1 mb-3 d-flex align-items-start justify-content-end">
                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 section_butt_del_edit">
                    <i class="mdi mdi-delete fs-4"></i>
                </a>
            </div>
        </div>
    </div>`;
        }

        // HTML for new variable inside a section
        function getNewVariableHtml_edit(secIndex, varIndex) {
            return `
            <div data-repeater-item-top-edit>
                <div class="row mb-2">
                    <div class="border border-secondary rounded ps-2 pe-4 px-0 py-2">
                        <div class="col-lg-11">
                            <div class="row">
                                <div class="col-lg-5">
                                    <label class="text-black mb-1 fs-6 fw-semibold" for="variable_name_edit_${secIndex}_${varIndex}">
                                        Variable Name<span class="text-danger">*</span>
                                    </label>
                                    <input type="hidden" id="variable_id_edit_${secIndex}" name="variable_id_edit[${secIndex}][${varIndex}]" value="0">
                                    <input type="text" class="form-control variable_name_input_edit"
                                        placeholder="Enter Variable Name" maxlength="80"
                                        name="variable_name_edit[${secIndex}][]"
                                        id="variable_name_edit_${secIndex}_${varIndex}" />
                                </div>
                                <div class="col-lg-5">
                                    <label class="text-black mb-1 fs-6 fw-semibold" for="amount_edit_${secIndex}_${varIndex}">
                                        Amount<span class="text-danger">*</span>
                                    </label>
                                    <input type="text" class="form-control amount_input_edit"
                                        placeholder="Enter Amount"
                                        name="amount_edit[${secIndex}][]" maxlength="10"
                                        id="amount_edit_${secIndex}_${varIndex}"
                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\\..*)\\./g, '$1');" />
                                </div>
                                <div class="col-lg-2 mb-3 topic_butt_div_edit">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-0 py-1 topic_butt_del">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="row edit_pages_row" style="display:flex !important;">
                                <div class="col-lg-5">
                                <label class="text-black mb-1 fs-6 fw-semibold" >Minimum Pages <span class="text-danger">*</span></label>
                                <input type="text" class="form-control edit_min_input" name="edit_min_pages[${secIndex}][]" id="edit_min_pages_${secIndex}_${varIndex}" placeholder="Enter Minimum Pages"  maxlength="5" oninput="this.value = this.value.replace(/\\D/g,'')" />
                                </div>
                                <div class="col-lg-5">
                                <label class="text-black mb-1 fs-6 fw-semibold">Maximum Pages <span class="text-danger">*</span></label>
                                <input type="text" class="form-control edit_max_input" placeholder="Enter Maximum Pages" name="edit_max_pages[${secIndex}][]"id="edit_max_pages_${secIndex}_${varIndex}" maxlength="5" oninput="this.value = this.value.replace(/\\D/g,'')" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;
        }

        // Add new section
        $('#main_add_more_edit').on('click', function() {
            const nextIndex = $('[data-repeater-item-sec-edit]').length;
            const newHtml = getNewSectionHtml_edit(nextIndex);
            $('[data-repeater-list="group-a_sec_edit"]').append(newHtml);
            // updateIds_edit();
        });

        // Add new variable inside a section
        $(document).on('click', '.topic_butt_edit', function() {
            const $section = $(this).closest('[data-repeater-item-sec-edit]');
            const $list = $section.find('[data-repeater-list-top-edit]');
            const secIndex = $section.index();
            const varIndex = $list.find('[data-repeater-item-top-edit]').length;
            $list.append(getNewVariableHtml_edit(secIndex, varIndex));
            // updateIds_edit();
        });

        $(document).on('click', '.toggle-variant-update', function() {
            const icon = $(this).find('.rotate-icon');
            const body = $(this).closest('.card').find('.card-body');
            body.slideToggle(200);
            icon.toggleClass('mdi-chevron-down mdi-chevron-up');
        });

        // Remove variable
        $(document).on('click', '.topic_butt_del', function() {
            $(this).closest('[data-repeater-item-top-edit]').remove();
            // updateIds_edit();
        });

        // Remove section
        $(document).on('click', '.section_butt_del_edit', function() {
            $(this).closest('[data-repeater-item-sec-edit]').remove();
            // updateIds_edit();
        });

    });
</script>

<script>
    function SwitchStatus_variable(UniversityId, isChecked) {
        const status = isChecked ? 0 : 1; // Set status based on checkbox state

        fetch(`/product_status_variable/${UniversityId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    console.log('Product Variant Variable Status updated successfully:', data.message);
                    toastr.success('Product Variant Variable Status Updated successfully!');
                } else {
                    console.error('Error updating Product Variant Variable Status:', data.message);
                    toastr.error('Error updating Product Variant Variable Status');
                }
            })
            .catch(error => {
                console.error('Error updating Product Variant Variable status:', error);
            });
    }
</script>

<script>
    function EditvalidateForm_variant() {
        var err = 0;

        function showError(input, message) {
            if (err === 0) {
                Swal.fire({
                    title: 'Error!',
                    text: message,
                    icon: 'error',
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false
                });
                input.addClass('err_msg');
                err++;
            }
        }

        // Validate Variant Names
        $('.variant_name_input_edit').each(function() {
            if (!$(this).val().trim()) {
                showError($(this), 'Enter Variant Name is Required..!');
            } else {
                $(this).removeClass('err_msg');
            }
        });

        // Validate Variable Names
        $('.variable_name_input_edit').each(function() {
            if (!$(this).val().trim()) {
                showError($(this), 'Enter Variable Name is Required..!');
            } else {
                $(this).removeClass('err_msg');
            }
        });

        // Validate Amounts
        $('.amount_input_edit').each(function() {
            var val = $(this).val().trim();
            if (!val || isNaN(val) || parseFloat(val) < 0) {
                showError($(this), 'Enter Amount is Required..!');
            } else {
                $(this).removeClass('err_msg');
            }
        });
        
        // Validate Amounts
       $('.edit_min_input').each(function() {
           var val = $(this).val().trim();
           if (!val || isNaN(val) || parseFloat(val) < 0) {
               showError($(this), 'Enter maximum Pages is Required..!');
           } else {
               $(this).removeClass('err_msg');
           }
       });
         // Validate Amounts
        $('.edit_max_input').each(function() {
            var val = $(this).val().trim();
            if (!val || isNaN(val) || parseFloat(val) < 0) {
                showError($(this), 'Enter Minimum Pages is Required..!');
            } else {
                $(this).removeClass('err_msg');
            }
        });


        if (err === 0) {
            // If no errors, proceed
            $('#EditvariantForm').submit();
            $('#btn_submit_edit').prop('disabled', true);
            return true;
        } else {
            // Enable button if needed
            $('#btn_submit_edit').prop('disabled', false);
            return false;
        }
    }
</script>

<script>
     Editariantmodel()
      function Editariantmodel(){
        
        if({{ $product->product_category_id }} == 1){
            $('.edit_pages_row').show();
        }else{
            $('.edit_pages_row').hide();
        }
      }
</script>
