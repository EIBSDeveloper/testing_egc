@extends('layouts/layoutMaster')

@section('title', 'Manage Products')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<style>
  /* Ensure consistent height and alignment */
  .task-row {
  align-items: flex-start;
  }
  
  /* Keep delete button container visible but empty for first card */
  .task-row:first-child > div.ms-3 {
  visibility: hidden; /* hide the button but keep space */
  margin-top: 1rem; /* same as appended cards */
  }
  
  /* Delete button container for appended cards */
  .task-row:not(:first-child) > div.ms-3 {
  visibility: visible;
  margin-top: 1rem;
  }
  
  /* Optional: ensure the .task-card fills remaining space nicely */
  .task-card {
  flex-grow: 1;
  }
</style>

@php
    $helper = new \App\Helpers\Helpers();
    $module_name = 'Product Management';
    $menu_name   = 'Manage Products';
@endphp
<!-- Users List Table -->
<div class="card card-action">
  <div class="card-header border-bottom pb-1">
    <div class="card-action-title">
      <h5 class="card-title mb-1">Manage Products</h5>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
          </li>
          <span class="text-dark opacity-75 me-1 ms-1">
            <i class="mdi mdi-arrow-right-thin fs-4"></i>
          </span>
          <li class="breadcrumb-item">
            <a href="javascript:;" class="d-flex align-items-center">Product Management</a>
          </li>
        </ol>
      </nav>
    </div>
    <div class="card-action-element">
      <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
        @if(auth()->user()->hasPermission($module_name, 'Filter', $menu_name))
        {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="filter" title="Filter">
          <span><i class="mdi mdi-filter-outline text-center text-center"></i></span>
        </a> --}}
        @endif
        @if(auth()->user()->hasPermission($module_name, 'Add', $menu_name))
        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_add_product">
          <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Product
        </a>
        @endif
      </div>
    </div>
  </div>
  <div class="card-body">
    <div class="filter_tbox" style="display: none;">
      <div class="row py-1">
        <div class="col-lg-3 mb-2">
          <label class="text-black mb-1 fs-6 fw-semibold">Product Category</label>
          <select class="select3 form-select">
            <option value="">All</option>
            <option value="1">Reasearch Products</option>
            <option value="2">PHD Products</option>
            <option value="3">Writing Products</option>
            <option value="4">Development Products</option>
            <option value="5">Analysis Products</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2">
          <label class="text-black mb-1 fs-6 fw-semibold">Product</label>
          <input type="text" class="form-control" placeholder="Enter Product" />
        </div>
        <div class="col-lg-3 mb-2">
          <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
          <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
            <option value="all">All</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="monthly">This Month</option>
            <option value="custom_date">Custom Date</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">Today</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="course_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">Start Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="course_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">End Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="course_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">This Month</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="ovr_month_fill" placeholder="Select Date" class="form-control" value="<?php echo date("M-Y"); ?>" />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">From Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="course_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">To Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="course_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
          </div>
        </div>
      </div>
      <div class="d-flex align-items-center justify-content-end mb-2">
        <a href="javascript:;" class="btn btn-sm fw-bold btn-secondary me-2">Reset</a>
        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary">Go</a>
      </div>
    </div>
    @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
      <div class="row">
        <div class="row">
          <div class="row mb-4">
            @php $perpage_count = $perpage ? $perpage : 10; @endphp
            <div class="col-lg-2">
                <span>Show</span>
                <br>
                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                    @php
                    $options = [10, 25, 100, 500]; // Define available options
                    @endphp
                    @php foreach ($options as $option): @endphp
                    <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                        @php echo $option; @endphp
                    </option>
                    @php endforeach; @endphp
                </select>
            </div>
            <div class="col-lg-10 d-flex align-items-end justify-content-end">
                <form id="search_form" method="POST" action="/manage_product">
                    @csrf
                  <div class="d-flex align-items-center gap-2 mt-2">
                    <div>
                      <input type="hidden" name="page" value="{{ request('page', 1) }}">
                      <input type="hidden" name="filter_on" value="1">
                      <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                      <input
                        type="text"
                        class="form-control"
                        id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                        placeholder="Enter Search"
                      />
                    </div>
                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                  </div>
                </form>
            </div>
          </div>
          <div class="col-lg-12">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
              <thead>
                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                  <th class="min-w-150px">Products</th>
                  <th class="min-w-150px">Delivery Duration</th>
                  <th class="min-w-100px">Base Price</th>
                  <th class="min-w-100px">Min. / Max. Price</th>
                   <th class="min-w-200px text-center">Facility / Variants / Task</th>
                  <th class="min-w-80px">Status</th>
                  <th class="min-w-100px">Action</th>
                </tr>
              </thead>
              <tbody class="text-black fw-semibold fs-7">
                @if (isset($ListTable))
                  @foreach ($ListTable as $i=> $list)
                    <tr>
                      <td>
                        <div class="text-truncate max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->product_name }}">{{ $list->product_name }}</div>
                        <div class="d-block">
                          <div class="text-dark fs-8" ><span data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->product_category_name }}">{{ $list->product_category_name }} </span>
                          @if ($list->jouranal_check==1)
                            <label class="" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Journal Publishment">
                              <img src="{{ asset('assets/phdizone_images/journal.ico') }}" alt="Journal Publishment" class="w-35px h-35px ">
                            </label>
                          @endif
                          </div>
                        </div>
                      </td>
                      <td>
                        <label class="badge bg-label-info border border-info rounded text-black text-black fs-7 fw-semibold">
                          {{ $list->duration }} 
                          @switch($list->duration_in)
                              @case(0)
                                  Minute
                                  @break
                              @case(1)
                                  Hour
                                  @break
                              @case(2)
                                  Days
                                  @break
                          @endswitch
                        </label>
                      </td>
                      <td align="right">
                        <label class="text-black text-black fs-7 fw-semibold">&#8377; {{ number_format($list->base_price??0) }}</label>
                      </td>
                      <td>
                        <label
                            class="badge bg-label-success rounded border border-success text-black fs-7 fw-semibold mb-1"
                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="Minimum Price">&#8377;
                            {{ number_format($list->min_amount??0) }}
                        </label>
                        <label class="text-black fs-7 fw-semibold ms-1 me-1">|</label>
                        <label
                            class="badge bg-label-danger rounded border border-danger text-black fs-7 fw-semibold mb-1"
                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="Maximum Price">&#8377;
                            {{ number_format($list->max_amount??0) }}
                        </label>
                      </td>
                        <td class="text-center">
                            @php
                            $get_varient_list = $helper->get_variant_count_data($list->sno);
                            $get_product_task_count = $helper->get_product_task_count($list->sno);
                            $get_varient_list = count($get_varient_list);
                            $facilities = json_decode($list->facility_ids ?? '[]', true);
                            $facilities = is_array($facilities) ? $facilities : [];
                            @endphp
                            <label class="badge bg-warning rounded-pill text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facilities Count">{{ count($facilities) }}</label>
                            <label class="badge bg-primary rounded-pill text-white fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Variants Count">{{$get_varient_list}}</label>
                            <label class="badge bg-secondary rounded-pill text-white fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tasks Count">{{$get_product_task_count}}</label>
                        </td>
                      <td>
                        <label class="switch switch-square">
                          <input type="checkbox"  class="switch-input" {{ $list->status == 0 ? 'checked' : '' }} onchange="SwitchStatus('{{ $list->sno }}', this.checked)" />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                      </td>
                      <td>                        
                        <span class="text-end">
                          
                          @if($get_varient_list == 0)
                          <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_add_product_variant" onclick="AddVariantmodel('{{ $list->sno }}','{{ $list->product_name }}','{{$list->product_category_id}}')">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Product Variant">
                              <i class="mdi mdi-table-plus fs-3 text-black"></i>
                            </span>
                          </a>
                          @else
                          <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2 waves-effect waves-light" data-bs-toggle="offcanvas" data-bs-target="#kt_modal_update_product_variant" onclick="UpdateVariantmodel('{{ $list->sno }}','{{ $list->product_name }}')">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Update Product Variant" data-bs-original-title="Update Product Variant">
                              <i class="mdi mdi-table-sync fs-3 text-black"></i>
                            </span>
                          </a>
                          @endif
                          @if($get_product_task_count == 0)
                          <!--<a href="javascript:;" class="btn btn-icon btn-sm p-0 me-1" data-bs-toggle="modal" onclick="addProductTask('{{ $list->sno }}', '{{ $list->product_name }}','Create')"-->
                          <!--  data-bs-target="#kt_modal_add_task">-->
                          <!--  <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Task">-->
                          <!--    <i class="mdi mdi-archive-plus fs-3 text-black"></i>-->
                          <!--  </span>-->
                          <!--</a>-->
                          @else
                          <!--<a href="javascript:;" class="btn btn-icon btn-sm p-0 me-1" data-bs-toggle="modal" onclick="addProductTask('{{ $list->sno }}', '{{ $list->product_name }}','Update')"-->
                          <!--  data-bs-target="#kt_modal_add_task">-->
                          <!--  <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Task">-->
                          <!--    <i class="mdi mdi mdi-archive-sync fs-3 text-black"></i>-->
                          <!--  </span>-->
                          <!--</a>-->
                           @endif
                          <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                          </a>
                          <div class="dropdown-menu dropdown-menu-end">
                            @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_product" onclick="Viewmodel('{{ $list->sno }}')">
                              <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                            </a>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_update_product" onclick="editmodel('{{ $list->sno }}')">
                              <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                            </a>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Delete', $menu_name))
                            <a href="#" class="dropdown-item"  onclick="confirmDelete('{{ $list->sno }}','{{ $list->product_name }}','{{ $list->product_category_name??'' }}')" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_product">
                              <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                                <i class="mdi mdi-delete-outline fs-3 text-black"></i>Delete
                              </span>
                            </a>
                            @endif
                          </div>
                        </span>
                      </td>
                    </tr>
                  @endforeach
                @endif
              </tbody>
            </table>
            <div class="mt-4">
                {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
            </div>
          </div>
        </div>
      </div>
    @endif
</div>


<!--begin::Modal - Create Product-->
<div class="modal fade" id="kt_modal_add_product" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">Create Product</h3>
        </div>
          <form method="POST" action="{{ route('add_product') }}" id="add_form">
            @csrf
            <div class="row mb-3">
              <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Product Category<span class="text-danger">*</span></label>
                <select class="select3 form-select" name="product_cat_id" id="product_cat_id">
                  <option value="">Select Product Category</option>
                    @if (isset($Product_cat_list))
                        @foreach ($Product_cat_list as $pc_list)
                            <option value="{{ $pc_list->sno }}">{{ $pc_list->product_category_name }}</option>
                        @endforeach
                    @endif
                </select>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Product Name<span class="text-danger">*</span></label>
                <input type="text" maxlength="80" name="product_name" id="product_name" class="form-control" placeholder="Enter Product Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                <div class="error_msg text-danger" id="product_name_err"></div>
              </div>
              <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Delivery Duration<span class="text-danger">*</span></label>
                <div class="d-flex align-items-center">
                  <input type="text" class="form-control me-2" maxlength="3" placeholder="Enter Value" name="duration" id="duration" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                  <div class="w-99">
                    <select class="select3 form-select" name="duration_in" id="duration_in">
                      <option value="">Select Duration</option>
                      <option value="0">Minutes</option>
                      <option value="1">Hours</option>
                      <option value="2">Days</option>
                    </select>
                  </div>
                </div>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Base Price<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="10" placeholder="Enter Base Price" name="base_price" id="base_price" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Min. Amount<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="10" placeholder="Enter Min. Amount" name="min_amount" id="min_amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Max. Amount<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="10" placeholder="Enter Max. Amount" name="max_amount" id="max_amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-8 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                <textarea class="form-control" rows="1" maxlength="250" name="desc" id="desc" placeholder="Enter Description"></textarea>
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Facility<span class="text-danger">*</span></label>
                <select class="select3 form-select" multiple data-placeholder="Select Facility" name="facility_ids[]" id="facility_ids">
                     @if (isset($Facility_list))
                        @foreach ($Facility_list as $fc_list)
                            <option value="{{ $fc_list->sno }}">{{ $fc_list->facility_name }}</option>
                        @endforeach
                    @endif
                </select>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                <select class="select3 form-select" multiple data-placeholder="Select Deliverables" name="deliverables_ids[]" id="deliverables_ids">
                     @if (isset($Deliverables_list))
                        @foreach ($Deliverables_list as $pd_list)
                            <option value="{{ $pd_list->sno }}">{{ $pd_list->delivarable_name }}</option>
                        @endforeach
                    @endif
                </select>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Slot Notes<span class="text-danger">*</span></label>
                <select class="select3 form-select" multiple data-placeholder="Select Facility" name="slot_notes_ids[]" id="slot_notes_ids">
                     @if (isset($Slot_Notes_list))
                        @foreach ($Slot_Notes_list as $sn_list)
                            <option value="{{ $sn_list->sno }}">{{ $sn_list->slot_notes_name }}</option>
                        @endforeach
                    @endif
                </select>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Tools</label>
                <select class="select3 form-select" multiple data-placeholder="Select Tools" name="tools_ids[]" id="tools_ids">
                     @if (isset($Tools_list))
                        @foreach ($Tools_list as $ts_list)
                            <option value="{{ $ts_list->sno }}">{{ $ts_list->product_tools_name }}</option>
                        @endforeach
                    @endif
                </select>
                <div class="error_msg text-danger"></div>
              </div>
            </div>
            <div class="d-flex justify-content-end align-items-center mt-6">
              <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
              <button type="button" class="btn btn-primary"  onclick="AddvalidateForm()">Create Product</button>
            </div>
          </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Product-->

<!--begin::Modal - Update Product-->
<div class="modal fade" id="kt_modal_update_product" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">Update Product</h3>
        </div>
        <form method="POST" action="{{ route('product_update') }}" id="edit_form">
            @csrf
            <div class="row mb-3">
              <div class="col-lg-4 mb-3">
                <input type="hidden" name="edit_id" id="edit_id">
                <label class="text-black mb-1 fs-6 fw-semibold">Product Category<span class="text-danger">*</span></label>
                <select class="select3 form-select" name="product_cat_id" id="product_cat_id_edit">
                  <option value="">Select Product Category</option>
                    @if (isset($Product_cat_list))
                        @foreach ($Product_cat_list as $pc_list)
                            <option value="{{ $pc_list->sno }}">{{ $pc_list->product_category_name }}</option>
                        @endforeach
                    @endif
                </select>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Product Name<span class="text-danger">*</span></label>
                <input type="text" maxlength="80" name="product_name" id="product_name_edit" class="form-control" placeholder="Enter Product Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                <div class="error_msg text-danger" id="product_name_edit_err"></div>
              </div>
              <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Delivery Duration<span class="text-danger">*</span></label>
                <div class="d-flex align-items-center">
                  <input type="text" class="form-control me-2" maxlength="3" placeholder="Enter Value" name="duration" id="duration_edit" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                  <div class="w-99">
                    <select class="select3 form-select" name="duration_in" id="duration_in_edit">
                      <option value="">Select Duration</option>
                      <option value="0">Minutes</option>
                      <option value="1">Hours</option>
                      <option value="2">Days</option>
                    </select>
                  </div>
                </div>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Base Price<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="10" placeholder="Enter Base Price" name="base_price" id="base_price_edit" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Min. Amount<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="10" placeholder="Enter Min. Amount" name="min_amount" id="min_amount_edit" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Max. Amount<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="10" placeholder="Enter Max. Amount" name="max_amount" id="max_amount_edit" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-8 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                <textarea class="form-control" rows="1" name="desc" id="desc_edit" maxlength="250" placeholder="Enter Description"></textarea>
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Facility<span class="text-danger">*</span></label>
                <select class="select3 form-select" multiple data-placeholder="Select Facility" name="facility_ids[]" id="facility_ids_edit">
                     @if (isset($Facility_list))
                        @foreach ($Facility_list as $fc_list)
                            <option value="{{ $fc_list->sno }}">{{ $fc_list->facility_name }}</option>
                        @endforeach
                    @endif
                </select>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                <select class="select3 form-select" multiple data-placeholder="Select Deliverables" name="deliverables_ids[]" id="deliverables_ids_edit">
                     @if (isset($Deliverables_list))
                        @foreach ($Deliverables_list as $pd_list)
                            <option value="{{ $pd_list->sno }}">{{ $pd_list->delivarable_name }}</option>
                        @endforeach
                    @endif
                </select>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Slot Notes<span class="text-danger">*</span></label>
                <select class="select3 form-select" multiple data-placeholder="Select Facility" name="slot_notes_ids[]" id="slot_notes_ids_edit">
                     @if (isset($Slot_Notes_list))
                        @foreach ($Slot_Notes_list as $sn_list)
                            <option value="{{ $sn_list->sno }}">{{ $sn_list->slot_notes_name }}</option>
                        @endforeach
                    @endif
                </select>
                <div class="error_msg text-danger"></div>
              </div>
              <div class="col-lg-12 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Tools</label>
                <select class="select3 form-select" multiple data-placeholder="Select Tools" name="tools_ids[]" id="tools_ids_edit">
                     @if (isset($Tools_list))
                        @foreach ($Tools_list as $ts_list)
                            <option value="{{ $ts_list->sno }}">{{ $ts_list->product_tools_name }}</option>
                        @endforeach
                    @endif
                </select>
                <div class="error_msg text-danger"></div>
              </div>
            </div>
            <div class="d-flex justify-content-end align-items-center mt-6">
              <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
              <button type="button" class="btn btn-primary"  onclick="EditvalidateForm()">Update Product</button>
            </div>
          </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Product-->

<!--begin::Modal - View Product-->
<div class="modal fade" id="kt_modal_view_product" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8">
          <h3 class="mb-4 text-black text-center">View Product</h3>
        </div>
        <div class="row">
          <div class="col-lg-6 mt-2">
            <div class="row mb-4">
              <label class="col-4 text-dark fs-6 fw-semibold">Product</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <div class="col-7">
                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom"  id="product_name_view">-</div>
              </div>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-dark fs-6 fw-semibold">Product Category</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <div class="col-7">
                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" id="product_cat_view">-</div>
              </div>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-dark fs-6 fw-semibold">Delivery Duration</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <div class="col-7">
                <div class="badge bg-warning rounded text-black fs-7 fw-semibold" id="product_duration">-</div>
              </div>
            </div>
          </div>
          <div class="col-lg-6 mt-2">
            <div class="row mb-4">
              <label class="col-4 text-dark fs-6 fw-semibold">Base Price</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <div class="col-7 text-black fs-6 fw-bold">&#8377; <span id="base_price_view">0</span></div>
            </div>
            <div class="row mb-4">
              <label class="col-4 text-dark fs-6 fw-semibold">Min. / Max Amount</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <div class="col-7">
                <label class="badge bg-success text-black fs-7 fw-semibold mb-1">&#8377; <span id="min_amount_view">0</span></label>
                <label class="text-black fs-7 fw-bold ms-1 me-1">|</label>
                <label class="badge bg-danger text-white fs-7 fw-semibold mb-1">&#8377; <span id="max_amount_view">0</span></label>
              </div>
            </div>
          </div>
        </div>
        <div class="row mb-4">
          <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Description</label>
          <label class="col-12 text-black text-justify fs-6 fw-bold">&emsp;&emsp;&emsp; <span id="desc_view">-</span></label>
        </div>
        <div class="col-lg-12 mb-2" id="tools_view">
            
       </div>
        <div class="row mb-6">
          <div class="col-lg-6 mb-2">
            <div class="border border-gray-700 rounded pb-2">
              <div class="d-flex align-items-center justify-content-between border-bottom bg-label-info">
                <div class="mb-0 ps-3 py-2">
                  <label class="text-black fw-semibold fs-6">Facility Details</label>
                </div>
                <div class="me-3">
                  <div class="badge bg-secondary rounded fs-6"><span id="fac_count_view">0</span></div>
                </div>
              </div>
              <div class="scroll-y max-h-200px min-h-200px px-3 py-2">
                <div class="row" id="facility_div">
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6 mb-2">
            <div class="border border-gray-700 rounded pb-2">
              <div class="d-flex align-items-center justify-content-between border-bottom bg-label-success">
                <div class="mb-0 ps-3 py-2">
                  <label class="text-black fw-semibold fs-6">Product Variant Details</label>
                </div>
                <div class="me-3">
                  <div class="badge bg-info text-white rounded fs-6" id="var_count">00</div>
                </div>
              </div>
              <div class="scroll-y max-h-200px min-h-200px px-3 py-2">
                <div class="row" id="variant_div">
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6 mb-2">
            <div class="border border-gray-800 rounded pb-2">
              <div class="d-flex align-items-center justify-content-between border-bottom bg-label-warning">
                <div class="mb-0 ps-3 py-2">
                  <label class="text-black fw-semibold fs-6">Deliverables Details</label>
                </div>
                <div class="me-3">
                  <div class="badge bg-warning text-black fw-semibold rounded fs-6" id="deli_count">00</div>
                </div>
              </div>
              <div class="scroll-y max-h-200px min-h-200px px-3 py-2">
                <div class="row" id="deli_div">
                  
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6 mb-2">
            <div class="border border-gray-800 rounded pb-2">
              <div class="d-flex align-items-center justify-content-between border-bottom bg-label-secondary">
                <div class="mb-0 ps-3 py-2">
                  <label class="text-black fw-semibold fs-6">Slot Notes Details</label>
                </div>
                <div class="me-3">
                  <div class="badge bg-success text-black fw-semibold rounded fs-6" id="s_notes_count">00</div>
                </div>
              </div>
              <div class="scroll-y max-h-200px min-h-200px px-3 py-2">
                <div class="row" id="s_notes_div">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - View Product-->

<!--begin::Modal - Delete Product-->
<div class="modal fade" id="kt_modal_delete_product" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Product ?
        <div class="d-block text-black fw-semibold fs-5 mt-3 py-2">
          <label id="del_product">-</label>
          <span class="ms-2 me-2">-</span>
          <label id="del_category">-</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="button" class="btn btn-danger me-3" onclick="delete_confirm()">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Product-->


<!--begin::Modal - Add Product Variant-->
<div class="modal fade" id="kt_modal_add_product_variant" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">Create <span class="text-info fw-bold" id="add_variant_name">-</span> Product Variant</h3>
        </div>

        <form method="POST" action="{{ route('add_variant_product') }}" id="AddvariantForm">
          @csrf
          <input type="hidden" name="add_variant_sno" id="add_variant_sno">
          <input type="hidden" name="add_variant_cat" id="add_variant_cat">
          <div class="scroll-y max-h-500px px-3 py-1 mb-4">
            <div class="form-repeater_section">
              <div data-repeater-list="group-a_sec">
                <div data-repeater-item_SEC>
                  <div class="row mb-4">
                    <div class="col-lg-11">
                      <div class="card rounded">
                        <div class="card-action">
                          <div class="card-header section_add bg-gray-200 px-3 py-2 collapsed">
                            <div class="card-action-title w-100">
                              <label class="text-black mb-1 fs-6 fw-semibold" for="variant_name_0_0"
                                >Variant Name<span class="text-danger">*</span></label
                              >
                              <input
                                type="text"
                                class="form-control variant_name_input"
                                placeholder="Enter Variant Name" maxlength="80"
                                name="variant_name[0][]"
                                id="variant_name_0_0"
                              />
                            </div>
                            <div class="card-action-element d-flex align-items-center">
                              <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                  <a href="javascript:;" class="syll_section_add">
                                    <i class="mdi mdi-chevron-down fs-3"></i>
                                  </a>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div class="collapse section_add border show">
                          <div class="card-body">
                            <div class="form-repeater_topic">
                              <div data-repeater-list_TOP>
                                <div data-repeater-item_TOP>
                                  <div class="row border border-secondary rounded px-0 py-2">
                                    <div class="col-lg-11">
                                        <div class="row">
                                            <div class="col-lg-6">
                                              <label class="text-black mb-1 fs-6 fw-semibold" >Variable Name<span class="text-danger">*</span></label>
                                              <input
                                                type="text"
                                                class="form-control variable_name_input"
                                                placeholder="Enter Variable Name" maxlength="80"
                                                name="variable_name[0][]"
                                                id="variable_name_0_0"
                                              />
                                            </div>
                                            <div class="col-lg-6">
                                              <label class="text-black mb-1 fs-6 fw-semibold" maxlength="10">Amount<span class="text-danger">*</span></label>
                                              <input
                                                type="text"
                                                class="form-control amount_input"
                                                placeholder="Enter Amount"
                                                name="amount[0][]" maxlength="10"
                                                id="amount_0_0" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
                                              />
                                            </div>
                                        </div>
                                        <div class="row pages_row" style="display:none !important;">
                                            <div class="col-lg-6">
                                              <label class="text-black mb-1 fs-6 fw-semibold" >Minimum Pages <span class="text-danger">*</span></label>
                                              <input type="text" class="form-control min_input" name="min_pages[0][]" id="min_pages_0_0" placeholder="Enter Minimum Pages" maxlength="5" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                                            </div>
                                            <div class="col-lg-6">
                                              <label class="text-black mb-1 fs-6 fw-semibold" >Maximum Pages <span class="text-danger">*</span></label>
                                              <input type="text" class="form-control max_input" placeholder="Enter Maximum Pages" name="max_pages[0][]"id="max_pages_0_0" maxlength="5" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6">
                                              <label class="text-black mb-1 fs-6 fw-semibold" >Production Hours <span class="text-danger">*</span></label>
                                              <input type="text" class="form-control production_hours_input" placeholder="Enter Production Hours" name="production_hours[0][]"id="production_hours_0_0" maxlength="5" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                                            </div>
                                        </div>
                                    </div>  
                                    
                                    <div class="col-lg-1 mb-3">
                                      {{-- <a
                                        href="javascript:;"
                                        class="btn btn-outline-danger mt-6 px-0 py-1 topic_butt_del"
                                        style="display:none;"
                                      >
                                        <i class="mdi mdi-delete fs-4"></i>
                                      </a> --}}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="mb-1 mt-3 d-flex justify-content-end align-items-end">
                              <button
                                type="button"
                                class="btn btn-sm btn-primary topic_butt_add fs-8 px-2 py-1"
                              >
                                <i class="mdi mdi-plus me-1"></i>Add Variable
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      class="col-lg-1 mb-3 d-flex align-items-start justify-content-end"
                    >
                      {{-- <a
                        href="javascript:;"
                        class="btn btn-outline-danger mt-6 px-1 py-2 section_butt_del"
                        style="display: none"
                      >
                        <i class="mdi mdi-delete fs-4"></i>
                      </a> --}}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="mb-1 mt-1 d-flex justify-content-end align-items-end me-4">
            <button
              type="button"
              class="btn btn-sm btn-primary section_butt_add fs-8 px-2 py-1"
              id="main_add_more"
            >
              <i class="mdi mdi-plus me-1"></i>Add Variant
            </button>
          </div>

          <div class="d-flex justify-content-center align-items-center mt-6">
            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
            <button type="button" class="btn btn-primary" onclick="AddvalidateForm_variant()" id="btn_submit_add">Create Product Variant</button>
          </div>
        </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Product Variant-->

<!-- begin::Modal - Update Product Variant -->
<div class="offcanvas offcanvas-end w-600px" id="kt_modal_update_product_variant" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" style="border-top-left-radius: 15px !important;border-bottom-left-radius: 15px !important;">
  <div class="offcanvas-header border-bottom mb-1">
    <h4 class="offcanvas-title text-center text-black">Update <span class="text-info fw-bold" id="update_variant_name">-</span> Product Variant</h4>
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close" onclick="empty_div()"></button>
  </div>
 
    <div class="offcanvas-body flex-grow-1 py-0 px-2 mb-1">
        <form method="POST" action="{{ route('upadte_variant_product') }}" id="EditvariantForm">
            @csrf
          <div class="mb-0 px-4 pt-2 pb-1" id="add_more_edit_div">
          </div>
          <div class="d-flex justify-content-center align-items-end mt-3 mb-3">
              <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="offcanvas" onclick="empty_div()">Cancel</a>
              <button type="button" class="btn btn-primary" onclick="EditvalidateForm_variant()" id="btn_submit_edit">Update Product Variant</button>
          </div>
       </form>
    </div>
</div>
<!-- end::Modal - Update Product Variant -->

{{-- Create Tasks --}}
<div class="modal fade" id="kt_modal_add_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
  data-bs-backdrop="static">
  <div class="modal-dialog modal-xl">
    <div class="modal-content rounded shadow">
      <!-- Modal Header -->
      <div class="modal-header justify-content-end border-0 pb-0">
        <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" fill="none" viewBox="0 0 24 24">
              <rect opacity="0.5" x="6" y="17.3" width="16" height="2" rx="1" transform="rotate(-45 6 17.3)"
                fill="currentColor" />
              <rect x="7.4" y="6" width="16" height="2" rx="1" transform="rotate(45 7.4 6)" fill="currentColor" />
            </svg>
          </span>
        </button>
      </div>

      <!-- Modal Body -->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black"><span id="task_to"></span> <span class="text-info fw-bold" id="product_task_name">-</span> Task</h3>
        </div>

        <form method="POST" action="{{ route('add_product_tasks') }}" id="AddTaskForm">
          @csrf
          <input type="hidden" name="product_task_id" id="product_task_id">
          <input type="hidden" name="task_to_hidden" id="task_to_hidden">
          <div class="scroll-y max-h-600px px-3 py-1 mb-4" id="task_card_container">
            <!-- Task Card -->
            <div class="task-row d-flex align-items-start mb-4" data-index="0">
              <!-- Card -->
              <div class="task-card flex-grow-1">
              </div>
              <!-- Delete button OUTSIDE the card -->
            </div>
          </div>

          <!-- Add More Task Button -->
          <div class="mb-3">
            <button type="button" class="btn btn-sm btn-primary" id="add_more_task"><i class="mdi mdi-plus"></i> Add
              More Task</button>
          </div>

          <!-- Action Buttons -->
          <div class="d-flex justify-content-center align-items-center mt-6">
            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary" id="task_st_btn">Create Task</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<input type="hidden" id="product_task_delete">
<!--begin::Modal - Delete variant-->
<div class="modal fade" id="kt_modal_product_task_delete" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-dialog-centered modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                <span id="product_task_delete_message"></span>
            </div>
            <input type="hidden" id="product_task_delete_id">
            <div class="row" id="product_task_delete_button">

            </div>
            <br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete variant-->

<input type="hidden"  id="task_checklist_delete">
<!--begin::Modal - Delete variable-->
<div class="modal fade" id="kt_modal_task_checklist_delete" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-dialog-centered modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                <span id="task_checklist_delete_message"></span>
            </div>
            <input type="hidden" id="task_checklist_delete_id">
            <div class="row" id="task_checklist_delete_button">

            </div>
            <br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete variable-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
       /* Customize Toastr container */
       .toast {
           background-color: #39484f;
       }
    
       /* Customize Toastr notification */
       .toast-success {
           background-color: green;
       }
    
       /* Customize Toastr notification */
       .toast-error {
           background-color: red;
       }
       .err_msg{
        /* background-color: red; */
        border-color: red;
       }
    
    </style>
    <script>
       // Display Toastr messages
       @if (Session::has('toastr'))
           var type = "{{ Session::get('toastr')['type'] }}";
           var message = "{{ Session::get('toastr')['message'] }}";
           toastr[type](message);
       @endif
    </script>
    <script>
        function sort_filter(val) {
            if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
            } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
            }
        }
    </script>

    <script>
    function deleteproduct_task(element, id, del_id) {
        if (del_id !== '') {
            $('#product_task_delete').click();

            const name = $('#task_name_' + id ).val() || '';
            $('#product_task_delete_id').val(del_id);
            $('#product_task_delete_message').html(
                'Are you sure you want to delete Product Task <br> <b class="text-danger">' + name + '</b> ?'
            );

            $('#product_task_delete_button').html(`
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="button" class="btn btn-danger me-3" onclick="delete_task_confirm('${del_id}', '${id}')">Yes, delete!</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, cancel</button>
                </div>
            `);
        }
    }

    function delete_task_confirm(delid, row_id) {
        const delete_id = delid;
    
        fetch('/product_task_delete/' + delete_id, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                $(`#task_card_container .task-row[data-index="${row_id}"]`).remove();
                toastr.success('Product Task Deleted successfully!');
                
                // Hide the delete modal properly
                const deleteModalEl = document.getElementById('kt_modal_product_task_delete');
                const deleteModal = bootstrap.Modal.getInstance(deleteModalEl);
                if (deleteModal) {
                    deleteModal.hide();
                }
            } else {
                toastr.error(data.error_msg || 'Something went wrong');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            toastr.error('Unexpected error occurred');
        });
    }

        
        document.getElementById("product_task_delete").addEventListener("click", function () {
            const deleteModal = new bootstrap.Modal(document.getElementById('kt_modal_product_task_delete'), {
                backdrop: 'static',
                keyboard: false
            });
            deleteModal.show();
        });

    </script>
    
    <script>
    function deletetask_chk_list(element, id, del_id) {
        if (del_id !== '') {
            $('#task_checklist_delete').click();
            // alert(del_id)
            const name = $(`#checklist_${id}_${del_id}`).val() || '';
            $('#task_checklist_delete_id').val(del_id);
            $('#task_checklist_delete_message').html(
                'Are you sure you want to delete Product Task Checklist <br> <b class="text-danger">' + name + '</b> ?'
            );

            $('#task_checklist_delete_button').html(`
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="button" class="btn btn-danger me-3" onclick="delete_task_checklist_confirm('${del_id}', '${id}')">Yes, delete!</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, cancel</button>
                </div>
            `);
        }
    }

    function delete_task_checklist_confirm(delid, row_id) {
        const delete_id = delid;

        fetch('/product_task_checklist_delete/' + delete_id, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                $("#task_checklist_div_" + row_id + '_' + delid).remove();
                // Safely find and remove the section
                toastr.success('Product Variable Deleted successfully!');
                // Hide the delete modal properly
                const deleteModalEl = document.getElementById('kt_modal_task_checklist_delete');
                const deleteModal = bootstrap.Modal.getInstance(deleteModalEl);
                if (deleteModal) {
                    deleteModal.hide();
                }

            } else {
                // console.error(data.error_msg || 'Unknown error');
            }
        })
        .catch(error => {
            // console.error('Error:', error);
        });
    }
     document.getElementById("task_checklist_delete").addEventListener("click", function () {
            const deleteModal = new bootstrap.Modal(document.getElementById('kt_modal_task_checklist_delete'), {
                backdrop: 'static',
                keyboard: false
            });
            deleteModal.show();
        });
</script>
<script>
        function confirmDelete(sno, name,cat) {
            document.querySelector('#kt_modal_delete_product .btn-danger').setAttribute('data-id', sno);
            $('#del_product').html(name);
            $('#del_category').html(cat);
        }

      // Form validation on submit
      $('#AddTaskForm').on('submit', function (e) {
        e.preventDefault(); // Prevent actual form submission
    
        let isValid = true;
    
        // Clear previous errors
        $('.invalid-feedback').text('');
        $('.form-control, .form-select').removeClass('is-invalid');
    
        // Validate each task row
        $('.task-row').each(function () {
          // Task name
          const taskInput = $(this).find('input[name="task_name[]"]');
          if (!taskInput.val().trim()) {
            taskInput.addClass('is-invalid');
            taskInput.siblings('.invalid-feedback').text('Task name is required.');
            isValid = false;
          }
    
          // Unit select
          const unitSelect = $(this).find('select[name="unit[]"]');
          if (!unitSelect.val()) {
            unitSelect.addClass('is-invalid');
            unitSelect.siblings('.invalid-feedback').text('Select a unit is required.');
            isValid = false;
          }
    
          // Hours select
          const hoursSelect = $(this).find('select[name="hours[]"]');
          if (!hoursSelect.val()) {
            hoursSelect.addClass('is-invalid');
            hoursSelect.siblings('.invalid-feedback').text('Select Working Hours is required.');
            isValid = false;
          }
    
          // Checklist items
          $(this).find('.checklist-item').each(function () {
            const checklistInput = $(this).find('input[type="text"]');
            if (!checklistInput.val().trim()) {
              checklistInput.addClass('is-invalid');
              checklistInput.siblings('.invalid-feedback').text('Checklist is required.');
              isValid = false;
            }
          });
        });
    
        if (isValid) {
          // If everything is valid, allow actual form submission
          this.submit();
        }
      });
    </script>
<script>
        function delete_confirm() {
    
            var delete_id = document.querySelector('#kt_modal_delete_product .btn-danger').getAttribute('data-id');
    
            fetch('/product_delete/' + delete_id, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Product Deleted successfully!');
                        location.reload();
    
                    } else {
    
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    </script>
<script>
        function SwitchStatus(UniversityId, isChecked) {
          const status = isChecked ? 0 : 1; // Set status based on checkbox state

          fetch(`/product_status/${UniversityId}`, {
                  method: 'POST',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                  },
                  body: JSON.stringify({
                      status: status
                  })
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      console.log('Product Status updated successfully:', data.message);
                      toastr.success('Product Status Updated successfully!');
                  } else {
                      console.error('Error updating Product Status:', data.message);
                      toastr.error('Error updating Product Status');
                  }
              })
              .catch(error => {
                  console.error('Error updating Product status:', error);
              });
        }
  </script>
<script>
        function AddvalidateForm() {
            let isValid = 0;

            // Clear all previous errors
            document.querySelectorAll('.error_msg').forEach(div => {
                div.innerText = '';
            });

            // Helper to set error
            function setError(id, message) {
                document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
                isValid = 1;
            }

            // Required fields validation
            const requiredFields = [{
                    id: 'product_cat_id',
                    name: 'Select Product Category'
                },
                {
                    id: 'product_name',
                    name: 'Enter Product Name'
                },
                {
                    id: 'duration',
                    name: 'Enter  Duration'
                },
                {
                    id: 'duration_in',
                    name: 'Select Duration In'
                },
                {
                    id: 'base_price',
                    name: 'Enter Base Price'
                },
                {
                    id: 'min_amount',
                    name: 'Enter Minimum Amount'
                },
                {
                    id: 'max_amount',
                    name: 'Enter Maximum Amount'
                },
                {
                    id: 'facility_ids',
                    name: 'Select Facilities'
                },
                {
                    id: 'deliverables_ids',
                    name: 'Select Deliverables'
                },
                {
                    id: 'slot_notes_ids',
                    name: 'Select Slot Notes'
                }
            ];

            requiredFields.forEach(field => {
                const value = document.getElementById(field.id).value.trim();
                if (value === '') {
                    setError(field.id, `${field.name} is required.`);
                }
            });

            const maximum_cost = parseFloat(document.getElementById("max_amount").value.trim()) || 0;
            const minimum_cost = parseFloat(document.getElementById("min_amount").value.trim()) || 0;
            // Compare Minimum and Maximum Costs
            if (minimum_cost > maximum_cost) {
                setError('min_amount', 'Min Amount should be less than Max Amount');
            }

            
            if (isValid == 0) {
                $('#add_form').submit();
            }
        }
        function EditvalidateForm() {
            let isValid = 0;

            // Clear all previous errors
            document.querySelectorAll('.error_msg').forEach(div => {
                div.innerText = '';
            });

            // Helper to set error
            function setError(id, message) {
                document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
                isValid = 1;
            }

            // Required fields validation
            const requiredFields = [{
                    id: 'product_cat_id_edit',
                    name: 'Select Product Category'
                },
                {
                    id: 'product_name_edit',
                    name: 'Enter Product Name'
                },
                {
                    id: 'duration_edit',
                    name: 'Enter Duration'
                },
                {
                    id: 'duration_in_edit',
                    name: 'Select Duration In'
                },
                {
                    id: 'base_price_edit',
                    name: 'Enter Base Price'
                },
                {
                    id: 'min_amount_edit',
                    name: 'Enter Minimum Amount'
                },
                {
                    id: 'max_amount_edit',
                    name: 'Enter Maximum Amount'
                },
                {
                    id: 'facility_ids_edit',
                    name: 'Select Facilities'
                },
                {
                    id: 'deliverables_ids_edit',
                    name: 'Select Deliverables'
                },
                {
                    id: 'slot_notes_ids_edit',
                    name: 'Select Slot Notes'
                }
            ];

            requiredFields.forEach(field => {
                const value = document.getElementById(field.id).value.trim();
                if (value === '') {
                    setError(field.id, `${field.name} is required.`);
                }
            });

            const maximum_cost = parseFloat(document.getElementById("max_amount_edit").value.trim()) || 0;
            const minimum_cost = parseFloat(document.getElementById("min_amount_edit").value.trim()) || 0;
            // Compare Minimum and Maximum Costs
            if (minimum_cost > maximum_cost) {
                setError('min_amount_edit', 'Min Amount should be less than Max Amount');
            }

            
            if (isValid == 0) {
                $('#edit_form').submit();
            }
        }
    </script>
<script>
        function editmodel(id) {
            fetch('/product_edit/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        console.log(data.data);
                        var com = data.data;
                        $('#edit_id').val(id);
                        $('#product_name_edit').val(com.product_name);
                        $('#product_cat_id_edit').val(com.product_category_id).change();
                        $('#duration_edit').val(com.duration);
                        $('#duration_in_edit').val(com.duration_in).change();
                        $('#base_price_edit').val(com.base_price);
                        $('#min_amount_edit').val(com.min_amount);
                        $('#max_amount_edit').val(com.max_amount);
                        $('#desc_edit').val(com.product_desc);

                        let facility_ids = [];

                        try {
                            facility_ids = JSON.parse(com.facility_ids).map(id => id.toString().trim());
                        } catch (e) {
                        }                        
                        $('#facility_ids_edit').val(facility_ids||'').change();
                        let deliverables_ids = [];

                        try {
                            deliverables_ids = JSON.parse(com.deliverables_ids).map(id => id.toString().trim());
                        } catch (e) {
                        }                        
                        $('#deliverables_ids_edit').val(deliverables_ids||'').change();
                        let slot_notes_ids = [];

                        try {
                            slot_notes_ids = JSON.parse(com.slot_notes_ids).map(id => id.toString().trim());
                        } catch (e) {
                        }                        
                        $('#slot_notes_ids_edit').val(slot_notes_ids||'').change();
                        let tools_ids = [];

                        try {
                            tools_ids = JSON.parse(com.tools_ids).map(id => id.toString().trim());
                        } catch (e) {
                        }                        
                        $('#tools_ids_edit').val(tools_ids||'').change();
                    } else {
                        // console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    // console.error('Error:', error);
                });
        }
    </script>
<script>
        function formatCurrency(amt) {
            var roundedAmt = parseFloat(amt);
            var isWhole = Number.isInteger(roundedAmt);
        
            return roundedAmt.toLocaleString('en-IN', {
                minimumFractionDigits: isWhole ? 0 : 2,
                maximumFractionDigits: isWhole ? 0 : 2
            });
        }
        function Viewmodel(id) {
            fetch('/product_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        // console.log(data.data);
                        var com = data.data;
                        $('#product_name_view').html(com.product_name).attr('title', com.product_name);
                        $('#product_cat_view').html(com.product_category_name).attr('title', com.product_category_name);
                        if(com.duration_in==0){
                          var dur = 'Minute';
                        }else if(com.duration_in==1){
                          var dur = 'Hours';
                        }
                        else if(com.duration_in==2){
                          var dur = 'Days';
                        }
                         var  duration = formatCurrency(com.duration)+' '+dur;

                        $('#product_duration').html(duration).attr('title', duration);
                        $('#base_price_view').html(formatCurrency(com.base_price)).attr('title', formatCurrency(com.base_price));
                        $('#max_amount_view').html(formatCurrency(com.max_amount)).attr('title', formatCurrency(com.max_amount));
                        $('#min_amount_view').html(formatCurrency(com.min_amount)).attr('title', formatCurrency(com.min_amount));
                        $('#desc_view').html(com.product_desc||'').attr('title', com.product_desc||'');
                        $('#facility_div').html(com.fac_div);
                        $('#variant_div').html(com.var_div);
                        $('#fac_count_view').html(com.fac_count);
                        $('#tools_view').html(com.tools_view);
                        $('#var_count').html(com.var_count);
                        $('#deli_count').html(com.deli_count);
                        $('#deli_div').html(com.deli_div);
                        $('#s_notes_count').html(com.s_notes_count);
                        $('#s_notes_div').html(com.s_notes_div);
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        // console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    // console.error('Error:', error);
              });
             
        }
    </script>
<script>
      function AddVariantmodel(id,name,cat){
        $('#add_variant_sno').val(id);
        $('#add_variant_cat').val(cat);
        $('#add_variant_name').html(name);
        
        if(cat == 1){
            $('.pages_row').show();
        }else{
            $('.pages_row').hide();
        }
      }
</script>
<script>
      $(document).ready(function () {
        // Update all IDs and names with indexing [sectionIndex][variableIndex]
        function updateIds() {
          $('[data-repeater-item_SEC]').each(function (secIndex) {
            // Update variant_name inputs in this section
            const variantInput = $(this).find('.variant_name_input').first();
            variantInput.attr('id', 'variant_name_' + secIndex + '_0');
            variantInput.attr('name', 'variant_name[' + secIndex + '][]');
            variantInput.prev('label').attr('for', 'variant_name_' + secIndex + '_0');

            // Update variables inside this section
            $(this)
              .find('[data-repeater-item_TOP]')
              .each(function (varIndex) {
                const variableInput = $(this).find('.variable_name_input').first();
                variableInput.attr(
                  'id',
                  'variable_name_' + secIndex + '_' + varIndex
                );
                variableInput.attr(
                  'name',
                  'variable_name[' + secIndex + '][]'
                );
                variableInput
                  .prev('label')
                  .attr('for', 'variable_name_' + secIndex + '_' + varIndex);

                const amountInput = $(this).find('.amount_input').first();
                amountInput.attr('id', 'amount_' + secIndex + '_' + varIndex);
                amountInput.attr('name', 'amount[' + secIndex + '][]');
                
                const min_input = $(this).find('.min_input').first();
                min_input.attr('id', 'min_pages' + secIndex + '_' + varIndex);
                min_input.attr('name', 'min_pages[' + secIndex + '][]');
                
                const max_input = $(this).find('.max_input').first();
                max_input.attr('id', 'max_pages' + secIndex + '_' + varIndex);
                max_input.attr('name', 'max_pages[' + secIndex + '][]');

                const production_hours = $(this).find('.production_hours_input').first();
                production_hours.attr('id', 'production_hours' + secIndex + '_' + varIndex);
                production_hours.attr('name', 'production_hours[' + secIndex + '][]');

                const topic_butt_del = $(this).find('.topic_butt_div').first();
                console.log(topic_butt_del);
                topic_butt_del.addClass('topic_butt_del_class_' + varIndex);


              });
              $('.topic_butt_del_class_0').hide();
          });
        }

        // Function to get new variable HTML block
        function getNewVariableHtml() {
            var cat = $('#add_variant_cat').val();
            
            if(cat == 1){
              var  show_page = 'flex';
              var  show_class = 'mt-8';
            }else{
               var  show_page = 'none';
               var  show_class = '';
            }
          return `
            <div data-repeater-item_TOP>
              
              <div class="row border border-secondary rounded px-0 py-2 mt-2">
                <div class="col-lg-11">
                    <div class="row">
                        <div class="col-lg-6">
                          <label class="text-black mb-1 fs-6 fw-semibold" >Variable Name<span class="text-danger">*</span></label>
                          <input
                            type="text"
                            class="form-control variable_name_input"
                            placeholder="Enter Variable Name" maxlength="80"
                            name=""
                            id=""
                          />
                        </div>
                        <div class="col-lg-6">
                          <label class="text-black mb-1 fs-6 fw-semibold" maxlength="10">Amount<span class="text-danger">*</span></label>
                          <input
                            type="text"
                            class="form-control amount_input"
                            placeholder="Enter Amount"
                            name="" maxlength="10"
                            id="" oninput="this.value = this.value.replace(/\\D/g,'')"
                          />
                        </div>
                    </div>
                    <div class="row pages_row" style="display:${show_page}">
                        <div class="col-lg-6">
                          <label class="text-black mb-1 fs-6 fw-semibold" >Minimum Pages <span class="text-danger">*</span></label>
                          <input type="text" class="form-control min_input" name="" id="" placeholder="Enter Minimum Pages" maxlength="5" oninput="this.value = this.value.replace(/\\D/g,'')" />
                        </div>
                        <div class="col-lg-6">
                          <label class="text-black mb-1 fs-6 fw-semibold" maxlength="10">Maximum Pages <span class="text-danger">*</span></label>
                          <input type="text" class="form-control max_input" placeholder="Enter Maximum Pages" name="" id="" maxlength="5" oninput="this.value = this.value.replace(/\\D/g,'')" />
                        </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-6">
                          <label class="text-black mb-1 fs-6 fw-semibold" maxlength="10">Production Hours <span class="text-danger">*</span></label>
                          <input type="text" class="form-control production_hours_input" placeholder="Enter Production Hours" name="" id="" maxlength="5" oninput="this.value = this.value.replace(/\\D/g,'')" />
                        </div>
                    </div>
                </div>  
                <div class="col-lg-1 mb-3 topic_butt_div ${show_class}">
                  <a href="javascript:;" class="btn btn-outline-danger mt-6 px-0 py-1 topic_butt_del">
                    <i class="mdi mdi-delete fs-4"></i>
                  </a>
                </div>
              </div>
            </div>
          `;
        }

        // Function to get new variant section HTML block
        function getNewSectionHtml() {
          return `
            <div data-repeater-item_SEC>
              <div class="row mb-4">
                <div class="col-lg-11">
                  <div class="card rounded">
                    <div class="card-action">
                      <div class="card-header section_add bg-gray-200 px-3 py-2 collapsed">
                        <div class="card-action-title w-100">
                          <label class="text-black mb-1 fs-6 fw-semibold" for="">Variant Name<span class="text-danger">*</span></label>
                          <input
                            type="text"
                            class="form-control variant_name_input"
                            placeholder="Enter Variant Name" maxlength="80"
                            name=""
                            id=""
                          />
                        </div>
                        <div class="card-action-element d-flex align-items-center">
                          <ul class="list-inline mb-0">
                            <li class="list-inline-item">
                              <a href="javascript:;" class="syll_section_add">
                                <i class="mdi mdi-chevron-down fs-3"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="collapse section_add border show">
                      <div class="card-body">
                        <div class="form-repeater_topic">
                          <div data-repeater-list_TOP>
                            ${getNewVariableHtml()}
                          </div>
                        </div>
                        <div class="mb-1 mt-3 d-flex justify-content-end align-items-end">
                          <button
                            type="button"
                            class="btn btn-sm btn-primary topic_butt_add fs-8 px-2 py-1"
                          >
                            <i class="mdi mdi-plus me-1"></i>Add variable
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-1 mb-3 d-flex align-items-start justify-content-end">
                  <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 section_butt_del">
                    <i class="mdi mdi-delete fs-4"></i>
                  </a>
                </div>
              </div>
            </div>
          `;
        }

        // Add new variant section
        $('#main_add_more').on('click', function () {
          $('[data-repeater-list="group-a_sec"]').append(getNewSectionHtml());
          updateIds();
        });

        // Add new variable row inside a variant section
        $(document).on('click', '.topic_butt_add', function () {
          const $topicList = $(this).closest('.card-body').find('[data-repeater-list_TOP]');
          $topicList.append(getNewVariableHtml());
          updateIds();
        });

        // Delete variable row inside a variant section
        $(document).on('click', '.topic_butt_del', function () {
          $(this).closest('[data-repeater-item_TOP]').remove();
          updateIds();
        });

        // Delete entire variant section
        $(document).on('click', '.section_butt_del', function () {
          $(this).closest('[data-repeater-item_SEC]').remove();
          updateIds();
        });

      

        // Initial setup
        updateIds();
        // Toggle collapse on variant header click
        $(document).on('click', '.syll_section_add', function () {
          const collapseDiv = $(this).closest('.card').find('.collapse.section_add');
          collapseDiv.collapse('toggle');
          $(this).toggleClass('collapsed');
        });
      });
    </script>
<script>
function AddvalidateForm_variant() {
    var err = 0;

    function showError(input, message) {
        if (err === 0) {
            Swal.fire({
                title: 'Error!',
                html: message,
                icon: 'error',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
            input.addClass('err_msg');
            err++;
        }
    }

    // Validate Variant Names
    $('.variant_name_input').each(function () {
        if (!$(this).val().trim()) {
            showError($(this), 'Enter Variant Name is Required..!');
        }else{
           $(this).removeClass('err_msg');
        }
    });

    // Validate Variable Names
    $('.variable_name_input').each(function () {
        if (!$(this).val().trim()) {
            showError($(this), 'Enter Variable Name is Required..!');
        }else{
           $(this).removeClass('err_msg');
        }
    });

    // Validate Amounts
    $('.amount_input').each(function () {
        var val = $(this).val().trim();
        if (!val || isNaN(val) || parseFloat(val) < 0) {
            showError($(this), 'Enter Amount is Required..!');
        }else{
           $(this).removeClass('err_msg');
        }
    });
    
    var cate = $('#add_variant_cat').val();
    
    if(cate == 1) {
        // Validate min pages
        $('.min_input').each(function () {
            var val = $(this).val().trim();
            if (!val || isNaN(val) || parseFloat(val) < 1) {
                showError($(this), 'Enter Minimum Pages is Required..!');
            }else{
               $(this).removeClass('err_msg');
            }
        });
        
        // Validate max pages
        $('.max_input').each(function () {
            var val = $(this).val().trim();
            if (!val || isNaN(val) || parseFloat(val) < 1) {
                showError($(this), 'Enter maximum Pages is Required..!');
            }else{
               $(this).removeClass('err_msg');
            }
        });
    } 

    // Validate max pages
        $('.production_hours_input').each(function () {
            var val = $(this).val().trim();
            if (!val || isNaN(val) || parseFloat(val) < 1) {
               showError($(this), 'Enter valid Production Hours <br> (must be greater than 1)..!');
            } else {
                $(this).removeClass('err_msg');
            }
        });



    if (err === 0) {
        // If no errors, proceed
        $('#AddvariantForm').submit();
        $('#btn_submit_add').prop('disabled', true);
        return true;
    } else {
        // Enable button if needed
        $('#btn_submit_add').prop('disabled', false);
        return false;
    }
}
</script>
<script>
  function UpdateVariantmodel(id,Name){

    $('#update_variant_name').html(Name);

  
      $.ajax({
        url: "{{ route('get_product_variant_data') }}",
        type: "GET",
        data: {
            id: id
        },
        success: function(response) {
            if (response) {
              $('#add_more_edit_div').empty().append(response);
            }
        },
        error: function(error) {
            // console.error('Error fetching course sub categories:', error);
        }
      });
    

  }
</script>
<script>
  function empty_div(){
    location.reload();
  }
</script>
<script>
 $(".list_page").DataTable({
    "ordering": false,
    "paging": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<script>
  $('#filter').click(function() {
    $('.filter_tbox').slideToggle('slow');
  });
</script>
<script>
  function date_fill_issue_rpt() {
    var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
    var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
    var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
    var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
    var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
    var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
    var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
    var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
    var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

    if (dt_fill_issue_rpt == "today") {
      today_dt_iss_rpt.style.display = "block";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else if (dt_fill_issue_rpt == "week") {
      today_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "block";
      week_to_dt_iss_rpt.style.display = "block";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";

      var curr = new Date; // get current date
      var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
      var last = first + 6; // last day is the first day + 6

      var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
      firstday = firstday.split("-").reverse().join("-");
      var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
      lastday = lastday.split("-").reverse().join("-");
      $('#week_from_date_fil').val(firstday);
      $('#week_to_date_fil').val(lastday);

    } else if (dt_fill_issue_rpt == "monthly") {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "block";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else if (dt_fill_issue_rpt == "custom_date") {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "block";
      to_dt_iss_rpt.style.display = "block";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    }
  }
</script>
<script>
  document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
    el.addEventListener('click', function () {
      // Small delay to allow modal animation to finish
      setTimeout(() => {
        location.reload();
      }, 150);
    });
  });
</script>
<script>
  let debounceTimer;

        function debounce(func, delay) {
            return function() {
                const context = this;
                const args = arguments;
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => func.apply(context, args), delay);
            };
        }

        function checkUniqueField(field, value, errorElementId, submitButtonId) {
            if (value === '') {
                $('#' + errorElementId).text('');
                return;
            }

            let sno = $('#edit_id').val() || null;

            $.ajax({
                url: '/check_duplicate_products',
                method: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    field: field,
                    value: value,
                    sno: sno
                },
                success: function(response) {
                    if (response.exists) {
                        $('#' + errorElementId).text(response.message);
                        $('#' + submitButtonId).prop('disabled', true);
                    } else {
                        $('#' + errorElementId).text('');
                        $('#' + submitButtonId).prop('disabled', false);
                    }
                }
            });
        }

        // Bind with debounce
        $('#product_name').on('input', debounce(function() {
            checkUniqueField('product_name', $(this).val(), 'product_name_err', 'create_product_btn');
        }, 600));

        $('#product_name_edit').on('input', debounce(function() {
            checkUniqueField('product_name', $(this).val(), 'product_name_edit_err', 'update_product_btn');
        }, 600));

</script>
<script>
   let taskIndex = 0; // Global tracker for next task index

function bindChecklistEvents(card) {
   const index = card.closest('.task-row').attr('data-index');

   card.find('.add-checklist-item').off('click').on('click', function () {
      const checklistItem = `
  <div class="input-group mb-2 checklist-item">
    <input type="text" class="form-control" name="checklist[${index}][]" placeholder="Enter checklist">
    <button class="btn btn-sm btn-outline-danger remove-checklist-item" type="button">
      <i class="mdi mdi-delete fs-4"></i>
    </button>
    <div class="invalid-feedback"></div>
  </div>`;
      card.find('.checklist-items').append(checklistItem);
   });

   card.off('click', '.remove-checklist-item').on('click', '.remove-checklist-item', function () {
      $(this).closest('.checklist-item').remove();
   });
}

// Toggle accordion
$(document).on('click', '.toggle-accordion', function () {
   const icon = $(this).find('.rotate-icon');
   const body = $(this).closest('.card').find('.card-body');
   body.slideToggle(200);
   icon.toggleClass('mdi-chevron-down mdi-chevron-up');
});

// Remove task card
$(document).on('click', '.remove-task', function () {
   $(this).closest('.task-row').remove();
});

// Add new task card button
$('#add_more_task').click(function () {
   addTaskCard(null, taskIndex++);
});

function addTaskCard(task, index) {
   let checklistHtml = '';
   if (task && task.checklists && task.checklists.length > 0) {
      task.checklists.forEach((item, idx) => {
            var chk_del_btn = `<button class="btn btn-sm btn-outline-danger remove-checklist-item" type="button">
                                  <i class="mdi mdi-delete fs-4"></i>
                                </button>`;
            if(item.sno){
                 var chk_del_btn = `<button class="btn btn-sm btn-outline-danger" type="button" onclick="deletetask_chk_list(this,'${index}','${item.sno}')">
                                  <i class="mdi mdi-delete fs-4"></i>
                                </button>`;
            }
          
         checklistHtml += `
          <div class="input-group mb-2 checklist-item" id="task_checklist_div_${index}_${item.sno}">
            <input type="text" class="form-control" name="checklist[${index}][]" id="checklist_${index}_${item.sno}" value="${item.task_checklist}" />
            <input type="hidden" class="form-control" name="checklist_sno[${index}][]" value="${item.sno}" placeholder="Enter checklist" />
            ${idx === 0 ? '' : `
            ${chk_del_btn}
            `}
            <div class="invalid-feedback"></div>
          </div>`;
      });
   } else {
      // no checklist items, so render one empty without delete button
      checklistHtml = `
      <div class="input-group mb-2 checklist-item">
        <input type="text" class="form-control" name="checklist[${index}][]" placeholder="Enter checklist" />
        <input type="hidden" class="form-control" name="checklist_sno[${index}][]" value="0" placeholder="Enter checklist" />
        <div class="invalid-feedback"></div>
      </div>`;
    }
   
      
    var delbth =`
      <button type="button" class="btn btn-outline-danger remove-task" 
            data-bs-toggle="tooltip"
            data-bs-placement="top"
            title="Delete">
        <i class="mdi mdi-delete fs-4"></i>
      </button>`;
      
    if(task && task.sno > 0){
       var   delbth = `<button
        type="button"
           class="btn btn-outline-danger"
            data-bs-toggle="tooltip"
            data-bs-placement="top"
            title="Delete"
            onclick="deleteproduct_task(this,'${index}','${task.sno}')">
            <i  class="mdi mdi-delete fs-4"></i>
        </button>`;
    }else{
        
    }


   const cardHtml = `
  <div class="task-row d-flex align-items-start mb-4" data-index="${index}">
    <div class="task-card flex-grow-1">
      <div class="card border shadow-sm rounded">
        <div class="card-header bg-light d-flex justify-content-between align-items-center py-3 px-4 accordion-header">
          <div class="w-100">
            <label class="form-label fw-semibold mb-1">Task Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control" name="task_name[]" id="task_name_${index}" value="${task ? task.task_name : ''}" />
            <input type="hidden" class="form-control" name="task_sno[]" value="${task ? task.sno : '0'}" />
            <div class="invalid-feedback task_name_err"></div>
          </div>
          <button type="button" class="btn btn-sm btn-icon toggle-accordion ms-3">
            <i class="mdi mdi-chevron-down fs-3 rotate-icon"></i>
          </button>
        </div>
        <div class="card-body px-4 pt-3 pb-4">
          <div class="row mb-4">
            <div class="col-md-6">
              <label class="form-label fw-semibold">Unit <span class="text-danger">*</span></label>
              <select class="select3 form-select" name="unit[]" id="unit_${index}">
                <option value="">Select Unit</option>
                @if (isset($Product_unit_list))
                    @foreach ($Product_unit_list as $unit_list)
                        <option value="{{ $unit_list->sno }}" ${task?.unit_id == {{ $unit_list->sno }} ? 'selected' : '' }>{{ $unit_list->unit_name }}</option>
                    @endforeach
                @endif
              </select>
              <div class="invalid-feedback"></div>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Hours <span class="text-danger">*</span></label>
              <select class="select3 form-select" name="hours[]" id="hours_${index}">
                <option value="">Select Hours</option>
                @php
                    $maxValue = 7; // Change as needed
                    $step = 0.5;
                @endphp
                @for ($i = $step; $i <= $maxValue; $i += $step)
                    <option value="{{$i}}" ${task?.hours_id=={{$i}} ? 'selected' : '' }>{{$i}}</option>
                @endfor
              </select>
              <div class="invalid-feedback"></div>
            </div>
          </div>
  
          <div class="checklist-section">
            <label class="form-label fw-semibold">Checklist <span class="text-danger">*</span></label>
            <div class="checklist-items">
              ${checklistHtml}
            </div>
            <button type="button" class="btn btn-sm btn-primary add-checklist-item mt-2">
              <i class="mdi mdi-plus"></i> Add More
            </button>
          </div>
        </div>
      </div>
    </div>
    
   
  
    <div class="ms-3 mt-4">
        ${delbth}
    </div>
  </div>`;

   $('#task_card_container').append(cardHtml);

   // Bind events on newly added card
   bindChecklistEvents($(`#task_card_container .task-row[data-index="${index}"]`).find('.task-card'));
   const select3 = $('.select3');
   if (select3.length) {
      select3.each(function () {
         const $this = $(this);

         // Wrap only if not already wrapped
         if (!$this.parent().hasClass('position-relative')) {
            $this.wrap('<div class="position-relative"></div>');
         }

         // Call your custom function (ensure it's defined elsewhere)
         select2Focus($this);

         // Initialize Select2 with dropdownParent
         $this.select2({
            dropdownParent: $this.parent()
         });
      });
   }
}

function addProductTask(id, name,task_to) {
   $('#product_task_id').val(id);
   $('#product_task_name').html(name);
   $('#task_to').html(task_to);
   $('#task_to_hidden').val(task_to);
   $('#task_st_btn').html(task_to + ' Task');
   $('#task_card_container').html('');
   taskIndex = 0; // reset index tracker for fresh start

   $.get(`/get_product_tasks/${id}`, function (data) {
      const tasks = data.data || [];

      if (tasks.length > 0) {
         tasks.forEach((task, index) => {
            addTaskCard(task, taskIndex++);
         });
      } else {
         addTaskCard(null, taskIndex++);
      }

      $('#kt_modal_add_task').modal('show');
   });
} 
</script>



    

@endsection