@extends('layouts/layoutMaster')

@section('title', 'Update Product Variant')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<!-- Users List Table -->
<div class="card card-action">
  <div class="card-header border-bottom pb-1">
    <div class="card-action-title">
      <h5 class="card-title mb-1">Update Product Variant</h5>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
          </li>
          <span class="text-dark opacity-75 me-1 ms-1">
            <i class="mdi mdi-arrow-right-thin fs-4"></i>
          </span>
          <li class="breadcrumb-item">
            <a href="javascript:;" class="d-flex align-items-center">Product Management</a>
          </li>
          <span class="text-dark opacity-75 me-1 ms-1">
            <i class="mdi mdi-arrow-right-thin fs-4"></i>
          </span>
          <li class="breadcrumb-item">
            <a href="javascript:;" class="d-flex align-items-center">Manage Products</a>
          </li>
        </ol>
      </nav>
    </div>
    <div class="card-action-element">
      <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
        <div class="badge bg-warning fw-semibold fs-3 text-black fw-bold">Thesis Writing</div>
      </div>
    </div>
  </div>
  <div class="card-body">
    <div class="form-repeater_section">
      <div data-repeater-list="group-a_sec">
        <div data-repeater-item>
          <div class="row mb-4">
            <div class="col-lg-11">
              <div class="row">
                <div class="col-lg-12">
                  <div class="card rounded">
                    <div class="card-action">
                      <div class="card-header section_add bg-gray-200 px-3 py-2 collapsed">
                        <div class="card-action-title">
                          <div class="row w-100">
                            <div class="col-lg-5">
                              <label class="text-black mb-1 fs-6 fw-semibold">Variant Name<span class="text-danger">*</span></label>
                              <input type="text" class="form-control" placeholder="Enter Variant Name" value="Pages" />
                            </div>
                          </div>
                        </div>
                        <div class="card-action-element d-flex align-items-center">
                          <ul class="list-inline mb-0">
                            <li class="list-inline-item">
                              <a href="javascript:;" class="syll_section_add"><i class="mdi mdi-chevron-down fs-3"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="collapse section_add border show">
                      <div class="card-body">
                        <div class="form-repeater_topic">
                          <div data-repeater-list="group-a_topic">
                            <div data-repeater-item>
                              <div class="row mb-2">
                                <div class="col-lg-6">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Variable Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Variable Name" value="100 Pages" />
                                </div>
                                <div class="col-lg-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Amount" value="5,000" />
                                </div>
                                <div class="col-lg-2 text-center mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                                  <div class="d-block ms-n4">
                                    <label class="switch switch-square">
                                      <input type="checkbox" class="switch-input" checked />
                                      <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                      </span>
                                    </label>
                                  </div>
                                </div>
                                <div class="col-lg-1 mb-3">
                                  <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 topic_butt_del" id="topic_butt_del" style="display: block !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                  </a>
                                </div>
                              </div>
                              <div class="row mb-2">
                                <div class="col-lg-6">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Variable Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Variable Name" value="300 Pages" />
                                </div>
                                <div class="col-lg-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Amount" value="10,000" />
                                </div>
                                <div class="col-lg-2 text-center mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                                  <div class="d-block ms-n4">
                                    <label class="switch switch-square">
                                      <input type="checkbox" class="switch-input" checked />
                                      <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                      </span>
                                    </label>
                                  </div>
                                </div>
                                <div class="col-lg-1 mb-3">
                                  <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 topic_butt_del" id="topic_butt_del" style="display: block !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                  </a>
                                </div>
                              </div>
                              <div class="row mb-2">
                                <div class="col-lg-6">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Variable Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Variable Name" value="500 Pages" />
                                </div>
                                <div class="col-lg-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Amount" value="15,000" />
                                </div>
                                <div class="col-lg-2 text-center mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                                  <div class="d-block ms-n4">
                                    <label class="switch switch-square">
                                      <input type="checkbox" class="switch-input" checked />
                                      <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                      </span>
                                    </label>
                                  </div>
                                </div>
                                <div class="col-lg-1 mb-3">
                                  <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 topic_butt_del" id="topic_butt_del" style="display: block !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                  </a>
                                </div>
                              </div>
                              <div class="row mb-2">
                                <div class="col-lg-6">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Variable Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Variable Name" value="600 Pages" />
                                </div>
                                <div class="col-lg-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Amount" value="17,000" />
                                </div>
                                <div class="col-lg-2 text-center mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                                  <div class="d-block ms-n4">
                                    <label class="switch switch-square">
                                      <input type="checkbox" class="switch-input" />
                                      <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                      </span>
                                    </label>
                                  </div>
                                </div>
                                <div class="col-lg-1 mb-3">
                                  <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 topic_butt_del" id="topic_butt_del" style="display: block !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="mb-1 mt-3">
                          <button class="btn btn-sm btn-primary topic_butt_add fs-8 px-2 py-1" data-repeater-create id="topic_butt_add">
                            <i class="mdi mdi-plus me-1"></i>Add More
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-1 mb-3">
              <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 section_butt_del" id="section_butt_del" style="display: block !important;">
                <i class="mdi mdi-delete fs-4"></i>
              </a>
            </div>
          </div>
          <div class="row mb-4">
            <div class="col-lg-11">
              <div class="row">
                <div class="col-lg-12">
                  <div class="card rounded">
                    <div class="card-action">
                      <div class="card-header section_add bg-gray-200 px-3 py-2 collapsed">
                        <div class="card-action-title">
                          <div class="row w-100">
                            <div class="col-lg-5">
                              <label class="text-black mb-1 fs-6 fw-semibold">Variant Name<span class="text-danger">*</span></label>
                              <input type="text" class="form-control" placeholder="Enter Variant Name" value="Days" />
                            </div>
                          </div>
                        </div>
                        <div class="card-action-element d-flex align-items-center">
                          <ul class="list-inline mb-0">
                            <li class="list-inline-item">
                              <a href="javascript:;" class="syll_section_add"><i class="mdi mdi-chevron-down fs-3"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="collapse section_add border show">
                      <div class="card-body">
                        <div class="form-repeater_topic">
                          <div data-repeater-list="group-a_topic">
                            <div data-repeater-item>
                              <div class="row mb-2">
                                <div class="col-lg-6">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Variable Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Variable Name" value="1 Day" />
                                </div>
                                <div class="col-lg-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Amount" value="500" />
                                </div>
                                <div class="col-lg-2 text-center mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                                  <div class="d-block ms-n4">
                                    <label class="switch switch-square">
                                      <input type="checkbox" class="switch-input" checked />
                                      <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                      </span>
                                    </label>
                                  </div>
                                </div>
                                <div class="col-lg-1 mb-3">
                                  <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 topic_butt_del" id="topic_butt_del" style="display: block !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                  </a>
                                </div>
                              </div>
                              <div class="row mb-2">
                                <div class="col-lg-6">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Variable Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Variable Name" value="5 Days" />
                                </div>
                                <div class="col-lg-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Amount" value="2,000" />
                                </div>
                                <div class="col-lg-2 text-center mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                                  <div class="d-block ms-n4">
                                    <label class="switch switch-square">
                                      <input type="checkbox" class="switch-input" checked />
                                      <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                      </span>
                                    </label>
                                  </div>
                                </div>
                                <div class="col-lg-1 mb-3">
                                  <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 topic_butt_del" id="topic_butt_del" style="display: block !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                  </a>
                                </div>
                              </div>
                              <div class="row mb-2">
                                <div class="col-lg-6">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Variable Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Variable Name" value="10 Days" />
                                </div>
                                <div class="col-lg-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Amount" value="3,500" />
                                </div>
                                <div class="col-lg-2 text-center mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                                  <div class="d-block ms-n4">
                                    <label class="switch switch-square">
                                      <input type="checkbox" class="switch-input" checked />
                                      <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                      </span>
                                    </label>
                                  </div>
                                </div>
                                <div class="col-lg-1 mb-3">
                                  <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 topic_butt_del" id="topic_butt_del" style="display: block !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="mb-1 mt-3">
                          <button class="btn btn-sm btn-primary topic_butt_add fs-8 px-2 py-1" data-repeater-create id="topic_butt_add">
                            <i class="mdi mdi-plus me-1"></i>Add More
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-1 mb-3">
              <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 section_butt_del" id="section_butt_del" style="display: block !important;">
                <i class="mdi mdi-delete fs-4"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="mb-1 mt-1">
      <button class="btn btn-sm btn-primary section_butt_add fs-8 px-2 py-1" data-repeater-create id="section_butt_add">
        <i class="mdi mdi-plus me-1"></i>Add More
      </button>
    </div>
    <div class="d-flex justify-content-end align-items-center mt-6">
      <a href="{{url('/manage_product')}}" class="btn btn-secondary me-3">Cancel</a>
      <a href="javascript:;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_update_product_variant">Update Product Variant</a>
    </div>
  </div>
</div>


<!--begin::Modal - Update Product Variant-->
<div class="modal fade" id="kt_modal_update_product_variant" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to Update Product Variant ?
        <div class="d-block text-black fw-semibold fs-5 mt-3 py-2">
          <label>Thesis Writing</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <a href="{{url('/manage_product')}}" class="btn btn-primary me-3">Yes</a>
        <a href="javascript:;" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Product Variant-->




<script>
  $('.section_butt_add').on('click', e => {
    var bt = parseFloat($('.form-repeater_section').length);
    let $clone = $('.form-repeater_section').first().clone().hide();
    $clone.insertBefore('.form-repeater_section:first').slideDown();
    if (bt == 1) {
      $('.section_butt_del').attr('style', 'display: block !important');
    } else {
      $('.section_butt_del').attr('style', 'display: block !important');
    }
  });

  $(document).on('click', '.form-repeater_section .section_butt_del', e => {
    var bt = parseFloat($('.section_butt_del').length);
    // alert(bt);
    $(e.target).closest('.form-repeater_section').slideUp(400, function() {
      $(this).remove()
    });
    if (bt == 2) {
      $('.section_butt_del').attr('style', 'display: none !important');
    } else {}
  });


  $('.topic_butt_add').on('click', e => {
    var bt = parseFloat($('.form-repeater_topic').length);
    let $clone = $('.form-repeater_topic').first().clone().hide();
    $clone.insertBefore('.form-repeater_topic:first').slideDown();
    if (bt == 1) {
      $('.topic_butt_del').attr('style', 'display: block !important');
    } else {
      $('.topic_butt_del').attr('style', 'display: block !important');
    }
  });

  $(document).on('click', '.form-repeater_topic .topic_butt_del', e => {
    var bt = parseFloat($('.topic_butt_del').length);
    // alert(bt);
    $(e.target).closest('.form-repeater_topic').slideUp(400, function() {
      $(this).remove()
    });
    if (bt == 2) {
      $('.topic_butt_del').attr('style', 'display: none !important');
    } else {}
  });
</script>

<!--Create Syllabus Section Accordion Start-->
<script>
  'use strict';

  (function() {
    const syll_section_add = [].slice.call(document.querySelectorAll('.syll_section_add'));

    // Collapsible card
    // --------------------------------------------------------------------
    if (syll_section_add) {
      syll_section_add.map(function(syll_section_add_Element) {
        syll_section_add_Element.addEventListener('click', sect_event => {
          sect_event.preventDefault();
          // Collapse the element
          new bootstrap.Collapse(syll_section_add_Element.closest('.card').querySelector('.collapse.section_add'));
          // Toggle collapsed class in `.card-header` element
          syll_section_add_Element.closest('.card-header').classList.toggle('collapsed');
          // Toggle class mdi-chevron-down & mdi-chevron-up
          Helpers._toggleClass(syll_section_add_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
        });
      });
    }

  })();
</script>
<!--Create Syllabus Section Accordion End-->
@endsection