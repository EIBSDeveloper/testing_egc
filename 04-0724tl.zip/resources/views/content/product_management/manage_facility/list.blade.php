@extends('layouts/layoutMaster')

@section('title', 'Manage Facility')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')

@endsection

@section('content')
<!-- Users List Table -->
<div class="card card-action">
  <div class="card-header border-bottom pb-1">
    <div class="card-action-title">
      <h5 class="card-title mb-1">Manage Facility</h5>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
          </li>
          <span class="text-dark opacity-75 me-1 ms-1">
            <i class="mdi mdi-arrow-right-thin fs-4"></i>
          </span>
          <li class="breadcrumb-item">
            <a href="javascript:;" class="d-flex align-items-center">Product Management</a>
          </li>
        </ol>
      </nav>
    </div>
    <div class="card-action-element">
      <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_add_facility">
          <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Create Facility
        </a>
      </div>
    </div>
  </div>
  <div class="card-body pt-2 pb-2">
    <div class="row">
      <div class="row mb-4">
      @php $perpage_count = $perpage ? $perpage : 10; @endphp
      <div class="col-lg-2">
          <span>Show</span>
          <br>
          <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
              @php
              $options = [10, 25, 100, 500]; // Define available options
              @endphp
              @php foreach ($options as $option): @endphp
              <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                  @php echo $option; @endphp
              </option>
              @php endforeach; @endphp
          </select>
      </div>
      <div class="col-lg-10 d-flex align-items-end justify-content-end">
          <form id="search_form" method="POST" action="/product/facility">
              @csrf
            <div class="d-flex align-items-center gap-2 mt-2">
              <div>
                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                <input type="hidden" name="filter_on" value="1">
                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                <input
                  type="text"
                  class="form-control"
                  id="lead_grp_fill" name="lead_grp_fill" value="{{ $lead_grp_fill ?? "" }}"
                  placeholder="Enter Search"
                />
              </div>
              <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
            </div>
          </form>
      </div>
    </div>
      <div class="col-lg-12">
        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
          <thead>
            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
              <th class="min-w-200px">Facilities</th>
              <th class="min-w-150px">Duration</th>
              <th class="min-w-50px">Status</th>
              <th class="min-w-80px">Actions</th>
            </tr>
          </thead>
          <tbody class="text-black fw-semibold fs-7">
            @if (isset($ListTable))
            @foreach ($ListTable as $i=> $list)
            <tr>
              <td>
                <label class="text-black fw-semibold fs-7">{{ $list->facility_name }}</label>
                <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Free scanning of 50 pages for demonstration."><i class="mdi mdi mdi-help-circle text-dark"></i></a>
              </td>
              <td>
                <label class="text-black fw-semibold fs-7">{{ $list->duration }} @if( $list->duration_in == 2 ) Days @elseif( $list->duration_in == 0 ) Minute @elseif( $list->duration_in == 1 ) Hour @endif</label>
              </td>
              <td>
                <label class="switch switch-square">
                  <input type="checkbox"  class="switch-input" {{ $list->status == 0 ? 'checked' : '' }} onchange="updateDepartmentStatus('{{ $list->sno }}', this.checked)" />
                  <span class="switch-toggle-slider">
                    <span class="switch-on"></span>
                    <span class="switch-off"></span>
                  </span>
                </label>
              </td>
              <td>
                <span class="text-end">
                  <a href="#"
                  onclick="populateUpdateModal('{{ $list->sno }}')" data-bs-toggle="modal" data-bs-target="#kt_modal_update_facility">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                      <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                    </span>
                  </a>
                  <a href="#" onclick="confirmDelete('{{ $list->sno }}','{{ $list->facility_name }}')" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_facility">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                      <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                    </span>
                  </a>
                </span>
              </td>
            </tr>

            @endforeach
            @endif
          </tbody>
        </table>
      </div>
      <div class="mt-4">
        {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
    </div>
    </div>
  </div>
</div>


<!--begin::Modal - Create Facility-->
<div class="modal fade" id="kt_modal_add_facility" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">Create Facility</h3>
        </div>
        <form method="POST" action="{{ route('add_facility') }}" onsubmit="return AddvalidateForm()">
          @csrf
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Facility Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="facility_name" name="facility_name" placeholder="Enter Facility Name" maxlength="100" />
            <div class="text-danger" id="facility_name_err"></div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
            <div class="d-flex align-items-center">
              <input type="text" class="form-control me-2" id="duration" name="duration" placeholder="Enter Value" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
              
              <div class="w-90">
                <select class="select3 form-select" id="duration_in" name="duration_in">
                  <option value="">Select Duration</option>
                  <option value="0">Minutes</option>
                  <option value="1">Hours</option>
                  <option value="2">Days</option>
                </select>
              </div>
            </div>
            <div class="text-danger" id="duration_err"></div>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Create Facility</button>
        </div>
      </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Facility-->

<!--begin::Modal - Update Facility-->
<div class="modal fade" id="kt_modal_update_facility" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">Update Facility</h3>
        </div>
        <form id="validationFormedit" class="needs-validation" method="POST"
        action="{{ route('facility_update') }}" onsubmit="return EditvalidateForm_grade()">
        @csrf
        <div class="row">
          <div class="col-lg-12 mb-3">
            <input type="hidden" id="edit_id" name="edit_id">
            <label class="text-black mb-1 fs-6 fw-semibold">Facility Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="edit_facilityname" name="edit_facilityname" placeholder="Enter Facility Name"  maxlength="100"/>
            <div class="text-danger" id="edit_facility_name_err"></div>
          </div>
          <div class="col-lg-12 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Duration<span class="text-danger">*</span></label>
            <div class="d-flex align-items-center">
              <input type="text" class="form-control me-2" id="edit_duration" name="edit_duration" placeholder="Enter Value" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
              
              <div class="w-90">
                <select class="select3 form-select" id="edit_durationin" name="edit_durationin">
                  <option value="">Select Duration</option>
                  <option value="0">Minutes</option>
                  <option value="1">Hours</option>
                  <option value="2">Days</option>
                </select>
              </div>
              
            </div>
            <div class="text-danger" id="edit_duration_err"></div>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Update Facility</button>
        </div>
      </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Facility-->


<!--begin::Modal - Delete Facility-->
<div class="modal fade" id="kt_modal_delete_facility" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
        <span id="delete_message"></span>
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">

        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal"
        onclick="deleteDepartmentCategory()">Yes, delete!</button>
    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Facility-->


<script>
  $(".list_page").DataTable({
    "ordering": false,
    "paging": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<script>
  function updateDepartmentStatus(UniversityId, isChecked) {
         const status = isChecked ? 0 : 1; // Set status based on checkbox state

         fetch(`/facility_status/${UniversityId}`, {
                 method: 'POST',
                 headers: {
                     'Content-Type': 'application/json',
                     'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                 },
                 body: JSON.stringify({
                     status: status
                 })
             })
             .then(response => response.json())
             .then(data => {
                 if (data.status === 200) {
                     console.log('Facility Status updated successfully:', data.message);
                     toastr.success('Facility Status Updated successfully!');
                 } else {
                     console.error('Error updating Facility Status:', data.message);
                     toastr.error('Error updating Facility Status');
                 }
             })
             .catch(error => {
                 console.error('Error updating Facility status:', error);
             });
     }
</script>
<script>
  function AddvalidateForm() {
      var err = 0;

      // Validate department Name
      var university_name = document.getElementById("facility_name").value.trim();
      if (university_name === "") {
          document.getElementById('facility_name_err').innerHTML = 'Enter Facility Name  is required...!';
          err++;
      } else {
          document.getElementById('facility_name_err').innerHTML = '';
      }
      var duration = document.getElementById("duration").value.trim();
      if (duration === "") {
          $('#duration_err').removeAttr('style');
          document.getElementById('duration_err').innerHTML = 'Enter Duration  is required...!';
          err++;
      } else {
          document.getElementById('duration_err').innerHTML = '';
      }
      var duration_in = document.getElementById("duration_in").value.trim();
      if (duration_in === "") {
          if(err==0){
              document.getElementById('duration_err').innerHTML = 'Select Duration is required...!';
              $('#duration_err').get(0).style.setProperty('margin-left', '17rem', 'important');

              err++;
          }
      } else {
          document.getElementById('duration_err').innerHTML = '';
      }
      
      


      return err === 0; // Returns true if there are no errors
  }
</script>
<script>
  let currentCategoryId;

  function populateUpdateModal(categoryId) {

      currentCategoryId = categoryId;
      fetch(`/facility_edit/${categoryId}`)
          .then(response => response.json())
          .then(data => {
              if (data.status === 200) {
                  const lead_status = data.data;

                  document.getElementById('edit_facilityname').value = lead_status.facility_name;
                  document.getElementById('edit_duration').value = lead_status.duration;
                  $('#edit_durationin').val(lead_status.duration_in).change();
                  document.getElementById('edit_id').value = lead_status.sno;


              } else {
                  console.error('Error fetching category:', data.message);
              }
          })
          .catch(error => {
              console.error('Error fetching category:', error);
          });
  }
</script>
<script>
  function EditvalidateForm_grade() {
      var err = 0;

     // Validate department Name
      var university_name = document.getElementById("edit_facilityname").value.trim();
      if (university_name === "") {
          document.getElementById('edit_facility_name_err').innerHTML = 'Enter Facility Name  is required...!';
          err++;
      } else {
          document.getElementById('edit_facility_name_err').innerHTML = '';
      }
      var duration = document.getElementById("edit_duration").value.trim();
      if (duration === "") {
          
          document.getElementById('edit_duration_err').innerHTML = 'Enter Duration is required...!';
          err++;
          $('#edit_duration_err').removeAttr('style');
      } else {
          document.getElementById('edit_duration_err').innerHTML = '';
      }
      var duration_in = document.getElementById("edit_durationin").value.trim();
      if (duration_in === "") {
          if(err==0){
              document.getElementById('edit_duration_err').innerHTML = 'Select Duration is required...!';
              $('#edit_duration_err').get(0).style.setProperty('margin-left', '17rem', 'important');

              err++;
          }
      } else {
          document.getElementById('edit_duration_err').innerHTML = '';
      }
      

      // Validate BG Color

      return err === 0;
  }
  </script>
  <script>
    function confirmDelete(sno, name) {
       document.querySelector('#kt_modal_delete_facility .btn-danger').setAttribute(
           'data-id', sno);
       $('#delete_message').html('Are you sure you want to delete <br> <b class="text-danger"> ' + name +
           '</b> Facility ?');
   }
  </script>
  <script>

   function deleteDepartmentCategory() {

       var universityId = document.querySelector('#kt_modal_delete_facility .btn-danger').getAttribute('data-id');

       fetch('/facility_delete/' + universityId, {
               method: 'DELETE',
               headers: {
                   'Content-Type': 'application/json',
                   'X-CSRF-TOKEN': '{{ csrf_token() }}'
               }
           })
           .then(response => response.json())
           .then(data => {
               if (data.status === 200) {
                   toastr.success('Facility Deleted successfully!');
                   location.reload();

               } else {

                   console.error(data.error_msg);
               }
           })
           .catch(error => {
               console.error('Error:', error);
           });
   }
   </script>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

   <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
   <style>
       /* Customize Toastr container */
       .toast {
           background-color: #39484f;
       }

       /* Customize Toastr notification */
       .toast-success {
           background-color: green;
       }

       /* Customize Toastr notification */
       .toast-error {
           background-color: red;
       }

       .error_msg {
           border: solid 2px red !important;
           border-color: red !important;
       }
   </style>
   <script>
       // Display Toastr messages
       @if (Session::has('toastr'))
           var type = "{{ Session::get('toastr')['type'] }}";
           var message = "{{ Session::get('toastr')['message'] }}";
           toastr[type](message);
       @endif
   </script>
   <script>
  function sort_filter(val) {
      if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#search_form').submit();
      } else {
      $('.sorting_filter_class').val(10);
      $('#search_form').submit();
      }
  }
  </script>
  <script>
  document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
    el.addEventListener('click', function () {
      // Small delay to allow modal animation to finish
      setTimeout(() => {
        location.reload();
      }, 150);
    });
  });
</script>
<script>
  let debounceTimer;
  
          function debounce(func, delay) {
              return function() {
                  const context = this;
                  const args = arguments;
                  clearTimeout(debounceTimer);
                  debounceTimer = setTimeout(() => func.apply(context, args), delay);
              };
          }
         const token = '{{ csrf_token() }}';
  
          function checkUniqueField(field, value, errorElementId, submitButtonId) {
              if (value === '') {
                  $('#' + errorElementId).text('');
                  return;
              }
  
              let sno = $('#edit_id').val() || null;
  
              $.ajax({
                  url: '/check_duplicate_facility',
                  method: 'POST',
                  data: {
                     _token: '{{ csrf_token() }}',
                      field: field,
                      value: value,
                      sno: sno
                  },
                  success: function(response) {
                      if (response.exists) {
                          $('#' + errorElementId).text(response.message);
                          $('#' + submitButtonId).prop('disabled', true);
                      } else {
                          $('#' + errorElementId).text('');
                          $('#' + submitButtonId).prop('disabled', false);
                      }
                  }
              });
          }
  
          // Bind with debounce
          $('#facility_name').on('input', debounce(function() {
              checkUniqueField('facility_name', $(this).val(), 'facility_name_err', 'create_facility_btn');
          }, 600));
  
          $('#edit_facilityname').on('input', debounce(function() {
              checkUniqueField('facility_name', $(this).val(), 'edit_facility_name_err', 'update_facility_btn');
          }, 600));
  
</script>

@endsection
