@extends('layouts/layoutMaster')

@section('title', 'Manage Add-On')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')

@endsection

@section('content')
@php
$helper = new \App\Helpers\Helpers();
@endphp
<!-- Users List Table -->
<div class="card card-action">
  <div class="card-header border-bottom pb-1">
    <div class="card-action-title">
      <h5 class="card-title mb-1">Manage Add-On</h5>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
          </li>
          <span class="text-dark opacity-75 me-1 ms-1">
            <i class="mdi mdi-arrow-right-thin fs-4"></i>
          </span>
          <li class="breadcrumb-item">
            <a href="javascript:;" class="d-flex align-items-center">Product Management</a>
          </li>
        </ol>
      </nav>
    </div>
    <div class="card-action-element">
      <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_add_addon">
          <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Create Add-on
        </a>
      </div>
    </div>
  </div>
  <div class="card-body pt-2 pb-2">
    <div class="row">
      <div class="row mb-4">
        @php $perpage_count = $perpage ? $perpage : 10; @endphp
        <div class="col-lg-2">
            <span>Show</span>
            <br>
            <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                @php
                $options = [10, 25, 100, 500]; // Define available options
                @endphp
                @php foreach ($options as $option): @endphp
                <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                    @php echo $option; @endphp
                </option>
                @php endforeach; @endphp
            </select>
        </div>
        <div class="col-lg-10 d-flex align-items-end justify-content-end">
            <form id="search_form" method="POST" action="/product/manage_add_on">
                @csrf
              <div class="d-flex align-items-center gap-2 mt-2">
                <div>
                  <input type="hidden" name="page" value="{{ request('page', 1) }}">
                  <input type="hidden" name="filter_on" value="1">
                  <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                  <input
                    type="text"
                    class="form-control"
                    id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                    placeholder="Enter Search"
                  />
                </div>
                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
              </div>
            </form>
        </div>
      </div>
      <div class="col-lg-12">
        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
          <thead>
            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
              <th class="min-w-150px">Add-On</th>
              <th class="min-w-80px">Variant</th>
              <th class="min-w-80px">Free Variant</th>
              <th class="min-w-80px">Paid Variant</th>
              <th class="min-w-50px">Status</th>
              <th class="min-w-80px">Actions</th>
            </tr>
          </thead>
          <tbody class="text-black fw-semibold fs-7">
            @if (isset($addons))
            @foreach ($addons as $i=> $add)
            <tr>
              <td>
                <label class="text-black fw-semibold fs-7">{{ $add->addon_name }}</label>
                <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="-"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
              </td>
              <td>
                <span class="bg-secondary text-white px-3 py-2 rounded">{{ $add->variant_count }}</span>
              </td>
              <td>
                <span class="text-white bg-info px-3 py-2 rounded">{{ $add->freevariant_count }}</span>
              </td>
              <td>
                <span class="text-black fw-bold bg-warning px-3 py-2 rounded">{{ $add->paidvariant_count }}</span>
              </td>
              <td>
                <label class="switch switch-square">
                  <input type="checkbox" class="switch-input" {{ $add->status == 0 ? 'checked' : '' }} onchange="updateDepartmentStatus('{{ $add->sno }}', this.checked)" />
                  <span class="switch-toggle-slider">
                    <span class="switch-on"></span>
                    <span class="switch-off"></span>
                  </span>
                </label>
              </td>
              <td>
                <span class="text-end">
                  <a href="#"
                  onclick="populateUpdateModal('{{ $add->sno }}')" data-bs-toggle="modal" data-bs-target="#kt_modal_update_addon">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                      <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                    </span>
                  </a>
                  <a href="#" onclick="confirmDelete('{{ $add->sno }}','{{ $add->addon_name }}')" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_addon">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                      <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                    </span>
                  </a>
                </span>
              </td>
            </tr>

            @endforeach
            @endif
          </tbody>
        </table>
      </div>
      {{-- <div class="mt-4">
        {{ $addons->appends(request()->except(['page', '_token']))->links() }}
    </div> --}}
    </div>
  </div>
</div>

<!--begin::Modal - Delete Addon-->
<div class="modal fade" id="kt_modal_delete_addon" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;"> <span id="delete_message"></span>
        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">

        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal"
        onclick="deleteDepartmentCategory()">Yes, delete!</button>
       <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Addon-->

<!--begin::Modal - Create Addon-->
<div class="modal fade" id="kt_modal_add_addon" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
  data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)"
                fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">Create Add-on</h3>
        </div>
        <form action="{{route('addon_add')}}" method="POST" id="create_addon_form">
          @csrf
          <div class="row">
            <div class="col-lg-4 mb-3">
              <label class="text-black mb-1 fs-6 fw-semibold">Add On Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" placeholder="Enter Add On Name" name="add_on_name" id="add_add_on_name" />
              <p id="add_on_name_error" class="text-danger mt-2 fs-7 fw-semibold"></p>
            </div>
          </div>
          <div class="form-repeater_addon_vart_create">
            <div data-repeater-list="group-a_addon_vart_create">
              <div data-repeater-item>
                <div class="row my-2 toggles">
                  <div class="col-lg-11">
                    <div class="row">
                      <div class="col-lg-3 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Variant<span class="text-danger">*</span></label>
                        <select class="select3 form-select variant-select-add" name="variant_select_0" id="variant_select_0" onchange="changeMinMax(this.value, 0)">
                        </select>
                        <p id="variant_select_error" class="text-danger mt-2 fs-7"></p>
                      </div>
                      <div class="col-lg-3 mb-3 mt-8">
                        <div class="form-check form-check-inline mb-1 me-5">
                          <input class="form-check-input free-paid-toggle" type="radio" name="free_price_0" value="free" onchange="minMaxToggle(this.value, 0)" checked />
                          <label class="form-check-label text-black mb-1 fs-6 fw-semibold">Free</label>
                        </div>
                        <div class="form-check form-check-inline mb-1">
                          <input class="form-check-input free-paid-toggle" type="radio" name="free_price_0" onchange="minMaxToggle(this.value, 0)" value="paid" />
                          <label class="form-check-label text-black mb-1 fs-6 fw-semibold">Paid</label>
                        </div>
                      </div>
                      <div class="col-lg-2 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Amount" name="amount_0" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                      </div>
                      <div id="min-max-container_0" class="d-none col-lg-4">
                        <div class="row">
                          <div class="col-lg-6 text-center mb-3">
                            <label class="text-black mb-2 fs-6 fw-semibold">Minimum Amount</label>
                            <div class="d-block">
                              <label class="badge bg-success text-black mb-1 fs-6 fw-semibold min-amount" id="variant_min_0">&#8377; 0</label>
                            </div>
                          </div>
                          <div class="col-lg-6 text-center mb-3" id="max_amt_tbox">
                            <label class="text-black mb-2 fs-6 fw-semibold">Maximum Amount</label>
                            <div class="d-block">
                              <label class="badge bg-danger text-white mb-1 fs-6 fw-semibold max-amount" id="variant_max_0">&#8377; 0</label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-1">
                    <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 addon_vart_create_butt_del"
                      id="addon_vart_create_butt_del" style="display: none !important;">
                      <i class="mdi mdi-delete fs-4"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div id="varaintAddContainer"></div>
          <div class="mb-1 mt-1">
            <button type="button" class="btn btn-sm fs-8 px-2 py-1 btn-primary addon_vart_create_butt_add" data-repeater-create id="addon_vart_create_butt_add">
              <i class="mdi mdi-plus me-1"></i>Add More
            </button>
          </div>
          <div class="d-flex justify-content-end align-items-center mt-4">
            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">Create Add-On</button>
          </div>
        </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Addon-->

<!--begin::Modal - Update Addon-->
<div class="modal fade" id="kt_modal_update_addon" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
  data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)"
                fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-6">
          <h3 class="text-center text-black">Update Add-on</h3>
        </div>
        <form action="{{ route('addon_update') }}" method="POST" id="update_addon_form">
          @csrf
          <div class="row">
              <div class="col-lg-4 mb-3">
                <input type="hidden" name="edit_id" id="edit_id">
                <label class="text-black mb-1 fs-6 fw-semibold">Add-on Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Amount" id="edit_addon_name" name="edit_addon_name"/>
                <p id="addonerr" class="text-danger"></p>
              </div>
          </div>
          <div class="form-repeater_addon_vart_edit">
            <div id="variantsContainer"></div>
          </div>
          <div class="mb-1 mt-1">
            <button type="button" class="btn btn-sm fs-8 px-2 py-1 btn-primary addon_vart_edit_butt_add" data-repeater-create
              id="addon_vart_edit_butt_add">
              <i class="mdi mdi-plus me-1"></i>Add More
            </button>
          </div>
          <div class="d-flex justify-content-end align-items-center mt-4">
            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">Update Add-On</button>
          </div>
        </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Addon-->

{{-- ! Datatable Script --}}
<script>
  $(".list_page").DataTable({
    "ordering": false,
    "paging": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<script>
  function updateDepartmentStatus(UniversityId, isChecked) {
         const status = isChecked ? 0 : 1; 

         fetch(`/addon_status/${UniversityId}`, {
                 method: 'POST',
                 headers: {
                     'Content-Type': 'application/json',
                     'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                 },
                 body: JSON.stringify({
                     status: status
                 })
             })
             .then(response => response.json())
             .then(data => {
                 if (data.status === 200) {
                     console.log('Addon Status updated successfully:', data.message);
                     toastr.success('Addon Status Updated successfully!');
                 } else {
                     console.error('Error updating Addon Status:', data.message);
                     toastr.error('Error updating Addon Status');
                 }
             })
             .catch(error => {
                 console.error('Error updating Addon status:', error);
             });
     }
</script>
<script>
  function sort_filter(val) {
      if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#search_form').submit();
      } else {
      $('.sorting_filter_class').val(10);
      $('#search_form').submit();
      }
  }
  </script>
<script>
  let currentCategoryId;
  let pagesOptions = [];
  let personsOptions = [];

 function populateUpdateModal(categoryId) {
  currentCategoryId = categoryId;
  fetch(`/addon_edit/${categoryId}`)
  .then(response => response.json())
  .then(data => {
  if (data.status === 200) {
  pagesOptions = data.options.pages;
  personsOptions = data.options.persons;
  
  variantsContainer.innerHTML = '';
  variantCount = 0;
  
  const lead_status = data.data;
  const variants = data.variants;
  
  $('#edit_id').val(lead_status.sno);
  $('#edit_addon_name').val(lead_status.addon_name);
  
  variants.forEach((variant, index) => {
  addVariant();
  
  const variantBlock = variantsContainer.querySelector(`.variant-block[data-index="${variantCount}"]`);
  const variantIdInput = variantBlock.querySelector(`input[name="variant_id_${variantCount}"]`);
  variantIdInput.value = variant.sno;
  
  const select = variantBlock.querySelector(`select[name="variant_select_${variantCount}"]`);
  const amountInput = variantBlock.querySelector(`input[name="amount_${variantCount}"]`);
  const freeRadio = variantBlock.querySelector(`input[name="free_price_${variantCount}"][value="free"]`);
  const paidRadio = variantBlock.querySelector(`input[name="free_price_${variantCount}"][value="paid"]`);
  
  if (select.querySelector(`option[value="${variant.variable_id}"]`)) {
  select.value = variant.variable_id;
  }
  amountInput.value = variant.amount;
  
  if (variant.free_paid === 0) {
  freeRadio.checked = true;
  } else {
  paidRadio.checked = true;
  }
  
  updateMinMaxAmounts(variantBlock, select.value);
  toggleMinMaxAmount(variantBlock);
  });
  
  updateDeleteButtonVisibility();
  } else {
  console.error('Error fetching category:', data.message);
  }
  })
  .catch(error => {
  console.error('Error fetching category:', error);
  });
  }
</script>
<script>
  function confirmDelete(sno, name) {
     document.querySelector('#kt_modal_delete_addon .btn-danger').setAttribute(
         'data-id', sno);
     $('#delete_message').html('Are you sure you want to delete <br> <b class="text-danger"> ' + name +
         '</b> AddOn ?');
 }
</script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>

<style>
  .text-purple {
    color: #6f42c1; /* Bootstrap’s purple-ish color */
  }
</style>

    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
     <script>
      function get_sub_department(id) {
        $('#variable_max').html(0);
    $('#variable_min').html(0);
    $('#variable_max_hidden').val(0);
    $('#variable_min_hidden').val(0);

          $.ajax({
              url: "{{ route('get_variable') }}",
              type: "GET",
              data: {
                  id: id
              },
              success: function(response) {
                  if (response.status === 200 && response.data) {
                      var selectDropdown = $('select[name="variable_id"]');
                      selectDropdown.empty();
                      selectDropdown.append($('<option value="">Select  Variable</option>'));
                      response.data.forEach(function(sub_dept) {
                          selectDropdown.append($('<option></option>').attr('value', sub_dept
                              .sno).text(sub_dept.service_variablename));
                      });
                  }
              },
              error: function(error) {
                  // console.error('Error fetching course sub categories:', error);
              }
          });

      }
  </script>

  <script>
  function get_maxcost(id) {
    $('#variable_max').html(0);
    $('#variable_min').html(0);
    $('#variable_max_hidden').val(0);
    $('#variable_min_hidden').val(0);
if(id!="")
{
  $.ajax({
              url: "{{ route('get_variable_by_id') }}",
              type: "GET",
              data: {
                  id: id
              },
              success: function(response) {
                  if (response.status === 200 && response.data) {
                    $('#variable_max').html(response.data.max_cost || '0');
                    $('#variable_min').html(response.data.min_cost || '0');
                    $('#variable_max_hidden').val(response.data.max_cost || '0');
                    $('#variable_min_hidden').val(response.data.min_cost || '0');
                  }
              },
              error: function(error) {
                  // console.error('Error fetching course sub categories:', error);
              }
          });

}

    }//get_variable
</script>

<script>
  // Dynamic variant add
  const variantTemplate = (index, variantId = '') => {

    const generateOptions = () => {
      let html = `<option value="">Select Variant</option>`;

      personsOptions.forEach( person => {
        const relatedVarients = pagesOptions.filter(v => v.addon_varientid === person.id);

        if(relatedVarients.length > 0){
          html += `<optgroup label="${person.name}">`;

          relatedVarients.forEach(pages => {
            html += `<option value="${pages.id}" data-min="${pages.min_cost}" data-max="${pages.max_cost}">${pages.name}</option>`;          });

          html += `</optgroup>`;
        }
      });

      return html;
    }
    return`
    <div class="variant-block my-2" data-index="${index}">
      <div class="row align-items-center">
        <div class="col-lg-2 mb-3">
          <input type="hidden" name="variant_id_${index}" value="" />
          <label class="text-black mb-1 fs-6 fw-semibold">Variant<span class="text-danger">*</span></label>
          <select class="select3 form-select variant-select" name="variant_select_${index}">
            ${generateOptions()}
          </select> 
        </div>
        
        <div class="col-lg-2 mb-3 mt-8">
          <div class="form-check form-check-inline mb-1 me-5">
            <input class="form-check-input free-radio" type="radio" name="free_price_${index}" value="free" checked />
            <label class="form-check-label text-black mb-1 fs-6 fw-semibold">Free</label>  
          </div>
          <div class="form-check form-check-inline mb-1">
            <input class="form-check-input paid-radio" type="radio" name="free_price_${index}" value="paid" />
            <label class="form-check-label text-black mb-1 fs-6 fw-semibold">Paid</label>
          </div>
        </div>

        <div class="col-lg-2 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Amount" name="amount_${index}" oninput="this.value = this.value.replace(/[^0-9]/g, '');" />
        </div>

        <div class="col-lg-2 text-center mb-3 min-max-amount" style="visibility: hidden; height: 0; overflow: hidden;">
          <label class="text-black mb-2 fs-6 fw-semibold">Minimum Amount</label>
          <div class="d-block">
            <label class="badge bg-success text-black mb-1 fs-6 fw-semibold min-amount-label">&#8377; 10,000</label>
          </div>
        </div>

        <div class="col-lg-2 text-center mb-3 min-max-amount" style="visibility: hidden; height: 0; overflow: hidden;">
          <label class="text-black mb-2 fs-6 fw-semibold">Maximum Amount</label>
          <div class="d-block">
            <label class="badge bg-danger text-white mb-1 fs-6 fw-semibold max-amount-label">&#8377; 15,000</label>
          </div>
        </div>

        <div class="col-lg-2 mb-3 mt-8">
          <button type="button" class="btn btn-outline-danger btn-delete-variant px-2 py-1" style="display:none;">
            <i class="mdi mdi-delete fs-4"></i>
          </button>
        </div>
      </div>
    </div>`;
    
  }

    let variantCount = 0;

    const variantsContainer = document.getElementById('variantsContainer');
    const addButton = document.getElementById('addon_vart_edit_butt_add');

    function toggleMinMaxAmount(variantBlock){

      const paidRadio = variantBlock.querySelector('.paid-radio');
      const minMaxElements = variantBlock.querySelectorAll('.min-max-amount');

      if(paidRadio.checked) {
        minMaxElements.forEach( el => {
          el.style.visibility = 'visible';
          el.style.height = 'auto';
          el.style.overflow = 'visible';
        });
      } else {
        minMaxElements.forEach(el => {
          el.style.visibility = 'hidden';
          el.style.height = '0';
          el.style.overflow = 'hidden';
        });
      }
    }

    function updateDeleteButtonVisibility() {

      const variantBlocks = variantsContainer.querySelectorAll('.variant-block');
      const deleteButtons = variantsContainer.querySelectorAll('.btn-delete-variant');

      if (variantBlocks.length <= 1) { 
        deleteButtons.forEach(btn=> btn.classList.add('d-none'));
      } else {
        deleteButtons.forEach(btn => btn.classList.remove('d-none'));
      }
    }

    function addVariant() {
      variantCount++;
      console.log('Adding Variant', variantCount);

      variantsContainer.insertAdjacentHTML('beforeend', variantTemplate(variantCount, pagesOptions, personsOptions));
      
      const newVariant = variantsContainer.querySelector(`.variant-block[data-index="${variantCount}"]`);

      // Update min / max amounts if a variant is already selected
      const select = newVariant.querySelector('select');
      updateMinMaxAmounts(newVariant, select.value);

      toggleMinMaxAmount(newVariant);
      updateDeleteButtonVisibility();
    }

    function removeVariant(event){
      if(!event.target.closest('.btn-delete-variant')) return;

      const variantBlock = event.target.closest('.variant-block');
      variantBlock.remove();
      variantCount--;
      updateDeleteButtonVisibility();
    }

    // Add initial variant on page load
    addVariant();

    // Event listeners
    addButton.addEventListener('click', (e) => {
      e.preventDefault();
      addVariant();
    })

    variantsContainer.addEventListener('click', removeVariant);

    variantsContainer.addEventListener('change', (e) => {
      const target = e.target;

      if(target.classList.contains('variant-select')){
        const variantBlock = target.closest('.variant-block');
        updateMinMaxAmounts(variantBlock, target.value);
      }

      if(target.classList.contains('free-radio') || target.classList.contains('paid-radio')){
        const variantBlock = target.closest('.variant-block');
        toggleMinMaxAmount(variantBlock);
      }
    });

    function updateMinMaxAmounts(variantBlock, selectedVariantId){
      
      const minLabel = variantBlock.querySelector('.min-amount-label');
      const maxLabel = variantBlock.querySelector('.max-amount-label');

      const pageVariant = pagesOptions.find(p => p.id == selectedVariantId);

      if(pageVariant){
        minLabel.textContent = `₹ ${pageVariant.min_cost.toLocaleString()}`;
        maxLabel.textContent = `₹ ${pageVariant.max_cost.toLocaleString()}`;
      } else {
        minLabel.textContent = `₹ 0`;
        maxLabel.textContent = `₹ 0`;
      }
    }
</script>

<script>
  // Edit Validation
 document.getElementById('update_addon_form').addEventListener('submit', (e) => {
    let isValid = true;
    const variantBlocks = document.querySelectorAll('.variant-block');

    variantBlocks.forEach(block => {
        const select = block.querySelector('select');
        const amountInput = block.querySelector('input[name^="amount_"]');

        // Remove existing errors if any
        const existingVariantError = block.querySelector('.variant-error');
        if (existingVariantError) existingVariantError.remove();

        const existingAmountError = block.querySelector('.amount-error');
        if (existingAmountError) existingAmountError.remove();

        // Validate select
        if (!select.value) {
            isValid = false;
            const error = document.createElement('div');
            error.classList.add('text-danger', 'variant-error', 'mt-1', 'fs-7');
            error.textContent = 'Select a Variant';
            select.parentElement.appendChild(error);
        }

        // Validate amount
        if (!amountInput.value) {
            isValid = false;
            const amountErr = document.createElement('div');
            amountErr.classList.add('text-danger', 'amount-error', 'mt-1', 'fs-7');
            amountErr.textContent = 'Enter an Amount';
            amountInput.parentElement.appendChild(amountErr);
        }
    });

    // Validate Add-On Name
    const addon = document.getElementById('edit_addon_name').value.trim();
    const addonerr = document.getElementById('addonerr');
    addonerr.textContent = '';

    if (addon === '') {
        addonerr.textContent = 'Enter Add-On Name.';
        isValid = false;
    }

    if (!isValid) {
        e.preventDefault();
    }
});
</script>

<script>
  function openEdit(sno, name){
    document.getElementById('edit_id').value = sno;
    document.getElementById('edit_addon_name').value = name;
  }
</script>

<script>
  // Add Variant Container
  let index = 1;
  document.getElementById('addon_vart_create_butt_add').addEventListener('click', () => {
    fetchAddOnVariant(index);
    var newAddVariant = `
      <div class="row my-2 toggles">
        <div class="col-lg-11">
          <div class="row">
            <div class="col-lg-3 mb-3">
              <label class="text-black mb-1 fs-6 fw-semibold">Variant<span class="text-danger">*</span></label>
              <select class="select3 form-select variant-select-add" id="variant_select_${index}" name="variant_select_${index}" onchange="changeMinMax(this.value, ${index})">
              </select>
            </div>
      
            <div class="col-lg-3 mb-3 mt-8">
              <div class="form-check form-check-inline mb-1 me-5">
                <input class="form-check-input free-paid-toggle" type="radio" name="free_price_${index}" value="free" onchange="minMaxToggle(this.value, ${index})"
                  checked />
                <label class="form-check-label text-black mb-1 fs-6 fw-semibold">Free</label>
              </div>
              <div class="form-check form-check-inline mb-1">
                <input class="form-check-input free-paid-toggle" type="radio" name="free_price_${index}" value="paid" onchange="minMaxToggle(this.value, ${index})" />
                <label class="form-check-label text-black mb-1 fs-6 fw-semibold">Paid</label>
              </div>
            </div>
      
            <div class="col-lg-2 mb-3">
              <label class="text-black mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="amount_${index}" placeholder="Enter Amount"
                oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
            </div>
            <div id="min-max-container_${index}" class="col-lg-4 d-none">
              <div class="row">
                <div class="col-lg-6 text-center mb-3">
                  <label class="text-black mb-2 fs-6 fw-semibold">Minimum Amount</label>
                  <div class="d-block">
                    <label class="badge bg-success text-black mb-1 fs-6 fw-semibold" id="variant_min_${index}">&#8377; 0</label>
                  </div>
                </div>
          
                <div class="col-lg-6 text-center mb-3">
                  <label class="text-black mb-2 fs-6 fw-semibold">Maximum Amount</label>
                  <div class="d-block">
                    <label class="badge bg-danger text-white mb-1 fs-6 fw-semibold" id="variant_max_${index}">&#8377; 0</label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-1">
          <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 addon_vart_create_butt_del"
            style="display: block !important;">
            <i class="mdi mdi-delete fs-4"></i>
          </a>
        </div>
      </div>`;
    document.getElementById('varaintAddContainer').insertAdjacentHTML('beforeend', newAddVariant);
    $('.select3').each(function() {
      $(this).wrap('<div class="position-relative"></div>').select2({
        dropdownParent: $(this).parent()
      });
    });
    index++;
  });
  
  // Handle variant block deletion
  $(document).on('click', '.addon_vart_create_butt_del', function () {
    $(this).closest('.row').remove();
  });
</script>



<script>
  $(document).ready(function() {
    $('#min-max-cost').select2();

    $('#min-max-cost').on('change', function() {
      const selectedOption = $(this).find('option:selected');
      const dataMinValue = selectedOption.data('min');
      const dataMaxValue = selectedOption.data('max');

      // Format the number with commas
      const formattedValue1 = dataMinValue ? Number(dataMinValue).toLocaleString('en-IN') : '';
      const formattedValue2 = dataMaxValue ? Number(dataMaxValue).toLocaleString('en-IN') : '';

      $('.min-amount').text(formattedValue1 ? `₹ ${formattedValue1}` : '');
      $('max-amount').text(formattedValue2 ? `₹ ${formattedValue2}` : '');
    });
  });
</script>

{{-- ! Add On Variant Variable Data Fetch --}}
<script>
  $(document).ready(function () {
    fetchAddOnVariant(0);
  });

  function fetchAddOnVariant(index) {
    $.ajax({
      url: "/addon_variant_variables",
      type: "GET",
      success: function(response) {
        if (response.status === 200 && response.data) {
          var variantDropdown = $(`#variant_select_${index}`);
          variantDropdown.empty();

          variantDropdown.append(`<option value="">Select Add On Variant</option>`)
          var groups = {};

          response.data.forEach(function(variable) {
            var groupName = variable.addon_varientname;

            if(!groups[groupName]) {
              groups[groupName] = $('<optgroup>', {label: groupName});
            }

            var option = $('<option>', {
              value: variable.sno,
              text: variable.addon_variablename
            });

            groups[groupName].append(option);
          });

          for(var group in groups) {
            variantDropdown.append(groups[group]);
          }
        }
      },
      error: function(error) {
        console.error('Error fetching branches:', error);
      }
    });
  }
</script>

{{-- ! Min & Max Amount Toggle --}}
<script>
  $(document).ready(function() {
    var checkedValue = $('input[name="free_price_0"]:checked').val();
    minMaxToggle(checkedValue);
  });

  function minMaxToggle(selectedValue, index) {
    var toggleContainer = $(`#min-max-container_${index}`);

    if(selectedValue === 'paid') {
      toggleContainer.removeClass('d-none').addClass('d-block');
    } else {
      toggleContainer.removeClass('d-block').addClass('d-none');
    }
  }
</script>

{{-- ! Update Min & Max Amount --}}
<script>
  function changeMinMax(id, index) {
    $.ajax({
      url: `/update_min_max/${id}`,
      method: 'GET',
      success: function (res) {
        if(res.status === 200) {
          $(`#variant_min_${index}`).html(res.data.min_cost);
          $(`#variant_max_${index}`).html(res.data.max_cost);
        }
      },
      error: function (err) {
        console.error('Error Fetching Data');
      }
    });
  }
</script>

{{-- ! Delete Add On --}}
<script>
  function deleteDepartmentCategory() {
    var universityId = document.querySelector('#kt_modal_delete_addon .btn-danger').getAttribute('data-id');
    fetch('/addon_delete/' + universityId, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': '{{ csrf_token() }}'
      }
    })
    .then(response => response.json())
    .then(data => {
      if (data.status === 200) {
        toastr.success('Addon Deleted successfully!');
        location.reload();

      } else {-
        console.error(data.error_msg);
      }
    })
    .catch(error => {
      console.error('Error:', error);
    });
  }
</script>

{{-- ! Add Validation --}}
<script>
  document.getElementById('create_addon_form').addEventListener('submit', (e) => {
    let isValid = true;
  
    // Clear Add-On name error first
    const addonNameError = document.getElementById('add_on_name_error');
    addonNameError.textContent = '';
  
    // Validate Add-On Name
    const addonNameInput = document.getElementById('add_add_on_name');
    if (addonNameInput.value.trim() === '') {
      addonNameError.textContent = 'Enter Add-On Name.';
      isValid = false;
    }
  
    // Validate each variant block
    const variantBlocks = document.querySelectorAll('.toggles');
  
    variantBlocks.forEach(block => {
      // Remove any existing errors inside this block
      const oldVariantError = block.querySelector('.variant-error');
      if (oldVariantError) oldVariantError.remove();
  
      const oldAmountError = block.querySelector('.amount-error');
      if (oldAmountError) oldAmountError.remove();
  
      const select = block.querySelector('select.variant-select-add');
      const amountInput = block.querySelector('input[name^="amount_"]');
  
      // Validate select
      if (!select.value) {
      isValid = false;
      const error = document.createElement('p');
      error.classList.add('text-danger', 'variant-error', 'mt-1', 'fs-7', 'fw-semibold');
      error.textContent = 'Select a Variant';
      
      select.parentElement.appendChild(error);
      }
  
      // Validate amount
      if (!amountInput.value.trim()) {
        isValid = false;
        const error = document.createElement('div');
        error.classList.add('text-danger', 'amount-error', 'mt-1', 'fs-7', 'fw-semibold');
        error.textContent = 'Enter an Amount';
        amountInput.parentElement.appendChild(error);
      }
    });
  
    if (!isValid) {
      e.preventDefault();
    }
  });
</script>
@endsection
