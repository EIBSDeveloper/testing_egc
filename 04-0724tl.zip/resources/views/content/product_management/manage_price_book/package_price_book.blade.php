@extends('layouts/layoutMaster')

@section('title', 'Manage Price Book')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
@php
$helper = new \App\Helpers\Helpers();
@endphp
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
</head>
<!-- Users List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Price Book</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Product Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Package Price Book</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal"
                    onclick="accordionDataFetch()" data-bs-target="#kt_modal_add_price_book">
                    <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Package Price Book
                </a>
            </div>
        </div>
    </div>
    <div class="nav-align-top mb-2">
        <ul class="nav nav-pills flex-nowrap" role="tablist">
            <div class="scroll-container-wrapper">
                <button class="scroll-btn left" id="scrollLeftBtn"><i
                        class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                <div class="scroll-container" id="scrollContainer">
                    <div class="item">
                        <li class="nav-item rounded" style="border: 1px solid #099dda;">
                            <a class="nav-link text-capitalize" href="{{ url('/manage_price_book') }}">
                                Product Price Book
                            </a>
                        </li>
                    </div>
                    <div class="item">
                        <li class="nav-item rounded" style="border: 1px solid #099dda;">
                            <a class="nav-link text-capitalize active" href="{{ url('/manage_price_book/package') }}">
                                Package Price Book
                            </a>
                        </li>
                    </div>
                    <div class="item">
                        <li class="nav-item rounded" style="border: 1px solid #099dda;">
                            <a class="nav-link text-capitalize" href="{{ url('/manage_price_book/add_on') }}">
                                Add On Price Book
                            </a>
                        </li>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn"><i
                            class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </div>
        </ul>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                        onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form id="search_form" method="POST" action="/manage_price_book/package">
                        @csrf
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <div>
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="0">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                    id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <input type="text" class="form-control" id="search_fill" name="search_fill"
                                    value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Packages</th>
                            <th class="min-w-100px">INR ( &#8377; )</th>
                            @foreach ($data as $d)
                                <th class="min-w-100px">{{ $d->currency_name }} ( {{ $d->currency_symbol }} )</th>
                            @endforeach
                            <th class="min-w-100px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        @foreach($ListTable as $list)
                        <tr>
                            <td>
                                <div class="text-truncate max-w-200px" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="{{ $list->package_name }}">{{ $list->package_name
                                    }}</div>
                            </td>
                            <td align="right">
                                <div class="fw-semibold">
                                    &#8377; {{ number_format($list->package_max) }}
                                    <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                        <i class="ms-1 mdi mdi-information fs-9"></i>
                                    </a>
                                    <div class="dropdown-menu py-2 px-4 text-black w-300px">
                                        <div class="row mt-4 mb-2">
                                            <label class="col-5 text-black fs-7 fw-semibold">Base Price</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-5 text-success fw-bold fs-7">&#8377; {{ number_format($list->package_base) }}</label>
                                        </div>
                                        <hr class="mb-0 mt-0">
                                        <div class="row mt-4 mb-2">
                                            <label class="col-5 text-black fs-7 fw-semibold">Min Amount</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-5 text-danger fw-bold fs-7">&#8377; {{ number_format($list->package_min) }}</label>
                                        </div>
                                        <hr class="mb-0 mt-0">
                                        <div class="row mt-4 mb-2">
                                            <label class="col-5 text-black fs-7 fw-semibold">Max Amount</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-5 text-danger fw-bold fs-7">&#8377; {{ number_format($list->package_max) }}</label>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            @foreach ($data as $d)
                                <td align="right">
                                    @php
                                        $currencyData = $helper->get_currency_package_price_book($list->package_id, $d->sno);
                                    @endphp
                                    <div class="fw-semibold">
                                        {{ $d->currency_symbol }} {{ number_format($currencyData->max_amount) }}
                                        <a href="#" class="dropdown-toggle hide-arrow " data-bs-toggle="dropdown" data-trigger="hover">
                                            <i class="ms-1 mdi mdi-information fs-9"></i>
                                        </a>
                                        <div class="dropdown-menu py-2 px-4 text-black w-300px">
                                            <div class="row mt-4 mb-2">
                                                <label class="col-5 text-black fs-7 fw-semibold">Base Price</label>
                                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                                <label class="col-5 text-success fw-bold fs-7">{{ $d->currency_symbol }} {{ number_format($currencyData->base_price) }}</label>
                                            </div>
                                            <hr class="mb-0 mt-0">
                                            <div class="row mt-4 mb-2">
                                                <label class="col-5 text-black fs-7 fw-semibold">Min Price</label>
                                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                                <label class="col-5 text-danger fw-bold fs-7">{{ $d->currency_symbol }} {{ number_format($currencyData->min_amount) }}</label>
                                            </div>
                                            <hr class="mb-0 mt-0">
                                            <div class="row mt-4 mb-2">
                                                <label class="col-5 text-black fs-7 fw-semibold">Max Price</label>
                                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                                <label class="col-5 text-danger fw-bold fs-7">{{ $d->currency_symbol }} {{ number_format($currencyData->max_amount) }}</label>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            @endforeach
                            <td>
                                <span class="text-end">
                                    <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_view_price_book"
                                        onclick="priceBookView('{{ $list->package_id }}')">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="View Package Price Book">
                                            <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i> <i class=""></i>
                                        </span>
                                    </a>
                                    <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_edit_price_book"
                                        onclick="fetchEditData('{{ $list->package_id }}')">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Edit Package Price Book">
                                            <i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>
                                        </span>
                                    </a>

                                </span>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Create Price Book-->
<div class="modal fade" id="kt_modal_add_price_book" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">Create Price Book Package</h3>
                </div>
                <form id="price_book_form" action="{{ route('add_package_price_book') }}" method="POST">
                    @csrf
                    <div class="row mb-3">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Package <span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="package_id" name="package_id"
                                onchange="packageVariantDataFetch(this.value)">
                                <!-- AJAX Will Populate Here -->
                            </select>
                            <div class="error_msg text-danger mt-1 fw-semibold fs-7" id="product_id_err"></div>
                        </div>
                    </div>

                    <div class="card rounded mb-3 border" id="inr-add-block" style="display: none;">
                        <div class="card-header bg-light border-bottom shadow-sm py-3">
                            <span class="fs-5 fw-semibold text-black text-capitalize me-2">
                                INR
                            </span>
                            <span class="text-primary fw-bold">
                                ( ₹ )
                            </span>
                                India
                        </div>
                        <div class="card-body py-1">
                            <div class="row mt-2">
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Base Price</label>
                                    <div class="text-danger fs-5 d-block fw-semibold " id="product-base-price">-</div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="product-min-amount">-</div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Maximum Amount</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="product-max-amount">-</div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Actual Price</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="product-actual-amount">-</div>
                                </div>
                                <div id="variants-container-inr" class="row"></div>
                            </div>
                        </div>
                    </div>

                    <div class="scroll-y max-h-1000px" id="whole-container" style="display: none;">
                        <div class="accordion" id="accordionExample">
                            <div id="accordion-container"></div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="create_price_book" style="display: none !important;"
                            onclick="addValidation()">Create Package Price Book</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Price Book-->

<!--begin::Modal - Edit Price Book-->
<div class="modal fade" id="kt_modal_edit_price_book" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">Update <span class="text-info fw-semibold"
                            id="edit-package-name">-</span></h3>
                </div>

                <form action="{{ route('package_update') }}" method="POST" id="edit_price_form">
                    @csrf
                    <!-- INR Card -->
                    <div class="card rounded mb-3">
                        <div class="card-header py-0 bg-light rounded">
                            <div class="py-3 ">
                                <span class="badge fs-4  py-1 text-black">INR ( <span class="text-primary">₹</span>
                                    )</span> India
                            </div>
                        </div>
                        <div class="card-body py-1">
                            <div class="row mt-2">
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Base Price</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="edit-inr-base">₹</div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="edit-inr-min">₹</div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Maximum Amount</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="edit-inr-max">₹</div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Actual Price</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="edit-actual-inr">₹</div>
                                </div>
                                <div id="edit-varient-inr" class="row"></div>
                            </div>
                        </div>
                    </div>
                    <div class="scroll-y max-h-1000px">

                        <!-- Accordion -->
                        <div class="accordion" id="editAccordionExample">
                            <div id="edit-accordion-container"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="editValidation()">Update&nbsp;<span
                                id="update-btn">-</span></button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Price Book-->

<!--begin::Modal - View Price Book-->
<div class="modal fade" id="kt_modal_view_price_book" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">View <span class="text-info fw-semibold"
                            id="view-package-name">-</span></h3>
                </div>

                <div class="card rounded mb-3">
                    <div class="card-header py-0 bg-light text-success rounded">
                        <div class="py-3 ">
                            <div class="fw-semibold text-black fs-4">INR ( <span class="text-primary">₹</span> ) India</div>
                        </div>
                    </div>
                    <!-- INR Container -->
                    <div class="card-body py-1">
                        <div class="row mt-2">
                            <div class="col-md-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Base Price</label>
                                <div class="text-danger fw-semibold d-block fs-5" id="view-inr-base">-</div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount</label>
                                <div class="text-danger fw-semibold d-block fs-5" id="view-inr-min">-</div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Maximum Amount</label>
                                <div class="text-danger fw-semibold d-block fs-5" id="view-inr-max">-</div>
                            </div>
                            <div id="view-varient-inr" class="row"></div>
                        </div>
                    </div>
                </div>
                <!-- Accordion -->
                <div class="scroll-y max-h-1000px">
                    <div class="accordion" id="viewAccordionExample">
                        <div id="view-accordion-container"></div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Price Book-->

<!-- Toastr Starts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .err_msg {
            /* background-color: red; */
            border-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
<!-- Toastr Ends -->

<!-- Sort Filter -->
<script>
    function sort_filter(val) {
        if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
        } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
        }
    }
</script>

<!-- Data Table -->
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<!-- Accordion Fetch -->
<script>
    function accordionDataFetch () {
        $.ajax({
            url: '/currency_accordion',
            method: 'GET',
            dataType: 'json',
            success: function (response) {
                if(response.status === 200) {
                    var data = response.data;
                    const accordionContainer = $('#accordion-container');
                    accordionContainer.html('');

                    if(data && data.length > 0) {
                        data.forEach((currency, index) => {
                            const headingId = `heading${index}`;
                            const collapseId = `collapse${index}`;

                            const accordionItem = `
                                <div class="accordion-item active">
                                    <h2 class="accordion-header" id="${headingId}">
                                        <button type="button" class="accordion-button collapsed bg-light border-0 shadow-sm fs-5 fw-semibold text-black"
                                            data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="false" aria-controls="${collapseId}">
                                            <span class="me-2 text-capitalize">
                                                ${currency.currency_name}
                                            </span>
                                            <span class="text-primary fw-bold">
                                                ( ${currency.currency_symbol} )
                                            </span>
                                            <span class="ms-2 text-capitalize">
                                                ${currency.country_name}
                                            </span>
                                        </button>
                                    </h2>
                                    <div id="${collapseId}" class="accordion-collapse collapse" aria-labelledby="${headingId}"
                                        data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <div class="card-body py-1">
                                                <div class="row">
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">
                                                            Base Price<span class="text-danger">*</span>
                                                        </label>
                                                        <input type="text" class="form-control validation_input" name="base_price[]" placeholder="Enter Base Price" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                        <div class="validation_err text-danger mt-1 fw-semibold fs-7"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">
                                                            Minimum Amount<span class="text-danger">*</span>
                                                        </label>
                                                        <input type="text" class="form-control validation_input" name="min_amount[]" placeholder="Enter Minimum Amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                        <div class="validation_err text-danger mt-1 fw-semibold fs-7"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">
                                                            Maximum Amount<span class="text-danger">*</span>
                                                        </label>
                                                        <input type="text" class="form-control validation_input" name="max_amount[]" placeholder="Enter Maximum Amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                        <div class="validation_err text-danger mt-1 fw-semibold fs-7"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">
                                                            Actual Amount<span class="text-danger">*</span>
                                                        </label>
                                                        <input type="text" class="form-control validation_input" name="actual_amount[]" placeholder="Enter Actual Amount"
                                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                        <div class="validation_err text-danger mt-1 fw-semibold fs-7"></div>
                                                    </div>
                                                    <input type="hidden" value="${currency.sno}" class="currency_id" name="currency_id[]" />                                                
                                                    <div class="row variants-container"></div>                      
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>`;
                            accordionContainer.append(accordionItem);
                        });
                    } else {
                        accordionContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                    }
                }
            },
            error: function (error) {
                console.log(`Error Fetching Data : ${error}`);
            }
        });
    }
</script>

<!-- Product Data Fetch -->
<script>
    $(document).ready(function () {
        $.ajax({
            url: '/package_data_fetch',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {
                    var products = response.data;
                    const productDropDown = $('#package_id');
                    productDropDown.empty();
                    productDropDown.append(
                        $('<option></option>').val('').text('Select Package')
                    );

                    products.forEach(p => {
                        productDropDown.append(
                            $('<option></option>').val(p.sno).text(p.package_name)
                        );
                    });
                } else {
                    console.log(`Data Cleared.`);
                }
            },
            error: function(error) {
                console.error(`Error Fetching Data: ${error}`);
            }
        });
    });
</script>

<!-- Product Variant Data Fetch -->
<script>
    function packageVariantDataFetch(id) {
        $.ajax({
            url: `/package_product_data_fetch/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {
                    const variants = response.data;
                    const isAccordion = $('.accordion-item');

                    if(isAccordion && isAccordion.length > 0) {
                        isAccordion.each(function () {
                            const $accordionItem = $(this);
                            const currencyId = $accordionItem.find('.currency_id').val();
                            const variantsContainer = $accordionItem.find('.variants-container');

                            variantsContainer.html('');

                            if (variants && variants.length > 0) {
                                variants.forEach(product => {
                                    var index = 0;
                                    product.variants.forEach((variant) => {
                                        const variantElement = `
                                            <label
                                                class="d-flex align-items-center justify-content-between text-white my-3 px-3 py-2 fs-5 fw-semibold bg-info rounded package-product-name">
                                                <span>${product.product_name} ( ${variant.variant_name} )</span>
                                                <span class="badge bg-warning text-black ms-3 fw-semibold" id="total-label_${currencyId}_${variant.variant_id}">0</span>
                                            </label>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                    data-bs-placement="right" title="Base Price">Base Price<span class="text-danger">*</span></label>
                                                <input type="text" class="form-control validation_input base-price" data-index="${index}" placeholder="Enter Base Price" name="product_base_price[${currencyId}][]" id="base_price_${currencyId}_${variant.variant_id}" onkeyup="changePrices(${currencyId}, ${variant.variant_id})"
                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                <div class="validation_err text-danger mt-1 fw-semibold fs-7"></div>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                    data-bs-placement="right" title="${variant.variable_name}">
                                                    ${variant.variable_name}<span class="text-danger">*</span>
                                                </label>
                                                <input type="hidden" name="package_id" value="${product.package_id}" />
                                                <input type="hidden" name="product_id[${currencyId}][]" value="${product.product_id}" />
                                                <input type="hidden" name="variant_id[${currencyId}][]" value="${variant.variant_id}" />
                                                <input type="hidden" name="variable_id[${currencyId}][]" value="${variant.variable_id}" />
                                                <input type="text" class="form-control validation_input amount" data-index="${index}" placeholder="Enter Amount" name="amount[${currencyId}][]" id="variant_amount_${currencyId}_${variant.variant_id}" onkeyup="changePrices(${currencyId}, ${variant.variant_id})"
                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                <div class="validation_err text-danger mt-1 fw-semibold fs-7"></div>
                                            </div>`;
                                        variantsContainer.append(variantElement);
                                        index ++;
                                    });
                                });
                            } else {
                                variantsContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                            }
                        });
                    } else {
                        variantsContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No Currency Found.</label>');
                    }

                    // INR Update
                    const variantsContainerINR = $('#variants-container-inr');
                    variantsContainerINR.html('');

                    if(variants && variants.length > 0) {
                        variants.forEach(product => {
                            product.variants.forEach(variantINR => {
                                const variantElementINR = `
                                <label
                                    class="d-flex align-items-center justify-content-between text-white my-3 px-3 py-2 fs-5 fw-semibold bg-info rounded package-product-name">
                                    <span>${product.product_name} ( ${variantINR.variant_name} )</span>
                                    <span class="badge bg-warning text-black ms-3 fw-semibold"
                                    >₹${parseFloat(product.product_base_price) + parseFloat(variantINR.amount)}</span>
                                </label>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                            data-bs-placement="right" title="Base Price">Base Price</label>
                                        <div class="text-danger fs-5 d-block fw-semibold">₹${Number(product.product_base_price).toLocaleString('en-IN')}
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                            data-bs-placement="right" title="${variantINR.variable_name}">${variantINR.variable_name}</label>
                                        <div class="text-danger fs-5 d-block fw-semibold">₹${Number(variantINR.amount).toLocaleString('en-IN')}
                                        </div>
                                    </div>`;
                                variantsContainerINR.append(variantElementINR);
                            });                     
                        });
                    } else {
                        variantsContainerINR.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                    }

                    if (Array.isArray(variants) && variants[0] && typeof variants[0].base_price !== 'undefined') {
                        $('#product-base-price').html(`₹${Number(variants[0].base_price).toLocaleString('en-IN')}`);
                        $('#product-min-amount').html(`₹${Number(variants[0].min_amount || 0).toLocaleString('en-IN')}`);
                        $('#product-max-amount').html(`₹${Number(variants[0].max_amount || 0).toLocaleString('en-IN')}`);
                        $('#product-actual-amount').html(`₹${Number(variants[0].actual_amount || 0).toLocaleString('en-IN')}`);
                    } else {
                        $('#product-base-price').html('₹0');
                        $('#product-min-amount').html('₹0');
                        $('#product-max-amount').html('₹0');
                        $('#product-actual-amount').html('₹0');
                    }                    
                }

                $('#whole-container').show();
                $('#inr-add-block').show();
                $('#create_price_book').show();
            },
            error: function(error) {
                console.log(`Error Fetching Data : ${error}`);
            }
        });
    }

    function changePrices(id, variant_id) {
        var base = parseFloat($('#base_price_' + id + '_' + variant_id).val()) || 0;
        var variant = parseFloat($('#variant_amount_' + id + '_' + variant_id).val()) || 0;
        var total = base + variant;
        $('#total-label_' + id + '_' + variant_id).html(total);
    }

</script>

<!-- Validation and Hide and Show Accordion -->
    <style>
        .input-error {
            border-color: #dc3545 !important;
            /* Bootstrap's danger color */
        }
    </style>

    <script>
        function addValidation() {
                let isValid = true;
                
                $('.validation_err').text('');
                $('.validation_input').removeClass('input-error');
                
                $('.accordion-button')
                    .removeClass('bg-danger bg-opacity-10 text-danger')
                    .addClass('bg-light')
                    .css('border-left', '');

                $('.validation_input').each(function() {
                    const $input = $(this);
                    const value = $input.val().trim();
                    const $errorElement = $input.closest('.mb-3').find('.validation_err');
                    
                    if(!value) {
                        isValid = false;
                        $input.addClass('input-error');
                        $errorElement.text('This field is required.');
                        
                        $input.closest('.accordion-item')
                            .find('.accordion-button')
                            .removeClass('bg-light')
                            .addClass('bg-danger bg-opacity-10 text-danger')
                            .css('border-left', '3px solid #dc3545');
                    }
                });

                // 3. FINAL CHECKS
                if(isValid) {
                    // Form is valid - ensure all styling is reset
                    $('.accordion-button')
                        .removeClass('bg-danger bg-opacity-10 text-danger')
                        .addClass('bg-light')
                        .css('border-left', '');
                    $('#price_book_form').submit();
                } else {
                    $('#whole-container').show();
                    $('#inr-add-block').show();
                }
                
                return false;
            }
    </script>
<!-- Validation Ends -->

<!-- Edit Accordion -->
<script>
    function editAccordionDataFetch () {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: '/currency_accordion',
                method: 'GET',
                dataType: 'json',
                success: function (response) {
                    if(response.status === 200) {
                        var data = response.data;
                        const editAccordionContainer = $('#edit-accordion-container');
                        editAccordionContainer.html('');

                        if(data && data.length > 0) {
                            data.forEach((currency, index) => {
                                const headingId = `heading${index}`;
                                const collapseId = `collapse${index}`;

                                const editAccordionItem = `
                                    <div class="accordion-item active edit-accordion">
                                        <h2 class="accordion-header" id="${headingId}">
                                            <button type="button" class="accordion-button collapsed bg-light border-0 shadow-sm fs-5 fw-semibold text-black"
                                                data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="false" aria-controls="${collapseId}">
                                                <span class="me-2 text-capitalize">
                                                    ${currency.currency_name}
                                                </span>
                                                <span class="text-primary fw-bold">
                                                    ( ${currency.currency_symbol} )
                                                </span>
                                                <span class="ms-2 text-capitalize">
                                                    ${currency.country_name}
                                                </span>
                                            </button>
                                        </h2>
                                        <div id="${collapseId}" class="accordion-collapse collapse" aria-labelledby="${headingId}"
                                            data-bs-parent="#editAccordionExample">
                                            <div class="accordion-body">
                                                <div class="card-body py-1">
                                                    <div class="row">
                                                        <input type="hidden" name="edit_id[]" />
                                                        <div class="col-lg-4 mb-3">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">
                                                                Base Price<span class="text-danger">*</span>
                                                            </label>
                                                            <input type="text" class="form-control validation_input_edit" name="edit_base_price[]" placeholder="Enter Base Price" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                            <div class="validation_err_edit text-danger mt-1 fw-semibold fs-7"></div>
                                                        </div>
                                                        <div class="col-lg-4 mb-3">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">
                                                                Minimum Amount<span class="text-danger">*</span>
                                                            </label>
                                                            <input type="text" class="form-control validation_input_edit" name="edit_min_amount[]" placeholder="Enter Minimum Amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                            <div class="validation_err_edit text-danger mt-1 fw-semibold fs-7"></div>
                                                        </div>
                                                        <div class="col-lg-4 mb-3">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">
                                                                Maximum Amount<span class="text-danger">*</span>
                                                            </label>
                                                            <input type="text" class="form-control validation_input_edit" name="edit_max_amount[]" placeholder="Enter Maximum Amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                            <div class="validation_err_edit text-danger mt-1 fw-semibold fs-7"></div>
                                                        </div>
                                                        <div class="col-lg-4 mb-3">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">
                                                                Actual Amount<span class="text-danger">*</span>
                                                            </label>
                                                            <input type="text" class="form-control validation_input_edit" name="edit_actual_amount[]"
                                                                placeholder="Enter Actual Amount"
                                                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                            <div class="validation_err_edit text-danger mt-1 fw-semibold fs-7"></div>
                                                        </div>
                                                        <input type="hidden" value="${currency.sno}" class="edit-currency_id" name="edit_currency_id[]" />                                                
                                                        <div class="row edit-variants-container"></div>                      
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>`;
                                editAccordionContainer.append(editAccordionItem);
                                resolve();
                            });
                        } else {
                            editAccordionContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                        }
                    }
                },
                error: function (error) {
                    console.log(`Error Fetching Data : ${error}`);
                    reject(error);
                }
            });
        });
    }
</script>

<!-- Edit Data Fetch -->
<script>
    function fetchEditData(id) {
        editAccordionDataFetch().then(() => {
            $.ajax({
                url: `/package_edit/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === 200) {
                        const edit = response.data;
                        const prizeBook = response.prizeBook;
                        const editIsAccordion = $('.edit-accordion');

                        if (editIsAccordion && editIsAccordion.length > 0) {
                            editIsAccordion.each(function () {
                                const $accordionItem = $(this);
                                const currencyId = $accordionItem.find('.edit-currency_id').val();
                                const editVariantsContainer = $accordionItem.find('.edit-variants-container');

                                const matchedPrize = prizeBook.find(pb => pb.currency_id == currencyId);
                                
                                if (matchedPrize) {
                                    $accordionItem.find('input[name="edit_base_price[]"]').val(matchedPrize.base_price);
                                    $accordionItem.find('input[name="edit_min_amount[]"]').val(matchedPrize.min_amount);
                                    $accordionItem.find('input[name="edit_max_amount[]"]').val(matchedPrize.max_amount);
                                    $accordionItem.find('input[name="edit_actual_amount[]"]').val(matchedPrize.actual_price);
                                    $accordionItem.find('input[name="edit_id[]"]').val(matchedPrize.sno);
                                }

                                editVariantsContainer.html('');

                                if (edit && edit.length > 0) {
                                    edit.forEach(product => {
                                        product.variants.forEach((variant, index) => {

                                            let amountValue = '';
                                            prizeBook.forEach(pb => {
                                                if (pb.currency_id == currencyId && pb.varient_details) {
                                                    try {
                                                        const varients = JSON.parse(pb.varient_details);
                                                        varients.forEach(v => {
                                                            if (
                                                                v.variant_id == variant.variant_id &&
                                                                v.variable_id == variant.variable_id
                                                            ) {
                                                                amountValue = v.amount;
                                                                baseProductAmount = v.base_price;
                                                            }
                                                        });
                                                    } catch (e) {
                                                        console.error("Error parsing varient_details:", e);
                                                    }
                                                }
                                            });

                                            const variantElement = `
                                                <label
                                                    class="d-flex align-items-center justify-content-between text-white my-3 px-3 py-2 fs-5 fw-semibold bg-info rounded package-product-name">
                                                    <span>${product.product_name} ( ${variant.variant_name} )</span>
                                                    <span class="badge bg-warning text-black ms-3 fw-semibold"
                                                        id="total-label_${currencyId}_${variant.variant_id}">${parseFloat(amountValue) + parseFloat(baseProductAmount)}</span>
                                                </label>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                        data-bs-placement="right" title="${variant.variable_name}">
                                                        Base Price<span class="text-danger">*</span>
                                                    </label>
                                                    <input type="text" class="form-control validation_input_edit" placeholder="Enter Amount"
                                                        name="product_base_price[${currencyId}][]" value="${baseProductAmount}" id="base_price_${currencyId}_${variant.variant_id}" onkeyup="changePrices(${currencyId}, ${variant.variant_id})"
                                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\\d*/, '$1');" />
                                                    <div class="validation_err_edit text-danger mt-1 fw-semibold fs-7"></div>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                        data-bs-placement="right" title="${variant.variable_name}">
                                                        ${variant.variable_name}<span class="text-danger">*</span>
                                                    </label>
                                                    <input type="hidden" name="edit_package_id" value="${product.package_id}" />
                                                    <input type="hidden" name="edit_variant_id[${currencyId}][]" value="${variant.variant_id}" />
                                                    <input type="hidden" name="edit_variable_id[${currencyId}][]" value="${variant.variable_id}" />
                                                    <input type="hidden" name="edit_product_id[${currencyId}][]" value="${product.product_id}" />
                                                    <input type="text" class="form-control validation_input_edit" placeholder="Enter Amount" 
                                                        name="edit_amount[${currencyId}][]"  onkeyup="changePrices(${currencyId}, ${variant.variant_id})" id="variant_amount_${currencyId}_${variant.variant_id}"
                                                        value="${amountValue}"
                                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\\d*/, '$1');" />
                                                    <div class="validation_err_edit text-danger mt-1 fw-semibold fs-7"></div>
                                                </div>`;
                                            
                                            editVariantsContainer.append(variantElement);
                                        });
                                    });
                                } else {
                                    editVariantsContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                                }

                                // 🪙 INR Section
                                const editVariantsContainerINR = $('#edit-varient-inr');
                                editVariantsContainerINR.html('');

                                if (edit && edit.length > 0) {
                                    edit.forEach(product => {
                                        product.variants.forEach(variantINR => {
                                            const variantElementINR = `
                                                <label
                                                    class="d-flex align-items-center justify-content-between text-white my-3 px-3 py-2 fs-5 fw-semibold bg-info rounded package-product-name">
                                                    <span>${product.product_name} ( ${variantINR.variant_name} )</span>
                                                    <span class="badge bg-warning text-black ms-3 fw-semibold">₹${parseFloat(product.product_base_price) + parseFloat(variantINR.amount)}</span>
                                                </label>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                        data-bs-placement="right" title="Base Price">
                                                        Base Price
                                                    </label>
                                                    <div class="text-danger fs-5 d-block fw-semibold">
                                                        ₹${Number(product.product_base_price).toLocaleString('en-IN')}
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                        data-bs-placement="right" title="${variantINR.variable_name}">
                                                        ${variantINR.variable_name}
                                                    </label>
                                                    <div class="text-danger fs-5 d-block fw-semibold">
                                                        ₹${Number(variantINR.amount).toLocaleString('en-IN')}
                                                    </div>
                                                </div>`;
                                            
                                            editVariantsContainerINR.append(variantElementINR);
                                        });
                                    });
                                } else {
                                    editVariantsContainerINR.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                                }
                            });
                        }

                        if (Array.isArray(edit) && edit[0] && typeof edit[0].base_price !== 'undefined') {
                            $('#edit-inr-base').html(`₹${Number(edit[0].base_price).toLocaleString('en-IN')}`);
                            $('#edit-inr-min').html(`₹${Number(edit[0].min_amount || 0).toLocaleString('en-IN')}`);
                            $('#edit-inr-max').html(`₹${Number(edit[0].max_amount || 0).toLocaleString('en-IN')}`);
                            $('#edit-actual-inr').html(`₹${Number(edit[0].actual_amount || 0).toLocaleString('en-IN')}`);
                        } else {
                            $('#edit-inr-base').html('₹0');
                            $('#edit-inr-min').html('₹0');
                            $('#edit-inr-max').html('₹0');
                            $('#edit-actual-inr').html('₹0');
                        }

                        $('#edit-package-name').html(edit[0].package_name);
                        $('#update-btn').html(edit[0].package_name);

                    }
                },
                error: function(error) {
                    console.log(`Error Fetching Data : ${error}`);
                }
            });
        });
    }
</script>

<!-- Edit Validation -->
<script>
    function editValidation() {
        let isValid = true;
        
        $('.validation_err_edit').text('');
        $('.validation_input_edit').removeClass('input-error');
        
        $('.accordion-button')
            .removeClass('bg-danger bg-opacity-10 text-danger')
            .addClass('bg-light')
            .css('border-left', '');

        $('.validation_input_edit').each(function() {
            const $input = $(this);
            const value = $input.val().trim();
            const $errorElement = $input.closest('.mb-3').find('.validation_err_edit');
            
            if(!value) {
                isValid = false;
                $input.addClass('input-error');
                $errorElement.text('This field is required.');
                
                $input.closest('.accordion-item')
                    .find('.accordion-button')
                    .removeClass('bg-light')
                    .addClass('bg-danger bg-opacity-10 text-danger')
                    .css('border-left', '3px solid #dc3545');
            }
        });

        // 3. FINAL CHECKS
        if(isValid) {
            // Form is valid - ensure all styling is reset
            $('.accordion-button')
                .removeClass('bg-danger bg-opacity-10 text-danger')
                .addClass('bg-light')
                .css('border-left', '');
                
            $('#edit_price_form').submit();
        } else {
            $('#whole-container').show();
            $('#inr-add-block').show();
        }
        
        return false;
    }
</script>

<!-- View Price Book -->
<script>
    function priceBookView(id) {
        viewAccordionDataFetch().then(() => {
            $.ajax({
                url: `/package_prize_book_view/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function (response) {
                    if(response.status === 200) {
                        const view = response.data;
                        const viewBook = response.prizeBook;
                        const viewIsAccordion = $('.view-accordion');

                        if (viewIsAccordion && viewIsAccordion.length > 0) {
                                viewIsAccordion.each(function () {
                                    const $accordionItem = $(this);
                                    const currencyId = $accordionItem.find('.view-currency_id').val();
                                    const viewVariantsContainer = $accordionItem.find('.view-variants-container');

                                    const matchedPrize = viewBook.find(pb => pb.currency_id == currencyId);
                                    
                                    if (matchedPrize) {
                                        $accordionItem.find('.view_base_price').html(matchedPrize.base_price);
                                        $accordionItem.find('.view_min_amount').html(matchedPrize.min_amount);
                                        $accordionItem.find('.view_max_amount').html(matchedPrize.max_amount);
                                        $accordionItem.find('.view_actual_amount').html(matchedPrize.actual_price);
                                    }

                                    viewVariantsContainer.html('');

                                    if (view && view.length > 0) {
                                        view.forEach(product => {
                                            product.variants.forEach((variant, index) => {

                                                let amountValue = '';
                                                viewBook.forEach(pb => {
                                                    if (pb.currency_id == currencyId && pb.varient_details) {
                                                        try {
                                                            const varients = JSON.parse(pb.varient_details);
                                                            varients.forEach(v => {
                                                                if (
                                                                    v.variant_id == variant.variant_id &&
                                                                    v.variable_id == variant.variable_id
                                                                ) {
                                                                    amountValue = v.amount;
                                                                    productBasePrice = v.base_price;
                                                                }
                                                            });
                                                        } catch (e) {
                                                            console.error("Error parsing varient_details:", e);
                                                        }
                                                    }
                                                });

                                                const variantElement = `
                                                    <label
                                                        class="d-flex align-items-center justify-content-between text-white my-3 px-3 py-2 fs-5 fw-semibold bg-info rounded package-product-name">
                                                        <span>${product.product_name} ( ${variant.variant_name} )</span>
                                                        <span class="badge bg-warning text-black ms-3 fw-semibold"
                                                            id="total-label_${currencyId}_${variant.variant_id}">${parseFloat(amountValue) + parseFloat(productBasePrice)}</span>
                                                    </label>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                            data-bs-placement="right" title="Base Price">
                                                            Base Price
                                                        </label>
                                                        <div class="text-danger fw-semibold d-block fs-5">${productBasePrice}</div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                            data-bs-placement="right" title="${variant.variable_name}">
                                                            ${variant.variable_name}
                                                        </label>
                                                        <div class="text-danger fw-semibold d-block fs-5">${amountValue}</div>
                                                    </div>`;
                                                
                                                viewVariantsContainer.append(variantElement);
                                            });
                                        });
                                    } else {
                                        viewVariantsContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                                    }

                                    // 🪙 INR Section
                                    const viewVariantsContainerINR = $('#view-varient-inr');
                                    viewVariantsContainerINR.html('');

                                    if (view && view.length > 0) {
                                        view.forEach(product => {
                                            product.variants.forEach(variantINR => {
                                                const variantElementINR = `
                                                    <label
                                                        class="d-flex align-items-center justify-content-between text-white my-3 px-3 py-2 fs-5 fw-semibold bg-info rounded package-product-name">
                                                        <span>${product.product_name} ( ${variantINR.variant_name} )</span>
                                                        <span class="badge bg-warning text-black ms-3 fw-semibold">₹${parseFloat(product.product_base_price) + parseFloat(variantINR.amount)}</span>
                                                    </label>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                            data-bs-placement="right" title="Base Price">
                                                            Base Price
                                                        </label>
                                                        <div class="text-danger fs-5 d-block fw-semibold">
                                                            ₹${Number(product.product_base_price).toLocaleString('en-IN')}
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                            data-bs-placement="right" title="${variantINR.variable_name}">
                                                            ${variantINR.variable_name}
                                                        </label>
                                                        <div class="text-danger fs-5 d-block fw-semibold">
                                                            ₹${Number(variantINR.amount).toLocaleString('en-IN')}
                                                        </div>
                                                    </div>`;
                                                
                                                viewVariantsContainerINR.append(variantElementINR);
                                            });
                                        });
                                    } else {
                                        viewVariantsContainerINR.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                                    }
                                });
                            }

                            if (Array.isArray(view) && view[0] && typeof view[0].base_price !== 'undefined') {
                                $('#view-inr-base').html(`₹${Number(view[0].base_price).toLocaleString('en-IN')}`);
                                $('#view-inr-min').html(`₹${Number(view[0].min_amount || 0).toLocaleString('en-IN')}`);
                                $('#view-inr-max').html(`₹${Number(view[0].max_amount || 0).toLocaleString('en-IN')}`);
                            } else {
                                $('#view-inr-base').html('₹0');
                                $('#view-inr-min').html('₹0');
                                $('#view-inr-max').html('₹0');
                            }

                        $('#view-package-name').html(view[0].package_name);
                        
                    } else {
                        console.log(`Error Fetching Data.`);
                    }
                },
                error: function (error) {
                    console.error(`Error Fetching Data : ${error}`);
                }
            });
        });
    }
</script>

<!-- View Accordion -->
<script>
    function viewAccordionDataFetch () {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: '/currency_accordion',
                method: 'GET',
                dataType: 'json',
                success: function (response) {
                    if(response.status === 200) {
                        var data = response.data;
                        const viewAccordionContainer = $('#view-accordion-container');
                        viewAccordionContainer.html('');

                        if(data && data.length > 0) {
                            data.forEach((currency, index) => {
                                const headingId = `heading${index}`;
                                const collapseId = `collapse${index}`;

                                const viewAccordionItem = `
                                    <div class="accordion-item active view-accordion">
                                        <h2 class="accordion-header" id="${headingId}">
                                            <button type="button" class="accordion-button collapsed bg-light border-0 shadow-sm fs-5 fw-semibold text-black"
                                                data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="false" aria-controls="${collapseId}">
                                                <span class="me-2 text-capitalize">
                                                    ${currency.currency_name}
                                                </span>
                                                <span class="text-primary fw-bold">
                                                    ( ${currency.currency_symbol} )  
                                                </span>
                                                <span class="ms-2 text-capitalize">
                                                    ${currency.country_name}
                                                </span>
                                            </button>
                                        </h2>
                                        <div id="${collapseId}" class="accordion-collapse collapse" aria-labelledby="${headingId}"
                                            data-bs-parent="#viewAccordionExample">
                                            <div class="accordion-body">
                                                <div class="card-body py-1">
                                                    <div class="row">
                                                        <div class="col-md-4 mb-3">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">Base Price</label>
                                                            <div class="text-danger fw-semibold d-block fs-5 view_base_price">-</div>
                                                        </div>
                                                        <div class="col-md-4 mb-3">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount</label>
                                                            <div class="text-danger fw-semibold d-block fs-5 view_min_amount">-</div>
                                                        </div>
                                                        <div class="col-md-4 mb-3">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">Maximum Amount</label>
                                                            <div class="text-danger fw-semibold d-block fs-5 view_max_amount">-</div>
                                                        </div>
                                                        <div class="col-md-4 mb-3">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">Actual Amount</label>
                                                            <div class="text-danger fw-semibold d-block fs-5 view_actual_amount">-</div>
                                                        </div>
                                                        <input type="hidden" value="${currency.sno}" class="view-currency_id"/>                                                
                                                        <div class="row view-variants-container"></div>                      
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>`;
                                viewAccordionContainer.append(viewAccordionItem);
                                resolve();
                            });
                        } else {
                            viewAccordionContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                        }
                    }
                },
                error: function (error) {
                    console.log(`Error Fetching Data : ${error}`);
                    reject(error);
                }
            });
        });
    }
</script>

@endsection