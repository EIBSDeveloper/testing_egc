@extends('layouts/layoutMaster')

@section('title', 'Manage Price Book')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
</head>
<!-- Users List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Price Book</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Product Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" onclick="accordionDataFetch()"
                    data-bs-target="#kt_modal_add_price_book">
                    <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Price Book
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                        onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form id="search_form" method="POST" action="/manage_price_book">
                        @csrf
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <div>
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="0">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                                    value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <input type="text" class="form-control" id="search_fill" name="search_fill"
                                    value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Products</th>
                            <th class="min-w-100px">Base Amount</th>
                            <th class="min-w-100px">Minimum Amount</th>
                            <th class="min-w-100px">Maximum Amount</th>
                            <th class="min-w-100px">Currency</th>
                            <th class="min-w-100px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        @foreach($ListTable as $list)
                            <tr>
                                <td>
                                    <div class="text-truncate max-w-200px" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="{{ $list->product_name }}">{{ $list->product_name }}</div>
                                    <div class="d-block">
                                        <div class="text-dark fs-8 text-truncate max-w-200px" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="{{ $list->product_category_name }}">{{ $list->product_category_name }}</div>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="badge bg-label-info border border-info rounded text-black text-black fs-7 fw-semibold">&#8377; {{ number_format($list->base_price) }}</label>
                                </td>
                                <td>
                                    <label
                                        class="badge bg-label-success rounded border border-success text-black fs-7 fw-semibold mb-1">
                                        &#8377; {{ number_format($list->min_amount) }}</label>
                                </td>
                                <td>
                                    <label
                                        class="badge bg-label-danger rounded border border-danger text-black fs-7 fw-semibold mb-1">
                                        &#8377; {{ number_format($list->max_amount) }}</label>
                                </td>
                                <td>
                                    <div class="fw-semibold">INR ( &#8377; )</div>
                                </td>

                                <td>
                                    <span class="text-end">
                                        <a href="javascript:;"
                                            class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_view_price_book" onclick="priceBookView('{{ $list->product_id }}')">
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="View Price Book">
                                                <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i> <i class=""></i>
                                            </span>
                                        </a>
                                        <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_edit_price_book" onclick="fetchEditData('{{ $list->product_id }}')">
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Edit Price Book">
                                                <i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>
                                            </span>
                                        </a>

                                    </span>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Create Price Book-->
<div class="modal fade" id="kt_modal_add_price_book" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">Create Price Book</h3>
                </div>
                <form id="price_book_form" action="{{ route('save_price_book') }}" method="POST">
                    @csrf
                    <div class="row mb-3">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Product <span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="product_id" name="product_id" onchange="productVariantDataFetch(this.value)">
                                <!-- AJAX Will Populate Here -->
                            </select>
                            <div class="error_msg text-danger mt-1 fw-semibold fs-7" id="product_id_err"></div>
                        </div>
                    </div>

                    <div class="card rounded mb-3 border" id="inr-add-block" style="display: none;">
                        <div class="card-header bg-light border-bottom shadow-sm py-3">
                            <span class="fs-5 fw-semibold text-black text-capitalize me-2">
                                INR
                            </span>
                            <span class="text-primary fw-bold">
                                ( ₹ )
                            </span>
                        </div>
                        <div class="card-body py-1">
                            <div class="row mt-2">
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Base Price</label>
                                    <div class="text-danger fs-5 d-block fw-semibold " id="product-base-price">-</div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="product-min-amount">-</div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Maximum Amount</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="product-max-amount">-</div>
                                </div>
                                <div id="variants-container-inr" class="row"></div>
                            </div>
                        </div>
                    </div>

                    <div class="scroll-y max-h-1000px" id="whole-container" style="display: none;">
                        <div class="accordion" id="accordionExample">
                            <div id="accordion-container"></div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="create_price_book" disabled onclick="addValidation()">Create Price Book</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Price Book-->

<!--begin::Modal - Edit Price Book-->
<div class="modal fade" id="kt_modal_edit_price_book" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">Update <span class="text-info fw-semibold" id="edit-product-name">-</span></h3>
                </div>

                <form action="{{ route('update_price_book') }}" method="POST" id="edit_price_form">
                    @csrf
                    <!-- INR Card -->
                    <div class="card rounded mb-3">
                        <div class="card-header py-0 bg-light rounded">
                            <div class="py-3 ">
                                <span class="badge fs-4  py-1 text-black">INR ( <span class="text-primary">₹</span> )</span>
                            </div>
                        </div>
                        <div class="card-body py-1">
                            <div class="row mt-2">
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Base Price</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="edit-inr-base">₹</div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="edit-inr-min">₹</div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Maximum Amount</label>
                                    <div class="text-danger fs-5 d-block fw-semibold" id="edit-inr-max">₹</div>
                                </div>
                                <div id="edit-varient-inr" class="row"></div>
                            </div>
                        </div>
                    </div>
                    <div class="scroll-y max-h-1000px">
                        
                        <!-- Accordion -->
                        <div class="accordion" id="accordionExample">
                            <div id="edit-accordion-container"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="editValidation()">Update&nbsp;<span id="update-btn">-</span></button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Price Book-->

<!--begin::Modal - View Price Book-->
<div class="modal fade" id="kt_modal_view_price_book" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">View <span class="text-info fw-semibold" id="view-product-name">-</span></h3>
                </div>

                <div class="card rounded mb-3">
                    <div class="card-header py-0 bg-light text-success rounded">
                        <div class="py-3 ">
                            <div class="fw-semibold text-black fs-4">INR ( <span class="text-primary">₹</span> )</div>
                        </div>
                    </div>
                    <!-- INR Container -->
                    <div class="card-body py-1">
                        <div class="row mt-2">
                            <div class="col-md-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Base Price</label>
                                <div class="text-danger fw-semibold d-block fs-5" id="view-inr-base">-</div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount</label>
                                <div class="text-danger fw-semibold d-block fs-5" id="view-inr-min">-</div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Maximum Amount</label>
                                <div class="text-danger fw-semibold d-block fs-5" id="view-inr-max">-</div>
                            </div>
                            <div id="view-varient-inr" class="row"></div>
                        </div>
                    </div>
                </div>
                <!-- Accordion -->
                <div class="scroll-y max-h-1000px">
                    <div class="accordion" id="accordionExample">
                        <div id="view-accordion-container"></div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Price Book-->

<!-- Toastr Starts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .err_msg {
            /* background-color: red; */
            border-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
<!-- Toastr Ends -->

<!-- Sort Filter -->
<script>
    function sort_filter(val) {
        if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
        } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
        }
    }
</script>

<!-- Data Table -->
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<!-- Accordion Fetch -->
<script>
    function accordionDataFetch () {
        $.ajax({
            url: '/currency_accordion',
            method: 'GET',
            dataType: 'json',
            success: function (response) {
                if(response.status === 200) {
                    var data = response.data;
                    const accordionContainer = $('#accordion-container');
                    accordionContainer.html('');

                    if(data && data.length > 0) {
                        data.forEach((currency, index) => {
                            const headingId = `heading${index}`;
                            const collapseId = `collapse${index}`;

                            const accordionItem = `
                                <div class="accordion-item active">
                                    <h2 class="accordion-header" id="${headingId}">
                                        <button type="button" class="accordion-button collapsed bg-light border-0 shadow-sm fs-5 fw-semibold text-black"
                                            data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="false" aria-controls="${collapseId}">
                                            <span class="me-2 text-capitalize">
                                                ${currency.currency_name}
                                            </span>
                                            <span class="text-primary fw-bold">
                                                ( ${currency.currency_symbol} )
                                            </span>
                                        </button>
                                    </h2>
                                    <div id="${collapseId}" class="accordion-collapse collapse" aria-labelledby="${headingId}"
                                        data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <div class="card-body py-1">
                                                <div class="row">
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">
                                                            Base Price<span class="text-danger">*</span>
                                                        </label>
                                                        <input type="text" class="form-control validation_input" name="data[${currency.sno}][base_price]" placeholder="Enter Base Price" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                        <div class="validation_err text-danger mt-1 fw-semibold fs-7"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">
                                                            Minimum Amount<span class="text-danger">*</span>
                                                        </label>
                                                        <input type="text" class="form-control validation_input" name="data[${currency.sno}][min_amount]" placeholder="Enter Minimum Amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                        <div class="validation_err text-danger mt-1 fw-semibold fs-7"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">
                                                            Maximum Amount<span class="text-danger">*</span>
                                                        </label>
                                                        <input type="text" class="form-control validation_input" name="data[${currency.sno}][max_amount]" placeholder="Enter Maximum Amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                        <div class="validation_err text-danger mt-1 fw-semibold fs-7"></div>
                                                    </div>
                                                    <input type="hidden" value="${currency.sno}" class="currency_id" />
                                                    <div class="row variants-container"></div>                      
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>`;
                            accordionContainer.append(accordionItem);
                        });
                    } else {
                        accordionContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                    }
                }
            },
            error: function (error) {
                console.log(`Error Fetching Data : ${error}`);
            }
        });
    }
</script>

<!-- Product Data Fetch -->
<script>
    $(document).ready(function () {
        $.ajax({
            url: '/product_data_fetch',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {
                    var products = response.data;
                    const productDropDown = $('#product_id');
                    productDropDown.empty();
                    productDropDown.append(
                        $('<option></option>').val('').text('Select Product')
                    );

                    products.forEach(p => {
                        productDropDown.append(
                            $('<option></option>').val(p.sno).text(p.product_name)
                        );
                    });
                } else {
                    console.log(`Data Cleared.`);
                }
            },
            error: function(error) {
                console.error(`Error Fetching Data: ${error}`);
            }
        });
    });
</script>

<!-- Product Variant Data Fetch -->
<script>
    function productVariantDataFetch(id) {
        $.ajax({
            url: `/product_variant_data_fetch/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {
                    const variants = response.data;
                    const isAccordion = $('.accordion-item');

                    // For each accordion item (each currency)
                    if(isAccordion && isAccordion.length > 0) {
                        isAccordion.each(function () {
                            const $accordionItem = $(this);
                            const currencyId = $accordionItem.find('.currency_id').val();
                            const variantsContainer = $accordionItem.find('.variants-container');

                            variantsContainer.html('');  // clear old variants

                            if(variants && variants.length > 0) {
                                variants.forEach(variant => {
                                    const variantElement = `
                                        <div class="col-lg-4 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                data-bs-placement="right" title="${variant.variable_name}">
                                                ${variant.variable_name}<span class="text-danger">*</span>
                                            </label>
                                            <input type="text" class="form-control validation_input" 
                                                name="data[${currencyId}][variants][${variant.sno}]" 
                                                placeholder="Enter Amount" 
                                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                            <div class="validation_err text-danger mt-1 fw-semibold fs-7"></div>
                                        </div>
                                    `;
                                    variantsContainer.append(variantElement);
                                });
                            } else {
                                variantsContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                            }
                        });
                    } else {
                        variantsContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                    }

                    // Also update the INR variants container and base price info as before
                    const variantsContainerINR = $('#variants-container-inr');
                    variantsContainerINR.html('');

                    if(variants && variants.length > 0) {
                        variants.forEach(variantINR => {
                            const variantElementINR = `
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                        data-bs-placement="right" title="${variantINR.variable_name}">${variantINR.variable_name}</label>
                                    <div class="text-danger fs-5 d-block fw-semibold">₹${Number(variantINR.variable_amount).toLocaleString('en-IN')}</div>
                                </div>`;
                            variantsContainerINR.append(variantElementINR);
                        });
                    } else {
                        variantsContainerINR.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                    }

                    if (Array.isArray(variants) && variants[0] && typeof variants[0].base_price !== 'undefined') {
                        $('#product-base-price').html(`₹${Number(variants[0].base_price).toLocaleString('en-IN')}`);
                        $('#product-min-amount').html(`₹${Number(variants[0].min_amount || 0).toLocaleString('en-IN')}`);
                        $('#product-max-amount').html(`₹${Number(variants[0].max_amount || 0).toLocaleString('en-IN')}`);
                    } else {
                        $('#product-base-price').html('₹0');
                        $('#product-min-amount').html('₹0');
                        $('#product-max-amount').html('₹0');
                    }                    
                }

                $('#whole-container').show();
                $('#inr-add-block').show();
                $('#create_price_book').prop('disabled', false);
            },
            error: function(error) {
                console.log(`Error Fetching Data : ${error}`);
            }
        });
    }

</script>

<!-- Validation and Hide and Show Accordion -->
    <style>
        .input-error {
            border-color: #dc3545 !important; /* Bootstrap's danger color */
        }
    </style>

    <script>
        function addValidation() {
            let isValid = true;
            
            $('.validation_err').text('');
            $('.validation_input').removeClass('input-error');
            
            $('.accordion-button')
                .removeClass('bg-danger bg-opacity-10 text-danger')
                .addClass('bg-light')
                .css('border-left', '');

            $('.validation_input').each(function() {
                const $input = $(this);
                const value = $input.val().trim();
                const $errorElement = $input.closest('.mb-3').find('.validation_err');
                
                if(!value) {
                    isValid = false;
                    $input.addClass('input-error');
                    $errorElement.text('This field is required.');
                    
                    $input.closest('.accordion-item')
                        .find('.accordion-button')
                        .removeClass('bg-light')
                        .addClass('bg-danger bg-opacity-10 text-danger')
                        .css('border-left', '3px solid #dc3545');
                }
            });

            // 3. FINAL CHECKS
            if(isValid) {
                // Form is valid - ensure all styling is reset
                $('.accordion-button')
                    .removeClass('bg-danger bg-opacity-10 text-danger')
                    .addClass('bg-light')
                    .css('border-left', '');
                $('#price_book_form').submit();
            } else {
                $('#whole-container').show();
                $('#inr-add-block').show();
            }
            
            return false;
        }
    </script>
<!-- Validation Ends -->

<!-- Edit Data Fetch -->
<script>
    function fetchEditData(id) {
        $.ajax({
            url: `/price_book_edit/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {
                    var edit = response.data;

                    $('#edit-product-name').html(edit[0].product_name);
                    $('#update-btn').text(edit[0].product_name);
                    $('#edit-inr-base').html(`₹${Number(edit[0].product_base || 0).toLocaleString('en-IN')}`);
                    $('#edit-inr-min').html(`₹${Number(edit[0].product_min || 0).toLocaleString('en-IN')}`);
                    $('#edit-inr-max').html(`₹${Number(edit[0].product_max || 0).toLocaleString('en-IN')}`);
                    const editAccordionContainer = $('#edit-accordion-container');
                    const editVariantINRContainer = $('#edit-varient-inr');
                    editAccordionContainer.html('');
                    editVariantINRContainer.html('');

                    if(edit && edit.length > 0) {
                        edit.forEach((currency, index) => {
                            
                            const headingIdEdit = `heading${index}`;
                            const collapseIdEdit = `collapse${index}`;

                            let variantInputs = '';

                            if (currency.variants && currency.variants.length > 0) {
                                variantInputs = currency.variants.map(variant => `
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                            data-bs-placement="right" title="${variant.variant_name}">
                                            ${variant.variant_name}<span class="text-danger">*</span>
                                        </label>
                                        <input type="text" class="form-control validation_input_edit"
                                            name="data[${currency.sno}][variants][${variant.variant_id}]" 
                                            value="${variant.amount}"
                                            placeholder="Enter Amount"
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                        <div class="validation_err_edit text-danger mt-1 fw-semibold fs-7"></div>
                                    </div>
                                `).join('');
                            } else {
                                variantInputs = `
                                    <label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>
                                `;
                            }
                            
                            const editAccordionItem = `
                            <div class="accordion-item active">
                                <h2 class="accordion-header" id="${headingIdEdit}">
                                    <button type="button" class="accordion-button collapsed bg-light border-0 shadow-sm fs-5 fw-semibold text-black"
                                        data-bs-toggle="collapse" data-bs-target="#${collapseIdEdit}" aria-expanded="false"
                                        aria-controls="${collapseIdEdit}">
                                        <span class="me-2 text-capitalize">${currency.currency_name}</span>
                                        <span class="text-primary fw-bold">( ${currency.currency_symbol} )</span>
                                    </button>
                                </h2>
                                <div id="${collapseIdEdit}" class="accordion-collapse collapse" aria-labelledby="${headingIdEdit}"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <div class="card-body py-1">
                                            <div class="row">
                                                <!-- Base Price -->
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-black mb-1 fs-6 fw-semibold">
                                                        Base Price<span class="text-danger">*</span>
                                                    </label>
                                                    <input type="text" class="form-control validation_input_edit" value="${currency.base_price}"
                                                        name="data[${currency.sno}][base_price]" placeholder="Enter Base Price"
                                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                    <div class="validation_err_edit text-danger mt-1 fw-semibold fs-7"></div>
                                                </div>
                            
                                                <!-- Min Amount -->
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-black mb-1 fs-6 fw-semibold">
                                                        Minimum Amount<span class="text-danger">*</span>
                                                    </label>
                                                    <input type="text" class="form-control validation_input_edit" value="${currency.min_amount}"
                                                        name="data[${currency.sno}][min_amount]" placeholder="Enter Minimum Amount"
                                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                    <div class="validation_err_edit text-danger mt-1 fw-semibold fs-7"></div>
                                                </div>
                            
                                                <!-- Max Amount -->
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-black mb-1 fs-6 fw-semibold">
                                                        Maximum Amount<span class="text-danger">*</span>
                                                    </label>
                                                    <input type="text" class="form-control validation_input_edit" value="${currency.max_amount}"
                                                        name="data[${currency.sno}][max_amount]" placeholder="Enter Maximum Amount"
                                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                                    <div class="validation_err_edit text-danger mt-1 fw-semibold fs-7"></div>
                                                </div>
                            
                                                <input type="hidden" name="data[${currency.sno}][sno]" value="${currency.sno}" />
                            
                                                <!-- Variant Inputs -->
                                                ${variantInputs}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            `;
                            
                            editAccordionContainer.append(editAccordionItem);

                            // INR Varient Container
                            let variantBadge = '';
                            editVariantINRContainer.html('');

                            if(currency.variants && currency.variants.length > 0) {
                                variantBadge = currency.variants.map(variant => `
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" title="${variant.variant_name}">
                                        ${variant.variant_name}
                                    </label>
                                    <div class="text-danger fs-5 d-block fw-semibold">
                                        ₹${Number(variant.variable_amount || 0).toLocaleString('en-IN')}
                                    </div>
                                </div>
                                `).join('');

                                editVariantINRContainer.append(variantBadge);
                            } else {
                                variantBadge = `
                                    <label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants
                                        found.</label>
                                    `;

                                editVariantINRContainer.append(variantBadge);
                            }
                        });
                    }
                    
                } else {
                    console.log('Error Fetching Data.');
                }
            },
            error: function(error) {
                console.error(`Error Fetching Data : ${error}`);
            }
        });
    }
</script>

<!-- Edit Validation -->
<script>
    function editValidation() {
        let isValid = true;
        
        $('.validation_err_edit').text('');
        $('.validation_input_edit').removeClass('input-error');
        
        $('.accordion-button')
            .removeClass('bg-danger bg-opacity-10 text-danger')
            .addClass('bg-light')
            .css('border-left', '');

        $('.validation_input_edit').each(function() {
            const $input = $(this);
            const value = $input.val().trim();
            const $errorElement = $input.closest('.mb-3').find('.validation_err_edit');
            
            if(!value) {
                isValid = false;
                $input.addClass('input-error');
                $errorElement.text('This field is required.');
                
                $input.closest('.accordion-item')
                    .find('.accordion-button')
                    .removeClass('bg-light')
                    .addClass('bg-danger bg-opacity-10 text-danger')
                    .css('border-left', '3px solid #dc3545');
            }
        });

        // 3. FINAL CHECKS
        if(isValid) {
            // Form is valid - ensure all styling is reset
            $('.accordion-button')
                .removeClass('bg-danger bg-opacity-10 text-danger')
                .addClass('bg-light')
                .css('border-left', '');
                
            $('#edit_price_form').submit();
        } else {
            $('#whole-container').show();
            $('#inr-add-block').show();
        }
        
        return false;
    }
</script>

<!-- View Price Book -->
<script>
    function priceBookView(id) {
        $.ajax({
            url: `/view_price_book/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function (response) {
                if(response.status === 200) {
                    var view = response.data;
                    
                    $('#view-product-name').html(view[0].product_name);
                    $('#view-currency-name').html(`${view.currency_name} ( <span class="text-primary">${view.currency_symbol}</span> )`);
                    $('#view-inr-base').html(`₹${Number(view[0].product_base || 0).toLocaleString('en-IN')}`);
                    $('#view-inr-min').html(`₹${Number(view[0].product_min || 0).toLocaleString('en-IN')}`);
                    $('#view-inr-max').html(`₹${Number(view[0].product_max || 0).toLocaleString('en-IN')}`);

                    const viewAccordionContainer = $('#view-accordion-container');
                    const viewVariantINRContainer = $('#view-varient-inr');
                    viewAccordionContainer.html('');
                    viewVariantINRContainer.html('');

                    if(view && view.length > 0) {
                        view.forEach((currency, index) => {
                            
                            const headingIdEdit = `heading${index}`;
                            const collapseIdEdit = `collapse${index}`;

                            let viewInputs = '';

                            if (currency.variants && currency.variants.length > 0) {
                                viewInputs = currency.variants.map(variant => `
                                    <div class="col-md-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">${variant.variant_name}</label>
                                        <div class="text-danger fw-semibold d-block fs-5">${variant.amount}</div>
                                    </div>
                                `).join('');
                            } else {
                                viewInputs = `
                                    <label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>
                                `;
                            }
                            
                            const viewAccordionItem = `
                                <div class="accordion-item active">
                                    <h2 class="accordion-header" id="${headingIdEdit}">
                                        <button type="button" class="accordion-button collapsed bg-light border-0 shadow-sm fs-5 fw-semibold text-black"
                                            data-bs-toggle="collapse" data-bs-target="#${collapseIdEdit}" aria-expanded="false"
                                            aria-controls="${collapseIdEdit}">
                                            <span class="me-2 text-capitalize">${currency.currency_name}</span>
                                            <span class="text-primary fw-bold">( ${currency.currency_symbol} )</span>
                                        </button>
                                    </h2>
                                    <div id="${collapseIdEdit}" class="accordion-collapse collapse" aria-labelledby="${headingIdEdit}"
                                        data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <div class="card-body py-1">
                                                <div class="row">
                                                    <!-- Base Price -->
                                                    <div class="col-md-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">
                                                            Base Price
                                                        </label>
                                                        <div class="text-danger fw-semibold d-block fs-5">${currency.base_price}</div>
                                                    </div>
                                                    <!-- Min Amount -->                         
                                                    <div class="col-md-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">
                                                            Minimum Amount
                                                        </label>
                                                        <div class="text-danger fw-semibold d-block fs-5">${currency.min_amount}</div>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">
                                                            Maximum Amount
                                                        </label>
                                                        <div class="text-danger fw-semibold d-block fs-5">${currency.max_amount}</div>
                                                    </div>                            
                                                    <!-- Variant Inputs -->
                                                    ${viewInputs}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                `;
                            
                            viewAccordionContainer.append(viewAccordionItem);

                            // INR Varient Container
                            let viewVariantBadge = '';
                            viewVariantINRContainer.html('');

                            if(currency.variants && currency.variants.length > 0) {
                                viewVariantBadge = currency.variants.map(variant => `
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" title="${variant.variant_name}">
                                        ${variant.variant_name}
                                    </label>
                                    <div class="text-danger fs-5 d-block fw-semibold">
                                        ₹${Number(variant.variable_amount || 0).toLocaleString('en-IN')}
                                    </div>
                                </div>
                                `).join('');

                                viewVariantINRContainer.append(viewVariantBadge);
                            } else {
                                viewVariantBadge = `
                                    <label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants
                                        found.</label>
                                    `;

                                viewVariantINRContainer.append(viewVariantBadge);
                            }
                        });
                    }
                } else {
                    console.log(`Error Fetching Data.`);
                }
            },
            error: function (error) {
                console.error(`Error Fetching Data : ${error}`);
            }
        });
    }
</script>

@endsection