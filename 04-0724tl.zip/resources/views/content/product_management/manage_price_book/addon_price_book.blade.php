@extends('layouts/layoutMaster')

@section('title', 'Manage Price Book')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
@php
$helper = new \App\Helpers\Helpers();
@endphp
<style>

    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }

    .indv_cust_jour thead th,
    .indv_cust_jour tbody td {
        padding: 8px !important;
        border: 1px solid rgb(180, 180, 180) !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>

<!-- Users List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Price Book</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Product Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Add On Price Book</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal"
                    onclick="accordionDataFetch()" data-bs-target="#kt_modal_add_price_book">
                    <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Add On Price Book
                </a>
            </div>
        </div>
    </div>
    <div class="nav-align-top mb-2">
        <ul class="nav nav-pills flex-nowrap" role="tablist">
            <div class="scroll-container-wrapper">
                <button class="scroll-btn left" id="scrollLeftBtn"><i
                        class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                <div class="scroll-container" id="scrollContainer">
                    <div class="item">
                        <li class="nav-item rounded" style="border: 1px solid #099dda;">
                            <a class="nav-link text-capitalize" href="{{ url('/manage_price_book') }}">
                                Product Price Book
                            </a>
                        </li>
                    </div>
                    <div class="item">
                        <li class="nav-item rounded" style="border: 1px solid #099dda;">
                            <a class="nav-link text-capitalize" href="{{ url('/manage_price_book/package') }}">
                                Package Price Book
                            </a>
                        </li>
                    </div>
                    <div class="item">
                        <li class="nav-item rounded" style="border: 1px solid #099dda;">
                            <a class="nav-link text-capitalize active" href="{{ url('/manage_price_book/add_on') }}">
                                Add On Price Book
                            </a>
                        </li>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn"><i
                            class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </div>
        </ul>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                        onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form id="search_form" method="POST" action="/manage_price_book/add_on">
                        @csrf
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <div>
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="0">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                    id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <input type="text" class="form-control" id="search_fill" name="search_fill"
                                    value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Add-On</th>
                            <th class="min-w-100px">Free Variant Count</th>
                            <th class="min-w-100px">Paid Variant Count</th>
                            <th class="min-w-100px">Currency</th>
                            <th class="min-w-100px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        @foreach($ListTable as $i => $list)
                            <tr id="indv_cust_hd_{{$list->sno}}">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1"
                                            onclick="open_func({{$i}});">
                                            <i class="mdi mdi-plus fs-4" id="plus_btn{{$i}}"></i>
                                        </a>
                                        <div class="mb-0 mx-2">
                                            <div class="text-truncate max-w-200px" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="{{ $list->addon_name }}">{{ $list->addon_name }}</div>
                                            </div>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="badge bg-label-info border border-info rounded text-black text-black fs-7 fw-semibold">{{ $list->freevariant_count }}</label>
                                </td>
                                <td>
                                    <label
                                        class="badge bg-label-success rounded border border-success text-black fs-7 fw-semibold mb-1">{{ $list->paidvariant_count }}</label>
                                </td>
                                <td>
                                    <div class="fw-semibold">INR ( &#8377; )</div>
                                </td>

                                <td>
                                    <span class="text-end">
                                        <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_view_price_book"
                                            onclick="priceBookView('{{ $list->addon_id }}')">
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="View Add On Price Book">
                                                <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i> <i class=""></i>
                                            </span>
                                        </a>
                                        <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_edit_price_book"
                                            onclick="fetchEditData('{{ $list->addon_id }}')">
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Edit Add On Price Book">
                                                <i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>
                                            </span>
                                        </a>

                                    </span>
                                </td>
                            </tr>
                            <tr id="colse_tr_div{{$i}}" style="display:none;background-color: #efffdd52;">
                                <td colspan="5" >
                                    <table class="table align-top gy-1 gs-2 indv_cust_jour">
                                        <thead>
                                            <tr class="text-start align-top fs-6 gs-0">
                                                <th class="min-w-50px text-black fw-semibold text-center">S.No</th>
                                                <th class="min-w-150px text-black fw-semibold">Variant Name</th>
                                                <th class="min-w-150px text-black fw-semibold">INR ( &#8377; )</th>
                                                @foreach ($data as $d)
                                                    <th class="min-w-100px text-black fw-semibold">{{ $d->currency_name }} ( {{ $d->currency_symbol }} )</th>
                                                @endforeach
                                            </tr>
                                        </thead>
                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                            @php
                                                $variantDatas = $helper->get_addon_variant($list->addon_id);
                                            @endphp
                                            @foreach ($variantDatas as $index => $variant)
                                                <tr>
                                                    <td align="center">{{ $index + 1 }}</td>
                                                    <td>
                                                        <div class="fs-7 fw-semibold text-black text-truncate max-w-225px" data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom" title="{{ $variant->varient_name }}">
                                                            {{ $variant->varient_name }}
                                                        </div>
                                                    </td>
                                                    <td align="right">
                                                        &#8377; {{ number_format($variant->amount) }}
                                                    </td>
                                                    @foreach ($data as $d)
                                                        @php
                                                            // get all variant details for this currency
                                                            $currencyVariants = $helper->get_currency_addon_price_book($list->addon_id, $d->sno);

                                                            // find the amount for current variant by matching variant_id
                                                            $matchedAmount = 0;
                                                            foreach ($currencyVariants as $cv) {
                                                                if ($cv['variant_id'] == $variant->varient_id) { 
                                                                    $matchedAmount = $cv['amount'];
                                                                    break;
                                                                }
                                                            }
                                                        @endphp
                                                        <td align="right">
                                                            {{ $d->currency_symbol }} {{ number_format($matchedAmount) }}
                                                        </td>
                                                    @endforeach
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Create Price Book-->
<div class="modal fade" id="kt_modal_add_price_book" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">Create Add On Price Book</h3>
                </div>
                <form id="price_book_form" action="{{ route('save_addon_price_book') }}" method="POST">
                    @csrf
                    <div class="row mb-3">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Add On <span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="addon_id" name="addon_id"
                                onchange="packageVariantDataFetch(this.value)">
                                <!-- AJAX Will Populate Here -->
                            </select>
                            <div class="error_msg text-danger mt-1 fw-semibold fs-7" id="product_id_err"></div>
                        </div>
                    </div>

                    <div class="card rounded mb-3 border" id="inr-add-block" style="display: none;">
                        <div class="card-header bg-light border-bottom shadow-sm py-3">
                            <span class="fs-5 fw-semibold text-black text-capitalize me-2">
                                INR
                            </span>
                            <span class="text-primary fw-bold">
                                ( ₹ )
                            </span>
                            India
                        </div>
                        <div class="card-body py-1">
                                <div id="variants-container-inr" class="row"></div>
                        </div>
                    </div>

                    <div class="scroll-y max-h-1000px" id="whole-container" style="display: none;">
                        <div class="accordion" id="accordionExample">
                            <div id="accordion-container"></div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="create_price_book"
                            style="display: none !important;" onclick="addValidation()">Create Add On Price Book</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Price Book-->

<!--begin::Modal - Edit Price Book-->
<div class="modal fade" id="kt_modal_edit_price_book" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">Update <span class="text-info fw-semibold"
                            id="edit-addon-name">-</span></h3>
                </div>

                <form action="{{ route('update_addon_price_book') }}" method="POST" id="edit_price_form">
                    @csrf
                    <!-- INR Card -->
                    <div class="card rounded mb-3">
                        <div class="card-header py-0 bg-light rounded">
                            <div class="py-3 ">
                                <span class="badge fs-4  py-1 text-black">INR ( <span class="text-primary">₹</span>
                                    )</span> India
                            </div>
                        </div>
                        <div class="card-body py-1">
                            <div class="row mt-2">
                                <div id="edit-varient-inr" class="row"></div>
                            </div>
                        </div>
                    </div>
                    <div class="scroll-y max-h-1000px">

                        <!-- Accordion -->
                        <div class="accordion" id="editAccordionExample">
                            <div id="edit-accordion-container"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="editValidation()">Update&nbsp;<span
                                id="update-btn">-</span></button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Price Book-->

<!--begin::Modal - View Price Book-->
<div class="modal fade" id="kt_modal_view_price_book" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">View <span class="text-info fw-semibold"
                            id="view-addon-name">-</span></h3>
                </div>

                <div class="card rounded mb-3">
                    <div class="card-header py-0 bg-light text-success rounded">
                        <div class="py-3 ">
                            <div class="fw-semibold text-black fs-4">INR ( <span class="text-primary">₹</span> ) India
                            </div>
                        </div>
                    </div>
                    <!-- INR Container -->
                    <div class="card-body py-1">
                        <div class="row mt-2">
                            <div id="view-varient-inr" class="row"></div>
                        </div>
                    </div>
                </div>
                <!-- Accordion -->
                <div class="scroll-y max-h-1000px">
                    <div class="accordion" id="viewAccordionExample">
                        <div id="view-accordion-container"></div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Price Book-->

<!-- Toastr Starts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .err_msg {
            /* background-color: red; */
            border-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
                @if (Session::has('toastr'))
                    var type = "{{ Session::get('toastr')['type'] }}";
                    var message = "{{ Session::get('toastr')['message'] }}";
                    toastr[type](message);
                @endif
    </script>
<!-- Toastr Ends -->

<!-- Sort Filter -->
<script>
    function sort_filter(val) {
        if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
        } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
        }
    }
</script>

<!-- Data Table -->
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<!-- Accordion Fetch -->
<script>
    function accordionDataFetch () {
        $.ajax({
            url: '/currency_accordion',
            method: 'GET',
            dataType: 'json',
            success: function (response) {
                if(response.status === 200) {
                    var data = response.data;
                    const accordionContainer = $('#accordion-container');
                    accordionContainer.html('');

                    if(data && data.length > 0) {
                        data.forEach((currency, index) => {
                            const headingId = `heading${index}`;
                            const collapseId = `collapse${index}`;

                            const accordionItem = `
                                <div class="accordion-item active">
                                    <h2 class="accordion-header" id="${headingId}">
                                        <button type="button" class="accordion-button collapsed bg-light border-0 shadow-sm fs-5 fw-semibold text-black"
                                            data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="false" aria-controls="${collapseId}">
                                            <span class="me-2 text-capitalize">
                                                ${currency.currency_name}
                                            </span>
                                            <span class="text-primary fw-bold">
                                                ( ${currency.currency_symbol} )
                                            </span>
                                            <span class="ms-2 text-capitalize">
                                                ${currency.country_name}
                                            </span>
                                        </button>
                                    </h2>
                                    <div id="${collapseId}" class="accordion-collapse collapse" aria-labelledby="${headingId}"
                                        data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <div class="card-body py-1">
                                                <div class="row">
                                                    <input type="hidden" value="${currency.sno}" class="currency_id" name="currency_id[]" />                                                
                                                    <div class="row variants-container"></div>                      
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>`;
                            accordionContainer.append(accordionItem);
                        });
                    } else {
                        accordionContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                    }
                }
            },
            error: function (error) {
                console.log(`Error Fetching Data : ${error}`);
            }
        });
    }
</script>

<!-- Add On Data Fetch -->
<script>
    $(document).ready(function () {
        $.ajax({
            url: '/add_on_data_fetch',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {
                    var products = response.data;
                    const productDropDown = $('#addon_id');
                    productDropDown.empty();
                    productDropDown.append(
                        $('<option></option>').val('').text('Select Add On')
                    );

                    products.forEach(p => {
                        productDropDown.append(
                            $('<option></option>').val(p.sno).text(p.addon_name)
                        );
                    });
                } else {
                    console.log(`Data Cleared.`);
                }
            },
            error: function(error) {
                console.error(`Error Fetching Data: ${error}`);
            }
        });
    });
</script>

<!-- Add On Variant Data Fetch -->
<script>
    function packageVariantDataFetch(id) {
        $.ajax({
            url: `/addon_variant_data_fetch/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {
                    const addons = response.data;
                    const isAccordion = $('.accordion-item');

                    if(isAccordion && isAccordion.length > 0) {
                        isAccordion.each(function () {
                            const $accordionItem = $(this);
                            const currencyId = $accordionItem.find('.currency_id').val();
                            const variantsContainer = $accordionItem.find('.variants-container');

                            variantsContainer.html('');

                            if(addons && addons.length > 0) {
                                addons.forEach(addon => {
                                    const addonItem = `
                                        <label class="d-flex align-items-center my-3 px-3 py-2 fs-5 fw-semibold bg-label-primary rounded">
                                            <span>${addon.varient_name} ( ${addon.variable_name} )</span>
                                            ${addon.free_paid === 0 ? `<span class="ms-auto badge bg-success text-white">Free</span>` : `<span
                                                class="ms-auto badge bg-danger text-white">Paid</span>`}
                                        </label>
                                        <input type="hidden" name="varient_ids[${currencyId}][]" value="${addon.varient_id}" />
                                        <input type="hidden" name="variable_ids[${currencyId}][]" value="${addon.variable_id}" />
                                        <div class="col-lg-4 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">
                                                Amount<span class="text-danger">*</span>
                                            </label>
                                            <input type="text" class="form-control validation_input" name="amounts[${currencyId}][]"
                                                placeholder="Enter Amount"
                                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                                            <div class="validation_err text-danger mt-1 fw-semibold fs-7"></div>
                                        </div>
                                    `;

                                    variantsContainer.append(addonItem);
                                })
                            }
                        });
                    } else {
                        variantsContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center d-block w-100">No Currency Found.</label>');
                    }

                    // INR Update
                    const variantsContainerINR = $('#variants-container-inr');
                    variantsContainerINR.html('');

                    if(addons && addons.length > 0) {
                        addons.forEach(addon => {
                            const addonItemINR = `
                                <label class="d-flex align-items-center my-3 px-3 py-2 fs-5 fw-semibold bg-label-primary rounded">
                                    <span>${addon.varient_name} ( ${addon.variable_name} )</span>
                                    ${addon.free_paid === 0 ? `<span class="ms-auto badge bg-success text-white">Free</span>` : `<span class="ms-auto badge bg-danger text-white">Paid</span>`}
                                </label>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                        data-bs-placement="right" title="Amount">
                                        Amount
                                    </label>
                                    <div class="text-danger fw-semibold d-block fs-5">${addon.amount}</div>
                                </div>
                            `;

                            variantsContainerINR.append(addonItemINR);
                        });
                    }        
                }

                $('#whole-container').show();
                $('#inr-add-block').show();
                $('#create_price_book').show();
            },
            error: function(error) {
                console.log(`Error Fetching Data : ${error}`);
            }
        });
    }

</script>

<!-- Validation and Hide and Show Accordion -->
    <style>
        .input-error {
            border-color: #dc3545 !important;
            /* Bootstrap's danger color */
        }
    </style>

    <script>
        function addValidation() {
                    let isValid = true;
                    
                    $('.validation_err').text('');
                    $('.validation_input').removeClass('input-error');
                    
                    $('.accordion-button')
                        .removeClass('bg-danger bg-opacity-10 text-danger')
                        .addClass('bg-light')
                        .css('border-left', '');

                    $('.validation_input').each(function() {
                        const $input = $(this);
                        const value = $input.val().trim();
                        const $errorElement = $input.closest('.mb-3').find('.validation_err');
                        
                        if(!value) {
                            isValid = false;
                            $input.addClass('input-error');
                            $errorElement.text('This field is required.');
                            
                            $input.closest('.accordion-item')
                                .find('.accordion-button')
                                .removeClass('bg-light')
                                .addClass('bg-danger bg-opacity-10 text-danger')
                                .css('border-left', '3px solid #dc3545');
                        }
                    });

                    // 3. FINAL CHECKS
                    if(isValid) {
                        // Form is valid - ensure all styling is reset
                        $('.accordion-button')
                            .removeClass('bg-danger bg-opacity-10 text-danger')
                            .addClass('bg-light')
                            .css('border-left', '');
                        $('#price_book_form').submit();
                    } else {
                        $('#whole-container').show();
                        $('#inr-add-block').show();
                    }
                    
                    return false;
                }
    </script>
<!-- Validation Ends -->

<!-- Edit Accordion -->
<script>
    function editAccordionDataFetch () {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: '/currency_accordion',
                method: 'GET',
                dataType: 'json',
                success: function (response) {
                    if(response.status === 200) {
                        var data = response.data;
                        const editAccordionContainer = $('#edit-accordion-container');
                        editAccordionContainer.html('');

                        if(data && data.length > 0) {
                            data.forEach((currency, index) => {
                                const headingId = `heading${index}`;
                                const collapseId = `collapse${index}`;

                                const editAccordionItem = `
                                    <div class="accordion-item active edit-accordion">
                                        <h2 class="accordion-header" id="${headingId}">
                                            <button type="button" class="accordion-button collapsed bg-light border-0 shadow-sm fs-5 fw-semibold text-black"
                                                data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="false" aria-controls="${collapseId}">
                                                <span class="me-2 text-capitalize">
                                                    ${currency.currency_name}
                                                </span>
                                                <span class="text-primary fw-bold">
                                                    ( ${currency.currency_symbol} )
                                                </span>
                                                <span class="ms-2 text-capitalize">
                                                    ${currency.country_name}
                                                </span>
                                            </button>
                                        </h2>
                                        <div id="${collapseId}" class="accordion-collapse collapse" aria-labelledby="${headingId}"
                                            data-bs-parent="#editAccordionExample">
                                            <div class="accordion-body">
                                                <div class="card-body py-1">
                                                    <div class="row">
                                                        <input type="hidden" value="${currency.sno}" class="edit-currency_id" name="edit_currency_id[]" />                                                
                                                        <div class="row edit-variants-container"></div>                      
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>`;
                                editAccordionContainer.append(editAccordionItem);
                                resolve();
                            });
                        } else {
                            editAccordionContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                        }
                    }
                },
                error: function (error) {
                    console.log(`Error Fetching Data : ${error}`);
                    reject(error);
                }
            });
        });
    }
</script>

<!-- Edit Data Fetch -->
<script>
    function fetchEditData(id) {
        editAccordionDataFetch().then(() => {
            $.ajax({
                url: `/addon_edit_data/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === 200) {
                        const inrData = response.data; // INR data
                        const currencies = response.currencies; // Currencies data
                        const editIsAccordion = $('.edit-accordion');

                        // Process INR data (unchanged)
                        const editVariantsContainerINR = $('#edit-varient-inr');
                        editVariantsContainerINR.html('');

                        $('#edit-addon-name').html(inrData[0].addon_name);
                        $('#update-btn').html(inrData[0].addon_name);

                        if (inrData && Array.isArray(inrData)) {
                            inrData.forEach(variant => {
                                const editAddonItemINR = `
                                    <label class="d-flex align-items-center my-3 px-3 py-2 fs-5 fw-semibold bg-label-primary rounded">
                                        <span>${variant.varient_name} (${variant.variable_name})</span>
                                        ${variant.free_paid == 0 ? `<span class="ms-auto badge bg-success text-white">Free</span>` : `<span class="ms-auto badge bg-danger text-white">Paid</span>`}
                                    </label>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                            data-bs-placement="right" title="Amount">
                                            Amount
                                        </label>
                                        <div class="text-danger fw-semibold d-block fs-5">${variant.amount}</div>
                                    </div>
                                `;
                                editVariantsContainerINR.append(editAddonItemINR);
                            });
                        }

                        // Process currency accordions
                        if (editIsAccordion && editIsAccordion.length > 0) {
                            editIsAccordion.each(function() {
                                const $accordionItem = $(this);
                                const currencyId = $accordionItem.find('.edit-currency_id').val();
                                const editVariantsContainer = $accordionItem.find('.edit-variants-container');
                                editVariantsContainer.html('');

                                // Find the currency that matches this accordion
                                const currency = currencies.find(c => c.currency_id == currencyId);
                                
                                if (currency) {
                                    try {
                                        // Parse the varient_details JSON string
                                        const varientDetails = JSON.parse(currency.varient_details);
                                        
                                        if (Array.isArray(varientDetails)) {
                                            // Match each variant with the INR data to get names
                                            varientDetails.forEach(variant => {
                                                const inrVariant = inrData.find(v => 
                                                    v.varient_id == variant.variant_id && 
                                                    v.variable_id == variant.variable_id
                                                );
                                                
                                                if (inrVariant) {
                                                    const editVarientElement = `
                                                        <label class="d-flex align-items-center my-3 px-3 py-2 fs-5 fw-semibold bg-label-primary rounded">
                                                            <span>${inrVariant.varient_name} (${inrVariant.variable_name})</span>
                                                            ${inrVariant.free_paid == 0 
                                                                ? `<span class="ms-auto badge bg-success text-white">Free</span>` 
                                                                : `<span class="ms-auto badge bg-danger text-white">Paid</span>`}
                                                        </label>
                                                        <input type="hidden" name="edit_id[${currencyId}]" value="${currency.sno}" />
                                                        <input type="hidden" name="edit_varient_ids[${currencyId}][]" value="${variant.variant_id}" />
                                                        <input type="hidden" name="edit_variable_ids[${currencyId}][]" value="${variant.variable_id}" />
                                                        <div class="col-lg-4 mb-3">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">
                                                                Amount<span class="text-danger">*</span>
                                                            </label>
                                                            <input type="text" class="form-control validation_input_edit" name="edit_amounts[${currencyId}][]" 
                                                                placeholder="Enter Amount" value="${variant.amount || ''}"
                                                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\\d*/, '$1');" />
                                                            <div class="validation_err_edit text-danger mt-1 fw-semibold fs-7"></div>
                                                        </div>`;
                                                    
                                                    editVariantsContainer.append(editVarientElement);
                                                }
                                            });
                                        }
                                    } catch (e) {
                                        console.error('Error parsing varient_details:', e);
                                    }
                                }
                            });
                        }
                    }
                },
                error: function(error) {
                    console.log('Error Fetching Data:', error);
                    alert('Error fetching data. Please try again.');
                }
            });
        });
    }
</script>

<!-- Edit Validation -->
<script>
    function editValidation() {
        let isValid = true;
        
        $('.validation_err_edit').text('');
        $('.validation_input_edit').removeClass('input-error');
        
        $('.accordion-button')
            .removeClass('bg-danger bg-opacity-10 text-danger')
            .addClass('bg-light')
            .css('border-left', '');

        $('.validation_input_edit').each(function() {
            const $input = $(this);
            const value = $input.val().trim();
            const $errorElement = $input.closest('.mb-3').find('.validation_err_edit');
            
            if(!value) {
                isValid = false;
                $input.addClass('input-error');
                $errorElement.text('This field is required.');
                
                $input.closest('.accordion-item')
                    .find('.accordion-button')
                    .removeClass('bg-light')
                    .addClass('bg-danger bg-opacity-10 text-danger')
                    .css('border-left', '3px solid #dc3545');
            }
        });

        // 3. FINAL CHECKS
        if(isValid) {
            // Form is valid - ensure all styling is reset
            $('.accordion-button')
                .removeClass('bg-danger bg-opacity-10 text-danger')
                .addClass('bg-light')
                .css('border-left', '');
                
            $('#edit_price_form').submit();
        } else {
            $('#whole-container').show();
            $('#inr-add-block').show();
        }
        
        return false;
    }
</script>

<!-- View Accordion -->
<script>
    function viewAccordionDataFetch () {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: '/currency_accordion',
                method: 'GET',
                dataType: 'json',
                success: function (response) {
                    if(response.status === 200) {
                        var data = response.data;
                        const editAccordionContainer = $('#view-accordion-container');
                        editAccordionContainer.html('');

                        if(data && data.length > 0) {
                            data.forEach((currency, index) => {
                                const headingId = `heading${index}`;
                                const collapseId = `collapse${index}`;

                                const editAccordionItem = `
                                    <div class="accordion-item active view-accordion">
                                        <h2 class="accordion-header" id="${headingId}">
                                            <button type="button" class="accordion-button collapsed bg-light border-0 shadow-sm fs-5 fw-semibold text-black"
                                                data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="false" aria-controls="${collapseId}">
                                                <span class="me-2 text-capitalize">
                                                    ${currency.currency_name}
                                                </span>
                                                <span class="text-primary fw-bold">
                                                    ( ${currency.currency_symbol} )
                                                </span>
                                                <span class="ms-2 text-capitalize">
                                                    ${currency.country_name}
                                                </span>
                                            </button>
                                        </h2>
                                        <div id="${collapseId}" class="accordion-collapse collapse" aria-labelledby="${headingId}"
                                            data-bs-parent="#viewAccordionExample">
                                            <div class="accordion-body">
                                                <div class="card-body py-1">
                                                    <div class="row">
                                                        <input type="hidden" value="${currency.sno}" class="view-currency_id" />                                                
                                                        <div class="row edit-variants-container"></div>                      
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>`;
                                editAccordionContainer.append(editAccordionItem);
                                resolve();
                            });
                        } else {
                            editAccordionContainer.html('<label class="text-white my-3 px-3 py-2 fs-6 fw-semibold bg-danger text-center rounded d-block w-100">No variants found.</label>');
                        }
                    }
                },
                error: function (error) {
                    console.log(`Error Fetching Data : ${error}`);
                    reject(error);
                }
            });
        });
    }
</script>

<!-- View Data Fetch -->
<script>
    function priceBookView(id) {
        viewAccordionDataFetch().then(() => {
            $.ajax({
                url: `/addon_view_data/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === 200) {
                        const inrData = response.data; // INR data
                        const currencies = response.currencies; // Currencies data
                        const editIsAccordion = $('.view-accordion');

                        // Process INR data (unchanged)
                        const editVariantsContainerINR = $('#view-varient-inr');
                        editVariantsContainerINR.html('');

                        $('#view-addon-name').html(inrData[0].addon_name);

                        if (inrData && Array.isArray(inrData)) {
                            inrData.forEach(variant => {
                                const editAddonItemINR = `
                                    <label class="d-flex align-items-center my-3 px-3 py-2 fs-5 fw-semibold bg-label-primary rounded">
                                        <span>${variant.varient_name} (${variant.variable_name})</span>
                                        ${variant.free_paid == 0 ? `<span class="ms-auto badge bg-success text-white">Free</span>` : `<span class="ms-auto badge bg-danger text-white">Paid</span>`}
                                    </label>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip"
                                            data-bs-placement="right" title="Amount">
                                            Amount
                                        </label>
                                        <div class="text-danger fw-semibold d-block fs-5">${variant.amount}</div>
                                    </div>
                                `;
                                editVariantsContainerINR.append(editAddonItemINR);
                            });
                        }

                        // Process currency accordions
                        if (editIsAccordion && editIsAccordion.length > 0) {
                            editIsAccordion.each(function() {
                                const $accordionItem = $(this);
                                const currencyId = $accordionItem.find('.view-currency_id').val();
                                const viewVariantsContainer = $accordionItem.find('.edit-variants-container');
                                viewVariantsContainer.html('');

                                // Find the currency that matches this accordion
                                const currency = currencies.find(c => c.currency_id == currencyId);
                                
                                if (currency) {
                                    try {
                                        // Parse the varient_details JSON string
                                        const varientDetails = JSON.parse(currency.varient_details);
                                        
                                        if (Array.isArray(varientDetails)) {
                                            // Match each variant with the INR data to get names
                                            varientDetails.forEach(variant => {
                                                const inrVariant = inrData.find(v => 
                                                    v.varient_id == variant.variant_id && 
                                                    v.variable_id == variant.variable_id
                                                );
                                                
                                                if (inrVariant) {
                                                    const viewVarientElement = `
                                                        <label class="d-flex align-items-center my-3 px-3 py-2 fs-5 fw-semibold bg-label-primary rounded">
                                                            <span>${inrVariant.varient_name} (${inrVariant.variable_name})</span>
                                                            ${inrVariant.free_paid == 0 
                                                                ? `<span class="ms-auto badge bg-success text-white">Free</span>` 
                                                                : `<span class="ms-auto badge bg-danger text-white">Paid</span>`}
                                                        </label>
                                                        <div class="col-lg-4 mb-3">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">
                                                                Amount<span class="text-danger">*</span>
                                                            </label>
                                                            <div class="text-danger fw-semibold d-block fs-5">${variant.amount || 0}</div>
                                                        </div>`;
                                                    
                                                    viewVariantsContainer.append(viewVarientElement);
                                                }
                                            });
                                        }
                                    } catch (e) {
                                        console.error('Error parsing varient_details:', e);
                                    }
                                }
                            });
                        }
                    }
                },
                error: function(error) {
                    console.log('Error Fetching Data:', error);
                    alert('Error fetching data. Please try again.');
                }
            });
        });
    }
</script>

<script>
    function open_func(id) {
      var colse_tr_div = document.getElementById("colse_tr_div"+id);
  
      if (colse_tr_div.style.display == "none") {
        document.getElementById("colse_tr_div"+id).style.display = "table-row";
        document.getElementById("plus_btn"+id).classList.remove("mdi-plus");
        document.getElementById("plus_btn"+id).classList.add("mdi-minus");
        document.getElementById("main_tr_div"+id).style.backgroundColor = "#f9f3c5db";
      } else {
        document.getElementById("colse_tr_div"+id).style.display = "none";
        document.getElementById("plus_btn"+id).classList.remove("mdi-minus");
        document.getElementById("plus_btn"+id).classList.add("mdi-plus");
        document.getElementById("main_tr_div"+id).removeAttribute("style");
      }
    }
</script>

@endsection