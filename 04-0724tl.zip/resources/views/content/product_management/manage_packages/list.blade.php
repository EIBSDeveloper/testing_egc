@extends('layouts/layoutMaster')

@section('title', 'Manage Packages')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
<style>
  .dataTables_scroll {
    max-height: 250px;
  }

  .list_page_1 thead th,
  .list_page_1 tbody td {
    padding: 7px !important;
  }

  .package_table thead th,
  .package_table tbody td {
    padding: 10px !important;
  }

  .indv_package thead th,
  .indv_package tbody td {
    padding: 8px !important;
    border: 1px solid rgb(180, 180, 180) !important;
  }
</style>
@section('content')
<!-- Users List Table -->
<div class="card card-action">
@php
    $helper = new \App\Helpers\Helpers();
    $module_name = 'Product Management';
    $menu_name   = 'Manage Packages';
@endphp
  <div class="card-header border-bottom pb-1">
    <div class="card-action-title">
      <h5 class="card-title mb-1">Manage Packages</h5>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
          </li>
          <span class="text-dark opacity-75 me-1 ms-1">
            <i class="mdi mdi-arrow-right-thin fs-4"></i>
          </span>
          <li class="breadcrumb-item">
            <a href="javascript:;" class="d-flex align-items-center">Product Management</a>
          </li>
        </ol>
      </nav>
    </div>
    <div class="card-action-element">
      
      <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
        @if(auth()->user()->hasPermission($module_name, 'Filter', $menu_name))
        {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="filter" title="Filter">
          <span><i class="mdi mdi-filter-outline text-center text-center"></i></span>
        </a>        --}}
        @endif
        @if(auth()->user()->hasPermission($module_name, 'Add', $menu_name))
        <a href="{{url('/manage_package/package_add')}}" class="btn btn-sm fw-bold btn-primary text-white">
          <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Packages
        </a>
        @endif
      </div>
    </div>
  </div>
  <div class="card-body">
    <div class="filter_tbox" style="display: none;">
      <div class="row py-1">
        <div class="col-lg-3 mb-2">
          <label class="text-black mb-1 fs-6 fw-semibold">Product Category</label>
          <select class="select3 form-select">
            <option value="">All</option>
            <option value="1">Reasearch Products</option>
            <option value="2">PHD Products</option>
            <option value="3">Writing Products</option>
            <option value="4">Development Products</option>
            <option value="5">Analysis Products</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2">
          <label class="text-black mb-1 fs-6 fw-semibold">Products</label>
          <input type="text" class="form-control" placeholder="Enter Product" />
        </div>
        <div class="col-lg-3 mb-2">
          <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
          <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
            <option value="all">All</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="monthly">This Month</option>
            <option value="custom_date">Custom Date</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">Today</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="course_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">Start Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="course_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">End Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="course_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">This Month</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="ovr_month_fill" placeholder="Select Date" class="form-control" value="<?php echo date("M-Y"); ?>" />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">From Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="course_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
          <label class="text-black mb-1 fs-6 fw-semibold">To Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="course_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
          </div>
        </div>
      </div>
      <div class="d-flex align-items-center justify-content-end mb-2">
        <a href="javascript:;" class="btn btn-sm fw-bold btn-secondary me-2">Reset</a>
        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary">Go</a>
      </div>
    </div>
    @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
      <div class="row">
        <div class="row mb-4">
          @php $perpage_count = $perpage ? $perpage : 10; @endphp
          <div class="col-lg-2">
              <span>Show</span>
              <br>
              <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                  @php
                  $options = [10, 25, 100, 500]; // Define available options
                  @endphp
                  @php foreach ($options as $option): @endphp
                  <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                      @php echo $option; @endphp
                  </option>
                  @php endforeach; @endphp
              </select>
          </div>
          <div class="col-lg-10 d-flex align-items-end justify-content-end">
              <form id="search_form" method="POST" action="/manage_package">
                  @csrf
                <div class="d-flex align-items-center gap-2 mt-2">
                  <div>
                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                    <input type="hidden" name="filter_on" value="1">
                    <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                    <input
                      type="text"
                      class="form-control"
                      id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                      placeholder="Enter Search"
                    />
                  </div>
                  <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                </div>
              </form>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="table-responsive">
            <table class="table align-middle table-row-dashed gy-0 gs-1 package_table">
              <thead>
                <tr class="text-start align-middle fw-bold fs-6 gs-0 bg-primary">
                  <th class="min-w-150px">Packages</th>
                  <th class="min-w-80px">Duration</th>
                  <th class="min-w-80px">Base Price</th>
                  <th class="min-w-100px">Min. / Max. Price</th>
                  <th class="min-w-80px text-center">Products</th>
                  <th class="min-w-100px">Add-on</th>
                  <th class="min-w-80px">Status</th>
                  <th class="min-w-100px text-center">Action</th>
                </tr>
              </thead>
              <tbody class="text-black fw-semibold fs-7">
                @if (isset($ListTable))
                  @foreach ($ListTable as $i=> $list)
                  @php
                    $get_product_list = $helper->get_package_product_data($list->sno);
                    $get_product_list_count = count($get_product_list);
                  @endphp
                  <tr id="main_tr_div{{$i}}">
                    <td>
                      <div class="d-flex align-items-center">
                        <div class="me-2 cursor-pointer">
                          <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" onclick="open_func({{$i}});">
                            <i class="mdi mdi-plus fs-4" id="plus_btn{{$i}}"></i>
                          </a>
                        </div>
                        <div class="mb-0">
                          <label class="text-truncate max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$list->package_name}}">{{$list->package_name}}</label>
                        </div>
                      </div>
                    </td>
                    <td>
                      <label class="badge bg-warning rounded text-black text-black fs-7 fw-semibold text-truncate max-w-100px"><span class="" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$list->actual_duration}}">{{$list->actual_duration}}</span></label>
                    </td>
                    <td align="right">
                      <label class="text-black text-black fs-7 fw-semibold">&#8377; {{ number_format($list->base_price) }}</label>
                    </td>
                    <td>
                      <label class="badge bg-success text-black fs-7 fw-semibold mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Minimum Price">&#8377; {{ number_format($list->min_amount) }}</label>
                      <label class="text-black fs-7 fw-semibold ms-1 me-1">|</label>
                      <label class="badge bg-danger text-white fs-7 fw-semibold mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Maximum Price">&#8377; {{ number_format($list->max_amount) }}</label>
                    </td>
                    <td class="text-center">
                      <label class="badge bg-secondary rounded-pill text-white fs-7 fw-semibold">{{$get_product_list_count}}</label>
                    </td>
                    <td>
                      @php
                          $package_add_on = $helper->get_package_add_on_counts($list->sno);
                          $free = $package_add_on['free'];
                          $paid = $package_add_on['paid'];
                      @endphp
                      @if ($free > 0 || $paid > 0)
                        <label class="text-black fs-7 fw-semibold mb-1">
                          <span>Free</span>
                          <span>-</span>
                          <span class="badge bg-info rounded-circle fs-7">{{$free}}</span>
                        </label>
                        <div class="d-block">
                          <label class="text-black fs-7 fw-semibold">
                            <span>Paid</span>
                            <span>-</span>
                            <span class="badge bg-danger text-white rounded-circle fs-7">{{$paid}}</span>
                          </label>
                        </div>
                        @else
                        -
                      @endif
                    </td>
                    <td>
                      <label class="switch switch-square">
                          <input type="checkbox"  class="switch-input" {{ $list->status == 0 ? 'checked' : '' }} onchange="SwitchStatus('{{ $list->sno }}', this.checked)" />
                          <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                          </span>
                        </label>
                    </td>
                    <td align="center">
                       @php
                                  
                          $encryptedValue = $helper->encrypt_decrypt($list->sno,'encrypt');
                          $edit_url = url('/manage_package/package_edit/' . $encryptedValue);
                      @endphp
                      <span class="text-end">
                        <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                          @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                          <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_packages" onclick="Viewmodel('{{ $list->sno }}')">
                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                          @endif
                          @if(auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                          <a href="{{$edit_url}}" class="dropdown-item">
                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                          </a>
                          @endif
                          @if(auth()->user()->hasPermission($module_name, 'Delete', $menu_name))
                            <a href="#" class="dropdown-item"  onclick="confirmDelete('{{ $list->sno }}','{{ $list->package_name }}','{{ $list->actual_duration??'' }}')" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_packages">
                              <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                                <i class="mdi mdi-delete-outline fs-3 text-black"></i>Delete
                              </span>
                            </a>
                          @endif
                        </div>
                      </span>
                    </td>
                  </tr>
                    
                  <tr id="colse_tr_div{{$i}}" style="display:none;background-color: #EFFFDD;">
                    <td colspan="8">
                      <div class="table-responsive">
                        <table class="table align-top gy-1 gs-2 indv_package">
                          <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0">
                              <th class="min-w-200px fw-semibold text-black">Products</th>
                              <th class="min-w-80px fw-semibold text-black text-center">Durations</th>
                              <th class="min-w-100px fw-semibold text-black text-center">Product Price</th>
                              <th class="min-w-80px fw-semibold text-black text-center">Variant</th>
                              <th class="min-w-100px fw-semibold text-black text-center">Variant Price</th>
                              <th class="min-w-100px fw-semibold text-black text-center">Total Price</th>
                            </tr>
                          </thead>
                          <tbody class="text-gray-600 fw-semibold fs-7">
                            @foreach ($get_product_list as $pi=> $plist)
                            <tr>
                              <td>
                                <label class="text-truncate max-w-150px fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$plist->product_name}}">{{$plist->product_name}}</label>
                                <div class="d-block">
                                  <label class="text-truncate text-dark max-w-150px fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$plist->product_category_name}}">{{$plist->product_category_name}}</label>
                                </div>
                              </td>
                              <td align="center">
                                <label class="badge bg-warning text-black rounded fw-semibold fs-8">{{$plist->product_duration ?? '-' }}</label>
                              </td>
                              <td align="right">
                                <label class="text-black fw-semibold fs-7">&#8377; {{ number_format($plist->product_amount) }}</label>
                              </td>
                             
                              <td align="center">
                                 @php
                                    $variant_variable_ids = json_decode($plist->variant_variable_ids ?? '[]', true);
                                    $variant_variable_ids = is_array($variant_variable_ids) ? $variant_variable_ids : [];
                                    $variant_variable_count = count($variant_variable_ids);
                                    $totalAmount = 0;
                                    foreach ($variant_variable_ids as $item) {
                                        $totalAmount += isset($item['amount']) ? (float)$item['amount'] : 0;
                                    }
                                @endphp
                                <label class="badge bg-info text-white rounded-circle fw-semibold fs-8">{{$variant_variable_count}}</label>
                              </td>
                              <td align="right">
                                <label class="text-black fw-semibold fs-7">&#8377; {{number_format($totalAmount)}}</label>
                              </td>
                              <td align="right">
                                @php
                                  $grand_total =  $plist->product_amount + $totalAmount;
                                @endphp
                                <label class="text-black fw-semibold fs-7">&#8377; {{number_format($grand_total)}}</label>
                              </td>
                            </tr>
                             @endforeach
                          </tbody>
                        </table>
                      </div>
                    </td>
                  </tr>
                  @endforeach
                @endif
              </tbody>
            </table>
            <div class="mt-4">
                {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
            </div>
          </div>
        </div>
      </div>
    @endif
  </div>
</div>


<!--begin::Modal - View Packages-->
<div class="modal fade" id="kt_modal_view_packages" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8">
          <h3 class="mb-4 text-black text-center">View Packages</h3>
        </div>
        <div class="row" id="view_package_div">

        </div>
        <div class="d-flex align-items-center justify-content-end mb-1 gap-5">
          <label class="fw-bold fs-3 me-13">Grand Total</label>
          <div class="fw-bold fs-1">&#8377; <span id="total_grand_amount">0</span></div>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - View Packages-->

<!--begin::Modal - Delete Packages-->
<div class="modal fade" id="kt_modal_delete_packages" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Packages ?
        <div class="d-block text-black fw-semibold fs-5 mt-3 py-2">
          <label id="del_product">-</label>
          <span class="ms-2 me-2">-</span>
          <label id="del_category">-</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" onclick="delete_confirm()">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Packages-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

   <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
   <style>
       /* Customize Toastr container */
       .toast {
           background-color: #39484f;
       }

       /* Customize Toastr notification */
       .toast-success {
           background-color: green;
       }

       /* Customize Toastr notification */
       .toast-error {
           background-color: red;
       }
       .err_msg{
        /* background-color: red; */
        border-color: red;
       }

   </style>
   <script>
       // Display Toastr messages
       @if (Session::has('toastr'))
           var type = "{{ Session::get('toastr')['type'] }}";
           var message = "{{ Session::get('toastr')['message'] }}";
           toastr[type](message);
       @endif
   </script>
    <script>
      function sort_filter(val) {
          if (val != "") {
          $('.sorting_filter_class').val(val);
          $('#search_form').submit();
          } else {
          $('.sorting_filter_class').val(10);
          $('#search_form').submit();
          }
      }
    </script>
    <script>
    function Viewmodel(id) {
            fetch('/package_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        // console.log(data.data);
                        var com = data.data;
                        $('#view_package_div').empty().html(com);
                        $('#total_grand_amount').empty().html(data.total_grand_amount);
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        // console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    // console.error('Error:', error);
              });
             
        }
    </script>

<script>
    function SwitchStatus(UniversityId, isChecked) {
        const status = isChecked ? 0 : 1; // Set status based on checkbox state

        fetch(`/package_status/${UniversityId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    console.log('Package Status updated successfully:', data.message);
                    toastr.success('Package Status Updated successfully!');
                } else {
                    console.error('Error updating Package Status:', data.message);
                    toastr.error('Error updating Package Status');
                }
            })
            .catch(error => {
                console.error('Error updating Package status:', error);
            });
    }
</script>
<script>
      function confirmDelete(sno, name,cat) {
        document.querySelector('#kt_modal_delete_packages .btn-danger').setAttribute('data-id', sno);
        $('#del_product').html(name);
        $('#del_category').html('('+cat+')');
    }
    </script>
    <script>

    function delete_confirm() {

        var delete_id = document.querySelector('#kt_modal_delete_packages .btn-danger').getAttribute('data-id');

        fetch('/package_delete/' + delete_id, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Package Deleted successfully!');
                    location.reload();

                } else {

                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
    </script>

<script>
  function open_func(id) {
    var colse_tr_div = document.getElementById("colse_tr_div"+id);

    if (colse_tr_div.style.display == "none") {
      document.getElementById("colse_tr_div"+id).style.display = "table-row";
      document.getElementById("plus_btn"+id).classList.remove("mdi-plus");
      document.getElementById("plus_btn"+id).classList.add("mdi-minus");
      document.getElementById("main_tr_div"+id).style.backgroundColor = "#f9f3c5db";
    } else {
      document.getElementById("colse_tr_div"+id).style.display = "none";
      document.getElementById("plus_btn"+id).classList.remove("mdi-minus");
      document.getElementById("plus_btn"+id).classList.add("mdi-plus");
      document.getElementById("main_tr_div"+id).removeAttribute("style");
    }
  }
</script>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    const maxChars = 50;
    const elements = document.querySelectorAll('.facility_txt');

    elements.forEach(el => {
      const fullText = el.textContent.trim();
      el.setAttribute('title', fullText);
      if (fullText.length > maxChars) {
        el.textContent = fullText.slice(0, maxChars) + '...';
      }
      bootstrap.Tooltip.getOrCreateInstance(el);
    });
  });
</script>
<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });


  $(".list_page_1").DataTable({
    "ordering": false,
    "paging": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
  // $('.list_page_1').wrap('<div class="dataTables_scroll" />');
</script>
<script>
  $('#filter').click(function() {
    $('.filter_tbox').slideToggle('slow');
  });
</script>
<script>
  function date_fill_issue_rpt() {
    var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
    var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
    var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
    var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
    var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
    var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
    var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
    var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
    var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

    if (dt_fill_issue_rpt == "today") {
      today_dt_iss_rpt.style.display = "block";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else if (dt_fill_issue_rpt == "week") {
      today_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "block";
      week_to_dt_iss_rpt.style.display = "block";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";

      var curr = new Date; // get current date
      var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
      var last = first + 6; // last day is the first day + 6

      var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
      firstday = firstday.split("-").reverse().join("-");
      var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
      lastday = lastday.split("-").reverse().join("-");
      $('#week_from_date_fil').val(firstday);
      $('#week_to_date_fil').val(lastday);

    } else if (dt_fill_issue_rpt == "monthly") {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "block";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else if (dt_fill_issue_rpt == "custom_date") {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "block";
      to_dt_iss_rpt.style.display = "block";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    }
  }
</script>
@endsection