@extends('layouts/layoutMaster')

@section('title', 'Update Packages')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
<style>
  .dataTables_scroll {
    max-height: 300px;
  }

  .list_page_1 thead th,
  .list_page_1 tbody td {
    padding: 7px !important;
  }

  .select2-selection__choice {
    text-wrap: wrap !important;
  }
  .bg-label-success_card {
    background-color: rgb(139, 234, 182) !important;
    color: #50cd89 !important;
}

.bg-label-success_card:hover {
    background-color: rgb(139, 234, 182) !important;
    color: #50cd89 !important;
}

</style>
@section('content')
<!-- Users List Table -->
@php
    $helper = new \App\Helpers\Helpers();
@endphp
<div class="card">
  <div class="card-header border-bottom pb-1">
    <h5 class="card-title mb-1">Update Packages</h5>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
        </li>
        <span class="text-dark opacity-75 me-1 ms-1">
          <i class="mdi mdi-arrow-right-thin fs-4"></i>
        </span>
        <li class="breadcrumb-item">
          <a href="javascript:;" class="d-flex align-items-center">Product Management</a>
        </li>
        <span class="text-dark opacity-75 me-1 ms-1">
          <i class="mdi mdi-arrow-right-thin fs-4"></i>
        </span>
        <li class="breadcrumb-item">
          <a href="javascript:;" class="d-flex align-items-center">Manage Packages</a>
        </li>
      </ol>
    </nav>
  </div>
  <div class="card-body">
    <form method="POST" action="{{ route('update_package') }}" id="add_form">
       @csrf
      <div class="row mb-3">
        <input type="hidden" name="Inserted_id" id="Inserted_id" value="{{$Inserted_id}}">
        <input type="hidden" name="over_all_total_amount" id="over_all_total_amount">
        <input type="hidden" name="grant_total_amount" id="grant_total_amount">
        <input type="hidden" name="overall_total_Duration" id="overall_total_Duration">
        <div class="col-lg-3 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Package Name<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Package Name" maxlength="180" id="package_name" name="package_name" value="{{$package_data->package_name}}" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"/>
          <div class="error_msg text-danger" id="package_name_err"></div>
        </div>
        <div class="col-lg-3 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Base Price<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Base Price" maxlength="10" id="base_price" name="base_price" value="{{$package_data->base_price}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
          <div class="error_msg text-danger"></div>
        </div>
        <div class="col-lg-3 text-center mb-3">
          <label class="text-dark mb-1 fs-6 fw-semibold">Actual Price</label>
          <div class="d-block">
            <label class="badge bg-success rounded fs-5 fw-semibold text-white">&#8377; <span class="over_all_total">{{number_format($package_data->actual_amount)}}</span></label>
          </div>
        </div>
        <div class="col-lg-3 text-center mb-3">
          <label class="text-dark mb-1 fs-6 fw-semibold">Durations</label>
          <div class="d-block">
            <label class="badge bg-warning rounded fs-5 fw-semibold text-black text-truncate max-w-75" ><span class="overall_totalDuration text_truncate_class" data-bs-placement="bottom">{{$package_data->actual_duration}}</span></label>
          </div>
        </div>
        <div class="col-lg-3 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Min. Amount<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Min. Amount" maxlength="10" id="min_amount" name="min_amount" value="{{$package_data->min_amount}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
          <div class="error_msg text-danger"></div>
        </div>
        <div class="col-lg-3 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Max. Amount<span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Enter Max. Amount" maxlength="10" id="max_amount" name="max_amount" value="{{$package_data->max_amount}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
          <div class="error_msg text-danger"></div>
        </div>
        <div class="col-lg-6 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
          <textarea class="form-control" rows="1" placeholder="Enter Description" maxlength="250" id="pack_desc" name="pack_desc">{{$package_data->package_desc}}</textarea>
        </div>
      </div>
      <div class="divider mt-1 mb-1">
        <div class="divider-text mb-0 text-black fw-semibold fs-3">Products Details</div>
      </div>
      <div class="row">
        <div class="col-lg-12 mb-3">
          <div class="nav-align-top mb-2">
            <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
              <div class="scroll-container-wrapper">
                <button type="button" class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                <div class="scroll-container" id="scrollContainer">
                  @foreach ($Product_cat_list as $inx => $cat_list)
                    <div class="item">
                      <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                        <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 @if($inx==0) active @endif" role="tab" data-bs-toggle="tab" data-bs-target="#tab_cate_{{$inx}}" aria-controls="tab_cate_1" aria-selected="false">
                          <span class="ms-2">{{$cat_list->product_category_name}}</span>
                          <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ str_pad($cat_list->product_count??0, 2, '0', STR_PAD_LEFT)??'0' }}</span>
                        </button>
                      </li>
                    </div>
                  @endforeach
                </div>
                <button type="button" class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
              </div>
            </ul>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-8 mb-1">
          @foreach ($Product_cat_list as $inx2 => $cat_list)
            <div class="tab-content p-0">
              <div class="tab-pane fade @if($inx2==0) show active @endif" id="tab_cate_{{$inx2}}" role="tabpanel">
                <div class="scroll-y border-gray-200i rounded max-h-300px  px-3 py-3">
                  <div class="row">
                    @php
                    $get_product_list = $helper->get_category_based_products($cat_list->sno,$Branch_id);
                    @endphp
                    @if (isset($get_product_list) && $get_product_list->isNotEmpty())
                      @foreach ($get_product_list as $pr_inx => $prd_list)
                        <div class="col-lg-4 mb-3">
                          <div class="card h-100 chse_me_card_btt rounded" id="card_color_{{$prd_list->sno}}">
                            <div class="card-body px-3 py-3">
                              <div class="d-flex align-items-center h-35px mb-2">
                                <div class="me-2 cursor-pointer">
                                  <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product">
                                    <i class="mdi mdi-book-settings-outline fs-4"></i>
                                  </div>
                                </div>
                                <div class="mb-0">
                                  <div class="text-black fs-7 fw-semibold text_truncate_class text-wrap"  data-bs-placement="bottom" >{{$prd_list->product_name}}</div>
                                </div>
                              </div>
                              <div class="d-flex align-items-center mb-2">
                                <div class="me-2 cursor-pointer">
                                  <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations & Facility">
                                    <i class="mdi mdi-calendar-today-outline fs-4"></i>
                                  </div>
                                </div>
                                <div class="d-block mb-0">
                                  <label class="cursor-pointer text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations">
                                    {{$prd_list->duration}} 
                                    @switch($prd_list->duration_in)
                                        @case(0)
                                            Minute
                                            @break
                                        @case(1)
                                            Hour
                                            @break
                                        @case(2)
                                            Days
                                            @break
                                    @endswitch
                                  </label>
                                  <label class="text-dark fs-6 fw-bold ms-1 me-1">|</label>
                                  @php
                                    $facilities = json_decode($prd_list->facility_ids ?? '[]', true);
                                    $facilities = is_array($facilities) ? $facilities : [];
                                    $fac_count  = count($facilities);
                                  @endphp
                                  <label class="cursor-pointer text-dark fs-6 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span class="text-black fs-7 fw-semibold me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facility">{{ str_pad($fac_count??0, 2, '0', STR_PAD_LEFT)??'0' }}</span>
                                    <span class="fs-8 text-info"><u>View Info</u></span>
                                  </label>
                                  <div class="dropdown-menu dropdown-menu-start w-350px">
                                    <div class="text-dark fs-6 text-center my-2 fw-semibold">Facility</div>
                                    <hr class="mt-0 mb-2 border-dark">
                                    <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                    @foreach ($facilities as $FSNO)
                                      @php $fac_data = $helper->get_product_facility($FSNO); @endphp
                                      @if ($fac_data)
                                        <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                          <label class="text-info fw-semibold fs-7 me-2">#</label>
                                          <label class="text-black fw-semibold text-justify fs-7">{{ $fac_data->facility_name }}</label>
                                        </div>
                                      @endif
                                    @endforeach

                                    </div>
                                  </div>
                                </div>
                              </div>
                              @php
                                  $tool_name = [];
                                  $tools_view_name = '';
                                  $Tools = json_decode($prd_list->tools_ids ?? '[]', true);
                                  $Tools = is_array($Tools) ? $Tools : [];
                                  foreach ($Tools as $Tlist) {
                                      $tools_data = $helper->get_tools_by_id($Tlist);
                                      if ($tools_data) {
                                          $name = $tools_data->product_tools_name ?? '';
                                          $tool_name[] = trim($name, ',');
                                      }
                                  }
                                  if (!empty($tool_name)) {
                                      $tools_view_name = implode(', ', $tool_name);
                                  }
                              @endphp
                              <div class="d-flex align-items-center h-35px mb-4">
                                <div class="me-2 cursor-pointer">
                                    <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tools">
                                        <i class="mdi mdi-tools fs-4"></i>
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <div class="text-black fs-7 fw-semibold text_truncate_class"  data-bs-placement="bottom" > {{ $tools_view_name ? $tools_view_name: '-' }}</div>
                                </div>
                              </div>

                              
                              <div class="d-flex align-items-center justify-content-center mb-2">
                                <div class="text-white fs-3 fw-bold rounded px-2 py-1" style="background: #833AB4; background: linear-gradient(90deg,rgba(131, 58, 180, 0.87) 40%, rgba(253, 29, 29, 0.81) 100%, rgba(252, 176, 69, 1) 100%);">&#8377; {{number_format($prd_list->base_price)}}</div>
                              </div>
                              <div class="mb-1 chse_me_btt" id="choose_me_button{{$prd_list->sno}}">
                                <a href="javascript:;" class="d-block btn btn-sm btn-primary fw-semibold chse_me_btta" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_{{$prd_list->sno}}">Choose me</a>
                              </div>
                              <!--begin::Modal - Add Product-->
                                <input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_{{$prd_list->sno}}" id="kt_modal_choose_me_triger{{$prd_list->sno}}">
                                <div class="modal fade" id="kt_modal_choose_me_{{$prd_list->sno}}" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                                  <!--begin::Modal dialog-->
                                  <div class="modal-dialog modal-lg">
                                    <!--begin::Modal content-->
                                    <div class="modal-content rounded">
                                      <!--begin::Modal header-->
                                      <div class="modal-header justify-content-end border-0 pb-0">
                                        <!--begin::Close-->
                                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal"  >
                                          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                          <span class="svg-icon svg-icon-1">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                            </svg>
                                          </span>
                                          <!--end::Svg Icon-->
                                        </div>
                                        <!--end::Close-->
                                      </div>
                                      <!--end::Modal header-->
                                      <!--begin::Modal body-->
                                      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                                        <!--begin::Heading-->
                                        <div class="mb-8 text-center">
                                          <h3 class="text-center mb-4 text-black" id="add_product_label_{{$prd_list->sno}}">Add Product</h3>
                                        </div>
                                        <div class="row mb-4">
                                          <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                                          <label class="col-1 text-black fs-6 fw-bold">:</label>
                                          <div class="col-8 text-black fs-6 fw-bold">{{$prd_list->product_name}}</div>
                                        </div>
                                        <div class="row mb-4">
                                          <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                                          <label class="col-1 text-black fs-6 fw-bold">:</label>
                                          <div class="col-8 text-black fs-6 fw-bold">{{$cat_list->product_category_name}}</div>
                                        </div>
                                        <div class="row mb-4">
                                          <label class="col-3 text-dark fs-6 fw-semibold">Base Price</label>
                                          <label class="col-1 text-black fs-6 fw-bold">:</label>
                                          <div class="col-8 text-black fs-6 fw-bold"><span class="badge bg-success px-2 py-2">{{number_format($prd_list->base_price)}}</span></div>
                                        </div>
                                        <div class="divider mt-1 mb-1">
                                          <div class="divider-text mb-0 text-black fw-semibold fs-3">Variants Details</div>
                                        </div>
                                        {{-- <form id="product_add_form_{{$prd_list->sno}}"> --}}
                                          <input type="hidden" name="Inserted_id_product" id="Inserted_id_product" value="{{$Inserted_id}}">
                                          <div class="row">
                                            <div class="col-lg-12 mb-1">
                                              <div class="bg-gray-200i rounded">
                                                <div class="scroll-y max-h-400px py-2 px-3">
                                                  <div class="row">
                                                    <div class="col-lg-12 mb-1">
                                                      <input type="hidden" name="product_id" id="product_id" value="{{$prd_list->sno}}">
                                                      <input type="hidden" name="product_amount" id="product_amount" value="{{$prd_list->base_price}}">
                                                      @php
                                                        $get_variant_data = $helper->get_variant_data_product($prd_list->sno);
                                                      @endphp
                                                      @if (isset($get_variant_data) && $get_variant_data->isNotEmpty())
                                                      @foreach ($get_variant_data as $vrn_inx => $vrn_list)
                                                        <div class="px-3 pt-1">
                                                          <div class="form-check form-check-inline mb-1 mt-1">
                                                            <input class="form-check-input" type="checkbox" id="variant_check_box_{{$vrn_list->sno}}" onclick="variant_check_func({{$vrn_list->sno}});" />
                                                            <label class="text-black mb-1 fs-6 text-justify fw-semibold">{{$vrn_list->product_variant_name}}</label>
                                                          </div>
                                                          <div id="variant_check_div_{{$vrn_list->sno}}" style="display: none;">
                                                            <div class="row mt-2">
                                                            @php
                                                              $get_variable_data = $helper->get_variable_by_variant($vrn_list->sno);
                                                            @endphp
                                                            @foreach ($get_variable_data as $vr_inx => $vr_list)
                                                              <div class="col-lg-4 mb-1">
                                                                <div class="form-check">
                                                                  <input class="form-check-input me-0 variable_radio_{{$vrn_list->sno}}" type="radio" name="variable_radio_[{{$vrn_list->sno}}]" value="{{$vr_list->sno}}" data-amount="{{$vr_list->variable_amount}}" disabled />
                                                                  <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                    <span>{{$vr_list->variable_name}}</span>
                                                                    <span class="ms-1 me-1">-</span>
                                                                    <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; {{ number_format($vr_list->variable_amount) }}</span>
                                                                  </label>
                                                                </div>
                                                              </div>
                                                            @endforeach
                                                            </div>
                                                            <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                                          </div>
                                                        </div>
                                                      @endforeach
                                                      @else
                                                      <label class="row text-center">
                                                        <span class="text-danger fs-5">No Variant found for this <b class="text-black"> {{$prd_list->product_name}} </b> Product</span>
                                                      </label>
                                                      @endif
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                          <div class="d-flex justify-content-center align-items-center mt-8">
                                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                            <button type="button" class="btn btn-primary" onclick="add_product({{$prd_list->sno}},{{$prd_list->base_price}})" id="add_product_button_{{$prd_list->sno}}">Add Product</button>
                                          </div>
                                        {{-- </form> --}}
                                      </div>
                                      <!--end::Modal body-->
                                    </div>
                                    <!--end::Modal content-->
                                  </div>
                                  <!--end::Modal dialog-->
                                </div>
                              <!--end::Modal - Add Product-->
                            </div>
                          </div>
                        </div>
                      @endforeach
                    @else
                    <label class="row text-center">
                      <span class="text-danger fs-5">No products found for this <b class="text-black"> {{$cat_list->product_category_name}} </b> category</span>
                    </label>
                    @endif
                  </div>
                </div>
              </div>
            </div>
          @endforeach
        </div>
        <div class="col-lg-4 mb-1">
          <div class="card h-100 rounded">
            <div class="scroll-y max-h-300px px-2 py-1">
              <div class="card-body px-1 py-1">
                <div class="row">
                  <div class="col-lg-12 px-1">
                    <div id="selected_product_list_div">
                    </div>                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="d-flex justify-content-end align-items-end me-2 ms-6">
        <span class="text-danger text-end row fw-bold fs-5" id="over_all_total_lab"></span>
      </div>
      @php
          $package_add_on = $helper->get_package_add_on_counts($Inserted_id);
          $free = $package_add_on['free'];
          $paid = $package_add_on['paid'];
      @endphp
      
      <div class="d-flex align-items-center mt-4 mb-1" >
          <div class="form-check form-check-inline">
              <input class="form-check-input w-25px h-25px" type="checkbox" id="prod_add_on" name="prod_add_on" onclick="product_add_on_func();"  value="1" @if ($free > 0 || $paid > 0) checked @endif  />
              <label class="text-black mb-1 fs-5 fw-semibold">Add-on Products</label>
              <label class="text-black mb-1 fs-5 fw-bold me-1 ms-1">-</label>
              <label class="badge bg-info mb-1 fw-semibold fs-5" >&#8377; <span id="addon_total_amount">0</span></label>
              <input type="hidden" name="addon_total_amount_value" id="addon_total_amount_value">
          </div>
      </div>
      <div class="mb-4" id="view_product_add_on" style="display:block;">
          <div class="row">
              <div class="col-lg-12 mb-1">
                  <div class="bg-label-warning rounded pb-4 pt-4">
                      <div class="scroll-y max-h-275px px-3 py-0">
                          <div class="row">
                              <div class="col-lg-12 mb-1">
                                  @if(isset($addOnProductList))
                                  @foreach($addOnProductList as $idxAdn => $add_on)
                                  @php
                                    $get_package_addon_data = $helper->get_package_addon_by_id($add_on->sno,$Inserted_id);
                                  @endphp
                                  <div class="px-3 pt-1">
                                      <div class="form-check form-check-inline mb-1 mt-1">
                                          <input class="form-check-input add_on_product" @if(isset($get_package_addon_data) && $get_package_addon_data->addon_id == $add_on->sno) checked @endif  type="checkbox" name="addOn_chk[{{$add_on->sno}}]" id="addOn_chk_{{$add_on->sno}}" value="{{$add_on->sno}}"/>
                                          <input class="" type="hidden" name="old_add_on_ids[{{$add_on->sno}}]" id="old_add_on_ids_{{$add_on->sno}}" value="@if(isset($get_package_addon_data) && $get_package_addon_data->addon_id == $add_on->sno) {{$get_package_addon_data->sno}} @else 0  @endif"/>
                                          <label class="text-black mb-1 fs-6 text-justify fw-semibold">{{ $add_on->addon_name ?? '-'}}</label>
                                      </div>
                                      <div class="row mt-2">
                                          @if(isset($add_on->add_varients))
                                          @foreach($add_on->add_varients as $idxvarient => $varient)
                                          @if($varient->free_paid == 0)
                                          <div class="col-lg-4 mb-1">
                                              <div class="form-check">
                                                  <input 
                                                    class="form-check-input me-0 add_on_varient" 
                                                    type="radio" 
                                                    value="{{ $varient->sno }}"  
                                                    name="addOn_varient_{{ $add_on->sno }}" 
                                                    id="addOn_varient_{{ $varient->sno }}"

                                                    @if(isset($get_package_addon_data) && $get_package_addon_data->addon_id != $add_on->sno)
                                                        disabled
                                                    @endif

                                                    @if(isset($get_package_addon_data) && $get_package_addon_data->addon_variant_id == $varient->sno)
                                                        checked
                                                    @endif
                                                />

                                                  <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                      <span>{{$varient->addon_variablename}}</span>
                                                      <span class="ms-1 me-1">-</span>
                                                      <span class="badge bg-label-success rounded fw-semibold fs-7">&#8377;<span> <strike>{{ number_format($varient->amount) }} </strike></span></span>    
                                                      <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                  </label>
                                                  <input type="hidden" name="addon_amount[{{$varient->sno}}]"  class="addon_amount" id="addon_amount" value="0" >
                                                  <input type="hidden" name="addon_amount_free[{{$varient->sno}}]"  id="addon_amount_free" value="{{$varient->amount}}" >
                                                  <input type="hidden" name="free_paid[{{$varient->sno}}]"  class="" id="free_paid" value="0" >
                                              </div>
                                          </div>
                                          @else
                                          <div class="col-lg-4 mb-1">
                                              <div class="form-check">
                                                   <input 
                                                    class="form-check-input me-0 add_on_varient" 
                                                    type="radio" 
                                                    value="{{ $varient->sno }}"  
                                                    name="addOn_varient_{{ $add_on->sno }}" 
                                                    id="addOn_varient_{{ $varient->sno }}"

                                                    @if(isset($get_package_addon_data) && $get_package_addon_data->addon_id != $add_on->sno)
                                                        disabled
                                                    @endif

                                                    @if(isset($get_package_addon_data) && $get_package_addon_data->addon_variant_id == $varient->sno)
                                                        checked
                                                    @endif
                                                />
                                                  <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                      <span>{{$varient->addon_variablename}}</span>
                                                      <span class="ms-1 me-1">-</span>
                                                      <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377;<span>{{ number_format($varient->amount) }}</span></span>
                                                  </label>
                                                  <input type="hidden" name="addon_amount[{{$varient->sno}}]"  class="addon_amount" id="addon_amount" value="{{$varient->amount}}" >
                                                  <input type="hidden" name="free_paid[{{$varient->sno}}]"  class="" id="free_paid" value="1" >
                                              </div>
                                          </div>
                                            @endif
                                            @endforeach
                                          @endif
                                      </div>
                                  </div>
                                  @if(count($addOnProductList)>0)
                                      @if($idxAdn !=(count($addOnProductList)-1) )
                                      <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                      @endif
                                  @endif
                                  @endforeach
                                  @endif
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <div class="d-flex align-items-center justify-content-end mb-10 gap-5 mt-2">
        <label class="fw-bold fs-3 me-13">Grand Total</label>
        <div class="fw-bold fs-1">&#8377; <span class="over_all_total text-success" ></span></div>
      </div>
      <div class="d-flex justify-content-end align-items-center mt-6">
        <a href="{{url('/manage_package')}}" class="btn btn-secondary me-3">Cancel</a>
        <input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_create_packages" id="submit_pop_up">
        <button type="button" class="btn btn-primary" onclick="Validation()">Update Packages</button>
      </div>
    </form>

  </div>
</div>


<!--begin::Modal - Update Packages-->
<div class="modal fade" id="kt_modal_create_packages" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to Update Packages ?
        <div class="d-block text-black fw-semibold fs-5 mt-3 py-2">
          <label>Complete Thesis Writing ( 90 Days )</label>
          <span class="ms-2 me-2">-</span>
          <label>Thesis Writing</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <a href="{{url('/manage_package')}}" class="btn btn-primary me-3">Yes</a>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Packages-->





<script>
    function calculateAddonTotal() {
        
        let total = 0;
        $('.add_on_product:checked').each(function () {
            const container = $(this).closest('.px-3');
            const selectedVarient = container.find('.add_on_varient:checked');
             const amount = parseFloat(selectedVarient.closest('.form-check').find('.addon_amount').val()) || 0;
            total += amount;
        });

        // Update display and hidden field
        $('#addon_total_amount').text(total.toFixed(2));
        $('#addon_total_amount_value').val(total.toFixed(2));
    }

    function product_add_on_func() {
            if ($('#prod_add_on').is(':checked')) {
                $('#view_product_add_on').show();
            } else {
                $('#view_product_add_on').hide();
                // Reset totals
                $('#addon_total_amount').text('0.00');
                $('#addon_total_amount_value').val(0);
                // Optionally uncheck all add-ons and variants
                $('.add_on_product').prop('checked', false);
                const radioButtons = $('.add_on_varient');
                radioButtons.prop('disabled', true);
                radioButtons.prop('checked', false);
            }

            calculateAddonTotal();
            calculateOverTotal()
        }
        $(window).on('load', function () {
            $('.add_on_product').each(function () {
                const container2 = $(this).closest('.px-3'); 
                const radioButtons2 = container2.find('.add_on_varient');
                if ($(this).is(':checked')) {
                    radioButtons2.prop('disabled', false);
                } else {
                    radioButtons2.prop('disabled', true);
                }
            });
        });

        $(document).ready(function () {
          // Handle add_on_product checkbox change
          $(document).on('change', '.add_on_product', function () {
              const container = $(this).closest('.px-3'); 
              const radioButtons = container.find('.add_on_varient');

              if ($(this).is(':checked')) {
                  radioButtons.prop('disabled', false);
                  radioButtons.prop('checked', false); 
              } else {
                  radioButtons.prop('disabled', true);
                  radioButtons.prop('checked', false);
              }

              calculateAddonTotal();
              calculateOverTotal();
          });

          // Handle variant radio change
          $(document).on('change', '.add_on_varient', function () {
              calculateAddonTotal();
              calculateOverTotal();
          });

          // Initial setup
          product_add_on_func();
      });



        function calculateOverTotal() {
            
          let subTotal = 0;
          let product_total =  parseFloat($('#over_all_total_amount').val().replace(/[^0-9.-]+/g, "")) ||0 ;
          let addOn_total   =  parseFloat($('#addon_total_amount_value').val().replace(/[^0-9.-]+/g, ""))||0 ;  
          var grant_total = product_total + addOn_total;
          $('.over_all_total').text(formatCurrency(grant_total));
          $('#grant_total_amount').val(grant_total);
            
        }
</script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const maxChars = 35;
        const elements = document.querySelectorAll('.text_truncate_class');
        elements.forEach(el => {
            const fullText = el.textContent.trim();
            if (fullText.length > maxChars) {
                el.setAttribute('title', fullText);
                el.textContent = fullText.slice(0, maxChars) + '...';
                bootstrap.Tooltip.getOrCreateInstance(el);
            }
        });
    });
</script>

<script>
function Validation() {
    let isValid = 0;
    // Clear all previous errors
    document.querySelectorAll('.error_msg').forEach(div => {
        div.innerText = '';
    });
    // Helper to set error
    function setError(id, message) {
        document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
        isValid = 1;
    }

    // Required fields validation
    const requiredFields = [
        {
            id: 'package_name',
            name: 'Enter Package Name'
        },
        {
            id: 'base_price',
            name: 'Enter Base Price'
        },
        {
            id: 'min_amount',
            name: 'Enter Minimum Amount'
        },
        {
            id: 'max_amount',
            name: 'Enter Maximum Amount'
        }
    ];

    requiredFields.forEach(field => {
        const value = document.getElementById(field.id).value.trim();
        if (value === '') {
            setError(field.id, `${field.name} is required.`);
        }
    });

    const maximum_cost = parseFloat(document.getElementById("max_amount").value.trim()) || 0;
    const minimum_cost = parseFloat(document.getElementById("min_amount").value.trim()) || 0;
    // Compare Minimum and Maximum Costs
    if (minimum_cost > maximum_cost) {
        setError('min_amount', 'Min Amount should be less than Max Amount');
    }

    const over_all_total_amount = parseFloat(document.getElementById("over_all_total_amount").value.trim()) || 0;
    // Compare Minimum and Maximum Costs
    if (over_all_total_amount < 1) {
      document.querySelector(`#over_all_total_lab`).innerText = 'Choose any one Product';
       isValid = 1;
    }else{
       document.querySelector(`#over_all_total_lab`).innerText = '';
    }

    
    if (isValid == 0) {
        $('#add_form').submit();
    }
}
</script>

<script>
  // $('.chse_me_btta').on('click', function(e) {
  //   e.preventDefault();
  //   $('.modal.show').modal('hide');  // Hide any currently open modals
  //   const target = $(this).data('bs-target');
  //   $(target).modal('show');          // Show the clicked modal
  // });

  
  function payment_slot_func() {
    document.getElementById("add_payment_slot").style.setProperty('display', 'none', 'important');
    document.getElementById("update_payment_slot").style.setProperty('display', 'block', 'important');
    document.querySelectorAll('.pymt_bg').forEach(el => el.style.backgroundColor = '#7fffd494');
    document.getElementById("aft_pymt_slt").style.setProperty('display', 'block', 'important');
  }
</script>
<script>
  $('.pymt_slot_create_add').on('click', e => {
    var bt = parseFloat($('.form-repeater_pymt_slot_create').length);
    let $clone = $('.form-repeater_pymt_slot_create').first().clone().hide();
    $clone.insertBefore('.form-repeater_pymt_slot_create:first').slideDown();
    if (bt == 1) {
      $('.pymt_slot_create_del').attr('style', 'display: block !important');
    } else {
      $('.pymt_slot_create_del').attr('style', 'display: block !important');
    }
  });

  $(document).on('click', '.form-repeater_pymt_slot_create .pymt_slot_create_del', e => {
    var bt = parseFloat($('.pymt_slot_create_del').length);
    // alert(bt);
    $(e.target).closest('.form-repeater_pymt_slot_create').slideUp(400, function() {
      $(this).remove()
    });
    if (bt == 2) {
      $('.pymt_slot_create_del').attr('style', 'display: none !important');
    } else {}
  });
</script>
<script>
  function cal_prod_on_of(id) {
    var cal_prod_tbox  = document.getElementById("cal_prod_tbox_" + id);
    var tooltipElement = document.getElementById("cal_prod_tlp_" + id);

    if (cal_prod_tbox.style.display == "none") {
      document.getElementById("cal_prod_tbox_" + id).style.display = "block";
      document.getElementById("cal_prod_plus_btton_" + id).classList.remove("mdi-plus");
      document.getElementById("cal_prod_plus_btton_" + id).classList.add("mdi-minus");
      document.getElementById("cal_prod_hd_" + id).style.backgroundColor = "#ebebeb";
      document.getElementById("cal_prod_hd_" + id).classList.remove("rounded");
      document.getElementById("cal_prod_hd_" + id).classList.add("rounded-top");
      document.getElementById("cal_prod_az_" + id).classList.add("border", "border-gray-400i", "rounded");

      tooltipElement.setAttribute("title", "Hide");
      tooltipElement.setAttribute("data-bs-original-title", "Hide");

      var tooltipInstance = bootstrap.Tooltip.getInstance(tooltipElement);
      tooltipInstance.dispose();
      new bootstrap.Tooltip(tooltipElement);
    } else {
      document.getElementById("cal_prod_tbox_" + id).style.display = "none";
      document.getElementById("cal_prod_plus_btton_" + id).classList.remove("mdi-minus");
      document.getElementById("cal_prod_plus_btton_" + id).classList.add("mdi-plus");
      document.getElementById("cal_prod_hd_" + id).style.backgroundColor = "#ffffff";
      document.getElementById("cal_prod_hd_" + id).classList.remove("rounded-top");
      document.getElementById("cal_prod_hd_" + id).classList.add("rounded");
      document.getElementById("cal_prod_az_" + id).classList.remove("border", "border-gray-400i", "rounded");

      tooltipElement.setAttribute("title", "Show");
      tooltipElement.setAttribute("data-bs-original-title", "Show");

      var tooltipInstance = bootstrap.Tooltip.getInstance(tooltipElement);
      tooltipInstance.dispose();
      new bootstrap.Tooltip(tooltipElement);
    }
  }
</script>

<script>
  function pckg_vart_dy_func() {
    var pckg_vart_dy_chk = document.getElementById("pckg_vart_dy_chk");
    var pckg_vart_dy_chk_tbox = document.getElementById("pckg_vart_dy_chk_tbox");
    const pckg_vart_days_chk = document.getElementsByName("pckg_vart_days_chk");
    if (pckg_vart_dy_chk.checked) {
      pckg_vart_dy_chk_tbox.style.display = "block";
      for (let i = 0; i < pckg_vart_days_chk.length; i++) {
        pckg_vart_days_chk[i].disabled = false;
      }
    } else {
      pckg_vart_dy_chk_tbox.style.display = "none";
      for (let i = 0; i < pckg_vart_days_chk.length; i++) {
        pckg_vart_days_chk[i].disabled = true;
        pckg_vart_days_chk[i].checked = false;
      }
    }
  }
  
  function variant_check_func(id) {
    const checkbox = document.getElementById("variant_check_box_" + id);
    const variantDiv = document.getElementById("variant_check_div_" + id);
    const radios = document.querySelectorAll(".variable_radio_" + id);

    if (checkbox.checked) {
      variantDiv.style.display = "block";
      radios.forEach(radio => {
        radio.disabled = false;
      });
    } else {
      variantDiv.style.display = "none";
      radios.forEach(radio => {
        radio.disabled = true;
        radio.checked = false;
      });
    }
  }


  function variant_check_func_edit(id) {
    const checkbox = document.getElementById("variant_check_box_edit" + id);
    const variantDiv = document.getElementById("variant_check_div_edit" + id);
    const radios = document.querySelectorAll(".variable_radio_edit" + id);

    if (checkbox.checked) {
      variantDiv.style.display = "block";
      radios.forEach(radio => {
        radio.disabled = false;
      });
    } else {
      variantDiv.style.display = "none";
      radios.forEach(radio => {
        radio.disabled = true;
        radio.checked = false;
      });
    }
  }


  
</script>
<script>
   function formatCurrency(amt) {
        var roundedAmt = parseFloat(amt);
        var isWhole = Number.isInteger(roundedAmt);
    
        return roundedAmt.toLocaleString('en-IN', {
            minimumFractionDigits: isWhole ? 0 : 2,
            maximumFractionDigits: isWhole ? 0 : 2
        });
    }
 
  product_list()
  function product_list() {
      var id = {{$Inserted_id}};
      fetch('/product_list_package_edit/' + id, {
          method: 'GET',
          headers: {
              'Content-Type': 'application/json',
              'X-CSRF-TOKEN': '{{ csrf_token() }}'
          }
      })
      .then(response => response.json())
      .then(data => {
          if (data.status === 200) {
              var record = data.data;
              $('#selected_product_list_div').empty().html(record);
              $('[data-bs-toggle="tooltip"]').tooltip();
              if (Array.isArray(data.product_ids)) {
                  data.product_ids.forEach(function(product_id) {
                      $('#choose_me_button' + product_id).hide();
                      $('#card_color_' + product_id).addClass('bg-label-success_card');
                  });
              }
              $('.over_all_total').empty().html(formatCurrency(data.over_all_total));
              $('#over_all_total_amount').val(data.over_all_total);
              $('#grant_total_amount').val(data.over_all_total);
              $('.overall_totalDuration').empty().html(data.overall_totalDuration).attr('title',data.overall_totalDuration);
              $('#overall_total_Duration').val(data.overall_totalDuration);
calculateOverTotal()
          } else {
              // console.error(data.error_msg);
          }
      })
      .catch(error => {
          // console.error('Error:', error);
    });
  }
</script>

<script>
  function edit_product(product_id) {
    let modal = $(`#kt_modal_choose_me_edit_${product_id}`);
    let product_amount = $('#product_amount_edit'+product_id).val();
    let insertedId = $(`#Inserted_id_product_edit`).val();
    let selectedVariants = [];

    // Loop through all checked variant checkboxes
    modal.find(`input[id^="variant_check_box_edit"]:checked`).each(function () {
        let variantId = $(this).attr('id').replace('variant_check_box_edit', '');
        let $selectedVariable = $(`.variable_radio_edit${variantId}:checked`);
        let variableId = $selectedVariable.val();
        let variableAmount = $selectedVariable.data('amount');
        if (variableId) {
            selectedVariants.push({
                variant_id: variantId,
                variable_id: variableId,
                amount: variableAmount
            });
        }
    });

    // Prepare data object
    let payload = {
        inserted_id: insertedId,
        product_id: product_id,
        product_amount: product_amount,
        variants: selectedVariants
    };

    $.ajax({
        url: "{{ route('package/product_edit') }}",
        method: "POST",
        data: JSON.stringify(payload),
        contentType: "application/json",
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        beforeSend: function () {
            // Optional: show loader or disable button
        },
        success: function (response) {
            if (response.status === true) {
                Swal.fire({
                    title: 'Product Update',
                    text: 'The product has been updated successfully!',
                    icon: 'success',
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false
                });
                product_list();
                $(`#kt_modal_choose_me_triger_edit${product_id}`).click();
            } else {
                Swal.fire({
                    title: "Couldn't update Product",
                    text: 'Something might have gone wrong.',
                    icon: 'warning',
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false
                });
                $(`#kt_modal_choose_me_triger_edit${product_id}`).click();
            }
        },
        error: function () {
            Swal.fire({
                title: "Couldn't update Product",
                text: 'Something might have gone wrong. Please verify.',
                icon: 'error',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
        }
    });
}



</script>
<script>
  function remove_product(id,product_id){
    // alert(id)
     fetch('/product_list_package_edit_delete/' + id, {
          method: 'GET',
          headers: {
              'Content-Type': 'application/json',
              'X-CSRF-TOKEN': '{{ csrf_token() }}'
          }
      })
      .then(response => response.json())
      .then(data => {
          if (data.status === 200) {
             product_list();
             $('#choose_me_button' + product_id).show();
             $('#card_color_' + product_id).removeClass('bg-label-success_card');
          } else {
              // console.error(data.error_msg);
          }
      })
      .catch(error => {
          // console.error('Error:', error);
    });
  }
</script>
<script>
  function add_product(product_id,product_amount) {
    let insertedId = $(`#Inserted_id_product`).val();
     let modal = $(`#kt_modal_choose_me_${product_id}`);
    let selectedVariants = [];

    modal.find('input[type="checkbox"].form-check-input:checked').each(function () {
      let checkbox = $(this);
      let variantId = checkbox.attr('id').split('_').pop(); // variant sno
      let $selectedVariable = $(`.variable_radio_${variantId}:checked`);
      let variableId = $selectedVariable.val();
      let variableAmount = $selectedVariable.data('amount');

      if (variableId) {
        // Avoid duplicates if needed
        let alreadyAdded = selectedVariants.some(item => item.variant_id === variantId);
        if (!alreadyAdded) {
          selectedVariants.push({
            variant_id: variantId,
            variable_id: variableId,
            amount: variableAmount
          });
        }
      }
    });


    // Prepare data object
    let payload = {
      inserted_id: insertedId,
      product_id: product_id,
      product_amount: product_amount,
      variants: selectedVariants
    };

    $.ajax({
      url: "{{ route('package/product_edit') }}",
      method: "POST",
      data: JSON.stringify(payload),
      contentType: "application/json",
      headers: {
        'X-CSRF-TOKEN': '{{ csrf_token() }}'
      },
      beforeSend: function () {
        // Optional: Show loader or disable button
      },
      success: function (response) {
        if (response.status === true) {
          Swal.fire({
            title: 'Product Added',
            text: 'The product has been added successfully!',
            icon: 'success',
            customClass: {
              confirmButton: 'btn btn-primary waves-effect waves-light'
            },
            buttonsStyling: false
          });
          product_list();
          $('#choose_me_button' + product_id).hide();
          $('#kt_modal_choose_me_triger' + product_id).click();
        } else {
          Swal.fire({
            title: "Couldn't Add Product",
            text: 'Something might have gone wrong.',
            icon: 'warning',
            customClass: {
              confirmButton: 'btn btn-primary waves-effect waves-light'
            },
            buttonsStyling: false
          });
          $('#kt_modal_choose_me_triger' + product_id).click();
        }
      },
      error: function (xhr) {
        Swal.fire({
          title: "Couldn't Add Product",
          text: 'Something might have gone wrong. Please verify.',
          icon: 'error',
          customClass: {
            confirmButton: 'btn btn-primary waves-effect waves-light'
          },
          buttonsStyling: false
        });
      }
    });
  }
</script>
<script>
  let debounceTimer;

        function debounce(func, delay) {
            return function() {
                const context = this;
                const args = arguments;
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => func.apply(context, args), delay);
            };
        }

        function checkUniqueField(field, value, errorElementId, submitButtonId) {
            if (value === '') {
                $('#' + errorElementId).text('');
                return;
            }

            let sno = $('#Inserted_id').val();

            $.ajax({
                url: '/check_duplicate_package',
                method: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    field: field,
                    value: value,
                    sno: sno
                },
                success: function(response) {
                    if (response.exists) {
                        $('#' + errorElementId).text(response.message);
                        $('#' + submitButtonId).prop('disabled', true);
                    } else {
                        $('#' + errorElementId).text('');
                        $('#' + submitButtonId).prop('disabled', false);
                    }
                }
            });
        }

        // Bind with debounce
        $('#package_name').on('input', debounce(function() {
            checkUniqueField('package_name', $(this).val(), 'package_name_err', 'update_package_btn');
        }, 600));

</script>

<script>
  $(".list_page_1").DataTable({
    "ordering": false,
    "paging": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
  $('.list_page_1').wrap('<div class="dataTables_scroll" />');
</script>
@endsection