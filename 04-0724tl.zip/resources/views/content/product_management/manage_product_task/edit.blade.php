@php
    $helper = new \App\Helpers\Helpers();
    $maxhour = $helper->get_branch_id(auth()->user()->branch_id)->task_working_hours ?? 7;
    $stephour = 0.25;
    $maxValue = 100; // For Task Percentage 
    $step = 5; // For Task Percentage Step
    $jr_name = $helper->get_employee_skill_by_id(1)->employee_skill ?? 'Junior';
    $mid_name = $helper->get_employee_skill_by_id(2)->employee_skill ?? 'Mid Level';
    $sr_name = $helper->get_employee_skill_by_id(3)->employee_skill ?? 'Senior';
@endphp

<form action="{{ route('Update_product_task_mapping') }}" method="POST" id="edit_product_task_form">
    @csrf
    <!-- First Row -->
    <div class="row mb-4">
        <input type="hidden" name="edit_map_id" value="{{$edit->sno}}">
        <div class="col-md-4">
            <label class="text-black mb-2 fs-6 fw-semibold">Product<span class="text-danger">*</span></label>
            <select id="edit_product_id" name="edit_product_id" class="select3 form-select" onchange="prd_change_edit(this.value)">
                <option value="">Select Product</option>
                 @if (isset($Product_list))
                    @foreach ($Product_list as $pd_list)
                        <option value="{{ $pd_list->sno }}" @if($pd_list->sno == $edit->product_id) selected @endif>{{ $pd_list->product_name }}</option>
                    @endforeach
                @endif
            </select>
            <div class="text-danger edit_product_id_err"></div>
        </div>
        <div class="col-md-4">
            <label class="text-black mb-2 fs-6 fw-semibold">Product Category</label><br>
            <label class="text-black fs-5 fw-semibold badge bg-label-info px-2 py-2" id="edit_add_pd_cat">-</label>
            <input type="hidden" id="cat_id_hide_edit" name="cat_id_hide_edit" >
        </div>
        <div class="col-md-4">
            <label class="text-black mb-2 fs-6 fw-semibold">Variant</label>
            <select class="select3 form-select" id="edit_variant_id" name="edit_variant_id" onchange="Var_change_edit(this.value)">
                <option value="">Select Variant</option>
            </select>
            <div class="text-danger error_message"></div>
        </div>
        <div class="col-md-4">
            <label class="text-black mb-2 fs-6 fw-semibold">Variable</label>
            <select class="select3 form-select" id="edit_variable_id" name="edit_variable_id">
                <option value="">Select Variable</option>
            </select>
            <div class="text-danger error_message"></div>
        </div>
    </div>
    <input type="hidden" name="editcode_cat" id="editcode_cat">
    
    <!-- Second Row -->
    <div class="row edit_more_row" style="display:block;">
        @php
        $old_percen = 0;
        @endphp
        @if(isset($product_task_list))
            @foreach($product_task_list as $index => $plist)
                <div class="row task_accr_div_edit mb-4">
                    <div class="col-11">
                        <input type="hidden" name="edit_task_ids[]" value="{{$plist->sno}}">
                        <input type="hidden" name="edit_task_id_{{ $index }}" value="{{$plist->sno}}">
                        
                        <!-- Independent Accordion for each task -->
                        <div class="accordion mt-4" id="edit_productTaskAccordion_{{ $index }}">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="edit_headingProductTask_{{ $index }}">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" 
                                            data-bs-target="#collapseProductTask_{{ $index }}" aria-expanded="false" 
                                            aria-controls="collapseProductTask_{{ $index }}">
                                        <span id="edit_task_accrod_label_{{ $index }}" class="text-info fs-5 fw-bold me-1">{{$plist->task_name}}</span> Product Task Details
                                        <span class="badge bg-success fs-5 rounded ms-3" id="edit_task_pecentage_{{ $index }}">{{$plist->flexible_check == 1 ? 0 : $plist->task_percentage}} %</span>
                                        @php
                                            $old_percen = $plist->task_percentage ?? 0;
                                        @endphp
                                    </button>
                                </h2>
                                <div id="collapseProductTask_{{ $index }}" class="accordion-collapse collapse" 
                                    aria-labelledby="edit_headingProductTask_{{ $index }}">
                                    <div class="accordion-body">
                                        <div class="mt-4 pe-3">
                                            <div class="product_task_card">
                                                <div class="">
                                                    <div class="row mb-6">
                                                        <input type="hidden" id="edit_task_pecentage_hidden_{{ $index }}" name="edit_task_pecentage_hidden_{{ $index }}" value="{{$plist->flexible_check == 1 ? 0 : $plist->task_percentage}}">
                                                        <div class="col-md-12 mb-1">
                                                            <label for="edit_task_name_{{ $index }}" class="text-black mb-2 fs-6 fw-semibold">
                                                                Task<span class="text-danger">*</span>
                                                            </label>
                                                            <input type="text" maxlength="200" id="edit_task_name_{{ $index }}" name="task_name[{{ $index }}]" class="form-control form-control-solid edit_task_class" placeholder="Enter Task" value="{{$plist->task_name}}" onkeyup="edit_task_name_change(this.value,{{ $index }})">
                                                            <div class="text-danger error_message"></div>
                                                        </div>
                                                        <div class="col-md-6 mb-1" id="edit_flexible_container_{{ $index }}" style="display: {{ $plist->flexible_check == 1 ? 'none' : 'block' }};">
                                                            <label for="edit_task_percentage_{{ $index }}" class="text-black mb-2 fs-6 fw-semibold">
                                                                Percentage<span class="text-danger">*</span>
                                                            </label>
                                                            <select id="edit_task_percentage_{{ $index }}" name="edit_task_percentage_{{ $index }}" class="select3 form-select edit_percentage_class edit_task_percentage" onchange="per_change_edit(this.value,{{ $index }})">
                                                                <option value="">Select Percentage</option>
                                                                @for ($p = $step; $p <= $maxValue; $p +=$step) 
                                                                    @if($old_percen >= $p)
                                                                        @if($plist->flexible_check == 1)
                                                                            <option value="{{$p}}" @if($p==$plist->task_percentage) selected @endif>{{$p}}</option>
                                                                        @else
                                                                            <option value="{{$p}}" @if($p == $plist->task_percentage) selected @endif>{{$p}}</option>
                                                                        @endif
                                                                    @endif
                                                                @endfor
                                                            </select>
                                                            <div class="text-danger error_message"></div>
                                                        </div>
                                                        <div class="col-lg-6 mb-1 d-flex align-items-end justify-content-evenly gap-3">
                                                            <div class="d-flex align-items-center gap-2 bg-success justify-content-center px-3 py-1 rounded">
                                                                <input class="form-check-input me-1  mt-1 fs-4" type="checkbox"  id="edit_code_or_write_{{ $index }}" name="edit_code_or_write_{{ $index }}"
                                                                    value="1" style="border: none;" {{ $plist->category_check == 1 ? 'checked' : '' }} onclick="editcodeWriteLabel(this, {{ $index }})">
                                                                <label class="text-dark mb-1 mt-1 fs-3 fw-semibold text-white" id="edit_code_write_label_{{ $index }}">{{ $plist->category_check == 1 ? 'Coding' : 'Writing' }}</label>
                                                            </div>
                                                            <div class="d-flex align-items-center gap-2 bg-info justify-content-center px-3 py-1 rounded">
                                                                <input class="form-check-input me-1  mt-1 fs-4" type="checkbox"id="edit_task_flex_{{ $index }}" name="edit_task_flex_{{ $index }}"
                                                                    value="1" style="border: none;" {{ $plist->flexible_check == 1 ? 'checked' : '' }} onchange="editflexibleChange(this, {{ $index }})">
                                                                <label class="text-dark mb-1 mt-1 fs-3 fw-semibold text-white" id="edit_task_flex_label_{{ $index }}">Flexible</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    @php
                                                        $emp_skill = json_decode($plist->emp_skill, true) ?? [];
                                                        $peremp_1 = $emp_skill['1']['percent'] ?? '';
                                                        $peremp_2 = $emp_skill['2']['percent'] ?? '';
                                                        $peremp_3 = $emp_skill['3']['percent'] ?? '';
                                                    @endphp
            
                                                    <!-- Code Allocation -->
                                                    <div class="mb-6 edit_code_cat_div" id="edit_code_cat_div_{{ $index }}" style="display:{{ $plist->category_check == 1 ? 'block' : 'none' }};">
                                                        <div class="pt-4">
                                                            <div class="row mb-4 bg-label-info rounded py-2 mx-0">
                                                                <div class="col-md-6 mb-1"><label>Employee Skill</label></div>
                                                                <div class="col-md-6 mb-1"><label>Hours for 100%</label></div>
                                                            </div>
                                                            
                                                            <!-- Junior -->
                                                            <div class="row mb-3 align-items-center">
                                                                <div class="col-md-6 mb-1">
                                                                    <span class="badge badge-circle bg-primary me-3"><i class="mdi mdi-account-school-outline text-white"></i></span>
                                                                    <label for="junior_percent_{{ $index }}">{{$jr_name}}</label>
                                                                </div>
                                                                <div class="col-md-6 mb-1">
                                                                    <select id="junior_hours_{{ $index }}" name="junior_hours_{{ $index }}" class="select3 form-select form-select-sm edit_hour_class">
                                                                        <option value="">Select Hours</option>
                                                                        @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                            <option value="{{$i}}" @if(isset($emp_skill['1']['hours']) && $i==$emp_skill['1']['hours']) selected @endif>{{$i}}</option>
                                                                        @endfor
                                                                    </select>
                                                                    <div class="text-danger error_message"></div>
                                                                </div>
                                                            </div>
            
                                                            <!-- Midlevel -->
                                                            <div class="row mb-3 align-items-center">
                                                                <div class="col-md-6 mb-1">
                                                                    <span class="badge badge-circle bg-warning me-3"><i class="mdi mdi-account-tie text-white"></i></span>
                                                                    <label for="mid_percent_{{ $index }}">{{$mid_name}}</label>
                                                                </div>
                                                                <div class="col-md-6 mb-1">
                                                                    <select id="mid_hours_{{ $index }}" name="mid_hours_{{ $index }}" class="select3 form-select form-select-sm edit_hour_class">
                                                                        <option value="">Select Hours</option>
                                                                        @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                            <option value="{{$i}}" @if(isset($emp_skill['2']['hours']) && $i==$emp_skill['2']['hours']) selected @endif>{{$i}}</option>
                                                                        @endfor
                                                                    </select>
                                                                    <div class="text-danger error_message"></div>
                                                                </div>
                                                            </div>
            
                                                            <!-- Senior -->
                                                            <div class="row align-items-center">
                                                                <div class="col-md-6 mb-1">
                                                                    <span class="badge badge-circle bg-success me-3"><i class="mdi mdi-account-tie-hat text-white"></i></span>
                                                                    <label for="senior_percent_{{ $index }}">{{$sr_name}}</label>
                                                                </div>
                                                                <div class="col-md-6 mb-1">
                                                                    <select id="senior_hours_{{ $index }}" name="senior_hours_{{ $index }}" class="select3 form-select form-select-sm edit_hour_class">
                                                                        <option value="">Select Hours</option>
                                                                        @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                            <option value="{{$i}}" @if(isset($emp_skill['3']['hours']) && $i==$emp_skill['3']['hours']) selected @endif>{{$i}}</option>
                                                                        @endfor
                                                                    </select>
                                                                    <div class="text-danger error_message"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
            
                                                    <!-- Write Allocation -->
                                                    <div class="mb-6 edit_write_cat_div" id="edit_write_cat_div_{{ $index }}" style="display:{{ $plist->category_check == 0 ? 'block' : 'none' }};">
                                                        <div class="pt-4">
                                                            <!-- Header Row -->
                                                            <div class="row mb-3 bg-label-info rounded py-2 mx-0">
                                                                <div class="col-md-4 mb-1">
                                                                  <label class="text-gray-700 fs-6 fw-semibold">Employee Skill</label>
                                                                </div>
                                                                <div class="col-md-4 mb-1">
                                                                  <label class="text-gray-700 fs-6 fw-semibold">No. of Words Per Page</label>
                                                                </div>
                                                                <div class="col-md-4 mb-1">
                                                                  <label class="text-gray-700 fs-6 fw-semibold">Hours Per Page</label>
                                                                </div>
                                                            </div>
            
                                                            <!-- Junior Row -->
                                                            <div class="row mb-3 align-items-center">
                                                                <div class="col-md-4 mb-1">
                                                                    <div class="d-flex align-items-center">
                                                                        <span class="badge badge-circle bg-primary me-3">
                                                                            <i class="mdi mdi-account-school-outline text-white"></i>
                                                                        </span>
                                                                        <label class="text-gray-800 fs-6 mb-0">{{$jr_name}}</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4 mb-1">
                                                                    <input type="text" maxlength="10" class="form-control form-control-sm edit_word_class" name="jr_word_count_{{ $index }}" id="jr_word_count_{{ $index }}" placeholder="Enter word count" value="{{$emp_skill['1']['words'] ?? ''}}">
                                                                    <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-md-4 mb-1">
                                                                    <select class="select3 form-select form-select-sm edit_hour_class" name="jr_hours_{{ $index }}" id="jr_hours_{{ $index }}">
                                                                        <option value="">Select Hours</option>
                                                                        @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                            <option value="{{$i}}" @if(isset($emp_skill['1']['hours']) && $i==$emp_skill['1']['hours']) selected @endif>{{$i}}</option>
                                                                        @endfor
                                                                    </select>
                                                                    <div class="text-danger error_message"></div>
                                                                </div>
                                                            </div>
            
                                                            <!-- Midlevel Row -->
                                                            <div class="row mb-3 align-items-center">
                                                                <div class="col-md-4 mb-1">
                                                                    <div class="d-flex align-items-center">
                                                                        <span class="badge badge-circle bg-warning me-3">
                                                                            <i class="mdi mdi-account-tie text-white"></i>
                                                                        </span>
                                                                        <label class="text-gray-800 fs-6 mb-0">{{$mid_name}}</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4 mb-1">
                                                                    <input type="text" maxlength="10" class="form-control form-control-sm edit_word_class" placeholder="Enter word count" name="mid_word_count_{{ $index }}" id="mid_word_count_{{ $index }}" value="{{$emp_skill['2']['words'] ?? ''}}"> 
                                                                    <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-md-4 mb-1">
                                                                    <select class="select3 form-select form-select-sm edit_hour_class" name="midl_hours_{{ $index }}" id="midl_hours_{{ $index }}">
                                                                        <option value="">Select Hours</option>
                                                                        @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                            <option value="{{$i}}" @if(isset($emp_skill['2']['hours']) && $i==$emp_skill['2']['hours']) selected @endif>{{$i}}</option>
                                                                        @endfor
                                                                    </select>
                                                                    <div class="text-danger error_message"></div>
                                                                </div>
                                                            </div>
            
                                                            <!-- Senior Row -->
                                                            <div class="row align-items-center">
                                                                <div class="col-md-4 mb-1">
                                                                    <div class="d-flex align-items-center">
                                                                        <span class="badge badge-circle bg-success me-3">
                                                                            <i class="mdi mdi-account-tie-hat text-white"></i>
                                                                        </span>
                                                                        <label class="text-gray-800 fs-6 mb-0">{{$sr_name}}</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4 mb-1">
                                                                    <input type="text" maxlength="10" class="form-control form-control-sm edit_word_class" placeholder="Enter word count" name="sr_word_count_{{ $index }}" id="sr_word_count_{{ $index }}" value="{{$emp_skill['3']['words'] ?? ''}}">
                                                                    <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-md-4 mb-1">
                                                                    <select class="select3 form-select form-select-sm edit_hour_class" name="sr_hours_{{ $index }}" id="sr_hours_{{ $index }}" >
                                                                        <option value="">Select Hours</option>
                                                                        @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                            <option value="{{$i}}" @if(isset($emp_skill['3']['hours']) && $i==$emp_skill['3']['hours']) selected @endif>{{$i}}</option>
                                                                        @endfor
                                                                    </select>
                                                                    <div class="text-danger error_message"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
            
                                                    <!-- Checklist -->
                                                    <div class="scroll-y max-h-300px mt-4 pe-3">
                                                        @if(isset($plist->check_list))
                                                            @foreach($plist->check_list as $cindex => $clist)  
                                                            <div class="row task_checklist_row align-items-center">
                                                                 <input type="hidden" name="edit_check_id[{{ $index }}][]" value="{{$clist->sno}}">
                                                                <div class="col-lg-10 mb-1">
                                                                    <label for="checklist_{{ $index }}_{{ $cindex }}" class="text-black fs-6 fw-semibold">
                                                                        Checklist<span class="text-danger">*</span>
                                                                    </label>
                                                                    <input maxlength="200" type="text" id="checklist_{{ $index }}_{{ $cindex }}" name="task_checklist[{{ $index }}][]" class="form-control edit_check_list_class"  placeholder="Enter Checklist" value="{{$clist->task_checklist ?? ''}}" />
                                                                    <div class="text-danger error_message"></div>
                                                                </div>
                                                                @if($cindex > 0)
                                                                <div class="col-lg-2 mb-1">
                                                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 task_checklist_del_edit">
                                                                        <i class="mdi mdi-delete fs-4"></i>
                                                                    </a>
                                                                </div>
                                                                @endif
                                                            </div> 
                                                            @endforeach
                                                        @else
                                                        <div class="row task_checklist_row align-items-center">
                                                            <input type="hidden" name="edit_check_id[0][]" value="0">
                                                            <div class="col-lg-10 mb-1">
                                                                <label for="checklist_0" class="text-black fs-6 fw-semibold">
                                                                    Checklist<span class="text-danger">*</span>
                                                                </label>
                                                                <input type="text" maxlength="200" id="checklist_0" name="task_checklist[0][]" class="form-control edit_check_list_class"  placeholder="Enter Checklist" />
                                                                <div class="text-danger error_message"></div>
                                                            </div>
                                                        </div>
                                                        @endif
                                                        <div class="task_checklist_container"></div>
                                                        <div class="mt-3">
                                                            <button type="button" class="btn btn-primary task_checklist_edit" data-check-list-id="{{ $index }}">
                                                                <i class="mdi mdi-plus me-1"></i> Add Checklist
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @if($index > 0)
                        <div class="col-1">
                            <button
                                type="button"
                                class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 task_del_edit"
                                data-bs-toggle="tooltip"
                                data-bs-placement="top"
                                title="Delete">
                                <i  class="mdi mdi-delete fs-4"></i>
                            </button>
                        </div>
                    @endif
                </div>
            @endforeach
        @endif

        <div id="product_task_container_edit"></div>
    </div>
    
    <div class="mt-3 edit_more_row" style="display:none;">
        <button type="button" class="btn btn-primary" data-repeater-create id="product_task_edit">
            <i class="mdi mdi-plus me-1"></i> Add Task
        </button>
    </div>

    <!-- Action Buttons -->
    <div class="d-flex justify-content-end align-items-center mt-4">
        <button type="button" class="btn btn-secondary me-3" data-bs-dismiss="modal" >Cancel</button>
        <button type="button" class="btn btn-primary create_btn" onclick="EditValidation()">Update Task Mapping</button>
    </div>
</form>
<input type="hidden" id="Edit_ai" value="{{$product_task_list ? count($product_task_list) : 0}}">

<script>
    // Global variables
    let productTaskCounterEdit = $('#Edit_ai').val();

    // Field validation function
    function validateFieldmain(selector, errorMessage) {
        let isValid = true;
    
        $(selector).each(function () {
            if (!$(this).is(':visible')) return;
            var errDiv = $(this).closest('.mb-1').find('.error_message');
            let value = $(this).val();
                
            if (value === '') {
                errDiv.text(errorMessage);
                $(this).closest('.accordion-item')
                .find('.accordion-button')
                .removeClass('bg-light')
                .addClass('bg-danger bg-opacity-10 text-danger')
                .css('border-left', '3px solid #dc3545');
                
                isValid = false;
            } else {
                $(this).closest('.accordion-item')
                  .find('.accordion-button')
                  .removeClass('bg-danger bg-opacity-10 text-danger')
                  .addClass('bg-light')
                  .css('border-left', '');
                  
                errDiv.text('');
            }
        });
    
        return isValid;
    }

    // Main validation function for edit
    function EditValidation() {
        let isValid = true;

        // Product validation
        var edit_product_id = $('#edit_product_id').val();
        if (edit_product_id === '') {
            $('.edit_product_id_err').html('Select Product is required');
            isValid = false;
        } else {
            $('.edit_product_id_err').html('');
        }

        // Task validation
        $('.task_accr_div_edit').each(function() {
            var taskId = $(this).find('.edit_task_class').attr('id');
            if (!taskId) return;
            
            var taskIndex = taskId.split('_').pop();
            var isCoding = $(`#edit_code_or_write_${taskIndex}`).is(':checked');

            // Common field validation
            if (!validateFieldmain(`#edit_task_name_${taskIndex}`, 'Task is required.')) {
                isValid = false;
            }
            
            // Only validate percentage if not flexible
            const isFlexible = $(`#edit_task_flex_${taskIndex}`).is(':checked');
            if (!isFlexible && !validateFieldmain(`#edit_task_percentage_${taskIndex}`, 'Percentage is required.')) {
                isValid = false;
            }
            
            if (!validateFieldmain(`.edit_check_list_class`, 'Checklist is required.')) {
                isValid = false;
            }

            // Type-specific validation
            if (isCoding) {
                // Coding task validation
                if (!validateFieldmain(`#junior_hours_${taskIndex}`, 'Junior hours are required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#mid_hours_${taskIndex}`, 'Mid hours are required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#senior_hours_${taskIndex}`, 'Senior hours are required.')) {
                    isValid = false;
                }
            } else {
                // Writing task validation
                if (!validateFieldmain(`#jr_word_count_${taskIndex}`, 'Junior word count is required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#jr_hours_${taskIndex}`, 'Junior hours are required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#mid_word_count_${taskIndex}`, 'Mid word count is required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#midl_hours_${taskIndex}`, 'Mid hours are required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#sr_word_count_${taskIndex}`, 'Senior word count is required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#sr_hours_${taskIndex}`, 'Senior hours are required.')) {
                    isValid = false;
                }
            }
        });

        if (!isValid) {
            return false;
        }

        // FIXED: Percentage validation - Check only non-flexible tasks
        var totalSelectedValue = 0;
        var hasFlexible = false;
        
        document.querySelectorAll('.edit_task_percentage').forEach(function (select) {
            const selectId = select.id;
            const indexMatch = selectId.match(/edit_task_percentage_(\d+)/);

            if (!indexMatch) return;

            const index = indexMatch[1];
            const isFlexible = document.querySelector(`#edit_task_flex_${index}`)?.checked;
            
            // Count flexible tasks
            if (isFlexible) {
                hasFlexible = true;
            }
            
            // Only add non-flexible task percentages
            if (!isFlexible && select.value) {
                const val = Number(select.value);
                if (!isNaN(val)) {
                    totalSelectedValue += val;
                }
            }
        });

        console.log('Total Percentage:', totalSelectedValue, 'Has Flexible:', hasFlexible);

        // Only validate if there are no flexible tasks
        if (!hasFlexible && totalSelectedValue !== 100) {
            Swal.fire({
                title: 'Warning',
                text: `Total Task percentage must be exactly 100%. Current total: ${totalSelectedValue}%`,
                icon: 'warning',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
            return false;
        }
        
        $('.create_btn').hide();
        $('#edit_product_task_form').submit();
        
        return true; 
    }

    // Initialize product change on page load
    prd_change_edit({{$edit->product_id}});

    // Product change handler for edit
    function prd_change_edit(val){
        if(val){
            $('.edit_more_row').show();
            
            $.ajax({
                url: "{{ route('get_product_variant_data_task') }}",
                type: "GET",
                data: { id: val },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var entityDropdown = $('#edit_variant_id');
                        entityDropdown.empty();
                        entityDropdown.append('<option value="">Select Variant</option>');
                        response.data.forEach(function(Data) {
                            entityDropdown.append($('<option></option>').attr('value', Data.sno).text(Data.product_variant_name));
                        });
                        $('#edit_variant_id').val({{$edit->variant_id}}).change();
                        $('#edit_add_pd_cat').html(response.data_category.product_category_name);
                        $('#cat_id_hide_edit').val(response.data_category.product_category_id);
                        
                        // Set editcode_cat based on product category
                        if(response.data_category.product_category_id == 1){
                            $('#editcode_cat').val(1);
                        } else {
                            $('#editcode_cat').val(2);
                        }
                        
                        var Dropdown = $('#edit_variable_id');
                        Dropdown.empty();
                        Dropdown.append('<option value="">Select Variable</option>');
                        productTaskCounterEdit = {{$product_task_list ? count($product_task_list) : 0}};
                    }
                },
                error: function(error) {
                    console.error('Error fetching states:', error);
                }
            });
       } else {
            $('.edit_task_class').val('');
            $('.edit_check_list_class').val('');
            $('.edit_word_class').val('');
            $('.edit_percentage_class').val('').change();
            $('.edit_hour_class').val('').change();
            $('.edit_more_row').hide();
            var entityDropdown = $('#edit_variant_id');
            entityDropdown.empty();
            entityDropdown.append('<option value="">Select Variant</option>');
            $('#edit_add_pd_cat').html('-');
            var Dropdown = $('#edit_variable_id');
            Dropdown.empty();
            Dropdown.append('<option value="">Select Variable</option>');
       }
    }

    // Variant change handler for edit
    function Var_change_edit(val){
        if(val){
            $.ajax({
                url: "{{ route('get_product_variable_data_task') }}",
                type: "GET",
                data: { id: val },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var Dropdown = $('#edit_variable_id');
                        Dropdown.empty();
                        Dropdown.append('<option value="">Select Variable</option>');
                        response.data.forEach(function(Data) {
                            Dropdown.append($('<option></option>').attr('value', Data.sno).text(Data.variable_name));
                        });
                        $('#edit_variable_id').val({{$edit->variable_id}}).change();
                    }
                },
                error: function(error) {
                    console.error('Error fetching states:', error);
                }
            });
       } else {
            var Dropdown = $('#edit_variable_id');
            Dropdown.empty();
            Dropdown.append('<option value="">Select Variable</option>');
       }
    }

    // Code/Write label toggle for edit
    function editcodeWriteLabel(checkbox, index) {
        const isChecked = checkbox.checked;
        
        // Update label text
        $('#edit_code_write_label_' + index).html(isChecked ? 'Coding' : 'Writing');
        
        // Show/hide appropriate allocation divs
        if (isChecked) {
            $('#edit_code_cat_div_' + index).show();
            $('#edit_write_cat_div_' + index).hide();
        } else {
            $('#edit_code_cat_div_' + index).hide();
            $('#edit_write_cat_div_' + index).show();
        }
        
        // Clear opposite type fields
        if (isChecked) {
            // Clear write fields
            $('#jr_word_count_' + index).val('');
            $('#jr_hours_' + index).val('').change();
            $('#mid_word_count_' + index).val('');
            $('#midl_hours_' + index).val('').change();
            $('#sr_word_count_' + index).val('');
            $('#sr_hours_' + index).val('').change();
        } else {
            // Clear code fields
            $('#junior_hours_' + index).val('').change();
            $('#mid_hours_' + index).val('').change();
            $('#senior_hours_' + index).val('').change();
        }
    }

    // Flexible task toggle for edit
    function editflexibleChange(checkbox, index) {
        var isChecked = checkbox.checked;

        if (isChecked) {
            $(`#edit_flexible_container_${index}`).hide();
            $(`#edit_task_pecentage_hidden_${index}`).val(0);
            $(`#edit_task_percentage_${index}`).val('').change();
            $(`#edit_task_pecentage_${index}`).html('0 %');
        } else {
            $(`#edit_flexible_container_${index}`).show();
            $(`#edit_task_pecentage_hidden_${index}`).val(0);
            $(`#edit_task_pecentage_${index}`).html('0 %');
            $(`#edit_task_percentage_${index}`).val('').change();
        }
    }

    // Percentage change handler for edit
    function per_change_edit(val,id){
        var value = val || 0;
        $('#edit_task_pecentage_'+id).html(value + ' %' );
        $('#edit_task_pecentage_hidden_'+id).val(value);
    }
    
    // Task name change handler for edit
    function edit_task_name_change(val,id){
        var value = val || '';
        $('#edit_task_accrod_label_'+id).html(value);
    }

    // Create percentage dropdown for edit
    function createPercentageDropdownEdit(euid) {
        var selects = document.querySelectorAll('.edit_task_percentage');
        var totalSelectedValue = 0;
        selects.forEach(function(select) {
            var val = Number(select.value);
            if (!isNaN(val)) {
                totalSelectedValue += val;
            }
        });
        
        var thresholdValue = 100 - totalSelectedValue;
        var step = {{$step}};
        var optionsHTML = '<option value="">Select Percentage</option>';
        
        for (var i = step; i <= thresholdValue; i += step) {
            optionsHTML += `<option value="${i}">${i}</option>`;
        }
        return `
        <select id="edit_task_percentage_${euid}" name="edit_task_percentage_${euid}" class="select3 form-select edit_percentage_class edit_task_percentage" onchange="per_change_edit(this.value, ${euid})">
            ${optionsHTML}
        </select>
        `;
    }

    // Checklist management for edit
    document.addEventListener('click', function (e) {
        const addButton = e.target.closest('.task_checklist_edit');
        
        if (addButton) {
            
            const checklistId = addButton.getAttribute('data-check-list-id');
            const container = addButton.closest('.accordion-body').querySelector('.task_checklist_container');
    
            const newTaskChecklist = `
                <div class="row task_checklist_row">
                    <input type="hidden" name="edit_check_id[${checklistId}][]" value="0">
                    <div class="col-lg-10 mb-1">
                        <label class="text-black fs-6 fw-semibold">Checklist<span class="text-danger">*</span></label>
                        <input type="text" maxlength="200" class="form-control edit_check_list_class" name="task_checklist[${checklistId}][]" placeholder="Enter Checklist" />
                        <div class="text-danger error_message"></div>
                    </div>
                    <div class="col-lg-2 mb-1">
                        <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 task_checklist_del_edit">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
                </div>`;
    
            if (container) {
                container.insertAdjacentHTML('beforeend', newTaskChecklist);
            }
        }
    });

    // Delete checklist for edit
    document.addEventListener('click', function (e) {
        if (e.target.closest('.task_checklist_del_edit')) {
            e.target.closest('.row').remove();
        }
    });

    // Word input validation for edit
    document.addEventListener('input', function (e) {
      if (e.target.classList.contains('edit_word_class')) {
        let val = e.target.value.replace(/[^0-9.]/g, '');
        val = val.replace(/^(\.)+/, '');
        val = val.replace(/(\..*)\./g, '$1');
        e.target.value = val;
      }
    });

    // Add new task for edit
    document.getElementById('product_task_edit').addEventListener('click', function (event) {
        event.preventDefault();
        
        let isValid = true;

        function validateFieldEdit(selector, errorMessage) {
            let valid = true;

            $(selector).each(function () {
                const container = $(this).closest('.edit_code_cat_div, .edit_write_cat_div');

                // Skip validation if container is hidden
                if (container.length > 0 && !container.is(':visible')) {
                    return;
                }

                // Skip flexible percentage tasks validation
                if ($(this).hasClass('edit_task_percentage')) {
                    const id = $(this).attr('id') || '';
                    const match = id.match(/edit_task_percentage_(\d+)/);
                    if (match) {
                        const index = match[1];
                        if ($(`#edit_task_flex_${index}`).is(':checked')) {
                            return;
                        }
                    }
                }

                const value = $(this).val();
                const errDiv = $(this).closest('.mb-1').find('.error_message');

                if (!value || value.trim() === '') {
                    errDiv.text(errorMessage);
                    valid = false;
                } else {
                    errDiv.text('');
                }
            });

            return valid;
        }

        var currentTaskIndex = productTaskCounterEdit - 1;
        var isCoding = $(`#edit_code_or_write_${currentTaskIndex}`).is(':checked');
        var cat_id_edit = $('#cat_id_hide_edit').val();

        let validations;

        if (isCoding) {
            validations = [
                ['.edit_task_class', 'Task is required.'],
                ['.edit_task_percentage', 'Percentage is required.'],
                ['.edit_code_cat_div .edit_hour_class', 'Hour is required.'],
                ['.edit_check_list_class', 'Checklist is required.']
            ];
        } else {
            validations = [
                ['.edit_task_class', 'Task is required.'],
                ['.edit_task_percentage', 'Percentage is required.'],
                ['.edit_write_cat_div .edit_hour_class', 'Hour is required.'],
                ['.edit_write_cat_div .edit_word_class', 'Word Count is required.'],
                ['.edit_check_list_class', 'Checklist is required.']
            ];
        }

        validations.forEach(([selector, message]) => {
            if (!validateFieldEdit(selector, message)) {
                isValid = false;
            }
        });

        if (!isValid) {
            return false;
        }

         // FIXED: Percentage validation - Check only non-flexible tasks
        var totalSelectedValue = 0;
        var hasFlexible = false;
        
        document.querySelectorAll('.edit_task_percentage').forEach(function (select) {
            const selectId = select.id;
            const indexMatch = selectId.match(/edit_task_percentage_(\d+)/);

            if (!indexMatch) return;

            const index = indexMatch[1];
            const isFlexible = document.querySelector(`#edit_task_flex_${index}`)?.checked;
            
            // Count flexible tasks
            if (isFlexible) {
                hasFlexible = true;
            }
            
            // Only add non-flexible task percentages
            if (!isFlexible && select.value) {
                const val = Number(select.value);
                if (!isNaN(val)) {
                    totalSelectedValue += val;
                }
            }
        });

        console.log('Total Percentage:', totalSelectedValue, 'Has Flexible:', hasFlexible);

        // Only validate if there are no flexible tasks
        if (!hasFlexible && totalSelectedValue == 100) {
            Swal.fire({
                title: 'Warning',
                text: `Total Task percentage must be exactly 100%. Current total: ${totalSelectedValue}%`,
                icon: 'warning',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
            return false;
        }
        
        productTaskCounterEdit++;
        const euid = productTaskCounterEdit;
        
        // Get product category for default settings
        var cat_id_edit = $('#cat_id_hide_edit').val();
        var isCodingDefault = (cat_id_edit == 2);

        // Create allocation divs HTML
        let code_write_div = `
            <div class="mb-6 edit_write_cat_div" id="edit_write_cat_div_${euid}" style="display:none;">
                <div class="pt-4">
                    <div class="row mb-4 bg-label-info rounded py-2 mx-0">
                        <div class="col-md-4 mb-1"><label>Employee Skill</label></div>
                        <div class="col-md-4 mb-1"><label>No. of Words Per Page</label></div>
                        <div class="col-md-4 mb-1"><label>Hours Per Page</label></div>
                    </div>
                    <!-- Junior Row -->
                    <div class="row mb-3 align-items-center">
                        <div class="col-md-4 mb-1">
                            <div class="d-flex align-items-center">
                                <span class="badge badge-circle bg-primary me-3">
                                    <i class="mdi mdi-account-school-outline text-white"></i>
                                </span>
                                <label class="text-gray-800 fs-6 mb-0">{{$jr_name}}</label>
                            </div>
                        </div>
                        <div class="col-md-4 mb-1">
                            <input type="text" maxlength="10" class="form-control form-control-sm edit_word_class" placeholder="Enter word count" name="jr_word_count_${euid}" id="jr_word_count_${euid}">
                            <div class="text-danger error_message"></div>
                        </div>
                        <div class="col-md-4 mb-1">
                            <select class="select3 form-select form-select-sm edit_hour_class" name="jr_hours_${euid}" id="jr_hours_${euid}">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                    <!-- Midlevel Row -->
                    <div class="row mb-3 align-items-center">
                        <div class="col-md-4 mb-1">
                            <div class="d-flex align-items-center">
                                <span class="badge badge-circle bg-warning me-3">
                                    <i class="mdi mdi-account-tie text-white"></i>
                                </span>
                                <label class="text-gray-800 fs-6 mb-0">{{$mid_name}}</label>
                            </div>
                        </div>
                        <div class="col-md-4 mb-1">
                            <input type="text" maxlength="10" class="form-control form-control-sm edit_word_class" placeholder="Enter word count" name="mid_word_count_${euid}" id="mid_word_count_${euid}">
                            <div class="text-danger error_message"></div>
                        </div>
                        <div class="col-md-4 mb-1">
                            <select class="select3 form-select form-select-sm edit_hour_class" name="midl_hours_${euid}" id="midl_hours_${euid}">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                    <!-- Senior Row -->
                    <div class="row align-items-center">
                        <div class="col-md-4 mb-1">
                            <div class="d-flex align-items-center">
                                <span class="badge badge-circle bg-success me-3">
                                    <i class="mdi mdi-account-tie-hat text-white"></i>
                                </span>
                                <label class="text-gray-800 fs-6 mb-0">{{$sr_name}}</label>
                            </div>
                        </div>
                        <div class="col-md-4 mb-1">
                            <input type="text" maxlength="10" class="form-control form-control-sm edit_word_class" placeholder="Enter word count" name="sr_word_count_${euid}" id="sr_word_count_${euid}">
                            <div class="text-danger error_message"></div>
                        </div>
                        <div class="col-md-4 mb-1">
                            <select class="select3 form-select form-select-sm edit_hour_class" name="sr_hours_${euid}" id="sr_hours_${euid}">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mb-6 edit_code_cat_div" id="edit_code_cat_div_${euid}" style="display:none;">
                <div class="pt-4">
                    <div class="row mb-4 bg-label-info rounded py-2 mx-0">
                        <div class="col-md-6 mb-1"><label>Employee Skill</label></div>
                        <div class="col-md-6 mb-1"><label>Hours For 100%</label></div>
                    </div>
                    <!-- Junior Row -->
                    <div class="row mb-3 align-items-center">
                        <div class="col-md-6 mb-1">
                            <span class="badge badge-circle bg-primary me-3">
                                <i class="mdi mdi-account-school-outline text-white"></i>
                            </span>
                            <label for="junior_percent_${euid}">{{$jr_name}}</label>
                        </div>
                        <div class="col-md-6 mb-1">
                            <select id="junior_hours_${euid}" name="junior_hours_${euid}" class="select3 form-select form-select-sm edit_hour_class">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                    <!-- Midlevel Row -->
                    <div class="row mb-3 align-items-center">
                        <div class="col-md-6 mb-1">
                            <span class="badge badge-circle bg-warning me-3">
                                <i class="mdi mdi-account-tie text-white"></i>
                            </span>
                            <label for="mid_percent_${euid}">{{$mid_name}}</label>
                        </div>
                        <div class="col-md-6 mb-1">
                            <select id="mid_hours_${euid}" name="mid_hours_${euid}" class="select3 form-select form-select-sm edit_hour_class">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                    <!-- Senior Row -->
                    <div class="row align-items-center">
                        <div class="col-md-6 mb-1">
                            <span class="badge badge-circle bg-success me-3">
                                <i class="mdi mdi-account-tie-hat text-white"></i>
                            </span>
                            <label for="senior_percent_${euid}">{{$sr_name}}</label>
                        </div>
                        <div class="col-md-6 mb-1">
                            <select id="senior_hours_${euid}" name="senior_hours_${euid}" class="select3 form-select form-select-sm edit_hour_class">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                </div>
            </div>`;
                        
        // Create percentage dropdown
        var percen = createPercentageDropdownEdit(euid);
    
        // Create new task HTML
        const newProductTask_edit = `
        <div class="row task_accr_div_edit mb-4">
            <input type="hidden" name="edit_task_id_${euid}" value="0">
            <div class="col-11">
                <!-- Independent Accordion for new task -->
                <div class="accordion mt-4" id="edit_productTaskAccordion_${euid}">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="edit_headingProductTask_${euid}">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" 
                                    data-bs-target="#collapseProductTask_${euid}" aria-expanded="false" 
                                    aria-controls="collapseProductTask_${euid}">
                                <span id="edit_task_accrod_label_${euid}" class="text-info fs-5 fw-bold me-1"></span>
                                Product Task Details <span class="badge bg-success fs-5 rounded ms-3" id="edit_task_pecentage_${euid}">0 %</span>
                            </button>
                        </h2>
                        <div id="collapseProductTask_${euid}" class="accordion-collapse collapse" 
                            aria-labelledby="edit_headingProductTask_${euid}">
                            <div class="accordion-body">
                                <div class="mt-4 pe-3">
                                    <div class="product_task_card">
                                        <div class="">
                                            <div class="row mb-6">
                                                <div class="col-md-12 mb-1">
                                                    <input type="hidden" id="edit_task_pecentage_hidden_${euid}" name="edit_task_pecentage_hidden_${euid}">
                                                    <label for="edit_task_name_${euid}" class="text-black mb-2 fs-6 fw-semibold">
                                                        Task<span class="text-danger">*</span>
                                                    </label>
                                                    <input type="text" maxlength="200" id="edit_task_name_${euid}" name="task_name[${euid}]"  class="form-control form-control-solid edit_task_class" placeholder="Enter Task" onkeyup="edit_task_name_change(this.value,${euid})">
                                                    <div class="text-danger error_message"></div>
                                                </div>
                                                <div class="col-md-6 mb-1" id="edit_flexible_container_${euid}" style="display: block">
                                                    <label for="edit_task_percentage_${euid}" class="text-black mb-2 fs-6 fw-semibold">
                                                        Percentage<span class="text-danger">*</span>
                                                    </label>
                                                     ${percen}
                                                    <div class="text-danger error_message"></div>
                                                </div>
                                                <div class="col-md-3 mb-1 mt-3">
                                                    <div class="bg-info px-2 py-1 text-white rounded mt-4">
                                                        <input class="form-check-input me-1 mt-1 fs-4" type="checkbox" id="edit_code_or_write_${euid}"
                                                            name="edit_code_or_write_${euid}" value="1" ${isCodingDefault ? 'checked' : ''} style="border: none;" onclick="editcodeWriteLabel(this, ${euid})">
                                                        <label class="text-dark mb-1 fs-3 fw-semibold text-white" id="edit_code_write_label_${euid}">${isCodingDefault ? 'Coding' : 'Writing'}</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 mb-1 mt-3">
                                                    <div class="bg-success px-2 py-1 text-white rounded mt-4">
                                                        <input class="form-check-input me-1 mt-1 fs-4" type="checkbox" id="edit_task_flex_${euid}" name="edit_task_flex_${euid}"
                                                            value="1" style="border: none;" onclick="editflexibleChange(this, ${euid})">
                                                        <label class="text-dark mb-1 fs-3 fw-semibold text-white" id="edit_task_flex_label_${euid}">Flexible</label>
                                                    </div>
                                                </div>
                                            </div>
                                            ${code_write_div}
                                            <!-- Checklist -->
                                            <div class="scroll-y max-h-300px mt-4 pe-3">
                                                <div>
                                                    <div>
                                                        <div class="row task_checklist_row align-items-center">
                                                            <div class="col-lg-10 mb-1">
                                                                <label for="checklist_${euid}" class="text-black fs-6 fw-semibold">
                                                                    Checklist<span class="text-danger">*</span>
                                                                </label>
                                                                <input type="text" maxlength="200" id="checklist_${euid}" class="form-control edit_check_list_class" name="task_checklist[${euid}][]" placeholder="Enter Checklist" />
                                                                <div class="text-danger error_message"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="task_checklist_container"></div>
                                                <div class="mt-3">
                                                    <button type="button" class="btn btn-primary task_checklist_edit" data-check-list-id="${euid}">
                                                        <i class="mdi mdi-plus me-1"></i> Add Checklist
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-1">
                <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 task_del_edit">
                    <i class="mdi mdi-delete fs-4"></i>
                </a>
            </div>
        </div>
        `;
    
        document.getElementById('product_task_container_edit').insertAdjacentHTML('beforeend', newProductTask_edit);
       
        // Initialize select2
        $('.select3').each(function() {
            $(this).wrap('<div class="position-relative"></div>').select2({
                dropdownParent: $(this).parent()
            });
        });

        // Initialize the new task
        setTimeout(() => {
            const checkbox = document.getElementById(`edit_code_or_write_${euid}`);
            editcodeWriteLabel(checkbox, euid);
        }, 0);
    });

    // Delete task for edit
    document.addEventListener('click', function (e) {
        if (e.target.closest('.task_del_edit')) {
            e.target.closest('.task_accr_div_edit').remove();
        }
    });

    // Re-initialize Bootstrap components
    function initializeBootstrapComponents() {
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }

    // Initialize when page loads
    document.addEventListener('DOMContentLoaded', function() {
        initializeBootstrapComponents();
    });
</script>
<script>
  document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
    el.addEventListener('click', function () {
      // Small delay to allow modal animation to finish
      setTimeout(() => {
        location.reload();
      }, 150);
    });
  });
</script>