@extends('layouts/layoutMaster')

@section('title', 'Manage Product Tasks')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 12px !important;
    }

    .card-action-element {
        padding: 1rem;
    }

    .table-responsive {
        overflow-x: auto;
    }
</style>

<!-- Product Task List Table -->
<div class="card card-action">
@php
    $helper = new \App\Helpers\Helpers();
    $maxhour = 50;
    $stephour = 0.5;
    $maxValue = 100; // For Task Pecentage 
    $step = 5; // For Task Pecentage Step
    $jr_name = $helper->get_employee_skill_by_id(1)->employee_skill ?? 'Junior';
    $mid_name = $helper->get_employee_skill_by_id(2)->employee_skill ?? 'Mid Level';
    $sr_name = $helper->get_employee_skill_by_id(3)->employee_skill ?? 'Senior';
@endphp
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Product Tasks</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center">
                            <i class="mdi mdi-home-outline text-body fs-4"></i>
                            <span class="ms-1">Dashboard</span>
                        </a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item active">Product Management</li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <button class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                    data-bs-target="#kt_modal_apt_add">
                    <i class="mdi mdi-plus me-2"></i>Add Product Task
                </button>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="row mb-4">
            @php $perpage_count = $perpage ? $perpage : 10; @endphp
            <div class="col-lg-2">
                <span>Show</span>
                <br>
                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                    @php
                    $options = [10, 25, 100, 500]; // Define available options
                    @endphp
                    @php foreach ($options as $option): @endphp
                    <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                        @php echo $option; @endphp
                    </option>
                    @php endforeach; @endphp
                </select>
            </div>
            <div class="col-lg-10 d-flex align-items-end justify-content-end">
                <form id="search_form" method="POST" action="/manage_product_task">
                    @csrf
                  <div class="d-flex align-items-center gap-2 mt-2">
                    <div>
                      <input type="hidden" name="page" value="{{ request('page', 1) }}">
                      <input type="hidden" name="filter_on" value="1">
                      <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                      <input
                        type="text"
                        class="form-control"
                        id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                        placeholder="Enter Search"
                      />
                    </div>
                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                  </div>
                </form>
            </div>
        </div>
        <div class="row table-responsive">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
              <thead>
                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                  <th class="min-w-150px">Products</th>
                  <th class="min-w-100px">Variant</th>
                  <th class="min-w-100px">Variable</th>
                  <th class="min-w-100px">Task Count</th>
                  <th class="min-w-100px">Action</th>
                </tr>
              </thead>
              <tbody class="text-black fw-semibold fs-7">
                @if (isset($ListTable))
                  @foreach ($ListTable as $i=> $list)
                    <tr>
                        <td>
                            <label class="text-black mb-1 fs-6 fw-semibold">{{ $list->product_name ?? '-' }}</label>
                            <div class="d-block">
                                <label class="bg-label-secondary fs-8 px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product Category">{{ $list->product_category_name ?? '-' }}</label>
                            </div>
                        </td>
                        <td>
                            <label class="text-black mb-1 fs-6 fw-semibold">{{ $list->product_variant_name ?? '-' }}</label>
                        </td>
                        <td>
                            <label class="text-black mb-1 fs-6 fw-semibold">{{ $list->variable_name ?? '-' }}</label>
                        </td>
                        <td>
                            <label class="badge bg-label-info text-black fw-semibold fs-6" style="font-weight: 600; padding: 0.35em 0.75em; border-radius: 9999px;">
                                {{ $list->task_count ?? '' }}
                            </label>
                        </td>
                        <td class="text-center">
                            <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2"
                                data-bs-toggle="modal" data-bs-target="#kt_modal_apt_edit" onclick="Edit('{{$list->sno}}')">
                                <i class="mdi mdi-square-edit-outline fs-3 text-black" title="Edit"></i>
                            </a>
                        </td>
                    </tr>
                  @endforeach
                @endif
              </tbody>
            </table>
            <div class="mt-4">
                {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Product Task Add-->
<div class="modal fade" id="kt_modal_apt_add" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-8 text-black">Create Product Task</h3>
                </div>
                <form action="{{ route('Add_product_task_mapping') }}" method="POST" id="add_product_task_form">
                    @csrf
                    <!-- First Row -->
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <label class="text-black mb-2 fs-6 fw-semibold">Product<span class="text-danger">*</span></label>
                            <select id="product_id" name="product_id" class="select3 form-select" onchange="prd_change(this.value)">
                                <option value="">Select Product</option>
                                 @if (isset($Product_list))
                                    @foreach ($Product_list as $pd_list)
                                        <option value="{{ $pd_list->sno }}">{{ $pd_list->product_name }}</option>
                                    @endforeach
                                @endif
                            </select>
                            <div class="text-danger product_id_err"></div>
                        </div>
                        <div class="col-md-4">
                            <label class="text-black mb-2 fs-6 fw-semibold">Product Category</label><br>
                            <label class="text-black fs-5 fw-semibold badge bg-label-info px-2 py-2" id="add_pd_cat">-</label>
                            <input type="hidden" id="cat_id_hide" name="cat_id_hide" >
                        </div>
                        <div class="col-md-4">
                            <label class="text-black mb-2 fs-6 fw-semibold">Variant</label>
                            <select class="select3 form-select" id="variant_id" name="variant_id" onchange="Var_change(this.value)">
                                <option value="">Select Variant</option>
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                        <div class="col-md-4">
                            <label class="text-black mb-2 fs-6 fw-semibold">Variable</label>
                            <select class="select3 form-select" id="variable_id" name="variable_id">
                                <option value="">Select Variable</option>
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>

                    <!-- Second Row -->
                    <div class="row add_more_row" style="display:none;">
                        <div class="col-11">
                            <div class="accordion mt-4" id="productTaskAccordion_0">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingProductTask_0">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse"
                                            data-bs-target="#collapseProductTask_0"
                                            aria-expanded="false"
                                            aria-controls="collapseProductTask_0">
                                            Product Task Details  <span class="badge bg-success fs-5 rounded ms-3" id="task_pecentage_0">0 %</span>
                                        </button>
                                    </h2>
                                    <div id="collapseProductTask_0" class="accordion-collapse collapse"
                                        aria-labelledby="headingProductTask_0"
                                        data-bs-parent="#productTaskAccordion_0">
                                        <div class="accordion-body">
                                            <div class="mt-4 pe-3">
                                                <div class="product_task_card">
                                                    <div class="">
                                                        <div class="row mb-6">
                                                            <input type="hidden" id="task_pecentage_hidden_0" name="task_pecentage_hidden_0">
                                                            <div class="col-md-6 mb-1">
                                                                <label for="task_name_0" class="text-black mb-2 fs-6 fw-semibold">
                                                                    Task<span class="text-danger">*</span>
                                                                </label>
                                                                <input type="text" id="task_name_0" name="task_name[0]" class="form-control form-control-solid task_class" placeholder="Enter Task">
                                                                <div class="text-danger error_message"></div>
                                                            </div>
                                                            <div class="col-md-6 mb-1">
                                                                <label for="task_percentage_0" class="text-black mb-2 fs-6 fw-semibold">
                                                                    Percentage<span class="text-danger">*</span>
                                                                </label>
                                                                <select id="task_percentage_0" name="task_percentage_0" class="select3 form-select percentage_class task_percentage" onchange="per_change(this.value,0)">
                                                                    <option value="">Select Percentage</option>
                                                                    @for ($p = $step; $p <= $maxValue; $p +=$step) 
                                                                        <option value="{{$p}}">{{$p}}</option>
                                                                        @endfor
                                                                    @endphp
                                                                </select>
                                                                <div class="text-danger error_message"></div>
                                                            </div>
                                                        </div>
                        
                                                        <!-- First Card - Code Allocation -->
                                                        <div class="mb-6 code_cat_div" style="display:none;">
                                                            <div class="pt-4">
                                                                <div class="row mb-4 bg-label-info rounded py-2 mx-0">
                                                                    <div class="col-md-4 mb-1"><label>Employee Skill</label></div>
                                                                    <div class="col-md-4 mb-1"><label>Percentage</label></div>
                                                                    <div class="col-md-4 mb-1"><label>Hours</label></div>
                                                                </div>
                        
                                                                <!-- Junior -->
                                                                <div class="row mb-3 align-items-center">
                                                                    <div class="col-md-4 mb-1">
                                                                        <span class="badge badge-circle bg-primary me-3"><i class="mdi mdi-account-school-outline text-white"></i></span>
                                                                        <label for="junior_percent_0">{{$jr_name}}</label>
                                                                    </div>
                                                                    <div class="col-md-4 mb-1">
                                                                        <select id="junior_percent_0" name="junior_percent_0" class="select3 form-select form-select-sm percentage_class">
                                                                            <option value="">Select %</option>
                                                                            @for ($p = $step; $p <= $maxValue; $p +=$step) 
                                                                                <option value="{{$p}}">{{$p}}</option>
                                                                                @endfor
                                                                            @endphp
                                                                        </select>
                                                                        <div class="text-danger error_message"></div>
                                                                    </div>
                                                                    <div class="col-md-4 mb-1">
                                                                        <select id="junior_hours_0" name="junior_hours_0" class="select3 form-select form-select-sm hour_class">
                                                                            <option value="">Select Hours</option>
                                                                            @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                                <option value="{{$i}}">{{$i}}</option>
                                                                            @endfor
                                                                        </select>
                                                                        <div class="text-danger error_message"></div>
                                                                    </div>
                                                                </div>
                        
                                                                <!-- Midlevel -->
                                                                <div class="row mb-3 align-items-center">
                                                                    <div class="col-md-4 mb-1">
                                                                        <span class="badge badge-circle bg-warning me-3"><i class="mdi mdi-account-tie text-white"></i></span>
                                                                        <label for="mid_percent_0">Midlevel</label>
                                                                    </div>
                                                                    <div class="col-md-4 mb-1">
                                                                        <select id="mid_percent_0"  name="mid_percent_0" class="select3 form-select form-select-sm percentage_class">
                                                                            <option value="">Select %</option>
                                                                            @for ($p = $step; $p <= $maxValue; $p +=$step) 
                                                                                <option value="{{$p}}">{{$p}}</option>
                                                                                @endfor
                                                                            @endphp
                                                                        </select>
                                                                        <div class="text-danger error_message"></div>
                                                                    </div>
                                                                    <div class="col-md-4 mb-1">
                                                                        <select id="mid_hours_0" name="mid_hours_0" class="select3 form-select form-select-sm hour_class">
                                                                            <option value="">Select Hours</option>
                                                                            @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                                <option value="{{$i}}">{{$i}}</option>
                                                                            @endfor
                                                                        </select>
                                                                        <div class="text-danger error_message"></div>
                                                                    </div>
                                                                </div>
                        
                                                                <!-- Senior -->
                                                                <div class="row align-items-center">
                                                                    <div class="col-md-4 mb-1">
                                                                        <span class="badge badge-circle bg-success me-3"><i class="mdi mdi-account-tie-hat text-white"></i></span>
                                                                        <label for="senior_percent_0">{{$sr_name}}</label>
                                                                    </div>
                                                                    <div class="col-md-4 mb-1">
                                                                        <select id="senior_percent_0" name="senior_percent_0" class="select3 form-select form-select-sm percentage_class">
                                                                            <option value="">Select %</option>
                                                                            @for ($p = $step; $p <= $maxValue; $p +=$step) 
                                                                                <option value="{{$p}}">{{$p}}</option>
                                                                                @endfor
                                                                            @endphp
                                                                        </select>
                                                                        <div class="text-danger error_message"></div>
                                                                    </div>
                                                                    <div class="col-md-4 mb-1">
                                                                        <select id="senior_hours_0" name="senior_hours_0" class="select3 form-select form-select-sm hour_class">
                                                                            <option value="">Select Hours</option>
                                                                            @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                                <option value="{{$i}}">{{$i}}</option>
                                                                            @endfor
                                                                        </select>
                                                                        <div class="text-danger error_message"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Second Card - Write Allocation -->
                                                        <div class="mb-6 write_cat_div" style="display:none;">
                                                            <div class="pt-4">
                                                              <!-- Header Row -->
                                                              <div class="row mb-4 bg-label-info rounded py-2 mx-0">
                                                                <div class="col-md-3 mb-1">
                                                                  <label class="text-gray-700 fs-6 fw-semibold">Employee Skill</label>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                  <label class="text-gray-700 fs-6 fw-semibold">Pages</label>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                  <label class="text-gray-700 fs-6 fw-semibold">No. of Words</label>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                  <label class="text-gray-700 fs-6 fw-semibold">Hours</label>
                                                                </div>
                                                              </div>
                                            
                                                              <!-- Junior Row -->
                                                              <div class="row mb-3 align-items-center">
                                                                <div class="col-md-3 mb-1">
                                                                  <div class="d-flex align-items-center">
                                                                    <span class="badge badge-circle bg-primary me-3">
                                                                      <i class="mdi mdi-account-school-outline text-white"></i>
                                                                    </span>
                                                                    <label class="text-gray-800 fs-6 mb-0">{{$jr_name}}</label>
                                                                  </div>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                  <input type="text" class="form-control form-control-sm page_class" name="jr_pages_0" id="jr_pages_0" placeholder="Enter Pages count">
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                    <input type="text" class="form-control form-control-sm word_class" name="jr_word_count_0" id="jr_word_count_0" placeholder="Enter word count">
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                  <select class="select3 form-select form-select-sm hour_class" name="jr_hours_0" id="jr_hours_0">
                                                                    <option value="">Select Hours</option>
                                                                    @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                        <option value="{{$i}}">{{$i}}</option>
                                                                    @endfor
                                                                  </select>
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                              </div>
                                            
                                                              <!-- Midlevel Row -->
                                                              <div class="row mb-3 align-items-center">
                                                                <div class="col-md-3 mb-1">
                                                                  <div class="d-flex align-items-center">
                                                                    <span class="badge badge-circle bg-warning me-3">
                                                                      <i class="mdi mdi-account-tie text-white"></i>
                                                                    </span>
                                                                    <label class="text-gray-800 fs-6 mb-0">{{$mid_name}}</label>
                                                                  </div>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                  <input type="text" class="form-control form-control-sm page_class" placeholder="Enter Pages count" name="mid_pages_0" id="mid_pages_0">
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                    <input type="text" class="form-control form-control-sm word_class" placeholder="Enter word count" name="mid_word_count_0" id="mid_word_count_0">
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                  <select class="select3 form-select form-select-sm hour_class" name="midl_hours_0" id="midl_hours_0">
                                                                    <option value="">Select Hours</option>
                                                                    @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                        <option value="{{$i}}">{{$i}}</option>
                                                                    @endfor
                                                                  </select>
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                              </div>
                                            
                                                              <!-- Senior Row -->
                                                              <div class="row align-items-center">
                                                                <div class="col-md-3 mb-1">
                                                                  <div class="d-flex align-items-center">
                                                                    <span class="badge badge-circle bg-success me-3">
                                                                      <i class="mdi mdi-account-tie-hat text-white"></i>
                                                                    </span>
                                                                    <label class="text-gray-800 fs-6 mb-0">{{$sr_name}}</label>
                                                                  </div>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                  <input type="text" class="form-control form-control-sm page_class" placeholder="Enter Pages count" name="sr_pages_0" id="sr_pages_0">
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                    <input type="text" class="form-control form-control-sm word_class" placeholder="Enter word count" name="sr_word_count_0" id="sr_word_count_0">
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-md-3 mb-1">
                                                                  <select class="select3 form-select form-select-sm hour_class" name="sr_hours_0" id="sr_hours_0">
                                                                    <option value="">Select Hours</option>
                                                                    @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                        <option value="{{$i}}">{{$i}}</option>
                                                                    @endfor
                                                                  </select>
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                              </div>
                                                            </div>
                                                        </div>
                                              
                                                        <!-- Checklist -->
                                                        <div class="scroll-y max-h-300px mt-4 pe-3">
                                                            <div>
                                                                <div>
                                                                    <div class="row task_checklist_row align-items-center">
                                                                        <div class="col-lg-10 mb-1">
                                                                            <label for="checklist_0" class="text-black fs-6 fw-semibold">
                                                                                Checklist<span class="text-danger">*</span>
                                                                            </label>
                                                                            <input type="text" id="checklist_0" name="task_checklist[0][]" class="form-control check_list_class"  placeholder="Enter Checklist" />
                                                                            <div class="text-danger error_message"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="task_checklist_container"></div>
                                                            <div class="mt-3">
                                                                <button type="button" class="btn btn-primary task_checklist_add" data-check-list-id="0">
                                                                    <i class="mdi mdi-plus me-1"></i> Add Checklist
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="product_task_container"></div>
                    </div>
                    
                    <div class="mt-3 add_more_row" style="display:none;">
                        <button type="button" class="btn btn-primary"  data-repeater-create id="product_task_add">
                            <i class="mdi mdi-plus me-1"></i> Add Task
                        </button>
                    </div>

                    <!-- Action Buttons -->
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3"data-bs-dismiss="modal">Cancel</button>
                        <!--style="display:none !important;"-->
                        <button type="button" class="btn btn-primary create_btn" onclick="AddValidation()" >Create Task</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Product Task Add -->

<!--begin::Modal - Product Task Add-->
<div class="modal fade" id="kt_modal_apt_edit" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" onclick="edit_close()">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-8 text-black">Update Product Task</h3>
                </div>
                <div id="edit_div"> </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Product Task Add -->

<input type="hidden" id="product_task_delete">
<!--begin::Modal - Delete variant-->
<div class="modal fade" id="kt_modal_product_task_delete" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-dialog-centered modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                <span id="product_task_delete_message"></span>
            </div>
            <input type="hidden" id="product_task_delete_id">
            <div class="row" id="product_task_delete_button">

            </div>
            <br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete variant-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .err_msg {
        /* background-color: red; */
        border-color: red;
    }
</style>

<script>
    // Display Toastr messages
       @if (Session::has('toastr'))
           var type = "{{ Session::get('toastr')['type'] }}";
           var message = "{{ Session::get('toastr')['message'] }}";
           toastr[type](message);
       @endif
</script>

<script>
    function Edit(val){
        $.ajax({
            url: "{{ route('edit_product_task_map') }}",
            method: "GET",
            data: {
                id:val
            },
            success: function (response) {
                $('#edit_div').html('');
                $('#edit_div').html(response);
                $('.select3').each(function() {
                    $(this).wrap('<div class="position-relative"></div>').select2({
                        dropdownParent: $(this).parent()
                    });
                });
                $('[data-bs-toggle="tooltip"]').tooltip();
            },
            error: function (xhr) {
                console.error(xhr.responseText);
            }
        });
    }
    function edit_close(){
        $('#edit_div').html('');
        location.reload();
    }
</script>


<script>
    $(".list_page").DataTable({
      "ordering": false,
      "paging": false,
      // "aaSorting":[],
      "language": {
          "lengthMenu": "Show _MENU_"
      , }
      ,"dom": "<'row mb-3'" +
        //   "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
        //   "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
          ">" +

          "<'table-responsive'tr>" +

          "<'row'" +
        //   "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
        //   "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
          ">"
    });
</script>


<script>
    function validateFieldmain(selector, errorMessage) {
        let isValid = true;
    
        $(selector).each(function () {
            var errDiv = $(this).closest('.mb-1').find('.error_message');
            let value = $(this).val();
                
            if (value === '') {
                $(this).closest('.accordion-item')
                .find('.accordion-button')
                .removeClass('bg-light')
                .addClass('bg-danger bg-opacity-10 text-danger')
                .css('border-left', '3px solid #dc3545');
                isValid = false;
                errDiv.text(errorMessage);
            } else {
                $('.accordion-button')
                .removeClass('bg-danger bg-opacity-10 text-danger')
                .addClass('bg-light')
                .css('border-left', '');

                errDiv.text('');
            }
        });
    
        return isValid;
    }
    function AddValidation() {
        let isValid = true; // Global scope for the function
    
        var product_id = $('#product_id').val();
        if (product_id === '') {
            $('.product_id_err').html('Select Product is required');
            isValid = false;
        } else {
            $('.product_id_err').html('');
        }
    
        var cat_id = $('#cat_id_hide').val() || 0;
    
        var validations = {
            1: [
                ['.task_class', 'Task is required.'],
                ['.task_percentage', 'Percentage is required.'],
                ['.write_cat_div .hour_class', 'Hour is required.'],
                ['.write_cat_div .page_class', 'Pages are required.'],
                ['.write_cat_div .word_class', 'Word Count is required.'],
                ['.write_cat_div .percentage_class', 'Percentage is required.'],
                ['.check_list_class', 'Checklist is required.']
            ],
            2: [
                ['.task_class', 'Task is required.'],
                ['.task_percentage', 'Percentage is required.'],
                ['.code_cat_div .hour_class', 'Hour is required.'],
                ['.code_cat_div .percentage_class', 'Percentage is required.'],
                ['.check_list_class', 'Checklist is required.']
            ]
        };
    
        (validations[cat_id] || []).forEach(([selector, message]) => {
            if (!validateFieldmain(selector, message)) {
                isValid = false;
            }
        });
    
        if (!isValid) {
            return false; // Stop form submission
        }
    
        // Check if total task percentage equals 100
        var totalSelectedValue = 0;
        document.querySelectorAll('.task_percentage').forEach(function (select) {
            var val = Number(select.value);
            if (!isNaN(val)) {
                totalSelectedValue += val;
            }
        });
    
        if (totalSelectedValue !== 100) {
            Swal.fire({
                title: 'Warning',
                text: 'Total Task percentage must be exactly 100%.',
                icon: 'warning',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
            return false;
        }
        
        
        $('.create_btn').hide();
        $('#add_product_task_form').submit();
        
        return true; 
    }
    function prd_change(val){
        if(val){
            $('.add_more_row').show();
            $('.task_class').val('');
            $('.check_list_class').val('');
            $('.page_class').val('');
            $('.word_class').val('');
            $('.percentage_class').val('').change();
            $('.hour_class').val('').change();
            
            $.ajax({
                url: "{{ route('get_product_variant_data_task') }}",
                type: "GET",
                data: { id: val },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        console.log(response.data)
                        var entityDropdown = $('#variant_id');
                        entityDropdown.empty();
                        entityDropdown.append('<option value="">Select Variant</option>');
                        response.data.forEach(function(Data) {
                            entityDropdown.append($('<option></option>').attr('value', Data.sno).text(Data.product_variant_name));
                        });
                        $('#add_pd_cat').html(response.data_category.product_category_name);
                        $('#cat_id_hide').val(response.data_category.product_category_id);
                        if(response.data_category.product_category_id == 1){
                            $('.code_cat_div').hide();
                            $('.write_cat_div').show();
                        }else{
                            $('.code_cat_div').show();
                            $('.write_cat_div').hide();
                        }
                        var Dropdown = $('#variable_id');
                        Dropdown.empty();
                        Dropdown.append('<option value="">Select Variable</option>');
                        const deleteButtons = document.querySelectorAll('.task_del');
                        // Click each one
                        deleteButtons.forEach(function(button) {
                            button.click();
                        });
                        
                        const task_checklist_del = document.querySelectorAll('.task_checklist_del');
                        // Click each one
                        task_checklist_del.forEach(function(button) {
                            button.click();
                        });
                        
                        
                        productTaskCounter = 0;
                    }
                },
                error: function(error) {
                    console.error('Error fetching states:', error);
                }
            });
       }else{
            $('.task_class').val('');
            $('.check_list_class').val('');
            $('.page_class').val('');
            $('.word_class').val('');
            $('.percentage_class').val('').change();
            $('.hour_class').val('').change();
           $('.add_more_row').hide();
           var entityDropdown = $('#variant_id');
            entityDropdown.empty();
            entityDropdown.append('<option value="">Select Variant</option>');
            $('#add_pd_cat').html('-');
            var Dropdown = $('#variable_id');
            Dropdown.empty();
            Dropdown.append('<option value="">Select Variable</option>');
       }
    }
    function Var_change(val){
        if(val){
            $.ajax({
                url: "{{ route('get_product_variable_data_task') }}",
                type: "GET",
                data: { id: val },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // console.log(response.data)
                        var Dropdown = $('#variable_id');
                        Dropdown.empty();
                        Dropdown.append('<option value="">Select Variable</option>');
                        response.data.forEach(function(Data) {
                            Dropdown.append($('<option></option>').attr('value', Data.sno).text(Data.variable_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching states:', error);
                }
            });
       }else{
            var Dropdown = $('#variable_id');
            Dropdown.empty();
            Dropdown.append('<option value="">Select Variable</option>');
       }
    }
    // Creating Task Checklist
    document.addEventListener('click', function (e) {
        const addButton = e.target.closest('.task_checklist_add');
        
        if (addButton) {
            const checklistId = addButton.getAttribute('data-check-list-id');
            const container = addButton.closest('.accordion-body').querySelector('.task_checklist_container');
    
            const newTaskChecklist = `
                <div class="row task_checklist_row">
                    <div class="col-lg-10 mb-1">
                        <label class="text-black fs-6 fw-semibold">Checklist<span class="text-danger">*</span></label>
                        <input type="text" class="form-control check_list_class" name="task_checklist[${checklistId}][]" placeholder="Enter Checklist" />
                        <div class="text-danger error_message"></div>
                    </div>
                    <div class="col-lg-2 mb-1">
                        <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 task_checklist_del">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
                </div>`;
    
            if (container) {
                container.insertAdjacentHTML('beforeend', newTaskChecklist);
            }
        }
    });
    // Deleting Task Checklist
    document.addEventListener('click', function (e) {
        if (e.target.closest('.task_checklist_del')) {
            e.target.closest('.row').remove();
        }
    });
    function per_change(val,id){
        var value = val || 0;
        $('#task_pecentage_'+id).html(value + ' %' );
        $('#task_pecentage_hidden_'+id).val(value);
    }
    function createPercentageDropdown(uid) {
    var selects = document.querySelectorAll('.task_percentage');
    var totalSelectedValue = 0;
    selects.forEach(function(select) {
        var val = Number(select.value);
        if (!isNaN(val)) {
            totalSelectedValue += val;
        }
    });
    

    var thresholdValue = 100 - totalSelectedValue;

    // Build options starting from minValue or step value whichever is higher
    var step = {{$step}}; // same as your PHP step
    var optionsHTML = '<option value="">Select Percentage</option>';
    
    for (var i = step; i <= thresholdValue; i += step) {
        // if (i > totalSelectedValue) {
            optionsHTML += `<option value="${i}">${i}</option>`;
        // }
    }
    return `
      <select id="task_percentage_${uid}" name="task_percentage_${uid}" class="select3 form-select percentage_class task_percentage" onchange="per_change(this.value, ${uid})">
        ${optionsHTML}
      </select>
    `;
}
</script>
<script>
    document.addEventListener('input', function (e) {
      if (e.target.classList.contains('page_class')) {
        let val = e.target.value.replace(/[^0-9.]/g, '');
        val = val.replace(/^(\.)+/, '');
        val = val.replace(/(\..*)\./g, '$1');
        e.target.value = val;
      }
    });
    document.addEventListener('input', function (e) {
      if (e.target.classList.contains('word_class')) {
        let val = e.target.value.replace(/[^0-9.]/g, '');
        val = val.replace(/^(\.)+/, '');
        val = val.replace(/(\..*)\./g, '$1');
        e.target.value = val;
      }
    });
    let productTaskCounter = 0;
    document.getElementById('product_task_add').addEventListener('click', function () {
    
        let isValid = true;
    
        function validateField(selector, errorMessage) {
            $(selector).each(function () {
                // if (!$(this).is(':visible')) return; // Skip hidden elements
        
                var errDiv = $(this).closest('.mb-1').find('.error_message');
                let value = $(this).val();
        
                if (value === '') {
                    isValid = false;
                    errDiv.text(errorMessage);
                } else {
                    errDiv.text('');
                }
            });
        }
        const cat_id = $('#cat_id_hide').val() || 0;
    
        const validations = {
            1: [
                ['.task_class', 'Task is required.'],
                ['.task_percentage', 'Percentage is required.'],
                ['.write_cat_div .hour_class', 'Hour is required.'],
               
                ['.write_cat_div .page_class', 'Pages is required.'],
                ['.write_cat_div .word_class', 'Word Count is required.'],
                ['.write_cat_div .percentage_class', 'Percentage is required.'],
                
                ['.check_list_class', 'Checklist is required.']
            ],
            2: [
                ['.task_class', 'Task is required.'],
                ['.task_percentage', 'Percentage is required.'],
                
                ['.code_cat_div .hour_class', 'Hour is required.'],
                
                ['.code_cat_div .percentage_class', 'Percentage is required.'],
                ['.check_list_class', 'Checklist is required.']
            ]
        };
        
        
        (validations[cat_id] || []).forEach(([selector, message]) => {
            const result = validateField(selector, message);
        });
        
        if (!isValid) {
            // alert('Please fill in all required fields.');
            return false; // Prevent form submission
        }
        
        var selects_per = document.querySelectorAll('.task_percentage');
        var totalSelectedValueper = 0;
        selects_per.forEach(function(select) {
            var val = Number(select.value);
            if (!isNaN(val)) {
                totalSelectedValueper += val;
            }
        });
        
        // Example inside a form submission or input change handler
        if (totalSelectedValueper >= 100) {
            Swal.fire({
                title: 'Warning',
                text: 'Total Task percentage has reached or exceeded 100%.',
                icon: 'warning',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
            return false; 
        }
        
        
        productTaskCounter++;
        const uid = productTaskCounter;
        
        let code_write_div = '';
        if (cat_id == 1) {
        code_write_div = `<div class="mb-6 write_cat_div">
                            <div class="pt-4">
                                <!-- Header Row -->
                                <div class="row mb-4 bg-label-info rounded py-2 mx-0">
                                    <div class="col-md-3 mb-1">
                                        <label class="text-gray-700 fs-6 fw-semibold">Employee Skill</label>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <label class="text-gray-700 fs-6 fw-semibold">Pages</label>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <label class="text-gray-700 fs-6 fw-semibold">No. of Words</label>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <label class="text-gray-700 fs-6 fw-semibold">Hours</label>
                                    </div>
                                </div>
                    
                                <!-- Junior Row -->
                                <div class="row mb-3 align-items-center">
                                    <div class="col-md-3 mb-1">
                                        <div class="d-flex align-items-center">
                                            <span class="badge badge-circle bg-primary me-3">
                                                <i class="mdi mdi-account-school-outline text-white"></i>
                                            </span>
                                            <label class="text-gray-800 fs-6 mb-0">{{$jr_name}}</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <input type="text" class="form-control form-control-sm page_class" placeholder="Enter Pages count" name="jr_pages_${uid}" id="jr_pages_${uid}">
                                        <div class="text-danger error_message"></div>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <input type="text" class="form-control form-control-sm word_class" placeholder="Enter word count" name="jr_word_count_${uid}" id="jr_word_count_${uid}">
                                        <div class="text-danger error_message"></div>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <select class="select3 form-select form-select-sm hour_class" name="jr_hours_${uid}" id="jr_hours_${uid}">
                                            <option value="">Select Hours</option>
                                            @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                <option value="{{$i}}">{{$i}}</option>
                                            @endfor
                                        </select>
                                        <div class="text-danger error_message"></div>
                                    </div>
                                </div>
                    
                                <!-- Midlevel Row -->
                                <div class="row mb-3 align-items-center">
                                    <div class="col-md-3 mb-1">
                                        <div class="d-flex align-items-center">
                                            <span class="badge badge-circle bg-warning me-3">
                                                <i class="mdi mdi-account-tie text-white"></i>
                                            </span>
                                            <label class="text-gray-800 fs-6 mb-0">{{$mid_name}}</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <input type="text" class="form-control form-control-sm page_class" placeholder="Enter Pages count" name="mid_pages_${uid}" id="mid_pages_${uid}">
                                        <div class="text-danger error_message"></div>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <input type="text" class="form-control form-control-sm word_class" placeholder="Enter word count" name="mid_word_count_${uid}" id="mid_word_count_${uid}">
                                        <div class="text-danger error_message"></div>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <select class="select3 form-select form-select-sm hour_class" name="midl_hours_${uid}" id="midl_hours_${uid}">
                                            <option value="">Select Hours</option>
                                            @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                <option value="{{$i}}">{{$i}}</option>
                                            @endfor
                                        </select>
                                        <div class="text-danger error_message"></div>
                                    </div>
                                </div>
                    
                                <!-- Senior Row -->
                                <div class="row align-items-center">
                                    <div class="col-md-3 mb-1">
                                        <div class="d-flex align-items-center">
                                            <span class="badge badge-circle bg-success me-3">
                                                <i class="mdi mdi-account-tie-hat text-white"></i>
                                            </span>
                                            <label class="text-gray-800 fs-6 mb-0">{{$sr_name}}</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <input type="text" class="form-control form-control-sm page_class" placeholder="Enter Pages count" name="sr_pages_${uid}" id="sr_pages_${uid}">
                                        <div class="text-danger error_message"></div>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <input type="text" class="form-control form-control-sm word_class" placeholder="Enter word count" name="sr_word_count_${uid}" id="sr_word_count_${uid}">
                                        <div class="text-danger error_message"></div>
                                    </div>
                                    <div class="col-md-3 mb-1">
                                        <select class="select3 form-select form-select-sm hour_class" name="sr_hours_${uid}" id="sr_hours_${uid}">
                                            <option value="">Select Hours</option>
                                            @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                <option value="{{$i}}">{{$i}}</option>
                                            @endfor
                                        </select>
                                        <div class="text-danger error_message"></div>
                                    </div>
                                </div>
                            </div>
                        </div>`;
                    }
        if (cat_id == 2) {
            code_write_div = `<div class="mb-6 code_cat_div">
                <div class="pt-4">
                    <div class="row mb-4 bg-label-info rounded py-2 mx-0">
                        <div class="col-md-4 mb-1"><label>Employee Skill</label></div>
                        <div class="col-md-4 mb-1"><label>Percentage</label></div>
                        <div class="col-md-4 mb-1"><label>Hours</label></div>
                    </div>
        
                    <!-- Junior Row -->
                    <div class="row mb-3 align-items-center">
                        <div class="col-md-4 mb-1">
                            <span class="badge badge-circle bg-primary me-3">
                                <i class="mdi mdi-account-school-outline text-white"></i>
                            </span>
                            <label for="junior_percent_${uid}">{{$jr_name}}</label>
                        </div>
                        <div class="col-md-4 mb-1">
                            <select id="junior_percent_${uid}" name="junior_percent_${uid}" class="select3 form-select form-select-sm percentage_class">
                                <option value="">Select %</option>
                                @for ($p = $step; $p <= $maxValue; $p +=$step) 
                                    <option value="{{$p}}">{{$p}}</option>
                                    @endfor
                                @endphp
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                        <div class="col-md-4 mb-1">
                            <select id="junior_hours_${uid}" name="junior_hours_${uid}" class="select3 form-select form-select-sm hour_class">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
        
                    <!-- Midlevel Row -->
                    <div class="row mb-3 align-items-center">
                        <div class="col-md-4 mb-1">
                            <span class="badge badge-circle bg-warning me-3">
                                <i class="mdi mdi-account-tie text-white"></i>
                            </span>
                            <label for="mid_percent_${uid}">{{$mid_name}}</label>
                        </div>
                        <div class="col-md-4 mb-1">
                            <select id="mid_percent_${uid}" name="mid_percent_${uid}" class="select3 form-select form-select-sm percentage_class">
                                <option value="">Select %</option>
                                @for ($p = $step; $p <= $maxValue; $p +=$step) 
                                    <option value="{{$p}}">{{$p}}</option>
                                    @endfor
                                @endphp
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                        <div class="col-md-4 mb-1">
                            <select id="mid_hours_${uid}" name="mid_hours_${uid}" class="select3 form-select form-select-sm hour_class">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
        
                    <!-- Senior Row -->
                    <div class="row align-items-center">
                        <div class="col-md-4 mb-1">
                            <span class="badge badge-circle bg-success me-3">
                                <i class="mdi mdi-account-tie-hat text-white"></i>
                            </span>
                            <label for="senior_percent_${uid}">{{$sr_name}}</label>
                        </div>
                        <div class="col-md-4 mb-1">
                            <select id="senior_percent_${uid}" name="senior_percent_${uid}" class="select3 form-select form-select-sm percentage_class">
                                <option value="">Select %</option>
                                @for ($p = $step; $p <= $maxValue; $p +=$step) 
                                    <option value="{{$p}}">{{$p}}</option>
                                    @endfor
                                @endphp
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                        <div class="col-md-4 mb-1">
                            <select id="senior_hours_${uid}" name="senior_hours_${uid}" class="select3 form-select form-select-sm hour_class">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                </div>
            </div>`;
        }
        // Create percentage dropdown HTML string
        var percen = createPercentageDropdown(uid);
    
    
        const newProductTask = `
        <div class="row task_accr_div">
            <div class="col-11">
                <div class="accordion mt-4" id="productTaskAccordion_${uid}">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingProductTask_${uid}">
                            <button class="accordion-button collapsed" type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#collapseProductTask_${uid}"
                                aria-expanded="false"
                                aria-controls="collapseProductTask_${uid}">
                                Product Task Details <span class="badge bg-success fs-5 rounded ms-3" id="task_pecentage_${uid}">0 %</span>
                            </button>
                        </h2>
                        <div id="collapseProductTask_${uid}" class="accordion-collapse collapse"
                            aria-labelledby="headingProductTask_${uid}"
                            data-bs-parent="#productTaskAccordion_${uid}">
                            <div class="accordion-body">
                                <div class="mt-4 pe-3">
                                    <div class="product_task_card">
                                        <div class="">
                                            <div class="row mb-6">
                                                <div class="col-md-6 mb-1">
                                                    <input type="hidden" id="task_pecentage_hidden_${uid}" name="task_pecentage_hidden_${uid}">
                                                    <label for="task_name_${uid}" class="text-black mb-2 fs-6 fw-semibold">
                                                        Task<span class="text-danger">*</span>
                                                    </label>
                                                    <input type="text" id="task_name_${uid}" name="task_name[${uid}]"  class="form-control form-control-solid task_class" placeholder="Enter Task">
                                                    <div class="text-danger error_message"></div>
                                                </div>
                                                <div class="col-md-6 mb-1">
                                                    <label for="task_percentage_${uid}" class="text-black mb-2 fs-6 fw-semibold">
                                                        Percentage<span class="text-danger">*</span>
                                                    </label>
                                                     ${percen}
                                                    <div class="text-danger error_message"></div>
                                                </div>
                                            </div>
            
                                            ${code_write_div}
                                            
            
                                            <!-- Checklist -->
                                            <div class="scroll-y max-h-300px mt-4 pe-3">
                                                <div>
                                                    <div>
                                                        <div class="row task_checklist_row align-items-center">
                                                            <div class="col-lg-10 mb-1">
                                                                <label for="checklist_${uid}" class="text-black fs-6 fw-semibold">
                                                                    Checklist<span class="text-danger">*</span>
                                                                </label>
                                                                <input type="text" id="checklist_${uid}" class="form-control check_list_class" name="task_checklist[${uid}][]" placeholder="Enter Checklist" />
                                                                <div class="text-danger error_message"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="task_checklist_container"></div>
                                                <div class="mt-3">
                                                    <button type="button" class="btn btn-primary task_checklist_add" data-check-list-id="${uid}">
                                                        <i class="mdi mdi-plus me-1"></i> Add Checklist
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-1">
                <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 task_del">
                    <i class="mdi mdi-delete fs-4"></i>
                </a>
            </div>
        </div>
        `;
    
        document.getElementById('product_task_container').insertAdjacentHTML('beforeend', newProductTask);
        $('.select3').each(function() {
            $(this).wrap('<div class="position-relative"></div>').select2({
                dropdownParent: $(this).parent()
            });
        });
    });
    document.addEventListener('click', function (e) {
        if (e.target.closest('.task_del')) {
            e.target.closest('.task_accr_div').remove();
        }
    });
</script>

<script>
    function deleteproduct_task(element, id, del_id) {
        if (del_id !== '') {
            $('#product_task_delete').click();

            const name = $('#edit_task_name_' + id ).val() || '';
            $('#product_task_delete_id').val(del_id);
            $('#product_task_delete_message').html(
                'Are you sure you want to delete Product Task <br> <b class="text-danger">' + name + '</b> ?'
            );

            $('#product_task_delete_button').html(`
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="button" class="btn btn-danger me-3" onclick="delete_task_confirm('${del_id}', '${id}')">Yes, delete!</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, cancel</button>
                </div>
            `);
        }
    }

    function delete_task_confirm(delid, row_id) {
        const delete_id = delid;
    
        fetch('/product_task_delete/' + delete_id, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                $(`#task_card_container .task-row[data-index="${row_id}"]`).remove();
                toastr.success('Product Task Deleted successfully!');
                
                // Hide the delete modal properly
                const deleteModalEl = document.getElementById('kt_modal_product_task_delete');
                const deleteModal = bootstrap.Modal.getInstance(deleteModalEl);
                if (deleteModal) {
                    deleteModal.hide();
                }
            } else {
                toastr.error(data.error_msg || 'Something went wrong');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            toastr.error('Unexpected error occurred');
        });
    }

        
        document.getElementById("product_task_delete").addEventListener("click", function () {
            const deleteModal = new bootstrap.Modal(document.getElementById('kt_modal_product_task_delete'), {
                backdrop: 'static',
                keyboard: false
            });
            deleteModal.show();
        });

    </script>



@endsection