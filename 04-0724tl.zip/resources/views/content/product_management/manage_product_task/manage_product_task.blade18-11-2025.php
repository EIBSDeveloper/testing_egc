@extends('layouts/layoutMaster')

@section('title', 'Manage Product Tasks')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 12px !important;
    }

    .card-action-element {
        padding: 1rem;
    }

    .table-responsive {
        overflow-x: auto;
    }
</style>

<!-- Product Task List Table -->
<div class="card card-action">
@php
    $helper = new \App\Helpers\Helpers();
    $maxhour = $helper->get_branch_id(auth()->user()->branch_id)->task_working_hours ?? 7;
    $stephour = 0.5;
    $maxValue = 100; // For Task Pecentage 
    $step = 5; // For Task Pecentage Step
    $jr_name = $helper->get_employee_skill_by_id(1)->employee_skill ?? 'Junior';
    $mid_name = $helper->get_employee_skill_by_id(2)->employee_skill ?? 'Mid Level';
    $sr_name = $helper->get_employee_skill_by_id(3)->employee_skill ?? 'Senior';
@endphp
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Product Tasks</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center">
                            <i class="mdi mdi-home-outline text-body fs-4"></i>
                            <span class="ms-1">Dashboard</span>
                        </a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item active">Product Management</li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <button class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                    data-bs-target="#kt_modal_apt_add">
                    <i class="mdi mdi-plus me-2"></i>Add Product Task
                </button>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="row mb-4">
            @php $perpage_count = $perpage ? $perpage : 10; @endphp
            <div class="col-lg-2">
                <span>Show</span>
                <br>
                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                    @php
                    $options = [10, 25, 100, 500]; // Define available options
                    @endphp
                    @php foreach ($options as $option): @endphp
                    <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                        @php echo $option; @endphp
                    </option>
                    @php endforeach; @endphp
                </select>
            </div>
            <div class="col-lg-10 d-flex align-items-end justify-content-end">
                <form id="search_form" method="POST" action="/manage_product_task">
                    @csrf
                  <div class="d-flex align-items-center gap-2 mt-2">
                    <div>
                      <input type="hidden" name="page" value="{{ request('page', 1) }}">
                      <input type="hidden" name="filter_on" value="1">
                      <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                      <input
                        type="text"
                        class="form-control"
                        id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                        placeholder="Enter Search"
                      />
                    </div>
                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                  </div>
                </form>
            </div>
        </div>
        <div class="row table-responsive">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
              <thead>
                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                  <th class="min-w-150px">Products</th>
                  <th class="min-w-100px">Variant</th>
                  <th class="min-w-100px">Variable</th>
                  <th class="min-w-100px">Task Count</th>
                  <th class="min-w-100px">Action</th>
                </tr>
              </thead>
              <tbody class="text-black fw-semibold fs-7">
                @if (isset($ListTable))
                  @foreach ($ListTable as $i=> $list)
                    <tr>
                        <td>
                            <label class="text-black mb-1 fs-6 fw-semibold">{{ $list->product_name ?? '-' }}</label>
                            <div class="d-block">
                                <label class="bg-label-secondary fs-8 px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product Category">{{ $list->product_category_name ?? '-' }}</label>
                            </div>
                        </td>
                        <td>
                            <label class="text-black mb-1 fs-6 fw-semibold">{{ $list->product_variant_name ?? '-' }}</label>
                        </td>
                        <td>
                            <label class="text-black mb-1 fs-6 fw-semibold">{{ $list->variable_name ?? '-' }}</label>
                        </td>
                        <td>
                            <label class="badge bg-label-info text-black fw-semibold fs-6" style="font-weight: 600; padding: 0.35em 0.75em; border-radius: 9999px;">
                                {{ $list->task_count ?? '' }}
                            </label>
                        </td>
                        <td class="text-center">
                            <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2"
                                data-bs-toggle="modal" data-bs-target="#kt_modal_apt_edit" onclick="Edit('{{$list->sno}}')">
                                <i class="mdi mdi-square-edit-outline fs-3 text-black" title="Edit"></i>
                            </a>
                        </td>
                    </tr>
                  @endforeach
                @endif
              </tbody>
            </table>
            <div class="mt-4">
                {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Product Task Add-->
<div class="modal fade" id="kt_modal_apt_add" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-8 text-black">Create Product Task</h3>
                </div>
                <form action="{{ route('Add_product_task_mapping') }}" method="POST" id="add_product_task_form">
                    @csrf
                    <!-- First Row -->
                    <div class="row mb-4">
                        <div class="col-lg-4">
                            <label class="text-black mb-2 fs-6 fw-semibold">Product<span class="text-danger">*</span></label>
                            <select id="product_id" name="product_id" class="select3 form-select" onchange="prd_change(this.value)">
                                <option value="">Select Product</option>
                                 @if (isset($Product_list))
                                    @foreach ($Product_list as $pd_list)
                                        <option value="{{ $pd_list->sno }}">{{ $pd_list->product_name }}</option>
                                    @endforeach
                                @endif
                            </select>
                            <div class="text-danger product_id_err"></div>
                        </div>
                        <div class="col-lg-4">
                            <label class="text-black mb-2 fs-6 fw-semibold">Product Category</label><br>
                            <label class="text-black fs-5 fw-semibold badge bg-label-info px-2 py-2" id="add_pd_cat">-</label>
                            <input type="hidden" id="cat_id_hide" name="cat_id_hide" >
                        </div>
                        <div class="col-lg-4">
                            <label class="text-black mb-2 fs-6 fw-semibold">Variant</label>
                            <select class="select3 form-select" id="variant_id" name="variant_id" onchange="Var_change(this.value)">
                                <option value="">Select Variant</option>
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                        <div class="col-lg-4">
                            <label class="text-black mb-2 fs-6 fw-semibold">Variable</label>
                            <select class="select3 form-select" id="variable_id" name="variable_id">
                                <option value="">Select Variable</option>
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>

                    <!-- Second Row -->
                    <div class="row add_more_row task_accr_div" style="display:none;">
                        <div class="col-11">
                            <div class="accordion mt-4" id="productTaskAccordion_0">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingProductTask_0">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse"
                                            data-bs-target="#collapseProductTask_0"
                                            aria-expanded="false"
                                            aria-controls="collapseProductTask_0">
                                            <span id="task_accrod_label_0" class="text-info fs-5 fw-bold me-1"></span> Product Task Details
                                            <span class="badge bg-success fs-5 rounded ms-3" id="task_pecentage_0">0 %</span> 
                                            <input type="hidden" name="code_cat" id="code_cat">
                                        </button>
                                    </h2>
                                    <div id="collapseProductTask_0" class="accordion-collapse collapse"
                                        aria-labelledby="headingProductTask_0"
                                        data-bs-parent="#productTaskAccordion_0">
                                        <div class="accordion-body">
                                            <div class="mt-4 pe-3">
                                                <div class="product_task_card">
                                                    <div class="">
                                                        <div class="row">
                                                            <input type="hidden" id="task_pecentage_hidden_0" name="task_pecentage_hidden_0">
                                                            <div class="col-lg-12 mb-1">
                                                                <label for="task_name_0" class="text-black mb-2 fs-6 fw-semibold">
                                                                    Task<span class="text-danger">*</span>
                                                                </label>
                                                                <input type="text" id="task_name_0" name="task_name[0]" class="form-control form-control-solid task_class" placeholder="Enter Task" onkeyup="task_name_change(this.value,0)">
                                                                <div class="text-danger error_message"></div>
                                                            </div>
                                                            <div class="col-lg-6 mb-1" id="flexible_container_0" style="display: block">
                                                                <label for="task_percentage_0" class="text-black mb-2 fs-6 fw-semibold">
                                                                    Percentage<span class="text-danger">*</span>
                                                                </label>
                                                                <select id="task_percentage_0" name="task_percentage_0" class="select3 form-select percentage_class task_percentage" onchange="per_change(this.value,0)">
                                                                    <option value="">Select Percentage</option>
                                                                    @for ($p = $step; $p <= $maxValue; $p +=$step) 
                                                                        <option value="{{$p}}">{{$p}}</option>
                                                                        @endfor
                                                                    @endphp
                                                                </select>
                                                                <div class="text-danger error_message"></div>
                                                            </div>
                                                            <div class="col-lg-6 mb-1 d-flex align-items-end justify-content-evenly gap-3">
                                                                <div class="d-flex align-items-center gap-2 bg-success px-3 py-1 rounded">
                                                                    <input class="form-check-input me-1  mt-1 fs-4" type="checkbox" id="code_or_write_0" name="code_or_write_0"
                                                                        value="1" style="border: none;" onclick="codeWriteLabel(this, 0)">
                                                                    <label class="text-dark mb-1 fs-3 fw-semibold text-white" id="code_write_label_0">-</label>
                                                                </div>
                                                                <div class="d-flex align-items-center gap-2 bg-info px-3 py-1 rounded">
                                                                    <input class="form-check-input me-1  mt-1 fs-4" type="checkbox" id="task_flex_0" name="task_flex_0"
                                                                        value="1" style="border: none;" onclick="flexibleChange(this, 0)">
                                                                    <label class="text-dark mb-1 fs-3 fw-semibold text-white" id="task_flex_label_0">Flexible</label>
                                                                </div>
                                                            </div>
                                                        </div>
                        
                                                        <!-- First Card - Code Allocation -->
                                                        <div class="mb-6 code_cat_div" id="code_cat_div_0" style="display:none;">
                                                            <div class="pt-4">
                                                                <div class="row mb-4 bg-label-info rounded py-2 mx-0">
                                                                    <div class="col-lg-6 mb-1"><label>Employee Skill</label></div>
                                                                    <div class="col-lg-6 mb-1"><label>Hours for 100%</label></div>
                                                                </div>
                        
                                                                <!-- Junior -->
                                                                <div class="row mb-3 align-items-center">
                                                                    <div class="col-lg-6 mb-1">
                                                                        <span class="badge badge-circle bg-primary me-3"><i class="mdi mdi-account-school-outline text-white"></i></span>
                                                                        <label for="junior_percent_0">{{$jr_name}}</label>
                                                                    </div>
                                                                    <div class="col-lg-6 mb-1">
                                                                        <select id="junior_hours_0" name="junior_hours_0" class="select3 form-select form-select-sm hour_class">
                                                                            <option value="">Select Hours</option>
                                                                            @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                                <option value="{{$i}}">{{$i}}</option>
                                                                            @endfor
                                                                        </select>
                                                                        <div class="text-danger error_message"></div>
                                                                    </div>
                                                                </div>
                        
                                                                <!-- Midlevel -->
                                                                <div class="row mb-3 align-items-center">
                                                                    <div class="col-lg-6 mb-1">
                                                                        <span class="badge badge-circle bg-warning me-3"><i class="mdi mdi-account-tie text-white"></i></span>
                                                                        <label for="mid_percent_0">Mid Level</label>
                                                                    </div>
                                                                    <div class="col-lg-6 mb-1">
                                                                        <select id="mid_hours_0" name="mid_hours_0" class="select3 form-select form-select-sm hour_class">
                                                                            <option value="">Select Hours</option>
                                                                            @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                                <option value="{{$i}}">{{$i}}</option>
                                                                            @endfor
                                                                        </select>
                                                                        <div class="text-danger error_message"></div>
                                                                    </div>
                                                                </div>
                        
                                                                <!-- Senior -->
                                                                <div class="row align-items-center">
                                                                    <div class="col-lg-6 mb-1">
                                                                        <span class="badge badge-circle bg-success me-3"><i class="mdi mdi-account-tie-hat text-white"></i></span>
                                                                        <label for="senior_percent_0">{{$sr_name}}</label>
                                                                    </div>
                                                                    <div class="col-lg-6 mb-1">
                                                                        <select id="senior_hours_0" name="senior_hours_0" class="select3 form-select form-select-sm hour_class">
                                                                            <option value="">Select Hours</option>
                                                                            @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                                <option value="{{$i}}">{{$i}}</option>
                                                                            @endfor
                                                                        </select>
                                                                        <div class="text-danger error_message"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Second Card - Write Allocation -->
                                                        <div class="mb-6 write_cat_div" id="write_cat_div_0" style="display:none;">
                                                            <div class="pt-4">
                                                              <!-- Header Row -->
                                                              <div class="row mb-3 bg-label-info rounded py-2 mx-0">
                                                                <div class="col-lg-4 mb-1">
                                                                  <label class="text-gray-700 fs-6 fw-semibold">Employee Skill</label>
                                                                </div>
                                                                <div class="col-lg-4 mb-1">
                                                                  <label class="text-gray-700 fs-6 fw-semibold">No. of Words Per Page</label>
                                                                </div>
                                                                <div class="col-lg-4 mb-1">
                                                                  <label class="text-gray-700 fs-6 fw-semibold">Hours Per Page</label>
                                                                </div>
                                                              </div>
                                            
                                                              <!-- Junior Row -->
                                                              <div class="row mb-3 align-items-center">
                                                                <div class="col-lg-4 mb-1">
                                                                  <div class="d-flex align-items-center">
                                                                    <span class="badge badge-circle bg-primary me-3">
                                                                      <i class="mdi mdi-account-school-outline text-white"></i>
                                                                    </span>
                                                                    <label class="text-gray-800 fs-6 mb-0">{{$jr_name}}</label>
                                                                  </div>
                                                                </div>
                                                                <div class="col-lg-4 mb-1">
                                                                    <input type="text" class="form-control form-control-sm word_class" name="jr_word_count_0" id="jr_word_count_0" placeholder="Enter word count">
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-lg-4 mb-1">
                                                                  <select class="select3 form-select form-select-sm hour_class" name="jr_hours_0" id="jr_hours_0">
                                                                    <option value="">Select Hours</option>
                                                                    @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                        <option value="{{$i}}">{{$i}}</option>
                                                                    @endfor
                                                                  </select>
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                              </div>
                                            
                                                              <!-- Midlevel Row -->
                                                              <div class="row mb-3 align-items-center">
                                                                <div class="col-lg-4 mb-1">
                                                                  <div class="d-flex align-items-center">
                                                                    <span class="badge badge-circle bg-warning me-3">
                                                                      <i class="mdi mdi-account-tie text-white"></i>
                                                                    </span>
                                                                    <label class="text-gray-800 fs-6 mb-0">{{$mid_name}}</label>
                                                                  </div>
                                                                </div>
                                                                <div class="col-lg-4 mb-1">
                                                                    <input type="text" class="form-control form-control-sm word_class" placeholder="Enter word count" name="mid_word_count_0" id="mid_word_count_0">
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-lg-4 mb-1">
                                                                  <select class="select3 form-select form-select-sm hour_class" name="midl_hours_0" id="midl_hours_0">
                                                                    <option value="">Select Hours</option>
                                                                    @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                        <option value="{{$i}}">{{$i}}</option>
                                                                    @endfor
                                                                  </select>
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                              </div>
                                            
                                                              <!-- Senior Row -->
                                                              <div class="row align-items-center">
                                                                <div class="col-lg-4 mb-1">
                                                                  <div class="d-flex align-items-center">
                                                                    <span class="badge badge-circle bg-success me-3">
                                                                      <i class="mdi mdi-account-tie-hat text-white"></i>
                                                                    </span>
                                                                    <label class="text-gray-800 fs-6 mb-0">{{$sr_name}}</label>
                                                                  </div>
                                                                </div>
                                                                <div class="col-lg-4 mb-1">
                                                                    <input type="text" class="form-control form-control-sm word_class" placeholder="Enter word count" name="sr_word_count_0" id="sr_word_count_0">
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                                <div class="col-lg-4 mb-1">
                                                                  <select class="select3 form-select form-select-sm hour_class" name="sr_hours_0" id="sr_hours_0">
                                                                    <option value="">Select Hours</option>
                                                                    @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                                                        <option value="{{$i}}">{{$i}}</option>
                                                                    @endfor
                                                                  </select>
                                                                  <div class="text-danger error_message"></div>
                                                                </div>
                                                              </div>
                                                            </div>
                                                        </div>
                                              
                                                        <!-- Checklist -->
                                                        <div class="scroll-y max-h-300px mt-4 pe-3">
                                                            <div>
                                                                <div>
                                                                    <div class="row task_checklist_row align-items-center">
                                                                        <div class="col-lg-10 mb-1">
                                                                            <label for="checklist_0" class="text-black fs-6 fw-semibold">
                                                                                Checklist<span class="text-danger">*</span>
                                                                            </label>
                                                                            <input type="text" id="checklist_0" name="task_checklist[0][]" class="form-control check_list_class"  placeholder="Enter Checklist" />
                                                                            <div class="text-danger error_message"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="task_checklist_container"></div>
                                                            <div class="mt-3">
                                                                <button type="button" class="btn btn-primary task_checklist_add" data-check-list-id="0">
                                                                    <i class="mdi mdi-plus me-1"></i> Add Checklist
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="product_task_container"></div>
                    </div>
                    
                    <div class="mt-3 add_more_row" style="display:none;">
                        <button type="button" class="btn btn-primary"  data-repeater-create id="product_task_add">
                            <i class="mdi mdi-plus me-1"></i> Add Task
                        </button>
                    </div>

                    <!-- Action Buttons -->
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3"data-bs-dismiss="modal">Cancel</button>
                        <!--style="display:none !important;"-->
                        <button type="button" class="btn btn-primary create_btn" onclick="AddValidation()" >Create Task</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Product Task Add -->

<!--begin::Modal - Product Task Edit-->
<div class="modal fade" id="kt_modal_apt_edit" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-8 text-black">Update Product Task</h3>
                </div>
                <div id="edit_div"> </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Product Task Edit -->

<input type="hidden" id="product_task_delete">

<!--begin::Modal - Delete variant-->
<div class="modal fade" id="kt_modal_product_task_delete" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-dialog-centered modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                <span id="product_task_delete_message"></span>
            </div>
            <input type="hidden" id="product_task_delete_id">
            <div class="row" id="product_task_delete_button">

            </div>
            <br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete variant-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .err_msg {
        /* background-color: red; */
        border-color: red;
    }
</style>

<script>
    // Display Toastr messages
       @if (Session::has('toastr'))
           var type = "{{ Session::get('toastr')['type'] }}";
           var message = "{{ Session::get('toastr')['message'] }}";
           toastr[type](message);
       @endif
</script>

<script>
    function Edit(val){
        $.ajax({
            url: "{{ route('edit_product_task_map') }}",
            method: "GET",
            data: {
                id:val
            },
            success: function (response) {
                $('#edit_div').html('');
                $('#edit_div').html(response);
                $('.select3').each(function() {
                    $(this).wrap('<div class="position-relative"></div>').select2({
                        dropdownParent: $(this).parent()
                    });
                });
                $('[data-bs-toggle="tooltip"]').tooltip();
            },
            error: function (xhr) {
                console.error(xhr.responseText);
            }
        });
    }
    function edit_close(){
        $('#edit_div').html('');
        location.reload();
    }
</script>


<script>
    $(".list_page").DataTable({
      "ordering": false,
      "paging": false,
      // "aaSorting":[],
      "language": {
          "lengthMenu": "Show _MENU_"
      , }
      ,"dom": "<'row mb-3'" +
        //   "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
        //   "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
          ">" +

          "<'table-responsive'tr>" +

          "<'row'" +
        //   "<'col-sm-12 col-lg-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
        //   "<'col-sm-12 col-lg-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
          ">"
    });
</script>




<script>
    // Global variables
    let productTaskCounter = 0;

    // Field validation function
    function validateFieldmain(selector, errorMessage) {
        let isValid = true;
    
        $(selector).each(function () {
            if (!$(this).is(':visible')) return;
            var errDiv = $(this).closest('.mb-1').find('.error_message');
            let value = $(this).val();
                
            if (value === '') {
                $(this).closest('.accordion-item')
                .find('.accordion-button')
                .removeClass('bg-light')
                .addClass('bg-danger bg-opacity-10 text-danger')
                .css('border-left', '3px solid #dc3545');
                isValid = false;
                errDiv.text(errorMessage);
            } else {
                $('.accordion-button')
                .removeClass('bg-danger bg-opacity-10 text-danger')
                .addClass('bg-light')
                .css('border-left', '');
                errDiv.text('');
            }
        });
    
        return isValid;
    }

    // Main validation function
    function AddValidation() {
        let isValid = true;

        // Product validation
        var product_id = $('#product_id').val();
        if (product_id === '') {
            $('.product_id_err').html('Select Product is required');
            isValid = false;
        } else {
            $('.product_id_err').html('');
        }

        // Task validation
        $('.task_accr_div').each(function() {
            var taskId = $(this).find('.task_class').attr('id');
            var taskIndex = taskId.split('_').pop();
            var isCoding = $(`#code_or_write_${taskIndex}`).is(':checked');

            // Common field validation
            if (!validateFieldmain(`#task_name_${taskIndex}`, 'Task is required.')) {
                isValid = false;
            }
            if (!validateFieldmain(`#task_percentage_${taskIndex}`, 'Percentage is required.')) {
                isValid = false;
            }
            if (!validateFieldmain(`#checklist_${taskIndex}`, 'Checklist is required.')) {
                isValid = false;
            }

            // Type-specific validation
            if (isCoding) {
                // Coding task validation
                if (!validateFieldmain(`#junior_hours_${taskIndex}`, 'Junior hours are required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#mid_hours_${taskIndex}`, 'Mid hours are required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#senior_hours_${taskIndex}`, 'Senior hours are required.')) {
                    isValid = false;
                }
            } else {
                // Writing task validation
                if (!validateFieldmain(`#jr_word_count_${taskIndex}`, 'Junior word count is required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#jr_hours_${taskIndex}`, 'Junior hours are required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#mid_word_count_${taskIndex}`, 'Mid word count is required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#midl_hours_${taskIndex}`, 'Mid hours are required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#sr_word_count_${taskIndex}`, 'Senior word count is required.')) {
                    isValid = false;
                }
                if (!validateFieldmain(`#sr_hours_${taskIndex}`, 'Senior hours are required.')) {
                    isValid = false;
                }
            }
        });

        if (!isValid) {
            return false;
        }

        // Percentage validation
        var totalSelectedValue = 0;
        document.querySelectorAll('.task_percentage').forEach(function (select) {
            const selectId = select.id;
            const indexMatch = selectId.match(/task_percentage_(\d+)/);

            if (!indexMatch) return;

            const index = indexMatch[1];
            const isFlexible = document.querySelector(`#task_flex_${index}`)?.checked;

            if (!isFlexible) {
                const val = Number(select.value);
                if (!isNaN(val)) {
                    totalSelectedValue += val;
                }
            }
        });

        const hasFlexible = Array.from(document.querySelectorAll('[id^="task_flex_"]')).some(cb => cb.checked);

        if (!hasFlexible && totalSelectedValue !== 100) {
            Swal.fire({
                title: 'Warning',
                text: 'Total Task percentage must be exactly 100%.',
                icon: 'warning',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
            return false;
        }
        
        $('.create_btn').hide();
        $('#add_product_task_form').submit();
        
        return true; 
    }

    // Product change handler
    function prd_change(val){
        if(val){
            $('.add_more_row').show();
            $('.task_class').val('');
            $('.check_list_class').val('');
            $('.word_class').val('');
            $('.hour_class').val('').change();
            
            $.ajax({
                url: "{{ route('get_product_variant_data_task') }}",
                type: "GET",
                data: { id: val },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var entityDropdown = $('#variant_id');
                        entityDropdown.empty();
                        entityDropdown.append('<option value="">Select Variant</option>');
                        response.data.forEach(function(Data) {
                            entityDropdown.append($('<option></option>').attr('value', Data.sno).text(Data.product_variant_name));
                        });
                        $('#add_pd_cat').html(response.data_category.product_category_name);
                        $('#cat_id_hide').val(response.data_category.product_category_id);
                        
                        // Set initial checkbox state based on product category
                        const checkbox = $('#code_or_write_0');
                        if(response.data_category.product_category_id == 1){
                            checkbox.prop('checked', false);
                            $('#code_cat').val(1);
                        } else {
                            checkbox.prop('checked', true);
                            $('#code_cat').val(2);
                        }
                        codeWriteLabel(checkbox[0], 0);
                        
                        var Dropdown = $('#variable_id');
                        Dropdown.empty();
                        Dropdown.append('<option value="">Select Variable</option>');
                        
                        // Clear existing tasks
                        const deleteButtons = document.querySelectorAll('.task_del');
                        deleteButtons.forEach(function(button) {
                            button.click();
                        });
                        
                        const task_checklist_del = document.querySelectorAll('.task_checklist_del');
                        task_checklist_del.forEach(function(button) {
                            button.click();
                        });
                        
                        productTaskCounter = 0;
                    }
                },
                error: function(error) {
                    console.error('Error fetching states:', error);
                }
            });
       } else {
            $('.task_class').val('');
            $('.check_list_class').val('');
            $('.word_class').val('');
            $('.hour_class').val('').change();
            $('.add_more_row').hide();
            var entityDropdown = $('#variant_id');
            entityDropdown.empty();
            entityDropdown.append('<option value="">Select Variant</option>');
            $('#add_pd_cat').html('-');
            var Dropdown = $('#variable_id');
            Dropdown.empty();
            Dropdown.append('<option value="">Select Variable</option>');
       }
    }

    // Variant change handler
    function Var_change(val){
        if(val){
            $.ajax({
                url: "{{ route('get_product_variable_data_task') }}",
                type: "GET",
                data: { id: val },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var Dropdown = $('#variable_id');
                        Dropdown.empty();
                        Dropdown.append('<option value="">Select Variable</option>');
                        response.data.forEach(function(Data) {
                            Dropdown.append($('<option></option>').attr('value', Data.sno).text(Data.variable_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching states:', error);
                }
            });
       } else {
            var Dropdown = $('#variable_id');
            Dropdown.empty();
            Dropdown.append('<option value="">Select Variable</option>');
       }
    }

    // Code/Write label toggle
    function codeWriteLabel(checkbox, index) {
        const isChecked = checkbox.checked;
        
        // Update label text
        $('#code_write_label_' + index).html(isChecked ? 'Coding' : 'Writing');
        
        // Show/hide appropriate allocation divs
        if (isChecked) {
            $('#code_cat_div_' + index).show();
            $('#write_cat_div_' + index).hide();
        } else {
            $('#code_cat_div_' + index).hide();
            $('#write_cat_div_' + index).show();
        }
        
        // Clear opposite type fields
        if (isChecked) {
            // Clear write fields
            $('#jr_word_count_' + index).val('');
            $('#jr_hours_' + index).val('').change();
            $('#mid_word_count_' + index).val('');
            $('#midl_hours_' + index).val('').change();
            $('#sr_word_count_' + index).val('');
            $('#sr_hours_' + index).val('').change();
        } else {
            // Clear code fields
            $('#junior_hours_' + index).val('').change();
            $('#mid_hours_' + index).val('').change();
            $('#senior_hours_' + index).val('').change();
        }
    }

    // Flexible task toggle
    function flexibleChange(checkbox, index) {
        var isChecked = checkbox.checked;

        if (isChecked) {
            $(`#flexible_container_${index}`).hide();
            $(`#task_pecentage_hidden_${index}`).val(0);
            $(`#task_percentage_${index}`).val('').change();
            $(`#task_pecentage_${index}`).html('0 %');
        } else {
            $(`#flexible_container_${index}`).show();
            $(`#task_pecentage_hidden_${index}`).val(0);
            $(`#task_pecentage_${index}`).html('0 %');
            $(`#task_percentage_${index}`).val('').change();
        }
    }

    // Percentage change handler
    function per_change(val,id){
        var value = val || 0;
        $('#task_pecentage_'+id).html(value + ' %' );
        $('#task_pecentage_hidden_'+id).val(value);
    }

    // Task name change handler
    function task_name_change(val,id){
        var value = val || '';
        $('#task_accrod_label_'+id).html(value);
    }

    // Create percentage dropdown
    function createPercentageDropdown(uid) {
        var selects = document.querySelectorAll('.task_percentage');
        var totalSelectedValue = 0;
        selects.forEach(function(select) {
            var val = Number(select.value);
            if (!isNaN(val)) {
                totalSelectedValue += val;
            }
        });
        
        var thresholdValue = 100 - totalSelectedValue;
        var step = {{$step}};
        var optionsHTML = '<option value="">Select Percentage</option>';
        
        for (var i = step; i <= thresholdValue; i += step) {
            optionsHTML += `<option value="${i}">${i}</option>`;
        }
        return `
          <select id="task_percentage_${uid}" name="task_percentage_${uid}" class="select3 form-select percentage_class task_percentage" onchange="per_change(this.value, ${uid})">
            ${optionsHTML}
          </select>
        `;
    }

    // Checklist management
    document.addEventListener('click', function (e) {
        const addButton = e.target.closest('.task_checklist_add');
        
        if (addButton) {
            const checklistId = addButton.getAttribute('data-check-list-id');
            const container = addButton.closest('.accordion-body').querySelector('.task_checklist_container');
    
            const newTaskChecklist = `
                <div class="row task_checklist_row">
                    <div class="col-lg-10 mb-1">
                        <label class="text-black fs-6 fw-semibold">Checklist<span class="text-danger">*</span></label>
                        <input type="text" class="form-control check_list_class" name="task_checklist[${checklistId}][]" placeholder="Enter Checklist" />
                        <div class="text-danger error_message"></div>
                    </div>
                    <div class="col-lg-2 mb-1">
                        <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 task_checklist_del">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
                </div>`;
    
            if (container) {
                container.insertAdjacentHTML('beforeend', newTaskChecklist);
            }
        }
    });

    // Delete checklist
    document.addEventListener('click', function (e) {
        if (e.target.closest('.task_checklist_del')) {
            e.target.closest('.row').remove();
        }
    });

    // Word input validation
    document.addEventListener('input', function (e) {
      if (e.target.classList.contains('word_class')) {
        let val = e.target.value.replace(/[^0-9.]/g, '');
        val = val.replace(/^(\.)+/, '');
        val = val.replace(/(\..*)\./g, '$1');
        e.target.value = val;
      }
    });

    // Add new task
    document.getElementById('product_task_add').addEventListener('click', function () {
        let isValid = true;

        // Validate current task before adding new one
        function validateField(selector, errorMessage) {
            $(selector).each(function () {
                const container = $(this).closest('.code_cat_div, .write_cat_div');
                if (container.length > 0 && !container.is(':visible')) {
                    return;
                }

                if ($(this).hasClass('task_percentage')) {
                    const id = $(this).attr('id') || '';
                    const match = id.match(/task_percentage_(\d+)/);
                    if (match) {
                        const index = match[1];
                        if ($(`#task_flex_${index}`).is(':checked')) {
                            return;
                        }
                    }
                }

                const value = $(this).val();
                const errDiv = $(this).closest('.mb-1').find('.error_message');

                if (!value || value.trim() === '') {
                    errDiv.text(errorMessage);
                    isValid = false;
                } else {
                    errDiv.text('');
                }
            });
        }

        // Get current task type and validate accordingly
        var currentTaskIndex = productTaskCounter;
        var isCoding = $(`#code_or_write_${currentTaskIndex}`).is(':checked');
        var cat_id = $('#cat_id_hide').val();

        if (isCoding) {
            var validations = [
                ['.task_class', 'Task is required.'],
                ['.task_percentage', 'Percentage is required.'],
                ['.code_cat_div .hour_class', 'Hour is required.'],
                ['.check_list_class', 'Checklist is required.']
            ];
        } else {
            var validations = [
                ['.task_class', 'Task is required.'],
                ['.task_percentage', 'Percentage is required.'],
                ['.write_cat_div .hour_class', 'Hour is required.'],
                ['.write_cat_div .word_class', 'Word Count is required.'],
                ['.check_list_class', 'Checklist is required.']
            ];
        }

        validations.forEach(([selector, message]) => {
            validateField(selector, message);
        });
        
        if (!isValid) {
            return false;
        }
        
        productTaskCounter++;
        const uid = productTaskCounter;
        
        // Get product category for default settings
        var cat_id = $('#cat_id_hide').val();
        var isCodingDefault = (cat_id == 2);

        // Create allocation divs HTML
        let code_write_div = `
            <div class="mb-6 write_cat_div" id="write_cat_div_${uid}" style="display:none;">
                <div class="pt-4">
                    <div class="row mb-4 bg-label-info rounded py-2 mx-0">
                        <div class="col-lg-4 mb-1"><label>Employee Skill</label></div>
                        <div class="col-lg-4 mb-1"><label>No. of Words Per Page</label></div>
                        <div class="col-lg-4 mb-1"><label>Hours Per Page</label></div>
                    </div>
                    <!-- Junior Row -->
                    <div class="row mb-3 align-items-center">
                        <div class="col-lg-4 mb-1">
                            <div class="d-flex align-items-center">
                                <span class="badge badge-circle bg-primary me-3">
                                    <i class="mdi mdi-account-school-outline text-white"></i>
                                </span>
                                <label class="text-gray-800 fs-6 mb-0">{{$jr_name}}</label>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-1">
                            <input type="text" class="form-control form-control-sm word_class" name="jr_word_count_${uid}" id="jr_word_count_${uid}" placeholder="Enter word count">
                            <div class="text-danger error_message"></div>
                        </div>
                        <div class="col-lg-4 mb-1">
                            <select class="select3 form-select form-select-sm hour_class" name="jr_hours_${uid}" id="jr_hours_${uid}">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                    <!-- Midlevel Row -->
                    <div class="row mb-3 align-items-center">
                        <div class="col-lg-4 mb-1">
                            <div class="d-flex align-items-center">
                                <span class="badge badge-circle bg-warning me-3">
                                    <i class="mdi mdi-account-tie text-white"></i>
                                </span>
                                <label class="text-gray-800 fs-6 mb-0">{{$mid_name}}</label>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-1">
                            <input type="text" class="form-control form-control-sm word_class" placeholder="Enter word count" name="mid_word_count_${uid}" id="mid_word_count_${uid}">
                            <div class="text-danger error_message"></div>
                        </div>
                        <div class="col-lg-4 mb-1">
                            <select class="select3 form-select form-select-sm hour_class" name="midl_hours_${uid}" id="midl_hours_${uid}">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                    <!-- Senior Row -->
                    <div class="row align-items-center">
                        <div class="col-lg-4 mb-1">
                            <div class="d-flex align-items-center">
                                <span class="badge badge-circle bg-success me-3">
                                    <i class="mdi mdi-account-tie-hat text-white"></i>
                                </span>
                                <label class="text-gray-800 fs-6 mb-0">{{$sr_name}}</label>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-1">
                            <input type="text" class="form-control form-control-sm word_class" placeholder="Enter word count" name="sr_word_count_${uid}" id="sr_word_count_${uid}">
                            <div class="text-danger error_message"></div>
                        </div>
                        <div class="col-lg-4 mb-1">
                            <select class="select3 form-select form-select-sm hour_class" name="sr_hours_${uid}" id="sr_hours_${uid}">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-6 code_cat_div" id="code_cat_div_${uid}" style="display:none;">
                <div class="pt-4">
                    <div class="row mb-4 bg-label-info rounded py-2 mx-0">
                        <div class="col-lg-6 mb-1"><label>Employee Skill</label></div>
                        <div class="col-lg-6 mb-1"><label>Hours for 100%</label></div>
                    </div>
                    <!-- Junior Row -->
                    <div class="row mb-3 align-items-center">
                        <div class="col-lg-6 mb-1">
                            <span class="badge badge-circle bg-primary me-3">
                                <i class="mdi mdi-account-school-outline text-white"></i>
                            </span>
                            <label for="junior_percent_${uid}">{{$jr_name}}</label>
                        </div>
                        <div class="col-lg-6 mb-1">
                            <select id="junior_hours_${uid}" name="junior_hours_${uid}" class="select3 form-select form-select-sm hour_class">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                    <!-- Midlevel Row -->
                    <div class="row mb-3 align-items-center">
                        <div class="col-lg-6 mb-1">
                            <span class="badge badge-circle bg-warning me-3">
                                <i class="mdi mdi-account-tie text-white"></i>
                            </span>
                            <label for="mid_percent_${uid}">{{$mid_name}}</label>
                        </div>
                        <div class="col-lg-6 mb-1">
                            <select id="mid_hours_${uid}" name="mid_hours_${uid}" class="select3 form-select form-select-sm hour_class">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                    <!-- Senior Row -->
                    <div class="row align-items-center">
                        <div class="col-lg-6 mb-1">
                            <span class="badge badge-circle bg-success me-3">
                                <i class="mdi mdi-account-tie-hat text-white"></i>
                            </span>
                            <label for="senior_percent_${uid}">{{$sr_name}}</label>
                        </div>
                        <div class="col-lg-6 mb-1">
                            <select id="senior_hours_${uid}" name="senior_hours_${uid}" class="select3 form-select form-select-sm hour_class">
                                <option value="">Select Hours</option>
                                @for ($i = $stephour; $i <= $maxhour; $i +=$stephour) 
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <div class="text-danger error_message"></div>
                        </div>
                    </div>
                </div>
            </div>`;
                        
        // Create percentage dropdown
        var percen = createPercentageDropdown(uid);
    
        // Create new task HTML
        const newProductTask = `
        <div class="row task_accr_div">
            <div class="col-11">
                <div class="accordion mt-4" id="productTaskAccordion_${uid}">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingProductTask_${uid}">
                            <button class="accordion-button collapsed" type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#collapseProductTask_${uid}"
                                aria-expanded="false"
                                aria-controls="collapseProductTask_${uid}">
                                <span id="task_accrod_label_${uid}" class="text-info fs-5 fw-bold me-1"></span>
                                Product Task Details <span class="badge bg-success fs-5 rounded ms-3" id="task_pecentage_${uid}">0 %</span>
                            </button>
                        </h2>
                        <div id="collapseProductTask_${uid}" class="accordion-collapse collapse"
                            aria-labelledby="headingProductTask_${uid}"
                            data-bs-parent="#productTaskAccordion_${uid}">
                            <div class="accordion-body">
                                <div class="mt-4 pe-3">
                                    <div class="product_task_card">
                                        <div>
                                            <div class="row mb-6">
                                                <div class="col-lg-12 mb-1">
                                                    <input type="hidden" id="task_pecentage_hidden_${uid}" name="task_pecentage_hidden_${uid}">
                                                    <label for="task_name_${uid}" class="text-black mb-2 fs-6 fw-semibold">
                                                        Task<span class="text-danger">*</span>
                                                    </label>
                                                    <input type="text" id="task_name_${uid}" name="task_name[${uid}]"  class="form-control form-control-solid task_class" placeholder="Enter Task" onkeyup="task_name_change(this.value,${uid})">
                                                    <div class="text-danger error_message"></div>
                                                </div>
                                                <div class="col-lg-6 mb-1" id="flexible_container_${uid}" style="display:block">
                                                    <label for="task_percentage_${uid}" class="text-black mb-2 fs-6 fw-semibold">
                                                        Percentage<span class="text-danger">*</span>
                                                    </label>
                                                     ${percen}
                                                    <div class="text-danger error_message"></div>
                                                </div>
                                                <div class="col-lg-6 mb-1 d-flex align-items-end justify-content-evenly gap-3">
                                                    <div class="d-flex align-items-center gap-2 bg-info px-3 py-1 rounded">
                                                        <input class="form-check-input me-1 mt-1 fs-4" type="checkbox" id="code_or_write_${uid}" name="code_or_write_${uid}"
                                                            value="1" ${isCodingDefault ? 'checked' : ''} style="border: none;" onclick="codeWriteLabel(this, ${uid})">
                                                        <label class="text-dark mb-1 fs-3 fw-semibold text-white" id="code_write_label_${uid}">${isCodingDefault ? 'Coding' : 'Writing'}</label>
                                                    </div>
                                                    <div class="d-flex align-items-center gap-2 bg-success px-3 py-1 rounded">
                                                        <input class="form-check-input me-1 mt-1 fs-4" type="checkbox" id="task_flex_${uid}" name="task_flex_${uid}"
                                                            value="1" style="border: none;" onclick="flexibleChange(this, ${uid})">
                                                        <label class="text-dark mb-1 fs-3 fw-semibold text-white" id="task_flex_label_${uid}">Flexible</label>
                                                    </div>
                                                </div>
                                            </div>
                                            ${code_write_div}
                                            <!-- Checklist -->
                                            <div class="scroll-y max-h-300px mt-4 pe-3">
                                                <div>
                                                    <div>
                                                        <div class="row task_checklist_row align-items-center">
                                                            <div class="col-lg-10 mb-1">
                                                                <label for="checklist_${uid}" class="text-black fs-6 fw-semibold">
                                                                    Checklist<span class="text-danger">*</span>
                                                                </label>
                                                                <input type="text" id="checklist_${uid}" class="form-control check_list_class" name="task_checklist[${uid}][]" placeholder="Enter Checklist" />
                                                                <div class="text-danger error_message"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="task_checklist_container"></div>
                                                <div class="mt-3">
                                                    <button type="button" class="btn btn-primary task_checklist_add" data-check-list-id="${uid}">
                                                        <i class="mdi mdi-plus me-1"></i> Add Checklist
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-1">
                <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 task_del">
                    <i class="mdi mdi-delete fs-4"></i>
                </a>
            </div>
        </div>
        `;
    
        document.getElementById('product_task_container').insertAdjacentHTML('beforeend', newProductTask);
        
        // Initialize select2
        $('.select3').each(function() {
            $(this).wrap('<div class="position-relative"></div>').select2({
                dropdownParent: $(this).parent()
            });
        });

        // Initialize the new task
        setTimeout(() => {
            const checkbox = document.getElementById(`code_or_write_${uid}`);
            codeWriteLabel(checkbox, uid);
        }, 0);
    });

    // Delete task
    document.addEventListener('click', function (e) {
        if (e.target.closest('.task_del')) {
            e.target.closest('.task_accr_div').remove();
        }
    });
</script>

 <script>
  document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
    el.addEventListener('click', function () {
      // Small delay to allow modal animation to finish
      setTimeout(() => {
        location.reload();
      }, 150);
    });
  });
</script>




@endsection