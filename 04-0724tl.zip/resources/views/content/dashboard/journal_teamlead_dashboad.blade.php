@php
    $configData = Helper::appClasses();
@endphp
@extends('layouts/layoutMaster')

@section('title', 'Journal Executive')
@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

    <head>
        <link rel="stylesheet" href="../../assets/vendor/libs/apex-charts/apex-charts.css" />
    </head>
    <style>
        .fade-in-onload {
            animation: fadeInUp 0.8s ease-out forwards;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(52px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
    <style>
        .table-wrapper {
            max-height: 500px;
            overflow-y: auto;
            overflow-x: hidden;
            border: 1px solid #eee;
        }

        /* Sticky Header */
        .table-header th {
            position: sticky;
            top: 0;
            z-index: 5;
            background: #099dda !important;
            color: white;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        .table tfoot tr {
            bottom: 0px;
            position: sticky;
        }
    </style>

    <style>
        .fade-in-onload {
            animation: fadeInUp 0.8s ease-out forwards;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(52px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .month-input-container {
            width: 130px;
        }

        .cursor-pointer {
            cursor: pointer;
        }

        /* Loading animation */
        .count-up {
            transition: all 0.5s ease;
        }

        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #ccc;
            border-top: 4px solid #007bff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            100% {
                transform: rotate(360deg);
            }
        }


        .loading-overlay {
            position: fixed;
            top: 0;
            /* FIXED */
            margin-top: auto;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 15, 15, 0.8);
            z-index: 9999;
            display: none;
            /* hide by default */
            align-items: center;
            /* vertical center */
            justify-content: center;
            /* horizontal center */
        }
    </style>


    <div class="container-fluid">
        <!-- Month Selector -->
        <div class="row g-3 mb-2">
            <div class="col-lg-12 d-flex align-items-end justify-content-end">
                <div class="month-input-container">
                    <div class="cursor-pointer input-group input-group-merge">
                        <span class="input-group-text bg-label-warning text-black">
                            <i class="mdi mdi-calendar-month-outline fs-4"></i>
                        </span>
                        <input type="text" id="ovr_month_fill"
                            class="cursor-pointer form-control bg-label-warning text-black" value="<?php echo date('M-Y'); ?>"
                            readonly>
                    </div>
                </div>
            </div>
        </div>


        <div class="row g-3">

            <!-- Loading Overlay -->
            <div id="loading-overlay" class="loading-overlay">
                <div class="text-center">
                    <div class="spinner-border text-warning" style="width: 3rem; height: 3rem; margin-top: 250px;"
                        role="status">
                        <span class="visually-hidden text-warning">Loading...</span>
                    </div>
                    <p class="mt-2 text-dark fw-medium text-white">Loading dashboard data...</p>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card rounded shadow w-100">
                    <div class="card-body" style="min-height:129px;">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="d-flex align-items-center justify-content-between flex-shrink-0 ">
                                    <div class="d-flex align-items-center gap-3 ">
                                        <img src="{{ asset('assets/phdizone_images/user_3.png') }}" id="userAvatar"
                                            alt="avatar" class="rounded-circle img-fluid d-flex flex-shrink-0 d-none"
                                            style="width: 80px; height: 80px; object-fit: cover;">
                                        <div id="userIntial"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle d-none"
                                            style="width: 60px; height: 60px;"></div>
                                        <div class="d-flex flex-column ">
                                            <div class="d-flex flex-column">
                                                <label class="fw-semibold fs-6 " style="max-width:600px;">Hey <label
                                                        class="text-black fs-3"
                                                        id="user-name">{{ Auth::user()->staff->staff_name }}
                                                    </label>, <label class="fw-semibold fs-6 text-nowrap">Glad You Back
                                                        Again <span
                                                            class="mdi mdi-creation text-warning"></span></label></label>
                                            </div>
                                            <div class="d-flex align-items-center gap-2 ">
                                                <span class=" fs-7 px-2 fw-semibold"
                                                    style="width: fit-content; background:#e0f2f1; color:#004d40; border:1px solid #004d40; border-radius:3px;"><span
                                                        class="mdi mdi-crown-circle me-1 fs-6"></span>Journal Team
                                                    Lead</span>
                                                <span class=" fs-7 px-2 fw-semibold"
                                                    style="width: fit-content; background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:3px;"><span
                                                        class="mdi mdi-heart-circle me-1 fs-6"></span><span
                                                        id="presentDays">0</span>% Attendence</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 fade-in-onload">
                <div class="row g-3">
                    <div class="col-lg-6">
                        <div class="card rounded shadow w-100" style="overflow: hidden;">
                            <div class="card-body  position-relative" style="min-height:124px;">
                                <div class="d-flex flex-column ">
                                    <div class="d-flex gap-1 align-items-center pt-3">
                                        <label class="text-black fw-semibold fs-1 mb-0" id="Overall-Published">0</label>
                                    </div>
                                    <label class="text-secondary fw-medium fs-6">Overall Published</label>
                                </div>
                                <img src="{{ asset('assets/phdizone_images/dashboard_images/books.png') }}" alt="avatar"
                                    class=" img-fluid position-absolute "
                                    style="width: 135px; height: 135px; object-fit: cover; left:65%; top:-2px;">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card rounded shadow w-100" style="overflow: hidden;">
                            <div class="card-body  position-relative" style="min-height:124px;">
                                <div class="d-flex flex-column ">
                                    <div class="d-flex gap-1 align-items-center pt-3">
                                        <label class="text-black fw-semibold fs-1 mb-0" id="Overall-Submitted">0</label>
                                    </div>
                                    <label class="text-secondary fw-medium fs-6">Overall Submitted</label>
                                </div>
                                <img src="{{ asset('assets/phdizone_images/dashboard_images/booksnew.png') }}"
                                    alt="avatar" class=" img-fluid position-absolute "
                                    style="width: 135px; height: 135px; object-fit: cover;left:65%; top:-2px;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 fade-in-onload ">
                <div class="card  rounded shadow w-100">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-start justify-content-start flex-column">
                            <div class="d-flex gap-1 align-items-center">
                                <label class="text-black fw-semibold fs-1 mb-0" id="Total-Journals">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6">Total Journals</label>
                        </div>
                        <div class="d-flex align-items-center justify-content-center rounded-circle bg-label-info"
                            style="width:52px; height:52px; ">
                            <i class="mdi mdi-file-document-multiple-outline text-info fs-3" style=" font-size:20px;"></i>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-lg-3 fade-in-onload">
                <div class="card  rounded shadow w-100">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-start justify-content-start flex-column">
                            <div class="d-flex gap-1 align-items-center">
                                <label class="text-black fw-semibold fs-1 mb-0" id="Pending-Verification">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6">Pending Verification</label>
                        </div>
                        <div class="d-flex align-items-center justify-content-center rounded-circle bg-label-danger"
                            style="width:52px; height:52px; ">
                            <i class="mdi mdi-file-document-alert-outline text-danger fs-3" style=" font-size:20px;"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 fade-in-onload">
                <div class="card  rounded shadow w-100">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-start justify-content-start flex-column">
                            <div class="d-flex gap-1 align-items-center">
                                <label class="text-black fw-semibold fs-1 mb-0" id="PC-Not-Assigned">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6" >PC Not Assigned</label>
                        </div>
                        <div class="d-flex align-items-center justify-content-center rounded-circle bg-label-warning"
                            style="width:52px; height:52px; ">
                            <i class="mdi mdi-account-remove-outline text-warning fs-3" style=" font-size:20px;"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 fade-in-onload">
                <div class="card  rounded shadow w-100">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-start justify-content-start flex-column">
                            <div class="d-flex gap-1 align-items-center">
                                <label class="text-black fw-semibold fs-1 mb-0" id="Total-Clients">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6">Total Clients</label>
                        </div>
                        <div class="d-flex align-items-center justify-content-center rounded-circle bg-label-success"
                            style="width:52px; height:52px; ">
                            <i class="mdi mdi-account-file-outline text-success fs-3" style=" font-size:20px;"></i>
                        </div>
                    </div>
                </div>
            </div>



            <div class="col-lg-12 fade-in-onload">
                <div class="card rounded  shadow-lg">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <label class="fw-semibold">Team Members Publication And Target Reports <span
                                            class="text-info ms-1 date-year" >{{date('M-Y')}}</span></label>
                                    <label class="fw-semibold badge text-white jcstsffscount"
                                        style="background: black">0</label>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="table-wrapper">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 ">
                                        <thead class="table-header">
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-200px">Members</th>
                                                <th class="min-w-100px ">Published </th>
                                                <th class="min-w-100px  ">Submitted</th>
                                                <th class="min-w-150px ">Allocated Paper</th>
                                                <th class="min-w-100px " data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="">Pending Publications</th>
                                                <th class="min-w-100px " data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="">Target</th>
                                                <th class="min-w-100px ">Achieved</th>
                                                <th class="min-w-100px " data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="">Clients</th>
                                            </tr>
                                        </thead>
                                        <tbody class="table-body text-black fw-semibold fs-7 target_tbody">
                                            <tr>
                                                <td>
                                                    <div class="d-flex justify-content-between align-items-center">
                                                        <div class="d-flex gap-2 align-items-center">
                                                            <img src="{{ asset('assets/phdizone_images/user_3.png') }}"
                                                                alt="avatar" class="rounded-circle img-fluid"
                                                                style="width: 40px; height: 40px; object-fit: cover;">
                                                            <div class="d-flex flex-column">
                                                                <label class="fw-semibold fs-7 text-black">Gopinath
                                                                    P</label>
                                                                <label
                                                                    class="fw-semibold fs-8  badge bg-label-info">Journal
                                                                    Executive</label>
                                                            </div>
                                                        </div>
                                                </td>
                                                <td align="center">
                                                    <div class="d-flex align-items-center gap-1">
                                                        <span class=" px-2  fw-semibold fs-6"
                                                            style="border-radius:4px; background:#f1f8e9; color:#33691e; border:1px solid #33691e; font-weight:600;">45</span>
                                                    </div>
                                                </td>
                                                <td align="center">
                                                    <div class="d-flex align-items-center gap-1">
                                                        <span class=" px-2  fw-semibold fs-6"
                                                            style="border-radius:4px; background:#fff0e0; color:#e65100; border:1px solid #e65100; font-weight:600;">12</span>
                                                    </div>
                                                </td>
                                                <td align="center">
                                                    <label class="text-black fw-semibold fs-6">30</label>
                                                </td>
                                                <td align="center">
                                                    <label class="text-danger fw-semibold fs-6">12</label>
                                                </td>
                                                <td align="center">
                                                    <div class="d-flex align-items-center gap-1">
                                                        <span class=" px-2  fw-semibold fs-6"
                                                            style="border-radius:4px; background:#f1f8e9; color:#33691e; border:1px solid #33691e; font-weight:600;">12</span>
                                                    </div>
                                                </td>
                                                <td align="center">
                                                    <div class="d-flex align-items-center gap-1">
                                                        <span class=" px-2  fw-semibold fs-6"
                                                            style="border-radius:4px; background:#fff0e0; color:#e65100; border:1px solid #e65100; font-weight:600;">45</span>
                                                    </div>
                                                </td>
                                                <td align="center">
                                                    <label class="text-black fw-semibold fs-6">13</label>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 fade-in-onload">
                <div class="card rounded  shadow-lg">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <label class="fw-semibold">Team Members Monthly Journal Status Reports <span
                                            class="text-info ms-1 date-year" >{{date('M-Y')}}</span></label>
                                    <label class="fw-semibold badge text-white jcstsffscount"
                                        style="background: black">0</label>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="table-wrapper">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 ">
                                        <thead class="table-header">
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-200px">Members</th>
                                                <th class="min-w-100px text-center">With Editor</span></th>
                                                {{-- <th class="min-w-100px  ">Submitted</th> --}}
                                                <th class="min-w-100px text-center">Under Review</span></th>
                                                <th class="min-w-100px text-center">Rejected</th>
                                                <th class="min-w-100px text-center">Revision</th>
                                                <th class="min-w-100px text-center">Eproofing</th>
                                                <th class="min-w-100px text-center">Accepted</th>
                                            </tr>
                                        </thead>
                                        <tbody class=" table-body text-black fw-semibold fs-7 status_tbody">
                                        </tbody>
                                        <tfoot>
                                            <tr style="background: #fbe9e7;">
                                                <td align="center">
                                                    <label class="px-3 fw-semibold fs-6"
                                                        style=" background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;">Total</label>
                                                </td>
                                                <td align="center">
                                                    <label class="px-3 fw-semibold fs-6"
                                                        style=" background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;"><label id="totalWithEditor"></label></label
                                                        </td>
                                                <td align="center">
                                                    <label class="px-3 fw-semibold fs-6"
                                                        style=" background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;"><label id="totalUnderReview"></label></label
                                                        </td>
                                                <td align="center">
                                                    <label class="px-3 fw-semibold fs-6"
                                                        style=" background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;"><label id="totalRejected"></label></label>
                                                </td>
                                                <td align="center">
                                                    <label class="px-3 fw-semibold fs-6"
                                                        style=" background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;"><label id="totalRevision"></label></label>
                                                </td>
                                                <td align="center">
                                                    <label class="px-3 fw-semibold fs-6"
                                                        style=" background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;"><label id="totalEproofing"></label></label>
                                                </td>
                                                <td align="center">
                                                    <label class="px-3 fw-semibold fs-6"
                                                        style=" background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;"><label id="totalAccepted"></label></label>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/animejs@3.2.1/lib/anime.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize date picker
            $('#ovr_month_fill').datepicker({
                format: "M-yyyy",
                startView: "months",
                minViewMode: "months",
                autoclose: true,
                todayHighlight: true
            }).on('changeDate', function(e) {
                var selectedMonth = e.format();
                fetchDashboardData(selectedMonth);
            });

            // Initialize tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });

            // Chart instance
            let lineChart = null;

            // Function to fetch dashboard data
            function fetchDashboardData(selectedMonth) {
                showLoading();

                $.ajax({
                    url: '{{ route('journal_team_lead.dashboard.get') }}',
                    type: 'GET',
                    data: {
                        date: selectedMonth
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.status === 200) {
                            updateDashboardData(response.data, response.chartData);
                            // Update month input
                            $('#ovr_month_fill').val(selectedMonth);
                        } else {
                            showError('Failed to load dashboard data');
                        }
                    },
                    error: function(xhr) {
                        console.error('Error:', xhr);
                        showError('An error occurred while loading dashboard data');
                    },
                    complete: function() {
                        hideLoading();
                    }
                });
            }

            // Function to parse integer safely - improved version
            function safeParseInt(value, defaultValue = 0) {
                if (value === null || value === undefined || value === '') {
                    return 0;
                }
                const parsed = parseInt(value);
                return isNaN(parsed) ? defaultValue : parsed;
            }

            // Function to get current value from element safely
            function getCurrentValue(elementId) {
                const element = document.getElementById(elementId);
                if (!element) return 0;

                // Try to get the numeric part from the element
                const text = element.textContent.trim();

                // Remove any non-numeric characters except minus sign
                const numericText = text.replace(/[^0-9-]/g, '');

                return safeParseInt(numericText, 0);
            }

            // Function to update dashboard data with animation
            function updateDashboardData(data, chartData) {
                // Update user name

                let staffImage = data.avatar;
                let staffName = data.userName || 'No Name Provided';
                if (staffImage) {
                    // alert(staffImage);
                    $('#userAvatar').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass(
                        'd-none');
                    $('#userIntial').addClass('d-none');
                } else {
                    let initial = staffName.charAt(0).toUpperCase();
                    // alert(initial);
                    $('#userIntial').text(initial).removeClass('d-none');
                    $('#userAvatar').addClass('d-none');
                }

                $('#user-name').text(staffName || 'N/A');
                $('#presentDays').text(data.presentDays || '0');

                 // Update chart year from selected month
                const monthYear = $('#ovr_month_fill').val();
                const year = monthYear ? monthYear.split('-')[1] : new Date().getFullYear();
                $('.date-year').text(monthYear);

                const Jcstaff = data.JcStaffList;
                const JcStaffCount = data.JcStaffList.length;
                $('.jcstsffscount').html(JcStaffCount);

                const tbody = $('.status_tbody');
                tbody.empty();

                // Totals
                let totals = {
                    withEditor: 0,
                    underReview: 0,
                    rejected: 0,
                    revision: 0,
                    eproofing: 0,
                    accepted: 0
                };

                Jcstaff.forEach(staff => {

                    totals.withEditor += staff.withEditorCount;
                    totals.underReview += staff.underReviewerCount;
                    totals.rejected += staff.rejectedCount;
                    totals.revision += staff.revisionCount;
                    totals.eproofing += staff.eproofingCount;
                    totals.accepted += staff.acceptedCount;

                    tbody.append(`
                                    <tr>
                                        <td>
                                            <div class="d-flex gap-2 align-items-center">
                                                <div class="symbol symbol-35px me-2">
                                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                                        ${staff.staff_avatar || '<div class="symbol-label bg-light-primary">' + (staff.staff_name ? staff.staff_name.charAt(0) : 'U') + '</div>'}
                                                    </div>
                                                </div>
                                                <div class="d-flex flex-column">
                                                    <label class="fw-semibold fs-7 text-black">${staff.staff_name}</label>
                                                    <label class="fw-semibold fs-8 badge bg-label-info">${staff.role_name}</label>
                                                </div>
                                            </div>
                                        </td>

                                        <td class="text-center"><label class="fw-semibold fs-6">${staff.withEditorCount}</label></td>
                                        <td class="text-center"><label class="fw-semibold fs-6">${staff.underReviewerCount}</label></td>
                                        <td class="text-center"><label class="fw-semibold fs-6 text-danger">${staff.rejectedCount}</label></td>
                                        <td class="text-center"><label class="fw-semibold fs-6">${staff.revisionCount}</label></td>
                                        <td class="text-center"><label class="fw-semibold fs-6">${staff.eproofingCount}</label></td>
                                        <td class="text-center"><label class="fw-semibold fs-6">${staff.acceptedCount}</label></td>
                                    </tr>
                                `);
                });

                $('#totalWithEditor').text(totals.withEditor);
                $('#totalUnderReview').text(totals.underReview);
                $('#totalRejected').text(totals.rejected);
                $('#totalRevision').text(totals.revision);
                $('#totalEproofing').text(totals.eproofing);
                $('#totalAccepted').text(totals.accepted);


                const Tar_tbody = $('.target_tbody');
                Tar_tbody.empty();

                // Totals
                let Tartotals = {
                    published: 0,
                    Submitted: 0,
                    total_journals: 0,
                    pending_verification: 0,
                    pc_not_assign: 0,
                    total_cilents: 0
                };

                Jcstaff.forEach(Tarstaff => {

                    Tartotals.published += Tarstaff.publishedCount;
                    Tartotals.Submitted += Tarstaff.submittedCount;
                    Tartotals.total_journals += Tarstaff.total_journals;
                    Tartotals.pending_verification += Tarstaff.pending_verification;
                    Tartotals.pc_not_assign += Tarstaff.pc_not_assign;
                    Tartotals.total_cilents += Tarstaff.overallClients;

                    Tar_tbody.append(`
                                    <tr>
                                        <td>
                                            <div class="d-flex gap-2 align-items-center">
                                                <div class="symbol symbol-35px me-2">
                                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                                        ${Tarstaff.staff_avatar || '<div class="symbol-label bg-light-primary">' + (Tarstaff.staff_name ? Tarstaff.staff_name.charAt(0) : 'U') + '</div>'}
                                                    </div>
                                                </div>
                                                <div class="d-flex flex-column">
                                                    <label class="fw-semibold fs-7 text-black">${Tarstaff.staff_name}</label>
                                                    <label class="fw-semibold fs-8 badge bg-label-info">${Tarstaff.role_name}</label>
                                                </div>
                                            </div>
                                        </td>

                                        <td align="center">
                                            <div class="d-flex align-items-center gap-1">
                                                <span class=" px-2  fw-semibold fs-6"
                                                    style="border-radius:4px; background:#f1f8e9; color:#33691e; border:1px solid #33691e; font-weight:600;">${Tarstaff.publishedCount}</span>
                                            </div>
                                        </td>
                                        <td align="center">
                                            <div class="d-flex align-items-center gap-1">
                                                <span class=" px-2  fw-semibold fs-6"
                                                    style="border-radius:4px; background:#fff0e0; color:#e65100; border:1px solid #e65100; font-weight:600;">${Tarstaff.submittedCount}</span>
                                            </div>
                                        </td>
                                        <td align="center">
                                            <label class="text-black fw-semibold fs-6">${Tarstaff.allocatedPaper}</label>
                                        </td>
                                        <td align="center">
                                            <label class="text-danger fw-semibold fs-6">${Tarstaff.pendingPublication}</label>
                                        </td>
                                        <td align="center">
                                            <div class="d-flex align-items-center gap-1">
                                                <span class=" px-2  fw-semibold fs-6"
                                                    style="border-radius:4px; background:#f1f8e9; color:#33691e; border:1px solid #33691e; font-weight:600;">${Tarstaff.target}</span>
                                            </div>
                                        </td>
                                        <td align="center">
                                            <div class="d-flex align-items-center gap-1">
                                                <span class=" px-2  fw-semibold fs-6"
                                                    style="border-radius:4px; background:#fff0e0; color:#e65100; border:1px solid #e65100; font-weight:600;">${Tarstaff.publishedCount}</span>
                                            </div>
                                        </td>
                                        <td align="center">
                                            <label class="text-black fw-semibold fs-6">${Tarstaff.overallClients}</label>
                                        </td>
                                    </tr>
                                `);
                });


                $('#Overall-Published').text(Tartotals.published);
                $('#Overall-Submitted').text(Tartotals.Submitted);
                $('#Total-Journals').text(Tartotals.total_journals);

                $('#Pending-Verification').text(Tartotals.pending_verification);
                $('#PC-Not-Assigned').text(Tartotals.pc_not_assign);
                $('#Total-Clients').text(Tartotals.total_cilents);


            }

            // Function to animate counter
            function animateCounter(elementId, targetValue) {
                const element = document.getElementById(elementId);
                if (!element) {
                    console.warn(`Element with id ${elementId} not found`);
                    return;
                }

                // Get current value safely
                const currentValue = getCurrentValue(elementId);

                // If target is NaN, set to 0
                const targetNum = isNaN(targetValue) ? 0 : targetValue;

                // If values are the same, just set the text
                if (currentValue === targetNum) {
                    element.textContent = targetNum;
                    return;
                }

                // Use anime.js for smooth animation if available
                if (typeof anime !== 'undefined') {
                    anime({
                        targets: {
                            value: currentValue
                        },
                        value: targetNum,
                        round: 1,
                        easing: 'easeOutQuart',
                        duration: 800,
                        update: function(anim) {
                            element.textContent = Math.floor(anim.animatedValue);
                        }
                    });
                } else {
                    // Fallback to simple update
                    element.textContent = targetNum;
                }
            }


            // Loading functions
            function showLoading() {
                $('#loading-overlay').fadeIn(300);
            }

            function hideLoading() {
                $('#loading-overlay').fadeOut(300);
            }

            function showError(message) {
                // Create error toast notification
                const toast = document.createElement('div');
                toast.className = 'toast align-items-center text-bg-danger border-0 position-fixed top-0 end-0 m-3';
                toast.setAttribute('role', 'alert');
                toast.setAttribute('aria-live', 'assertive');
                toast.setAttribute('aria-atomic', 'true');

                toast.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">
                        <i class="mdi mdi-alert-circle me-2"></i> ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            `;

                document.body.appendChild(toast);
                const bsToast = new bootstrap.Toast(toast);
                bsToast.show();

                // Remove toast after it's hidden
                toast.addEventListener('hidden.bs.toast', function() {
                    document.body.removeChild(toast);
                });
            }

            // Initialize dashboard with current month data
            fetchDashboardData('<?php echo date('M-Y'); ?>');
        });
    </script>


@endsection
