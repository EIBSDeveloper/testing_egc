@extends('layouts/layoutMaster')

@section('title', 'Manage Login Approval')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/toastr/toastr.scss', 'resources/assets/vendor/libs/animate-css/animate.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js', 'resources/assets/vendor/libs/clipboard/clipboard.js', 'resources/assets/vendor/libs/toastr/toastr.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }

        .otp {
            text-transform: uppercase;
            font-weight: bold;
            letter-spacing: 2px;
        }
    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Login Approval</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center">
                                <i class="mdi mdi-home-outline text-body fs-4"></i>
                            </a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Branch Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <a href="javascript:;" class="btn btn-sm fw-semibold btn-primary text-white" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_create_code" onclick="generateCouponCodeNew()">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Generate Code
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="row mb-4">
                    @php $perpage_count = $perpage ? $perpage : 10; @endphp
                    <div class="col-lg-2">
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                            onchange="sort_filter(this.value);">
                            @php
                                $options = [10, 25, 100, 500]; // Define available options
                            @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}"
                                    @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                    @php echo $option; @endphp
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-lg-10 d-flex align-items-end justify-content-end">
                        <form id="search_form" method="POST" action="/login-approval">
                            @csrf
                            <div class="d-flex align-items-center gap-2 mt-2">
                                <div>
                                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                    <input type="hidden" name="filter_on" value="1">
                                    <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                        id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                    <input type="text" class="form-control" id="search_fill" name="search_fill"
                                        value="{{ $search_fill ?? '' }}" placeholder="Enter Search" />
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                    onclick="search_filter_func()">Search</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-12 table-responsive">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top fw-semibold fs-6 gs-0 bg-primary">
                                <th class="min-w-120px">Timer Not Stopped</th>
                                <th class="min-w-120px">Job Role</th>
                                <th class="min-w-100px">Created Login Code</th>
                                <th class="min-w-100px">Expiry (m)</th>
                                <th class="min-w-100px">Created At</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                            <!-- Dynamic content will be loaded here -->
                            @foreach ($ListTable as $approval)
                                <tr>
                                    <td>
                                        <label class="badge bg-label-info fs-7 text-black fw-semibold">
                                            {{ $approval->staff_name ?? 'Unknown' }}
                                        </label>
                                    </td>
                                    <td>
                                        <label class="text-black fw-semibold">
                                            {{ $approval->job_position_name ?? 'N/A' }}
                                        </label>
                                    </td>
                                    <td>
                                        <div class="d-block">
                                            <label class="text-info fs-8 fw-semibold me-1"
                                                id="coup_code_val_td_{{ $approval->sno }}">
                                                {{ $approval->login_code }}
                                            </label>
                                            <a href="javascript:;" class="cpy-btn btn btn-sm btn-label-primary px-2 py-1"
                                                data-clipboard-action="copy"
                                                data-clipboard-target="#coup_code_val_td_{{ $approval->sno }}">
                                                <i class="mdi mdi-content-copy fs-6 text-black"></i>
                                            </a>
                                        </div>
                                    </td>
                                    <td>
                                        @php
                                            $remaining = $approval->getRemainingTime();
                                            $statusClass = $remaining > 0 ? 'bg-label-danger' : 'bg-label-secondary';
                                            $statusText =
                                                $remaining > 0
                                                    ? 'more in ' . $remaining . ' min' . ($remaining > 1 ? 's' : '')
                                                    : 'Expired';
                                        @endphp
                                        <label class="badge {{ $statusClass }} fw-semibold fs-7">{{ $statusText }}</label>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-1 align-items-center">
                                            <label>{{ $approval->created_at->format('d-M-Y') }}</label>
                                            <label class="text-secondary">|</label>
                                            <label
                                                class="text-secondary">{{ $approval->created_at->format('H:i') }}</label>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Code Modal -->
    <div class="modal fade" id="kt_modal_create_code" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <div class="modal-dialog modal-md">
            <div class="modal-content rounded">
                <div class="modal-header justify-content-end border-0 pb-0">
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                    </div>
                </div>
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Generate Code</h3>
                    </div>
                    <form id="generate_code_form">
                        @csrf
                        <div class="row mb-6">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Staff<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="staff_id" name="staff_id" required>
                                    <option value="">Select Staff</option>
                                    @foreach ($staffList as $staff)
                                        <option value="{{ $staff->sno }}">{{ $staff->staff_name }} -
                                            {{ $staff->job_position_name }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Generated Code</label>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mb-1 d-flex align-items-center gap-2" id="coup_gen_box">
                                            <label class="text-success fs-4 fw-semibold m-0" id="coup_code_label"></label>
                                            <input type="hidden" name="login_code" id="generated_code_input" required>
                                        </div>
                                        <p class="text-muted fs-7 mb-0">Code will be generated automatically</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Expiry Time<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="expiry_time" name="expiry_time" required>
                                    <option value="">Select Expiry Time</option>
                                    <option value="1">1 min</option>
                                    <option value="2">2 min</option>
                                    <option value="5">5 min</option>
                                    <option value="10">10 min</option>
                                    <option value="15">15 min</option>
                                    <option value="30">30 min</option>
                                    <option value="60">60 min</option>
                                </select>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <button type="button" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary" id="save_code_btn">Done</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const clipboardList = [].slice.call(document.querySelectorAll('.cpy-btn'));

            if (ClipboardJS) {
                clipboardList.map(function(clipboardEl) {
                    const clipboard = new ClipboardJS(clipboardEl);
                    clipboard.on('success', function(e) {
                        if (e.action == 'copy') {
                            toastr['success']('', 'Copied to Clipboard!!');
                        }
                    });
                });
            } else {
                clipboardList.map(function(clipboardEl) {
                    clipboardEl.setAttribute('disabled', true);
                });
            }
        });
    </script>

    <script>
        // Generate coupon code function
        function generateCouponCodeNew() {
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            let couponCode = '';

            for (let i = 0; i < 6; i++) {
                couponCode += characters.charAt(
                    Math.floor(Math.random() * characters.length)
                );
            }
            // alert(couponCode)

            $('#coup_code_label').html(couponCode);
            $('#generated_code_input').val(couponCode);
        }
        // Save code via AJAX
        $('#generate_code_form').submit(function(e) {
            e.preventDefault();

            const staffId = $('#staff_id').val();
            const expiryTime = $('#expiry_time').val();
            const loginCode = $('#generated_code_input').val();

            if (!staffId || !expiryTime || !loginCode) {
                toastr['error']('Please fill all required fields');
                return;
            }

            $('#save_code_btn').prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm"></span> Saving...');

            $.ajax({
                url: 'login-approval/store',
                type: 'POST',
                data: {
                    staff_id: staffId,
                    expiry_time: expiryTime,
                    login_code: loginCode,
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    if (response.success) {
                        toastr['success'](response.message);
                        $('#kt_modal_create_code').modal('hide');

                        // Reload page to show new entry
                        setTimeout(function() {
                            window.location.reload();
                        }, 1000);
                    } else {
                        toastr['error'](response.message);
                        $('#save_code_btn').prop('disabled', false).html('Done');
                    }
                },
                error: function(xhr) {
                    if (xhr.status === 422) {
                        const errors = xhr.responseJSON.errors;
                        $.each(errors, function(key, value) {
                            toastr['error'](value[0]);
                        });
                    } else {
                        toastr['error']('Failed to save code');
                    }
                    $('#save_code_btn').prop('disabled', false).html('Done');
                }
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const inputs = document.querySelectorAll('.otp');

            inputs.forEach((input, index) => {

                // Allow A-Z and 0-9 only, auto CAPS, auto move
                input.addEventListener('input', () => {
                    input.value = input.value
                        .replace(/[^a-zA-Z0-9]/g, '')
                        .toUpperCase();

                    if (input.value && index < inputs.length - 1) {
                        inputs[index + 1].focus();
                    }
                });

                // Backspace → previous
                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Backspace' && !input.value && index > 0) {
                        inputs[index - 1].focus();
                    }
                });

                // Paste full code (A-Z / 0-9)
                input.addEventListener('paste', (e) => {
                    const paste = e.clipboardData
                        .getData('text')
                        .replace(/[^a-zA-Z0-9]/g, '')
                        .toUpperCase();

                    paste.split('').forEach((char, i) => {
                        if (inputs[i]) inputs[i].value = char;
                    });

                    e.preventDefault();
                });

            });
        });
    </script>
    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>
@endsection
