@php
    $helper = new \App\Helpers\Helpers();
@endphp
@extends('layouts/layoutMaster')

@section('title', 'Project Coordinator Dashboard')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
    <style>
        /* Default for large screens */
        .row.header-row {
            height: 150px;
            background-color: #099DDA;
        }

        .row.header-row .position-absolute {
            top: 60px;
        }

        .empty-space {
            height: 5px;
        }

        /* Loading Spinner */
        .loading-spinner {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 200px;
        }

        /* Responsive adjustments */
        @media (max-width: 1440px) {
            .row.header-row {
                height: 220px;
            }

            .row.header-row .position-absolute {
                top: 80px;
                left: 5px;
            }

            .empty-space {
                height: 50px;
            }
        }

        @media (max-width: 1200px) {
            .header-row .col-xl-2 {
                flex: 0 0 33.333333%;
                max-width: 33.333333%;
            }

            .table_1 {
                min-width: 1100px !important;
            }
        }

        @media (max-width: 992px) {
            .header-row .col-lg-2 {
                flex: 0 0 50%;
                max-width: 50%;
            }

            .pending-approvals .col-lg-3 {
                flex: 0 0 50%;
                max-width: 50%;
            }

            .header-user-info {
                flex-direction: column;
                align-items: flex-start !important;
            }

            .header-user-info .avatar {
                margin-bottom: 10px;
            }

            .date-filter-container {
                width: 100% !important;
                margin-top: 15px;
            }

            .table_1 {
                min-width: 900px !important;
            }

            .table_1 thead th,
            .table_1 tbody td {
                padding: 4px !important;
                font-size: 0.75rem !important;
            }

            .table_1-container {
                max-height: 500px !important;
            }
        }

        @media (max-width: 768px) {
            .row.header-row {
                height: auto;
                min-height: 280px;
                padding: 15px 0;
            }

            .row.header-row .position-absolute {
                position: static !important;
                top: 0;
                left: 0;
            }

            .header-row .col-md-6 {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .pending-approvals .col-md-6 {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .empty-space {
                height: 100px;
            }

            .header-content {
                flex-direction: column;
            }

            .user-info-section {
                width: 100%;
                margin-bottom: 20px;
            }

            .date-filter-section {
                width: 100%;
            }

            .header-stats {
                padding-left: 15px !important;
                padding-right: 15px !important;
            }

            .table_1 {
                min-width: 700px !important;
            }

            .staff-cell img {
                width: 35px !important;
                height: 35px !important;
            }
        }

        @media (max-width: 576px) {
            .header-row .col-sm-12 {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .pending-approvals .col-sm-6 {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .empty-space {
                height: 80px;
            }

            .card-label {
                font-size: 0.85rem !important;
            }

            .stat-number {
                font-size: 1.75rem !important;
            }

            .pending-number {
                font-size: 2.5rem !important;
            }

            .table_1 {
                min-width: 600px !important;
            }
        }

        @media (max-width: 425px) {
            .row.header-row {
                height: auto;
                min-height: 350px;
            }

            .empty-space {
                height: 0px;
            }

            .stat-number {
                font-size: 1.5rem !important;
            }

            .pending-number {
                font-size: 2rem !important;
            }
        }

        @media (max-width: 375px) {
            .row.header-row {
                min-height: 380px;
            }

            .empty-space {
                height: 200px;
            }
        }

        /* Responsive table container */
        .table-responsive-container {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            max-width: 100%;
            position: relative;
            margin: 0 -15px;
            padding: 0 15px;
        }

        /* Adjust columns for small screens */
        .row.header-row .col-xl-3,
        .row.header-row .col-lg-3,
        .row.header-row .col-md-6,
        .row.header-row .col-sm-12 {
            margin-bottom: 0.5rem;
        }

        /* Card hover effects */
        .card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        /* Scrollbar styling */
        .table_1-container::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        .table_1-container::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        .table_1-container::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }

        .table_1-container::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
    </style>

    <style>
        /* Desktop table styles */
        .table_1-container {
            overflow-x: auto;
            overflow-y: auto;
            max-height: 600px;
            position: relative;
            border: 1px solid #dee2e6;
            border-radius: 8px;
        }

        .table_1 {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
            min-width: 1400px;
            margin: 0;
        }

        .table_1 thead th,
        .table_1 tbody td {
            position: relative;
            z-index: 1;
            padding: 8px;
            white-space: nowrap;
            border: 1px solid #dee2e6;
        }

        .table_1 thead th {
            position: sticky;
            top: 0;
            background: #099dda;
            color: #fff;
            z-index: 3;
            font-size: 0.85rem;
            font-weight: 600;
            text-align: center;
            vertical-align: middle;
            border-bottom: 2px solid #099dda;
        }

        .table_1 tbody td {
            background: #fff;
            color: #000;
            font-size: 0.9rem;
            text-align: center;
            vertical-align: middle;
        }

        .table_1 thead th:first-child {
            position: sticky;
            left: 0;
            background: #099dda;
            z-index: 5;
        }

        .table_1 tbody td:first-child {
            position: sticky;
            left: 0;
            background: #fff;
            z-index: 4;
            border-right: 2px solid #dee2e6;
        }

        .table_1 thead th:first-child,
        .table_1 tbody td:first-child {
            min-width: 200px;
        }

        /* Highlight today's date */
        .bg-warning.text-dark {
            background-color: #ffc107 !important;
            color: #000 !important;
            font-weight: bold;
        }

        /* Zero tasks styling */
        .bg-danger.text-white {
            background-color: #dc3545 !important;
            color: #fff !important;
        }

        /* Weekend styling */
        .bg-light-success {
            background-color: rgba(40, 167, 69, 0.1) !important;
        }

        /* Future days styling */
        .bg-light.text-muted {
            background-color: #f8f9fa !important;
            color: #6c757d !important;
            opacity: 0.8;
        }

        /* Staff cell styling */
        .staff-cell {
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 200px;
        }

        .staff-cell img {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #dee2e6;
        }

        .staff-info {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .staff-name {
            font-weight: 600;
            font-size: 0.9rem;
            color: #333;
        }

        .staff-role {
            font-size: 0.75rem;
            color: #666;
            background-color: #e3f2fd;
            padding: 2px 8px;
            border-radius: 12px;
            margin-top: 2px;
        }
    </style>

    <!-- Loading Spinner -->
    <div id="loadingSpinner" class="loading-spinner d-none">
        <div class="text-center">
            <div class="spinner-border text-warning" style="width: 3rem; height: 3rem; margin-top: 250px;" role="status">
                <span class="visually-hidden text-secondary">Loading...</span>
            </div>
            <p class="mt-2 text-dark fw-medium text-primary">Loading dashboard data...</p>
        </div>
    </div>

    <!-- Dashboard Content -->
    <div class="dashboard-content">
        <div class="row header-row gy-3 position-relative mb-15">
            <div class="d-flex header-content align-items-start justify-content-between gap-2 mb-4 px-3 px-md-0">
                <div class="user-info-section d-flex align-items-center flex-wrap gap-3 mb-2">
                    @php
                        if (
                            Auth::user()->staff->staff_image != '' &&
                            file_exists(public_path('staff_images/' . Auth::user()->staff->staff_image))
                        ) {
                            $staff_image =
                                '<div class="avatar avatar-xl flex-shrink-0"><img src="' .
                                asset('staff_images/' . Auth::user()->staff->staff_image) .
                                '" alt="Staff" class="rounded-circle img-fluid" style="width: 40px; height: 40px; object-fit: cover;" /></div>';
                        } else {
                            $initial = strtoupper(substr(Auth::user()->staff->staff_name, 0, 1));
                            $staff_image =
                                '<div class="avatar-initial rounded-circle bg-info fs-1 p-2 text-white">' .
                                $initial .
                                '</div>';
                        }
                    @endphp
                    {!! $staff_image !!}
                    <div class="d-flex flex-column flex-grow-1">
                        <label class="text-white fw-semibold fs-5 mb-1 text-wrap"
                            style="max-width: 400px;">{{ Auth::user()->staff->staff_name }}</label>
                        <label class="text-black bg-white p-2 border rounded badge fw-semibold mb-0" id="userRole">Project
                            Coordinator</label>
                    </div>
                </div>
                <div class="date-filter-section d-flex align-items-center justify-content-end mb-1 gap-2">
                    <div class="date-filter-container">
                        <div class="cursor-pointer input-group input-group-merge">
                            <span class="input-group-text bg-label-warning text-black"><i
                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="ovr_year_fill"
                                class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class w-100px"
                                value="<?php echo date('M-Y'); ?>" readonly onchange="loadDashboardData(this.value)">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row header-stats g-3 mt-0 ps-6 pe-6">
                <!-- Total Services Card -->
                <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 mb-1">
                    <div class="card rounded h-100" style="border-bottom:5px solid #e35b5b;">
                        <div class="card-body p-2">
                            <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap">
                                <div
                                    class="d-flex align-items-start flex-column justify-content-center gap-0 text-center text-md-start">
                                    <label class="fw-semibold mb-0 stat-number total-services-count"
                                        style="font-size: 2.25rem;" id="totalServicesCount">0</label>
                                    <label class="fw-semibold fs-7 text-dark mb-0 card-label">Services</label>
                                </div>
                                <span class="p-2 rounded-circle badge bg-gray-200">
                                    <i class="mdi mdi-locker-multiple fs-4" style="color: #e35b5b"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Total Journals Card -->
                <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 mb-1">
                    <div class="card rounded h-100" style="border-bottom:5px solid #4ec5b3;">
                        <div class="card-body p-2">
                            <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap">
                                <div
                                    class="d-flex align-items-start flex-column justify-content-center gap-0 text-center text-md-start">
                                    <label class="fw-semibold mb-0 stat-number" style="font-size: 2.25rem;"
                                        id="totalJournalsCount">0</label>
                                    <label class="fw-semibold fs-7 text-dark mb-0 card-label">Journals</label>
                                </div>
                                <span class="p-2 rounded-circle badge bg-gray-200">
                                    <i class="mdi mdi-newspaper-variant-outline fs-4" style="color: #4ec5b3"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- New Request Card -->
                <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 mb-1">
                    <div class="card rounded h-100" style="border-bottom:5px solid #14cee1;">
                        <div class="card-body p-2">
                            <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap">
                                <div
                                    class="d-flex align-items-start flex-column justify-content-center gap-0 text-center text-md-start">
                                    <label class="fw-semibold mb-0 stat-number" style="font-size: 2.25rem;"
                                        id="newRequestCount">0</label>
                                    <label class="fw-semibold fs-7 text-dark mb-0 card-label">Requirements</label>
                                </div>
                                <span class="p-2 rounded-circle badge bg-gray-200">
                                    <i class="mdi mdi-file-arrow-left-right-outline fs-4" style="color: #14cee1"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Total Tasks Card -->
                <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 mb-1">
                    <div class="card rounded h-100" style="border-bottom:5px solid #86018f;">
                        <div class="card-body p-2">
                            <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap">
                                <div
                                    class="d-flex align-items-start flex-column justify-content-center gap-0 text-center text-md-start">
                                    <label class="fw-semibold mb-0 stat-number" style="font-size: 2.25rem;"
                                        id="totalTasksCount">0</label>
                                    <label class="fw-semibold fs-7 text-dark mb-0 card-label">Tasks</label>
                                </div>
                                <span class="p-2 rounded-circle badge bg-gray-200">
                                    <i class="mdi mdi-book-clock-outline fs-4" style="color: #86018f"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- QC Verification Card -->
                <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 mb-1">
                    <div class="card rounded h-100" style="border-bottom:5px solid #66ad25;">
                        <div class="card-body p-2">
                            <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap">
                                <div
                                    class="d-flex align-items-start flex-column justify-content-center gap-0 text-center text-md-start">
                                    <label class="fw-semibold mb-0 stat-number" style="font-size: 2.25rem;"
                                        id="qcVerificationCount">0</label>
                                    <label class="fw-semibold fs-7 text-dark mb-0 card-label">QC Verification</label>
                                </div>
                                <span class="p-2 rounded-circle badge bg-gray-200">
                                    <i class="mdi mdi-finance fs-4" style="color: #66ad25"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>



                <!-- Rework Task Card -->
                <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 mb-1">
                    <div class="card rounded h-100" style="border-bottom:5px solid #1749a5;">
                        <div class="card-body p-2">
                            <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap">
                                <div
                                    class="d-flex align-items-start flex-column justify-content-center gap-0 text-center text-md-start">
                                    <label class="fw-semibold mb-0 stat-number" style="font-size: 2.25rem;"
                                        id="reworkTaskCount">0</label>
                                    <label class="fw-semibold fs-7 text-dark mb-0 card-label">Rework Task</label>
                                </div>
                                <span class="p-2 rounded-circle badge bg-gray-200">
                                    <i class="mdi mdi-clock-edit-outline fs-4" style="color: #1749a5"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>

        <div class="empty-space"></div>

        <!-- Pending & Approvals Section -->
        <div class="row pending-approvals gy-3 px-3 mb-2">
            <div class="col-12">
                <label class="fs-5 text-black fw-semibold mb-3">Pendings & Approvals</label>
            </div>
            <a href="/requirement_management/manage_requirement" class="col-lg-3 col-md-6 col-sm-6 mb-2">
                <div class="dark-card rounded-3 h-100 bg-label-info">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h2 class="fw-bold display-5 mb-1 text-info" id="unassignedRequirementsCount">0</h2>
                                <p class="text-black mb-0">Unassigned Requirements <i
                                        class="mdi mdi-chevron-right text-info fs-4"></i></p>
                            </div>
                            <div class="bg-label-light bg-opacity-25 p-3 rounded-circle">
                                <i class="mdi mdi-file-document-outline text-info fs-2"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            <a href="/requirement_management/manage_requirement" class="col-lg-3 col-md-6 col-sm-6 mb-2">
                <div class="dark-card rounded-3 h-100 bg-label-success">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h2 class="fw-bold display-5 mb-1 text-success" id="awaitingApprovalsCount">0</h2>
                                <p class="text-black mb-0">Awaiting Approvals <i
                                        class="mdi mdi-chevron-right text-success fs-4"></i></p>
                            </div>
                            <div class="bg-label-light bg-opacity-25 p-3 rounded-circle">
                                <i class="mdi mdi-check-decagram-outline text-success fs-2"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            <a href="/production_management/lead_appointment" class="col-lg-3 col-md-6 col-sm-6 mb-2">
                <div class="dark-card rounded-3 h-100 bg-label-primary">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h2 class="fw-bold display-5 mb-1 text-primary" id="unassignedAppointmentsCount">0</h2>
                                <p class="text-black mb-0">Unassigned Appointments <i
                                        class="mdi mdi-chevron-right text-primary fs-4"></i></p>
                            </div>
                            <div class="bg-label-light bg-opacity-25 p-3 rounded-circle">
                                <i class="mdi mdi-calendar-clock text-primary fs-2"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            <a href="/manage_revision" class="col-lg-3 col-md-6 col-sm-6 mb-2">
                <div class="dark-card rounded-3 h-100 bg-label-danger">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h2 class="fw-bold display-5 mb-1 text-danger" id="unassignedRevisionsCount">0</h2>
                                <p class="text-black mb-0">Unassigned Revisions <i
                                        class="mdi mdi-chevron-right text-danger fs-4"></i></p>
                            </div>
                            <div class="bg-label-light bg-opacity-25 p-3 rounded-circle">
                                <i class="mdi mdi-pencil-circle text-danger fs-2"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>

        <style>
            .dark-card {
                border: none;
                cursor: pointer;
                background: #fff;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }

            .dark-card:hover {
                background: linear-gradient(135deg, #9ca7b6 0%, #b1b3b6 100%);
                transform: translateY(-2px);
                transition: all 0.3s ease;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            }

            .bg-label-info {
                background-color: rgba(23, 162, 184, 0.1) !important;
            }

            .bg-label-success {
                background-color: rgba(40, 167, 69, 0.1) !important;
            }

            .bg-label-primary {
                background-color: rgba(0, 123, 255, 0.1) !important;
            }

            .bg-label-danger {
                background-color: rgba(220, 53, 69, 0.1) !important;
            }
        </style>

        <!-- Monthly Production Task Count Table -->
        <div class="row gy-3 px-3 mb-2">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <label class="fs-5 text-black fw-semibold">Monthly Production Task Count</label>
                    <div class="d-flex align-items-center gap-2">
                        <span class="badge bg-warning text-dark">Today</span>
                        <span class="badge bg-danger text-white">Zero Tasks</span>
                        <span class="badge bg-info text-white">Future Task</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 mb-2">
                <div class="card rounded">
                    <div class="card-body p-2">
                        <!-- Desktop Table View -->
                        <div class="table_1-container">
                            <table
                                class="table_1 table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page"
                                id="monthlyTaskTable">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-200px text-center">Staff</th>
                                        <!-- Dynamic headers will be added here -->
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold text-center" id="monthlyTaskTableBody">
                                    <!-- Data will be loaded dynamically via AJAX -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Initialize DataTable
        $(document).ready(function() {
            // Initialize date picker
            initializeDatePicker();

            // Load initial data
            loadDashboardData($("#ovr_year_fill").val());
        });

        // Function to initialize date picker
        function initializeDatePicker() {
            $("#ovr_year_fill").datepicker({
                format: "M-yyyy",
                startView: "months",
                minViewMode: "months",
                autoclose: true,
                todayHighlight: true,
                orientation: "bottom auto"
            }).on('changeDate', function(e) {
                loadDashboardData($(this).val());

            });
        }

        // Function to update desktop task table dynamically based on month
        function updateDesktopTaskTable(tasks, monthYear) {
            const tableBody = $("#monthlyTaskTableBody");
            const tableHead = $("#monthlyTaskTable thead tr");
            tableBody.empty();

            // Parse the month-year string
            const monthInfo = monthYear || "Jan-2026";
            const [monthName, year] = monthInfo.split('-');

            let month, yearNum;
            try {
                // Get month number from month name
                month = new Date(`${monthName} 1, ${year}`).getMonth() + 1;
                yearNum = parseInt(year);
            } catch (e) {
                // Fallback to current date
                const now = new Date();
                month = now.getMonth() + 1;
                yearNum = now.getFullYear();
            }

            // Get number of days in the selected month
            const daysInMonth = 31; // Fixed based on your data structure

            // Get today's date for highlighting
            const today = new Date();
            const currentDay = today.getDate();
            const currentMonth = today.getMonth() + 1;
            const currentYear = today.getFullYear();

            // Generate dynamic table headers
            let tableHeaders =
                `<th class="min-w-200px text-center" style="position: sticky; left: 0; background: #099dda; z-index: 5;">Staff</th>`;

            // Add day columns (1-31 as per your data)
            for (let day = 1; day <= daysInMonth; day++) {
                const date = new Date(yearNum, month - 1, day);
                const dayName = date.toLocaleDateString('en-US', {
                    weekday: 'short'
                });
                const isToday = (day === currentDay && month === currentMonth && yearNum === currentYear);
                const todayClass = isToday ? 'bg-warning text-dark' : '';

                const dayNumber = day.toString().padStart(2, '0');
                const monthNumber = month.toString().padStart(2, '0');

                tableHeaders += `
                    <th class="min-w-100px text-center ${todayClass}" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="${date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}">
                        ${dayNumber}/${monthNumber}<br>
                        ${dayName}
                    </th>
                `;
            }

            // Update table header
            tableHead.html(tableHeaders);

            if (!tasks || tasks.length === 0) {
                const colspan = daysInMonth + 1; // Staff column + 31 days
                tableBody.append(`
                    <tr>
                        <td colspan="${colspan}" class="text-center py-4">
                            <div class="text-muted">
                                <i class="mdi mdi-information-outline fs-4 me-2"></i>
                                No task data available for ${monthInfo}.
                            </div>
                        </td>
                    </tr>
                `);

                // Initialize DataTable
                initializeDataTable(daysInMonth);
                return;
            }

            // Process each staff member
            tasks.forEach((staff, index) => {
                let row = `
                    <tr>
                        <td style="position: sticky; left: 0; background: white; z-index: 3; min-width: 200px;">
                            <div class="staff-cell">
                                <img src="${staff.avatar || '{{ asset('assets/phdizone_images/user_2.png') }}'}" 
                                     alt="${staff.name}"
                                     onerror="this.src='{{ asset('assets/phdizone_images/user_2.png') }}'">
                                <div class="staff-info">
                                    <div class="staff-name">${staff.name}</div>
                                    <div class="staff-role">${staff.role}</div>
                                </div>
                            </div>
                        </td>
                `;

                // Add daily task counts for each day (1-31)
                for (let day = 1; day <= daysInMonth; day++) {
                    // Get task count from daily_tasks object
                    const taskCount = staff.daily_tasks && staff.daily_tasks[day] ? staff.daily_tasks[day] : 0;

                    const date = new Date(yearNum, month - 1, day);
                    const isToday = (day === currentDay && month === currentMonth && yearNum === currentYear);
                    const isWeekend = date.getDay() === 0 || date.getDay() === 6; // 0 = Sunday, 6 = Saturday

                    // Check if date is in future
                    const isFuture = date > new Date();

                    let cellClass = '';
                    let badgeClass = '';

                    if (isToday) {
                        cellClass = 'bg-warning text-dark';
                        badgeClass = 'bg-dark text-white';
                    } else if (isFuture) {
                        if (taskCount > 0) {
                            cellClass = 'bg-info text-white';
                            badgeClass = 'text-white border border-white';
                        } else {
                            cellClass = 'bg-light text-muted';
                            badgeClass = 'text-muted border border-light';
                        }
                    } else if (taskCount === 0 && !isFuture) {
                        cellClass = 'bg-danger text-white';
                        badgeClass = '';
                    } else if (isWeekend && !isFuture) {
                        cellClass = 'bg-light-success';
                        badgeClass = 'text-black border border-dark';
                    } else {
                        badgeClass = 'text-black border border-dark';
                    }

                    row += `
                        <td class="${cellClass}" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })} - Tasks: ${taskCount}">
                            <span class="badge rounded-circle ${badgeClass} fs-6">
                                ${taskCount}
                            </span>
                        </td>
                    `;
                }

                row += `</tr>`;
                tableBody.append(row);
                 $('[data-bs-toggle="tooltip"]').tooltip();
            });

            // Initialize DataTable with updated columns
            initializeDataTable(daysInMonth);
           

        }

        // Function to initialize DataTable
        function initializeDataTable(daysInMonth) {
            if ($.fn.DataTable.isDataTable('.list_page')) {
                $('.list_page').DataTable().destroy();
            }

            const columnDefs = [{
                target: 0, // Staff column
                orderable: false,
                searchable: true,
                width: '200px'
            }];

            // Make all day columns not searchable and not orderable
            for (let i = 1; i <= daysInMonth; i++) {
                columnDefs.push({
                    target: i,
                    orderable: false,
                    searchable: false,
                    width: '100px'
                });
            }

            $(".list_page").DataTable({
                "ordering": false,
                "paging": true,
                "pageLength": 10,
                "lengthChange": true,
                "searching": true,
                "info": true,
                "autoWidth": false,
                "responsive": false,
                "scrollX": true,
                "scrollY": "400px",
                "scrollCollapse": true,
                "fixedColumns": {
                    left: 1 // Fix the first column (Staff)
                },
                "columnDefs": columnDefs,
                "language": {
                    "lengthMenu": "Show _MENU_ staff per page",
                    "search": "Search staff:",
                    "info": "Showing _START_ to _END_ of _TOTAL_ staff",
                    "paginate": {
                        "previous": "<i class='mdi mdi-chevron-left'></i>",
                        "next": "<i class='mdi mdi-chevron-right'></i>"
                    }
                },
                "dom": "<'row'<'col-sm-12 col-md-6'l><'col-sm-12 col-md-6'f>>" +
                    "<'row'<'col-sm-12'tr>>" +
                    "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>"
            });
        }

        // Function to load dashboard data
        function loadDashboardData(dateFilter) {
            // Show loading spinner
            $("#loadingSpinner").removeClass("d-none");
            $(".dashboard-content").addClass("d-none");

            $.ajax({
                url: "{{ route('dashboard.project_coordinator') }}",
                method: "GET",
                data: {
                    date_filter: dateFilter,
                    _token: "{{ csrf_token() }}"
                },
                dataType: "json",
                success: function(response) {
                    // Hide loading spinner
                    $("#loadingSpinner").addClass("d-none");
                    $(".dashboard-content").removeClass("d-none");

                    // Update summary cards
                    if (response.summary) {
                        $("#totalServicesCount").text(response.summary.total_services || '0');
                        $("#totalJournalsCount").text(response.summary.total_journals || '0');
                        $("#totalTasksCount").text(response.summary.total_tasks || '0');
                        // Set others to 0 if not in response
                        $("#qcVerificationCount").text(response.summary.qc_verification || '0');
                        $("#newRequestCount").text(response.summary.new_requests || '0');
                        $("#reworkTaskCount").text(response.summary.rework_tasks || '0');
                    }

                    // Update pending & approvals
                    if (response.pendings) {
                        $("#unassignedRequirementsCount").text(response.pendings.unassigned_requirements ||
                            '0');
                        $("#awaitingApprovalsCount").text(response.pendings.awaiting_approvals || '0');
                        $("#unassignedAppointmentsCount").text(response.pendings.unassigned_appointments ||
                            '0');
                        $("#unassignedRevisionsCount").text(response.pendings.unassigned_revisions || '0');
                    }

                    // Get the selected month
                    const selectedMonth = response.month_info ? response.month_info.display_month :
                        (dateFilter || $("#ovr_year_fill").val());

                    // Update monthly task table
                    updateDesktopTaskTable(response.monthly_tasks || [], selectedMonth);
                },
                error: function(xhr, status, error) {
                    console.error("Error loading dashboard data:", error);

                    // Hide loading spinner even on error
                    $("#loadingSpinner").addClass("d-none");
                    $(".dashboard-content").removeClass("d-none");

                    // Show error message
                    toastr.error('Failed to load dashboard data. Please try again.', 'Error');
                }
            });
        }
    </script>

    <!-- Add Toastr for notifications -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        .toast {
            font-size: 14px;
        }

        /* Responsive table adjustments */
        @media (max-width: 1200px) {
            .table_1 {
                min-width: 1100px !important;
            }
        }

        @media (max-width: 992px) {
            .table_1 {
                min-width: 900px !important;
            }

            .table_1 thead th,
            .table_1 tbody td {
                padding: 4px !important;
                font-size: 0.75rem !important;
            }

            .table_1-container {
                max-height: 500px !important;
            }
        }

        @media (max-width: 768px) {
            .table_1 {
                min-width: 700px !important;
            }

            .staff-cell img {
                width: 35px !important;
                height: 35px !important;
            }
        }

        @media (max-width: 576px) {
            .table_1 {
                min-width: 600px !important;
            }
        }
    </style>
@endsection
