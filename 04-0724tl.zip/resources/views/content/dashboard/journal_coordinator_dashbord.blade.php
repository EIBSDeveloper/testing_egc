@extends('layouts/layoutMaster')

@section('title', 'Journal Executive')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

    <head>
        <link rel="stylesheet" href="../../assets/vendor/libs/apex-charts/apex-charts.css" />
        <!-- Bootstrap Datepicker CSS -->
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    </head>

    <style>
        .fade-in-onload {
            animation: fadeInUp 0.8s ease-out forwards;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(52px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .month-input-container {
            width: 130px;
        }

        .cursor-pointer {
            cursor: pointer;
        }

        /* Loading animation */
        .count-up {
            transition: all 0.5s ease;
        }

        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #ccc;
            border-top: 4px solid #007bff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            100% {
                transform: rotate(360deg);
            }
        }


        .loading-overlay {
            position: fixed;
            top: 0;
            /* FIXED */
            margin-top: auto;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 15, 15, 0.8);
            z-index: 9999;
            display: none;
            /* hide by default */
            align-items: center;
            /* vertical center */
            justify-content: center;
            /* horizontal center */
        }
    </style>

    <div class="container-fluid">


        <!-- Loading Overlay -->
            <div id="loading-overlay" class="loading-overlay">
                <div class="text-center">
                    <div class="spinner-border text-warning" style="width: 3rem; height: 3rem; margin-top: 250px;"
                        role="status">
                        <span class="visually-hidden text-warning">Loading...</span>
                    </div>
                    <p class="mt-2 text-dark fw-medium text-white">Loading dashboard data...</p>
                </div>
            </div>

        <!-- Month Selector -->
        <div class="row g-3 mb-2">
            <div class="col-lg-12 d-flex align-items-end justify-content-end">
                <div class="month-input-container">
                    <div class="cursor-pointer input-group input-group-merge">
                        <span class="input-group-text bg-label-warning text-black">
                            <i class="mdi mdi-calendar-month-outline fs-4"></i>
                        </span>
                        <input type="text" id="ovr_month_fill"
                            class="cursor-pointer form-control bg-label-warning text-black" value="<?php echo date('M-Y'); ?>"
                            readonly>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Dashboard Content -->
        <div class="row g-3" id="dashboard-content">
            <div class="col-lg-6 fade-in-onload">
                <div class="card rounded shadow w-100">
                    <div class="card-body" style="min-height:129px;">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="d-flex align-items-center justify-content-between flex-shrink-0 ">
                                    <div class="d-flex align-items-center gap-3 ">
                                        <img src="{{ asset('assets/phdizone_images/user_3.png') }}" id="userAvatar"
                                            alt="avatar" class="rounded-circle img-fluid d-flex flex-shrink-0 d-none"
                                            style="width: 80px; height: 80px; object-fit: cover;">
                                        <div id="userIntial"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle d-none"
                                            style="width: 60px; height: 60px;"></div>
                                        <div class="d-flex flex-column ">
                                            <div class="d-flex flex-column">
                                                <label class="fw-semibold fs-6 " style="max-width:600px;">Hey
                                                    <label class="text-black fs-3" id="user-name">{{ Auth::user()->staff->staff_name }}</label>,
                                                    <label class="fw-semibold fs-6 text-nowrap">Glad You Back Again
                                                        <span class="mdi mdi-creation text-warning"></span>
                                                    </label>
                                                </label>
                                            </div>
                                            <div class="d-flex align-items-center gap-2 ">
                                                <span class=" fs-7 px-2 fw-semibold"
                                                    style="width: fit-content; background:#e0f2f1; color:#004d40; border:1px solid #004d40; border-radius:3px;">
                                                    <span class="mdi mdi-crown-circle me-1 fs-6"></span>Journal Coordinator
                                                </span>
                                                <span class=" fs-7 px-2 fw-semibold"
                                                    style="width: fit-content; background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:3px;">
                                                    <span class="mdi mdi-heart-circle me-1 fs-6"></span> <span id="presentDays">0</span>% Attendance
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Published Card -->
            <div class="col-lg-3">
                <div class="card rounded shadow w-100" style="overflow: hidden;">
                    <div class="card-body position-relative" style="min-height:128px;">
                        <div class="d-flex flex-column">
                            <div class="d-flex gap-1 align-items-center pt-3">
                                <label class="text-black fw-semibold fs-1 mb-0 count-up" id="published-count">0</label>
                                <label class="text-black fw-semibold fs-8 mt-2">|</label>
                                <label class="text-danger fs-6 mt-2" id="published-prev" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Last Month">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6">Published</label>
                        </div>
                        <img src="{{ asset('assets/phdizone_images/dashboard_images/books.png') }}" alt="avatar"
                            class="img-fluid position-absolute"
                            style="width: 135px; height: 135px; object-fit: cover; left:65%; top:-2px;">
                    </div>
                </div>
            </div>

            <!-- Submitted Card -->
            <div class="col-lg-3">
                <div class="card rounded shadow w-100" style="overflow: hidden;">
                    <div class="card-body position-relative" style="min-height:128px;">
                        <div class="d-flex flex-column">
                            <div class="d-flex gap-1 align-items-center pt-3">
                                <label class="text-black fw-semibold fs-1 mb-0 count-up" id="submitted-count">0</label>
                                <label class="text-black fw-semibold fs-8 mt-2">|</label>
                                <label class="text-danger fs-6 mt-2" id="submitted-prev" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Last Month">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6">Submitted</label>
                        </div>
                        <img src="{{ asset('assets/phdizone_images/dashboard_images/booksnew.png') }}" alt="avatar"
                            class="img-fluid position-absolute"
                            style="width: 135px; height: 135px; object-fit: cover;left:65%; top:-2px;">
                    </div>
                </div>
            </div>



            <!-- Journal Status Cards -->
            <div class="col-lg-12">
                <label class="text-dark fw-medium fs-5">Journal Status</label>
            </div>

            <div class="col-lg-2">
                <div class="card rounded shadow w-100">
                    <div class="card-body bg-label-info rounded" style="box-shadow: none;">
                        <div class="d-flex align-items-start justify-content-start flex-column">
                            <div class="d-flex gap-1 align-items-center">
                                <label class="text-black fw-semibold fs-1 mb-0 count-up" id="with-editor-count">0</label>
                                <label class="text-black fw-semibold fs-8 mt-2">|</label>
                                <label class="text-danger fs-6 mt-2" id="with-editor-prev" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Last Month">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6">With Editor</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-2">
                <div class="card rounded shadow w-100">
                    <div class="card-body bg-label-warning rounded" style="box-shadow: none;">
                        <div class="d-flex align-items-start justify-content-start flex-column">
                            <div class="d-flex gap-1 align-items-center">
                                <label class="text-black fw-semibold fs-1 mb-0 count-up" id="under-review-count">0</label>
                                <label class="text-black fw-semibold fs-8 mt-2">|</label>
                                <label class="text-danger fs-6 mt-2" id="under-review-prev" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Last Month">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6 text-nowrap">Under Review</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-2">
                <div class="card rounded shadow w-100">
                    <div class="card-body bg-label-danger rounded" style="box-shadow: none;">
                        <div class="d-flex align-items-start justify-content-start flex-column">
                            <div class="d-flex gap-1 align-items-center">
                                <label class="text-black fw-semibold fs-1 mb-0 count-up" id="rejected-count">0</label>
                                <label class="text-black fw-semibold fs-8 mt-2">|</label>
                                <label class="text-danger fs-6 mt-2" id="rejected-prev" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Last Month">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6">Rejected</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-2">
                <div class="card rounded shadow w-100">
                    <div class="card-body bg-label-primary rounded" style="box-shadow: none;">
                        <div class="d-flex align-items-start justify-content-start flex-column">
                            <div class="d-flex gap-1 align-items-center">
                                <label class="text-black fw-semibold fs-1 mb-0 count-up" id="revision-count">0</label>
                                <label class="text-black fw-semibold fs-8 mt-2">|</label>
                                <label class="text-danger fs-6 mt-2" id="revision-prev" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Last Month">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6">Revision</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-2">
                <div class="card rounded shadow w-100">
                    <div class="card-body bg-label-secondary rounded" style="box-shadow: none;">
                        <div class="d-flex align-items-start justify-content-start flex-column">
                            <div class="d-flex gap-1 align-items-center">
                                <label class="text-black fw-semibold fs-1 mb-0 count-up" id="eproofing-count">0</label>
                                <label class="text-black fw-semibold fs-8 mt-2">|</label>
                                <label class="text-danger fs-6 mt-2" id="eproofing-prev" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Last Month">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6">Eproofing</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-2">
                <div class="card rounded shadow w-100">
                    <div class="card-body bg-label-success rounded" style="box-shadow: none;">
                        <div class="d-flex align-items-start justify-content-start flex-column">
                            <div class="d-flex gap-1 align-items-center">
                                <label class="text-black fw-semibold fs-1 mb-0 count-up" id="accepted-count">0</label>
                                <label class="text-black fw-semibold fs-8 mt-2">|</label>
                                <label class="text-danger fs-6 mt-2" id="accepted-prev" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Last Month">0</label>
                            </div>
                            <label class="text-secondary fw-medium fs-6">Accepted</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 fade-in-onload">
                <label class="text-dark fw-medium fs-5 shadow bg-none" style="box-shadow:none !important;">Journal
                    Publication</label>
            </div>
            <div class="col-lg-4 fade-in-onload">
                <div class="row g-3">
                    <div class="col-lg-12 fade-in-onload">
                        <div class="card rounded shadow w-100">
                            <div class="card-body position-relative">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex flex-column align-items-start justify-content-start">
                                        <div class="d-flex gap-1 align-items-center">
                                            <label class="text-black fw-semibold fs-1 mb-0 count-up"
                                                id="allocated-paper">0</label>
                                            <label class="text-black fw-semibold fs-8 mt-2">|</label>
                                            <label class="text-danger  fs-6 mt-2" id="allocated-paper-prev"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Last Month">0</label>
                                        </div>
                                        <label class="text-secondary fw-medium fs-6"> Allocated Paper</label>
                                    </div>
                                    <div class="d-flex flex-column align-items-end justify-content-end">
                                        <div class="d-flex gap-1 align-items-center">
                                            <label class="text-black fw-semibold fs-1 mb-0 count-up"
                                                id="pending-publication">0</label>
                                            <label class="text-black fw-semibold fs-8 mt-2">|</label>
                                            <label class="text-danger  fs-6 mt-2" id="pending-publication-prev"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Last Month">0</label>
                                        </div>
                                        <label class="text-secondary fw-medium fs-6">Pending Publications</label>
                                    </div>
                                </div>
                                <div class="divider divider-vertical position-absolute" style="top:0px; left:45%;">
                                    <div class="divider-text">VS</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 fade-in-onload">
                        <div class="card rounded shadow w-100">
                            <div class="card-body position-relative">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex flex-column align-items-start justify-content-start">
                                        <div class="d-flex gap-1 align-items-center">
                                            <label class="text-black fw-semibold fs-1 mb-0" id="PBtarget">0</label>
                                        </div>
                                        <label class="text-secondary fw-medium fs-6">Target</label>
                                    </div>
                                    <div class="d-flex flex-column align-items-end justify-content-end">
                                        <div class="d-flex gap-1 align-items-center">
                                            <label class="text-black fw-semibold fs-1 mb-0" id="PBtargetAch">0</label>
                                        </div>
                                        <label class="text-secondary fw-medium fs-6">Achieved</label>
                                    </div>
                                </div>
                                <div class="divider divider-vertical position-absolute" style="top:0px; left:45%;">
                                    <div class="divider-text">VS</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 fade-in-onload">
                        <div class="card rounded shadow w-100" style="overflow: hidden;">
                            <div class="card-body  position-relative">
                                <div class="d-flex flex-column ">
                                    <div class="d-flex gap-1 align-items-center">
                                        <label class="text-black fw-semibold fs-1 mb-0 count-up"
                                            id="overall-clients">0</label>
                                        
                                    </div>
                                    <label class="text-secondary fw-medium fs-6">Overall Clients</label>
                                </div>
                                <img src="{{ asset('assets/phdizone_images/dashboard_images/team.png') }}" alt="avatar"
                                    class=" img-fluid position-absolute"
                                    style="width: 135px; height: 135px; object-fit: cover; left:65%; top:-2px;  filter:">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Chart Section -->
            <div class="col-lg-8 fade-in-onload">
                <div class="card rounded shadow w-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-between">
                            <h5 class="card-title">Monthly Journal Published Status</h5>
                            <span class="badge bg-label-info rounded-pill ms-2 fs-7"
                                id="chart-year">{{ date('Y') }}</span>
                        </div>
                        <div class="m-0">
                            <canvas id="myLineChart" style="max-width: 100%; min-height: 286px;"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Required Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/animejs@3.2.1/lib/anime.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize date picker
            $('#ovr_month_fill').datepicker({
                format: "M-yyyy",
                startView: "months",
                minViewMode: "months",
                autoclose: true,
                todayHighlight: true
            }).on('changeDate', function(e) {
                var selectedMonth = e.format();
                fetchDashboardData(selectedMonth);
            });

            // Initialize tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });

            // Chart instance
            let lineChart = null;

            // Function to fetch dashboard data
            function fetchDashboardData(selectedMonth) {
                showLoading();

                $.ajax({
                    url: '{{ route('journal.dashboard.get') }}',
                    type: 'GET',
                    data: {
                        date: selectedMonth
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.status === 200) {
                            updateDashboardData(response.data, response.chartData);
                            // Update month input
                            $('#ovr_month_fill').val(selectedMonth);
                        } else {
                            showError('Failed to load dashboard data');
                        }
                    },
                    error: function(xhr) {
                        console.error('Error:', xhr);
                        showError('An error occurred while loading dashboard data');
                    },
                    complete: function() {
                        hideLoading();
                    }
                });
            }

            // Function to parse integer safely - improved version
            function safeParseInt(value, defaultValue = 0) {
                if (value === null || value === undefined || value === '') {
                    return 0;
                }
                const parsed = parseInt(value);
                return isNaN(parsed) ? defaultValue : parsed;
            }

            // Function to get current value from element safely
            function getCurrentValue(elementId) {
                const element = document.getElementById(elementId);
                if (!element) return 0;

                // Try to get the numeric part from the element
                const text = element.textContent.trim();

                // Remove any non-numeric characters except minus sign
                const numericText = text.replace(/[^0-9-]/g, '');

                return safeParseInt(numericText, 0);
            }

            // Function to update dashboard data with animation
            function updateDashboardData(data, chartData) {
                // Update user name

                let staffImage = data.avatar;
                let staffName = data.userName || 'No Name Provided';
                if (staffImage) {
                    // alert(staffImage);
                    $('#userAvatar').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                    $('#userIntial').addClass('d-none');
                } else {
                    let initial = staffName.charAt(0).toUpperCase();
                    // alert(initial);
                    $('#userIntial').text(initial).removeClass('d-none');
                    $('#userAvatar').addClass('d-none');
                }

                $('#user-name').text(staffName || 'N/A');
                $('#presentDays').text(data.presentDays || '0');

                // Update all counters
                $('#published-count').html(data.publishedCount || 0);
                $('#published-prev').html(data.publishedPrevMonth || 0);

                $('#submitted-count').html(data.submittedCount || 0);
                $('#submitted-prev').html(data.submittedPrevMonth || 0);

                $('#with-editor-count').html(data.withEditorCount || 0);
                $('#with-editor-prev').html(data.withEditorPrevMonth || 0);

                $('#under-review-count').html(data.underReviewerCount || 0);
                $('#under-review-prev').html(data.underReviewerPrevMonth || 0);

                $('#rejected-count').html(data.rejectedCount || 0);
                $('#rejected-prev').html(data.rejectedPrevMonth || 0);

                $('#revision-count').html(data.revisionCount || 0);
                $('#revision-prev').html(data.revisionPrevMonth || 0);

                $('#eproofing-count').html(data.eproofingCount || 0);
                $('#eproofing-prev').html(data.eproofingPrevMonth || 0);

                $('#accepted-count').html(data.acceptedCount || 0);
                $('#accepted-prev').html(data.acceptedPrevMonth || 0);

                $('#allocated-paper').html(data.allocatedPaper || 0);
                $('#allocated-paper-prev').html(data.allocatedPaperPrevMonth || 0);

                $('#pending-publication').html(data.pendingPublication || 0);
                $('#pending-publication-prev').html(data.pendingPublicationPrevMonth || 0);

                $('#overall-clients').html(data.overallClients || 0);
                $('#PBtarget').html(data.PBtarget || 0);
                $('#PBtargetAch').html(data.publishedCount || 0);


                // Update chart year from selected month
                const monthYear = $('#ovr_month_fill').val();
                const year = monthYear ? monthYear.split('-')[1] : new Date().getFullYear();
                $('#chart-year').text(year);

                // Update chart
                updateChart(chartData);
            }

            // Function to animate counter
            function animateCounter(elementId, targetValue) {
                const element = document.getElementById(elementId);
                if (!element) {
                    console.warn(`Element with id ${elementId} not found`);
                    return;
                }

                // Get current value safely
                const currentValue = getCurrentValue(elementId);

                // If target is NaN, set to 0
                const targetNum = isNaN(targetValue) ? 0 : targetValue;

                // If values are the same, just set the text
                if (currentValue === targetNum) {
                    element.textContent = targetNum;
                    return;
                }

                // Use anime.js for smooth animation if available
                if (typeof anime !== 'undefined') {
                    anime({
                        targets: {
                            value: currentValue
                        },
                        value: targetNum,
                        round: 1,
                        easing: 'easeOutQuart',
                        duration: 800,
                        update: function(anim) {
                            element.textContent = Math.floor(anim.animatedValue);
                        }
                    });
                } else {
                    // Fallback to simple update
                    element.textContent = targetNum;
                }
            }

            // Function to update chart
            function updateChart(chartData) {
                const ctx = document.getElementById('myLineChart');
                if (!ctx) return;

                // Ensure chartData is an array of numbers (not NaN)
                const safeChartData = Array.isArray(chartData) ?
                    chartData.map(val => safeParseInt(val, 0)) :
                    Array(12).fill(0);

                // Check if all values are 0
                const allZeros = safeChartData.every(val => val === 0);

                // Get max value for scaling
                const maxValue = Math.max(...safeChartData);

                // Destroy existing chart if it exists
                if (lineChart) {
                    lineChart.destroy();
                }

                // Create new chart
                lineChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT',
                            'NOV', 'DEC'
                        ],
                        datasets: [{
                            label: 'Published',
                            data: safeChartData,
                            borderColor: '#ffc107',
                            backgroundColor: allZeros ? 'transparent' : 'rgba(255, 193, 7, 0.2)',
                            tension: 0.3,
                            pointBackgroundColor: '#ffc107',
                            pointRadius: 4,
                            pointHoverRadius: 6,
                            fill: !allZeros,
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                suggestedMax: maxValue === 0 ? 10 : Math.ceil(maxValue * 1.1),
                                grid: {
                                    drawBorder: false,
                                    color: 'rgba(0,0,0,0.1)'
                                },
                                ticks: {
                                    callback: function(value) {
                                        return value === 0 ? '0' : value;
                                    },
                                    stepSize: maxValue === 0 ? 2 : Math.max(1, Math.ceil(maxValue / 5))
                                }
                            },
                            x: {
                                grid: {
                                    display: false
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const value = context.parsed.y;
                                        return `${value} Published`;
                                    }
                                }
                            },
                            legend: {
                                display: false
                            }
                        }
                    }
                });

                // Add "No Data" message if all zeros
                if (allZeros) {
                    const noDataPlugin = {
                        id: 'noData',
                        afterDraw(chart) {
                            const {
                                ctx,
                                width,
                                height
                            } = chart;
                            ctx.save();
                            ctx.textAlign = 'center';
                            ctx.textBaseline = 'middle';
                            ctx.font = '14px Arial';
                            ctx.fillStyle = '#6c757d';
                            ctx.fillText('No published data available', width / 2, height / 2);
                            ctx.restore();
                        }
                    };

                    // Add plugin to chart
                    Chart.register(noDataPlugin);
                }
            }

            // Loading functions
            function showLoading() {
                $('#loading-overlay').fadeIn(300);
            }

            function hideLoading() {
                $('#loading-overlay').fadeOut(300);
            }

            function showError(message) {
                // Create error toast notification
                const toast = document.createElement('div');
                toast.className = 'toast align-items-center text-bg-danger border-0 position-fixed top-0 end-0 m-3';
                toast.setAttribute('role', 'alert');
                toast.setAttribute('aria-live', 'assertive');
                toast.setAttribute('aria-atomic', 'true');

                toast.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">
                        <i class="mdi mdi-alert-circle me-2"></i> ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            `;

                document.body.appendChild(toast);
                const bsToast = new bootstrap.Toast(toast);
                bsToast.show();

                // Remove toast after it's hidden
                toast.addEventListener('hidden.bs.toast', function() {
                    document.body.removeChild(toast);
                });
            }

            // Initialize dashboard with current month data
            fetchDashboardData('<?php echo date('M-Y'); ?>');
        });
    </script>
@endsection
