{{-- resources/views/content/dashboard/points.blade.php --}}
@extends('layouts/layoutMaster')

@section('title', 'Points Settings')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 
           'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 
           'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 
           'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js'])
@endsection

@section('content')
<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-end align-items-center mb-2">
                    <button type="button" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_add_points">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Points
                    </button>
                </div>
                
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page" id="pointsTable">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-50px">S.No</th>
                                    <th class="min-w-300px">Points Name</th>
                                    <th class="min-w-300px">Points</th>
                                    <th class="min-w-80px">Status</th>
                                    <th class="min-w-50px">Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7">
                                @forelse($pointsList as $index => $point)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>
                                        <label>{{ $point->points_name }}</label>
                                        <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                            title="{{ $point->comments ?? '-' }}">
                                            <i class="mdi mdi-help-circle text-dark"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <label class="{{ $point->points < 0 ? 'text-danger' : 'text-success' }} px-2 py-2 rounded">
                                            {{ $point->points > 0 ? '+' : '' }}{{ $point->points }}
                                        </label>
                                    </td>
                                    <td>
                                        <label class="switch switch-square">
                                            <input type="checkbox" class="switch-input status-toggle" 
                                                data-id="{{ $point->sno }}"
                                                {{ $point->status == 0 ? 'checked' : '' }} />
                                            <span class="switch-toggle-slider">
                                                <span class="switch-on"></span>
                                                <span class="switch-off"></span>
                                            </span>
                                        </label>
                                    </td>
                                    <td>
                                        <span class="text-end">
                                            <button type="button" class="btn btn-icon btn-sm me-2 edit-btn" 
                                                data-id="{{ $point->sno }}"
                                                data-name="{{ $point->points_name }}"
                                                data-points="{{ $point->points }}"
                                                data-description="{{ $point->comments }}"
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_edit_points"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                                                <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                            </button>
                                            @if($point->status == 2)
                                            <button type="button" class="btn btn-icon btn-sm delete-btn"
                                                data-id="{{ $point->sno }}"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                                                <i class="mdi mdi-trash-can-outline fs-3 text-danger"></i>
                                            </button>
                                            @endif
                                        </span>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="6" class="text-center">No points found</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Add Points Modal --}}
<div class="modal fade" id="kt_modal_add_points" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <div class="modal-dialog modal-md">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Create Points</h3>
                </div>
                <form action="{{ route('points.add') }}" method="POST" id="addPointsForm">
                    @csrf
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Points Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="points_name" placeholder="Enter Points Name" required />
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Points<span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="points" placeholder="Enter Points (e.g., 5 or -5)" required />
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="2" name="description" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create Points</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

{{-- Edit Points Modal --}}
<div class="modal fade" id="kt_modal_edit_points" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <div class="modal-dialog modal-md">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Points</h3>
                </div>
                <form action="{{ route('points.update') }}" method="POST" id="editPointsForm">
                    @csrf
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Points Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="edit_points_name" id="edit_points_name" 
                                placeholder="Enter Points Name" required />
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Points<span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="edit_points" id="edit_points" 
                                placeholder="Enter Points" required />
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="2" name="edit_description" id="edit_description" 
                                placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Points</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

@section('page-script')
<script>
$(document).ready(function() {
    // Initialize DataTable
    var table = $("#pointsTable").DataTable({
        "ordering": false,
        "pageLength": 25, // Set default page length to 25
        "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]], // Define available options
        "language": {
            "lengthMenu": "Show _MENU_",
            "info": "Showing _START_ to _END_ of _TOTAL_ entries",
            "infoEmpty": "Showing 0 to 0 of 0 entries",
            "infoFiltered": "(filtered from _MAX_ total entries)",
            "search": "Search:",
            "paginate": {
                "first": "First",
                "last": "Last",
                "next": "Next",
                "previous": "Previous"
            }
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-content-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +
            "<'table-responsive'tr>" +
            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });

    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Edit button click handler
    $('.edit-btn').on('click', function() {
        var id = $(this).data('id');
        var name = $(this).data('name');
        var points = $(this).data('points');
        var description = $(this).data('description');
        
        $('#edit_id').val(id);
        $('#edit_points_name').val(name);
        $('#edit_points').val(points);
        $('#edit_description').val(description);
    });

    // Status toggle handler
    $('.status-toggle').on('change', function() {
        var id = $(this).data('id');
        var status = $(this).is(':checked') ? 0 : 1;
        
        $.ajax({
            url: '{{ url("points/status") }}/' + id,
            type: 'PUT',
            data: {
                status: status,
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                if(response.status == 200) {
                    toastr.success('Status updated successfully');
                } else {
                    toastr.error('Failed to update status');
                }
            },
            error: function() {
                toastr.error('An error occurred');
            }
        });
    });

    // Delete button handler
    $('.delete-btn').on('click', function() {
        var id = $(this).data('id');
        
        if(confirm('Are you sure you want to delete this points record?')) {
            $.ajax({
                url: '{{ url("points/delete") }}/' + id,
                type: 'DELETE',
                data: {
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    if(response.status == 200) {
                        toastr.success('Deleted successfully');
                        location.reload();
                    } else {
                        toastr.error('Failed to delete');
                    }
                },
                error: function() {
                    toastr.error('An error occurred');
                }
            });
        }
    });
});
</script>
@endsection