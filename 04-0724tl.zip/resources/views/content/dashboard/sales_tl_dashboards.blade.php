@php
$configData = Helper::appClasses();
@endphp
@extends('layouts/layoutMaster')

@section('title', 'Sales TL Dashboards')

@section('content')
<style>
    :root {
        --progress-bar-width: 40px;
        --progress-bar-height: 40px;
        --font-size: 1rem;
        --progress-color: #28a745;
        --background-color: #e2e6ea;
        --inner-circle-color: white;
        --percentage-color: #333;
    }

    .progress-circle {
        position: relative;
        width: var(--progress-bar-width);
        height: var(--progress-bar-height);
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .inner-circle {
        position: absolute;
        width: calc(var(--progress-bar-width) - 8px);
        height: calc(var(--progress-bar-height) - 8px);
        border-radius: 50%;
        background-color: var(--inner-circle-color);
    }

    .percentage {
        position: relative;
        font-size: 11px;
        color: var(--percentage-color);
        font-weight: bold;
    }

    .w_10 {
        width: 10% !important;
    }

    .w_20 {
        width: 20% !important;
    }

    .w_30 {
        width: 30% !important;
    }

    .w_40 {
        width: 40% !important;
    }

    .w_60 {
        width: 60% !important;
    }

    table thead th {
        padding: 5px !important;
    }

    table tbody td {
        padding: 5px !important;
    }
</style>
@php
$helper = new \App\Helpers\Helpers();
@endphp
<div class="d-flex align-items-center justify-content-between">
    <div class="nav-align-top mb-3">
        <ul class="nav nav-pills" role="tablist">
            <li class="nav-item mb-1 me-1">
                <button type="button" class="nav-link text-capitalize border rounded active" role="tab"
                    data-bs-toggle="tab" data-bs-target="#tab_team" aria-controls="tab_my_self"
                    aria-selected="true">Team</button>
            </li>
            <li class="nav-item mb-1">
                <button type="button" class="nav-link text-capitalize border rounded" role="tab" data-bs-toggle="tab"
                    data-bs-target="#tab_my_self" aria-controls="tab_team" aria-selected="false">MySelf</button>
            </li>
        </ul>
    </div>
</div>
<div class="tab-content p-0">
    <div class="tab-pane fade" id="tab_my_self" role="tabpanel">
        <div class="row gy-4">
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="fs-5 text-center rounded-start-top rounded-end-top border-bottom fw-semibold bg-label-info pt-2 pb-2 text-black"
                        style="background-color:rgb(157, 188, 252) !important;">
                        🚀 Today ( {{date('d-M-Y')}} )
                    </div>
                    <!-- <div class="card-header d-flex align-items-center flex-wrap p-2 pe-3 pt-2 mb-2">
                                <div class="card-action-title mb-1">
                                    <div class="d-flex align-items-center flex-wrap px-1">
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input rounded bg-danger border border-gray-300i" data-kt-image-input="true">
                                                <img src="{{asset('assets/phdizone_images/staff_4.png')}}" alt="user-avatar" class="w-60px h-60px" />
                                            </div>
                                        </div>
                                        <div class="mb-0 align-items-center">
                                            <div class="d-block">
                                                <label class="fs-7 fw-semibold text-black max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">Haritha S</label>
                                            </div>
                                            <div class="d-block mt-n1">
                                                <label class="fs-8 fw-semibold text-info max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Nick Name">( Zara )</label>
                                            </div>
                                            <div class="fs-8 fw-semibold">
                                                <label><i class="mdi mdi-crown-circle-outline fs-4 text-black"></i></label>
                                                <label class="fs-8 fw-semibold text-dark">Sales Executive</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-action-element d-flex align-items-center flex-wrap gap-3">
                                    <div class="symbol symbol-35px cursor-pointer mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Ratio">
                                        <img src="{{asset('assets/phdizone_images/staff_rate/h_50.png')}}" alt="user-avatar" class="image-input-wrapper w-20px h-20px"  />
                                        <div class="fs-8 fw-semibold text-center text-black">25%</div>
                                    </div>
                                    <div class="mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Trust Score">
                                        <div class="fs-8 fw-semibold text-center text-dark">TS</div>
                                        <div class="fs-8 fw-semibold text-center text-black">
                                            <label class="badge bg-info fw-semibold fs-8">05<label>
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <div class="fs-8 fw-semibold text-center text-dark">Points</div>
                                        <div class="fs-8 fw-semibold text-center text-black">
                                            <label class="badge bg-danger fw-semibold fs-8">1271<label>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                    <div class="card-body pt-4">
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-5">
                            <div class="text-center bg-label-warning rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark">Conversion</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">{{$todayConversionSelf}}</div>
                            </div>
                            <div class="text-center bg-label-info rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Conversion Rate">CR</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">{{$convertion_rate}}%</div>
                            </div>
                            <div class="text-center bg-label-secondary rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Average Business Value">ABV</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">
                                    <label class="">&#8377; {{$averageBusinessValue}}</label>
                                </div>
                            </div>
                            <div class="text-center bg-label-danger rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Average Collection Value">ACV</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">
                                    <label class="">&#8377; {{$averageCollectionValue}}</label>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-0">
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Appointments</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$appointmentsTodaySelf}}</label>
        
                                    @if($differenceAppointmentsTodaySelf > 0)
                                    <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($differenceAppointmentsTodaySelf <= 0) <label class="text-danger"><i
                                            class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                        @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label class="fs-7 text-{{$differenceAppointmentsTodaySelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageAppointmentsTodaySelf) }}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Yesterday</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Walk - In</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$todayWalkInCountSelf}}</label>
        
                                    @if($differenceWalkInCountTodaySelf > 0)
                                    <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($differenceWalkInCountTodaySelf <= 0) <label class="text-danger"><i
                                            class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                        @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label
                                        class="fs-7 text-{{$differenceWalkInCountTodaySelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageWalkInCountTodaySelf) }}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Yesterday</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Followups</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$todayFollowUpsSelf}}</label>
        
                                    @if($differenceFollowUpsTodaySelf > 0)
                                    <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($differenceFollowUpsTodaySelf <= 0) <label class="text-danger"><i
                                            class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                        @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label class="fs-7 text-{{$differenceFollowUpsTodaySelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageFollowUpdsTodaySelf) }}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Yesterday</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Outgoing Call</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$todayOutGoingCallsSelf}}</label>
        
                                    @if($differenceOutgoingCallsTodaySelf > 0)
                                    <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($differenceOutgoingCallsTodaySelf <= 0) <label class="text-danger"><i
                                            class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                        @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label class="fs-7 text-{{$differenceOutgoingCallsTodaySelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageOutGoingCallsTodaySelf) }}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Yesterday</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="fs-5 text-center rounded-start-top rounded-end-top border-bottom fw-semibold bg-label-info pt-2 pb-2 text-black"
                        style="background-color:#9dfcbf !important;">🌟 This Month ( {{date('M-Y')}} )
                    </div>
                    <div class="card-body pt-4">
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-5">
                            <div class="text-center bg-label-warning rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark">Conversion</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">{{$currentMonthConversionSelf}}</div>
                            </div>
                            <div class="text-center bg-label-info rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Conversion Rate">CR</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">{{$convertion_rate_month}}%</div>
                            </div>
                            <div class="text-center bg-label-secondary rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Average Business Value">ABV</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">
                                    <label class="">&#8377; {{$averageBusinessValueMonth}}</label>
                                </div>
                            </div>
                            <div class="text-center bg-label-danger rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Average Collection Value">ACV</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">
                                    <label class="">&#8377; {{$averageCollectionValueMonth}}</label>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-0">
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Appointments</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$appointmentsCurrentMonthSelf}}</label>
        
                                    @if($differenceAppointmentsCurrentMonthSelf > 0)
                                    <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($differenceAppointmentsCurrentMonthSelf <= 0) <label class="text-danger"><i
                                            class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                        @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label
                                        class="fs-7 text-{{$differenceAppointmentsCurrentMonthSelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageAppointmentsCurrentMonthSelf) }}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Walk - In</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$currentMonthWalkInCountSelf}}</label>
                                    @if($differenceWalkInCountCurrentMonthSelf > 0)
                                    <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($differenceWalkInCountCurrentMonthSelf <= 0) <label class="text-danger"><i
                                            class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                        @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label
                                        class="fs-7 text-{{$differenceWalkInCountCurrentMonthSelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageWalkInCountCurrentMonthSelf) }}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Followups</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$currentMonthFollowUpsSelf}}</label>
        
                                    @if($differenceFollowUpsCurrentMonthSelf > 0)
                                    <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($differenceFollowUpsCurrentMonthSelf <= 0) <label class="text-danger"><i
                                            class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                        @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label
                                        class="fs-7 text-{{$differenceFollowUpsCurrentMonthSelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageFollowUpsCurrentMonthSelf) }}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Outgoing Call</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$currentMonthOutgoingCallsSelf}}</label>
        
                                    @if($differenceOutGoingCallsCurrentMonthSelf > 0)
                                    <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($differenceOutGoingCallsCurrentMonthSelf <= 0) <label class="text-danger"><i
                                            class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                        @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label
                                        class="fs-7 text-{{$differenceOutGoingCallsCurrentMonthSelf <= 0 ? 'danger' : 'success'}}">{{$percentageOutgoingCallsCurrentMonthSelf}}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-2">
                <div class="card h-100 rounded">
                    <div class="card-body px-3">
                        <div class="d-flex justify-content-center align-items-center flex-wrap mb-1">
                            <div class="avatar mb-2">
                                <div class="avatar-initial bg-label-primary rounded">
                                    <i class="mdi mdi-account-star-outline mdi-24px"></i>
                                </div>
                            </div>
                        </div>
                        <div class="text-center text-dark fw-semibold mb-1">Total Leads</div>
                        <div class="card-info">
                            <div class="fs-4 fw-bold text-black text-center mb-2">
                                <label>{{ $currentMonthTotalLeadsSelf }}</label>
                                @if($differenceTotalLeadsSelf > 0)
                                <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                @elseif($differenceTotalLeadsSelf <= 0) <label class="text-danger"><i
                                        class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif
                            </div>
                            <div class="fw-semibold fs-8">
                                <label
                                    class="fs-7 text-{{$differenceTotalLeadsSelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageTotalLeadsSelf) }}%</label>
                                <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-2">
                <div class="card h-100 rounded">
                    <div class="card-body px-3">
                        <div class="d-flex justify-content-center align-items-center flex-wrap mb-1">
                            <div class="avatar mb-2">
                                <div class="avatar-initial bg-label-primary rounded">
                                    <i class="mdi mdi-shield-account-outline mdi-24px"></i>
                                </div>
                            </div>
                        </div>
                        <div class="text-center text-dark fw-semibold mb-1">Active Leads</div>
                        <div class="card-info">
                            <div class="fs-4 fw-bold text-black text-center mb-2">
                                <label>{{$currentMonthActiveLeadsSelf}}</label>
                                @if($differenceActiveLeadsSelf > 0)
                                <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                @elseif($differenceActiveLeadsSelf <= 0) <label class="text-danger"><i
                                        class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif
                            </div>
                            <div class="fw-semibold fs-8">
                                <label
                                    class="fs-7 text-{{$differenceActiveLeadsSelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageActiveLeadsSelf) }}%</label>
                                <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-2">
                <div class="card h-100 rounded">
                    <div class="card-body px-3">
                        <div class="d-flex justify-content-center align-items-center flex-wrap mb-1">
                            <div class="avatar mb-2">
                                <div class="avatar-initial bg-label-primary rounded">
                                    <i class="mdi mdi-account-off-outline mdi-24px"></i>
                                </div>
                            </div>
                        </div>
                        <div class="text-center text-dark fw-semibold mb-1">Spam Leads</div>
                        <div class="card-info">
                            <div class="fs-4 fw-bold text-black text-center mb-2">
                                <label>{{$currentMonthSpamLeadsSelf}}</label>
        
                                @if($differenceSpamLeadsSelf > 0)
                                <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                @elseif($differenceSpamLeadsSelf <= 0) <label class="text-danger"><i
                                        class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif
                            </div>
                            <div class="fw-semibold fs-8">
                                <label
                                    class="fs-7 text-{{$differenceSpamLeadsSelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageSpamLeadsSelf) }}%</label>
                                <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-2">
                <div class="card h-100 rounded">
                    <div class="card-body px-3">
                        <div class="d-flex justify-content-center align-items-center flex-wrap mb-1">
                            <div class="avatar mb-2">
                                <div class="avatar-initial bg-label-primary rounded">
                                    <i class="mdi mdi-account-cancel-outline mdi-24px"></i>
                                </div>
                            </div>
                        </div>
                        <div class="text-center text-dark fw-semibold mb-1">Dead Leads</div>
                        <div class="card-info">
                            <div class="fs-4 fw-bold text-black text-center mb-2">
                                <label>{{$currentMonthDeadLeadsSelf}}</label>
        
                                @if($differenceDeadLeadsSelf > 0)
                                <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                @elseif($differenceDeadLeadsSelf <= 0) <label class="text-danger"><i
                                        class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif
                            </div>
                            <div class="fw-semibold fs-8">
                                <label
                                    class="fs-7 text-{{$differenceDeadLeadsSelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageDeadLeadsSelf) }}%</label>
                                <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-2">
                <div class="card h-100 rounded">
                    <div class="card-body px-3">
                        <div class="d-flex justify-content-center align-items-center flex-wrap mb-1">
                            <div class="avatar mb-2">
                                <div class="avatar-initial bg-label-primary rounded">
                                    <i class="mdi mdi-account-school-outline mdi-24px"></i>
                                </div>
                            </div>
                        </div>
                        <div class="text-center text-dark fw-semibold mb-1">Convt. Customer</div>
                        <div class="card-info">
                            <div class="fs-4 fw-bold text-black text-center mb-2">
                                <label>{{$CurrentMonthCustomerConvertSelf}}</label>
        
                                @if($differenceCustomerConvertSelf > 0)
                                <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                @elseif($differenceCustomerConvertSelf <= 0) <label class="text-danger"><i
                                        class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif
                            </div>
                            <div class="fw-semibold fs-8">
                                <label
                                    class="fs-7 text-{{$differenceCustomerConvertSelf <= 0 ? 'danger' : 'success'}}">{{ round($percentageCustomerConvertSelf) }}%</label>
                                <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-2">
                <div class="card h-100 rounded">
                    <div class="card-body px-3">
                        <div class="d-flex align-items-center justify-content-between border-bottom cursor-pointer mb-3 pb-3">
                            <div class="text-center text-dark fw-semibold mb-1" data-bs-toggle="tooltip"
                                data-bs-placement="bottom" title="On Day Conversion">
                                <span>ODC</span>
                                <img src="{{asset('assets/phdizone_images/trophy.png')}}" alt="user-avatar"
                                    class="image-input-wrapper w-25px h-25px" />
                            </div>
                            <div class="badge bg-warning text-black fs-6 fw-bold text-center">{{$odc_count}}</div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between border-bottom cursor-pointer mb-3 pb-3">
                            <div class="text-center text-dark fw-semibold mb-1" data-bs-toggle="tooltip"
                                data-bs-placement="bottom" title="On Month Conversion">
                                <span>MC</span>
                                <img src="{{asset('assets/phdizone_images/stars.png')}}" alt="user-avatar"
                                    class="image-input-wrapper w-25px h-25px" />
                            </div>
                            <div class="badge bg-info fs-6 fw-bold text-center">{{$mc_count}}</div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="text-center text-dark fw-semibold mb-1" data-bs-toggle="tooltip"
                                data-bs-placement="bottom" title="Old Month Conversion">OMC</div>
                            <div class="badge bg-success fs-6 fw-bold text-center">{{$omc_count}}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="card-header rounded-start-top rounded-end-top border-bottom py-3 pb-3"
                        style="background-color:#00ffad !important;">
                        <div class="card-action-title text-black fw-semibold fs-5">Top 5 Sales Person ( {{date('M-Y')}} )</div>
                    </div>
                    <div class="card-body pt-3">
                        <div class="scroll-y max-h-200px pe-2">
                            @foreach($top_5_sales_persons as $index => $t5sp)
                            <div class="d-flex align-items-center justify-content-between border-bottom pb-2 px-1 py-1 mb-2">
                                <div class="d-flex align-items-center">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input border border-gray-300i rounded bg-label-danger"
                                            data-kt-image-input="true">
                                            @if ($t5sp->staff_image)
                                            <img src="{{ asset('staff_images/' . $t5sp->staff_image)}}" alt="user-avatar"
                                                class="image-input-wrapper w-px-40 h-px-40" />
                                            @else
                                            <img src="{{ asset('phdizone_images/staff_3.png')}}" alt="user-avatar"
                                                class="image-input-wrapper w-px-40 h-px-40" />
                                            @endif
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <div class="fs-7 fw-semibold text-black">{{ $t5sp->staff_name }}</div>
                                        <div class="d-block text-dark fw-semibold fs-8">{{ $t5sp->nick_name }}</div>
                                    </div>
                                </div>
                                <div class="text-end fw-semibold">
                                    <div class="text-center fw-semibold fs-8">
                                        <img src="{{ asset('assets/phdizone_images/staff_rate/rank' . ($index + 1) . '.gif') }}"
                                            alt="rank" class="w-55px h-45px" />
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="card-header rounded-start-top rounded-end-top border-bottom py-3 pb-3"
                        style="background-color:#cafc9d !important;">
                        <div class="card-action-title text-black fw-semibold fs-5">Lead Source ( {{date('M-Y')}} ) </div>
                        <div class="card-action-element text-info fw-semibold fs-6">
                            <div class="badge bg-warning fw-semibold rounded-pill fs-6 text-black">{{ $lead_sources->count() }}
                            </div>
                        </div>
                    </div>
                    <div class="card-body pt-3">
                        <div class="scroll-y max-h-200px pe-2">
                            @foreach($lead_sources as $leads)
                            <div class="d-flex align-items-center border-bottom mb-2">
                                <div class="w-50 mb-2">
                                    <div class="text-dark fw-semibold fs-6">{{ $leads->lead_source_name }}</div>
                                </div>
                                <div class="w-50 d-flex align-items-center justify-content-end gap-3 mb-2">
                                    <div class="badge bg-warning text-black fw-semibold rounded-pill fs-7">{{
                                        $leads->total_leads }}</div>
                                    <div class="progress-circle"
                                        style="background: conic-gradient(var(--progress-color) {{ $leads->percentage }}%, var(--background-color) 0);">
                                        <div class="inner-circle"></div>
                                        <div class="percentage">{{$leads->percentage}}%</div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="card-header rounded-start-top rounded-end-top border-bottom py-3 pb-3"
                        style="background-color:#fbcfdf !important;">
                        <div class="card-action-title text-black fw-semibold fs-5">Followup Schedule ( {{date('d-M-Y')}} )</div>
                        <div class="card-action-element text-center fw-semibold fs-6">
                            <span
                                class="badge bg-success fw-semibold rounded-pill text-white fs-6">{{$filteredAppointments->count()}}</span>
                        </div>
                    </div>
                    <div class="card-body pt-3">
                        <div class="scroll-y max-h-200px pe-2">
                            @foreach($filteredAppointments as $app)
                            <div class="d-flex align-items-center justify-content-between border-bottom pb-2 px-1 py-1 mb-2">
                                <div class="mb-0">
                                    <div class="fw-semibold">
                                        <label class="fs-7 fw-semibold text-black me-2">{{ $app->lead_name }}</label>
                                    </div>
        
                                    @if($app->display_status === 'Completed')
                                    <div class="d-block text-danger fw-semibold fs-8">Completed</div>
                                    @elseif($app->display_status === 'Rescheduled')
                                    <div class="d-block text-danger fw-semibold fs-8">Re Scheduled</div>
                                    @endif
                                </div>
        
                                <div class="text-end fw-semibold">
                                    @php
                                    $dtDate = \Carbon\Carbon::parse($app->appointment_date);
                                    $dtTime = \Carbon\Carbon::parse($app->appointment_time);
                                    @endphp
                                    <div class="badge bg-success text-black fw-semibold fs-8">@if($app->display_status ===
                                        'Rescheduled') {{ $dtDate->format('d-M-Y') }} @endif</div>
                                    <div class="d-block">
                                        <div class="badge bg-label-success text-black fw-semibold fs-8">
                                            @if($app->display_status === 'Rescheduled')
                                            {{ $dtTime->format('h:i A') }}
                                            @else
                                            {{ $dtTime->format('h:i A') }}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="card-header rounded-start-top rounded-end-top border-bottom py-3 pb-3"
                        style="background-color:#f3d9b2 !important;">
                        <div class="card-action-title text-black fw-semibold fs-5">Appointment Schedule ( {{date('d-M-Y')}} )
                        </div>
                        <div class="card-action-element text-center fw-semibold fs-6">
                            <span class="fs-7 fw-semibold text-dark">Walk In </span>
                            <span class="badge bg-label-info fw-semibold rounded-pill text-black fs-6">{{ $walkInCount }}</span>
                        </div>
                    </div>
                    <div class="card-body pt-3">
                        <div class="scroll-y max-h-200px pe-2">
                            @foreach($appointmentFilter as $tapp)
                            <div class="d-flex align-items-center justify-content-between border-bottom pb-2 px-1 py-1 mb-2">
                                <div class="d-flex align-items-center">
                                    <div class="mb-0 align-items-center">
                                        <div class="fs-7 fw-semibold text-black">{{$tapp->lead_name}}</div>
                                        @if($tapp->app_status === 'Completed')
                                        <div class="d-block text-danger fw-semibold fs-8">Completed</div>
                                        @elseif($tapp->app_status === 'Rescheduled')
                                        <div class="d-block text-danger fw-semibold fs-8">Re Scheduled</div>
                                        @endif
                                    </div>
                                </div>
                                <div class="text-dark fw-semibold fs-8">
                                    @php
                                    $dt = \Carbon\Carbon::parse($tapp->appointment_date);
                                    @endphp
        
                                    @if($tapp->app_status === 'Rescheduled')
                                    {{ $dt->format('d-M-Y') }}<br>
                                    {{ $dt->format('h:i A') }}
                                    @else
                                    {{ $dt->format('h:i A') }}
                                    @endif
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>  
        </div>
    </div>
    <div class="tab-pane fade show active" id="tab_team" role="tabpanel">
        <div class="row gy-4">
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="fs-5 text-center rounded-start-top rounded-end-top border-bottom fw-semibold bg-label-info pt-2 pb-2 text-black"
                        style="background-color:rgb(157, 188, 252) !important;">🚀 Team - Today (
                        <?php echo date("d-M-Y"); ?> )
                    </div>
                    <div class="card-body pt-4">
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-5">
                            <div class="text-center bg-label-warning rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark">Conversion</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">{{$convertCustomerTodayTeam}}</div>
                            </div>
                            <div class="text-center bg-label-info rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Conversion Rate">CR</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">{{$convertion_rate_team_tdy}}%</div>
                            </div>
                            <div class="text-center bg-label-secondary rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Average Business Value">ABV</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">
                                    <label class="">&#8377; {{$averageBusinessValueTeamTdy}}</label>
                                </div>
                            </div>
                            <div class="text-center bg-label-danger rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Average Collection Value">ACV</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">
                                    <label class="">&#8377; {{$averageCollectionValueTeamTdy}}</label>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-0">
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Appointments</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$tdy_app_team}}</label>
                                    
                                    @if($diff_app_team > 0)
                                        <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($diff_app_team <= 0) 
                                        <label class="text-danger"><i class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label
                                        class="fs-7 text-{{$diff_app_team <= 0 ? 'danger' : 'success'}}">{{$per_app_team}}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Yesterday</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Walk - In</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$walkInCountTodayTeam}}</label>
                            
                                    @if($differenceTeamWalkInCount > 0)
                                    <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($differenceTeamWalkInCount <= 0) <label class="text-danger"><i
                                            class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                        @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label
                                        class="fs-7 text-{{$differenceTeamWalkInCount <= 0 ? 'danger' : 'success'}}">{{ round($percentageWalkInCountTeam) }}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Followups</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$tdy_flwup_team}}</label>
                                    
                                    @if($diff_flwup_team > 0)
                                        <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($diff_flwup_team <= 0) 
                                        <label class="text-danger"><i class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label
                                        class="fs-7 text-{{$diff_flwup_team <= 0 ? 'danger' : 'success'}}">{{(round($per_flwup_team))}}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Yesterday</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Outgoing Call</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$tdy_calls_team}}</label>
                                    
                                    @if($diff_calls_team > 0)
                                        <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($diff_calls_team <= 0) 
                                        <label class="text-danger"><i class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label class="fs-7 text-{{$diff_calls_team <= 0 ? 'danger' : 'success'}}">{{round($per_calls_team)}}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Yesterday</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="fs-5 text-center rounded-start-top rounded-end-top border-bottom fw-semibold bg-label-info pt-2 pb-2 text-black"
                        style="background-color:#9dfcbf !important;">🌟 Team - This Month (
                        <?php echo date("M-Y"); ?> )
                    </div>
                    <div class="card-body pt-4">
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-5">
                            <div class="text-center bg-label-warning rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark">Conversion</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">{{$convertCustomerCurrentMonthTeam}}</div>
                            </div>
                            <div class="text-center bg-label-info rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Conversion Rate">CR</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">{{$convertion_rate_team_month}}%</div>
                            </div>
                            <div class="text-center bg-label-secondary rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Average Business Value">ABV</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">
                                    <label class="">&#8377; {{$averageBusinessValueTeamMnth}}</label>
                                </div>
                            </div>
                            <div class="text-center bg-label-danger rounded px-2 py-1 mb-0">
                                <div class="fs-6 fw-semibold text-dark" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Average Collection Value">ACV</div>
                                <div class="d-block text-center fs-4 text-black fw-bold">
                                    <label class="">&#8377; {{$averageCollectionValueTeamMnth}}</label>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-0">
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Appointments</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$tdy_app_month_team}}</label>
                                    
                                    @if($diff_app_month_team > 0)
                                        <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($diff_app_month_team <= 0) 
                                        <label class="text-danger"><i class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label
                                        class="fs-7 text-{{$diff_app_month_team <= 0 ? 'danger' : 'success'}}">{{round($per_app_month_team)}}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Walk - In</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$walkInCountTodayTeam}}</label>
                                    
                                    @if($differenceTeamWalkInCount > 0)
                                        <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($differenceTeamWalkInCount <= 0) 
                                        <label class="text-danger"><i class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif                                
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label class="fs-7 text-{{$differenceTeamWalkInCount <= 0 ? 'danger' : 'success'}}">{{round($percentageWalkInCountTeam)}}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Followups</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$tdy_flwup_month_team}}</label>

                                    @if($diff_flwup_month_team > 0)
                                        <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($diff_flwup_month_team <= 0) 
                                        <label class="text-danger"><i class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label
                                        class="fs-7 text-{{$diff_flwup_month_team <= 0 ? 'danger' : 'success'}}">{{round($per_flwup_mnth_team)}}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                                </div>
                            </div>
                            <div class="text-center mb-0">
                                <div class="fs-7 fw-semibold mb-1">Outgoing Call</div>
                                <div class="d-block text-center fs-4 text-black fw-bold mb-1">
                                    <label>{{$tdy_calls_month_team}}</label>
                                    
                                    @if($diff_calls_month_team > 0)
                                        <label class="text-success"><i class="mdi mdi-trending-up mdi-20px ms-1"></i></label>
                                    @elseif($diff_calls_month_team <= 0) 
                                        <label class="text-danger"><i class="mdi mdi-trending-down mdi-20px ms-1"></i></label>
                                    @endif
                                </div>
                                <div class="text-center fs-7 fw-bold">
                                    <label class="fs-7 text-{{$diff_calls_month_team <= 0 ? 'danger' : 'success'}}">{{round($per_calls_month_team)}}%</label>
                                    <label class="fs-8 fw-semibold text-gray-200i ms-1">Last Month</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card rounded card-action h-100">
                    <div class="card-header rounded-start-top rounded-end-top border-bottom py-3 pb-2">
                        <div class="card-action-title text-black fw-semibold fs-5">
                            <label class="text-black fw-semibold fs-4">Team Members Monthly Sales Reports &nbsp; -
                                &nbsp;</label>
                            <label class="text-info fw-semibold fs-5">
                                <?php echo date("M-Y"); ?>
                            </label>
                        </div>
                        <div class="card-action-element text-center fw-semibold fs-6">
                            <div class="badge bg-info fw-semibold rounded-pill text-white fs-6">{{$staffFiltering->count()}}</div>
                        </div>
                    </div>
                    <div class="card-body pt-3">
                        <table
                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                    <th class="min-w-200px">Members</th>
                                    <th class="min-w-80px text-center">Active Leads</th>
                                    <th class="min-w-80px text-center">Conversion</th>
                                    <th class="min-w-50px text-center">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Conversion Rate">CR</span>
                                    </th>
                                    <th class="min-w-100px text-center">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Average Business Value">ABV</span>
                                    </th>
                                    <th class="min-w-100px text-center">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Average Collection Value">ACV</span>
                                    </th>
                                    <th class="min-w-50px text-center">Walk-In</th>
                                    <th class="min-w-50px text-center">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Average Outgoing Call Rate">AOCR</span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7">
                                @foreach ($staffFiltering as $staffs)
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="symbol symbol-35px me-1">
                                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                                        @if ($staffs->staff_image)
                                                        <img src="{{ asset('staff_images/' . $staffs->staff_image)}}" alt="user-avatar"
                                                            class="image-input-wrapper w-px-40 h-px-40" />
                                                        @else
                                                        <img src="{{ asset('phdizone_images/staff_3.png')}}" alt="user-avatar" class="image-input-wrapper w-px-40 h-px-40" />
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center mb-0">
                                                    <div class="me-1">
                                                        <label class="fs-8">{{$staffs->staff_name}}</label>
                                                        <div class="d-block">
                                                            <div class="badge bg-info fw-bold fs-9">{{$staffs->job_position_name}}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        @php
                                            $active_leads = $helper->get_active_leads($staffs->sno);
                                            $convert_customer = $helper->get_convrt_customer($staffs->sno);
                                            $cust_percentage = $helper->get_cr_pre($staffs->sno);
                                            $abv_count = $helper->get_abc_count($staffs->sno);
                                            $acv_count = $helper->get_acv_count($staffs->sno);
                                            $walkin_count = $helper->get_walkin_count($staffs->sno);
                                        @endphp
                                        <td>
                                            <div class="fs-7 text-center">{{$active_leads}}</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-center">
                                                <label class="fs-7 badge bg-label-warning text-black fw-semibold">{{$convert_customer}}</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-center">{{$cust_percentage}} %</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-end">&#8377; {{$abv_count}}</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-end">&#8377; {{$acv_count}}</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-center">
                                                <label class="fs-7 badge bg-label-info fw-semibold">{{$walkin_count}}</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-center">13 %</div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card rounded card-action h-100">
                    <div class="card-header rounded-start-top rounded-end-top border-bottom py-3 pb-2">
                        <div class="card-action-title text-black fw-semibold fs-5">
                            <label class="text-black fw-semibold fs-4">Team Members Monthly Lead Reports &nbsp; -
                                &nbsp;</label>
                            <label class="text-info fw-semibold fs-5">
                                {{ date('M-Y') }}
                            </label>
                        </div>
                        <div class="card-action-element text-center fw-semibold fs-6">
                            <div class="badge bg-info fw-semibold rounded-pill text-white fs-6">{{$staffFiltering->count()}}</div>
                        </div>
                    </div>
                    <div class="card-body pt-3">
                        <table
                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                    <th class="min-w-200px">Members</th>
                                    <th class="min-w-100px text-center">Total Leads</th>
                                    <th class="min-w-125px text-center">Active Leads</th>
                                    <th class="min-w-125px text-center">Spam Leads</th>
                                    <th class="min-w-100px text-center">Dead Leads</th>
                                    <th class="min-w-150px text-center">Convt. Customers</th>
                                    <th class="min-w-50px text-center">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="On Day Conversion">ODC</span>
                                    </th>
                                    <th class="min-w-50px text-center">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="On Month Conversion">MC</span>
                                    </th>
                                    <th class="min-w-50px text-center">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Old Month Conversion">OMC</span>
                                    </th>
                                </tr>
                            </thead>
                            @php
                                $total_leads_sum = 0;
                                $active_leads_sum = 0;
                                $spam_leads_sum = 0;
                                $dead_leads_sum = 0;
                                $converted_customers_sum = 0;
                                $odc_sum = 0;
                                $mc_sum = 0;
                                $omc_sum = 0;
                            @endphp
                            <tbody class="text-black fw-semibold fs-7">
                                @foreach ($staffFiltering as $staffs)
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="symbol symbol-35px me-1">
                                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                                        @if ($staffs->staff_image)
                                                        <img src="{{ asset('staff_images/' . $staffs->staff_image)}}" alt="user-avatar"
                                                            class="image-input-wrapper w-px-40 h-px-40" />
                                                        @else
                                                        <img src="{{ asset('phdizone_images/staff_3.png')}}" alt="user-avatar" class="image-input-wrapper w-px-40 h-px-40" />
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center mb-0">
                                                    <div class="me-1">
                                                        <label class="fs-8">{{$staffs->staff_name}}</label>
                                                        <div class="d-block">
                                                            <div class="badge bg-info fw-bold fs-9">{{$staffs->job_position_name}}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            @php
                                                $total_leads = $helper->get_total_leads($staffs->sno);
                                                $active_leads = $helper->get_active_leads($staffs->sno);
                                                $spam_leads = $helper->get_spam_leads($staffs->sno);
                                                $dead_leads = $helper->get_dead_leads($staffs->sno);
                                                $convert_customer = $helper->get_convrt_customer($staffs->sno);
                                                $odc_count = $helper->get_odc_count($staffs->sno);
                                                $mc_count = $helper->get_mc_count($staffs->sno);
                                                $omc_count = $helper->get_omc_count($staffs->sno);

                                                // Accumulate totals
                                                $total_leads_sum += $total_leads;
                                                $active_leads_sum += $active_leads;
                                                $spam_leads_sum += $spam_leads;
                                                $dead_leads_sum += $dead_leads;
                                                $converted_customers_sum += $convert_customer;
                                                $odc_sum += $odc_count;
                                                $mc_sum += $mc_count;
                                                $omc_sum += $omc_count;
                                            @endphp
                                            <div class="fs-7 text-center">{{$total_leads}}</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-center">{{$active_leads}}</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-center">{{$spam_leads}}</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-center">{{$dead_leads}}</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-center">{{$convert_customer}}</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-center">{{$odc_count}}</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-center">{{$mc_count}}</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 text-center">{{$omc_count}}</div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr class="text-start align-top fs-6 gs-0 bg-primary"
                                    style="background-color: #f0913d !important;">
                                    <th class="min-w-200px text-black fw-semibold">Total</th>
                                    <th class="min-w-100px text-center text-black fw-semibold">{{ $total_leads_sum }}</th>
                                    <th class="min-w-125px text-center text-black fw-semibold">{{ $active_leads_sum }}</th>
                                    <th class="min-w-125px text-center text-black fw-semibold">{{ $spam_leads_sum }}</th>
                                    <th class="min-w-100px text-center text-black fw-semibold">{{ $dead_leads_sum }}</th>
                                    <th class="min-w-150px text-center text-black fw-semibold">{{ $converted_customers_sum }}</th>
                                    <th class="min-w-50px text-center text-black fw-semibold">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Total On Day Conversion">{{ $odc_sum }}</span>
                                    </th>
                                    <th class="min-w-50px text-center text-black fw-semibold">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Total On Month Conversion">{{ $mc_sum }}</span>
                                    </th>
                                    <th class="min-w-50px text-center text-black fw-semibold">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Total Old Month Conversion">{{ $omc_sum }}</span>
                                    </th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="card-header rounded-start-top rounded-end-top border-bottom py-3 pb-3"
                        style="background-color:#00ffad !important;">
                        <div class="card-action-title text-black fw-semibold fs-5">Top 5 Sales Person</div>
                    </div>
                    <div class="card-body pt-3">
                        <div class="scroll-y max-h-200px pe-2">
                            @foreach($top_5_sales_persons as $index => $t5sp)
                            <div class="d-flex align-items-center justify-content-between border-bottom pb-2 px-1 py-1 mb-2">
                                <div class="d-flex align-items-center">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input border border-gray-300i rounded bg-label-danger" data-kt-image-input="true">
                                            @if ($t5sp->staff_image)
                                            <img src="{{ asset('staff_images/' . $t5sp->staff_image)}}" alt="user-avatar"
                                                class="image-input-wrapper w-px-40 h-px-40" />
                                            @else
                                            <img src="{{ asset('phdizone_images/staff_3.png')}}" alt="user-avatar"
                                                class="image-input-wrapper w-px-40 h-px-40" />
                                            @endif
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <div class="fs-7 fw-semibold text-black">{{ $t5sp->staff_name }}</div>
                                        <div class="d-block text-dark fw-semibold fs-8">{{ $t5sp->nick_name }}</div>
                                    </div>
                                </div>
                                <div class="text-end fw-semibold">
                                    <div class="text-center fw-semibold fs-8">
                                        <img src="{{ asset('assets/phdizone_images/staff_rate/rank' . ($index + 1) . '.gif') }}" alt="rank"
                                            class="w-55px h-45px" />
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="card-header rounded-start-top rounded-end-top border-bottom py-3 pb-3"
                        style="background-color:#cafc9d !important;">
                        <div class="card-action-title text-black fw-semibold fs-5">Lead Source</div>
                        <div class="card-action-element text-info fw-semibold fs-6">
                            <div class="badge bg-warning fw-semibold rounded-pill fs-6 text-black">{{$lead_sources_team->count()}}</div>
                        </div>
                    </div>
                    <div class="card-body pt-3">
                        <div class="scroll-y max-h-200px pe-2">
                            @foreach($lead_sources_team as $leads)
                            <div class="d-flex align-items-center border-bottom mb-2">
                                <div class="w-50 mb-2">
                                    <div class="text-dark fw-semibold fs-6">{{ $leads->lead_source_name }}</div>
                                </div>
                                <div class="w-50 d-flex align-items-center justify-content-end gap-3 mb-2">
                                    <div class="badge bg-warning text-black fw-semibold rounded-pill fs-7">{{
                                        $leads->total_leads }}</div>
                                    <div class="progress-circle"
                                        style="background: conic-gradient(var(--progress-color) {{ $leads->percentage }}%, var(--background-color) 0);">
                                        <div class="inner-circle"></div>
                                        <div class="percentage">{{$leads->percentage}}%</div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="card-header rounded-start-top rounded-end-top border-bottom py-3 pb-3"
                        style="background-color:#fbcfdf !important;">
                        <div class="card-action-title text-black fw-semibold fs-5">Followup Schedule</div>
                        <div class="card-action-element text-center fw-semibold fs-6">
                            <span class="badge bg-success fw-semibold rounded-pill text-white fs-6">{{$filteredAppointmentsTeam->count()}}</span>
                        </div>
                    </div>
                    <div class="card-body pt-3">
                        <div class="scroll-y max-h-200px pe-2">
                            @foreach ($filteredAppointmentsTeam as $fat)
                                <div class="d-flex align-items-center justify-content-between border-bottom pb-2 px-1 py-1 mb-2">
                                    <div class="mb-0 w_40">
                                        <div class="fw-semibold">
                                            <label class="fs-7 fw-semibold text-black me-2">{{$fat->lead_name}}</label>
                                        </div>
                                        
                                        @if($fat->display_status === 'Completed')
                                            <div class="d-block text-danger fw-semibold fs-8">Completed</div>
                                        @elseif($fat->display_status === 'Rescheduled')
                                            <div class="d-block text-danger fw-semibold fs-8">Re Scheduled</div>
                                        @endif
                                    </div>
                                    <div class="fs-7 fw-semibold text-black flex-wrap w_40" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                        data-bs-original-title="Assigned Staff">{{$fat->staff_name}}</div>
                                    <div class="text-end fw-semibold w_20">
                                        @php
                                        $dtDate = \Carbon\Carbon::parse($fat->appointment_date);
                                        $dtTime = \Carbon\Carbon::parse($fat->appointment_time);
                                        @endphp
                                        <div class="badge bg-success text-black fw-semibold fs-8">@if($fat->display_status ===
                                            'Rescheduled') {{ $dtDate->format('d-M-Y') }} @endif</div>
                                        <div class="d-block">
                                            <div class="badge bg-label-success text-black fw-semibold fs-8">
                                                @if($fat->display_status === 'Rescheduled')
                                                {{ $dtTime->format('h:i A') }}
                                                @else
                                                {{ $dtTime->format('h:i A') }}
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card rounded card-action h-100">
                    <div class="card-header rounded-start-top rounded-end-top border-bottom py-3 pb-3"
                        style="background-color:#f3d9b2 !important;">
                        <div class="card-action-title text-black fw-semibold fs-5">Appointment Schedule</div>
                        <div class="card-action-element text-center fw-semibold fs-6">
                            <span class="fs-7 fw-semibold text-dark">Walk In</span>
                            <span class="badge bg-label-info fw-semibold rounded-pill text-black fs-6">{{$walkInCountTeam}}</span>
                        </div>
                    </div>
                    <div class="card-body pt-3">
                        <div class="scroll-y max-h-200px pe-2">
                            @foreach($appointmentFilterToday as $fill)
                                <div
                                    class="d-flex align-items-center justify-content-between border-bottom pb-2 px-1 py-1 mb-2">
                                    <div class="d-flex align-items-center w_40">
                                        <div class="mb-0 align-items-center">
                                            <div class="fs-7 fw-semibold text-black">{{$fill->lead_name}}</div>
                                            
                                            @if($fill->app_status === 'Completed')
                                                <div class="d-block text-danger fw-semibold fs-8">Completed</div>
                                            @elseif($fill->app_status === 'Rescheduled')
                                                <div class="d-block text-danger fw-semibold fs-8">Re Scheduled</div>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="fs-7 fw-semibold text-black flex-wrap w_40" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" data-bs-original-title="Assigned Staff">{{$fill->staff_name}}</div>
                                    <div class="text-end fw-semibold w_20">
                                        @php
                                        $dtDate = \Carbon\Carbon::parse($fill->appointment_date);
                                        @endphp
                                        <div class="badge bg-success text-black fw-semibold fs-8">@if($fill->app_status === 'Rescheduled') {{ $dtDate->format('d-M-Y') }} @endif</div>
                                        <div class="d-block">
                                            <div class="badge bg-label-success text-black fw-semibold fs-8">
                                                @if($fill->app_status === 'Rescheduled')
                                                {{ $dtDate->format('h:i A') }}
                                                @else
                                                {{ $dtDate->format('h:i A') }}
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<!--begin::Modal - Loser window-->
<div class="modal fade" id="kt_modal_loser_window" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-dialog-centered modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded bg-danger" style="background-color: #ff6e6b !important;">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="text-white fw-semibold fs-2">x</span>
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                @php
                $last_staff = $top_5_sales_persons->last();
                @endphp
                <div class="text-center">
                    <img src="{{asset('assets/phdizone_images/staff_rate/loser.gif')}}" alt="loser"
                        class="w-300px h-300px" />
                </div>
                <div class="text-white text-center mb-3 fs-1 fw-semibold">You’re the last <span
                        class="text-warning fw-bold">{{$last_staff->staff_name}}</span></div>
                <div class="d-block fw-semibold text-center fs-4 text-white">You didn’t just miss the target you’re last
                    in line. Time to wake up, step up, and prove you’ve got what it takes.</div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Loser window-->




<style>
@keyframes shake {
    0% { transform: translate(1px, 1px) rotate(0deg); }
    10% { transform: translate(-1px, -2px) rotate(-1deg); }
    20% { transform: translate(-3px, 0px) rotate(1deg); }
    30% { transform: translate(3px, 2px) rotate(0deg); }
    40% { transform: translate(1px, -1px) rotate(1deg); }
    50% { transform: translate(-1px, 2px) rotate(-1deg); }
    60% { transform: translate(-3px, 1px) rotate(0deg); }
    70% { transform: translate(3px, 1px) rotate(-1deg); }
    80% { transform: translate(-1px, -1px) rotate(1deg); }
    90% { transform: translate(1px, 2px) rotate(0deg); }
    100% { transform: translate(1px, -2px) rotate(-1deg); }
}

.shake-modal {
    animation: shake 0.6s;
}
</style>






<!-- Sad Emoji Animation + Sound -->
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.5.1/dist/confetti.browser.min.js"></script>
<audio id="loseSound" src="https://www.myinstants.com/media/sounds/sad-trombone.mp3" preload="auto"></audio>

<script>
    window.onload = function() {
        const myModalEl = document.getElementById('kt_modal_loser_window');
        const myModal = new bootstrap.Modal(myModalEl);
        myModal.show();

        // Play dramatic "losing" sound
        document.getElementById('loseSound').play();

        // Add shake animation to modal for drama
        myModalEl.classList.add('shake-modal');
        setTimeout(() => myModalEl.classList.remove('shake-modal'), 1000);

        // Create a sad confetti rain (gray, slow, falling)
        const canvas = document.createElement('canvas');
        canvas.style.position = 'fixed';
        canvas.style.top = '0';
        canvas.style.left = '0';
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        canvas.style.pointerEvents = 'none';
        canvas.style.zIndex = '9999';
        document.body.appendChild(canvas);

        const myConfetti = confetti.create(canvas, {
            resize: true,
            useWorker: false
        });

        const sadInterval = setInterval(() => {
            myConfetti({
                particleCount: 50,
                spread: 80,
                gravity: 1.5,
                angle: 90,
                origin: { x: Math.random(), y: 0 },
                colors: ['#aaa', '#888', '#666'], // sad/gray colors
                scalar: 0.8,
                ticks: 150
            });
        }, 400);

        // Stop confetti when modal is closed
        myModalEl.addEventListener('hidden.bs.modal', () => {
            clearInterval(sadInterval);
            canvas.remove();
        });
    };
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection