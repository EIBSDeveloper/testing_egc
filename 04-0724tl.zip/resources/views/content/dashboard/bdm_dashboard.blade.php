
@extends('layouts/layoutMaster')

@section('title', 'Business Development Manager Dashboard')
@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<style>
  .table_1 {
      border-collapse: separate;
      border-spacing: 0;
      width: 100%;
  }

  /* Sticky header */
  .table_1 thead th {
      position: sticky;
      top: 0;
      background: #099dda;
      color: #fff;
      z-index: 10; /* higher than body */
  }

  /* Body cells */
  .table_1 tbody td {
      background: #fff;
      color: #000;
      position: relative;
      z-index: 1;
  }

  /* Sticky first column (header + body) */
  .table_1 thead th:first-child,
  .table_1 tbody td:first-child {
      position: sticky;
      left: 0;
  }

  /* First column header (top priority) */
  .table_1 thead th:first-child {
      z-index: 20; /* highest */
      background: #099dda;
  }

  /* First column body */
  .table_1 tbody td:first-child {
      z-index: 15;
      background: #fff;
  }
  .gradient-card {
    background: linear-gradient(
      to bottom right,
      var(--grad-color),
      #6b6b6b
    );
    border: none;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
  }

  .gradient-dark {
    --grad-color: #3b3a3ae6;    /* danger */
  }

  /* Initial hidden state */
  .fade-in-onload {
      opacity: 0;
      transform: translateY(15px);
      animation: fadeInUp 0.6s ease forwards;
  }

  /* Animation */
  @keyframes fadeInUp {
      to {
          opacity: 1;
          transform: translateY(0);
      }
  }

  .table-wrapper {
    max-height: 300px;
    overflow-y: auto;
    overflow-x: hidden;
    border: 1px solid #eee;
  }

  /* Sticky Header */
  .table-header th {
      position: sticky;
      top: 0;
      z-index: 5;
      background: #099DDA !important;
      color: white;
      padding-top: 10px;
      padding-bottom: 10px;
  }

  .custom-scroll {
    overflow-x: auto;
  }

  .custom-scroll table {
    width: 100%; /* force horizontal scroll */
  }

  /* Sticky first column (header + body) */
  .custom-scroll th:first-child,
  .custom-scroll td:first-child {
      position: sticky;
      left: 0;
      background: #fff; /* IMPORTANT: prevent overlap transparency */
      z-index: 2;
  }

  /* Header needs higher z-index */
  .custom-scroll thead th:first-child {
      z-index: 3;
      background: #0d6efd; /* match your bg-primary */
      color: #fff;
  }

  .stat-card {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    border-radius: 12px;
    color: #fff;
    box-shadow: 0 6px 15px rgba(0,0,0,0.1);
  }

  .stat-card .icon-box {
      width: 50px;
      height: 50px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(255,255,255,0.2);
  }

  .stat-card .icon-box i {
      font-size: 24px;
      color: #fff;
  }

  .stat-card h4 {
      margin: 0;
      font-weight: 700;
  }

  .stat-card span {
      font-size: 13px;
      opacity: 0.9;
  }

  .stat-card.green {
      background: linear-gradient(135deg, #1abc9c, #16a085);
  }

  .stat-card.blue {
      background: linear-gradient(135deg, #4e73df, #224abe);
  }

  .stat-card.pink {
      background: linear-gradient(135deg, #c850c0, #ff0066);
  }

  .stat-gradient {
      background: linear-gradient(135deg, #00b09b, #96c93d); /* green gradient */
      border: none;
      color: #fff;
  }

  .icon-badge {
      background: rgba(255,255,255,0.2);
      color: #fff;
      border-radius: 10px;
      padding: 8px 10px;
  }

  /* Optional Hover Effect */
  .stat-gradient:hover {
      transform: translateY(-3px);
      transition: 0.3s ease;
      box-shadow: 0 10px 25px rgba(0,0,0,0.15);
  }

  /* WARNING GRADIENT */
  .stat-gradient-warning {
      background: linear-gradient(135deg, #f7971e, #ffd200); /* orange → yellow */
      border: none;
      color: #fff;
  }

  /* keep same icon style */
  .stat-gradient-warning .icon-badge {
      background: rgba(255,255,255,0.25);
      color: #fff;
  }

  /* same hover */
  .stat-gradient-warning:hover {
      transform: translateY(-3px);
      transition: 0.3s ease;
      box-shadow: 0 10px 25px rgba(0,0,0,0.15);
  }
</style>
<div class="row g-3">
  <div class="col-lg-12  d-flex justify-content-end align-items-center">
    <div class="" style="width:200px;">
        <div class="cursor-pointer input-group input-group-merge">
            <span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="dateFilter" class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class" value="<?php echo date("M-Y"); ?>" readonly onchange="dataFilterChange()">
            <span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-menu-down fs-4"></i></span>
        </div>
    </div>
  </div>
  <div class="col-lg-4 fade-in-onload">
    <div class="card rounded shadow w-100 ">
      <div class="card-body p-3">
        <div class="d-flex align-items-center justify-content-start gap-2">
          <span class="badge bg-label-info rounded-circle">
           <img src="{{ asset('assets/phdizone_images/admin.png') }}" alt="" width="50px">
          </span>
          <div class="d-flex flex-column align-items-center">
            <span class="text-dark fs-6 fw-semibold">
              Hey {{$user->staff_name}} 👋, Glad You are back again,
            </span>
            <label class="d-flex align-items-center justify-content-start gap-2">
              <span class="text-primary fw-semibold">Business Development Manager</span>
              <span>|</span>
              <span class="text-success">
                <i class="mdi mdi-heart"></i>
              </span>
              <span class="text-success fw-semibold">25%</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4 fade-in-onload">
    <div class="card stat-gradient-warning rounded shadow w-100">
      <div class="card-body p-3">
        <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
          <div class="d-flex flex-column">
            <span class="text-dark fs-6 fw-medium">
              Target
            </span>
            <span class="text-black fs-2 fw-semibold">
              ₹ 34,000
            </span>
          </div>
          <span class="badge bg-label-warning rounded">
            <i class="mdi mdi-bullseye text-warning fs-3"></i>
          </span>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4 fade-in-onload">
    <div class="card stat-gradient rounded shadow w-100">
      <div class="card-body p-3">
        <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
          
          <div class="d-flex flex-column">
            <span class="text-white fs-6 fw-medium">
              Achieved
            </span>
            <span class="text-white fs-2 fw-semibold">
              ₹ 26,669
            </span>
          </div>

          <span class="badge icon-badge">
            <i class="mdi mdi-shield-star-outline fs-3"></i>
          </span>

        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="card rounded shadow fade-in-onload">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-2">
            <label class="text-dark fw-semibold fs-6">Lead Pipeline</label>
            <span class="badge bg-warning rounded-3 text-black"><i class="mdi mdi-account-outline"></i>Myself</span>
          </div>
          <div class="col-lg-12 mb-2">
            <div class="row border p-2 rounded bg-gray-100">
              <div class="col-md-3 border-end">
                <div class="d-flex flex-column">
                  <label>
                    <span>
                      <i class="mdi mdi-account-multiple-outline text-black fs-4"></i>
                    </span>
                    <span class="text-dark fs-6 fw-medium">
                      Total Leads
                    </span>
                  </label>
                  <span class="text-black fs-2 fw-semibold" id="self-total-lead-this-month">
                    45
                  </span>
                  <label class="d-flex align-items-center justify-content-start gap-2 fs-8">
                    <span class="text-success fw-semibold">+ 45%</span>
                    <span class="text-success fw-semibold">Vs Last Month</span>
                  </label>
                </div>
              </div>
              <div class="col-md-3 border-end">
                <div class="d-flex flex-column">
                  <label>
                    <span>
                      <i class="mdi mdi-account-heart-outline text-black fs-4"></i>
                    </span>
                    <span class="text-dark fs-6 fw-medium">
                      Active Leads
                    </span>
                  </label>
                  <span class="text-info fs-2 fw-semibold">
                    33
                  </span>
                  <label class="d-flex align-items-center justify-content-start gap-2 fs-8">
                    <span class="text-success fw-semibold">+ 23%</span>
                    <span class="text-success fw-semibold">Vs Last Month</span>
                  </label>
                </div>
              </div>
              <div class="col-md-3 border-end">
                <div class="d-flex flex-column">
                  <label>
                    <span>
                      <i class="mdi mdi-account-remove-outline text-black fs-4"></i>
                    </span>
                    <span class="text-dark fs-6 fw-medium">
                      Dead Leads
                    </span>
                  </label>
                  <span class="text-primary fs-2 fw-semibold">
                    08
                  </span>
                  <label class="d-flex align-items-center justify-content-start gap-2 fs-8">
                    <span class="text-danger fw-semibold">- 0.5%</span>
                    <span class="text-danger fw-semibold">Vs Last Month</span>
                  </label>
                </div>
              </div>
              <div class="col-md-3">
                <div class="d-flex flex-column">
                  <label>
                    <span>
                      <i class="mdi mdi-account-cancel-outline text-black fs-4"></i>
                    </span>
                    <span class="text-dark fs-6 fw-medium">
                      Spam Leads
                    </span>
                  </label>
                  <span class="text-danger fs-2 fw-semibold">
                    04
                  </span>
                  <label class="d-flex align-items-center justify-content-start gap-2 fs-8">
                    <span class="text-danger fw-semibold">- 0.5%</span>
                    <span class="text-danger fw-semibold">Vs Last Month</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card rounded shadow w-100 fade-in-onload">
      <div class="card-body py-3">
        <div class="row">
          <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-2">
            <label class="text-dark fw-semibold fs-6">Financials</label>
            <span class="badge bg-warning rounded-3 text-black"><i class="mdi mdi-account-outline"></i>Myself</span>
          </div>
          <div class="mb-2 d-flex align-items-center justify-content-between gap-2 p-2 rounded bg-gray-100">
              <span class="text-dark fs-6 fw-medium">
                Avg. Business Value
              </span>
              <span class="text-black fs-2 fw-semibold">
                ₹ 36,500
              </span>
          </div>
          <div class="mb-2 d-flex align-items-center justify-content-between gap-2 p-2 rounded bg-gray-100">
              <span class="text-dark fs-6 fw-medium">
                Avg. Collection Value
              </span>
              <span class="text-black fs-2 fw-semibold">
                ₹ 15,000
              </span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="card rounded shadow fade-in-onload">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-2">
            <label class="text-dark fw-semibold fs-6">Lead Pipeline</label>
            <span class="badge bg-danger rounded-3 text-white"><i class="mdi mdi-account-multiple-outline"></i>Team</span>
          </div>
          <div class="col-lg-12 mb-2">
            <div class="row border p-2 rounded bg-gray-100">
              <div class="col-md-3 border-end">
                <div class="d-flex flex-column">
                  <label>
                    <span>
                      <i class="mdi mdi-account-multiple-outline text-black fs-4"></i>
                    </span>
                    <span class="text-dark fs-6 fw-medium">
                      Total Leads
                    </span>
                  </label>
                  <span class="text-black fs-2 fw-semibold">
                    152
                  </span>
                  <label class="d-flex align-items-center justify-content-start gap-2 fs-8">
                    <span class="text-success fw-semibold">+ 45%</span>
                    <span class="text-success fw-semibold">Vs Last Month</span>
                  </label>
                </div>
              </div>
              <div class="col-md-3 border-end">
                <div class="d-flex flex-column">
                  <label>
                    <span>
                      <i class="mdi mdi-account-heart-outline text-black fs-4"></i>
                    </span>
                    <span class="text-dark fs-6 fw-medium">
                      Active Leads
                    </span>
                  </label>
                  <span class="text-info fs-2 fw-semibold">
                    96
                  </span>
                  <label class="d-flex align-items-center justify-content-start gap-2 fs-8">
                    <span class="text-success fw-semibold">+ 23%</span>
                    <span class="text-success fw-semibold">Vs Last Month</span>
                  </label>
                </div>
              </div>
              <div class="col-md-3 border-end">
                <div class="d-flex flex-column">
                  <label>
                    <span>
                      <i class="mdi mdi-account-remove-outline text-black fs-4"></i>
                    </span>
                    <span class="text-dark fs-6 fw-medium">
                      Dead Leads
                    </span>
                  </label>
                  <span class="text-primary fs-2 fw-semibold">
                    35
                  </span>
                  <label class="d-flex align-items-center justify-content-start gap-2 fs-8">
                    <span class="text-danger fw-semibold">- 0.5%</span>
                    <span class="text-danger fw-semibold">Vs Last Month</span>
                  </label>
                </div>
              </div>
              <div class="col-md-3">
                <div class="d-flex flex-column">
                  <label>
                    <span>
                      <i class="mdi mdi-account-cancel-outline text-black fs-4"></i>
                    </span>
                    <span class="text-dark fs-6 fw-medium">
                      Spam Leads
                    </span>
                  </label>
                  <span class="text-danger fs-2 fw-semibold">
                    21
                  </span>
                  <label class="d-flex align-items-center justify-content-start gap-2 fs-8">
                    <span class="text-danger fw-semibold">- 0.5%</span>
                    <span class="text-danger fw-semibold">Vs Last Month</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card rounded shadow w-100 fade-in-onload">
      <div class="card-body py-3">
        <div class="row">
          <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-2">
            <label class="text-dark fw-semibold fs-6">Financials</label>
            <span class="badge bg-danger rounded-3 text-white"><i class="mdi mdi-account-multiple-outline"></i>Team</span>
          </div>
          <div class="mb-2 d-flex align-items-center justify-content-between gap-2 p-2 rounded bg-gray-100">
              <span class="text-dark fs-6 fw-medium">
                Avg. Business Value
              </span>
              <span class="text-black fs-2 fw-semibold">
                ₹ 36,500
              </span>
          </div>
          <div class="mb-2 d-flex align-items-center justify-content-between gap-2 p-2 rounded bg-gray-100">
              <span class="text-dark fs-6 fw-medium">
                Avg. Collection Value
              </span>
              <span class="text-black fs-2 fw-semibold">
                ₹ 15,000
              </span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="card rounded shadow w-100 fade-in-onload">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-12 mb-1">
            <label class="text-dark fw-semibold">Sales Performance Trend (Last 6 Months)</label>
          </div>
          <div class="col-lg-12">
            <div id="sales_performance_myself"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4 fade-in-onload">
    <div class="card rounded shadow gradient-card gradient-dark">
      <div class="card-body p-2">
        <div class="row">
          <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-5">
            <label class="text-white fs-6 fw-semibold">Quick Stats</label>
          </div>
          <div class="col-lg-12">
            <div class="d-flex align-items-center justify-content-between mb-2 gap-5 bg-white rounded py-1 px-3">
              <label class="text-dark fs-7">On Day Conversion</label>
              <label class="text-black fs-2">15</label>
            </div>
            <div class="d-flex align-items-center justify-content-between mb-2 gap-5 bg-white rounded py-1 px-3">
              <label class="text-dark fs-7">On Month Conversion</label>
              <label class="text-black fs-2">150</label>
            </div>
            <div class="d-flex align-items-center justify-content-between mb-2 gap-5 bg-white rounded py-1 px-3">
              <label class="text-dark fs-7">Last Month Conversion</label>
              <label class="text-danger fs-2">168</label>
            </div>
            <div class="d-flex align-items-center justify-content-between mb-2 gap-5 bg-white rounded py-1 px-3">
              <label class="text-dark fs-7">Conversion Rate</label>
              <label class="text-black fs-2">48%</label>
            </div>
            <hr class="text-white">
            <div class="d-flex align-items-center justify-content-between gap-5">
              <label class="text-white fs-7">Appointments</label>
              <label class="text-white fw-semibold fs-2">12</label>
            </div>
            <div class="d-flex align-items-center justify-content-between gap-5">
              <label class="text-white fs-7">Walk-ins</label>
              <label class="text-white fw-semibold fs-2">31</label>
            </div>
            <div class="d-flex align-items-center justify-content-between gap-5">
              <label class="text-white fs-7">Follow-ups</label>
              <label class="text-white fw-semibold fs-2">25</label>
            </div>
            <div class="d-flex align-items-center justify-content-between gap-5">
              <label class="text-white fs-7">Outgoing Calls</label>
              <label class="text-white fw-semibold fs-2">128</label>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4 col-md-6">
    <div class="stat-card green">
      <div class="icon-box">
        <i class="mdi mdi-check-circle-outline"></i>
      </div>
      <div class="text-end">
        <h4 class="text-white">₹25,832.91</h4>
        <span>Recent Payment</span>
      </div>
    </div>
  </div>
  <div class="col-lg-4 col-md-6">
    <div class="stat-card blue">
      <div class="icon-box">
        <i class="mdi mdi-credit-card-outline"></i>
      </div>
      <div class="text-end">
        <h4 class="text-white">₹2,71,330.87</h4>
        <span>Outstanding Details</span>
      </div>
    </div>
  </div>
  <div class="col-lg-4 col-md-6">
    <div class="stat-card pink">
      <div class="icon-box">
        <i class="mdi mdi-file-document-outline"></i>
      </div>
      <div class="text-end">
        <h4 class="text-white">₹7,70,281</h4>
        <span>Total Collections</span>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card rounded shadow w-100 fade-in-onload">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-12 ">
            <div class="d-flex align-items-center justify-content-between mb-3">
              <div class="fw-semibold text-dark fs-6">Outstanding Details</div>
              <label class="fs-6 badge bg-label-danger rounded   border border-danger">
                  <span class="fw-semibold text-black">06</span>
              </label> 
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <div class="table-wrapper">
              <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                <thead class="table-header">
                  <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                    <th class="min-w-80px">Customer</th>
                    <th class="min-w-50px">Amount</th>
                  </tr>
                </thead>
                <tbody class="table-body text-black fw-semibold fs-7">
                  <tr>
                    <td>
                        <div class="d-flex align-items-center gap-1">
                          <img src="{{ asset('assets/phdizone_images/user_1.png') }}" alt="customer image" class="w-45px h-45px rounded-circle border border-2">
                          <div class="d-flex flex-column">
                              <label class="fs-6 me-1">Arjun Babu G</label>
                              <span class="text-primary fs-8">2025/MDU01/CUS2130</span>
                          </div>
                        </div>
                    </td>                                  
                    <td>
                      <span class="fs-5 text-danger">26,860.34</span>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div class="d-flex align-items-center gap-1">
                        <img src="{{ asset('assets/phdizone_images/user_1.png') }}" class="w-45px h-45px rounded-circle border border-2">
                        <div class="d-flex flex-column">
                          <label class="fs-6 me-1">Karthik R</label>
                          <span class="text-primary fs-8">2025/MDU01/CUS2131</span>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span class="fs-5 text-danger">18,540.00</span>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div class="d-flex align-items-center gap-1">
                        <img src="{{ asset('assets/phdizone_images/admin.png') }}" class="w-45px h-45px rounded-circle border border-2">
                        <div class="d-flex flex-column">
                          <label class="fs-6 me-1">Divya S</label>
                          <span class="text-primary fs-8">2025/MDU01/CUS2132</span>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span class="fs-5 text-danger">32,120.75</span>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div class="d-flex align-items-center gap-1">
                        <img src="{{ asset('assets/phdizone_images/user_1.png') }}" class="w-45px h-45px rounded-circle border border-2">
                        <div class="d-flex flex-column">
                          <label class="fs-6 me-1">Praveen Kumar</label>
                          <span class="text-primary fs-8">2025/MDU01/CUS2133</span>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span class="fs-5 text-danger">9,875.50</span>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div class="d-flex align-items-center gap-1">
                        <img src="{{ asset('assets/phdizone_images/admin.png') }}" class="w-45px h-45px rounded-circle border border-2">
                        <div class="d-flex flex-column">
                          <label class="fs-6 me-1">Meena Lakshmi</label>
                          <span class="text-primary fs-8">2025/MDU01/CUS2134</span>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span class="fs-5 text-danger">41,300.20</span>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div class="d-flex align-items-center gap-1">
                        <img src="{{ asset('assets/phdizone_images/user_1.png') }}" class="w-45px h-45px rounded-circle border border-2">
                        <div class="d-flex flex-column">
                          <label class="fs-6 me-1">Sathish V</label>
                          <span class="text-primary fs-8">2025/MDU01/CUS2135</span>
                        </div>
                    </div>
                    </td>
                    <td>
                      <span class="fs-5 text-danger">22,760.90</span>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div class="d-flex align-items-center gap-1">
                        <img src="{{ asset('assets/phdizone_images/admin.png') }}" class="w-45px h-45px rounded-circle border border-2">
                        <div class="d-flex flex-column">
                          <label class="fs-6 me-1">Anitha R</label>
                          <span class="text-primary fs-8">2025/MDU01/CUS2136</span>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span class="fs-5 text-danger">15,990.00</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div> 
  </div>
  <div class="col-lg-6 fade-in-onload">
    <div class="card rounded  shadow fade-in-onload" style="height: 385px" >
      <div class="card-body">
        <div class="row">
          <div class="col-lg-12 mb-3">
            <div class="d-flex justify-content-between align-items-center">
              <label class="fw-semibold">Low MPC Paid (<span class="text-info fw-semibold mx-1"><?php echo date('M-Y'); ?></span>)</label>
              <label class="fw-semibold badge text-white " style="background: black">03</label>
            </div>
          </div>
          <div class="col-lg-12">
            <div class="row scroll-y" style="max-height:300px;">
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img
                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                    alt="avatar"
                    class="rounded-circle img-fluid"
                    style="width: 40px; height: 40px; object-fit: cover;"
                  >
                  <div class="d-flex flex-column">
                    <label class="fw-semibold fs-7 text-black">Gopinath P</label>
                    <label class="fw-semibold fs-8 text-secondary">2025/MDU01/CUS2130</label>
                  </div>
                </div>
                  <div class="d-flex flex-column align-items-end">
                  <label class="fw-semibold fs-8 text-danger">₹ 3,000</label>
                  <span class="badge bg-label-danger fs-8 text-danger">5 Days Left</span>
                  </div>
                </div>
              </div>
              <hr class="mb-2">
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img
                    src="{{ asset('assets/phdizone_images/admin.png') }}"
                    alt="avatar"
                    class="rounded-circle img-fluid"
                    style="width: 40px; height: 40px; object-fit: cover;"
                  >
                  <div class="d-flex flex-column">
                    <label class="fw-semibold fs-7 text-black">Swetha</label>
                    <label class="fw-semibold fs-8 text-secondary">2025/MDU01/CUS2129</label>
                  </div>
                </div>
                  <div class="d-flex flex-column align-items-end">
                  <label class="fw-semibold fs-8 text-danger">₹ 4,300</label>
                  <span class="badge bg-label-danger fs-8 text-danger">4 Days Left</span>
                  </div>
                </div>
              </div>
              <hr class="mb-2">
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img
                    src="{{ asset('assets/phdizone_images/admin.png') }}"
                    alt="avatar"
                    class="rounded-circle img-fluid"
                    style="width: 40px; height: 40px; object-fit: cover;"
                  >
                  <div class="d-flex flex-column">
                    <label class="fw-semibold fs-7 text-black">Aishwarya V S</label>
                    <label class="fw-semibold fs-8 text-secondary">2025/MDU01/CUS2128</label>
                  </div>
                </div>
                  <div class="d-flex flex-column align-items-end">
                  <label class="fw-semibold fs-8 text-danger">₹ 4,300</label>
                  <span class="badge bg-label-danger fs-8 text-danger">3 Days Left</span>
                  </div>
                </div>
              </div>
              <hr class="mb-2">
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img src="{{ asset('assets/phdizone_images/user_3.png') }}"
                      class="rounded-circle img-fluid"
                      style="width: 40px; height: 40px; object-fit: cover;">
                    <div class="d-flex flex-column">
                      <label class="fw-semibold fs-7 text-black">Karthik R</label>
                      <label class="fw-semibold fs-8 text-secondary">2025/MDU01/CUS2131</label>
                    </div>
                  </div>
                  <div class="d-flex flex-column align-items-end">
                    <label class="fw-semibold fs-8 text-danger">₹ 2,150</label>
                    <span class="badge bg-label-danger fs-8 text-danger">6 Days Left</span>
                  </div>
                </div>
              </div>
              <hr class="mb-2">
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img src="{{ asset('assets/phdizone_images/admin.png') }}"
                      class="rounded-circle img-fluid"
                      style="width: 40px; height: 40px; object-fit: cover;">
                    <div class="d-flex flex-column">
                      <label class="fw-semibold fs-7 text-black">Divya S</label>
                      <label class="fw-semibold fs-8 text-secondary">2025/MDU01/CUS2132</label>
                    </div>
                  </div>
                  <div class="d-flex flex-column align-items-end">
                    <label class="fw-semibold fs-8 text-danger">₹ 5,600</label>
                    <span class="badge bg-label-danger fs-8 text-danger">2 Days Left</span>
                  </div>
                </div>
              </div>
              <hr class="mb-2">
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img src="{{ asset('assets/phdizone_images/user_3.png') }}"
                      class="rounded-circle img-fluid"
                      style="width: 40px; height: 40px; object-fit: cover;">
                    <div class="d-flex flex-column">
                      <label class="fw-semibold fs-7 text-black">Praveen Kumar</label>
                      <label class="fw-semibold fs-8 text-secondary">2025/MDU01/CUS2133</label>
                    </div>
                  </div>
                  <div class="d-flex flex-column align-items-end">
                    <label class="fw-semibold fs-8 text-danger">₹ 1,980</label>
                    <span class="badge bg-label-danger fs-8 text-danger">7 Days Left</span>
                  </div>
                </div>
              </div>
              <hr class="mb-2">
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img src="{{ asset('assets/phdizone_images/admin.png') }}"
                      class="rounded-circle img-fluid"
                      style="width: 40px; height: 40px; object-fit: cover;">
                    <div class="d-flex flex-column">
                      <label class="fw-semibold fs-7 text-black">Meena Lakshmi</label>
                      <label class="fw-semibold fs-8 text-secondary">2025/MDU01/CUS2134</label>
                    </div>
                  </div>
                  <div class="d-flex flex-column align-items-end">
                    <label class="fw-semibold fs-8 text-danger">₹ 3,750</label>
                    <span class="badge bg-label-danger fs-8 text-danger">1 Day Left</span>
                  </div>
                </div>
              </div>
              <hr class="mb-2">
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img src="{{ asset('assets/phdizone_images/user_3.png') }}"
                      class="rounded-circle img-fluid"
                      style="width: 40px; height: 40px; object-fit: cover;">
                    <div class="d-flex flex-column">
                      <label class="fw-semibold fs-7 text-black">Sathish V</label>
                      <label class="fw-semibold fs-8 text-secondary">2025/MDU01/CUS2135</label>
                    </div>
                  </div>
                  <div class="d-flex flex-column align-items-end">
                    <label class="fw-semibold fs-8 text-danger">₹ 6,200</label>
                    <span class="badge bg-label-danger fs-8 text-danger">8 Days Left</span>
                  </div>
                </div>
              </div>
              <hr class="mb-2">
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img src="{{ asset('assets/phdizone_images/admin.png') }}"
                      class="rounded-circle img-fluid"
                      style="width: 40px; height: 40px; object-fit: cover;">
                    <div class="d-flex flex-column">
                      <label class="fw-semibold fs-7 text-black">Anitha R</label>
                      <label class="fw-semibold fs-8 text-secondary">2025/MDU01/CUS2136</label>
                    </div>
                  </div>
                  <div class="d-flex flex-column align-items-end">
                    <label class="fw-semibold fs-8 text-danger">₹ 2,890</label>
                    <span class="badge bg-label-danger fs-8 text-danger">9 Days Left</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-12 fade-in-onload">
    <div class="card rounded fade-in-onload shadow">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-12 mb-3">
            <div class="d-flex justify-content-between align-items-center">
              <label class="fw-semibold">Team Members Monthly Sales & Lead Reports (<span class="text-info ms-1"><?php echo date('M-Y'); ?></span>)</label>
              <label class="fw-semibold badge text-white " style="background: black">04</label>
            </div>
          </div>
          <div class="col-lg-12">
            <table class="table_1 table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page ">
              <thead>
                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                  <th class="min-w-100px" >Members</th>
                  <th class="min-w-100px text-center" >Total Leads</th>
                  <th class="min-w-150px text-center" >Active Leads</th>
                  <th class="min-w-100px text-center" >Dead Leads</th>
                  <th class="min-w-100px text-center" >Spam Leads</th>
                  <th class="min-w-100px text-center ">Conversion</th>
                  <th class="min-w-100px text-center " data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Day Conversion">ODC</th>
                  <th class="min-w-100px text-center " data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Month Conversion">MC</th>
                  <th class="min-w-100px text-center " data-bs-toggle="tooltip" data-bs-placement="bottom" title="Old Day Conversion">OMC</th>
                  <th class="min-w-150px text-center">Conversion Rate</th>
                  <th class="min-w-100px text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Average Bussiness Value">ABV</th>
                  <th class="min-w-100px text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Average Collection Value">ACV</th>
                  <th class="min-w-100px text-center">Walk-In</th>
                  <th class="min-w-100px text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Average Outgoing Call Rate">AOCR</th>
                </tr>
              </thead>
              <tbody class="text-black fw-semibold fs-7">
                <tr>
                  <td>
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="d-flex gap-2 align-items-center">
                        <img src="{{ asset('assets/phdizone_images/user_3.png') }}" class="rounded-circle img-fluid" style="width: 40px; height: 40px; object-fit: cover;">
                        <div class="d-flex flex-column">
                          <label class="fw-semibold fs-7 text-black">Karthik R</label>
                          <label class="fw-semibold fs-8 badge bg-label-info">Sales Executive</label>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">180</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">140</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">15</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">25</label>
                  </td>
                  <td align="center">
                    <span class="px-2 fw-semibold fs-6" style="border-radius:4px; background:#f1f8e9; color:#33691e; border:1px solid #33691e;">38</span>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">12</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">20</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">10</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">11%</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">₹ 11,500</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">₹ 15,200</label>
                  </td>
                  <td align="center">
                    <span class="px-2 fw-semibold fs-6" style="border-radius:4px; background:#fff0e0; color:#e65100; border:1px solid #e65100;">9</span>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">10%</label>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="d-flex gap-2 align-items-center">
                        <img src="{{ asset('assets/phdizone_images/user_3.png') }}" class="rounded-circle img-fluid" style="width: 40px; height: 40px; object-fit: cover;">
                        <div class="d-flex flex-column">
                          <label class="fw-semibold fs-7 text-black">Divya S</label>
                          <label class="fw-semibold fs-8 badge bg-label-info">Telecaller</label>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">220</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">170</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">20</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">30</label>
                  </td>
                  <td align="center">
                    <span class="px-2 fw-semibold fs-6" style="border-radius:4px; background:#f1f8e9; color:#33691e; border:1px solid #33691e;">50</span>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">18</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">25</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">7</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">14%</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">₹ 14,000</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">₹ 19,000</label>
                  </td>
                  <td align="center">
                    <span class="px-2 fw-semibold fs-6" style="border-radius:4px; background:#fff0e0; color:#e65100; border:1px solid #e65100;">15</span>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">15%</label>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="d-flex gap-2 align-items-center">
                        <img src="{{ asset('assets/phdizone_images/user_3.png') }}" class="rounded-circle img-fluid" style="width: 40px; height: 40px; object-fit: cover;">
                        <div class="d-flex flex-column">
                          <label class="fw-semibold fs-7 text-black">Praveen Kumar</label>
                          <label class="fw-semibold fs-8 badge bg-label-info">Sales Executive</label>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">160</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">120</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">18</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">22</label>
                  </td>
                  <td align="center">
                    <span class="px-2 fw-semibold fs-6" style="border-radius:4px; background:#f1f8e9; color:#33691e; border:1px solid #33691e;">30</span>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">10</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">15</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">5</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">9%</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">₹ 9,500</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">₹ 13,000</label>
                  </td>
                  <td align="center">
                    <span class="px-2 fw-semibold fs-6" style="border-radius:4px; background:#fff0e0; color:#e65100; border:1px solid #e65100;">8</span>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">8%</label>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="d-flex gap-2 align-items-center">
                        <img src="{{ asset('assets/phdizone_images/user_3.png') }}" class="rounded-circle img-fluid" style="width: 40px; height: 40px; object-fit: cover;">
                        <div class="d-flex flex-column">
                          <label class="fw-semibold fs-7 text-black">Meena Lakshmi</label>
                          <label class="fw-semibold fs-8 badge bg-label-info">Counsellor</label>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">240</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">190</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">16</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">34</label>
                  </td>
                  <td align="center">
                    <span class="px-2 fw-semibold fs-6" style="border-radius:4px; background:#f1f8e9; color:#33691e; border:1px solid #33691e;">60</span>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">20</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">30</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">10</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">16%</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">₹ 16,000</label>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">₹ 22,000</label>
                  </td>
                  <td align="center">
                    <span class="px-2 fw-semibold fs-6" style="border-radius:4px; background:#fff0e0; color:#e65100; border:1px solid #e65100;">18</span>
                  </td>
                  <td align="center">
                    <label class="text-black fw-semibold fs-6">18%</label>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4 fade-in-onload ">
    <div class="card rounded fade-in-onload shadow " style="height: 400px" >
      <div class="card-body">
        <div class="row">
          <div class="col-lg-12">
            <div class="d-flex justify-content-between align-items-center">
              <label class="fw-semibold">Followup Schedule (<span class="text-info fw-semibold mx-1"><?php echo date('d-M-Y'); ?></span>)</label>
              <label class="fw-semibold badge text-white " style="background: black">03</label>
            </div>
          </div>
          <div class="col-lg-12"><hr></div>
          <div class="col-lg-12">
            <div class="row scroll-y" style="max-height:350px;">
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img
                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                    alt="avatar"
                    class="rounded-circle img-fluid"
                    style="width: 40px; height: 40px; object-fit: cover;"
                  >
                  <div class="d-flex flex-column">
                    <label class="fw-semibold fs-7 text-black">Bhavani</label>
                    <label class="fw-semibold fs-8 text-success">Completed</label>
                  </div>
                </div>
                  <div class="d-flex flex-column align-items-end justify-content-end">
                  <span class="badge bg-label-primary text-white mb-1" style="width:fit-content;">11:45 AM</span>
                  <div class="d-flex gap-1 align-items-center">
                    <div class="d-flex gap-1 align-items-center  px-1" style="border-radius:5px ; background:#e3f2fd; color:#0d47a1; border:1px solid #0d47a1 ; width: fit-content;">
                      <div class="d-flex align-items-center">
                        <span class="mdi mdi-account-circle me-1 " data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff"></span>
                        <label class="fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff">
                          Charles darwin
                        </label>
                      </div>
                    </div>
                  </div>
                  </div>
                </div>

              </div>

              <hr class="mb-2">

              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img
                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                    alt="avatar"
                    class="rounded-circle img-fluid"
                    style="width: 40px; height: 40px; object-fit: cover;"
                  >
                  <div class="d-flex flex-column">
                    <label class="fw-semibold fs-7 text-black">Palpandi</label>
                    <label class="fw-semibold fs-8 text-danger">Re-Scheduled</label>
                    <label class="fw-semibold fs-8 text-danger">13-Mar-2025</label>
                  </div>
                </div>
                  <div class="d-flex flex-column align-items-end justify-content-end">
                  <span class="badge bg-label-primary text-white mb-1" style="width:fit-content;">11:45 AM</span>
                  <div class="d-flex gap-1 align-items-center">
                    <div class="d-flex gap-1 align-items-center  px-1" style="border-radius:5px ; background:#e3f2fd; color:#0d47a1; border:1px solid #0d47a1 ; width: fit-content;">
                      <div class="d-flex align-items-center">
                        <span class="mdi mdi-account-circle me-1 " data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff"></span>
                        <label class="fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff">
                          Lewis hamilton
                        </label>
                      </div>
                    </div>
                  </div>
                  </div>
                </div>

              </div>

              <hr class="mb-2">

              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img
                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                    alt="avatar"
                    class="rounded-circle img-fluid"
                    style="width: 40px; height: 40px; object-fit: cover;"
                  >
                  <div class="d-flex flex-column">
                    <label class="fw-semibold fs-7 text-black">Saravana priyan</label>
                  </div>
                </div>
                  <div class="d-flex flex-column align-items-end justify-content-end">
                  <span class="badge bg-label-primary text-white mb-1" style="width:fit-content;">12:15 PM</span>
                  <div class="d-flex gap-1 align-items-center">
                    <div class="d-flex gap-1 align-items-center  px-1" style="border-radius:5px ; background:#e3f2fd; color:#0d47a1; border:1px solid #0d47a1 ; width: fit-content;">
                      <div class="d-flex align-items-center">
                        <span class="mdi mdi-account-circle me-1 " data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff"></span>
                        <label class="fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff">
                          Lando norris
                        </label>
                      </div>
                    </div>
                  </div>
                  </div>
                </div>

              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4 fade-in-onload">
    <div class="card rounded fade-in-onload shadow " style="height: 400px" >
      <div class="card-body">
        <div class="row">
          <div class="col-lg-12">
            <div class="d-flex justify-content-between align-items-center">
              <label class="fw-semibold">Appointment Schedule (<span class="text-info fw-semibold mx-1"><?php echo date('d-M-Y'); ?></span>)</label>
              <label class="fw-semibold badge text-white " style="background: black">03</label>
            </div>
          </div>
          <div class="col-lg-12"><hr></div>
          <div class="col-lg-12">
            <div class="row scroll-y" style="max-height:350px;">


              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img
                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                    alt="avatar"
                    class="rounded-circle img-fluid"
                    style="width: 40px; height: 40px; object-fit: cover;"
                  >
                  <div class="d-flex flex-column">
                    <label class="fw-semibold fs-7 text-black">Kesava</label>
                    <label class="fw-semibold fs-8 text-success">Completed</label>
                  </div>
                </div>
                  <div class="d-flex flex-column align-items-end justify-content-end">
                  <span class="badge bg-label-primary text-white mb-1" style="width:fit-content;">11:45 AM</span>
                  <div class="d-flex gap-1 align-items-center">
                    <div class="d-flex gap-1 align-items-center  px-1" style="border-radius:5px ; background:#e3f2fd; color:#0d47a1; border:1px solid #0d47a1 ; width: fit-content;">
                      <div class="d-flex align-items-center">
                        <span class="mdi mdi-account-circle me-1 " data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff"></span>
                        <label class="fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff">
                          Max
                        </label>
                      </div>
                    </div>
                  </div>
                  </div>
                </div>

              </div>

              <hr class="mb-2">

              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img
                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                    alt="avatar"
                    class="rounded-circle img-fluid"
                    style="width: 40px; height: 40px; object-fit: cover;"
                  >
                  <div class="d-flex flex-column">
                    <label class="fw-semibold fs-7 text-black">Sigashini</label>
                    <label class="fw-semibold fs-8 text-danger">Re-Scheduled</label>
                    <label class="fw-semibold fs-8 text-danger">13-Mar-2025</label>
                  </div>
                </div>
                  <div class="d-flex flex-column align-items-end justify-content-end">
                  <span class="badge bg-label-primary text-white mb-1" style="width:fit-content;">11:45 AM</span>
                  <div class="d-flex gap-1 align-items-center">
                    <div class="d-flex gap-1 align-items-center  px-1" style="border-radius:5px ; background:#e3f2fd; color:#0d47a1; border:1px solid #0d47a1 ; width: fit-content;">
                      <div class="d-flex align-items-center">
                        <span class="mdi mdi-account-circle me-1 " data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff"></span>
                        <label class="fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff">
                          Max Verstappen
                        </label>
                      </div>
                    </div>
                  </div>
                  </div>
                </div>

              </div>

              <hr class="mb-2">

              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img
                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                    alt="avatar"
                    class="rounded-circle img-fluid"
                    style="width: 40px; height: 40px; object-fit: cover;"
                  >
                  <div class="d-flex flex-column">
                    <label class="fw-semibold fs-7 text-black">Karthikeyan</label>
                  </div>
                </div>
                  <div class="d-flex flex-column align-items-end justify-content-end">
                  <span class="badge bg-label-primary text-white mb-1" style="width:fit-content;">12:15 PM</span>
                  <div class="d-flex gap-1 align-items-center">
                    <div class="d-flex gap-1 align-items-center  px-1" style="border-radius:5px ; background:#e3f2fd; color:#0d47a1; border:1px solid #0d47a1 ; width: fit-content;">
                      <div class="d-flex align-items-center">
                        <span class="mdi mdi-account-circle me-1 " data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff"></span>
                        <label class="fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff">
                          Vik
                        </label>
                      </div>
                    </div>
                  </div>
                  </div>
                </div>

              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4 fade-in-onload">
    <div class="card rounded  shadow fade-in-onload" style="height: 400px" >
      <div class="card-body">
        <div class="row">
          <div class="col-lg-12">
            <div class="d-flex justify-content-between align-items-center">
              <label class="fw-semibold">Recent Payment (<span class="text-info fw-semibold mx-1"><?php echo date('d-M-Y'); ?></span>)</label>
              <label class="fw-semibold badge text-white " style="background: black">05</label>
            </div>
          </div>
          <div class="col-lg-12"><hr></div>
          <div class="col-lg-12">
            <div class="row scroll-y" style="max-height:350px;">
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img src="{{ asset('assets/phdizone_images/user_2.png') }}" class="rounded-circle img-fluid" style="width: 40px; height: 40px; object-fit: cover;">
                    <div class="d-flex flex-column">
                      <label class="fw-semibold fs-7 text-black">Arun Kumar</label>
                      <label class="fw-semibold fs-8 text-dark">2025/MDU01/CUS/1235</label>
                    </div>
                  </div>
                  <div class="d-flex flex-column align-items-end">
                    <span class="badge bg-label-primary text-white mb-1">10-May-2026</span>
                    <div class="d-flex gap-1 align-items-center px-1" style="border-radius:5px;background:#fde3ef;color:#c0072f;border:1px solid #c0072f;width:fit-content;">
                      <span class="mdi mdi-currency-inr me-1 fs-8"></span>
                      <label class="fw-semibold fs-7">8,450</label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img src="{{ asset('assets/phdizone_images/admin.png') }}" class="rounded-circle img-fluid" style="width: 40px; height: 40px; object-fit: cover;">
                    <div class="d-flex flex-column">
                      <label class="fw-semibold fs-7 text-black">Divya Sharma</label>
                      <label class="fw-semibold fs-8 text-dark">2025/MDU01/CUS/1236</label>
                    </div>
                  </div>
                  <div class="d-flex flex-column align-items-end">
                    <span class="badge bg-label-primary text-white mb-1">09-May-2026</span>
                    <div class="d-flex gap-1 align-items-center px-1" style="border-radius:5px;background:#fde3ef;color:#c0072f;border:1px solid #c0072f;width:fit-content;">
                      <span class="mdi mdi-currency-inr me-1 fs-8"></span>
                      <label class="fw-semibold fs-7">12,300</label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img src="{{ asset('assets/phdizone_images/user_5.png') }}" class="rounded-circle img-fluid" style="width: 40px; height: 40px; object-fit: cover;">
                    <div class="d-flex flex-column">
                      <label class="fw-semibold fs-7 text-black">Rohit Verma</label>
                      <label class="fw-semibold fs-8 text-dark">2025/MDU01/CUS/1237</label>
                    </div>
                  </div>
                  <div class="d-flex flex-column align-items-end">
                    <span class="badge bg-label-primary text-white mb-1">08-May-2026</span>
                    <div class="d-flex gap-1 align-items-center px-1" style="border-radius:5px;background:#fde3ef;color:#c0072f;border:1px solid #c0072f;width:fit-content;">
                      <span class="mdi mdi-currency-inr me-1 fs-8"></span>
                      <label class="fw-semibold fs-7">5,980</label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img src="{{ asset('assets/phdizone_images/admin.png') }}" class="rounded-circle img-fluid" style="width: 40px; height: 40px; object-fit: cover;">
                    <div class="d-flex flex-column">
                      <label class="fw-semibold fs-7 text-black">Meena Iyer</label>
                      <label class="fw-semibold fs-8 text-dark">2025/MDU01/CUS/1238</label>
                    </div>
                  </div>
                  <div class="d-flex flex-column align-items-end">
                    <span class="badge bg-label-primary text-white mb-1">07-May-2026</span>
                    <div class="d-flex gap-1 align-items-center px-1" style="border-radius:5px;background:#fde3ef;color:#c0072f;border:1px solid #c0072f;width:fit-content;">
                      <span class="mdi mdi-currency-inr me-1 fs-8"></span>
                      <label class="fw-semibold fs-7">18,750</label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="d-flex gap-2 align-items-center">
                    <img src="{{ asset('assets/phdizone_images/user_1.png') }}" class="rounded-circle img-fluid" style="width: 40px; height: 40px; object-fit: cover;">
                    <div class="d-flex flex-column">
                      <label class="fw-semibold fs-7 text-black">Sanjay Patel</label>
                      <label class="fw-semibold fs-8 text-dark">2025/MDU01/CUS/1239</label>
                    </div>
                  </div>
                  <div class="d-flex flex-column align-items-end">
                    <span class="badge bg-label-primary text-white mb-1">06-May-2026</span>
                    <div class="d-flex gap-1 align-items-center px-1" style="border-radius:5px;background:#fde3ef;color:#c0072f;border:1px solid #c0072f;width:fit-content;">
                      <span class="mdi mdi-currency-inr me-1 fs-8"></span>
                      <label class="fw-semibold fs-7">9,640</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }
</style>
<script>
  function getLast6Months() {
      const months = [];
      const today = new Date();

      for (let i = 5; i >= 0; i--) {
          let d = new Date(today.getFullYear(), today.getMonth() - i, 1);
          months.push(d.toLocaleString('default', { month: 'short', year: 'numeric' }));
      }

      return months;
  }

  // Labels (last 6 months)
  const categories = getLast6Months();

  // Dummy data (replace with API later)
  const totalLeads = [120, 150, 180, 220, 260, 300];
  const conversions = [40, 60, 75, 110, 140, 180];

  var options = {
      series: [
          {
              name: "Total Leads",
              data: totalLeads
          },
          {
              name: "Conversions",
              data: conversions
          }
      ],
      chart: {
          type: 'area',
          height: 350,
          toolbar: { show: false }
      },
      dataLabels: {
          enabled: false
      },
      stroke: {
          curve: 'smooth',
          width: 3
      },
      colors: ['#fd9d0d', '#04864a'], // blue & green
      fill: {
          type: 'gradient',
          gradient: {
              shadeIntensity: 1,
              opacityFrom: 0.4,
              opacityTo: 0.1
          }
      },
      xaxis: {
          categories: categories
      },
      yaxis: {
          title: {
              text: 'Count'
          }
      },
      legend: {
          position: 'top',
          horizontalAlign: 'right'
      }
  };

  var chart = new ApexCharts(document.querySelector("#sales_performance_myself"), options);
  chart.render();
</script>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
  function initializeTooltips() {
        setTimeout(() => {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.forEach(tooltipTriggerEl => {
                try {
                    new bootstrap.Tooltip(tooltipTriggerEl);
                } catch (e) {
                    console.log('Tooltip initialization error:', e);
                }
            });
        }, 500);
    }
</script>
<script>
    //  $('#dateFilter').datepicker({
    //         format: "mm-yyyy",
    //         startView: "months",
    //         minViewMode: "months",
    //         autoclose: true,
    //         todayHighlight: true
    //     }).on('changeMonth', function(e) {
    //         const month = e.date.getMonth() + 1;
    //         const year = e.date.getFullYear();
    //         const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct',
    //             'Nov', 'Dec'
    //         ];
    //         const formattedDate = `${monthNames[month-1]}-${year}`;
    //         const activeTab = $('.tab-pane.fade.show.active').attr('id');
    //         // Update date filter value
    //         $('#dateFilter').val(formattedDate);

    //         loadBDMDashboard (formattedDate);
            
    //     });

   
</script>
<script>
  function convertDisplayDateToApiDate(displayDate) {
        if (!displayDate) return null;

        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const parts = displayDate.split('-');
        const monthName = parts[0];
        const year = parts[1];
        const monthIndex = monthNames.findIndex(m => m.toLowerCase() === monthName.toLowerCase()) + 1;

        return `${monthIndex.toString().padStart(2, '0')}-${year}`;
    }

    // Format date for display (03-2025 to Mar-2025)
    function formatDateForDisplay(dateStr) {
        if (!dateStr) return '';
        const parts = dateStr.split('-');
        if (parts.length !== 2) return dateStr;

        const month = parseInt(parts[0]);
        const year = parts[1];
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

        return `${monthNames[month-1]}-${year}`;
    }
</script>
<script>
  async function loadBDMDashboard() {
        const loadingEl = document.getElementById('self-loading');
        const dateFilter = document.getElementById('dateFilter');

        // Get date for API
        let apiDate = dateFilter;
       
            const displayDate = dateFilter ? dateFilter.value : '<?php echo date('M-Y'); ?>';
            apiDate = displayDate;
        

        // Show loading
        if (loadingEl) loadingEl.classList.remove('d-none');

        try {

            const apiDateFormatted = convertDisplayDateToApiDate(apiDate);

            const params = new URLSearchParams({
                date_filter: apiDate
            });

            const response = await fetch(
                `/dashboard/bdm_data?${params.toString()}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json'
                    }
                }
            );

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            console.log('API Response:', result); // Debug log

            // Check if we have the expected structure
            if (result.data) {
                updateSelfDashboard(result.data);
            } else if (result.success) {
                // If response doesn't have data property but has success
                updateSelfDashboard(result);
            } else {
                // If response has different structure (like your example)
                updateSelfDashboard(result);
            }

        } catch (error) {
            console.error('Error loading self dashboard:', error);
            toastr.success('error', 'Failed to load dashboard data: ' + error.message);
        } finally {
            if (loadingEl) loadingEl.classList.add('d-none');
        }
    }
</script>
<script>
   function updateElementText(elementId, text) {
        const element = document.getElementById(elementId);
        if (element) element.textContent = text;
    }

    function updateFollowupSchedule(Followups, containerId) {
        const container = document.getElementById(containerId);
        const countBadge = document.getElementById(containerId.replace('-container', '-count'));

        if (!container) return;

        let html = '';
        Followups.forEach(followup => {
            html += `
                    <div class="col-lg-12 mb-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex gap-2 align-items-center">
                               <div class="symbol symbol-35px me-2">                                    
                                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold"
                                        style="width:35px;height:35px;">
                                        ${followup.lead_name?.charAt(0).toUpperCase()}
                                    </div>                                                                
                                </div>
                                <div class="d-flex flex-column">
                                    <label class="fw-semibold fs-7 text-black">${followup.lead_name}</label>
                                    <div class="d-block text-info fw-semibold fs-8">${followup.lead_ai_id}</div>
                                    ${followup.display_status === 'Rescheduled' ? '<div class="d-block text-danger fw-semibold fs-8">Re-Scheduled</div>' : ''}
                                </div>
                            </div>
                           ${followup.appointment_date ? `
                                <div class="d-flex flex-column">
                                    <span class="badge bg-label-primary text-white">${followup.appointment_time || ''}</span>
                                    <label class="fw-semibold fs-8 text-danger">${followup.appointment_date}</label>
                                </div>
                            ` : `
                                <span class="badge bg-label-primary text-white">${followup.appointment_time}</span>
                            `}
                        </div>
                    </div>
                    <hr class="mb-2">
                `;
        });

        if (Followups.length === 0) {
            html = '<div class="col-lg-12 text-center text-muted py-3">No followups scheduled for today</div>';
        }

        container.innerHTML = html;
        // console.log(html);
        // Update count badge
        if (countBadge) {
            countBadge.textContent = Followups.length;
        }
    }

     // Format currency
    function formatCurrency(amount) {
        if (typeof amount === 'number') {
            return '₹ ' + amount.toLocaleString('en-IN', {
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            });
        }
        return amount;
    }

    // Update Appointment Schedule for self dashboard
    function updateAppointmentSchedule(Appointments, containerId) {
        const container = document.getElementById(containerId);
        const countBadge = document.getElementById(containerId.replace('-container', '-count'));
        if (!container) return;

        let html = '';
        Appointments.forEach(appointment => {
            html += `
                    <div class="col-lg-12 mb-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex gap-2 align-items-center">
                               <div class="symbol symbol-35px me-2">
                                    ${
                                        appointment.avatar
                                        ? `
                                                                    <img src="${appointment.avatar}"
                                                                        alt="user-avatar"
                                                                        class="rounded-circle w-35px h-35px object-fit-cover" />
                                                                `
                                        : `
                                                                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold"
                                                                        style="width:35px;height:35px;">
                                                                        ${appointment.lead_name?.charAt(0).toUpperCase()}
                                                                    </div>
                                                                `
                                    }
                                </div>
                                <div class="d-flex flex-column">
                                    <div class="fs-7 fw-semibold text-black mb-0 align-items-center text-truncate max-w-350px"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="${appointment.lead_name} - ${appointment.lead_ai_id}" >${appointment.lead_name} - ${appointment.lead_ai_id}</div>
                                    ${appointment.app_status === 'Rescheduled'
                                        ? '<div class="d-block text-danger fw-semibold fs-8">Re-Scheduled</div>'
                                        : ''
                                    }
                                    ${appointment.app_status === 'Completed'
                                        ? '<div class="d-block text-success fw-semibold fs-8">Re-Scheduled</div>'
                                        : ''
                                    }
                                    ${appointment.app_status === 'Scheduled'
                                        ? '<div class="d-block text-info fw-semibold fs-8">Scheduled</div>'
                                        : ''
                                    }
                                </div>
                            </div>
                            ${appointment.appointment_date ? `
                                <div class="d-flex flex-column">
                                    <span class="badge bg-label-primary text-white">${appointment.appointment_time || ''}</span>
                                    <label class="fw-semibold fs-8 text-danger">${appointment.appointment_date}</label>
                                </div>
                            ` : `
                                <span class="badge bg-label-primary text-white">${appointment.appointment_time || ''}</span>
                            `}
                        </div>
                    </div>
                    <hr class="mb-2">
                `;
        });

        if (Appointments.length === 0) {
            html = '<div class="col-lg-12 text-center text-muted py-3">No appointments scheduled for today</div>';
        }

        container.innerHTML = html;

        // Update count badge
        if (countBadge) {
            countBadge.textContent = Appointments.length;
        }
    }

    // Update Low MPC for self dashboard
    function updateLowMpc(items, containerId) {
        const container = document.getElementById(containerId);
        const countBadge = document.getElementById(containerId.replace('-container', '-count'));

        if (!container) return;

        let html = '';
        let entries = Object.entries(items); // 👈 KEY FIX

        entries.forEach(([key, mpc]) => {
            html += `
            <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex gap-2 align-items-center">
                        <div class="symbol symbol-35px me-2">
                            <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold" style="width:35px;height:35px;">
                                ${(mpc.customer_name || 'U').charAt(0).toUpperCase()}
                            </div>
                        </div>
                        <div class="d-flex flex-column">
                            <label class="fw-semibold fs-7 text-black">
                                ${mpc.customer_name || 'Unknown'}
                            </label>
                            <label class="fw-semibold fs-8 text-secondary">
                                ${key}
                            </label>
                        </div>
                    </div>
                    <div class="d-flex flex-column align-items-end">
                        <label class="fw-semibold fs-8 text-danger">
                        ${formatCurrency(mpc.total_paid || 0)}
                        </label>
                        <span class="badge bg-label-danger fs-8 text-danger">
                            ${mpc.days_left || ''}
                        </span>
                    </div>
                </div>
            </div>
            <hr class="mb-2">
        `;
        });

        if (entries.length === 0) {
            html = '<div class="col-lg-12 text-center text-muted py-3">No low MPC payments</div>';
        }

        container.innerHTML = html;

        // Update count badge
        if (countBadge) {
            countBadge.textContent = entries.length;
        }
    }
  function updateSelfDashboard(data) {
        console.log('Self dashboard data:', data); // Debug log

        // Today's metrics - using the actual field names from your response
        $('#self-total-lead-this-month').html(data.total_leads || 0);
        $('#self-total-lead-last-month').html(`${data.total_leads_prev ||0} Last Month`);

        $('#self-active-lead-this-month').html(data.active_leads || 0);
        $('#self-active-lead-last-month').html(`${data.active_leads_prev ||0} Last Month`);

        $('#self-spam-lead-this-month').html(data.spam_leads || 0);
        $('#self-spam-lead-last-month').html(`${data.spam_leads_prev ||0} Last Month`);

        $('#self-dead-lead-this-month').html(data.dead_leads || 0);
        $('#self-dead-lead-last-month').html(`${data.dead_leads_prev ||0} Last Month`);

        // Monthly metrics - using staff target data
        const staffTarget = data.StaffTarget || {};
        updateElementText('self-conversion-month', staffTarget.conversion_actual || 0);
        updateElementText('self-conversion-rate-month', `${staffTarget.CR_actual || "0.00"}%`);
        updateElementText('self-avg-business-month', `₹ ${formatNumber(staffTarget.ABV_actual || 0)}`);
        updateElementText('self-avg-collection-month', `₹ ${formatNumber(staffTarget.ACV_actual || 0)}`);

        // Today Status - using avg fields
        $('#self-this-month-appointments').html(data.appointmentsToday || 0);
        $('#self-last-month-appointments').html(`${data.appointmentsYesterday ||0} Last Month`);
        $('#self-this-month-walkin-change').html(data.monthwalkincount || 0);
        $('#self-last-month-walkin-change').html(`${data.Premonthwalkincount ||0} Last Month`);
        $('#self-this-month-followups').html(data.monthFollowupCount || 0);
        $('#self-last-month-followups').html(`${data.PremonthFollowupCount ||0} Last Month`);
        $('#self-this-month-outgoing').html(data.monthcall_out.outgoing_call_count || 0);
        $('#self-last-month-outgoing').html(`${data.Premonthcall_out ||0} Last Month`);

        // Conversion Types
        updateElementText('self-on-month-conversion', data.mc_count || 0);
        updateElementText('self-old-month-conversion', data.omc_count || 0);
        updateElementText('self-one-day-conversion', data.odc_count || 0);

        // Followup Schedule
        if (data.followup_schedule && Array.isArray(data.followup_schedule)) {
            updateFollowupSchedule(data.followup_schedule, 'self-followup-container');
        } else {
            updateFollowupSchedule([], 'self-followup-container');
        }

        // Appointment Schedule
        if (data.appointment_schedule && Array.isArray(data.appointment_schedule)) {
            updateAppointmentSchedule(data.appointment_schedule, 'self-appointment-container');
        } else {
            updateAppointmentSchedule([], 'self-appointment-container');
        }

        // Low MPC
        if (data.low_mpc_list && typeof data.low_mpc_list === 'object') {
            updateLowMpc(data.low_mpc_list, 'self-low-mpc-container');
        } else {
            updateLowMpc({}, 'self-low-mpc-container');
        }


        // console.log('low_mpc_list', data.low_mpc_list)

        // Update count badges

        // Initialize tooltips after data load
        setTimeout(() => initializeTooltips(), 100);
    }
</script>

<script>
   function dataFilterChange(){
     
      loadBDMDashboard();

    }

        loadBDMDashboard();
        initializeTooltips();
</script>
@endsection
