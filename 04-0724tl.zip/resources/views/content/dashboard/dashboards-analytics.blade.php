@extends('layouts/layoutMaster')

@section('title', 'Dashboard - CRM')

@section('vendor-style')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
  'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
  'resources/assets/vendor/libs/apex-charts/apex-charts.scss',
  'resources/assets/vendor/libs/swiper/swiper.scss'
])
@endsection

@section('page-style')
<!-- Page -->
@vite([
  'resources/assets/vendor/scss/pages/cards-statistics.scss',
  'resources/assets/vendor/scss/pages/cards-analytics.scss'
])
@endsection

@section('vendor-script')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
  'resources/assets/vendor/libs/apex-charts/apexcharts.js',
  'resources/assets/vendor/libs/swiper/swiper.js'
  ])
@endsection

@section('page-script')
@vite('resources/assets/js/dashboards-crm.js')
@endsection

@section('content')
{{-- <div class="row gy-4 mb-4">
  <!-- Coming Soon Dashboard Card -->
  <div class="col-xl-12">
    <div class="card shadow-lg" style="min-height: 650px; position: relative; overflow: hidden;">
      <div class="card-body h-100 d-flex flex-column flex-md-row justify-content-between px-4 px-md-5 align-items-center gap-4">

        <!-- Left: Text + Countdown -->
        <div class="d-flex flex-column justify-content-center gap-4 text-center text-md-start" style="max-width: 100%; flex: 1;">
          <!-- Message -->
          <div class="p-4 shadow" style="background: linear-gradient(135deg, #099ad9, #eb9431); color: white; animation: fadeInUp 1s ease; border-radius: 32px;">
            <h1 class="card-title text-white mb-3 fw-bold">
              <i class="mdi mdi-lightning-bolt me-2 fs-1"></i>Dashboard Coming Soon!
            </h1>
            <p class="lead mb-3">We are working hard to bring you something amazing.</p>
            <p class="mb-0 opacity-75">Stay tuned — exciting updates are on the way.</p>
          </div>

          <!-- Countdown Box -->
          <div class="d-flex justify-content-center justify-content-md-start flex-wrap gap-3" id="countdownBox">
            <!-- Countdown units will be inserted via JS -->
          </div>
        </div>

        <!-- Right: Image -->
        <div class="text-end d-flex align-items-center justify-content-center" style="flex: 1;">
          <img src="{{ asset('assets/phdizone_images/dashboard/phd-assist.png') }}" alt="Coming Soon"
            style="max-width: 100%; max-height: 520px;" class="img-fluid">
        </div>
      </div>
    </div>
  </div>
</div> --}}
<div class="row gy-4 mb-4">
  <!-- Coming Soon Dashboard Card -->
  <div class="col-xl-12">
    <div class="card shadow-lg position-relative text-white rounded" style="min-height: 650px; overflow: hidden; background:#4ec5f8">

      <!-- Left Background Image -->
      <div class="position-absolute top-0 start-0 h-100"
           style="width: 50%;
                  background-image: url('{{ asset('assets/phdizone_images/dashboard/phd-Helper.png') }}');
                  background-size: contain;
                  background-repeat: no-repeat;
                  background-position: left center;
                  opacity: 0.8;
                  z-index: 1;">
      </div>

      <!-- Right Background Image -->
      <div class="position-absolute top-0 end-0 h-100"
           style="width: 50%;
                  background-image: url('{{ asset('assets/phdizone_images/dashboard/phd-assist.png') }}');
                  background-size: contain;
                  background-repeat: no-repeat;
                  background-position: right center;
                  opacity: 0.6;
                  z-index: 1;">
      </div>

      <!-- Content Layer -->
      <div class="card-body h-100 position-relative d-flex flex-column justify-content-center align-items-center text-center px-4 px-md-5">

        <!-- Main Message Box -->
        <div class="p-4 mb-4 shadow glass-box">
          <h1 class="card-title text-white mb-3 fw-bold">
            <i class="mdi mdi-lightning-bolt me-2 fs-1"></i>Dashboard Coming Soon!
          </h1>
          <p class="lead mb-3">We are working hard to bring you something amazing.</p>
          <p class="mb-0 opacity-75">Stay tuned — exciting updates are on the way.</p>
        </div>

        <!-- Countdown Box -->
        <div class="d-flex justify-content-center flex-wrap gap-3 " id="countdownBox"></div>
      </div>
    </div>
  </div>
</div>

<!-- Styles -->
<style>
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(40px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .card-body {
    z-index: 2;
  }
  .glass-box {
    background: rgba(255, 255, 255, 0.1); /* Semi-transparent white */
    border-radius: 32px;
    backdrop-filter: blur(10px); /* The blur effect */
    -webkit-backdrop-filter: blur(10px); /* Safari support */
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.2);
    max-width: 700px;
  }
  #countdownBox .time-box {
    background: #ea9332;
    color: #fff;
    padding: 20px;
    border-radius: 20px;
    min-width: 90px;
    text-align: center;
  }

  #countdownBox .time-box span {
    display: block;
    font-size: 1.5rem;
    font-weight: bold;
  }

  #countdownBox .time-box small {
    display: block;
    font-size: 0.875rem;
    opacity: 0.8;
  }

  html, body {
    overflow-x: hidden;
  }

  @media (max-width: 768px) {
    .card-body {
      flex-direction: column !important;
    }

    .position-absolute[style*="left"],
    .position-absolute[style*="right"] {
      background-size: 80% !important;
      opacity: 0.05 !important;
    }
  }

  /* .time-box {
      padding: 20px;
      border-radius: 20px;
      min-width: 90px;
      text-align: center;
      color: #fff;
      font-weight: bold;
    }

    .time-box span {
      display: block;
      font-size: 1.5rem;
    }

    .time-box small {
      display: block;
      font-size: 0.875rem;
      opacity: 0.8;
    }

    /* Glass Effect */
    /* .time-box.glass-box {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.2);
    } */

</style>

<!-- JS Countdown -->
<script>
  function updateCountdown() {
    const endDate = new Date("2025-06-30T00:00:00").getTime();
    const now = new Date().getTime();
    const diff = endDate - now;

    if (diff <= 0) {
     // document.getElementById("countdownBox").innerHTML = `<div class="time-box"><span>0</span><small>Launched</small></div>`;
      return;
    }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const mins = Math.floor((diff / (1000 * 60)) % 60);
    const secs = Math.floor((diff / 1000) % 60);

    document.getElementById("countdownBox").innerHTML = `
      <div class="time-box glass-box"><span>${days}</span><small>Days</small></div>
      <div class="time-box glass-box"><span>${hours}</span><small>Hours</small></div>
      <div class="time-box glass-box"><span>${mins}</span><small>Minutes</small></div>
      <div class="time-box glass-box"><span>${secs}</span><small>Seconds</small></div>
    `;
  }

  setInterval(updateCountdown, 1000);
  updateCountdown();
</script>



  <!--/ Congratulations card -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>




@endsection
