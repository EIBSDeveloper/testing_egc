@extends('layouts/layoutMaster')

@section('title', 'CEO & Business Head Dashboard')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('content')

    <style>
        .fade-in-onload {
            animation: fadeInUp 0.8s ease-out forwards;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(52px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Universal sticky table styles - FIXED FOR ALL TABLES */
        .table-wrapper {
            overflow: auto;
            max-height: 600px;
            max-width: 100%;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            position: relative;
            margin-bottom: 20px;
            border: 1px solid #dee2e6;
        }

        /* Sticky header - applies to all sticky tables */
        .sticky_table {
            width: 100%;
            border-collapse: separate !important;
            border-spacing: 0 !important;
            background: white;
        }

        .sticky_table thead tr {
            position: sticky !important;
            top: 0 !important;
            z-index: 1000 !important;
        }

        .sticky_table thead th {
            position: sticky !important;
            top: 0 !important;
            background: #099DDA !important;
            color: white !important;
            z-index: 1000 !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
            border-bottom: 2px solid rgba(255, 255, 255, 0.3) !important;
            white-space: nowrap;
            padding: 12px 8px !important;
            font-weight: 600;
        }

        /* Sticky first column (Staff) */
        .sticky_table th.col-staff,
        .sticky_table td.col-staff {
            position: sticky !important;
            left: 0 !important;
            z-index: 900 !important;
            background: white !important;
            min-width: 200px;
            max-width: 200px;
            border-right: 2px solid #dee2e6 !important;
            box-shadow: 2px 0 5px -2px rgba(0, 0, 0, 0.1);
        }

        .sticky_table th.col-staff-journal,
        .sticky_table td.col-staff-journal {
            position: sticky !important;
            left: 0 !important;
            z-index: 900 !important;
            background: white !important;
            min-width: 150px;
            max-width: 150px;
            border-right: 2px solid #dee2e6 !important;
            box-shadow: 2px 0 5px -2px rgba(0, 0, 0, 0.1);
        }

        /* Sticky second column (Work/Stage) */
        .sticky_table th.col-work,
        .sticky_table td.col-work {
            position: sticky !important;
            left: 200px !important;
            z-index: 850 !important;
            background: white !important;
            min-width: 200px;
            max-width: 200px;
            border-right: 2px solid #dee2e6 !important;
            box-shadow: 2px 0 5px -2px rgba(0, 0, 0, 0.1);
        }

        .sticky_table th.col-work-journal,
        .sticky_table td.col-work-journal {
            position: sticky !important;
            left: 200px !important;
            z-index: 850 !important;
            background: white !important;
            min-width: 100px;
            max-width: 100px;
            border-right: 2px solid #dee2e6 !important;
            box-shadow: 2px 0 5px -2px rgba(0, 0, 0, 0.1);
        }

        /* Sticky last column (Action) */
        .sticky_table th.col-action,
        .sticky_table td.col-action {
            position: sticky !important;
            right: 0 !important;
            z-index: 900 !important;
            background: white !important;
            min-width: 140px;
            max-width: 140px;
            border-left: 2px solid #dee2e6 !important;
            box-shadow: -2px 0 5px -2px rgba(0, 0, 0, 0.1);
        }

        /* Header sticky columns - higher z-index */
        .sticky_table thead th.col-staff,
        .sticky_table thead th.col-work,
        .sticky_table thead th.col-staff-journal,
        .sticky_table thead th.col-work-journal,
        .sticky_table thead th.col-action {
            background: #099DDA !important;
            color: white !important;
            z-index: 1100 !important;
            border-bottom: 2px solid rgba(255, 255, 255, 0.3) !important;
        }

        /* Header sticky column borders */
        .sticky_table thead th.col-staff {
            border-right: 2px solid rgba(255, 255, 255, 0.3) !important;
        }

        .sticky_table thead th.col-work {
            border-right: 2px solid rgba(255, 255, 255, 0.3) !important;
        }

        .sticky_table thead th.col-action {
            border-left: 2px solid rgba(255, 255, 255, 0.3) !important;
        }

        /* Day columns - normal scrolling */
        .sticky_table th.day-col,
        .sticky_table td.day-col {
            min-width: 180px;
            max-width: 180px;
            text-align: center;
            background: white;
            white-space: nowrap;
        }

        .sticky_table thead th.day-col {
            background: #099DDA !important;
            color: white !important;
            z-index: 950 !important;
        }

        /* Table cell borders */
        .sticky_table td {
            border: 1px solid #dee2e6 !important;
            padding: 12px 8px !important;
            vertical-align: middle;
            background: white;
        }

        /* Hover effect for sticky cells */
        .sticky_table tbody tr:hover td.col-staff,
        .sticky_table tbody tr:hover td.col-work,
        .sticky_table tbody tr:hover td.col-action {
            background: #f8f9fa !important;
        }

        .sticky_table tbody tr:hover td {
            background: #f8f9fa;
        }

        /* Fix for sales table specific */
        .sales_table {
            width: 100%;
            border-collapse: separate !important;
            border-spacing: 0 !important;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {

            .sticky_table th.col-staff,
            .sticky_table td.col-staff {
                min-width: 220px;
                left: 0;
            }

            .sticky_table th.col-work,
            .sticky_table td.col-work {
                min-width: 160px;
                left: 220px;
            }

            .sticky_table th.col-action,
            .sticky_table td.col-action {
                min-width: 120px;
            }

            .sticky_table th.day-col,
            .sticky_table td.day-col {
                min-width: 150px;
            }
        }

        /* Safari compatibility */
        @media screen and (-webkit-min-device-pixel-ratio: 0) {

            .sticky_table th.col-staff,
            .sticky_table td.col-staff,
            .sticky_table th.col-work,
            .sticky_table td.col-work,
            .sticky_table th.col-action,
            .sticky_table td.col-action {
                -webkit-transform: translateZ(0);
            }
        }

        /* Custom scrollbar */
        .table-wrapper::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }

        .table-wrapper::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 5px;
        }

        .table-wrapper::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 5px;
        }

        .table-wrapper::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        /* Loader Styles */
        .loader-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.95);
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: opacity 0.3s ease;
        }

        .loader-content {
            text-align: center;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        .spinner-border {
            width: 3rem;
            height: 3rem;
        }

        .data-loading {
            opacity: 0.6;
            pointer-events: none;
        }

        table thead th {
            border: 1px solid #fff !important;
        }

        table tbody td {
            border: 1px solid #0000003d !important;
        }

        /* ===== Skeleton Loader ===== */
        .skeleton-container {
            width: 100%;
            padding: 20px;
        }

        .skeleton {
            position: relative;
            overflow: hidden;
            background-color: #e9ecef;
            border-radius: 6px;
        }

        .skeleton::after {
            content: '';
            position: absolute;
            top: 0;
            left: -150px;
            width: 150px;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, .6), transparent);
            animation: skeleton-loading 1.2s infinite;
        }

        @keyframes skeleton-loading {
            100% {
                left: 100%;
            }
        }

        .skeleton-table {
            width: 100%;
            border-collapse: collapse;
        }

        .skeleton-table td {
            padding: 15px 12px !important;
            border-bottom: 1px solid #dee2e6 !important;
        }

        .skeleton-text {
            height: 16px;
            margin-bottom: 8px;
            border-radius: 4px;
        }

        .skeleton-text-sm {
            height: 14px;
            width: 80%;
            margin-bottom: 6px;
        }

        .skeleton-badge {
            height: 34px;
            width: 120px;
            border-radius: 20px;
        }

        .skeleton-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .skeleton-cell {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
        }

        .skeleton-progress {
            height: 45px;
            width: 140px;
            border-radius: 8px;
        }

        .skeleton-status {
            height: 30px;
            width: 100px;
            border-radius: 20px;
            margin: 0 auto;
        }

        .table-skeleton-wrapper {
            width: 100%;
            background: white;
            border-radius: 8px;
            overflow: hidden;
        }

        .skeleton-header {
            background: #099DDA;
            padding: 12px;
        }

        .skeleton-header-cell {
            height: 20px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 4px;
        }

        .dashboard-bg-icon {
            width: 120px;
            height: 120px;
            opacity: 0.5;
            filter: blur(1px);
            transform: scale(1.1);
            transition: transform 0.4s ease;
        }


        .gradient-card {
            background: linear-gradient(to bottom right,
                    var(--grad-color),
                    #ffffff);
            border: none;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
        }

        .gradient-info {
            --grad-color: #f2ecff;
            /* info */
        }

        .gradient-success {
            --grad-color: #cee2d7;
            /* success */
        }

        .gradient-primary {
            --grad-color: #eaf9ff;
            /* warning */
        }

        .gradient-danger {
            --grad-color: #fdd7dbe6;
            /* danger */
        }
    </style>

    <!-- Loader -->
    <div id="dashboard-loader" class="loader-overlay" style="display: none;">
        <div class="loader-content">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-3">Loading dashboard data...</p>
        </div>
    </div>

    <div class="row g-3" id="dashboard-container">
        <div class="col-lg-12 d-flex justify-content-between align-items-between">
            <div class="d-flex gap-1 align-items-center gap-3">
                @if (Auth::user()->staff->role_id == 1)
                    <h1 class="fw-semibold text-secondary">Chief Executive Officer Dashboard</h1>
                @else
                    <h1 class="fw-semibold text-secondary">Business Head Dashboard</h1>
                @endif
                <h1 class="date_view_class text-info"><?php echo date('M-Y'); ?></h1>
            </div>
            <div class=" " style="width:200px;">
                <div class="date-filter-container">
                    <div class="cursor-pointer input-group input-group-merge">
                        <span class="input-group-text bg-label-warning text-black"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="ovr_year_fill"
                            class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class w-100px"
                            value="<?php echo date('M-Y'); ?>" readonly onchange="loadDashboardData(this.value)">
                        
                    </div>
                </div>
            </div>
        </div>

        {{-- New Ui Start --}}
        <div class="col-lg-4 fade-in-onload">
            <div class="card rounded shadow w-100 gradient-card gradient-info">
                <div class="card-body p-3 position-relative overflow-hidden">
                    <div class="position-absolute" style="top: 5px; right: 0px; pointer-events: none;">
                        <img src="{{ asset('assets/phdizone_images/bg/revenue.png') }}" alt="Image"
                            class="dashboard-bg-icon" />
                    </div>
                    <div class="d-flex align-items-center justify-content-start gap-2 mb-2">
                        <span class="badge bg-label-info rounded">
                            <i class="mdi mdi-currency-usd text-info"></i>
                        </span>
                        <span class="text-dark fs-5 fw-semibold">
                            Revenue Goal
                        </span>
                    </div>
                    <div class="d-flex align-items-end justify-content-start gap-2 mb-2">
                        <span class="fs-2 text-black fw-medium" id="business-actual">₹ 0</span>
                        <span class="fs-6">/</span>
                        <span class="fs-6 text-danger fw-semibold" id="business-target">₹ 0</span>
                    </div>
                    <div class="d-flex align-items-center justify-content-end gap-2">
                        <span class="text-black fw-bold fs-5"><span id="business-percentage">0</span> achieved</span>
                    </div>
                    <div>
                        <div class="progress rounded mb-2 border borger-gray-400"
                            style="background-color:rgb(255, 255, 255);height: 10px;" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" title="Project Progress : 0%">
                            <div class="progress-bar rounded text-white bg-info" style="width: 0%;" role="progressbar"
                                aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="col-lg-4 fade-in-onload">
            <div class="card rounded shadow w-100 gradient-card gradient-success">
                <div class="card-body p-3 position-relative overflow-hidden">
                    <div class="position-absolute" style="top: 5px; right: 10px; pointer-events: none;">
                        <img src="{{ asset('assets/phdizone_images/bg/money-bundle.png') }}" alt="Image"
                            class="dashboard-bg-icon" />
                    </div>
                    <div class="d-flex align-items-center justify-content-start gap-2 mb-2">
                        <span class="badge bg-label-success rounded">
                            <i class="mdi mdi-bullseye text-success"></i>
                        </span>
                        <span class="text-dark fs-5 fw-semibold">
                            Post Sale
                        </span>
                    </div>
                    <div class="d-flex align-items-center justify-content-start gap-2 mb-2">
                        <span class="fs-2 text-black fw-medium" id="post-sale-actual">0</span>
                        <span class="fs-6">/</span>
                        <span class="fs-6 text-danger fw-semibold" id="post-sale-target">0</span>
                    </div>
                    <div class="d-flex align-items-center justify-content-end gap-2">
                        <span class="text-black fw-bold fs-5"><span id="post-sale-percentage"></span> achieved</span>
                    </div>
                    <div>
                        <div class="progress rounded mb-2 border borger-gray-400"
                            style="background-color:rgb(255, 255, 255);height: 10px;" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" title="Project Progress : 0%">
                            <div class="progress-bar rounded text-white bg-success" style="width: 0%;" role="progressbar"
                                aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4 fade-in-onload">
            <div class="card rounded shadow w-100 gradient-card gradient-primary">
                <div class="card-body p-3 position-relative overflow-hidden">
                    <div class="position-absolute" style="top: 5px; right: 10px; pointer-events: none;">
                        <img src="{{ asset('assets/phdizone_images/bg/cashback.png') }}" alt="Image"
                            class="dashboard-bg-icon" />
                    </div>
                    <div class="d-flex align-items-center justify-content-start gap-2 mb-2">
                        <span class="badge bg-label-primary rounded">
                            <i class="mdi mdi-check-circle-outline text-primary"></i>
                        </span>
                        <span class="text-dark fs-5 fw-semibold">
                            Pre Sale
                        </span>
                    </div>
                    <div class="d-flex align-items-center justify-content-start gap-2 mb-2">
                        <span class="fs-2 text-black fw-medium" id="pre-sale-actual">0</span>
                        <span class="fs-6">/</span>
                        <span class="fs-6 text-danger fw-semibold" id="pre-sale-target">0</span>
                    </div>
                    <div class="d-flex align-items-center justify-content-end gap-2">
                        <span class="text-black fw-bold fs-5"><span id="pre-sale-percentage"></span> achieved</span>
                    </div>
                    <div>
                        <div class="progress rounded mb-2 border borger-gray-400"
                            style="background-color:rgb(255, 255, 255);height: 10px;" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" title="Project Progress : 0%">
                            <div class="progress-bar rounded text-white bg-primary" style="width: 0%;" role="progressbar"
                                aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 fade-in-onload">
            <div class="card rounded shadow w-100">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 mb-2 d-flex justify-content-between gap-5">
                            <lable class="text-black fs-5 fw-semibold">Conversion Performance (<span
                                    class="text-info"><?php echo date('M-Y'); ?></span>)</lable>
                            <span class="bg-primary badge rounded text-white fw-semibold fs-6">Pre-Sale</span>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Target</label>
                            <label class="text-black fs-2" id="conversion-target">0</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Achieved</label>
                            <label class="text-danger fs-2" id="conversion-actual">0</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Rate Target</label>
                            <label class="text-black fs-2" id="conversion-rate-target">0%</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Rate Achieved</label>
                            <label class="text-danger fs-2" id="conversion-rate-actual">0%</label>
                        </div>
                        <div class="col-lg-12">
                            <div id="pre_sale_conversion_chart"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- <div class="col-lg-6 fade-in-onload">
            <div class="card rounded shadow w-100">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 mb-2 d-flex justify-content-between gap-5">
                            <lable class="text-black fs-5 fw-semibold">Conversion Performance (<span
                                    class="text-info"><?php echo date('M-Y'); ?></span>)</lable>
                            <span class="bg-primary badge rounded text-white fw-semibold fs-6">Post-Sale</span>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Target</label>
                            <label class="text-black fs-2">150</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Achieved</label>
                            <label class="text-danger fs-2">150</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Rate Target</label>
                            <label class="text-black fs-2">75%</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Rate Achieved</label>
                            <label class="text-danger fs-2">18%</label>
                        </div>
                        <div class="col-lg-12">
                            <div id="post_sale_conversion_chart"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div> --}}

        <div class="col-lg-6 fade-in-onload">
            <div class="card rounded shadow w-100">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-5">
                            <label class="text-black fs-5 fw-semibold">Business Value Analysis (<span
                                    class="text-info"><?php echo date('M-Y'); ?></span>)</label>
                            <span class="fs-6 text-white badge bg-primary fw-semibold rounded">
                                Pre Sale
                            </span>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Avg. Business Value Target</label>
                            <label class="text-black fs-2" id="avg-business-target">₹ 0</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Avg. Business Value Achieved</label>
                            <label class="text-danger fs-2" id="avg-business-actual">₹ 0</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Value Target</label>
                            <label class="text-black fs-2" id="avg-conversion-target">₹ 0</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Value Achieved</label>
                            <label class="text-danger fs-2" id="avg-conversion-actual">₹ 0</label>
                        </div>
                        <div class="col-lg-12">
                            <div id="business_pre_sale_chart"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- <div class="col-lg-6 fade-in-onload">
            <div class="card rounded shadow w-100">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-5">
                            <label class="text-black fs-5 fw-semibold">Business Value Analysis (<span
                                    class="text-info"><?php echo date('Y'); ?></span>)</label>
                            <span class="fs-6 text-white badge bg-primary fw-semibold rounded">
                                Post Sale
                            </span>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Avg. Business Value Target</label>
                            <label class="text-black fs-2">₹ 1,50,000</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Avg. Business Value Achieved</label>
                            <label class="text-danger fs-2">₹ 34,80,000</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Value Target</label>
                            <label class="text-black fs-2">₹ 8,000</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Conversion Value Achieved</label>
                            <label class="text-danger fs-2">₹ 11,400</label>
                        </div>
                        <div class="col-lg-12">
                            <div id="business_chart"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div> --}}




        <div class="col-lg-4 fade-in-onload">
            <div class="card rounded  shadow-lg">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 mb-2">
                            <label class="text-black fs-5 fw-semibold">Lead Status</label>
                        </div>
                        <div class="col-lg-12 mb-2">
                            <div id="lead_status_chart"></div>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            {{-- id="total-leads" --}}
                            <label class="text-dark fs-7">Active</label>
                            <label class="fs-2 fw-semibold" style="color: #198754;" id="active-leads">0</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Spam</label>
                            <label class="fs-2 fw-semibold" style="color: #ffc107;" id="spam-leads">0</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Dead</label>
                            <label class="fs-2 fw-semibold" style="color: #6c757d;" id="dead-leads">0</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Converted</label>
                            <label class="fs-2 fw-semibold" style="color: #dc3545;" id="converted-customers">0</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4 fade-in-onload">
            <div class="card rounded shadow-lg">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 mb-2">
                            <label class="text-black fs-5 fw-semibold">Service Status (<span
                                    class="text-info fs-6">Overall</span>)</label>
                        </div>
                        <div class="col-lg-12 mb-2">
                            <div id="service_status_chart"></div>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            {{-- id="total-service" --}}
                            <label class="text-dark fs-7">Staff Allocated</label>
                            <label class="fs-2 fw-semibold" style="color: #36d1dc;" id="staff-allocated">0</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Milestone Pending</label>
                            <label class="fs-2 fw-semibold" style="color: #f7971e;" id="milestone-pending">0</label>
                        </div>
                        <div class="col-lg-6 d-flex flex-column">
                            <label class="text-dark fs-7">Unmapped Milestone</label>
                            <label class="fs-2 fw-semibold" style="color: #ff4e50;" id="unmapped-milestone">0</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4 fade-in-onload">
            <div class="card rounded shadow-lg gradient-card gradient-danger">
                <div class="card-body p-2">
                    <div class="row">
                        <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-5">
                            <label class="text-black fs-5 fw-semibold">Action Pending (<span
                                    class="text-info fs-6">Overall</span>)</label>
                            <span class="badge bg-label-danger fw-semibold rounded">
                                <i class="mdi mdi-alert-rhombus-outline fs-4"></i>
                            </span>
                        </div>
                        <div class="col-lg-12 mb-2">
                            <div class="card rounded shadow-md p-2">
                                <div class="d-flex align-items-center justify-content-between gap-5">
                                    <label class="text-dark fs-6">Outstanding Count</label>
                                    <label class="text-danger fs-2" id="outstanding-count">0</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-2">
                            <div class="card rounded shadow-md p-2">
                                <div class="d-flex align-items-center justify-content-between gap-5">
                                    <label class="text-dark fs-6">Low MPC Count</label>
                                    <label class="text-danger fs-2" id="low-mpc-count">0</label>
                                </div>
                            </div>
                        </div>
                        {{-- <div class="col-lg-12 mb-2">
                            <div class="card rounded shadow-md p-2">
                                <div class="d-flex align-items-center justify-content-between gap-5">
                                    <label class="text-dark fs-6">Customer Not Started</label>
                                    <label class="text-danger fs-2">15</label>
                                </div>
                            </div>
                        </div> --}}
                        <div class="col-lg-12 mb-2">
                            <div class="card rounded shadow-md p-2">
                                <div class="d-flex align-items-center justify-content-between gap-5">
                                    <label class="text-dark fs-6">Staff Attendance (<span
                                            class="text-info">{{ date('d-M-Y') }}</span>)</label>
                                    <label class="text-danger fs-2"><span id="attendance-actual">0</span> <small
                                            class="text-muted fs-5">/ <span id="attendance-target">0</span>
                                        </small></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-12 mb-2">
                            <label class="text-black fs-5 fw-medium">Pending Approvals (<span
                                    class="text-info fs-6">Overall</span>)</label>
                        </div>
                        <div class="col-lg-12 d-flex align-items-center justify-content-between gap-5 mb-2 border-bottom">
                            <label class="text-dark fs-6">Drop Waiting</label>
                            <label class="text-black fs-2" id="drop-waiting">0</label>
                        </div>
                        <div class="col-lg-12 d-flex align-items-center justify-content-between gap-5 mb-2 border-bottom">
                            <label class="text-dark fs-6">Refund Waiting</label>
                            <label class="text-black fs-2" id="refund-waiting">0</label>
                        </div>
                        <div class="col-lg-12 d-flex align-items-center justify-content-between gap-5 mb-2 border-bottom">
                            <label class="text-dark fs-6">Payment Verify</label>
                            <label class="text-black fs-2" id="payment_verification">0</label>
                        </div>
                        <div class="col-lg-12 d-flex align-items-center justify-content-between gap-5">
                            <label class="text-dark fs-6">Login Approval</label>
                            <label class="text-black fs-2" id="login-approval">0</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-12 fade-in-onload">
            <div class="card rounded shadow w-100" style="overflow: hidden;">
                <div class="card-body  position-relative p-5">
                    <div class="row g-3">
                        <div class="col-lg-8">
                            <label class="text-black fw-medium fs-5  shadow-lg bg-none"
                                style="box-shadow:none !important;">Journal Status</label>
                            <label class="fs-5 text-info fw-semibold ">
                                (<span class="text-info fs-6">Overall</span>)
                            </label>
                            <div class="row g-2">
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="with-editor">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">With Editor</label>
                                            </div>
                                            <span class="badge rounded p-2" style="color: #fff;background-color: #A8AB14;"
                                                id="with-editor-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="under-review">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Under Review</label>
                                            </div>
                                            <span class="badge rounded p-2" style="color: #fff;background-color: #ED9900;"
                                                id="under-review-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="rejected">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Rejected</label>
                                            </div>
                                            <span class="badge rounded p-2" style="color: #fff;background-color: #FF4D49;"
                                                id="rejected-per">
                                                4.5%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="revision">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Revision</label>
                                            </div>
                                            <span class="badge rounded p-2" style="color: #fff;background-color: #00AD6D;"
                                                id="revision-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="eproofing">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Eproofing</label>
                                            </div>
                                            <span class="badge rounded p-2" style="color: #fff;background-color: #940097;"
                                                id="eproofing-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="accepted">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Accepted</label>
                                            </div>
                                            <span class="badge rounded p-2" style="color: #fff;background-color: #007BFF;"
                                                id="accepted-per">
                                                6.7%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="submitted">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Submitted</label>
                                            </div>
                                            <span class="badge rounded p-2" style="color: #fff;background-color: #2196f3;"
                                                id="submitted-per">
                                                8.6%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="published">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Published</label>
                                            </div>
                                            <span class="badge rounded p-2" style="color: #fff;background-color: #7239EA;"
                                                id="published-per">
                                                14.9%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div id="journal_status_chart"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-12 fade-in-onload">
            <div class="card rounded shadow w-100" style="overflow: hidden;">
                <div class="card-body  position-relative p-5">
                    <div class="row g-3">
                        <div class="col-lg-8">
                            <label class="text-black fw-medium fs-5  shadow-lg bg-none"
                                style="box-shadow:none !important;">Revision Status</label>
                            <label class="fs-5 text-info fw-semibold ">
                                (<span class="text-info fs-6">Overall</span>)
                            </label>
                            <div class="row g-2">
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="jtl-verification">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">JTL Verification</label>
                                            </div>
                                            <span class="badge rounded p-2"
                                                style="background-color: #f4eeff;color: #6610f2;"
                                                id="jtl-verification-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2"
                                                    id="revision-staff-assigned">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Staff Assigned</label>
                                            </div>
                                            <span class="badge rounded p-2"
                                                style="background-color: #effcff;color: #0dcaf0;"
                                                id="revision-staff-assigned-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2"
                                                    id="revision-inprogress">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">In progress</label>
                                            </div>
                                            <span class="badge rounded p-2"
                                                style="background-color: #ecfff6;color: #198754;"
                                                id="revision-inprogress-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2"
                                                    id="revision-completed">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Completed</label>
                                            </div>
                                            <span class="badge rounded p-2"
                                                style="background-color: #e8fdf7;color: #20c997;"
                                                id="revision-completed-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2"
                                                    id="waiting-documentation">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Waiting For
                                                    Documentation</label>
                                            </div>
                                            <span class="badge rounded p-2"
                                                style="background-color: #fffbf1;color: #ffc107;"
                                                id="waiting-documentation-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="pc-not-assign">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">PC Not Assign</label>
                                            </div>
                                            <span class="badge rounded p-2"
                                                style="background-color: #fff7f1;color: #fd7e14;" id="pc-not-assign-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="revision-rework">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Rework</label>
                                            </div>
                                            <span class="badge rounded p-2"
                                                style="background-color: #fff1f2;color: #dc3545;"
                                                id="revision-rework-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2" id="staff-not-assign">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">Staff Not Assign</label>
                                            </div>
                                            <span class="badge rounded p-2"
                                                style="background-color: #ecf6ff;color: #6c757d;"
                                                id="staff-not-assign-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2"
                                                    id="pc-pending-verification">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">PC Pending
                                                    Verification</label>
                                            </div>
                                            <span class="badge rounded p-2"
                                                style="background-color: #e6f0ff;color: #0d6efd;"
                                                id="pc-pending-verification-per">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card rounded bg-gray-100 p-2" style="box-shadow: none;">
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold fs-2"
                                                    id="jtl-pending-verification">0</label>
                                                <label class="text-secondary fw-semibold fs-7 ">JTL Pending
                                                    Verification</label>
                                            </div>
                                            <span class="badge rounded p-2"
                                                style="background-color: #ffe8f4;color: #d63384;"
                                                id="jtl-pending-verification">
                                                0%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div id="revision_status_chart"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {{-- New Ui end --}}



        <!-- Sales Goal Set Status -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Sales Goal Set Status</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold date_view_class">{{ date('M-Y') }}</label>
            </div>
        </div>

        <div class="col-lg-12 fade-in-onload">
            <div class="table-wrapper position-relative">
                <div class="table-container">
                    <!-- Sales Table Skeleton -->
                    <div id="sales-skeleton" class="table-skeleton-wrapper" style="display: none;">
                        <table class="skeleton-table sticky_table" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th class="col-staff" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                                    </th>
                                    <th class="col-work" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 100px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 60px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 100px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 100px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 100px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="col-action" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @for ($i = 0; $i < 3; $i++)
                                    <tr>
                                        <td class="col-staff">
                                            <div class="d-flex align-items-center">
                                                <div class="skeleton skeleton-avatar me-2"></div>
                                                <div style="width: 100%;">
                                                    <div class="skeleton skeleton-text w-75"></div>
                                                    <div class="skeleton skeleton-text w-50"></div>
                                                    <div class="skeleton skeleton-text-sm w-50"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="col-work">
                                            <div class="skeleton skeleton-text w-80"></div>
                                            <div class="skeleton skeleton-text-sm w-60"></div>
                                        </td>
                                        <td class="day-col">
                                            <div class="skeleton-cell">
                                                <div class="skeleton skeleton-badge"></div>
                                                <div class="skeleton skeleton-badge"></div>
                                            </div>
                                        </td>
                                        <td class="day-col">
                                            <div class="skeleton-cell">
                                                <div class="skeleton skeleton-badge"></div>
                                                <div class="skeleton skeleton-badge"></div>
                                            </div>
                                        </td>
                                        <td class="day-col">
                                            <div class="skeleton-cell">
                                                <div class="skeleton skeleton-badge"></div>
                                                <div class="skeleton skeleton-badge"></div>
                                            </div>
                                        </td>
                                        <td class="day-col">
                                            <div class="skeleton-cell">
                                                <div class="skeleton skeleton-badge"></div>
                                                <div class="skeleton skeleton-badge"></div>
                                            </div>
                                        </td>
                                        <td class="day-col">
                                            <div class="skeleton-cell">
                                                <div class="skeleton skeleton-badge"></div>
                                                <div class="skeleton skeleton-badge"></div>
                                            </div>
                                        </td>
                                        <td class="day-col">
                                            <div class="skeleton-cell">
                                                <div class="skeleton skeleton-badge"></div>
                                                <div class="skeleton skeleton-badge"></div>
                                            </div>
                                        </td>
                                        <td class="day-col">
                                            <div class="skeleton-cell">
                                                <div class="skeleton skeleton-badge"></div>
                                                <div class="skeleton skeleton-badge"></div>
                                            </div>
                                        </td>
                                        <td class="col-action">
                                            <div class="skeleton skeleton-status"></div>
                                        </td>
                                    </tr>
                                @endfor
                            </tbody>
                        </table>
                    </div>

                    <table
                        class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 min-w-max sales_table"
                        style="display: none;">
                        <thead>
                            <tr>
                                <th class="col-staff">Staff</th>
                                <th class="col-work">Stage</th>
                                <th class="day-col min-w-200px">Conversion</th>
                                <th class="day-col min-w-200px text-center">CR</th>
                                <th class="day-col min-w-400px text-center">ABV</th>
                                <th class="day-col min-w-400px text-center">ACV</th>
                                <th class="day-col min-w-200px text-center">Avg Call Out</th>
                                <th class="day-col min-w-200px text-center">Avg Walk-Ins</th>
                                <th class="day-col min-w-200px text-center">Avg Followup</th>
                                <th class="col-action">Status</th>
                            </tr>
                        </thead>
                        <!-- Dynamic content will be loaded via JavaScript -->
                    </table>
                    <div id="sales_goal_msg"></div>
                </div>
            </div>
        </div>



        <!-- Production Goal Set Status -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Production Goal Set Status</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold date_view_class">{{ date('M-Y') }}</label>
            </div>
        </div>

        <div class="col-lg-12 fade-in-onload">
            <div class="table-wrapper position-relative">
                <div class="table-container">
                    <!-- Production Table Skeleton -->
                    <div id="production-skeleton" class="table-skeleton-wrapper" style="display: none;">
                        <table class="skeleton-table sticky_table" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th class="col-staff" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                                    </th>
                                    <th class="col-work" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 120px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="col-action" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @for ($i = 0; $i < 3; $i++)
                                    <tr>
                                        <td class="col-staff">
                                            <div class="d-flex align-items-center">
                                                <div class="skeleton skeleton-avatar me-2"></div>
                                                <div style="width: 100%;">
                                                    <div class="skeleton skeleton-text w-75"></div>
                                                    <div class="skeleton skeleton-text w-50"></div>
                                                    <div class="skeleton skeleton-text-sm w-50"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="col-work">
                                            <div class="skeleton skeleton-text w-80"></div>
                                            <div class="skeleton skeleton-text-sm w-60"></div>
                                        </td>
                                        <td class="day-col">
                                            <div class="skeleton-cell">
                                                <div class="skeleton skeleton-badge"></div>
                                                <div class="skeleton skeleton-badge"></div>
                                            </div>
                                        </td>
                                        <td class="day-col">
                                            <div class="skeleton-cell">
                                                <div class="skeleton skeleton-badge"></div>
                                                <div class="skeleton skeleton-badge"></div>
                                            </div>
                                        </td>
                                        <td class="col-action">
                                            <div class="skeleton skeleton-status"></div>
                                        </td>
                                    </tr>
                                @endfor
                            </tbody>
                        </table>
                    </div>

                    <table
                        class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 min-w-max">
                        <thead>
                            <tr>
                                <th class="col-staff">Staff</th>
                                <th class="col-work">Stage</th>
                                <th class="day-col">Working Hours</th>
                                <th class="day-col">Rework</th>
                                <th class="col-action">Action</th>
                            </tr>
                        </thead>
                        <tbody id="production-goal-table-body">
                            <!-- Dynamic content will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Journal Goal Set Status -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Journal Goal Set Status</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold date_view_class">{{ date('M-Y') }}</label>
            </div>
        </div>

        <div class="col-lg-12 fade-in-onload">
            <div class="table-wrapper position-relative">
                <div class="table-container">
                    <!-- Journal Table Skeleton -->
                    <div id="journal-skeleton" class="table-skeleton-wrapper" style="display: none;">
                        <table class="skeleton-table sticky_table" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th class="col-staff-journal" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                                    </th>
                                    <th class="col-work-journal" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 120px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="col-action" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell"
                                            style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @for ($i = 0; $i < 3; $i++)
                                    <tr>
                                        <td class="col-staff-journal">
                                            <div class="d-flex align-items-center">
                                                <div class="skeleton skeleton-avatar me-2"></div>
                                                <div style="width: 100%;">
                                                    <div class="skeleton skeleton-text w-75"></div>
                                                    <div class="skeleton skeleton-text w-50"></div>
                                                    <div class="skeleton skeleton-text-sm w-50"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="col-work-journal">
                                            <div class="skeleton skeleton-text w-80"></div>
                                            <div class="skeleton skeleton-text-sm w-60"></div>
                                        </td>
                                        <td class="day-col">
                                            <div class="skeleton-cell">
                                                <div class="skeleton skeleton-badge"></div>
                                                <div class="skeleton skeleton-badge"></div>
                                            </div>
                                        </td>
                                        <td class="col-action">
                                            <div class="skeleton skeleton-status"></div>
                                        </td>
                                    </tr>
                                @endfor
                            </tbody>
                        </table>
                    </div>

                    <table
                        class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 min-w-max">
                        <thead>
                            <tr>
                                <th class="col-staff-journal">Staff</th>
                                <th class="col-work-journal">Stage</th>
                                <th class="day-col">No Of Papers</th>
                                <th class="col-action">Action</th>
                            </tr>
                        </thead>
                        <tbody id="journal-goal-table-body">
                            <!-- Dynamic content will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Skeleton Templates -->
    <script type="text/template" id="sales-skeleton-template">
        <div class="table-skeleton-wrapper">
            <table class="skeleton-table sticky_table" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="col-staff" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                        </th>
                        <th class="col-work" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                        </th>
                        @for($i = 0; $i < 8; $i++)
                        <th class="day-col" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 100px; height: 20px; margin: 0 auto;"></div>
                        </th>
                        @endfor
                        <th class="col-action" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @for($i = 0; $i < 5; $i++)
                    <tr>
                        <td class="col-staff">
                            <div class="d-flex align-items-center">
                                <div class="skeleton skeleton-avatar me-2"></div>
                                <div style="width: 100%;">
                                    <div class="skeleton skeleton-text w-75"></div>
                                    <div class="skeleton skeleton-text w-50"></div>
                                    <div class="skeleton skeleton-text-sm w-50"></div>
                                </div>
                            </div>
                        </td>
                        <td class="col-work">
                            <div class="skeleton skeleton-text w-80"></div>
                            <div class="skeleton skeleton-text-sm w-60"></div>
                        </td>
                        @for($j = 0; $j < 8; $j++)
                        <td class="day-col">
                            <div class="skeleton-cell">
                                <div class="skeleton skeleton-badge"></div>
                                <div class="skeleton skeleton-badge"></div>
                            </div>
                        </td>
                        @endfor
                        <td class="col-action">
                            <div class="skeleton skeleton-status"></div>
                        </td>
                    </tr>
                    @endfor
                </tbody>
            </table>
        </div>
    </script>

    <script type="text/template" id="production-skeleton-template">
        <div class="table-skeleton-wrapper">
            <table class="skeleton-table sticky_table" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="col-staff" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                        </th>
                        <th class="col-work" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                        </th>
                        <th class="day-col" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 120px; height: 20px; margin: 0 auto;"></div>
                        </th>
                        <th class="day-col" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                        </th>
                        <th class="col-action" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @for($i = 0; $i < 5; $i++)
                    <tr>
                        <td class="col-staff">
                            <div class="d-flex align-items-center">
                                <div class="skeleton skeleton-avatar me-2"></div>
                                <div style="width: 100%;">
                                    <div class="skeleton skeleton-text w-75"></div>
                                    <div class="skeleton skeleton-text w-50"></div>
                                    <div class="skeleton skeleton-text-sm w-50"></div>
                                </div>
                            </div>
                        </td>
                        <td class="col-work">
                            <div class="skeleton skeleton-text w-80"></div>
                            <div class="skeleton skeleton-text-sm w-60"></div>
                        </td>
                        <td class="day-col">
                            <div class="skeleton-cell">
                                <div class="skeleton skeleton-badge"></div>
                                <div class="skeleton skeleton-badge"></div>
                            </div>
                        </td>
                        <td class="day-col">
                            <div class="skeleton-cell">
                                <div class="skeleton skeleton-badge"></div>
                                <div class="skeleton skeleton-badge"></div>
                            </div>
                        </td>
                        <td class="col-action">
                            <div class="skeleton skeleton-status"></div>
                        </td>
                    </tr>
                    @endfor
                </tbody>
            </table>
        </div>
    </script>

    <script type="text/template" id="journal-skeleton-template">
        <div class="table-skeleton-wrapper">
            <table class="skeleton-table sticky_table" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="col-staff" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                        </th>
                        <th class="col-work" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                        </th>
                        <th class="day-col" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 120px; height: 20px; margin: 0 auto;"></div>
                        </th>
                        <th class="col-action" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @for($i = 0; $i < 5; $i++)
                    <tr>
                        <td class="col-staff">
                            <div class="d-flex align-items-center">
                                <div class="skeleton skeleton-avatar me-2"></div>
                                <div style="width: 100%;">
                                    <div class="skeleton skeleton-text w-75"></div>
                                    <div class="skeleton skeleton-text w-50"></div>
                                    <div class="skeleton skeleton-text-sm w-50"></div>
                                </div>
                            </div>
                        </td>
                        <td class="col-work">
                            <div class="skeleton skeleton-text w-80"></div>
                            <div class="skeleton skeleton-text-sm w-60"></div>
                        </td>
                        <td class="day-col">
                            <div class="skeleton-cell">
                                <div class="skeleton skeleton-badge"></div>
                                <div class="skeleton skeleton-badge"></div>
                            </div>
                        </td>
                        <td class="col-action">
                            <div class="skeleton skeleton-status"></div>
                        </td>
                    </tr>
                    @endfor
                </tbody>
            </table>
        </div>
    </script>

@endsection

@section('page-script')
    <!-- Add Toastr for notifications -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    <script>
        let activeAjax = {};

        function showSkeleton(section) {
            if (section === 'sales') {
                $(".sales_table").hide();
                $("#sales-skeleton").show();
                $("#sales_goal_msg").html('');
            }
            if (section === 'production') {
                $("#production-goal-table-body").parent().hide();
                $("#production-skeleton").show();
            }
            if (section === 'journal') {
                $("#journal-goal-table-body").parent().hide();
                $("#journal-skeleton").show();
            }
            if (section === 'all') {
                $(".sales_table").hide();
                $("#production-goal-table-body").parent().hide();
                $("#journal-goal-table-body").parent().hide();
                $("#sales-skeleton").show();
                $("#production-skeleton").show();
                $("#journal-skeleton").show();
            }
        }

        function hideSkeleton(section) {
            if (section === 'sales') {
                $("#sales-skeleton").hide();
                $(".sales_table").show();
            }
            if (section === 'production') {
                $("#production-skeleton").hide();
                $("#production-goal-table-body").parent().show();
            }
            if (section === 'journal') {
                $("#journal-skeleton").hide();
                $("#journal-goal-table-body").parent().show();
            }
            if (section === 'all') {
                $("#sales-skeleton").hide();
                $("#production-skeleton").hide();
                $("#journal-skeleton").hide();
                $(".sales_table").show();
                $("#production-goal-table-body").parent().show();
                $("#journal-goal-table-body").parent().show();
            }
        }

        function runAjax(key, section, config) {
            if (activeAjax[key]) {
                activeAjax[key].abort();
            }
            showSkeleton(section);
            activeAjax[key] = $.ajax({
                ...config,
                complete: function() {
                    activeAjax[key] = null;
                    hideSkeleton(section);
                }
            });
        }

        function getRoleColor(role) {
            if (!role) return "bg-secondary text-white";
            role = role.toLowerCase();
            if (role.includes("team lead")) {
                return "bg-danger text-white";
            } else if (role.includes("head")) {
                return "bg-success text-white";
            } else {
                return "bg-info text-white";
            }
        }

        // SALES GOAL TABLE - STAFF VIEW
        function fetchsalesStaff(month, year, dept = null) {
            runAjax('staff', 'sales', {
                url: "{{ route('staff_goal') }}",
                type: "GET",
                data: {
                    month_id: month,
                    year: year,
                    department_id: dept ?? 1
                },
                success: function(response) {
                    if (!response.data || response.data.length == 0) {
                        $(".sales_table").hide();
                        $("#sales_goal_msg").html(
                            '<p class="text-muted text-center pt-5">No goals found for this Department.</p>'
                        );
                        return;
                    } else {
                        $(".sales_table").show();
                        $("#sales_goal_msg").html('');
                    }

                    if (response.status === 200 && Array.isArray(response.data) && response.data.length > 0) {
                        let tableHtml = `<thead><tr>`;
                        let goalsetHtml = '';
                        const firstStaff = response.data[0];

                        tableHtml += `<th class="col-staff">Staff</th>`;
                        tableHtml += `<th class="col-work">Stage</th>`;

                        const checkFields = [{
                                check: 'conversion_check',
                                label: 'Conversion',
                                width: 'min-w-200px'
                            },
                            {
                                check: 'cr_check',
                                label: 'CR',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'abv_check',
                                label: 'ABV',
                                width: 'min-w-400px text-center'
                            },
                            {
                                check: 'acv_check',
                                label: 'ACV',
                                width: 'min-w-400px text-center'
                            },
                            {
                                check: 'avg_call_out_check',
                                label: 'Avg Call Out',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'no_of_walk_check',
                                label: 'Avg Walk-Ins',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'no_of_followup_check',
                                label: 'Avg Followup',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'working_hours_check',
                                label: 'Working hours',
                                width: 'min-w-350px text-center'
                            },
                            {
                                check: 'rework_check',
                                label: 'Rework',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'no_of_papers_check',
                                label: 'No Of Papers',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'harvesting_percentage_check',
                                label: 'Harvesting (%)',
                                width: 'min-w-200px text-center'
                            }
                        ];

                        checkFields.forEach(field => {
                            if (firstStaff[field.check] == 1) {
                                tableHtml += `<th class="day-col ${field.width}">${field.label}</th>`;
                            }
                        });

                        tableHtml +=
                            `<th class="col-action">Status</th></tr></thead><tbody id="goal_set_container">`;

                        let achievedCount = 0;
                        let Arr_sts = [];

                        response.data.forEach(function(staff) {
                            goalsetHtml += `
                                <tr>
                                    <td class="col-staff">
                                        <div class="d-flex align-items-center">
                                            <div class="symbol symbol-35px me-2">
                                                <div class="image-input image-input-circle">
                                                    ${staff.staff_image}
                                                </div>
                                            </div>
                                            <div class="ms-2">
                                                <div class="mb-0">
                                                    <span class="fs-6 fw-bold">${staff.staff_name}</span>
                                                </div>
                                                <div class="d-block">
                                                    <label class="text-dark fs-7 d-block">${staff.department_name}</label>
                                                </div>
                                                <div class="d-block">
                                                    <label class="text-black fs-8 badge ${getRoleColor(staff.role_name)}">${staff.role_name}</label>
                                                </div>
                                                ${staff.role_name && staff.role_name.toLowerCase().includes("team lead") ? `
                                                                                                                <div class="d-flex align-items-center mt-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${staff.role_name} Target">
                                                                                                                    <span class="badge rounded-pill px-2 py-1" style="font-size: 0.65rem; background: linear-gradient(to right, #00a9ff, #ff00ea); color: white;">
                                                                                                                        ${staff.sales_lead_checks == 1 ? 'Self' : 'Team'}
                                                                                                                    </span>
                                                                                                                </div>
                                                                                                            ` : ''}
                                            </div>
                                        </div>
                                    </td>
                                    <td class="col-work">
                                        ${staff.score_td}
                                    </td>
                            `;

                            let staffAchieved = true;
                            let allOverZero = true;

                            checkFields.forEach(field => {
                                if (staff[field.check] == 1) {
                                    const fieldName = field.check.replace('_check', '');
                                    const fieldNameActual = fieldName + '_actual';
                                    const overAllValue = staff[fieldName] ?? '';
                                    const actualValue = staff[fieldNameActual] ?? '';

                                    const Over = parseFloat(overAllValue) || 0;
                                    const Act = parseFloat(actualValue) || 0;

                                    let Bgc = 'danger';
                                    let BGB = '';

                                    if (Over === 0 && Act === 0) {
                                        Bgc = 'danger';
                                    } else if (Act === 0) {
                                        Bgc = 'danger';
                                        staffAchieved = false;
                                    } else if (Over === 0) {
                                        Bgc = 'danger';
                                        BGB = 'style="background-color: #c6fdeb;"';
                                    } else if (Over === Act || Act > Over) {
                                        Bgc = 'success';
                                        BGB = 'style="background-color: #c6fdeb;"';
                                    } else if (Act < Over) {
                                        staffAchieved = false;
                                    }

                                    if (fieldName === 'rework') {
                                        BGB = '';
                                        if (Over < Act) {
                                            Bgc = 'danger';
                                            staffAchieved = false;
                                        } else {
                                            BGB = 'style="background-color: #c6fdeb;"';
                                        }
                                    }

                                    if (Over > 0) {
                                        allOverZero = false;
                                    }

                                    goalsetHtml += `
                                        <td class="day-col" ${BGB}>
                                            <div class="row g-0">
                                                <div class="col-6">
                                                    <label class="">Target</label>
                                                    <div class="d-block w-auto" conversion="">
                                                        <label class="fw-bold me-3 fs-2 badge bg-label-secondary px-2 py-2"title="${formatNumber(Over)} Target">
                                                        ${formatNumber(Over)}
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <label class="">Actual</label>
                                                    <div class="d-block w-auto" conversion_actual="">
                                                        <label class="fw-bold me-3 fs-2  badge ${Act >= Over ? 'bg-label-success' : 'bg-label-danger'} px-2 py-2"data-bs-toggle="tooltip" title="${formatNumber(Act)} Actual">
                                                        ${formatNumber(Act)}
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    `;
                                }
                            });
                            // <td class="day-col" >
                            //     <div class="row g-0">
                            //         <div class="col-6 pe-1">
                            //             <div class="d-flex flex-column">
                            //                 <small class="text-muted">Target</small>
                            //                 <span class="fw-bold badge bg-label-secondary px-2 py-2" 
                            //                     data-bs-toggle="tooltip" title="${formatNumber(Over)} Target">
                            //                     ${formatNumber(Over)}
                            //                 </span>
                            //             </div>
                            //         </div>
                            //         <div class="col-6 ps-1">
                            //             <div class="d-flex flex-column">
                            //                 <small class="text-muted">Actual</small>
                            //                 <span class="fw-bold badge bg-label-${Bgc} px-2 py-2" 
                            //                     data-bs-toggle="tooltip" title="${formatNumber(Act)} Actual">
                            //                     ${formatNumber(Act)}
                            //                 </span>
                            //             </div>
                            //         </div>
                            //     </div>
                            // </td>

                            let status = '';
                            let sts_color = '';

                            if (staff.goal_achievements == true) {
                                if (allOverZero) {
                                    status = 'Not Assigned';
                                    sts_color = 'danger';
                                } else {
                                    status = staffAchieved ? 'Goal Achieved' : 'On Progress';
                                    sts_color = staffAchieved ? 'success' : 'info';
                                    if (staffAchieved) achievedCount++;
                                }
                            } else {
                                status = staffAchieved ? '10X Achieved' : 'On Progress';
                                sts_color = staffAchieved ? 'success' : 'info';
                            }

                            if (staff.goal_completed == 1) {
                                if (!staffAchieved && staff.status_10x != 1) {
                                    status = 'Not Achieved';
                                    sts_color = 'danger';
                                } else {
                                    status = '10X Achieved';
                                    sts_color = 'success';
                                }

                                if (staff.sales_lead_checks != 1) {
                                    const role = staff.role_name.toLowerCase();
                                    if (role.includes("team lead")) {
                                        Arr_sts.push(status);
                                        if (Arr_sts.includes("On Progress") || Arr_sts.includes(
                                                "Not Achieved")) {
                                            status = 'Team Not Achieved';
                                            sts_color = 'warning text-black';
                                        }
                                    }
                                }
                            }

                            goalsetHtml += `
                                <td class="col-action">
                                    <span class="badge bg-${sts_color} fs-6 p-2 w-100">${status}</span>
                                </td>
                            </tr>`;
                        });

                        tableHtml += goalsetHtml + `</tbody>`;
                        $(".sales_table").html(tableHtml).show();
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }
                },
                error: function(error) {
                    console.error('Error fetching staff:', error);
                    $(".sales_table").hide();
                    $("#sales_goal_msg").html(
                        '<p class="text-danger text-center pt-5">Failed to load sales data. Please try again.</p>'
                    );
                }
            });
        }

        // PRODUCTION GOAL TABLE - STAFF VIEW
        function fetchProductionStaff(month, year, dept = 2) {
            runAjax('production_staff', 'production', {
                url: "{{ route('staff_goal') }}",
                type: "GET",
                data: {
                    month_id: month,
                    year: year,
                    department_id: dept
                },
                success: function(response) {
                    if (!response.data || response.data.length == 0) {
                        $("#production-goal-table-body").html(
                            '<tr><td colspan="5" class="text-center py-4"><div class="text-muted">No production goals found for this month.</div></td></tr>'
                        );
                        return;
                    }

                    let tableBodyHtml = '';

                    response.data.forEach(function(staff) {
                        let status = '';
                        let statusClass = '';
                        let staffAchieved = true;
                        let allOverZero = true;

                        const workingHoursTarget = parseFloat(staff.working_hours) || 0;
                        const workingHoursActual = parseFloat(staff.working_hours_actual) || 0;
                        const reworkTarget = parseFloat(staff.rework) || 0;
                        const reworkActual = parseFloat(staff.rework_actual) || 0;

                        if (workingHoursTarget > 0) allOverZero = false;
                        if (reworkTarget > 0) allOverZero = false;

                        if (workingHoursActual < workingHoursTarget) {
                            staffAchieved = false;
                        }
                        if (reworkActual > reworkTarget) {
                            staffAchieved = false;
                        }

                        if (staff.goal_achievements == true) {
                            if (allOverZero) {
                                status = 'Not Assigned';
                                statusClass = 'danger';
                            } else {
                                status = staffAchieved ? 'Goal Achieved' : 'On Progress';
                                statusClass = staffAchieved ? 'success' : 'info';
                            }
                        } else {
                            status = staffAchieved ? '10X Achieved' : 'On Progress';
                            statusClass = staffAchieved ? 'success' : 'info';
                        }

                        if (staff.goal_completed == 1) {
                            if (!staffAchieved && staff.status_10x != 1) {
                                status = 'Not Achieved';
                                statusClass = 'danger';
                            } else {
                                status = '10X Achieved';
                                statusClass = 'success';
                            }
                        }
                        tableBodyHtml += `
                            <tr>
                                <td class="col-staff">
                                    <div class="d-flex align-items-center">
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle">
                                                ${staff.staff_image}
                                            </div>
                                        </div>
                                        <div class="ms-2">
                                            <div class="mb-0">
                                                <span class="fs-6 fw-bold">${staff.staff_name}</span>
                                            </div>
                                            <div class="d-block">
                                                <label class="text-dark fs-7 d-block">${staff.department_name}</label>
                                            </div>
                                            <div class="d-block">
                                                <label class="text-black fs-8 badge ${getRoleColor(staff.role_name)}">${staff.role_name}</label>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="col-work">
                                    ${staff.score_td}
                                </td>
                                <td class="day-col">
                                    <div class="row g-0">
                                        <div class="col-6">
                                            <label class="">Target</label>
                                            <div class="d-block w-auto" conversion="">
                                                <label class="fw-bold me-3 fs-2 badge bg-label-secondary px-2 py-2">
                                                    ${formatNumber(workingHoursTarget)}
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <label class="">Actual</label>
                                            <div class="d-block w-auto" conversion_actual="">
                                                <label class="fw-bold me-3 fs-2  badge ${workingHoursActual >= workingHoursTarget ? 'bg-label-success' : 'bg-label-danger'} px-2 py-2">
                                                    ${formatNumber(workingHoursActual)}
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="day-col">
                                    <div class="row g-0">
                                        <div class="col-6">
                                            <label class="">Target</label>
                                            <div class="d-block w-auto" conversion="">
                                                <label class="fw-bold me-3 fs-2 badge bg-label-secondary px-2 py-2">
                                                    ${formatNumber(reworkTarget)}
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <label class="">Actual</label>
                                            <div class="d-block w-auto" conversion_actual="">
                                                <label class="fw-bold me-3 fs-2  badge ${reworkActual <= reworkTarget ? 'bg-label-success' : 'bg-label-danger'} px-2 py-2">
                                                    ${formatNumber(reworkActual)}
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="col-action">
                                    <span class="badge bg-${statusClass} fs-6 p-2 w-100">${status}</span>
                                </td>
                            </tr>
                        `;
                    });

                    $("#production-goal-table-body").html(tableBodyHtml);
                    $('[data-bs-toggle="tooltip"]').tooltip();
                },
                error: function(error) {
                    console.error('Error fetching production staff:', error);
                    $("#production-goal-table-body").html(
                        '<tr><td colspan="5" class="text-center py-4"><div class="text-danger">Failed to load production data. Please try again.</div></td></tr>'
                    );
                }
            });
        }

        // JOURNAL GOAL TABLE - STAFF VIEW
        function fetchJournalStaff(month, year, dept = 14) {
            runAjax('journal_staff', 'journal', {
                url: "{{ route('staff_goal') }}",
                type: "GET",
                data: {
                    month_id: month,
                    year: year,
                    department_id: dept
                },
                success: function(response) {
                    if (!response.data || response.data.length == 0) {
                        $("#journal-goal-table-body").html(
                            '<tr><td colspan="4" class="text-center py-4"><div class="text-muted">No journal goals found for this month.</div></td></tr>'
                        );
                        return;
                    }

                    let tableBodyHtml = '';

                    response.data.forEach(function(staff) {
                        let status = '';
                        let statusClass = '';
                        let staffAchieved = true;
                        let allOverZero = true;

                        const papersTarget = parseFloat(staff.no_of_papers) || 0;
                        const papersActual = parseFloat(staff.no_of_papers_actual) || 0;

                        if (papersTarget > 0) allOverZero = false;

                        if (papersActual < papersTarget) {
                            staffAchieved = false;
                        }

                        if (staff.goal_achievements == true) {
                            if (allOverZero) {
                                status = 'Not Assigned';
                                statusClass = 'danger';
                            } else {
                                status = staffAchieved ? 'Goal Achieved' : 'On Progress';
                                statusClass = staffAchieved ? 'success' : 'info';
                            }
                        } else {
                            status = staffAchieved ? '10X Achieved' : 'On Progress';
                            statusClass = staffAchieved ? 'success' : 'info';
                        }

                        if (staff.goal_completed == 1) {
                            if (!staffAchieved && staff.status_10x != 1) {
                                status = 'Not Achieved';
                                statusClass = 'danger';
                            } else {
                                status = '10X Achieved';
                                statusClass = 'success';
                            }
                        }

                        tableBodyHtml += `
                            <tr>
                                <td class="col-staff-journal" >
                                    <div class="d-flex align-items-center">
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle">
                                                ${staff.staff_image}
                                            </div>
                                        </div>
                                        <div class="ms-2">
                                            <div class="mb-0">
                                                <span class="fs-6 fw-bold">${staff.staff_name}</span>
                                            </div>
                                            <div class="d-block">
                                                <label class="text-dark fs-7 d-block">${staff.department_name}</label>
                                            </div>
                                            <div class="d-block">
                                                <label class="text-black fs-8 badge ${getRoleColor(staff.role_name)}">${staff.role_name}</label>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="col-work-journal">
                                    ${staff.score_td}
                                </td>
                                <td class="day-col">
                                    <div class="row g-0">
                                        <div class="col-6">
                                            <label class="">Target</label>
                                            <div class="d-block w-auto" conversion="">
                                                <label class="fw-bold me-3 fs-2 badge bg-label-secondary px-2 py-2"title="${formatNumber(papersTarget)} Target">
                                                ${papersTarget}
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <label class="">Actual</label>
                                            <div class="d-block w-auto" conversion_actual="">
                                                <label class="fw-bold me-3 fs-2  badge bg-label-info px-2 py-2"data-bs-toggle="tooltip" title="${formatNumber(papersActual)} Actual">
                                                ${papersActual}
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="col-action">
                                    <span class="badge bg-${statusClass} fs-6 p-2 w-100">${status}</span>
                                </td>
                            </tr>
                        `;
                    });


                    // <td class="day-col">
                    //     <div class="d-flex flex-row align-items-center gap-2">
                    //         <span class="badge bg-label-secondary mb-1 p-2 w-75">
                    //             <small>Target</small><br>
                    //             <strong>${papersTarget}</strong>
                    //         </span>
                    //         <span class="badge ${papersActual >= papersTarget ? 'bg-label-success' : 'bg-label-danger'} p-2 w-75">
                    //             <small>Actual</small><br>
                    //             <strong>${papersActual}</strong>
                    //         </span>
                    //     </div>
                    // </td>

                    $("#journal-goal-table-body").html(tableBodyHtml);
                    $('[data-bs-toggle="tooltip"]').tooltip();
                },
                error: function(error) {
                    console.error('Error fetching journal staff:', error);
                    $("#journal-goal-table-body").html(
                        '<tr><td colspan="4" class="text-center py-4"><div class="text-danger">Failed to load journal data. Please try again.</div></td></tr>'
                    );
                }
            });
        }

        function formatPercentageTargetActual(actual, target) {
            actual = Number(actual) || 0;
            target = Number(target) || 0;

            if (target <= 0) return '0%';

            let percentage = (actual / target) * 100;

            return Math.round(percentage) + '%';
        }
        // Single comprehensive function for dashboard data loading
        loadDashboardData($('#ovr_year_fill').val());

        function loadDashboardData(selectedDate) {
            $('#dashboard-loader').show();
            $('#dashboard-container').addClass('data-loading');

            // Show all skeletons
            showSkeleton('all');

            if (!/^[A-Za-z]{3}-\d{4}$/.test(selectedDate)) {
                console.error('Invalid date format. Expected: MMM-YYYY');
                selectedDate = new Date().toLocaleString('default', {
                    month: 'short'
                }) + '-' + new Date().getFullYear();
            }

            $('.date_view_class').html(selectedDate);

            $.ajax({
                url: "{{ route('ceo.dashboard.data') }}",
                method: "GET",
                data: {
                    date_filter: selectedDate,
                    _token: "{{ csrf_token() }}"
                },
                dataType: "json",
                success: function(response) {
                    if (response.success && response.data) {
                        const data = response.data;

                        // BUSINESS GOAL SET
                        if (data.business_goal) {
                            // Calculate percentages
                            const businessPercentage = formatPercentageTargetActual(data.business_goal.actual,
                                data.business_goal.target);
                            const postSalePercentage = formatPercentageTargetActual(data.business_goal
                                .post_sale_actual, data.business_goal.post_sale_target);
                            const preSalePercentage = formatPercentageTargetActual(data.business_goal
                                .pre_sale_actual, data.business_goal.pre_sale_target);

                            // Update text values
                            $('#business-target').text(formatCurrency(data.business_goal.target || 0));
                            $('#business-actual').text(formatCurrency(data.business_goal.actual || 0));
                            $('#business-percentage').text(businessPercentage);

                            $('#post-sale-target').text(data.business_goal.post_sale_target || 0);
                            $('#post-sale-actual').text(data.business_goal.post_sale_actual || 0);
                            $('#post-sale-percentage').text(postSalePercentage);

                            $('#pre-sale-target').text(data.business_goal.pre_sale_target || 0);
                            $('#pre-sale-actual').text(data.business_goal.pre_sale_actual || 0);
                            $('#pre-sale-percentage').text(preSalePercentage);

                            // Update progress bars
                            // Revenue Goal progress bar (info)
                            $('.gradient-card.gradient-info .progress-bar').css('width', businessPercentage);
                            $('.gradient-card.gradient-info .progress-bar').attr('aria-valuenow',
                                businessPercentage);
                            $('.gradient-card.gradient-info .progress').attr('title',
                                `Project Progress: ${businessPercentage}`);

                            // Post Sale progress bar (success)
                            $('.gradient-card.gradient-success .progress-bar').css('width', postSalePercentage);
                            $('.gradient-card.gradient-success .progress-bar').attr('aria-valuenow',
                                postSalePercentage);
                            $('.gradient-card.gradient-success .progress').attr('title',
                                `Project Progress: ${postSalePercentage}`);

                            // Pre Sale progress bar (primary)
                            $('.gradient-card.gradient-primary .progress-bar').css('width', preSalePercentage);
                            $('.gradient-card.gradient-primary .progress-bar').attr('aria-valuenow',
                                preSalePercentage);
                            $('.gradient-card.gradient-primary .progress').attr('title',
                                `Project Progress: ${preSalePercentage}`);
                        }

                        // SALES TARGETS
                        if (data.sales_targets) {
                            // Conversion Target
                            $('#conversion-target').text(data.sales_targets.conversion_target || 0);
                            $('#conversion-actual').text(data.sales_targets.conversion_actual || 0);

                            if (data.sales_targets.conversion_target < data.sales_targets.conversion_actual) {
                                $('#conversion-actual').removeClass('text-danger').addClass('text-success');
                            } else {
                                $('#conversion-actual').removeClass('text-success').addClass('text-danger');
                            }

                            // Conversion Rate
                            $('#conversion-rate-target').text(formatPercentage(data.sales_targets
                                .conversion_rate_target || 0));
                            $('#conversion-rate-actual').text(formatPercentage(data.sales_targets
                                .conversion_rate_actual || 0));

                            if (data.sales_targets.conversion_rate_target < data.sales_targets
                                .conversion_rate_actual) {
                                $('#conversion-rate-actual').removeClass('text-danger').addClass(
                                    'text-success');
                            } else {
                                $('#conversion-rate-actual').removeClass('text-success').addClass(
                                    'text-danger');
                            }

                            // Average Business Value
                            $('#avg-business-target').text(formatCurrency(data.sales_targets
                                .avg_business_target || 0));
                            $('#avg-business-actual').text(formatCurrency(data.sales_targets
                                .avg_business_actual || 0));

                            if (data.sales_targets.avg_business_target < data.sales_targets
                                .avg_business_actual) {
                                $('#avg-business-actual').removeClass('text-danger').addClass('text-success');
                            } else {
                                $('#avg-business-actual').removeClass('text-success').addClass('text-danger');
                            }


                            // Use dynamic monthly data from API - Show ALL 12 months
                            const monthlyData = data.sales_targets.monthly_data || {};
                            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep',
                                'Oct', 'Nov', 'Dec'
                            ];

                            // Get all 12 months of data from backend (backend should return all months with zeros for future months)
                            let targetPreConversions = monthlyData.conversion_target || Array(12).fill(0);
                            let achievedPreConversions = monthlyData.conversion_actual || Array(12).fill(0);
                            let targetPreRate = monthlyData.conversion_rate_target || Array(12).fill(0);
                            let achievedPreRate = monthlyData.conversion_rate_actual || Array(12).fill(0);

                            const currentMonthIndex = new Date().getMonth();

                            var options = {
                                series: [{
                                    name: 'Target Conversions',
                                    type: 'column',
                                    data: targetPreConversions
                                }, {
                                    name: 'Achieved Conversions',
                                    type: 'column',
                                    data: achievedPreConversions
                                }, {
                                    name: 'Target Rate (%)',
                                    type: 'line',
                                    data: targetPreRate
                                }, {
                                    name: 'Achieved Rate (%)',
                                    type: 'line',
                                    data: achievedPreRate
                                }],
                                chart: {
                                    type: 'line',
                                    height: 350,
                                    toolbar: {
                                        show: true,
                                        tools: {
                                            download: true,
                                            selection: false,
                                            zoom: false,
                                            zoomin: false,
                                            zoomout: false,
                                            pan: false,
                                            reset: false
                                        }
                                    },
                                    zoom: {
                                        enabled: false
                                    }
                                },
                                plotOptions: {
                                    bar: {
                                        horizontal: false,
                                        columnWidth: '55%',
                                        borderRadius: 3
                                    }
                                },
                                dataLabels: {
                                    enabled: false
                                },
                                stroke: {
                                    width: [0, 0, 2, 2],
                                    curve: 'smooth'
                                },
                                xaxis: {
                                    categories: months, // All 12 months
                                    labels: {
                                        style: {
                                            colors: months.map((_, index) =>
                                                index <= currentMonthIndex ? '#333' : '#999'
                                            ),
                                            fontWeight: months.map((_, index) =>
                                                index <= currentMonthIndex ? 'bold' : 'normal'
                                            )
                                        },
                                        rotate: -45,
                                        rotateAlways: false
                                    },
                                    title: {
                                        text: 'Months (Jan - Dec)',
                                        style: {
                                            fontSize: '12px',
                                            fontWeight: 'bold'
                                        }
                                    }
                                },
                                colors: ['#9333EA', '#16A34A', '#EAB308', '#DC2626'],
                                yaxis: [{
                                    title: {
                                        text: 'Conversions Count',
                                        style: {
                                            fontSize: '12px'
                                        }
                                    },
                                    labels: {
                                        formatter: function(val) {
                                            return Math.round(val);
                                        }
                                    }
                                }, {
                                    opposite: true,
                                    title: {
                                        text: 'Conversion Rate (%)',
                                        style: {
                                            fontSize: '12px'
                                        }
                                    },
                                    labels: {
                                        formatter: function(val) {
                                            return val.toFixed(2) + "%";
                                        }
                                    }
                                }],
                                tooltip: {
                                    shared: true,
                                    intersect: false,
                                    y: {
                                        formatter: function(val, {
                                            seriesIndex,
                                            dataPointIndex
                                        }) {
                                            if (seriesIndex >= 2) {
                                                return val.toFixed(2) + "%";
                                            }
                                            return Math.round(val);
                                        }
                                    },
                                    x: {
                                        formatter: function(val, {
                                            dataPointIndex
                                        }) {
                                            const isFutureMonth = dataPointIndex > currentMonthIndex;
                                            return months[dataPointIndex] + (isFutureMonth ?
                                                ' (Future)' : '');
                                        }
                                    }
                                },
                                legend: {
                                    position: 'top',
                                    horizontalAlign: 'center',
                                    fontSize: '12px',
                                    fontWeight: 'bold'
                                },
                                grid: {
                                    borderColor: '#e7e7e7',
                                    row: {
                                        colors: ['#f3f3f3', 'transparent'],
                                        opacity: 0.5
                                    }
                                },
                                annotations: {
                                    xaxis: [{
                                        x: months[currentMonthIndex],
                                        borderColor: '#FF4560',
                                        label: {
                                            style: {
                                                color: '#fff',
                                                background: '#FF4560'
                                            },
                                            text: 'Current Month'
                                        }
                                    }]
                                }
                            };

                            var chart = new ApexCharts(document.querySelector("#pre_sale_conversion_chart"),
                                options);
                            chart.render();


                            // Average Conversion Value
                            $('#avg-conversion-target').text(formatCurrency(data.sales_targets
                                .avg_conversion_target || 0));
                            $('#avg-conversion-actual').text(formatCurrency(data.sales_targets
                                .avg_conversion_actual || 0));

                            if (data.sales_targets.avg_conversion_target < data.sales_targets
                                .avg_conversion_actual) {
                                $('#avg-conversion-actual').removeClass('text-danger').addClass('text-success');
                            } else {
                                $('#avg-conversion-actual').removeClass('text-success').addClass('text-danger');
                            }

                            // ============================================
                            // GRAPH 2: Business Value Analysis Chart (business_pre_sale_chart)
                            // ============================================

                            // Get business value monthly data
                            let avgBusinessTarget = monthlyData.avg_business_target || Array(12).fill(0);
                            let avgBusinessActual = monthlyData.avg_business_actual || Array(12).fill(0);
                            let avgConversionTarget = monthlyData.avg_conversion_target || Array(12).fill(0);
                            let avgConversionActual = monthlyData.avg_conversion_actual || Array(12).fill(0);

                            var businessChartOptions = {
                                series: [{
                                    name: 'Avg Business Value Target',
                                    type: 'column',
                                    data: avgBusinessTarget
                                }, {
                                    name: 'Avg Business Value Achieved',
                                    type: 'column',
                                    data: avgBusinessActual
                                }, {
                                    name: 'Avg Conversion Value Target',
                                    type: 'line',
                                    data: avgConversionTarget
                                }, {
                                    name: 'Avg Conversion Value Achieved',
                                    type: 'line',
                                    data: avgConversionActual
                                }],
                                chart: {
                                    type: 'line',
                                    height: 350,
                                    toolbar: {
                                        show: true,
                                        tools: {
                                            download: true,
                                            selection: false,
                                            zoom: false,
                                            zoomin: false,
                                            zoomout: false,
                                            pan: false,
                                            reset: false
                                        }
                                    },
                                    zoom: {
                                        enabled: false
                                    }
                                },
                                plotOptions: {
                                    bar: {
                                        horizontal: false,
                                        columnWidth: '55%',
                                        borderRadius: 3
                                    }
                                },
                                dataLabels: {
                                    enabled: false
                                },
                                stroke: {
                                    width: [0, 0, 2, 2],
                                    curve: 'smooth'
                                },
                                xaxis: {
                                    categories: months,
                                    labels: {
                                        style: {
                                            colors: months.map((_, index) => index <= currentMonthIndex ?
                                                '#333' : '#999'),
                                            fontWeight: months.map((_, index) => index <=
                                                currentMonthIndex ? 'bold' : 'normal')
                                        },
                                        rotate: -45,
                                        rotateAlways: false
                                    },
                                    title: {
                                        text: 'Months (Jan - Dec)',
                                        style: {
                                            fontSize: '12px',
                                            fontWeight: 'bold'
                                        }
                                    }
                                },
                                colors: [
                                    '#36d1dc', // Avg Target (cyan)
                                    '#1e90ff', // Avg Achieved (blue)
                                    '#f7971e', // Conv Target (orange)
                                    '#ff4e50' // Conv Achieved (red)
                                ],
                                yaxis: [{
                                    title: {
                                        text: 'Business Value (₹)',
                                        style: {
                                            fontSize: '12px'
                                        }
                                    },
                                    labels: {
                                        formatter: function(val) {
                                            return '₹ ' + val.toLocaleString('en-IN');
                                        }
                                    }
                                }, {
                                    opposite: true,
                                    title: {
                                        text: 'Conversion Value (₹)',
                                        style: {
                                            fontSize: '12px'
                                        }
                                    },
                                    labels: {
                                        formatter: function(val) {
                                            return '₹ ' + val.toLocaleString('en-IN');
                                        }
                                    }
                                }],
                                tooltip: {
                                    shared: true,
                                    intersect: false,
                                    y: {
                                        formatter: function(val, {
                                            seriesIndex
                                        }) {
                                            return '₹ ' + val.toLocaleString('en-IN', {
                                                minimumFractionDigits: 2,
                                                maximumFractionDigits: 2
                                            });
                                        }
                                    },
                                    x: {
                                        formatter: function(val, {
                                            dataPointIndex
                                        }) {
                                            const isFutureMonth = dataPointIndex > currentMonthIndex;
                                            return months[dataPointIndex] + (isFutureMonth ?
                                                ' (Future)' : '');
                                        }
                                    }
                                },
                                legend: {
                                    position: 'top',
                                    horizontalAlign: 'center',
                                    fontSize: '12px',
                                    fontWeight: 'bold'
                                },
                                grid: {
                                    borderColor: '#e7e7e7',
                                    row: {
                                        colors: ['#f3f3f3', 'transparent'],
                                        opacity: 0.5
                                    }
                                },
                                annotations: {
                                    xaxis: [{
                                        x: months[currentMonthIndex],
                                        borderColor: '#FF4560',
                                        label: {
                                            style: {
                                                color: '#fff',
                                                background: '#FF4560'
                                            },
                                            text: 'Current Month'
                                        }
                                    }]
                                }
                            };

                            var businessChart = new ApexCharts(document.querySelector(
                                "#business_pre_sale_chart"), businessChartOptions);
                            businessChart.render();

                        }

                        // ALERT SYSTEM
                        if (data.alerts) {
                            $('#attendance-target').text(data.alerts.attendance_target || 0);
                            $('#attendance-actual').text(data.alerts.attendance_actual || 0);
                            $('#outstanding-count').text(data.alerts.outstanding_count || 0);
                            $('#low-mpc-count').text(data.alerts.low_mpc_count || 0);
                            $('#payment_verification').text(data.alerts.customer_not_started || 0);
                        }

                        // APPROVAL PENDING
                        if (data.approval_pending) {
                            $('#drop-waiting').text(data.approval_pending.drop_waiting || 0);
                            $('#refund-waiting').text(data.approval_pending.refund_waiting || 0);
                            $('#accounts-confirmation').text(data.approval_pending.accounts_confirmation || 0);
                            $('#login-approval').text(data.approval_pending.login_approval || 0);
                        }

                        // LEAD STATUS
                        if (data.lead_status) {
                            // $('#total-leads').text();
                            $('#active-leads').text(data.lead_status.active || 0);
                            $('#spam-leads').text(data.lead_status.spam || 0);
                            $('#dead-leads').text(data.lead_status.dead || 0);
                            $('#converted-customers').text(data.lead_status.converted || 0);
                            var total_leads = (data.lead_status.active ?? 0) +
                                (data.lead_status.spam ?? 0) +
                                (data.lead_status.dead ?? 0) +
                                (data.lead_status.converted ?? 0);
                            var options = {
                                series: [data.lead_status.active || 0, data.lead_status.spam || 0, data
                                    .lead_status.dead || 0, data.lead_status.converted || 0
                                ], // Active, Spam, Dead, Converted
                                chart: {
                                    type: 'donut',
                                    height: 300
                                },
                                labels: ['Active Lead', 'Spam Lead', 'Dead Lead', 'Converted'],

                                colors: ['#36d1dc', '#ffc107', '#6c757d',
                                    '#198754'
                                ], // success, warning, secondary, danger

                                legend: {
                                    position: 'bottom',
                                },
                                dataLabels: {
                                    enabled: false
                                },

                                plotOptions: {
                                    pie: {
                                        donut: {
                                            size: '65%',
                                            labels: {
                                                show: true,
                                                name: {
                                                    show: true,
                                                    fontSize: '14px'
                                                },
                                                value: {
                                                    show: true,
                                                    fontSize: '18px',
                                                    fontWeight: 600
                                                },
                                                total: {
                                                    show: true,
                                                    label: 'Total Lead',
                                                    fontSize: '14px',
                                                    formatter: function(w) {
                                                        return total_leads;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                },

                                tooltip: {
                                    y: {
                                        formatter: function(val) {
                                            return val + " Leads";
                                        }
                                    }
                                }
                            };

                            var chart = new ApexCharts(document.querySelector("#lead_status_chart"), options);
                            chart.render();
                        }

                        // SERVICE STATUS
                        if (data.service_status) {
                            // $('#total-service').text(data.service_status.total || 0);
                            $('#staff-allocated').text(data.service_status.staff_allocated || 0);
                            $('#milestone-pending').text(data.service_status.milestone_pending || 0);
                            $('#unmapped-milestone').text(data.service_status.milestone_pending || 0);
                            var total_services = (data.service_status.staff_allocated ?? 0) +
                                (data.service_status.milestone_pending ?? 0) +
                                (data.service_status.milestone_pending ?? 0);
                            var options = {
                                series: [data.service_status.staff_allocated || 0, data.service_status
                                    .milestone_pending || 0, data.service_status.milestone_pending || 0
                                ], // Staff Allocated, Milestone Pending, Unmapped
                                chart: {
                                    type: 'donut',
                                    height: 300
                                },
                                labels: ['Staff Allocated', 'Milestone Pending', 'Unmapped Milestone'],

                                colors: ['#36d1dc', '#f7971e', '#ff4e50'],

                                legend: {
                                    position: 'bottom'
                                },

                                dataLabels: {
                                    enabled: false
                                },

                                plotOptions: {
                                    pie: {
                                        donut: {
                                            size: '65%',
                                            labels: {
                                                show: true,
                                                name: {
                                                    show: true,
                                                    fontSize: '14px'
                                                },
                                                value: {
                                                    show: true,
                                                    fontSize: '18px',
                                                    fontWeight: 600
                                                },
                                                total: {
                                                    show: true,
                                                    label: 'Total Service',
                                                    fontSize: '14px',
                                                    formatter: function(w) {
                                                        return total_services;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                },

                                tooltip: {
                                    y: {
                                        formatter: function(val) {
                                            return val + " Services";
                                        }
                                    }
                                }
                            };

                            var chart = new ApexCharts(document.querySelector("#service_status_chart"),
                                options);
                            chart.render();
                        }

                        // JOURNAL STATUS
                        if (data.journal_status) {
                            $('#with-editor').text(data.journal_status.with_editor || 0);
                            $('#under-review').text(data.journal_status.under_review || 0);
                            $('#rejected').text(data.journal_status.rejected || 0);
                            $('#revision').text(data.journal_status.revision || 0);
                            $('#eproofing').text(data.journal_status.eproofing || 0);
                            $('#accepted').text(data.journal_status.accepted || 0);
                            $('#submitted').text(data.journal_status.submitted || 0);
                            $('#published').text(data.journal_status.published || 0);




                            // Data
                            const journalData = [
                                data.journal_status.with_editor || 0,
                                data.journal_status.under_review || 0,
                                data.journal_status.revision || 0,
                                data.journal_status.accepted || 0,
                                data.journal_status.rejected || 0,
                                data.journal_status.eproofing || 0,
                                data.journal_status.submitted || 0,
                                data.journal_status.published || 0,
                            ];

                            // Calculate total
                            const totalJournal = journalData.reduce((a, b) => a + b, 0);

                            $('#with-editor-per').text(formatPercentageTargetActual(data.journal_status
                                .with_editor || 0, totalJournal));
                            $('#under-review-per').text(formatPercentageTargetActual(data.journal_status
                                .under_review || 0, totalJournal));
                            $('#rejected-per').text(formatPercentageTargetActual(data.journal_status.rejected ||
                                0, totalJournal));
                            $('#revision-per').text(formatPercentageTargetActual(data.journal_status.revision ||
                                0, totalJournal));
                            $('#eproofing-per').text(formatPercentageTargetActual(data.journal_status
                                .eproofing || 0, totalJournal));
                            $('#accepted-per').text(formatPercentageTargetActual(data.journal_status.accepted ||
                                0, totalJournal));
                            $('#submitted-per').text(formatPercentageTargetActual(data.journal_status
                                .submitted || 0, totalJournal));
                            $('#published-per').text(formatPercentageTargetActual(data.journal_status
                                .published || 0, totalJournal));

                            var options = {
                                series: journalData,

                                chart: {
                                    type: 'donut',
                                    height: 300
                                },

                                labels: [
                                    'With Editor',
                                    'Under Review',
                                    'Revision',
                                    'Accepted',
                                    'Rejected',
                                    'Eproofing',
                                    'Submitted',
                                    'Published'
                                ],

                                // 🎨 Professional color palette
                                colors: [
                                    '#A8AB14', // 'With Editor',
                                    '#ED9900', // 'Under Review',
                                    '#00AD6D', // 'Revision',
                                    '#007BFF', // 'Accepted',
                                    '#FF4D49', // 'Rejected',
                                    '#940097', // 'Eproofing',
                                    '#2196f3', // 'Submitted',
                                    '#7239EA' // 'Published'
                                ],

                                legend: {
                                    position: 'bottom'
                                },

                                dataLabels: {
                                    enabled: false
                                },

                                plotOptions: {
                                    pie: {
                                        donut: {
                                            size: '65%',
                                            labels: {
                                                show: true,

                                                name: {
                                                    show: true,
                                                    fontSize: '13px'
                                                },

                                                value: {
                                                    show: true,
                                                    fontSize: '18px',
                                                    fontWeight: 600
                                                },

                                                total: {
                                                    show: true,
                                                    label: 'Total Journal',
                                                    fontSize: '14px',
                                                    formatter: function() {
                                                        return totalJournal; // dynamic total
                                                    }
                                                }
                                            }
                                        }
                                    }
                                },

                                // Tooltip with percentage
                                tooltip: {
                                    y: {
                                        formatter: function(val) {
                                            let percent = ((val / totalJournal) * 100).toFixed(1);
                                            return val + " (" + percent + "%)";
                                        }
                                    }
                                }
                            };

                            var chart = new ApexCharts(document.querySelector("#journal_status_chart"),
                                options);
                            chart.render();
                        }

                        // REVISION STATUS
                        if (data.revision_status) {
                            $('#jtl-verification').text(data.revision_status.jtl_verification || 0);
                            $('#revision-staff-assigned').text(data.revision_status.staff_assigned || 0);
                            $('#revision-inprogress').text(data.revision_status.inprogress || 0);
                            $('#revision-completed').text(data.revision_status.completed || 0);
                            $('#waiting-documentation').text(data.revision_status.waiting_documentation || 0);
                            $('#pc-not-assign').text(data.revision_status.pc_not_assign || 0);
                            $('#revision-rework').text(data.revision_status.rework || 0);
                            $('#staff-not-assign').text(data.revision_status.staff_not_assign || 0);
                            $('#pc-pending-verification').text(data.revision_status.pc_pending_verification ||
                                0);
                            $('#jtl-pending-verification').text(data.revision_status.jtl_pending_verification ||
                                0);

                            // Data
                            const revisionData = [
                                data.revision_status.jtl_verification || 0,
                                data.revision_status.staff_assigned || 0,
                                data.revision_status.inprogress || 0,
                                data.revision_status.completed || 0,
                                data.revision_status.waiting_documentation || 0,
                                data.revision_status.pc_not_assign || 0,
                                data.revision_status.rework || 0,
                                data.revision_status.staff_not_assign || 0,
                                data.revision_status.pc_pending_verification || 0,
                                data.revision_status.jtl_pending_verification || 0,
                            ];

                            // Total
                            const totalRevision = revisionData.reduce((a, b) => a + b, 0);

                            // Percentages
                            $('#jtl-verification-per').text(
                                formatPercentageTargetActual(data.revision_status.jtl_verification || 0,
                                    totalRevision)
                            );

                            $('#revision-staff-assigned-per').text(
                                formatPercentageTargetActual(data.revision_status.staff_assigned || 0,
                                    totalRevision)
                            );

                            $('#revision-inprogress-per').text(
                                formatPercentageTargetActual(data.revision_status.inprogress || 0,
                                    totalRevision)
                            );

                            $('#revision-completed-per').text(
                                formatPercentageTargetActual(data.revision_status.completed || 0,
                                    totalRevision)
                            );

                            $('#waiting-documentation-per').text(
                                formatPercentageTargetActual(data.revision_status.waiting_documentation ||
                                    0, totalRevision)
                            );

                            $('#pc-not-assign-per').text(
                                formatPercentageTargetActual(data.revision_status.pc_not_assign || 0,
                                    totalRevision)
                            );

                            $('#revision-rework-per').text(
                                formatPercentageTargetActual(data.revision_status.rework || 0,
                                    totalRevision)
                            );

                            $('#staff-not-assign-per').text(
                                formatPercentageTargetActual(data.revision_status.staff_not_assign || 0,
                                    totalRevision)
                            );

                            $('#pc-pending-verification-per').text(
                                formatPercentageTargetActual(data.revision_status.pc_pending_verification ||
                                    0, totalRevision)
                            );

                            $('#jtl-pending-verification-per').text(
                                formatPercentageTargetActual(data.revision_status
                                    .jtl_pending_verification || 0, totalRevision)
                            );

                            var options = {
                                series: revisionData,

                                chart: {
                                    type: 'donut',
                                    height: 350
                                },

                                labels: [
                                    'JTL Verification',
                                    'Staff Assigned',
                                    'In Progress',
                                    'Completed',
                                    'Waiting For Documentation',
                                    'PC Not Assign',
                                    'Rework',
                                    'Staff Not Assign',
                                    'PC Pending Verification',
                                    'JTL Pending Verification'
                                ],

                                // 🎨 Different theme (so it doesn’t look same as journal)
                                colors: [
                                    '#6610f2', // indigo
                                    '#0dcaf0', // cyan
                                    '#198754', // green
                                    '#20c997', // teal
                                    '#ffc107', // yellow
                                    '#fd7e14', // orange
                                    '#dc3545', // red
                                    '#6c757d', // gray
                                    '#0d6efd', // blue
                                    '#d63384' // pink
                                ],

                                legend: {
                                    position: 'bottom'
                                },

                                dataLabels: {
                                    enabled: false
                                },

                                plotOptions: {
                                    pie: {
                                        donut: {
                                            size: '65%',
                                            labels: {
                                                show: true,

                                                name: {
                                                    show: true,
                                                    fontSize: '13px'
                                                },

                                                value: {
                                                    show: true,
                                                    fontSize: '18px',
                                                    fontWeight: 600
                                                },

                                                total: {
                                                    show: true,
                                                    label: 'Total Revision',
                                                    fontSize: '14px',
                                                    formatter: function() {
                                                        return totalRevision; // dynamic total
                                                    }
                                                }
                                            }
                                        }
                                    }
                                },

                                // Tooltip with %
                                tooltip: {
                                    y: {
                                        formatter: function(val) {
                                            let percent = ((val / totalRevision) * 100).toFixed(1);
                                            return val + " (" + percent + "%)";
                                        }
                                    }
                                }
                            };

                            var chart = new ApexCharts(document.querySelector("#revision_status_chart"),
                                options);
                            chart.render();
                        }

                        fetchsalesStaff(data.month, data.year, 1);
                        fetchProductionStaff(data.month, data.year, 2);
                        fetchJournalStaff(data.month, data.year, 14);
                    } else {
                        loadFromCache(selectedDate);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Dashboard load error:', error);
                    loadFromCache(selectedDate);
                },
                complete: function() {
                    $('#dashboard-loader').hide();
                    $('#dashboard-container').removeClass('data-loading');
                    initializeTooltips();
                }
            });
        }

        function loadFromCache(selectedDate) {
            const cachedData = localStorage.getItem('dashboard_cache_' + selectedDate);
            if (cachedData) {
                try {
                    const data = JSON.parse(cachedData);
                    // Update UI with cached data
                } catch (e) {
                    console.error('Failed to parse cached data:', e);
                }
            }
        }

        function formatCurrency(amount) {
            if (typeof amount !== 'number') amount = parseFloat(amount) || 0;
            return '₹ ' + new Intl.NumberFormat('en-IN').format(amount.toFixed(0));
        }

        function formatNumber(amount) {
            if (typeof amount !== 'number') amount = parseFloat(amount) || 0;
            return new Intl.NumberFormat('en-IN').format(amount.toFixed(2));
        }

        function formatPercentage(num) {
            if (typeof num !== 'number') num = parseFloat(num) || 0;
            return num.toFixed(2) + '%';
        }

        function initializeTooltips() {
            if (typeof bootstrap !== 'undefined') {
                const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                tooltipTriggerList.forEach(tooltipTriggerEl => {
                    new bootstrap.Tooltip(tooltipTriggerEl);
                });
            }
        }

        // Initialize datepicker and event listener
        document.addEventListener("DOMContentLoaded", function() {
            $('.month_filter_common_class').datepicker({
                format: "M-yyyy",
                startView: "months",
                minViewMode: "months",
                autoclose: true,
                orientation: "bottom",
                templates: {
                    leftArrow: '<i class="mdi mdi-chevron-left"></i>',
                    rightArrow: '<i class="mdi mdi-chevron-right"></i>'
                }
            }).on('changeMonth', function(e) {
                loadDashboardData($(this).val());
            });

        });
    </script>

    <script>
        function getLast6Months() {
            const months = [];
            const now = new Date();

            for (let i = 5; i >= 0; i--) {
                const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
                months.push(d.toLocaleString('default', {
                    month: 'short'
                }));
            }

            return months;
        }

        var options = {
            series: [{
                    name: 'Avg Target',
                    data: [120000, 140000, 150000, 130000, 160000, 150000]
                },
                {
                    name: 'Avg Achieved',
                    data: [200000, 250000, 3480000, 300000, 420000, 380000]
                },
                {
                    name: 'Conv Target',
                    data: [7000, 7500, 8000, 7800, 8200, 8000]
                },
                {
                    name: 'Conv Achieved',
                    data: [9000, 10000, 11400, 9500, 12000, 11000]
                }
            ],


            chart: {
                type: 'bar',
                height: 300,
                toolbar: {
                    show: false
                }
            },

            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '60%',
                    borderRadius: 2,
                }
            },

            dataLabels: {
                enabled: false
            },

            xaxis: {
                categories: getLast6Months()
            },

            // 🎨 New Color Theme (Premium look)
            colors: [
                '#36d1dc', // Avg Target (cyan)
                '#1e90ff', // Avg Achieved (blue)
                '#f7971e', // Conv Target (orange)
                '#ff4e50' // Conv Achieved (red)
            ],

            yaxis: {
                min: 5000,
                logarithmic: true,
                labels: {
                    formatter: function(val) {
                        return '₹ ' + val.toLocaleString();
                    }
                }
            },

            tooltip: {
                y: {
                    formatter: function(val) {
                        return '₹ ' + val.toLocaleString();
                    }
                }
            },

            legend: {
                position: 'top'
            },

            grid: {
                borderColor: '#f1f1f1'
            }
        };

        var chart = new ApexCharts(document.querySelector("#business_chart"), options);
        chart.render();
    </script>


    <script>
        function getLast6Months() {
            const months = [];
            const now = new Date();

            for (let i = 5; i >= 0; i--) {
                const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
                months.push(d.toLocaleString('default', {
                    month: 'short'
                }));
            }

            return months;
        }

        var options = {
            series: [{
                    name: 'Avg Target',
                    data: [120000, 140000, 150000, 130000, 160000, 150000]
                },
                {
                    name: 'Avg Achieved',
                    data: [200000, 250000, 3480000, 300000, 420000, 380000]
                },
                {
                    name: 'Conv Target',
                    data: [7000, 7500, 8000, 7800, 8200, 8000]
                },
                {
                    name: 'Conv Achieved',
                    data: [9000, 10000, 11400, 9500, 12000, 11000]
                }
            ],


            chart: {
                type: 'bar',
                height: 300,
                toolbar: {
                    show: false
                }
            },

            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '60%',
                    borderRadius: 2,
                }
            },

            dataLabels: {
                enabled: false
            },

            xaxis: {
                categories: getLast6Months()
            },

            // 🎨 🔥 New Color Theme (Premium look)
            colors: [
                '#36d1dc', // Avg Target (cyan)
                '#1e90ff', // Avg Achieved (blue)
                '#f7971e', // Conv Target (orange)
                '#ff4e50' // Conv Achieved (red)
            ],

            yaxis: {
                min: 5000,
                logarithmic: true,
                labels: {
                    formatter: function(val) {
                        return '₹ ' + val.toLocaleString();
                    }
                }
            },

            tooltip: {
                y: {
                    formatter: function(val) {
                        return '₹ ' + val.toLocaleString();
                    }
                }
            },

            legend: {
                position: 'top'
            },

            grid: {
                borderColor: '#f1f1f1'
            }
        };

        var chart = new ApexCharts(document.querySelector("#business_chart"), options);
        chart.render();
    </script>


@endsection
