@extends('layouts/blankLayout')

@section('title', 'Login')

@section('page-style')
@vite([
'resources/assets/vendor/scss/pages/page-auth.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
'resources/assets/vendor/libs/@form-validation/auto-focus.js'
])
@endsection

@section('content')
<style>
  .log_bg_img {
    background-image: url('assets/phdizone_images/login/login_bg.png');
    /* rotate: 180 deg; */
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover !important;
    /* width: 100% !important;
    height: 100% !important; */
  }
</style>
<div class="authentication-wrapper authentication-cover">
  <!-- Logo -->
  <!-- <a href="{{url('/')}}" class="auth-cover-brand d-flex align-items-center gap-2">
    <span class="app-brand-logo demo">@include('_partials.macros',["width"=>25,"withbg"=>'var(--bs-primary)'])</span>
    <span class="app-brand-text demo text-heading fw-bold">{{config('variables.templateName')}}</span>
  </a> -->
  <!-- /Logo -->
  <div class="authentication-inner row m-0">
    <!-- /Left Section -->
    <div class="d-flex col-12 col-lg-5 col-xl-5 align-items-center authentication-bg position-relative py-sm-5 px-4 py-4">
      <div class="w-px-400 mx-auto pt-lg-0">
        <div class="d-flex align-items-center justify-content-center px-2 pb-4">
          <img src="{{asset('assets/phdizone_images/phdizone_logo.png') }}" class="auth-cover-illustration w-300px " alt="auth-illustration" />
        </div>
        <h3 class="mb-6 text-center fw-bold">Research Gateway Hub</h3>
        <form class="mb-3" action="{{route('login_auth')}}" method="POST" onsubmit="return LoginvalidateForm()">
          @csrf
          <div class="mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Username<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="user_name" name="name" placeholder="Enter Username" autofocus />
            <div class="text-danger" id="user_name_err"></div>
          </div>
          <div class="mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
            <div class="form-password-toggle">
              <div class="input-group input-group-merge">
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" aria-describedby="password" />
                <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline fs-4"></i></span>
              </div>
            </div>
            <div class="text-danger" id="password_err"></div>
          </div>
          <div class="mb-3 d-flex justify-content-between">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="remember-me">
              <label class="" for="remember-me">
                Remember Me
              </label>
            </div>
          </div>
          <button type="submit" class="btn btn-primary d-grid w-100">
            Login
          </button>
        </form>
      </div>
    </div>
    <div class="d-none d-lg-flex col-lg-7 col-xl-7 align-items-center justify-content-center log_bg_img p-5 pb-2">
      <!-- <img src="{{asset('assets/img/illustrations/auth-login-illustration-light.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" data-app-light-img="illustrations/auth-login-illustration-light.png" data-app-dark-img="illustrations/auth-login-illustration-dark.png" />
      <img src="{{asset('assets/img/illustrations/auth-cover-login-mask-light.png') }}" class="authentication-image" alt="mask" data-app-light-img="illustrations/auth-cover-login-mask-light.png" data-app-dark-img="illustrations/auth-cover-login-mask-dark.png" /> -->
      <div class="d-flex align-items-center pt-15 ms-5">
        <img src="{{asset('assets/phdizone_images/login/login_img.gif') }}" class="auth-cover-illustration w-550px h-450px" alt="auth-illustration" style="max-inline-size: 100% !important;" />
      </div>
      <!-- <img src="{{asset('assets/eapl_images/student_login/login/login.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" /> -->
      <!-- <img src="{{asset('assets/eapl_images/student_login/5.jpg') }}" class="authentication-image opacity-25 h-100" alt="auth-illustration" /> -->
    </div>
    <!-- /Left Section -->
    <!-- Login -->
    <!-- /Login -->
  </div>
</div>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
  .toast {
    background-color: #39484f;
  }
  .toast-success {
    background-color: green;
  }
  .toast-error {
    background-color: red;
  }
  .error_msg {
    border: solid 2px red !important;
    border-color: red !important;
  }


  
</style>

<script type="text/javascript">
    function LoginvalidateForm() {
        var uname = document.getElementById("user_name").value;
        var pwd = document.getElementById("password").value;

        if (uname !== '' && pwd !== '') {
            login_validation(); // Assuming this is a valid function
            return true; // Allow form submission
        } else {
            // Handle error (e.g., show a message)
            // document.getElementById('user_name_err').innerHTML = 'User Name is required...!';
            // document.getElementById('user_name').classList.add('error_msg');
            // document.getElementById('password_err').innerHTML = 'Password is required...!';
            // document.getElementById('password').classList.add('error_msg');
            return false; // Prevent form submission
        }
    }
</script>
<script>
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
    toastr[type](message);
  @endif

  function LoginvalidateForm() {
    var err = 0;
    var user_name = document.getElementById("user_name").value.trim();
    if (user_name === "") {
        document.getElementById('user_name_err').innerHTML = 'User Name is required...!';
        document.getElementById('user_name').classList.add('error_msg');
        err++;
    } else {
        document.getElementById('user_name').classList.remove('error_msg');
        document.getElementById('user_name_err').innerHTML = '';
    }
    var password = document.getElementById("password").value.trim();
    if (password === "") {
        document.getElementById('password_err').innerHTML = 'Password is required...!';
        document.getElementById('password').classList.add('error_msg');
        err++;
    } else {
        document.getElementById('password').classList.remove('error_msg');
        document.getElementById('password_err').innerHTML = '';
    }
    if (err === 0) {
      showLoadingScreen();
      return true;
    }
    return false;
  }

  document.getElementById('user_name').addEventListener('input', function() {
    document.getElementById('user_name_err').innerHTML = '';
    this.classList.remove('error_msg');
  });

  document.getElementById('password').addEventListener('input', function() {
    document.getElementById('password_err').innerHTML = '';
    this.classList.remove('error_msg');
  });

  function showLoadingScreen() {
    document.getElementById('loadingScreen').style.display = 'block';
  }
</script>
@endsection