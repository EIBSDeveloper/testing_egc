@extends('layouts/layoutMaster')

@section('title', 'Pre-Sales Executive Dashboard')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

    <style>
        /* Loading Spinner Styles */
        #loadingSpinner {
            min-height: 500px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .spinner-border {
            width: 3rem;
            height: 3rem;
        }

        :root {
            --progress-bar-width: 40px;
            --progress-bar-height: 40px;
            --font-size: 1rem;
            --progress-color: #28a745;
            --background-color: #e2e6ea;
            --inner-circle-color: white;
            --percentage-color: #333;
        }

        .progress-circle {
            position: relative;
            width: var(--progress-bar-width);
            height: var(--progress-bar-height);
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .inner-circle {
            position: absolute;
            width: calc(var(--progress-bar-width) - 8px);
            height: calc(var(--progress-bar-height) - 8px);
            border-radius: 50%;
            background-color: var(--inner-circle-color);
        }

        .percentage {
            position: relative;
            font-size: 11px;
            color: var(--percentage-color);
            font-weight: bold;
        }

        @media (max-width: 992px) {
            .card-body {
                padding: 1rem !important;
            }

            .text-wrap {
                max-width: 300px !important;
            }
        }

        @media (max-width: 768px) {
            .d-flex.justify-content-between.align-items-end {
                flex-wrap: wrap;
                justify-content: center !important;
            }

            .fw-semibold.text-danger.mb-1,
            .fw-semibold.text-info.mb-1,
            .fw-semibold.text-success.mb-1 {
                font-size: 2rem !important;
            }
        }

        @media (max-width: 576px) {
            .card {
                box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.3);
            }

            .avatar img {
                width: 60px !important;
                height: 60px !important;
            }

            .text-wrap {
                max-width: 100% !important;
                font-size: 0.95rem !important;
            }

            .badge {
                font-size: 0.7rem !important;
            }

            .d-flex.justify-content-center {
                flex-direction: column;
                gap: 1rem !important;
            }
        }

        .bullet-vertical {
            display: inline-block;
            border-radius: 2px;
        }

        @media (max-width: 1200px) {
            .card-body {
                padding: 1.25rem !important;
            }
        }

        @media (max-width: 992px) {
            .fs-4 {
                font-size: 1.2rem !important;
            }

            .fs-3 {
                font-size: 1.5rem !important;
            }

            .fs-7 {
                font-size: 0.8rem !important;
            }
        }

        @media (max-width: 768px) {
            .row>[class*="col-"] {
                margin-bottom: 1rem;
            }

            .card-body {
                padding: 1rem 1.25rem !important;
            }

            .fs-4 {
                font-size: 1.1rem !important;
            }

            .fs-3 {
                font-size: 1.3rem !important;
            }

            .fs-7 {
                font-size: 0.75rem !important;
            }
        }

        @media (max-width: 576px) {
            .card {
                box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.25) !important;
            }

            .card-body {
                padding: 0.9rem 1rem !important;
            }

            .fs-4 {
                font-size: 1rem !important;
            }

            .fs-3 {
                font-size: 1.2rem !important;
            }

            .fs-7 {
                font-size: 0.7rem !important;
            }

            .bullet-vertical {
                height: 20px !important;
                width: 4px !important;
            }
        }

        .card {
            border-radius: 10px;
        }

        .badge {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        @media (min-width: 992px) {

            .col-xl-3:last-child,
            .col-lg-6:nth-child(2n):last-child {
                border-right: none !important;
            }
        }

        @media (max-width: 1200px) {
            .fs-1 {
                font-size: 2rem !important;
            }
        }

        @media (max-width: 992px) {
            .fs-1 {
                font-size: 1.8rem !important;
            }

            .fs-7 {
                font-size: 0.8rem !important;
            }

            .card-body {
                padding: 1rem !important;
            }

            .border-end-sm {
                border-right: none !important;
                border-bottom: 1px solid #e5e5e5;
            }
        }

        @media (max-width: 768px) {
            .fs-1 {
                font-size: 1.6rem !important;
            }

            .fs-7 {
                font-size: 0.75rem !important;
            }

            .badge span {
                font-size: 1.3rem !important;
            }

            .card-body {
                padding: 0.8rem 1rem !important;
            }
        }

        @media (max-width: 576px) {
            .fs-1 {
                font-size: 1.4rem !important;
            }

            .fs-7 {
                font-size: 0.7rem !important;
            }

            .badge {
                padding: 0.5rem !important;
            }

            .mdi {
                font-size: 1.2rem !important;
            }
        }

        .h-450px {
            height: 450px;
        }

        .h-350px {
            height: 350px;
        }

        .object-fit-cover {
            object-fit: cover;
        }

        .max-w-350px {
            max-width: 350px;
        }

        .fs-8 {
            font-size: 0.75rem;
        }
    </style>

    <!-- Loading Spinner -->
    <div id="loadingSpinner" class="d-none">
        <div class="text-center py-4">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading dashboard data...</p>
        </div>
    </div>

    <div class="dashboard-content">
        <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
            <div class="d-flex align-items-center flex-wrap gap-3">
                <div class="avatar avatar-xl flex-shrink-0 position-relative">
                    <img src="{{ asset('assets/phdizone_images/user_1.png') }}" id="userAvatar" alt="avatar"
                        class="rounded-circle border border-dark shadow-lg img-fluid" />
                    <div id="userIntial"
                        class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold position-absolute top-0 start-0"
                        style="width: 70px; height: 70px; display: none;"></div>
                </div>
                <div class="d-flex flex-column flex-grow-1">
                    <label class="text-black fw-semibold fs-5 mb-1 text-wrap" style="max-width: 400px;"
                        id="userName"></label>
                    <label class="text-danger fw-semibold mb-0" id="userRoleName">Pre-sales Executive</label>
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-end mb-1 gap-2">
                <div class="w-75 mb-1">
                    <div class="cursor-pointer input-group input-group-merge">
                        <span class="input-group-text bg-label-warning text-black"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="dateFilter"
                            class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class"
                            value="<?php echo date('M-Y'); ?>" readonly onchange="loadDashboardData(this.value)">
                        <span class="input-group-text bg-label-warning text-black"><i
                                class="mdi mdi-menu-down fs-4"></i></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-lg-6 col-md-12">
                <div class="row g-2 mb-2">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 mb-1">
                        <div class="card rounded px-3 py-3 border" style="box-shadow: none; height: 100%;">
                            <label class="fw-semibold fs-6 text-success mb-0">Total Lead</label>
                            <div class="d-flex align-items-center justify-content-between gap-3">
                                <span class="fw-semibold text-black fs-2" id="totalLeads">0</span>
                                <div class="d-flex align-items-center flex-shrink-0 me-3">
                                    <i class="fs-5 me-1" id="totalLeadUpDown"></i>
                                    <span class="fs-7 fw-semibold" id="totalLeadsPercentage">0%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 mb-1">
                        <div class="card rounded px-3 py-3 border" style="box-shadow: none; height: 100%;">
                            <label class="fw-semibold fs-6 text-warning mb-0">Active Lead</label>
                            <div class="d-flex align-items-center justify-content-between gap-3">
                                <span class="fw-semibold text-black fs-2" id="activeLeads">0</span>
                                <div class="d-flex align-items-center flex-shrink-0 me-3">
                                    <i class="fs-5 me-1" id="ActiveLeadUpDown"></i>
                                    <span class="fs-7 fw-semibold" id="activeLeadsPercentage">0%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 mb-1">
                        <div class="card rounded px-3 py-3 border" style="box-shadow: none; height: 100%;">
                            <label class="fw-semibold fs-6 text-secondary mb-0">Spam Lead</label>
                            <div class="d-flex align-items-center justify-content-between gap-3">
                                <span class="fw-semibold text-black fs-2" id="spamLeads">0</span>
                                <div class="d-flex align-items-center flex-shrink-0 me-3">
                                    <i class="fs-5 me-1" id="SpamLeadUpDown"></i>
                                    <span class="fs-7 fw-semibold" id="spamLeadsPercentage">0%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 mb-1">
                        <div class="card rounded px-3 py-3 border" style="box-shadow: none; height: 100%;">
                            <label class="fw-semibold fs-6 text-danger mb-0">Dead Lead</label>
                            <div class="d-flex align-items-center justify-content-between gap-3">
                                <span class="fw-semibold text-black fs-2" id="deadLeads">0</span>
                                <div class="d-flex align-items-center flex-shrink-0 me-3">
                                    <i class="fs-5 me-1" id="DeadLeadUpDown"></i>
                                    <span class="fs-7 fw-semibold" id="deadLeadsPercentage">0%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row g-2 mb-2">
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                        <div class="card w-100 h-100 bg-white border rounded">
                            <div class="card-body d-flex align-items-center justify-content-between">
                                <div class="d-flex flex-column gap-1">
                                    <div class="d-flex align-items-center gap-2">
                                        <label class="fs-1 text-black fw-semibold mb-0" id="avgAppointments">0</label>
                                    </div>
                                    <label class="text-black fs-7 fw-semibold mb-0">Average Appointments</label>
                                </div>
                                <div class="avatar avatar-lg my-auto">
                                    <div class="avatar-initial bg-label-dark rounded-circle">
                                        <i class="mdi mdi-calendar-account-outline text-dark fs-3"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                        <div class="card w-100 h-100 bg-white border rounded">
                            <div class="card-body d-flex align-items-center justify-content-between">
                                <div class="d-flex flex-column gap-1">
                                    <div class="d-flex align-items-center gap-2">
                                        <label class="fs-1 text-black fw-semibold mb-0" id="avgFollowups">0</label>
                                    </div>
                                    <label class="text-black fs-7 fw-semibold mb-0">Average Followups</label>
                                </div>
                                <div class="avatar avatar-lg my-auto">
                                    <div class="avatar-initial bg-label-info rounded-circle">
                                        <i class="mdi mdi-calendar-clock-outline fs-3 text-info"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                        <div class="card w-100 h-100 bg-white border rounded">
                            <div class="card-body d-flex align-items-center justify-content-between">
                                <div class="d-flex flex-column gap-1">
                                    <div class="d-flex align-items-center gap-2">
                                        <label class="fs-1 text-black fw-semibold mb-0" id="avgWalkIn">0</label>
                                    </div>
                                    <label class="text-black fs-7 fw-semibold mb-0">Average Walk-In</label>
                                </div>
                                <div class="avatar avatar-lg my-auto">
                                    <div class="avatar-initial bg-label-primary rounded-circle">
                                        <i class="mdi mdi-exit-run text-primary fs-3"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                        <div class="card w-100 h-100 bg-white border rounded">
                            <div class="card-body d-flex align-items-center justify-content-between">
                                <div class="d-flex flex-column gap-1">
                                    <div class="d-flex align-items-center gap-2">
                                        <label class="fs-1 text-black fw-semibold mb-0" id="avgMissedCalls">0</label>
                                    </div>
                                    <label class="text-black fs-7 fw-semibold mb-0">Average Outgoing Calls</label>
                                </div>
                                <div class="avatar avatar-lg my-auto">
                                    <div class="avatar-initial bg-label-danger rounded-circle">
                                        <i class="mdi mdi-phone-missed-outline fs-3 text-danger"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row g-2 mb-2">
                    <div class="col-lg-12 col-md-12 mb-2">
                        <div class="card px-3 py-3 rounded border"
                            style="box-shadow: none; height: auto; min-height: 663px;">
                            <div class="row">
                                <div class="col-lg-4 mb-2">
                                    <label class="text-dark fs-5 fw-semibold mb-0">Metrics</label>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-5 text-dark mb-0">Target</label>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-5 text-dark mb-0">Achieved</label>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-lg-4 mb-2">
                                    <div class="d-flex gap-2 align-items-center">
                                        <span class="badge bg-label-secondary rounded-circle px-2 py-2">
                                            <i class="mdi mdi-account-outline text-black fw-bold"></i>
                                        </span>
                                        <label class="text-dark fs-5 fw-semibold mb-0">Conversion</label>
                                    </div>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2 text-black mb-0" id="conversionTarget">0</label>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2" id="conversionAchieved">0</label>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-lg-4 mb-2">
                                    <div class="d-flex gap-2 align-items-center">
                                        <span class="badge bg-label-secondary rounded-circle px-2 py-2">
                                            <i class="mdi mdi-handshake-outline text-black fw-bold"></i>
                                        </span>
                                        <label class="text-dark fs-5 fw-semibold mb-0">Avg. Business Value</label>
                                    </div>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2 text-black mb-0" id="businessValueTarget">₹ 0</label>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2" id="businessValueAchieved">₹ 0</label>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-lg-4 mb-2">
                                    <div class="d-flex gap-2 align-items-center">
                                        <span class="badge bg-label-secondary rounded-circle px-2 py-2">
                                            <i class="mdi mdi-finance text-black fw-bold"></i>
                                        </span>
                                        <label class="text-dark fs-5 fw-semibold mb-0">Conversion Rate</label>
                                    </div>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2 text-black mb-0" id="conversionRateTarget">0</label>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2" id="conversionRateAchieved">0</label>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-lg-4 mb-2">
                                    <div class="d-flex gap-2 align-items-center">
                                        <span class="badge bg-label-secondary rounded-circle px-2 py-2">
                                            <i class="mdi mdi-currency-inr text-black fw-bold"></i>
                                        </span>
                                        <label class="text-dark fs-5 fw-semibold mb-0">Avg. Collection Value</label>
                                    </div>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2 text-black mb-0" id="collectionValueTarget">₹ 0</label>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2" id="collectionValueAchieved">₹ 0</label>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-lg-4 mb-2">
                                    <div class="d-flex gap-2 align-items-center">
                                        <span class="badge bg-label-secondary rounded-circle px-2 py-2">
                                            <i class="mdi mdi-account-group text-black fw-bold"></i>
                                        </span>
                                        <label class="text-dark fs-5 fw-semibold mb-0">Walk In</label>
                                    </div>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2 text-black mb-0" id="walkInTarget">0</label>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2" id="walkInAchieved">0</label>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-lg-4 mb-2">
                                    <div class="d-flex gap-2 align-items-center">
                                        <span class="badge bg-label-secondary rounded-circle px-2 py-2">
                                            <i class="mdi mdi-phone-outgoing text-black fw-bold"></i>
                                        </span>
                                        <label class="text-dark fs-5 fw-semibold mb-0">Avg. Outgoing Call Rate</label>
                                    </div>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2 text-black mb-0" id="outgoingCallTarget">0</label>
                                </div>
                                <div class="col-lg-4 mb-2 text-center">
                                    <label class="fw-semibold fs-2" id="outgoingCallAchieved">0</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 col-md-12">
                <div class="row g-2 mb-2">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 mb-1">
                        <div class="card rounded px-3 py-3 border" style="box-shadow: none; height: 100%;">
                            <label class="fw-semibold fs-6 text-success mb-0">On Day</label>
                            <div class="d-flex align-items-center justify-content-between gap-3">
                                <span class="fw-semibold text-black fs-2" id="odcCount">0</span>
                                <div class="d-flex align-items-center flex-shrink-0 me-3">
                                    <span class="fs-7 text-dark fw-semibold">Conversion</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 mb-1">
                        <div class="card rounded px-3 py-3 border" style="box-shadow: none; height: 100%;">
                            <label class="fw-semibold fs-6 text-warning mb-0">On Month</label>
                            <div class="d-flex align-items-center justify-content-between gap-3">
                                <span class="fw-semibold text-black fs-2" id="mcCount">0</span>
                                <div class="d-flex align-items-center flex-shrink-0 me-3">
                                    <span class="fs-7 text-dark fw-semibold">Conversion</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 mb-1">
                        <div class="card rounded px-3 py-3 border" style="box-shadow: none; height: 100%;">
                            <label class="fw-semibold fs-6 text-secondary mb-0">Old Month</label>
                            <div class="d-flex align-items-center justify-content-between gap-3">
                                <span class="fw-semibold text-black fs-2" id="omcCount">0</span>
                                <div class="d-flex align-items-center flex-shrink-0 me-3">
                                    <span class="fs-7 text-dark fw-semibold">Conversion</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 mb-1">
                        <div class="card rounded px-3 py-3 border" style="box-shadow: none; height: 100%;">
                            <label class="fw-semibold fs-6 text-danger mb-0">Total</label>
                            <div class="d-flex align-items-center justify-content-between gap-3">
                                <span class="fw-semibold text-black fs-2" id="convertedCustomers">0</span>
                                <div class="d-flex align-items-center flex-shrink-0 me-3">
                                    <span class="fs-7 text-dark fw-semibold">Conversion</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row g-2 mb-2">
                    <div class="card rounded border card-action" style="box-shadow: none; height: 450px;">
                        <div class="card-header border-bottom py-3 pb-2">
                            <div class="card-action-title text-black fw-semibold fs-4">Followup Schedule
                                <label class="ms-3">( <span class="text-success">{{ date('d-M-Y') }}</span> )</label>
                            </div>
                            <div class="card-action-element text-center fw-semibold fs-6">
                                <span class="badge bg-success fw-semibold rounded-pill text-white fs-6"
                                    id="dayFollowUpCount">0</span>
                            </div>
                        </div>
                        <div class="card-body overflow-auto" style="max-height: 350px;" id="followupSchedule">
                            <!-- Followup schedule will be populated via AJAX -->
                            <div class="text-center py-3">
                                <div class="spinner-border spinner-border-sm" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row g-2 mb-2">
                    <div class="card rounded border card-action" style="box-shadow: none; height: 450px;">
                        <div class="card-header border-bottom py-3 pb-3">
                            <div class="card-action-title text-black fw-semibold fs-4 my-auto">Appointment Schedule
                                <label class="ms-3">( <span class="text-success">{{ date('d-M-Y') }}</span> )</label>
                            </div>
                            <div class="card-action-element text-center fw-semibold fs-6">
                                <span class="fs-7 fw-semibold text-dark">Walk In</span>
                                <span class="badge bg-label-info fw-semibold rounded-pill text-black fs-6"
                                    id="walkInBadge">0</span>
                            </div>
                        </div>
                        <div class="card-body overflow-auto pt-3" style="max-height: 350px;" id="appointmentSchedule">
                            <!-- Appointment schedule will be populated via AJAX -->
                            <div class="text-center py-3">
                                <div class="spinner-border spinner-border-sm" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-2 mt-2">
            <div class="col-lg-12">
                <div class="card rounded border card-action" style="box-shadow: none; height: 350px;">
                    <div class="card-header border-bottom py-3 pb-2">
                        <div class="card-action-title text-black fw-semibold fs-5">Low MPC Paid</div>
                        <div class="card-action-element text-center fw-semibold fs-6">
                            <div class="badge bg-danger rounded-pill fs-6 fw-semibold" id="lowMpcBadge">0</div>
                        </div>
                    </div>
                    <div class="card-body overflow-auto" style="max-height: 250px;" id="lowMpcList">
                        <!-- Low MPC list will be populated via AJAX -->
                        <div class="text-center py-3">
                            <div class="spinner-border spinner-border-sm" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Initialize dashboard when document is ready
        $(document).ready(function() {
            // Initialize datepicker if available
            if ($.fn.datepicker) {
                $('.month_filter_common_class').datepicker({
                    format: 'M-yyyy',
                    viewMode: 'months',
                    minViewMode: 'months',
                    autoclose: true
                });
            }

            // Load initial data
            loadDashboardData($("#dateFilter").val());

            // Auto-refresh every 5 minutes (300000 ms)
            setInterval(function() {
                loadDashboardData($("#dateFilter").val());
            }, 300000);
        });

        // Refresh when page becomes visible again
        document.addEventListener("visibilitychange", function() {
            if (!document.hidden) {
                loadDashboardData($("#dateFilter").val());
            }
        });

        // Function to load dashboard data
        function loadDashboardData(dateFilter) {
            // Show loading spinner
            $("#loadingSpinner").removeClass("d-none");
            $(".dashboard-content").addClass("d-none");

            $.ajax({
                url: "{{ route('dashboard/sales_executive') }}",
                method: "GET",
                data: {
                    date_filter: dateFilter,
                    _token: "{{ csrf_token() }}"
                },
                dataType: "json",
                success: function(response) {
                    updateDashboardData(response);
                    $("#loadingSpinner").addClass("d-none");
                    $(".dashboard-content").removeClass("d-none");
                },
                error: function(xhr, status, error) {
                    console.error("Error loading dashboard data:", error);
                    $("#loadingSpinner").addClass("d-none");
                    $(".dashboard-content").removeClass("d-none");

                    // Show error message if toastr is available
                    if (typeof toastr !== 'undefined') {
                        toastr.error('Failed to load dashboard data. Please try again.');
                    }
                }
            });
        }

        // Helper function to update lead cards with trend indicators
        function updateLeadCard(valueId, percentageId, iconId, value, percentage) {
            $(valueId).text(value || 0);

            // Format percentage with % sign
            let percentageValue = (percentage || 0);
            $(percentageId).text(percentageValue);

            // Reset classes
            $(iconId).removeClass('mdi-trending-up mdi-trending-down text-success text-danger');
            $(percentageId).removeClass('text-success text-danger');

            // Add appropriate classes based on comparison
            if (value >= percentage) {
                $(iconId).addClass('mdi mdi-trending-up text-success');
                $(percentageId).addClass('text-success');
            } else {
                $(iconId).addClass('mdi mdi-trending-down text-danger');
                $(percentageId).addClass('text-danger');
            }
        }

        // Function to update dashboard data
        function updateDashboardData(data) {
            // Basic stats
            let staffImage = data.staff_details?.staff_image;
            let staffName = data.staff_details?.staff_name || 'No Name Provided';

            // Handle user avatar
            $('#userAvatar').hide();
            $('#userIntial').hide();
            if (staffImage) {
                $('#userAvatar').show();
                $('#userAvatar').attr('src', `{{ asset('staff_images') }}/${staffImage}`).show();
            } else {
                $('#userIntial').show();
                let initial = staffName.charAt(0).toUpperCase();
                $('#userIntial').text(initial);
            }

            $("#userName").text(staffName);
            $("#userRoleName").text(data.staff_details?.job_position_name || 'Pre-sales Executive');

            // Update lead counts
            updateLeadCard('#totalLeads', '#totalLeadsPercentage', '#totalLeadUpDown',
                data.total_leads, data.total_leads_percentage);
            updateLeadCard('#activeLeads', '#activeLeadsPercentage', '#ActiveLeadUpDown',
                data.active_leads, data.active_leads_percentage);
            updateLeadCard('#spamLeads', '#spamLeadsPercentage', '#SpamLeadUpDown',
                data.spam_leads, data.spam_leads_percentage);
            updateLeadCard('#deadLeads', '#deadLeadsPercentage', '#DeadLeadUpDown',
                data.dead_leads, data.dead_leads_percentage);

            // Conversion stats
            $("#odcCount").text(data.odc_count || 0);
            $("#mcCount").text(data.mc_count || 0);
            $("#omcCount").text(data.omc_count || 0);
            $("#convertedCustomers").text(data.converted_customers || 0);

            const staffTarget = data.StaffTarget || {};

            const getStatusIcon = (actual, target) => {
                return actual >= target && target > 0 ?
                    'mdi-trending-up text-success' :
                    'mdi-trending-down text-danger';
            };

            const getStatusClassText = (actual, target) => {
                return actual >= target && target > 0 ?
                    'text-success' :
                    'text-danger';
            };

            // Walk-in & Calls (with trend icons)
            const walkTarget = staffTarget.no_of_walk ?? 0;
            const walkActual = staffTarget.no_of_walk_actual ?? 0;
            const callTarget = staffTarget.avg_call_out ?? 0;
            const callActual = staffTarget.avg_call_out_actual ?? 0;

            // Walk-in status
            $("#walkInAchieved")
                .removeClass('text-danger text-success')
                .addClass(getStatusClassText(walkActual, walkTarget))
                .html(`${walkActual} <i class="mdi ${getStatusIcon(walkActual, walkTarget)} ms-1 fs-5"></i>`);

            // Outgoing calls status
            $("#outgoingCallAchieved")
                .removeClass('text-danger text-success')
                .addClass(getStatusClassText(callActual, callTarget))
                .html(`${callActual} <i class="mdi ${getStatusIcon(callActual, callTarget)} ms-1 fs-5"></i>`);

            const getStatusClass = (actual, target) => {
                return target > 0 && actual >= target ?
                    'text-success' :
                    'text-danger';
            };

            // Conversion
            const conversionTarget = staffTarget.conversion ?? 0;
            const conversionActual = staffTarget.conversion_actual ?? 0;

            $("#conversionAchieved")
                .text(conversionActual)
                .removeClass('text-danger text-success')
                .addClass(getStatusClass(conversionActual, conversionTarget));

            // Business Value (CR)
            const crTarget = staffTarget.CR ?? 0;
            const crActual = staffTarget.CR_actual ?? 0;

            $("#conversionRateAchieved")
                .text(formatCurrency(crActual))
                .removeClass('text-danger text-success')
                .addClass(getStatusClass(crActual, crTarget));

            // Conversion Rate (ABV)
            const abvTarget = staffTarget.ABV ?? 0;
            const abvActual = staffTarget.ABV_actual ?? 0;

            $("#businessValueAchieved")
                .text(formatCurrency(abvActual))
                .removeClass('text-danger text-success')
                .addClass(getStatusClass(abvActual, abvTarget));

            // Collection Value (ACV)
            const acvTarget = staffTarget.ACV ?? 0;
            const acvActual = staffTarget.ACV_actual ?? 0;

            $("#collectionValueAchieved")
                .text(formatCurrency(acvActual))
                .removeClass('text-danger text-success')
                .addClass(getStatusClass(acvActual, acvTarget));

            // Targets
            $("#outgoingCallTarget").text(callTarget);
            $("#walkInTarget").text(walkTarget);
            $("#conversionTarget").text(conversionTarget);
            $("#conversionRateTarget").text(crTarget);
            $("#businessValueTarget").text(formatCurrency(abvTarget));
            $("#collectionValueTarget").text(formatCurrency(acvTarget));

            // Average stats
            $("#avgAppointments").text(data.avg_appointments || 0);
            $("#avgWalkIn").text(data.avg_walk_in || 0);
            $("#avgFollowups").text(data.avg_followups || 0);
            $("#avgMissedCalls").text(data.avg_missed_calls || 0);

            // Badges
            $("#walkInBadge").text(data.walk_in_badge || "0");
            $("#lowMpcBadge").text(data.low_mpc_list_count || "0");

            // Dynamic lists
            updateAppointmentSchedule(data.appointment_schedule || []);
            updateLowMpcList(data.low_mpc_list || []);
            updateFollowupSchedule(data.followup_schedule || []);
        }

        // Format currency
        function formatCurrency(amount) {
            if (typeof amount === 'number') {
                return '₹ ' + amount.toLocaleString('en-IN', {
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 0
                });
            }
            return amount || '₹ 0';
        }

        // Update appointment schedule
        function updateAppointmentSchedule(appointments) {
            const container = $("#appointmentSchedule");
            container.empty();

            if (!appointments || appointments.length === 0) {
                container.html('<div class="text-center py-3 text-muted">No appointments scheduled</div>');
                return;
            }

            appointments.forEach(function(appointment) {
                const appointmentHtml = `
                    <div class="d-flex align-items-center justify-content-between border-bottom p-3 mb-2 ${appointment.appointment_category === '3' ? 'bg-label-info rounded' : ''}">
                        <div class="d-flex align-items-center">
                            <div class="symbol symbol-35px me-2">
                                ${
                                    appointment.avatar
                                    ? `<img src="${appointment.avatar}"
                                                            alt="user-avatar"
                                                            class="rounded-circle" style="width:35px;height:35px;object-fit:cover;" />`
                                    : `<div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold"
                                                            style="width:35px;height:35px;">
                                                            ${appointment.lead_name?.charAt(0).toUpperCase() || '?'}
                                                        </div>`
                                }
                            </div>

                            <div class="mb-0 align-items-center">
                                <div class="fs-7 fw-semibold text-black mb-0 align-items-center text-truncate" style="max-width: 250px;" 
                                     title="${appointment.lead_name || ''} - ${appointment.lead_ai_id || ''}">
                                    ${appointment.lead_name || ''} - ${appointment.lead_ai_id || ''}
                                </div>
                                ${appointment.app_status === 'Rescheduled'
                                    ? '<div class="d-block text-danger fw-semibold fs-8">Re-Scheduled</div>'
                                    : ''
                                }
                                ${appointment.app_status === 'Completed'
                                    ? '<div class="d-block text-success fw-semibold fs-8">Completed</div>'
                                    : ''
                                }
                                ${appointment.app_status === 'Scheduled'
                                    ? '<div class="d-block text-info fw-semibold fs-8">Scheduled</div>'
                                    : ''
                                }
                            </div>
                        </div>

                        <div class="${appointment.appointment_date ? 'text-end' : 'text-center'} fw-semibold">
                            ${appointment.appointment_date 
                                ? `<div class="text-dark fw-semibold fs-8">${appointment.appointment_date}</div>` 
                                : ''
                            }
                            <div class="text-dark fw-semibold fs-8">${appointment.appointment_time || ''}</div>
                        </div>
                    </div>
                `;
                container.append(appointmentHtml);
            });

            // Initialize tooltips if Bootstrap tooltips are available
            if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
                var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
                tooltipTriggerList.map(function(tooltipTriggerEl) {
                    return new bootstrap.Tooltip(tooltipTriggerEl)
                });
            }
        }

        // Update low MPC list
        function updateLowMpcList(mpcList) {
            const container = $("#lowMpcList");
            container.empty();

            // Check if mpcList is an object
            const entries = mpcList && typeof mpcList === 'object' ? Object.entries(mpcList) : [];

            if (entries.length === 0) {
                container.html('<div class="text-center py-3 text-muted">No low MPC payments</div>');
                return;
            }

            entries.forEach(function([key, mpc]) {
                const mpcHtml = `
                    <div class="d-flex align-items-center justify-content-between border-bottom pb-3 mb-2">
                        <div class="d-flex align-items-center">
                            <div class="symbol symbol-35px me-2">
                                ${
                                    mpc.avatar
                                        ? `<img src="${mpc.avatar}"
                                                                class="rounded-circle" style="width:35px;height:35px;object-fit:cover;" />`
                                        : `<div class="rounded-circle bg-primary text-white 
                                                                d-flex align-items-center justify-content-center fw-bold"
                                                                style="width:35px;height:35px;">
                                                                ${mpc.customer_name?.charAt(0).toUpperCase() || '?'}
                                                           </div>`
                                }
                            </div>

                            <div>
                                <div class="fs-7 fw-semibold text-black">${mpc.customer_name || ''}</div>
                                <div class="fs-8 text-muted">${key}</div>
                            </div>
                        </div>

                        <div class="text-end fw-semibold">
                            <div class="text-danger fs-6">${formatCurrency(mpc.total_paid)}</div>
                            <div class="badge bg-label-danger text-dark fs-8">
                                ${mpc.days_left || ''}
                            </div>
                        </div>
                    </div>
                `;
                container.append(mpcHtml);
            });
        }

        // Update followup schedule
        function updateFollowupSchedule(followups) {
            const container = $("#followupSchedule");
            container.empty();

            if (!followups || followups.length === 0) {
                container.html('<div class="text-center py-3 text-muted">No followups scheduled</div>');
                $('#dayFollowUpCount').text('0');
                return;
            }

            $('#dayFollowUpCount').text(followups.length);

            followups.forEach(function(followup) {
                const followupHtml = `
                    <div class="d-flex align-items-center justify-content-between border-bottom p-3 mb-2 ${followup.display_status === 'Rescheduled' ? 'bg-label-danger rounded' : ''}">
                        <div class="mb-0">
                            <div class="fw-semibold">
                                <label class="fs-7 fw-semibold text-black me-2">${followup.lead_name || ''}</label>
                                <label><i class="mdi ${followup.lead_gender === 2 ? 'mdi-face-woman text-danger' : 'mdi-face-man text-info'}"></i></label>
                            </div>
                            <div class="d-block text-info fw-semibold fs-8">${followup.lead_ai_id || ''}</div>
                            ${followup.display_status === 'Rescheduled' ? '<div class="d-block text-danger fw-semibold fs-8">Re-Scheduled</div>' : ''}
                        </div>
                        <div class="text-end fw-semibold">
                            ${followup.display_status === 'Rescheduled' ? `<div class="badge bg-success text-black fw-semibold fs-8 mb-2">${followup.appointment_date || ''}</div>` : ''}
                            <div class="d-block">
                                <div class="badge bg-label-success text-black fw-semibold fs-8">${followup.appointment_time || ''}</div>
                            </div>
                        </div>
                    </div>
                `;
                container.append(followupHtml);
            });
        }
    </script>
@endsection
