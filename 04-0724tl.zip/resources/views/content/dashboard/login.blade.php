@extends('layouts/blankLayout')

@section('title', 'Login')

@section('page-style')
    @vite(['resources/assets/vendor/scss/pages/page-auth.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/@form-validation/bootstrap5.js', 'resources/assets/vendor/libs/@form-validation/auto-focus.js'])
@endsection

@section('content')
    <style>
        .log_bg_img {
            background-image: url('assets/phdizone_images/login/login_bg.png');
            /* rotate: 180 deg; */
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover !important;
            /* width: 100% !important;
                                    height: 100% !important; */
        }
    </style>
    <div class="authentication-wrapper authentication-cover">
        <!-- Logo -->
        <!-- <a href="{{ url('/') }}" class="auth-cover-brand d-flex align-items-center gap-2">
                                    <span class="app-brand-logo demo">@include('_partials.macros', [
                                        'width' => 25,
                                        'withbg' => 'var(--bs-primary)',
                                    ])</span>
                                    <span class="app-brand-text demo text-heading fw-bold">{{ config('variables.templateName') }}</span>
                                  </a> -->
        <!-- /Logo -->
        <div class="authentication-inner row m-0">
            <!-- /Left Section -->
            <div
                class="d-flex col-12 col-lg-5 col-xl-5 align-items-center authentication-bg position-relative py-sm-5 px-4 py-4">
                <div class="w-px-400 mx-auto pt-lg-0">
                    <div class="d-flex align-items-center justify-content-center px-2 pb-4">
                        <img src="{{ asset('assets/phdizone_images/phdizone_logo.png') }}"
                            class="auth-cover-illustration w-300px " alt="auth-illustration" />
                    </div>
                    <h3 class="mb-6 text-center fw-bold">Research Gateway Hub</h3>
                    <form class="mb-3" action="{{ route('login_auth') }}" method="POST"
                        onsubmit="return LoginvalidateForm()">
                        @csrf
                        <div class="mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Username<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="user_name" name="name"
                                placeholder="Enter Username" autofocus />
                            <div class="text-danger" id="user_name_err"></div>
                        </div>
                        <div class="mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Password<span
                                    class="text-danger">*</span></label>
                            <div class="form-password-toggle">
                                <div class="input-group input-group-merge">
                                    <input type="password" class="form-control" id="password" name="password"
                                        placeholder="Enter Password" aria-describedby="password" />
                                    <span class="input-group-text cursor-pointer"><i
                                            class="mdi mdi-eye-off-outline fs-4"></i></span>
                                </div>
                            </div>
                            <div class="text-danger" id="password_err"></div>
                        </div>
                        <div class="mb-3 d-flex justify-content-between">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="remember-me">
                                <label class="" for="remember-me">
                                    Remember Me
                                </label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary d-grid w-100">
                            Login
                        </button>

                    </form>
                </div>
            </div>

            <div class="d-none d-lg-flex col-lg-7 col-xl-7 align-items-center justify-content-center log_bg_img p-5 pb-2">
                <!-- <img src="{{ asset('assets/img/illustrations/auth-login-illustration-light.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" data-app-light-img="illustrations/auth-login-illustration-light.png" data-app-dark-img="illustrations/auth-login-illustration-dark.png" />
                                      <img src="{{ asset('assets/img/illustrations/auth-cover-login-mask-light.png') }}" class="authentication-image" alt="mask" data-app-light-img="illustrations/auth-cover-login-mask-light.png" data-app-dark-img="illustrations/auth-cover-login-mask-dark.png" /> -->
                <div class="d-flex align-items-center pt-15 ms-5">
                    <img src="{{ asset('assets/phdizone_images/login/login_img.gif') }}"
                        class="auth-cover-illustration w-550px h-450px" alt="auth-illustration"
                        style="max-inline-size: 100% !important;" />
                </div>
                <!-- <img src="{{ asset('assets/eapl_images/student_login/login/login.png') }}" class="auth-cover-illustration w-100" alt="auth-illustration" /> -->
                <!-- <img src="{{ asset('assets/eapl_images/student_login/5.jpg') }}" class="authentication-image opacity-25 h-100" alt="auth-illustration" /> -->
            </div>
            <!-- /Left Section -->
            <!-- Login -->
            <!-- /Login -->
        </div>
    </div>
    <input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_login_alert" id="alertpopup">
    <div class="modal fade" id="kt_modal_login_alert" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <div class="modal-dialog modal-md">
            <div class="modal-content rounded border border-danger border-2">
                <div class="modal-body pt-10 pb-10 px-10 px-xl-10">
                    <div class="mb-8 d-flex justify-content-center align-items-center">
                        <img src="{{ asset('assets/phdizone_images/lockwithkey.png') }}" alt="avatar"
                            class="rounded-circle img-fluid" style="width: 145px; height: 150px; object-fit: fit;">
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-12 mb-6">
                            <div class="d-flex flex-column align-items-center justify-content-center gap-2">
                                <label class="text-danger mb-1 fs-4 fw-semibold">
                                    Authentication Blocked
                                </label>
                                <label class="text-black mb-1 fs-6 fw-semibold">
                                    Enter Code
                                </label>
                                <input type="hidden" id="user_id_authentication" name="user_id_authentication">
                                <div class="row otp-inputs">
                                    @for ($i = 1; $i <= 6; $i++)
                                        <div class="col-lg-2">
                                            <input type="text" class="form-control text-center otp" maxlength="1"
                                                autocomplete="off" id="otp{{ $i }}" />
                                        </div>
                                    @endfor
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="alert alert-danger fw-semibold text-center" role="alert">
                                The task timer was not stopped. Please coordinate with <b>Business Head</b> to obtain the
                                required code to continue.
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center">
                        <button type="button" class="btn btn-primary" id="verify_otp_btn">Verify</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        .toast {
            background-color: #39484f;
        }

        .toast-success {
            background-color: green;
        }

        .toast-error {
            background-color: red;
        }

        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }

        .otp-inputs input {
            font-size: 1.5rem;
            font-weight: bold;
            height: 60px;
            border: 2px solid #e4e6ef;
            transition: all 0.3s ease;
        }

        .otp-inputs input:focus {
            border-color: #009ef7;
            box-shadow: 0 0 0 3px rgba(0, 158, 247, 0.1);
            outline: none;
        }

        .otp-inputs input.filled {
            border-color: #50cd89;
            background-color: rgba(80, 205, 137, 0.05);
        }
    </style>

    <script type="text/javascript">
        // Add paste functionality for OTP
        $('.otp-inputs').on('paste', function(e) {
            e.preventDefault();
            var pasteData = e.originalEvent.clipboardData.getData('text').trim();

            if (pasteData.length === 6 && /^\d+$/.test(pasteData)) {
                for (var i = 0; i < 6; i++) {
                    $('#otp' + (i + 1)).val(pasteData[i]);
                }
                $('#otp6').focus();
            }
        });

        function LoginvalidateForm() {
            var uname = document.getElementById("user_name").value;
            var pwd = document.getElementById("password").value;

            if (uname !== '' && pwd !== '') {
                login_validation(); // Assuming this is a valid function
                return true; // Allow form submission
            } else {
                // Handle error (e.g., show a message)
                // document.getElementById('user_name_err').innerHTML = 'User Name is required...!';
                // document.getElementById('user_name').classList.add('error_msg');
                // document.getElementById('password_err').innerHTML = 'Password is required...!';
                // document.getElementById('password').classList.add('error_msg');
                return false; // Prevent form submission
            }
        }
    </script>
    <script>
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";

            // Show toastr message
            toastr[type](message);

            $(document).ready(function() {
                var authentication = "{{ Session::get('toastr')['authentication'] ?? '' }}";
                var user_id = "{{ Session::get('toastr')['user_id'] ?? '' }}";

                if (authentication == 1) {
                    $('#kt_modal_login_alert').modal({
                        backdrop: 'static',
                        keyboard: false
                    });
                    $('#kt_modal_login_alert').modal('show');
                    $('#user_id_authentication').val(user_id);
                } else {
                    $('#user_id_authentication').val('');
                }
            });
        @endif

        $(document).ready(function() {
            // Auto-focus on first OTP input when modal is shown
            $('#kt_modal_login_alert').on('shown.bs.modal', function() {
                $('.otp').val('');
                $('#otp1').focus();
            });

            // OTP input navigation and auto-focus
            $('.otp').on('input', function() {
                var currentIndex = $(this).attr('id').replace('otp', '');
                var value = $(this).val();

                if (value.length === 1 && currentIndex < 6) {
                    $('#otp' + (parseInt(currentIndex) + 1)).focus();
                }
            });

            // Handle backspace key
            $('.otp').on('keydown', function(e) {
                var currentIndex = parseInt($(this).attr('id').replace('otp', ''));

                if (e.key === 'Backspace' && $(this).val() === '' && currentIndex > 1) {
                    $('#otp' + (currentIndex - 1)).focus();
                }
            });

            // Verify OTP button click handler
            $('#verify_otp_btn').on('click', function() {
                verifyAuthenticationCode();
            });

            // Enter key press handler
            $('.otp').on('keypress', function(e) {
                if (e.which === 13) { // Enter key
                    verifyAuthenticationCode();
                }
            });

            function verifyAuthenticationCode() {
                // Collect OTP digits
                var otp = '';
                var isValid = true;

                for (var i = 1; i <= 6; i++) {
                    var digit = $('#otp' + i).val();
                    if (!digit) {
                        isValid = false;
                        break;
                    }
                    otp += digit;
                }

                // Check if all digits were entered
                if (!isValid) {
                    toastr.error('Please enter all 6 character of the authentication code');
                    $('#otp1').focus();
                    return;
                }

                var userId = $('#user_id_authentication').val();

                // Check if user ID is missing
                if (!userId) {
                    toastr.error('User ID is missing');
                    return;
                }


                // Show loading state
                var verifyBtn = $('#verify_otp_btn');
                var originalText = verifyBtn.text();
                verifyBtn.prop('disabled', true).text('Verifying...');

                // AJAX request
                $.ajax({
                    url: '{{ route('verify.auth.code') }}',
                    type: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        user_id: userId,
                        otp_code: otp
                    },
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);

                            // Hide modal
                            $('#kt_modal_login_alert').modal('hide');

                            // Clear OTP inputs
                            $('.otp').val('');

                            // Redirect after a short delay
                            if (response.redirect) {
                                setTimeout(function() {
                                    window.location.href = response.redirect;
                                }, 1000);
                            } else {
                                // Default redirect to dashboard
                                setTimeout(function() {
                                    window.location.href = '{{ route('dashboards') }}';
                                }, 1000);
                            }
                        } else {
                            toastr.error(response.message);
                            // Clear OTP inputs on failure
                            $('.otp').val('');
                            $('#otp1').focus();

                            // If error is about permissions, redirect
                            if (response.redirect && response.message.includes('permissions')) {
                                setTimeout(function() {
                                    window.location.href = response.redirect;
                                }, 2000);
                            }
                        }
                    },
                    error: function(xhr) {
                        var errorMsg = 'Verification failed. Please try again.';
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            errorMsg = xhr.responseJSON.message;
                        }
                        toastr.error(errorMsg);

                        // Clear OTP inputs on error
                        $('.otp').val('');
                        $('#otp1').focus();
                    },
                    complete: function() {
                        // Reset button state
                        verifyBtn.prop('disabled', false).text(originalText);
                    }
                });
            }

            // Modal hidden event
            $('#kt_modal_login_alert').on('hidden.bs.modal', function() {
                $('.otp').val('');
            });

            // Add paste functionality for OTP
            $('.otp-inputs').on('paste', function(e) {
                e.preventDefault();
                var pasteData = e.originalEvent.clipboardData.getData('text').trim();

                if (pasteData.length === 6 && /^\d{6}$/.test(pasteData)) {
                    for (var i = 0; i < 6; i++) {
                        $('#otp' + (i + 1)).val(pasteData[i]);
                    }
                    $('#otp6').focus();
                } else {
                    toastr.warning('Please paste exactly 6 digits');
                }
            });
        });


        function LoginvalidateForm() {
            var err = 0;
            var user_name = document.getElementById("user_name").value.trim();
            if (user_name === "") {
                document.getElementById('user_name_err').innerHTML = 'User Name is required...!';
                document.getElementById('user_name').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('user_name').classList.remove('error_msg');
                document.getElementById('user_name_err').innerHTML = '';
            }
            var password = document.getElementById("password").value.trim();
            if (password === "") {
                document.getElementById('password_err').innerHTML = 'Password is required...!';
                document.getElementById('password').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('password').classList.remove('error_msg');
                document.getElementById('password_err').innerHTML = '';
            }
            if (err === 0) {
                showLoadingScreen();
                return true;
            }
            return false;
        }

        document.getElementById('user_name').addEventListener('input', function() {
            document.getElementById('user_name_err').innerHTML = '';
            this.classList.remove('error_msg');
        });

        document.getElementById('password').addEventListener('input', function() {
            document.getElementById('password_err').innerHTML = '';
            this.classList.remove('error_msg');
        });

        function showLoadingScreen() {
            document.getElementById('loadingScreen').style.display = 'block';
        }
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const inputs = document.querySelectorAll('.otp');

            inputs.forEach((input, index) => {

                // Allow A-Z and 0-9 only, auto CAPS, auto move
                input.addEventListener('input', () => {
                    input.value = input.value
                        .replace(/[^a-zA-Z0-9]/g, '')
                        .toUpperCase();

                    if (input.value && index < inputs.length - 1) {
                        inputs[index + 1].focus();
                    }
                });

                // Backspace → previous
                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Backspace' && !input.value && index > 0) {
                        inputs[index - 1].focus();
                    }
                });

                // Paste full code (A-Z / 0-9)
                input.addEventListener('paste', (e) => {
                    const paste = e.clipboardData
                        .getData('text')
                        .replace(/[^a-zA-Z0-9]/g, '')
                        .toUpperCase();

                    paste.split('').forEach((char, i) => {
                        if (inputs[i]) inputs[i].value = char;
                    });

                    e.preventDefault();
                });

            });
        });
    </script>
@endsection
