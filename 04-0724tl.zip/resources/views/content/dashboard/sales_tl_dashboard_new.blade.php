@php
    $configData = Helper::appClasses();
@endphp
@extends('layouts/layoutMaster')

@section('title', 'Sales Team Lead Dashboard')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

<style>
    .fade-in-onload {
        animation: fadeInUp 0.8s ease-out forwards;
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(52px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .loading-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(255, 255, 255, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
        border-radius: 0.5rem;
    }
</style>

@section('content')
    <style>
        .fade-in-onload {
            animation: fadeInUp 0.8s ease-out forwards;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(52px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .loading-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            border-radius: 0.5rem;
        }

        .scroll-y {
            overflow-y: auto;
            max-height: 150px;
        }
    </style>

    <div class="row">
        <div class="col-lg-12">
            <div class="nav-align-top mb-5">
                <ul class="nav nav-pills d-d-flex justify-content-between" role="tablist">
                    <div class="d-flex align-items-center gap-2">
                        <div class="item">
                            <li class="nav-item rounded" style="border: 1px solid #099dda;">
                                <button type="button" id="tab-self-btn" class="nav-link text-capitalize active"
                                    role="tab" data-bs-toggle="tab" data-bs-target="#tab_my_self"
                                    aria-controls="tab_my_self" aria-selected="false">My Self</button>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item rounded" style="border: 1px solid #099dda;">
                                <button type="button" id="tab-team-btn" class="nav-link text-capitalize" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#tab_my_team" aria-controls="tab_my_team"
                                    aria-selected="false">My Team</button>
                            </li>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-end mb-1 gap-2">
                        <div class="w-75 mb-1">
                            <div class="cursor-pointer input-group input-group-merge">
                                <span class="input-group-text bg-label-warning text-black"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="dateFilter"
                                    class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class"
                                    value="<?php echo date('M-Y'); ?>" readonly>
                                <span class="input-group-text bg-label-warning text-black"><i
                                        class="mdi mdi-menu-down fs-4"></i></span>
                            </div>
                        </div>
                    </div>
                </ul>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="tab-content p-0">
                <!-- Self Dashboard Tab -->
                <div class="tab-pane fade show active" id="tab_my_self" role="tabpanel">
                    <div id="self-dashboard-container" class="position-relative">
                        <div id="self-loading" class="loading-overlay d-none">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </div>
                        <div id="self-dashboard-content" class="row g-3">
                            <!-- Today's Metrics -->
                            <div class="col-lg-6 fade-in-onload">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row g-3 ">
                                            <div class="col-lg-6">
                                                <div class="card rounded  shadow-lg">
                                                    <div class="card-body d-flex flex-column ">
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-end justify-content-between">
                                                            <div class="d-flex  align-items-center justify-content-center rounded-circle"
                                                                style="width:42px; height:42px; background:#d2f8fd;">
                                                                <i class="mdi mdi-account-group fs-3"
                                                                    style="color:#1babc4; font-size:20px;"></i>
                                                            </div>
                                                            <label class="text-black fw-semibold fs-1"
                                                                id="self-total-lead-this-month">0</label>
                                                        </div>
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                                                            <label class="fs-8 text-danger fw-semibold"
                                                                id="self-total-lead-last-month">0 Last Month</label>
                                                            <label class="text-secondary fw-semibold fs-7 "> Total
                                                                Leads</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded  shadow-lg">
                                                    <div class="card-body d-flex flex-column ">
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-end justify-content-between">
                                                            <div class="d-flex  align-items-center justify-content-center rounded-circle"
                                                                style="width:42px; height:42px; background:#d2f8fd;">
                                                                <i class="mdi mdi-account-star fs-3"
                                                                    style="color:#1babc4; font-size:20px;"></i>
                                                            </div>
                                                            <label class="text-black fw-semibold fs-1 m-0 p-0"
                                                                id="self-active-lead-this-month">0</label>
                                                        </div>
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                                                            <label class="fs-8 text-danger fw-semibold"
                                                                id="self-active-lead-last-month">0 Last Month</label>
                                                            <label class="text-secondary fw-semibold fs-7 "> Active
                                                                Leads</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded  shadow-lg">
                                                    <div class="card-body d-flex flex-column ">
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-end justify-content-between">
                                                            <div class="d-flex  align-items-center justify-content-center rounded-circle"
                                                                style="width:42px; height:42px; background:#d2f8fd;">
                                                                <i class="mdi mdi-account-cancel fs-3"
                                                                    style="color:#1babc4; font-size:20px;"></i>
                                                            </div>
                                                            <label class="text-black fw-semibold fs-1 m-0 p-0"
                                                                id="self-spam-lead-this-month">0</label>
                                                        </div>
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                                                            <label class="fs-8 text-danger fw-semibold"
                                                                id="self-spam-lead-last-month">11 Last Month</label>
                                                            <label class="text-secondary fw-semibold fs-7 "> Spam
                                                                Leads</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded  shadow-lg">
                                                    <div class="card-body d-flex flex-column ">
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-end justify-content-between">
                                                            <div class="d-flex  align-items-center justify-content-center rounded-circle"
                                                                style="width:42px; height:42px; background:#d2f8fd;">
                                                                <i class="mdi mdi-account-off fs-3"
                                                                    style="color:#1babc4; font-size:20px;"></i>
                                                            </div>
                                                            <label class="text-black fw-semibold fs-1 m-0 p-0"
                                                                id="self-dead-lead-this-month">0</label>
                                                        </div>
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                                                            <label class="fs-8 text-danger fw-semibold"
                                                                id="self-dead-lead-last-month">0 Last Month</label>
                                                            <label class="text-secondary fw-semibold fs-7 "> Dead
                                                                Leads</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Monthly Metrics -->
                            <div class="col-lg-6 fade-in-onload">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row g-3">
                                            <div class="col-lg-6">
                                                <div class="card rounded shadow-lg" style="background: #002855;">
                                                    <div
                                                        class="card-body d-flex align-items-center justify-content-center">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label id="self-conversion-month"
                                                                class="fw-semibold fs-1 text-white">0</label>
                                                            <label class="text-white fw-semibold fs-7">Conversion This
                                                                Month</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded shadow-lg" style="background: #002855;">
                                                    <div
                                                        class="card-body d-flex align-items-center justify-content-center">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label id="self-conversion-rate-month"
                                                                class="fw-semibold fs-1 text-white">0%</label>
                                                            <label class="text-white fw-semibold fs-7">Conversion Rate This
                                                                Month</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded shadow-lg" style="background: #002855;">
                                                    <div
                                                        class="card-body d-flex align-items-center justify-content-center">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label id="self-avg-business-month"
                                                                class="fw-semibold fs-1 text-white">₹ 0</label>
                                                            <label class="text-white fw-semibold fs-7">Avg Business Value
                                                                This Month</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded shadow-lg" style="background: #002855;">
                                                    <div
                                                        class="card-body d-flex align-items-center justify-content-center">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label id="self-avg-collection-month"
                                                                class="fw-semibold fs-1 text-white">₹ 0</label>
                                                            <label class="text-white fw-semibold fs-7">Avg Collection Value
                                                                This Month</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 fade-in-onload">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="card rounded  border border-secondary " style="box-shadow: 5px 5px;">
                                            <div class="card-body">
                                                <div class="d-flex flex-column">
                                                    <div class="d-flex flex-column align-items-center">
                                                        <label class="text-secondary fw-semibold fs-7 text-center">On
                                                            Day</label>
                                                        <label class="text-black fw-semibold fs-1"
                                                            id="self-one-day-conversion">0</label>
                                                        <label
                                                            class="text-secondary fw-semibold fs-7 text-center">Conversion</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="card rounded  border border-secondary" style="box-shadow: 5px 5px;">
                                            <div class="card-body">
                                                <div class="d-flex flex-column">
                                                    <div class="d-flex flex-column align-items-center">
                                                        <label class="text-secondary fw-semibold fs-7 text-center">On
                                                            Month</label>
                                                        <label class="text-black fw-semibold fs-1"
                                                            id="self-on-month-conversion">0</label>
                                                        <label
                                                            class="text-secondary fw-semibold fs-7 text-center">Conversion</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="card rounded  border border-secondary" style="box-shadow: 5px 5px;">
                                            <div class="card-body">
                                                <div class="d-flex flex-column">
                                                    <div class="d-flex flex-column align-items-center">
                                                        <label class="text-secondary fw-semibold fs-7 text-center">Old
                                                            Lead</label>
                                                        <label class="text-black fw-semibold fs-1"
                                                            id="self-old-month-conversion">0</label>
                                                        <label
                                                            class="text-secondary fw-semibold fs-7 text-center">Conversion</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Conversion Types -->
                            <div class="col-lg-6 fade-in-onload">
                                <div class="card rounded  shadow-lg " style="background: #002855;">
                                    <div class="card-body">
                                        <div class="row ">
                                            <div class="col-lg-3">
                                                <div class="row">
                                                    <div class="col-lg-12 text-end">
                                                        <label class="fs-8 text-danger fw-semibold"
                                                            id="self-last-month-appointments">0 Last Month</label>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label class=" fw-semibold fs-1 text-white"
                                                                id="self-this-month-appointments">0</label>
                                                            <label class="text-white fw-semibold fs-7">Appointments</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="row">
                                                    <div class="col-lg-12 text-end">
                                                        <label class="fs-8 text-danger fw-semibold"
                                                            id="self-last-month-walkin-change">0 Last Month</label>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label class=" fw-semibold fs-1 text-white"
                                                                id="self-this-month-walkin-change">0</label>
                                                            <label class="text-white fw-semibold fs-7">Walk - In</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="row">
                                                    <div class="col-lg-12 text-end">
                                                        <label class="fs-8 text-danger fw-semibold"
                                                            id="self-last-month-followups">0 Last Month</label>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label class=" fw-semibold fs-1 text-white"
                                                                id="self-this-month-followups">0</label>
                                                            <label class="text-white fw-semibold fs-7">Followups</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="row">
                                                    <div class="col-lg-12 text-end">
                                                        <label class="fs-8 text-danger fw-semibold"
                                                            id="self-last-month-outgoing">0 Last Month</label>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label class=" fw-semibold fs-1 text-white"
                                                                id="self-this-month-outgoing">0</label>
                                                            <label class="text-white fw-semibold fs-7">Outgoing
                                                                Call</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Schedules -->
                            <div class="col-lg-4 fade-in-onload">
                                <div class="card rounded shadow-lg" style="height: 250px">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <label class="fw-semibold">Followup Schedule <label class="ms-3">(
                                                            <span class="text-success">{{ date('d-M-Y') }}</span>
                                                            )</label></label>
                                                    <label id="self-followup-count" class="fw-semibold badge text-white"
                                                        style="background: black">0</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <hr>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="row scroll-y" id="self-followup-container">
                                                    <!-- Dynamic content will be loaded here -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 fade-in-onload">
                                <div class="card rounded shadow-lg" style="height: 250px">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div class="fw-semibold">Appointment Schedule <label class="ms-3">(
                                                            <span class="text-success">{{ date('d-M-Y') }}</span> )</label>
                                                    </div>
                                                    <label id="self-appointment-count"
                                                        class="fw-semibold badge text-white"
                                                        style="background: black">0</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <hr>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="row scroll-y" id="self-appointment-container">
                                                    <!-- Dynamic content will be loaded here -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 fade-in-onload">
                                <div class="card rounded shadow-lg" style="height: 250px">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <label class="fw-semibold">Low MPC Paid</label>
                                                    <label id="self-mpc-count" class="fw-semibold badge text-white"
                                                        style="background: black">0</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <hr>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="row scroll-y" id="self-low-mpc-container">
                                                    <!-- Dynamic content will be loaded here -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Team Dashboard Tab -->
                <div class="tab-pane fade" id="tab_my_team" role="tabpanel">
                    <div id="team-dashboard-container" class="position-relative">
                        <div id="team-loading" class="loading-overlay d-none">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </div>
                        <div id="team-dashboard-content" class="row g-3">
                            <!-- Team Today's Metrics -->
                            <div class="col-lg-6 fade-in-onload">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row g-3">
                                            <div class="col-lg-6">
                                                <div class="card rounded  shadow-lg">
                                                    <div class="card-body d-flex flex-column ">
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-end justify-content-between">
                                                            <div class="d-flex  align-items-center justify-content-center rounded-circle"
                                                                style="width:42px; height:42px; background:#d2f8fd;">
                                                                <i class="mdi mdi-account-group fs-3"
                                                                    style="color:#1babc4; font-size:20px;"></i>
                                                            </div>
                                                            <label class="text-black fw-semibold fs-1"
                                                                id="team-total-lead-this-month">0</label>
                                                        </div>
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                                                            <label class="fs-8 text-danger fw-semibold"
                                                                id="team-total-lead-last-month">0 Last Month</label>
                                                            <label class="text-secondary fw-semibold fs-7 "> Total
                                                                Leads</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded  shadow-lg">
                                                    <div class="card-body d-flex flex-column ">
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-end justify-content-between">
                                                            <div class="d-flex  align-items-center justify-content-center rounded-circle"
                                                                style="width:42px; height:42px; background:#d2f8fd;">
                                                                <i class="mdi mdi-account-star fs-3"
                                                                    style="color:#1babc4; font-size:20px;"></i>
                                                            </div>
                                                            <label class="text-black fw-semibold fs-1 m-0 p-0"
                                                                id="team-active-lead-this-month">0</label>
                                                        </div>
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                                                            <label class="fs-8 text-danger fw-semibold"
                                                                id="team-active-lead-last-month">0 Last Month</label>
                                                            <label class="text-secondary fw-semibold fs-7 "> Active
                                                                Leads</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded  shadow-lg">
                                                    <div class="card-body d-flex flex-column ">
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-end justify-content-between">
                                                            <div class="d-flex  align-items-center justify-content-center rounded-circle"
                                                                style="width:42px; height:42px; background:#d2f8fd;">
                                                                <i class="mdi mdi-account-cancel fs-3"
                                                                    style="color:#1babc4; font-size:20px;"></i>
                                                            </div>
                                                            <label class="text-black fw-semibold fs-1 m-0 p-0"
                                                                id="team-spam-lead-this-month">0</label>
                                                        </div>
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                                                            <label class="fs-8 text-danger fw-semibold"
                                                                id="team-spam-lead-last-month">11 Last Month</label>
                                                            <label class="text-secondary fw-semibold fs-7 "> Spam
                                                                Leads</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded  shadow-lg">
                                                    <div class="card-body d-flex flex-column ">
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-end justify-content-between">
                                                            <div class="d-flex  align-items-center justify-content-center rounded-circle"
                                                                style="width:42px; height:42px; background:#d2f8fd;">
                                                                <i class="mdi mdi-account-off fs-3"
                                                                    style="color:#1babc4; font-size:20px;"></i>
                                                            </div>
                                                            <label class="text-black fw-semibold fs-1 m-0 p-0"
                                                                id="team-dead-lead-this-month">0</label>
                                                        </div>
                                                        <div
                                                            class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                                                            <label class="fs-8 text-danger fw-semibold"
                                                                id="team-dead-lead-last-month">0 Last Month</label>
                                                            <label class="text-secondary fw-semibold fs-7 "> Dead
                                                                Leads</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Team Monthly Metrics -->
                            <div class="col-lg-6 fade-in-onload">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row g-3">
                                            <div class="col-lg-6">
                                                <div class="card rounded shadow-lg" style="background: #002855;">
                                                    <div
                                                        class="card-body d-flex align-items-center justify-content-center">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label id="team-conversion-month"
                                                                class="fw-semibold fs-1 text-white">0</label>
                                                            <label class="text-white fw-semibold fs-7">Conversion This
                                                                Month</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded shadow-lg" style="background: #002855;">
                                                    <div
                                                        class="card-body d-flex align-items-center justify-content-center">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label id="team-conversion-rate-month"
                                                                class="fw-semibold fs-1 text-white">0%</label>
                                                            <label class="text-white fw-semibold fs-7">Conversion Rate This
                                                                Month</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded shadow-lg" style="background: #002855;">
                                                    <div
                                                        class="card-body d-flex align-items-center justify-content-center">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label id="team-avg-business-month"
                                                                class="fw-semibold fs-1 text-white">₹ 0</label>
                                                            <label class="text-white fw-semibold fs-7">Avg Business Value
                                                                This Month</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="card rounded shadow-lg" style="background: #002855;">
                                                    <div
                                                        class="card-body d-flex align-items-center justify-content-center">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <label id="team-avg-collection-month"
                                                                class="fw-semibold fs-1 text-white">₹ 0</label>
                                                            <label class="text-white fw-semibold fs-7">Avg Collection Value
                                                                This Month</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Team Members Sales Table -->
                            <div class="col-lg-12 fade-in-onload">
                                <div class="card rounded shadow-lg">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-12 mb-3">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <label class="fw-semibold">Team Members Monthly Sales Reports <span
                                                            id="team-sales-month"
                                                            class="text-info ms-1"><?php echo date('M-Y'); ?></span></label>
                                                    <label id="team-members-count" class="fw-semibold badge text-white"
                                                        style="background: black">0</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table
                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                <th class="min-w-200px">Members</th>
                                                                <th class="min-w-200px text-center">Active Leads</th>
                                                                <th class="min-w-100px text-center">Conversion</th>
                                                                <th class="min-w-150px text-center">Conversion Rate</th>
                                                                <th class="min-w-100px text-center"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Average Business Value">ABV</th>
                                                                <th class="min-w-100px text-center"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Average Collection Value">ACV</th>
                                                                <th class="min-w-100px text-center">Walk-In</th>
                                                                <th class="min-w-100px text-center"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Average Outgoing Call Rate">AOCR</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="team-members-sales-tbody"
                                                            class="text-black fw-semibold fs-7">
                                                            <!-- Dynamic content will be loaded here -->
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Team Lead Reports Table -->
                            <div class="col-lg-12 fade-in-onload">
                                <div class="card rounded shadow-lg">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-12 mb-3">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <label class="fw-semibold">Team Members Monthly Lead Reports
                                                        <span id="team-lead-month"
                                                            class="text-info ms-1"><?php echo date('M-Y'); ?></span>
                                                    </label>
                                                    <label id="team-lead-count" class="fw-semibold badge text-white"
                                                        style="background: black">0</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table
                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                <th class="min-w-200px">Members</th>
                                                                <th class="min-w-200px text-center text-nowrap">Total Leads
                                                                </th>
                                                                <th class="min-w-100px text-center text-nowrap">Active Lead
                                                                </th>
                                                                <th class="min-w-150px text-center text-nowrap">Spam Lead
                                                                </th>
                                                                <th class="min-w-100px text-center text-nowrap">Dead Lead
                                                                </th>
                                                                <th class="min-w-100px text-center text-nowrap"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Converted Customers">Convt. Cust</th>
                                                                <th class="min-w-100px text-center"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="One Day Conversion">ODC</th>
                                                                <th class="min-w-100px text-center"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="On Month Conversion">MC</th>
                                                                <th class="min-w-100px text-center"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Old Month Conversion">OMC</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="team-lead-reports-tbody"
                                                            class="text-black fw-semibold fs-7">
                                                            <!-- Dynamic content will be loaded here -->
                                                        </tbody>
                                                        <tfoot>
                                                            <tr id="team-lead-total-row">
                                                                <!-- Dynamic total row will be loaded here -->
                                                            </tr>
                                                        </tfoot>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Team Schedules -->
                            <div class="col-lg-4 fade-in-onload">
                                <div class="card rounded shadow-lg" style="height: 250px">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div class="fw-semibold">Followup Schedule <label class="ms-3">(
                                                            <span class="text-success">{{ date('d-M-Y') }}</span> )</label>
                                                    </div>
                                                    <label id="team-followup-count" class="fw-semibold badge text-white"
                                                        style="background: black">0</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <hr>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="row scroll-y" id="team-followup-container">
                                                    <!-- Dynamic content will be loaded here -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 fade-in-onload">
                                <div class="card rounded shadow-lg" style="height: 250px">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div class="fw-semibold">Appointment Schedule <label class="ms-3">(
                                                            <span class="text-success">{{ date('d-M-Y') }}</span> )</label>
                                                    </div>
                                                    <label id="team-appointment-count"
                                                        class="fw-semibold badge text-white"
                                                        style="background: black">0</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <hr>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="row scroll-y" id="team-appointment-container">
                                                    <!-- Dynamic content will be loaded here -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 fade-in-onload">
                                <div class="card rounded shadow-lg" style="height: 250px">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <label class="fw-semibold">Low MPC Paid </label>
                                                    <label id="team-mpc-count" class="fw-semibold badge text-white"
                                                        style="background: black">0</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <hr>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="row scroll-y" id="team-low-mpc-container">
                                                    <!-- Dynamic content will be loaded here -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize date picker
        $('#dateFilter').datepicker({
            format: "mm-yyyy",
            startView: "months",
            minViewMode: "months",
            autoclose: true,
            todayHighlight: true
        }).on('changeMonth', function(e) {
            const month = e.date.getMonth() + 1;
            const year = e.date.getFullYear();
            const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct',
                'Nov', 'Dec'
            ];
            const formattedDate = `${monthNames[month-1]}-${year}`;
            const activeTab = $('.tab-pane.fade.show.active').attr('id');

            // Update date filter value
            $('#dateFilter').val(formattedDate);

            if (activeTab === 'tab_my_self') {
                loadSelfDashboard(formattedDate);
            } else if (activeTab === 'tab_my_team') {
                loadTeamDashboard(formattedDate);
            }
        });

        // Tab change event
        $('button[data-bs-toggle="tab"]').on('shown.bs.tab', function(e) {
            const target = $(e.target).attr('data-bs-target');
            const dateFilter = $('#dateFilter').val();
            const date = dateFilter;

            if (target === '#tab_my_self') {
                loadSelfDashboard(date);
            } else if (target === '#tab_my_team') {
                loadTeamDashboard(date);
            }
        });

        // Load initial self dashboard data
        loadSelfDashboard();

        // Initialize tooltips
        initializeTooltips();
    });

    // Convert display date (Mar-2025) to API date (03-2025)
    function convertDisplayDateToApiDate(displayDate) {
        if (!displayDate) return null;

        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const parts = displayDate.split('-');
        const monthName = parts[0];
        const year = parts[1];
        const monthIndex = monthNames.findIndex(m => m.toLowerCase() === monthName.toLowerCase()) + 1;

        return `${monthIndex.toString().padStart(2, '0')}-${year}`;
    }

    // Format date for display (03-2025 to Mar-2025)
    function formatDateForDisplay(dateStr) {
        if (!dateStr) return '';
        const parts = dateStr.split('-');
        if (parts.length !== 2) return dateStr;

        const month = parseInt(parts[0]);
        const year = parts[1];
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

        return `${monthNames[month-1]}-${year}`;
    }

    // Load Self Dashboard
    // Load Self Dashboard - UPDATED VERSION
    async function loadSelfDashboard(date = null) {
        const loadingEl = document.getElementById('self-loading');
        const dateFilter = document.getElementById('dateFilter');

        // Get date for API
        let apiDate = date;
        if (!apiDate) {
            const displayDate = dateFilter ? dateFilter.value : '<?php echo date('M-Y'); ?>';
            apiDate = displayDate;
        }

        // Show loading
        if (loadingEl) loadingEl.classList.remove('d-none');

        try {

            const apiDateFormatted = convertDisplayDateToApiDate(apiDate);

            const params = new URLSearchParams({
                date_filter: apiDate
            });

            const response = await fetch(
                `/dashboard/sales_tl_self_executive?${params.toString()}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json'
                    }
                }
            );

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            console.log('API Response:', result); // Debug log

            // Check if we have the expected structure
            if (result.data) {
                updateSelfDashboard(result.data);
            } else if (result.success) {
                // If response doesn't have data property but has success
                updateSelfDashboard(result);
            } else {
                // If response has different structure (like your example)
                updateSelfDashboard(result);
            }

        } catch (error) {
            console.error('Error loading self dashboard:', error);
            toastr.success('error', 'Failed to load dashboard data: ' + error.message);
        } finally {
            if (loadingEl) loadingEl.classList.add('d-none');
        }
    }
    // Update Self Dashboard with data
    function updateSelfDashboard(data) {
        console.log('Self dashboard data:', data); // Debug log

        // Today's metrics - using the actual field names from your response
        $('#self-total-lead-this-month').html(data.total_leads || 0);
        $('#self-total-lead-last-month').html(`${data.total_leads_prev ||0} Last Month`);

        $('#self-active-lead-this-month').html(data.active_leads || 0);
        $('#self-active-lead-last-month').html(`${data.active_leads_prev ||0} Last Month`);

        $('#self-spam-lead-this-month').html(data.spam_leads || 0);
        $('#self-spam-lead-last-month').html(`${data.spam_leads_prev ||0} Last Month`);

        $('#self-dead-lead-this-month').html(data.dead_leads || 0);
        $('#self-dead-lead-last-month').html(`${data.dead_leads_prev ||0} Last Month`);

        // Monthly metrics - using staff target data
        const staffTarget = data.StaffTarget || {};
        updateElementText('self-conversion-month', staffTarget.conversion_actual || 0);
        updateElementText('self-conversion-rate-month', `${staffTarget.CR_actual || "0.00"}%`);
        updateElementText('self-avg-business-month', `₹ ${formatNumber(staffTarget.ABV_actual || 0)}`);
        updateElementText('self-avg-collection-month', `₹ ${formatNumber(staffTarget.ACV_actual || 0)}`);

        // Today Status - using avg fields
        $('#self-this-month-appointments').html(data.appointmentsToday || 0);
        $('#self-last-month-appointments').html(`${data.appointmentsYesterday ||0} Last Month`);
        $('#self-this-month-walkin-change').html(data.monthwalkincount || 0);
        $('#self-last-month-walkin-change').html(`${data.Premonthwalkincount ||0} Last Month`);
        $('#self-this-month-followups').html(data.monthFollowupCount || 0);
        $('#self-last-month-followups').html(`${data.PremonthFollowupCount ||0} Last Month`);
        $('#self-this-month-outgoing').html(data.monthcall_out.outgoing_call_count || 0);
        $('#self-last-month-outgoing').html(`${data.Premonthcall_out ||0} Last Month`);

        // Conversion Types
        updateElementText('self-on-month-conversion', data.mc_count || 0);
        updateElementText('self-old-month-conversion', data.omc_count || 0);
        updateElementText('self-one-day-conversion', data.odc_count || 0);

        // Followup Schedule
        if (data.followup_schedule && Array.isArray(data.followup_schedule)) {
            updateFollowupSchedule(data.followup_schedule, 'self-followup-container');
        } else {
            updateFollowupSchedule([], 'self-followup-container');
        }

        // Appointment Schedule
        if (data.appointment_schedule && Array.isArray(data.appointment_schedule)) {
            updateAppointmentSchedule(data.appointment_schedule, 'self-appointment-container');
        } else {
            updateAppointmentSchedule([], 'self-appointment-container');
        }

        // Low MPC
        if (data.low_mpc_list && typeof data.low_mpc_list === 'object') {
            updateLowMpc(data.low_mpc_list, 'self-low-mpc-container');
        } else {
            updateLowMpc({}, 'self-low-mpc-container');
        }


        // console.log('low_mpc_list', data.low_mpc_list)

        // Update count badges

        // Initialize tooltips after data load
        setTimeout(() => initializeTooltips(), 100);
    }

    // Load Team Dashboard
    async function loadTeamDashboard(date = null) {
        const loadingEl = document.getElementById('team-loading');
        const dateFilter = document.getElementById('dateFilter');

        // Get display date
        let displayDate = date || dateFilter?.value || '<?php echo date('M-Y'); ?>';

        // Get date for API
        let apiDate = date;
        if (!apiDate) {
            const displayDate = dateFilter ? dateFilter.value : '<?php echo date('M-Y'); ?>';
            apiDate = displayDate;
        }

        if (loadingEl) loadingEl.classList.remove('d-none');

        try {

            const params = new URLSearchParams({
                date_filter: apiDate
            });

            const response = await fetch(
                `/dashboard/sales_tl_team_executive?${params.toString()}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json'
                    }
                }
            );

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();

            // Use result directly if there's no 'success' key
            const dashboardData = result.data ?? result;

            if (dashboardData && typeof dashboardData === 'object') {
                updateTeamDashboard(dashboardData);
            } else {
                throw new Error('Invalid dashboard response');
            }

        } catch (error) {
            console.error('Team dashboard error:', error);
            toastr.success('error', 'Failed to load team dashboard data');
        } finally {
            if (loadingEl) loadingEl.classList.add('d-none');
        }
    }



    // Update Team Dashboard with data
    function updateTeamDashboard(data) {
        // Team Today metrics
        console.log('team dashboard data', data)
        $('#team-total-lead-this-month').html(data.total_leads || 0);
        $('#team-total-lead-last-month').html(`${data.total_leads_prev ||0} Last Month`);

        $('#team-active-lead-this-month').html(data.active_leads || 0);
        $('#team-active-lead-last-month').html(`${data.active_leads_prev ||0} Last Month`);

        $('#team-spam-lead-this-month').html(data.spam_leads || 0);
        $('#team-spam-lead-last-month').html(`${data.spam_leads_prev ||0} Last Month`);

        $('#team-dead-lead-this-month').html(data.dead_leads || 0);
        $('#team-dead-lead-last-month').html(`${data.dead_leads_prev ||0} Last Month`);


        // Monthly metrics - using staff target data
        const staffTargets = data.StaffTarget || {};
        updateElementText('team-conversion-month', staffTargets.conversion_actual || 0);
        updateElementText('team-conversion-rate-month', `${staffTargets.CR_actual || "0.00"}%`);
        updateElementText('team-avg-business-month', `₹ ${formatNumber(staffTargets.ABV_actual || 0)}`);
        updateElementText('team-avg-collection-month', `₹ ${formatNumber(staffTargets.ACV_actual || 0)}`);

        // Today Status - using avg fields
        $('#team-this-month-appointments').html(data.appointmentsToday || 0);
        $('#team-last-month-appointments').html(`${data.appointmentsYesterday ||0} Last Month`);
        $('#team-this-month-walkin-change').html(data.monthwalkincount || 0);
        $('#team-last-month-walkin-change').html(`${data.Premonthwalkincount ||0} Last Month`);
        $('#team-this-month-followups').html(data.monthFollowupCount || 0);
        $('#team-last-month-followups').html(`${data.PremonthFollowupCount ||0} Last Month`);
        $('#team-this-month-outgoing').html(data.monthcall_out || 0);
        $('#team-last-month-outgoing').html(`${data.Premonthcall_out ||0} Last Month`);


        // Followup Schedule
        if (data.followup_schedule && Array.isArray(data.followup_schedule)) {
            updateFollowupSchedule(data.followup_schedule, 'team-followup-container');
        } else {
            updateFollowupSchedule([], 'team-followup-container');
        }

        // Appointment Schedule
        if (data.appointment_schedule && Array.isArray(data.appointment_schedule)) {
            updateAppointmentSchedule(data.appointment_schedule, 'team-appointment-container');
        } else {
            updateAppointmentSchedule([], 'team-appointment-container');
        }

        // Low MPC
        if (data.low_mpc_list && typeof data.low_mpc_list === 'object') {
            updateLowMpc(data.low_mpc_list, 'team-low-mpc-container');
        } else {
            updateLowMpc({}, 'team-low-mpc-container');
        }

        // Update month labels
        if (data.selected_date) {
            const displayDate = formatDateForDisplay(data.selected_date);
            updateElementText('team-sales-month', displayDate);
            updateElementText('team-lead-month', displayDate);
        } else if (data.display_month) {
            updateElementText('team-sales-month', data.display_month);
            updateElementText('team-lead-month', data.display_month);
        }

        // Team Members Sales Data
        if (data.team_members && Array.isArray(data.team_members)) {
            updateTeamMembersTable(data.team_members);
        } else {
            updateTeamMembersTable([]);
        }

        // Team Lead Reports
        if (data.team_lead_reports && Array.isArray(data.team_lead_reports)) {
            updateTeamLeadReports(data.team_lead_reports);
        } else {
            updateTeamLeadReports([]);
        }

        // // Team Followup Schedule
        // if (data.team_followup_schedule && Array.isArray(data.team_followup_schedule)) {
        //     updateTeamFollowupSchedule(data.team_followup_schedule);
        // } else {
        //     updateTeamFollowupSchedule([]);
        // }

        // // Team Appointment Schedule
        // if (data.team_appointment_schedule && Array.isArray(data.team_appointment_schedule)) {
        //     updateTeamAppointmentSchedule(data.team_appointment_schedule);
        // } else {
        //     updateTeamAppointmentSchedule([]);
        // }

        // // Team Low MPC
        // if (data.team_low_mpc && Array.isArray(data.team_low_mpc)) {
        //     updateTeamLowMpc(data.team_low_mpc);
        // } else {
        //     updateTeamLowMpc([]);
        // }

        // Initialize tooltips after data load
        initializeTooltips();
    }

    // Helper functions
    function updateElementText(elementId, text) {
        const element = document.getElementById(elementId);
        if (element) element.textContent = text;
    }

    function formatNumber(num) {
        if (num === null || num === undefined) return '0';
        const numValue = typeof num === 'string' ? parseFloat(num) : num;
        return numValue.toLocaleString('en-IN', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 2
        });
    }

    function formatChange(change) {
        if (change === undefined || change === null || change === '') return '+0';

        // Handle string percentages like "2%"
        if (typeof change === 'string' && change.includes('%')) {
            return change;
        }

        // Handle numbers
        const num = parseFloat(change);
        if (isNaN(num)) return '+0';

        const sign = num >= 0 ? '+' : '';
        return `${sign}${num}`;
    }

    function formatNumber(num) {
        if (num === null || num === undefined) return '0';

        // Handle string numbers
        const numValue = typeof num === 'string' ? parseFloat(num) : num;

        if (isNaN(numValue)) return '0';

        return numValue.toLocaleString('en-IN', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 2
        });
    }

    // Update Followup Schedule for self dashboard
    function updateFollowupSchedule(Followups, containerId) {
        const container = document.getElementById(containerId);
        const countBadge = document.getElementById(containerId.replace('-container', '-count'));

        if (!container) return;

        let html = '';
        Followups.forEach(followup => {
            html += `
                    <div class="col-lg-12 mb-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex gap-2 align-items-center">
                               <div class="symbol symbol-35px me-2">                                    
                                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold"
                                        style="width:35px;height:35px;">
                                        ${followup.lead_name?.charAt(0).toUpperCase()}
                                    </div>                                                                
                                </div>
                                <div class="d-flex flex-column">
                                    <label class="fw-semibold fs-7 text-black">${followup.lead_name}</label>
                                    <div class="d-block text-info fw-semibold fs-8">${followup.lead_ai_id}</div>
                                    ${followup.display_status === 'Rescheduled' ? '<div class="d-block text-danger fw-semibold fs-8">Re-Scheduled</div>' : ''}
                                </div>
                            </div>
                           ${followup.appointment_date ? `
                                <div class="d-flex flex-column">
                                    <span class="badge bg-label-primary text-white">${followup.appointment_time || ''}</span>
                                    <label class="fw-semibold fs-8 text-danger">${followup.appointment_date}</label>
                                </div>
                            ` : `
                                <span class="badge bg-label-primary text-white">${followup.appointment_time}</span>
                            `}
                        </div>
                    </div>
                    <hr class="mb-2">
                `;
        });

        if (Followups.length === 0) {
            html = '<div class="col-lg-12 text-center text-muted py-3">No followups scheduled for today</div>';
        }

        container.innerHTML = html;
        // console.log(html);
        // Update count badge
        if (countBadge) {
            countBadge.textContent = Followups.length;
        }
    }

    // Update Appointment Schedule for self dashboard
    function updateAppointmentSchedule(Appointments, containerId) {
        const container = document.getElementById(containerId);
        const countBadge = document.getElementById(containerId.replace('-container', '-count'));
        if (!container) return;

        let html = '';
        Appointments.forEach(appointment => {
            html += `
                    <div class="col-lg-12 mb-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex gap-2 align-items-center">
                               <div class="symbol symbol-35px me-2">
                                    ${
                                        appointment.avatar
                                        ? `
                                                                    <img src="${appointment.avatar}"
                                                                        alt="user-avatar"
                                                                        class="rounded-circle w-35px h-35px object-fit-cover" />
                                                                `
                                        : `
                                                                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold"
                                                                        style="width:35px;height:35px;">
                                                                        ${appointment.lead_name?.charAt(0).toUpperCase()}
                                                                    </div>
                                                                `
                                    }
                                </div>
                                <div class="d-flex flex-column">
                                    <div class="fs-7 fw-semibold text-black mb-0 align-items-center text-truncate max-w-350px"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="${appointment.lead_name} - ${appointment.lead_ai_id}" >${appointment.lead_name} - ${appointment.lead_ai_id}</div>
                                    ${appointment.app_status === 'Rescheduled'
                                        ? '<div class="d-block text-danger fw-semibold fs-8">Re-Scheduled</div>'
                                        : ''
                                    }
                                    ${appointment.app_status === 'Completed'
                                        ? '<div class="d-block text-success fw-semibold fs-8">Re-Scheduled</div>'
                                        : ''
                                    }
                                    ${appointment.app_status === 'Scheduled'
                                        ? '<div class="d-block text-info fw-semibold fs-8">Scheduled</div>'
                                        : ''
                                    }
                                </div>
                            </div>
                            ${appointment.appointment_date ? `
                                <div class="d-flex flex-column">
                                    <span class="badge bg-label-primary text-white">${appointment.appointment_time || ''}</span>
                                    <label class="fw-semibold fs-8 text-danger">${appointment.appointment_date}</label>
                                </div>
                            ` : `
                                <span class="badge bg-label-primary text-white">${appointment.appointment_time || ''}</span>
                            `}
                        </div>
                    </div>
                    <hr class="mb-2">
                `;
        });

        if (Appointments.length === 0) {
            html = '<div class="col-lg-12 text-center text-muted py-3">No appointments scheduled for today</div>';
        }

        container.innerHTML = html;

        // Update count badge
        if (countBadge) {
            countBadge.textContent = Appointments.length;
        }
    }

    // Update Low MPC for self dashboard
    function updateLowMpc(items, containerId) {
        const container = document.getElementById(containerId);
        const countBadge = document.getElementById(containerId.replace('-container', '-count'));

        if (!container) return;

        let html = '';
        let entries = Object.entries(items); // 👈 KEY FIX

        entries.forEach(([key, mpc]) => {
            html += `
            <div class="col-lg-12 mb-2">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex gap-2 align-items-center">
                        <div class="symbol symbol-35px me-2">
                            <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold" style="width:35px;height:35px;">
                                ${(mpc.customer_name || 'U').charAt(0).toUpperCase()}
                            </div>
                        </div>
                        <div class="d-flex flex-column">
                            <label class="fw-semibold fs-7 text-black">
                                ${mpc.customer_name || 'Unknown'}
                            </label>
                            <label class="fw-semibold fs-8 text-secondary">
                                ${key}
                            </label>
                        </div>
                    </div>
                    <div class="d-flex flex-column align-items-end">
                        <label class="fw-semibold fs-8 text-danger">
                        ${formatCurrency(mpc.total_paid || 0)}
                        </label>
                        <span class="badge bg-label-danger fs-8 text-danger">
                            ${mpc.days_left || ''}
                        </span>
                    </div>
                </div>
            </div>
            <hr class="mb-2">
        `;
        });

        if (entries.length === 0) {
            html = '<div class="col-lg-12 text-center text-muted py-3">No low MPC payments</div>';
        }

        container.innerHTML = html;

        // Update count badge
        if (countBadge) {
            countBadge.textContent = entries.length;
        }
    }

    // Format currency
    function formatCurrency(amount) {
        if (typeof amount === 'number') {
            return '₹ ' + amount.toLocaleString('en-IN', {
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            });
        }
        return amount;
    }

    // Update Team Members Table
    function updateTeamMembersTable(members) {
        const tbody = document.getElementById('team-members-sales-tbody');
        const countBadge = document.getElementById('team-members-count');

        if (!tbody) return;

        let html = '';
        members.forEach(member => {
            html += `
                    <tr>
                        <td>
                            <div class="d-flex gap-2 align-items-center">
                                <img src="${member.avatar || '{{ asset('assets/phdizone_images/user_3.png') }}'}" 
                                    alt="avatar" class="rounded-circle img-fluid"
                                    style="width: 40px; height: 40px; object-fit: cover;">
                                <div class="d-flex flex-column">
                                    <label class="fw-semibold fs-7 text-black">${member.name || 'Unknown'}</label>
                                    <label class="fw-semibold fs-8 badge bg-label-info">${member.role || 'Staff'}</label>
                                </div>
                            </div>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">${member.active_leads || 0}</label>
                        </td>
                        <td align="center">
                            <span class="px-2 fw-semibold fs-6"
                                style="border-radius:4px; background:#f1f8e9; color:#33691e; border:1px solid #33691e;">
                                ${member.conversion || 0}
                            </span>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">${member.conversion_rate || 0}%</label>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">₹ ${formatNumber(member.avg_business_value || 0)}</label>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">₹ ${formatNumber(member.avg_collection_value || 0)}</label>
                        </td>
                        <td align="center">
                            <span class="px-2 fw-semibold fs-6"
                                style="border-radius:4px; background:#fff0e0; color:#e65100; border:1px solid #e65100;">
                                ${member.walk_in || 0}
                            </span>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">${member.outgoing_call_rate || 0}%</label>
                        </td>
                    </tr>
                `;
        });

        if (members.length === 0) {
            html = '<tr><td colspan="8" class="text-center text-muted py-3">No team members found</td></tr>';
        }

        tbody.innerHTML = html;

        // Update count badge
        if (countBadge) {
            countBadge.textContent = members.length;
        }
    }

    function updateTeamLeadReports(reports) {
        const tbody = document.getElementById('team-lead-reports-tbody');
        const countBadge = document.getElementById('team-lead-count');

        if (!tbody) return;

        let html = '';
        let totals = {
            total_leads: 0,
            active_leads: 0,
            spam_leads: 0,
            dead_leads: 0,
            converted_customers: 0,
            one_day_conversion: 0,
            on_month_conversion: 0,
            old_month_conversion: 0
        };

        reports.forEach(report => {
            // Update totals
            totals.total_leads += report.total_leads || 0;
            totals.active_leads += report.active_leads || 0;
            totals.spam_leads += report.spam_leads || 0;
            totals.dead_leads += report.dead_leads || 0;
            totals.converted_customers += report.converted_customers || 0;
            totals.one_day_conversion += report.one_day_conversion || 0;
            totals.on_month_conversion += report.on_month_conversion || 0;
            totals.old_month_conversion += report.old_month_conversion || 0;

            html += `
                    <tr>
                        <td>
                            <div class="d-flex gap-2 align-items-center">
                                <img src="${report.avatar || '{{ asset('assets/phdizone_images/user_3.png') }}'}" 
                                    alt="avatar" class="rounded-circle img-fluid"
                                    style="width: 40px; height: 40px; object-fit: cover;">
                                <div class="d-flex flex-column">
                                    <label class="fw-semibold fs-7 text-black">${report.name || 'Unknown'}</label>
                                    <label class="fw-semibold fs-8 badge bg-label-info">${report.role || 'Staff'}</label>
                                </div>
                            </div>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">${report.total_leads || 0}</label>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">${report.active_leads || 0}</label>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">${report.spam_leads || 0}</label>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">${report.dead_leads || 0}</label>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">${report.converted_customers || 0}</label>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">${report.one_day_conversion || 0}</label>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">${report.on_month_conversion || 0}</label>
                        </td>
                        <td align="center">
                            <label class="text-black fw-semibold fs-6">${report.old_month_conversion || 0}</label>
                        </td>
                    </tr>
                `;
        });

        if (reports.length === 0) {
            html = '<tr><td colspan="9" class="text-center text-muted py-3">No team lead reports available</td></tr>';
        }

        tbody.innerHTML = html;

        // Update totals row
        const totalRow = document.getElementById('team-lead-total-row');
        if (totalRow) {
            totalRow.innerHTML = `
                    <td align="center">
                        <label class="px-3 fw-semibold fs-6"
                            style="background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;">Total</label>
                    </td>
                    <td align="center">
                        <label class="px-3 fw-semibold fs-6"
                            style="background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;">${totals.total_leads}</label>
                    </td>
                    <td align="center">
                        <label class="px-3 fw-semibold fs-6"
                            style="background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;">${totals.active_leads}</label>
                    </td>
                    <td align="center">
                        <label class="px-3 fw-semibold fs-6"
                            style="background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;">${totals.spam_leads}</label>
                    </td>
                    <td align="center">
                        <label class="px-3 fw-semibold fs-6"
                            style="background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;">${totals.dead_leads}</label>
                    </td>
                    <td align="center">
                        <label class="px-3 fw-semibold fs-6"
                            style="background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;">${totals.converted_customers}</label>
                    </td>
                    <td align="center">
                        <label class="px-3 fw-semibold fs-6"
                            style="background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;">${totals.one_day_conversion}</label>
                    </td>
                    <td align="center">
                        <label class="px-3 fw-semibold fs-6"
                            style="background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;">${totals.on_month_conversion}</label>
                    </td>
                    <td align="center">
                        <label class="px-3 fw-semibold fs-6"
                            style="background:#fbe9e7; color:#d84315; border:1px solid #d84315; border-radius:4px;">${totals.old_month_conversion}</label>
                    </td>
                `;
        }

        // Update count badge
        if (countBadge) {
            countBadge.textContent = reports.length;
        }
    }
    // Initialize tooltips
    function initializeTooltips() {
        setTimeout(() => {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.forEach(tooltipTriggerEl => {
                try {
                    new bootstrap.Tooltip(tooltipTriggerEl);
                } catch (e) {
                    console.log('Tooltip initialization error:', e);
                }
            });
        }, 500);
    }

    // Add this CSS for tooltips
    const style = document.createElement('style');
    style.textContent = `
            .tooltip {
                z-index: 9999;
            }
            .scroll-y {
                overflow-y: auto;
                max-height: 150px;
            }
            .scroll-y::-webkit-scrollbar {
                width: 5px;
            }
            .scroll-y::-webkit-scrollbar-track {
                background: #f1f1f1;
                border-radius: 10px;
            }
            .scroll-y::-webkit-scrollbar-thumb {
                background: #888;
                border-radius: 10px;
            }
            .scroll-y::-webkit-scrollbar-thumb:hover {
                background: #555;
            }
        `;
    document.head.appendChild(style);
</script>
