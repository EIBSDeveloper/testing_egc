@extends('layouts/layoutMaster')

@section('title', 'CRE Dashboard')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/apex-charts/apex-charts.scss','resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection
 
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection
 
@section('page-script')
    @vite(['resources/assets/vendor/libs/apex-charts/apexcharts.js','resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

    <style>
        .fade-in-onload {
            animation: fadeInUp 0.8s ease-out forwards;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(52px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
    <style>
        .circular-progress {
            --size: 50px;
            --progress: 75;
            --track-color: #e9ecef;
            --fill-color: #617085;
            width: var(--size);
            height: var(--size);
            border-radius: 50%;
            background: conic-gradient(var(--fill-color) calc(var(--progress) * 1%),
                    var(--track-color) 0);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .circular-progress::before {
            content: '';
            position: absolute;
            width: calc(var(--size) - 12px);
            height: calc(var(--size) - 12px);
            background: #eff2f5;
            border-radius: 50%;
        }

        .progress-value {
            position: relative;
            font-size: 12px;
            font-weight: 800;
        }

         /* Loading Spinner */
        .loading-spinner {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 200px;
        }
    </style>


    <!-- Loading Spinner -->
    <div id="loadingSpinner" class="loading-spinner d-none">
        <div class="text-center">
            <div class="spinner-border text-warning" style="width: 3rem; height: 3rem; margin-top: 250px;" role="status">
                <span class="visually-hidden text-secondary">Loading...</span>
            </div>
            <p class="mt-2 text-dark fw-medium text-primary">Loading {{Auth::user()->staff->staff_name}} dashboard data...</p>
        </div>
    </div>
    <div class="row g-3 dashboard-content" id="dashboardContent">
        <div class="col-lg-12  d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
                @php
                    if (
                        Auth::user()->staff->staff_image != '' &&
                        file_exists(public_path('staff_images/' . Auth::user()->staff->staff_image))
                    ) {
                        $staff_image =
                            '<div class="avatar avatar-xl flex-shrink-0"><img src="' .
                            asset('staff_images/' . Auth::user()->staff->staff_image) .
                            '" alt="Staff" class="rounded-circle img-fluid" style="width: 60px; height: 60px; " /></div>';
                    } else {
                        $initial = strtoupper(substr(Auth::user()->staff->staff_name, 0, 1));
                        $staff_image =
                            '<div class="avatar-initial rounded-circle bg-info fs-1 p-2 text-white">' .
                            $initial .
                            '</div>';
                    }
                @endphp
                {!! $staff_image !!}
                <div class="d-flex align-items-center gap-2">
                    <div class="d-flex flex-column">
                        <div class="d-flex align-items-baseline gap-2 ">
                            <label class="fs-5 fw-semibold text-secondary">Hey</label>
                            <label class="fs-2 fw-semibold text-dark">{{ Auth::user()->staff->staff_name }}</label>
                            <label class="fs-5 fw-semibold text-secondary">Glade You Back Again</label>
                            <span class="mdi mdi-creation text-warning"></span>
                        </div>
                        <label class="fs-7 fw-semibold text-info">Customer Relationship Executive <span
                                class="mdi mdi-crown ms-1 text-info"></span></label>
                    </div>
                    {{-- <div class="d-flex flex-column align-items-center">
                        <div class="circular-progress" data-progress="100">
                            <span class="progress-value">100%</span>
                        </div>
                        <label class="fw-semibold fs-7 mt-2 text-secondary">Goal
                            Set Ratio</label>
                    </div> --}}
                </div>


            </div>
            <div class="date-filter-section d-flex align-items-center justify-content-end mb-1 gap-2">
                <div class="date-filter-container">
                    <div class="cursor-pointer input-group input-group-merge">
                        <span class="input-group-text bg-label-warning text-black"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="ovr_year_fill"
                            class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class w-100px"
                            value="<?php echo date('M-Y'); ?>" readonly onchange="loadDashboardData(this.value)">
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-2 ">
            <div class="card rounded shadow" style="background: #002855;">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div class="d-flex flex-column flex-grow-1">
                        <div class="d-flex align-items-center justify-content-between ">
                            <label class="text-white fs-1 fw-semibold" id="Total_Customers">0</label>
                            <span class="mdi mdi-account-group text-white fs-4  mb-0 rounded p-2 bg-secondary  "></span>
                        </div>
                        <label class="fs-7 text-white ">Total Customers</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 ">
            <div class="card rounded shadow" style="background: #002855;">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div class="d-flex flex-column flex-grow-1">
                        <div class="d-flex align-items-center justify-content-between ">
                            <label class="text-white fs-1 fw-semibold" id="Presale_Customers">0</label>
                            <span class="mdi mdi-account-star text-white fs-4  mb-0 rounded p-2 bg-secondary"></span>
                        </div>
                        <label class="fs-7 text-white">PreSale Customers</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 ">
            <div class="card rounded shadow" style="background: #002855;">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div class="d-flex flex-column flex-grow-1">
                        <div class="d-flex align-items-center justify-content-between ">
                            <label class="text-white fs-1 fw-semibold" id="PostSale_Customers">0</label>
                            <span
                                class="mdi mdi-account-supervisor text-white fs-4  mb-0 rounded p-2 bg-secondary  "></span>
                        </div>
                        <label class="fs-7 text-white ">PostSale Customers</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 ">
            <div class="card rounded shadow" style="background: #002855;">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div class="d-flex flex-column flex-grow-1">
                        <div class="d-flex align-items-center justify-content-between ">
                            <label class="text-white fs-1 fw-semibold" id="Not_Yet_Started">0</label>
                            <span class="mdi mdi-account-cog text-white fs-4  mb-0 rounded p-2 bg-secondary  "></span>
                        </div>
                        <label class="fs-7 text-white ">Total Services</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 ">
            <div class="card rounded shadow" style="background: #002855;">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div class="d-flex flex-column flex-grow-1">
                        <div class="d-flex align-items-center justify-content-between ">
                            <label class="text-white fs-1 fw-semibold" id="Droped_Customers">0</label>
                            <span class="mdi mdi-account-remove text-white fs-4  mb-0 rounded p-2 bg-secondary  "></span>
                        </div>
                        <label class="fs-7 text-white ">Droped Customers</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 ">
            <div class="card rounded shadow" style="background: #002855;">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div class="d-flex flex-column flex-grow-1">
                        <div class="d-flex align-items-center justify-content-between ">
                            <label class="text-white fs-1 fw-semibold" id="Refunded_Customers">0</label>
                            <span
                                class="mdi mdi-account-arrow-right text-white fs-4  mb-0 rounded p-2 bg-secondary  "></span>
                        </div>
                        <label class="fs-7 text-white ">Refunded Customers</label>
                    </div>
                </div>
            </div>
        </div>
        



        <div class="col-lg-6 fade-in-onload">
            <div class="card rounded shadow bg-label-secondary">
                <div class="card-body">
                    <div class="row g-2">
                        <div class="col-lg-12">
                            <div class="d-flex justify-content-between align-items-center">
                                <label class="fs-5 text-secondary ">Harvest Details</label>
                                <div class="d-flex gap-1 align-items-baseline">
                                    <label class="text-black fs-1 fw-semibold" id="Payments_left">0</label>
                                    <label class="text-secondary fs-7 "> Payments left</label>
                                </div>
                            </div>
                        </div>
                        {{-- <div class="col-lg-12"><hr class="m-0"></div> --}}
                        <div class="col-lg-6 border-end">
                            <div class="d-flex flex-column ">
                                <label class="text-black fs-1 fw-semibold" id="Total_Amount">&#8377; 0</label>
                                <label class="fs-7 text-secondary ">Total Amount</label>
                            </div>
                        </div>
                        <div class="col-lg-6 border-start">
                            <div class="d-flex flex-column align-items-end">
                                <label class="text-black fs-1 fw-semibold" id="Paid_Amount">&#8377; 0</label>
                                <label class="fs-7 text-secondary ">Paid Amount</label>
                            </div>
                        </div>
                        <div class="col-lg-6 border-end">
                            <div class="d-flex flex-column ">
                                <label class="text-black fs-1 fw-semibold" id="Balance_Amount">&#8377; 0</label>
                                <label class="fs-7 text-secondary " >Balance Amount</label>
                            </div>
                        </div>
                        <div class="col-lg-6 border-start">
                            <div class="d-flex flex-column align-items-end">
                                <div class="d-flex gap-1 align-items-baseline">
                                    <label class="text-black fs-1 fw-semibold" id="Balance_Percentage">0%</label>
                                    {{-- <label class="fs-7 text-secondary"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="Last Month">89.16%</label> --}}
                                </div>
                                <label class="fs-7 text-secondary ">Balance Percentage</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 fade-in-onload">
            <div class="card rounded shadow bg-label-secondary">
                <div class="card-body">
                    <div class="row g-2">
                        <div class="col-lg-12">
                            <div class="d-flex justify-content-between align-items-center">
                                <label class="fs-5 text-secondary ">OutStanding Details</label>
                                <div class="d-flex gap-1 align-items-baseline">
                                    <label class="text-black fs-1 fw-semibold" id="Outstanding_Payments_left">0</label>
                                    <label class="text-secondary fs-7 "> Payments left</label>
                                </div>
                            </div>
                        </div>
                        {{-- <div class="col-lg-12"><hr class="m-0"></div> --}}
                        <div class="col-lg-6 border-end">
                            <div class="d-flex flex-column">
                                <label class="text-black fs-1 fw-semibold" id="Outstanding_This_Month">&#8377; 0</label>
                                <label class="fs-7 text-secondary " >This Month</label>
                            </div>
                        </div>
                        <div class="col-lg-6 border-start">
                            <div class="d-flex flex-column align-items-end">
                                <label class="text-black fs-1 fw-semibold" id="Outstanding_Next_Month">&#8377; 0</label>
                                <label class="fs-7 text-secondary " >Next Month</label>
                            </div>
                        </div>
                        <div class="col-lg-6 border-end">
                            <div class="d-flex flex-column">
                                <label class="text-black fs-1 fw-semibold" id="Outstanding_Upcoming">&#8377; 0</label>
                                <label class="fs-7 text-secondary " >Upcoming</label>
                            </div>
                        </div>
                        <div class="col-lg-6 border-start">
                            <div class="d-flex flex-column align-items-end">
                                <label class="text-black fs-1 fw-semibold" id="Outstanding_Overall">&#8377; 0</label>
                                <label class="fs-7 text-secondary "  >OverAll</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-lg-9 fade-in-onload">
            <div class="card rounded shadow">
                <div class="card-body py-2">
                    <div class="row g-2">
                        <div class="col-lg-12">
                            <div class="d-flex justify-content-between align-items-center">
                                <label class="fs-5 text-secondary ">Review Details</label>
                                <div class="d-flex gap-1 align-items-baseline">
                                    <label class="text-black fs-1 fw-semibold" id="Total_Reviews">0</label>

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div id="horizontalBarChartCRE"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-lg-3 fade-in-onload">
            <div class="row g-3">
                <div class="col-lg-6">
                    <div class="card rounded shadow " style=" background:#635c5c;">
                        <div class="card-body ">
                            <div class="d-flex flex-column ">
                                <label class="fs-5 text-white ">Total </label>
                                <label class="text-white fs-1 fw-semibold" id="Total_Appointments">0</label>
                                <label class="fs-7 text-white ">Appointments</label>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card rounded shadow" style="  background:#436a88;">
                        <div class="card-body ">
                            <div class="d-flex flex-column ">
                                <label class="fs-5 text-white ">Scheduled</label>
                                <label class="text-white fs-1 fw-semibold" id="Scheduled_Appointments">0</label>
                                <label class="fs-7 text-white ">Appointments</label>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card rounded shadow" style="  background:#7c3434;">
                        <div class="card-body ">
                            <div class="d-flex flex-column ">
                                <label class="fs-5 text-white ">Cancelled</label>
                                <label class="text-white fs-1 fw-semibold" id="Cancelled_Appointments">0</label>
                                <label class="fs-7 text-white ">Appointments</label>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card rounded shadow" style="  background:#517a76;">
                        <div class="card-body ">
                            <div class="d-flex flex-column ">
                                <label class="fs-5 text-white ">Completed</label>
                                <label class="text-white fs-1 fw-semibold" id="Completed_Appointments">0</label>
                                <label class="fs-7 text-white ">Appointments</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Initialize datepicker
            $('.month_filter_common_class').datepicker({
                format: "M-yyyy",
                startView: "months",
                minViewMode: "months",
                autoclose: true,
                orientation: "bottom"
            });

            // Load initial data with current month
            loadDashboardData($('#ovr_year_fill').val());

            // Chart instance variable
            let chartInstance = null;
        });

        loadDashboardData($('#ovr_year_fill').val());

        function loadDashboardData(selectedDate) {
            showLoading();

            // Make AJAX request to fetch dashboard data
            $.ajax({
                url: "{{ route('cre.dashboard.data') }}",
                method: "GET",
                data: {
                    date_filter: selectedDate
                },
                dataType: "json",
                success: function(response) {
                    if (response.success) {
                        updateDashboardData(response.data);
                        updateChart(response.data.reviews.chart_data);
                    } else {
                        showError('Failed to load dashboard data: ' + (response.message || 'Unknown error'));
                    }
                    hideLoading();
                },
                error: function(xhr, status, error) {
                    console.error('Error loading dashboard data:', error);
                    showError('Error loading dashboard data. Please try again.');
                    hideLoading();
                }
            });
        }

        function updateDashboardData(data) {
            // Update KPI Cards
            $('#Total_Customers').text(data.total_customers || 0);
            $('#PostSale_Customers').text(data.postsale_customers || 0);
            $('#Presale_Customers').text(data.presale_customers || 0);
            $('#Droped_Customers').text(data.dropped_customers || 0);
            $('#Refunded_Customers').text(data.refunded_customers || 0);
            $('#Not_Yet_Started').text(data.not_yet_started || 0);

            // Update Harvest Details
            $('#Payments_left').text(data.harvest.payments_left || 0);
            $('#Total_Amount').html(formatCurrency(data.harvest.total_amount || 0));
            $('#Paid_Amount').html(formatCurrency(data.harvest.paid_amount || 0));
            $('#Balance_Amount').html(formatCurrency(data.harvest.balance_amount || 0));
            $('#Balance_Percentage').text(data.harvest.balance_percentage?.toFixed(2) + '%' || '0%');

            // Update Outstanding Details
            $('#Outstanding_Payments_left').text(data.outstanding.payments_left || 0);
            $('#Outstanding_This_Month').html(formatCurrency(data.outstanding.this_month || 0));
            $('#Outstanding_Next_Month').html(formatCurrency(data.outstanding.next_month || 0));
            $('#Outstanding_Upcoming').html(formatCurrency(data.outstanding.upcoming || 0));
            $('#Outstanding_Overall').html(formatCurrency(data.outstanding.overall || 0));

            // Update Appointment Cards
            $('#Total_Appointments').text(data.appointments.total || 0);
            $('#Scheduled_Appointments').text(data.appointments.scheduled || 0);
            $('#Cancelled_Appointments').text(data.appointments.cancelled || 0);
            $('#Completed_Appointments').text(data.appointments.completed || 0);

            // Update Reviews Count
            $('#Total_Reviews').text(data.reviews.total || 0);

            // Update month display if needed
            if (data.meta && data.meta.month_year) {
                $('#ovr_year_fill').val(data.meta.month_year);
            }
        }

        function updateChart(reviewsData) {
            console.log('Chart Data:', reviewsData); // 🔥 DEBUG

            const horizontalBarChartEl = document.querySelector('#horizontalBarChartCRE');

            if (!horizontalBarChartEl) {
                console.error('Chart element not found');
                return;
            }

            if (!Array.isArray(reviewsData)) {
                console.error('Invalid chart data', reviewsData);
                reviewsData = [0, 0, 0, 0, 0];
            }

            if (window.chartInstance) {
                window.chartInstance.destroy();
            }

            const horizontalBarChartConfig = {
                chart: {
                    height: 205,
                    type: 'bar',
                    fontFamily: 'Inter',
                    toolbar: {
                        show: false
                    }
                },
                plotOptions: {
                    bar: {
                        horizontal: true,
                        distributed: true,
                        barHeight: '80%',
                        borderRadius: 8,
                        dataLabels: {
                            position: 'center'
                        }
                    }
                },
                dataLabels: {
                    enabled: true,
                    style: {
                        colors: ['#fff'],
                        fontSize: '12px'
                    }
                },
                series: [{
                    name: 'Review Count',
                    data: reviewsData
                }],
                colors: ['#e63946', '#f77f00', '#ffba08', '#43aa8b', '#277da1'],
                xaxis: {
                    categories: ['1 Star', '2 Star', '3 Star', '4 Star', '5 Star']
                },
                tooltip: {
                    y: {
                        formatter: val => `${val} reviews`
                    }
                },
                legend: {
                    show: false
                }
            };

            window.chartInstance = new ApexCharts(horizontalBarChartEl, horizontalBarChartConfig);
            window.chartInstance.render();
        }


        function formatCurrency(amount) {
            if (typeof amount !== 'number') {
                amount = parseFloat(amount) || 0;
            }

            // Format for Indian Rupees
            const formatter = new Intl.NumberFormat('en-IN', {
                style: 'currency',
                currency: 'INR',
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });

            return formatter.format(amount).replace('₹', '&#8377; ');
        }

        function showLoading() {
            // alert('load')
            $('#loadingSpinner').removeClass('d-none');
            $('#dashboardContent').addClass('d-none');
        }

        function hideLoading() {
            $('#loadingSpinner').addClass('d-none');
            $('#dashboardContent').removeClass('d-none');
        }

        function showError(message) {
            // Use SweetAlert or Toast for better UX
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: message,
                    timer: 3000,
                    showConfirmButton: false
                });
            } else {
                // alert(message);
            }
        }
    </script>



@endsection
