@extends('layouts/layoutMaster')

@section('title', 'CEO & Business Head Dashboard')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('content')

    <style>
        .fade-in-onload {
            animation: fadeInUp 0.8s ease-out forwards;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(52px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Universal sticky table styles - FIXED FOR ALL TABLES */
        .table-wrapper {
            overflow: auto;
            max-height: 600px;
            max-width: 100%;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            position: relative;
            margin-bottom: 20px;
            border: 1px solid #dee2e6;
        }

        /* Sticky header - applies to all sticky tables */
        .sticky_table {
            width: 100%;
            border-collapse: separate !important;
            border-spacing: 0 !important;
            background: white;
        }

        .sticky_table thead tr {
            position: sticky !important;
            top: 0 !important;
            z-index: 1000 !important;
        }

        .sticky_table thead th {
            position: sticky !important;
            top: 0 !important;
            background: #099DDA !important;
            color: white !important;
            z-index: 1000 !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
            border-bottom: 2px solid rgba(255, 255, 255, 0.3) !important;
            white-space: nowrap;
            padding: 12px 8px !important;
            font-weight: 600;
        }

        /* Sticky first column (Staff) */
        .sticky_table th.col-staff,
        .sticky_table td.col-staff {
            position: sticky !important;
            left: 0 !important;
            z-index: 900 !important;
            background: white !important;
            min-width: 280px;
            max-width: 280px;
            border-right: 2px solid #dee2e6 !important;
            box-shadow: 2px 0 5px -2px rgba(0, 0, 0, 0.1);
        }

        /* Sticky second column (Work/Stage) */
        .sticky_table th.col-work,
        .sticky_table td.col-work {
            position: sticky !important;
            left: 280px !important;
            z-index: 850 !important;
            background: white !important;
            min-width: 200px;
            max-width: 200px;
            border-right: 2px solid #dee2e6 !important;
            box-shadow: 2px 0 5px -2px rgba(0, 0, 0, 0.1);
        }

        /* Sticky last column (Action) */
        .sticky_table th.col-action,
        .sticky_table td.col-action {
            position: sticky !important;
            right: 0 !important;
            z-index: 900 !important;
            background: white !important;
            min-width: 140px;
            max-width: 140px;
            border-left: 2px solid #dee2e6 !important;
            box-shadow: -2px 0 5px -2px rgba(0, 0, 0, 0.1);
        }

        /* Header sticky columns - higher z-index */
        .sticky_table thead th.col-staff,
        .sticky_table thead th.col-work,
        .sticky_table thead th.col-action {
            background: #099DDA !important;
            color: white !important;
            z-index: 1100 !important;
            border-bottom: 2px solid rgba(255, 255, 255, 0.3) !important;
        }

        /* Header sticky column borders */
        .sticky_table thead th.col-staff {
            border-right: 2px solid rgba(255, 255, 255, 0.3) !important;
        }

        .sticky_table thead th.col-work {
            border-right: 2px solid rgba(255, 255, 255, 0.3) !important;
        }

        .sticky_table thead th.col-action {
            border-left: 2px solid rgba(255, 255, 255, 0.3) !important;
        }

        /* Day columns - normal scrolling */
        .sticky_table th.day-col,
        .sticky_table td.day-col {
            min-width: 180px;
            max-width: 180px;
            text-align: center;
            background: white;
            white-space: nowrap;
        }

        .sticky_table thead th.day-col {
            background: #099DDA !important;
            color: white !important;
            z-index: 950 !important;
        }

        /* Table cell borders */
        .sticky_table td {
            border: 1px solid #dee2e6 !important;
            padding: 12px 8px !important;
            vertical-align: middle;
            background: white;
        }

        /* Hover effect for sticky cells */
        .sticky_table tbody tr:hover td.col-staff,
        .sticky_table tbody tr:hover td.col-work,
        .sticky_table tbody tr:hover td.col-action {
            background: #f8f9fa !important;
        }

        .sticky_table tbody tr:hover td {
            background: #f8f9fa;
        }

        /* Fix for sales table specific */
        .sales_table {
            width: 100%;
            border-collapse: separate !important;
            border-spacing: 0 !important;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .sticky_table th.col-staff,
            .sticky_table td.col-staff {
                min-width: 220px;
                left: 0;
            }

            .sticky_table th.col-work,
            .sticky_table td.col-work {
                min-width: 160px;
                left: 220px;
            }

            .sticky_table th.col-action,
            .sticky_table td.col-action {
                min-width: 120px;
            }

            .sticky_table th.day-col,
            .sticky_table td.day-col {
                min-width: 150px;
            }
        }

        /* Safari compatibility */
        @media screen and (-webkit-min-device-pixel-ratio: 0) {
            .sticky_table th.col-staff,
            .sticky_table td.col-staff,
            .sticky_table th.col-work,
            .sticky_table td.col-work,
            .sticky_table th.col-action,
            .sticky_table td.col-action {
                -webkit-transform: translateZ(0);
            }
        }

        /* Custom scrollbar */
        .table-wrapper::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }

        .table-wrapper::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 5px;
        }

        .table-wrapper::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 5px;
        }

        .table-wrapper::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        /* Loader Styles */
        .loader-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.95);
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: opacity 0.3s ease;
        }

        .loader-content {
            text-align: center;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        .spinner-border {
            width: 3rem;
            height: 3rem;
        }

        .data-loading {
            opacity: 0.6;
            pointer-events: none;
        }

        table thead th {
            border: 1px solid #fff !important;
        }

        table tbody td {
            border: 1px solid #0000003d !important;
        }

        /* ===== Skeleton Loader ===== */
        .skeleton-container {
            width: 100%;
            padding: 20px;
        }

        .skeleton {
            position: relative;
            overflow: hidden;
            background-color: #e9ecef;
            border-radius: 6px;
        }

        .skeleton::after {
            content: '';
            position: absolute;
            top: 0;
            left: -150px;
            width: 150px;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, .6), transparent);
            animation: skeleton-loading 1.2s infinite;
        }

        @keyframes skeleton-loading {
            100% {
                left: 100%;
            }
        }

        .skeleton-table {
            width: 100%;
            border-collapse: collapse;
        }

        .skeleton-table td {
            padding: 15px 12px !important;
            border-bottom: 1px solid #dee2e6 !important;
        }

        .skeleton-text {
            height: 16px;
            margin-bottom: 8px;
            border-radius: 4px;
        }

        .skeleton-text-sm {
            height: 14px;
            width: 80%;
            margin-bottom: 6px;
        }

        .skeleton-badge {
            height: 34px;
            width: 120px;
            border-radius: 20px;
        }

        .skeleton-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .skeleton-cell {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
        }

        .skeleton-progress {
            height: 45px;
            width: 140px;
            border-radius: 8px;
        }

        .skeleton-status {
            height: 30px;
            width: 100px;
            border-radius: 20px;
            margin: 0 auto;
        }

        .table-skeleton-wrapper {
            width: 100%;
            background: white;
            border-radius: 8px;
            overflow: hidden;
        }

        .skeleton-header {
            background: #099DDA;
            padding: 12px;
        }

        .skeleton-header-cell {
            height: 20px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 4px;
        }
    </style>

    <!-- Loader -->
    <div id="dashboard-loader" class="loader-overlay" style="display: none;">
        <div class="loader-content">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-3">Loading dashboard data...</p>
        </div>
    </div>

    <div class="row g-3" id="dashboard-container">
        <div class="col-lg-12 d-flex justify-content-between align-items-between">
            <div class="d-flex gap-1 align-items-center gap-3">
                @if(Auth::user()->staff->role_id == 1)
                <h1 class="fw-semibold text-secondary">Chief Executive Officer Dashboard</h1>
                @else
                <h1 class="fw-semibold text-secondary">Business Head Dashboard</h1>
                @endif
            </div>
            <div class=" " style="width:200px;">
                <div class="date-filter-container">
                    <div class="cursor-pointer input-group input-group-merge">
                        <span class="input-group-text bg-label-warning text-black"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="ovr_year_fill"
                            class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class w-100px"
                            value="<?php echo date('M-Y'); ?>" readonly onchange="loadDashboardData(this.value)">
                    </div>
                </div>
            </div>
        </div>

        <!-- Business Goal Set -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Business Goal Set</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold date_view_class">{{ date('M-Y') }}</label>
            </div>
        </div>

        <div class="col-lg-6 fade-in-onload">
            <div class="card rounded shadow w-100 ">
                <div class="card-body position-relative">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex flex-column align-items-start justify-content-start">
                            <label class="text-black fw-semibold fs-1 mb-0" id="business-target">₹ 0</label>
                            <label class="text-secondary fw-medium fs-6">Target</label>
                        </div>
                        <div class="d-flex flex-column align-items-end justify-content-end">
                            <label class="text-danger fw-semibold fs-1 mb-0" id="business-actual">₹ 0</label>
                            <label class="text-secondary fw-medium fs-6">Actual</label>
                        </div>
                    </div>
                    <div class="divider divider-vertical position-absolute" style="top:0px; left:45%;">
                        <div class="divider-text">VS</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow w-100">
                <div class="card-body position-relative">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex flex-column align-items-start justify-content-start">
                            <label class="text-black fw-semibold fs-1 mb-0" id="post-sale-target">0</label>
                            <label class="text-secondary fw-medium fs-6">Post Sale</label>
                        </div>
                        <div class="d-flex flex-column align-items-end justify-content-end">
                            <label class="text-danger fw-semibold fs-1 mb-0" id="post-sale-actual">0</label>
                            <label class="text-secondary fw-medium fs-6">Actual</label>
                        </div>
                    </div>
                    <div class="divider divider-vertical position-absolute" style="top:0px; left:45%;">
                        <div class="divider-text">VS</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow w-100">
                <div class="card-body position-relative">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex flex-column align-items-start justify-content-start">
                            <label class="text-black fw-semibold fs-1 mb-0" id="pre-sale-target">0</label>
                            <label class="text-secondary fw-medium fs-6">Pre Sale</label>
                        </div>
                        <div class="d-flex flex-column align-items-end justify-content-end">
                            <label class="text-danger fw-semibold fs-1 mb-0" id="pre-sale-actual">0</label>
                            <label class="text-secondary fw-medium fs-6">Actual</label>
                        </div>
                    </div>
                    <div class="divider divider-vertical position-absolute" style="top:0px; left:45%;">
                        <div class="divider-text">VS</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Overall Targets & Achieved -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Overall Targets & Achieved (<span
                    class="text-info">Sales</span>)</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold date_view_class">{{ date('M-Y') }}</label>
            </div>
        </div>

        <div class="col-lg-6 fade-in-onload">
            <div class="card rounded shadow w-100">
                <div class="card-body position-relative d-flex flex-column gap-4">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex flex-column align-items-start justify-content-start">
                            <label class="text-black fw-semibold fs-1 mb-0" id="conversion-target">0</label>
                            <label class="text-secondary fw-medium fs-6">Conversion Target</label>
                        </div>
                        <div class="d-flex flex-column align-items-end justify-content-end">
                            <label class="text-danger fw-semibold fs-1 mb-0" id="conversion-actual">0</label>
                            <label class="text-secondary fw-medium fs-6">Conversion Achieved</label>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex flex-column align-items-start justify-content-start">
                            <label class="text-black fw-semibold fs-1 mb-0" id="conversion-rate-target">0%</label>
                            <label class="text-secondary fw-medium fs-6">Conversion Rate Target</label>
                        </div>
                        <div class="d-flex flex-column align-items-end justify-content-end">
                            <label class="text-danger fw-semibold fs-1 mb-0" id="conversion-rate-actual">0%</label>
                            <label class="text-secondary fw-medium fs-6">Conversion Rate Achieved</label>
                        </div>
                    </div>
                    <div class="divider divider-vertical position-absolute" style="top:0px; left:45%;">
                        <div class="divider-text">VS</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 fade-in-onload">
            <div class="card rounded shadow w-100">
                <div class="card-body position-relative d-flex flex-column gap-4">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex flex-column align-items-start justify-content-start">
                            <label class="text-black fw-semibold fs-1 mb-0" id="avg-business-target">₹ 0</label>
                            <label class="text-secondary fw-medium fs-6">Average Business Value Target</label>
                        </div>
                        <div class="d-flex flex-column align-items-end justify-content-end">
                            <label class="text-danger fw-semibold fs-1 mb-0" id="avg-business-actual">₹ 0</label>
                            <label class="text-secondary fw-medium fs-6">Average Business Value Achieved</label>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex flex-column align-items-start justify-content-start">
                            <label class="text-black fw-semibold fs-1 mb-0" id="avg-conversion-target">₹ 0</label>
                            <label class="text-secondary fw-medium fs-6">Average Conversion Value Target</label>
                        </div>
                        <div class="d-flex flex-column align-items-end justify-content-end">
                            <label class="text-danger fw-semibold fs-1 mb-0" id="avg-conversion-actual">₹ 0</label>
                            <label class="text-secondary fw-medium fs-6">Average Conversion Value Achieved</label>
                        </div>
                    </div>
                    <div class="divider divider-vertical position-absolute" style="top:0px; left:45%;">
                        <div class="divider-text">VS</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Alert System -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Alert System</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold" id="alert-date">{{ date('d-M-Y') }}</label>
            </div>
        </div>

        <!-- Alert Cards -->
        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow-lg">
                <div class="card-body d-flex flex-column">
                    <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                        <div class="d-flex gap-1 align-items-center">
                            <label class="text-danger fw-semibold fs-1" id="attendance-actual">0</label>
                            <label class="text-black fw-semibold fs-1">/</label>
                            <label class="text-black fw-semibold fs-1" id="attendance-target">0</label>
                        </div>
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#d2f8fd;">
                            <i class="mdi mdi-account-group fs-3" style="color:#1babc4; font-size:20px;"></i>
                        </div>
                    </div>
                    <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                        <label class="text-secondary fw-semibold fs-7">Staff Attendance</label>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow-lg">
                <div class="card-body d-flex flex-column">
                    <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                        <label class="text-black fw-semibold fs-1 m-0 p-0" id="outstanding-count">0</label>
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#d2f8fd;">
                            <i class="mdi mdi-account-alert fs-3" style="color:#1babc4; font-size:20px;"></i>
                        </div>
                    </div>
                    <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                        <label class="text-secondary fw-semibold fs-7"> Outstanding Count</label>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow-lg">
                <div class="card-body d-flex flex-column">
                    <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                        <label class="text-black fw-semibold fs-1 m-0 p-0" id="payment_verification">0</label>
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#d2f8fd;">
                            <i class="mdi mdi-cash-sync fs-3" style="color:#1babc4; font-size:20px;"></i>
                        </div>
                    </div>
                    <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                        <label class="text-secondary fw-semibold fs-7"> Payment Verification</label>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow-lg">
                <div class="card-body d-flex flex-column">
                    <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                        <label class="text-black fw-semibold fs-1 m-0 p-0" id="low-mpc-count">0</label>
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#d2f8fd;">
                            <i class="mdi mdi-account-cash fs-3" style="color:#1babc4; font-size:20px;"></i>
                        </div>
                    </div>
                    <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                        <label class="text-secondary fw-semibold fs-7"> Low MPC Count</label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Approval Pending Alert -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Approval Pending Alert</label>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow w-100" style="overflow: hidden;">
                <div class="card-body position-relative p-5">
                    <div class="d-flex flex-column">
                        <div class="d-flex gap-1 align-items-center pt-3">
                            <label class="text-black fw-semibold fs-1 mb-0" id="drop-waiting">0</label>
                        </div>
                        <label class="text-secondary fw-semibold fs-7">Drop Waiting</label>
                    </div>
                    <img src="{{ asset('assets/phdizone_images/money-loss.png') }}" alt="avatar"
                        class="img-fluid position-absolute overflow-hidden"
                        style="width: 115px; height: 115px; object-fit: cover; left:60%; top:1px;">
                </div>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow w-100" style="overflow: hidden;">
                <div class="card-body position-relative p-5">
                    <div class="d-flex flex-column">
                        <div class="d-flex gap-1 align-items-center pt-3">
                            <label class="text-black fw-semibold fs-1 mb-0" id="refund-waiting">0</label>
                        </div>
                        <label class="text-secondary fw-semibold fs-7">Refund Waiting</label>
                    </div>
                    <img src="{{ asset('assets/phdizone_images/rupee-alert.png') }}" alt="avatar"
                        class="img-fluid position-absolute overflow-hidden"
                        style="width: 115px; height: 115px; object-fit: cover; left:60%; top:1px;">
                </div>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow w-100" style="overflow: hidden;">
                <div class="card-body position-relative p-5">
                    <div class="d-flex flex-column">
                        <div class="d-flex gap-1 align-items-center pt-3">
                            <label class="text-black fw-semibold fs-1 mb-0" id="accounts-confirmation">0</label>
                        </div>
                        <label class="text-secondary fw-semibold fs-7">Accounts Payment Approval</label>
                    </div>
                    <img src="{{ asset('assets/phdizone_images/confirmation.png') }}" alt="avatar"
                        class="img-fluid position-absolute overflow-hidden"
                        style="width: 115px; height: 115px; object-fit: cover; left:60%; top:1px;">
                </div>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow w-100" style="overflow: hidden;">
                <div class="card-body position-relative p-5">
                    <div class="d-flex flex-column">
                        <div class="d-flex gap-1 align-items-center pt-3">
                            <label class="text-black fw-semibold fs-1 mb-0" id="login-approval">0</label>
                        </div>
                        <label class="text-secondary fw-semibold fs-7">Login Approval</label>
                    </div>
                    <img src="{{ asset('assets/phdizone_images/login_approval.png') }}" alt="avatar"
                        class="img-fluid position-absolute overflow-hidden"
                        style="width: 115px; height: 115px; object-fit: cover; left:60%; top:1px;">
                </div>
            </div>
        </div>

        <!-- Lead Status -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Lead Status</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold date_view_class">{{ date('M-Y') }}</label>
            </div>
        </div>

        <div class="col-lg-12 fade-in-onload">
            <div class="card rounded shadow-lg">
                <div class="card-body d-flex align-items-center justify-content-between gap-3">
                    <div class="d-flex flex-column border-end flex-grow-1">
                        <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                            <label class="text-black fw-semibold fs-1" id="total-leads">0</label>
                        </div>
                        <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                            <label class="text-secondary fw-semibold fs-7">Total Lead</label>
                        </div>
                    </div>
                    <div class="d-flex flex-column border-end flex-grow-1">
                        <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                            <label class="text-black fw-semibold fs-1" id="active-leads">0</label>
                        </div>
                        <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                            <label class="text-secondary fw-semibold fs-7">Active Lead</label>
                        </div>
                    </div>
                    <div class="d-flex flex-column border-end flex-grow-1">
                        <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                            <label class="text-black fw-semibold fs-1" id="spam-leads">0</label>
                        </div>
                        <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                            <label class="text-secondary fw-semibold fs-7">Spam Lead</label>
                        </div>
                    </div>
                    <div class="d-flex flex-column border-end flex-grow-1">
                        <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                            <label class="text-black fw-semibold fs-1" id="dead-leads">0</label>
                        </div>
                        <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                            <label class="text-secondary fw-semibold fs-7">Dead Lead</label>
                        </div>
                    </div>
                    <div class="d-flex flex-column">
                        <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                            <label class="text-info fw-semibold fs-1" id="converted-customers">0</label>
                        </div>
                        <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                            <label class="text-secondary fw-semibold fs-7">Convert Customer</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Service Status -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Service Status</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold date_view_class">{{ date('M-Y') }}</label>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow-lg">
                <div class="card-body d-flex flex-column">
                    <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                        <label class="text-black fw-semibold fs-1" id="total-service">0</label>
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#d2f8fd;">
                            <i class="mdi mdi-file-document-edit fs-3" style="color:#1babc4; font-size:20px;"></i>
                        </div>
                    </div>
                    <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                        <label class="text-secondary fw-semibold fs-7">Total Service</label>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow-lg">
                <div class="card-body d-flex flex-column">
                    <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                        <label class="text-black fw-semibold fs-1 m-0 p-0" id="staff-allocated">0</label>
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#d2f8fd;">
                            <i class="mdi mdi-account-group fs-3" style="color:#1babc4; font-size:20px;"></i>
                        </div>
                    </div>
                    <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                        <label class="text-secondary fw-semibold fs-7">PC Not Allocated</label>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow-lg">
                <div class="card-body d-flex flex-column">
                    <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                        <label class="text-black fw-semibold fs-1 m-0 p-0" id="milestone-pending">0</label>
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#d2f8fd;">
                            <i class="mdi mdi-compass fs-3" style="color:#1babc4; font-size:20px;"></i>
                        </div>
                    </div>
                    <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                        <label class="text-secondary fw-semibold fs-7">Milestone Pending Confirmation</label>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 fade-in-onload">
            <div class="card rounded shadow-lg">
                <div class="card-body d-flex flex-column">
                    <div class="d-flex flex-grow-1 align-items-end justify-content-between">
                        <label class="text-black fw-semibold fs-1 m-0 p-0" id="unmapped-milestone">0</label>
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#d2f8fd;">
                            <i class="mdi mdi-compass-off fs-3" style="color:#1babc4; font-size:20px;"></i>
                        </div>
                    </div>
                    <div class="d-flex flex-grow-1 align-items-center justify-content-between mt-1">
                        <label class="text-secondary fw-semibold fs-7">Unmapped Milestone</label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Journal Status -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Journal Status</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold date_view_class">{{ date('M-Y') }}</label>
            </div>
        </div>

        <div class="col-lg-12 fade-in-onload">
            <div class="card rounded shadow w-100" style="overflow: hidden;">
                <div class="card-body position-relative p-5">
                    <div class="row g-3">
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="with-editor">0</label>
                                <label class="text-secondary fw-semibold fs-7">With Editor</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="under-review">0</label>
                                <label class="text-secondary fw-semibold fs-7">Under Review</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="rejected">0</label>
                                <label class="text-secondary fw-semibold fs-7">Rejected</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="revision">0</label>
                                <label class="text-secondary fw-semibold fs-7">Revision</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="eproofing">0</label>
                                <label class="text-secondary fw-semibold fs-7">Eproofing</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="accepted">0</label>
                                <label class="text-secondary fw-semibold fs-7">Accepted</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="submitted">0</label>
                                <label class="text-secondary fw-semibold fs-7">Submitted</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-info fw-semibold fs-1" id="published">0</label>
                                <label class="text-secondary fw-semibold fs-7">Published</label>
                            </div>
                        </div>
                    </div>
                    <img src="{{ asset('assets/phdizone_images/books.png') }}" alt="avatar"
                        class="img-fluid position-absolute overflow-hidden"
                        style="width: 200px; height: 200px; object-fit: cover; left:85%; top:1px;">
                </div>
            </div>
        </div>

        <!-- Revision Status -->
        <div class="col-lg-12 fade-in-onload">
            <div class="card rounded shadow w-100" style="overflow: hidden;">
                <div class="card-body position-relative p-5">
                    <div class="row g-3">
                        <div class="col-lg-12">
                            <label class="text-dark fw-medium fs-5">Revision Status</label>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="jtl-verification">0</label>
                                <label class="text-secondary fw-semibold fs-7">JTL Verification</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="revision-staff-assigned">0</label>
                                <label class="text-secondary fw-semibold fs-7">Staff Assigned</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="revision-inprogress">0</label>
                                <label class="text-secondary fw-semibold fs-7">In progress</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="revision-completed">0</label>
                                <label class="text-secondary fw-semibold fs-7">Completed</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="waiting-documentation">0</label>
                                <label class="text-secondary fw-semibold fs-7">Waiting For Documentation</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="pc-not-assign">0</label>
                                <label class="text-secondary fw-semibold fs-7">PC Not Assign</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="staff-not-assign">0</label>
                                <label class="text-secondary fw-semibold fs-7">Staff Not Assign</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="revision-rework">0</label>
                                <label class="text-secondary fw-semibold fs-7">Rework</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="pc-pending-verification">0</label>
                                <label class="text-secondary fw-semibold fs-7">PC Pending Verification</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="d-flex flex-column">
                                <label class="text-black fw-semibold fs-1" id="jtl-pending-verification">0</label>
                                <label class="text-secondary fw-semibold fs-7">JTL Pending Verification</label>
                            </div>
                        </div>
                    </div>
                    <img src="{{ asset('assets/phdizone_images/booksnew.png') }}" alt="avatar"
                        class="img-fluid position-absolute overflow-hidden"
                        style="width: 200px; height: 200px; object-fit: cover; left:85%; top:70px;">
                </div>
            </div>
        </div>

        <!-- Sales Goal Set Status -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Sales Goal Set Status</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold date_view_class">{{ date('M-Y') }}</label>
            </div>
        </div>

        <div class="col-lg-12 fade-in-onload">
            <div class="table-wrapper position-relative">
                <div class="table-container">
                    <!-- Sales Table Skeleton -->
                    <div id="sales-skeleton" class="table-skeleton-wrapper" style="display: none;">
                        <table class="skeleton-table sticky_table" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th class="col-staff" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                                    </th>
                                    <th class="col-work" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 100px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 60px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 100px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 100px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 100px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="col-action" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @for ($i = 0; $i < 3; $i++)
                                <tr>
                                    <td class="col-staff">
                                        <div class="d-flex align-items-center">
                                            <div class="skeleton skeleton-avatar me-2"></div>
                                            <div style="width: 100%;">
                                                <div class="skeleton skeleton-text w-75"></div>
                                                <div class="skeleton skeleton-text w-50"></div>
                                                <div class="skeleton skeleton-text-sm w-50"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="col-work">
                                        <div class="skeleton skeleton-text w-80"></div>
                                        <div class="skeleton skeleton-text-sm w-60"></div>
                                    </td>
                                    <td class="day-col">
                                        <div class="skeleton-cell">
                                            <div class="skeleton skeleton-badge"></div>
                                            <div class="skeleton skeleton-badge"></div>
                                        </div>
                                    </td>
                                    <td class="day-col">
                                        <div class="skeleton-cell">
                                            <div class="skeleton skeleton-badge"></div>
                                            <div class="skeleton skeleton-badge"></div>
                                        </div>
                                    </td>
                                    <td class="day-col">
                                        <div class="skeleton-cell">
                                            <div class="skeleton skeleton-badge"></div>
                                            <div class="skeleton skeleton-badge"></div>
                                        </div>
                                    </td>
                                    <td class="day-col">
                                        <div class="skeleton-cell">
                                            <div class="skeleton skeleton-badge"></div>
                                            <div class="skeleton skeleton-badge"></div>
                                        </div>
                                    </td>
                                    <td class="day-col">
                                        <div class="skeleton-cell">
                                            <div class="skeleton skeleton-badge"></div>
                                            <div class="skeleton skeleton-badge"></div>
                                        </div>
                                    </td>
                                    <td class="day-col">
                                        <div class="skeleton-cell">
                                            <div class="skeleton skeleton-badge"></div>
                                            <div class="skeleton skeleton-badge"></div>
                                        </div>
                                    </td>
                                    <td class="day-col">
                                        <div class="skeleton-cell">
                                            <div class="skeleton skeleton-badge"></div>
                                            <div class="skeleton skeleton-badge"></div>
                                        </div>
                                    </td>
                                    <td class="col-action">
                                        <div class="skeleton skeleton-status"></div>
                                    </td>
                                </tr>
                                @endfor
                            </tbody>
                        </table>
                    </div>
                    
                    <table
                        class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 min-w-max sales_table"
                        style="display: none;">
                        <thead>
                            <tr>
                                <th class="col-staff">Staff</th>
                                <th class="col-work">Stage</th>
                                <th class="day-col min-w-200px">Conversion</th>
                                <th class="day-col min-w-200px text-center">CR</th>
                                <th class="day-col min-w-400px text-center">ABV</th>
                                <th class="day-col min-w-400px text-center">ACV</th>
                                <th class="day-col min-w-200px text-center">Avg Call Out</th>
                                <th class="day-col min-w-200px text-center">Avg Walk-Ins</th>
                                <th class="day-col min-w-200px text-center">Avg Followup</th>
                                <th class="col-action">Status</th>
                            </tr>
                        </thead>
                        <!-- Dynamic content will be loaded via JavaScript -->
                    </table>
                    <div id="sales_goal_msg"></div>
                </div>
            </div>
        </div>

        <!-- Journal Goal Set Status -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Journal Goal Set Status</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold date_view_class">{{ date('M-Y') }}</label>
            </div>
        </div>

        <div class="col-lg-12 fade-in-onload">
            <div class="table-wrapper position-relative">
                <div class="table-container">
                    <!-- Journal Table Skeleton -->
                    <div id="journal-skeleton" class="table-skeleton-wrapper" style="display: none;">
                        <table class="skeleton-table sticky_table" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th class="col-staff" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                                    </th>
                                    <th class="col-work" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 120px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="col-action" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @for ($i = 0; $i < 3; $i++)
                                <tr>
                                    <td class="col-staff">
                                        <div class="d-flex align-items-center">
                                            <div class="skeleton skeleton-avatar me-2"></div>
                                            <div style="width: 100%;">
                                                <div class="skeleton skeleton-text w-75"></div>
                                                <div class="skeleton skeleton-text w-50"></div>
                                                <div class="skeleton skeleton-text-sm w-50"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="col-work">
                                        <div class="skeleton skeleton-text w-80"></div>
                                        <div class="skeleton skeleton-text-sm w-60"></div>
                                    </td>
                                    <td class="day-col">
                                        <div class="skeleton-cell">
                                            <div class="skeleton skeleton-badge"></div>
                                            <div class="skeleton skeleton-badge"></div>
                                        </div>
                                    </td>
                                    <td class="col-action">
                                        <div class="skeleton skeleton-status"></div>
                                    </td>
                                </tr>
                                @endfor
                            </tbody>
                        </table>
                    </div>
                    
                    <table
                        class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 min-w-max">
                        <thead>
                            <tr>
                                <th class="col-staff">Staff</th>
                                <th class="col-work">Stage</th>
                                <th class="day-col">No Of Papers</th>
                                <th class="col-action">Action</th>
                            </tr>
                        </thead>
                        <tbody id="journal-goal-table-body">
                            <!-- Dynamic content will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Production Goal Set Status -->
        <div class="col-lg-12 d-flex justify-content-between align-items-center px-3">
            <label class="text-dark fw-medium fs-5">Production Goal Set Status</label>
            <div class="d-flex align-items-baseline gap-1 px-3" style="background: #7466E4; border-radius:5px;">
                <label class="fs-5 text-white fw-bold date_view_class">{{ date('M-Y') }}</label>
            </div>
        </div>

        <div class="col-lg-12 fade-in-onload">
            <div class="table-wrapper position-relative">
                <div class="table-container">
                    <!-- Production Table Skeleton -->
                    <div id="production-skeleton" class="table-skeleton-wrapper" style="display: none;">
                        <table class="skeleton-table sticky_table" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th class="col-staff" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                                    </th>
                                    <th class="col-work" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 120px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="day-col" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                    <th class="col-action" style="background: #099DDA !important;">
                                        <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @for ($i = 0; $i < 3; $i++)
                                <tr>
                                    <td class="col-staff">
                                        <div class="d-flex align-items-center">
                                            <div class="skeleton skeleton-avatar me-2"></div>
                                            <div style="width: 100%;">
                                                <div class="skeleton skeleton-text w-75"></div>
                                                <div class="skeleton skeleton-text w-50"></div>
                                                <div class="skeleton skeleton-text-sm w-50"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="col-work">
                                        <div class="skeleton skeleton-text w-80"></div>
                                        <div class="skeleton skeleton-text-sm w-60"></div>
                                    </td>
                                    <td class="day-col">
                                        <div class="skeleton-cell">
                                            <div class="skeleton skeleton-badge"></div>
                                            <div class="skeleton skeleton-badge"></div>
                                        </div>
                                    </td>
                                    <td class="day-col">
                                        <div class="skeleton-cell">
                                            <div class="skeleton skeleton-badge"></div>
                                            <div class="skeleton skeleton-badge"></div>
                                        </div>
                                    </td>
                                    <td class="col-action">
                                        <div class="skeleton skeleton-status"></div>
                                    </td>
                                </tr>
                                @endfor
                            </tbody>
                        </table>
                    </div>
                    
                    <table
                        class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 min-w-max">
                        <thead>
                            <tr>
                                <th class="col-staff">Staff</th>
                                <th class="col-work">Stage</th>
                                <th class="day-col">Working Hours</th>
                                <th class="day-col">Rework</th>
                                <th class="col-action">Action</th>
                            </tr>
                        </thead>
                        <tbody id="production-goal-table-body">
                            <!-- Dynamic content will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Skeleton Templates -->
    <script type="text/template" id="sales-skeleton-template">
        <div class="table-skeleton-wrapper">
            <table class="skeleton-table sticky_table" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="col-staff" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                        </th>
                        <th class="col-work" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                        </th>
                        @for($i = 0; $i < 8; $i++)
                        <th class="day-col" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 100px; height: 20px; margin: 0 auto;"></div>
                        </th>
                        @endfor
                        <th class="col-action" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @for($i = 0; $i < 5; $i++)
                    <tr>
                        <td class="col-staff">
                            <div class="d-flex align-items-center">
                                <div class="skeleton skeleton-avatar me-2"></div>
                                <div style="width: 100%;">
                                    <div class="skeleton skeleton-text w-75"></div>
                                    <div class="skeleton skeleton-text w-50"></div>
                                    <div class="skeleton skeleton-text-sm w-50"></div>
                                </div>
                            </div>
                        </td>
                        <td class="col-work">
                            <div class="skeleton skeleton-text w-80"></div>
                            <div class="skeleton skeleton-text-sm w-60"></div>
                        </td>
                        @for($j = 0; $j < 8; $j++)
                        <td class="day-col">
                            <div class="skeleton-cell">
                                <div class="skeleton skeleton-badge"></div>
                                <div class="skeleton skeleton-badge"></div>
                            </div>
                        </td>
                        @endfor
                        <td class="col-action">
                            <div class="skeleton skeleton-status"></div>
                        </td>
                    </tr>
                    @endfor
                </tbody>
            </table>
        </div>
    </script>

    <script type="text/template" id="production-skeleton-template">
        <div class="table-skeleton-wrapper">
            <table class="skeleton-table sticky_table" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="col-staff" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                        </th>
                        <th class="col-work" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                        </th>
                        <th class="day-col" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 120px; height: 20px; margin: 0 auto;"></div>
                        </th>
                        <th class="day-col" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                        </th>
                        <th class="col-action" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @for($i = 0; $i < 5; $i++)
                    <tr>
                        <td class="col-staff">
                            <div class="d-flex align-items-center">
                                <div class="skeleton skeleton-avatar me-2"></div>
                                <div style="width: 100%;">
                                    <div class="skeleton skeleton-text w-75"></div>
                                    <div class="skeleton skeleton-text w-50"></div>
                                    <div class="skeleton skeleton-text-sm w-50"></div>
                                </div>
                            </div>
                        </td>
                        <td class="col-work">
                            <div class="skeleton skeleton-text w-80"></div>
                            <div class="skeleton skeleton-text-sm w-60"></div>
                        </td>
                        <td class="day-col">
                            <div class="skeleton-cell">
                                <div class="skeleton skeleton-badge"></div>
                                <div class="skeleton skeleton-badge"></div>
                            </div>
                        </td>
                        <td class="day-col">
                            <div class="skeleton-cell">
                                <div class="skeleton skeleton-badge"></div>
                                <div class="skeleton skeleton-badge"></div>
                            </div>
                        </td>
                        <td class="col-action">
                            <div class="skeleton skeleton-status"></div>
                        </td>
                    </tr>
                    @endfor
                </tbody>
            </table>
        </div>
    </script>

    <script type="text/template" id="journal-skeleton-template">
        <div class="table-skeleton-wrapper">
            <table class="skeleton-table sticky_table" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="col-staff" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 100px; height: 20px;"></div>
                        </th>
                        <th class="col-work" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px;"></div>
                        </th>
                        <th class="day-col" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 120px; height: 20px; margin: 0 auto;"></div>
                        </th>
                        <th class="col-action" style="background: #099DDA !important;">
                            <div class="skeleton-header-cell" style="width: 80px; height: 20px; margin: 0 auto;"></div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @for($i = 0; $i < 5; $i++)
                    <tr>
                        <td class="col-staff">
                            <div class="d-flex align-items-center">
                                <div class="skeleton skeleton-avatar me-2"></div>
                                <div style="width: 100%;">
                                    <div class="skeleton skeleton-text w-75"></div>
                                    <div class="skeleton skeleton-text w-50"></div>
                                    <div class="skeleton skeleton-text-sm w-50"></div>
                                </div>
                            </div>
                        </td>
                        <td class="col-work">
                            <div class="skeleton skeleton-text w-80"></div>
                            <div class="skeleton skeleton-text-sm w-60"></div>
                        </td>
                        <td class="day-col">
                            <div class="skeleton-cell">
                                <div class="skeleton skeleton-badge"></div>
                                <div class="skeleton skeleton-badge"></div>
                            </div>
                        </td>
                        <td class="col-action">
                            <div class="skeleton skeleton-status"></div>
                        </td>
                    </tr>
                    @endfor
                </tbody>
            </table>
        </div>
    </script>

@endsection

@section('page-script')
    <!-- Add Toastr for notifications -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    <script>
        let activeAjax = {};

        function showSkeleton(section) {
            if (section === 'sales') {
                $(".sales_table").hide();
                $("#sales-skeleton").show();
                $("#sales_goal_msg").html('');
            }
            if (section === 'production') {
                $("#production-goal-table-body").parent().hide();
                $("#production-skeleton").show();
            }
            if (section === 'journal') {
                $("#journal-goal-table-body").parent().hide();
                $("#journal-skeleton").show();
            }
            if (section === 'all') {
                $(".sales_table").hide();
                $("#production-goal-table-body").parent().hide();
                $("#journal-goal-table-body").parent().hide();
                $("#sales-skeleton").show();
                $("#production-skeleton").show();
                $("#journal-skeleton").show();
            }
        }

        function hideSkeleton(section) {
            if (section === 'sales') {
                $("#sales-skeleton").hide();
                $(".sales_table").show();
            }
            if (section === 'production') {
                $("#production-skeleton").hide();
                $("#production-goal-table-body").parent().show();
            }
            if (section === 'journal') {
                $("#journal-skeleton").hide();
                $("#journal-goal-table-body").parent().show();
            }
            if (section === 'all') {
                $("#sales-skeleton").hide();
                $("#production-skeleton").hide();
                $("#journal-skeleton").hide();
                $(".sales_table").show();
                $("#production-goal-table-body").parent().show();
                $("#journal-goal-table-body").parent().show();
            }
        }

        function runAjax(key, section, config) {
            if (activeAjax[key]) {
                activeAjax[key].abort();
            }
            showSkeleton(section);
            activeAjax[key] = $.ajax({
                ...config,
                complete: function() {
                    activeAjax[key] = null;
                    hideSkeleton(section);
                }
            });
        }

        function getRoleColor(role) {
            if (!role) return "bg-secondary text-white";
            role = role.toLowerCase();
            if (role.includes("team lead")) {
                return "bg-danger text-white";
            } else if (role.includes("head")) {
                return "bg-success text-white";
            } else {
                return "bg-info text-white";
            }
        }

        // SALES GOAL TABLE - STAFF VIEW
        function fetchsalesStaff(month, year, dept = null) {
            runAjax('staff', 'sales', {
                url: "{{ route('staff_goal') }}",
                type: "GET",
                data: {
                    month_id: month,
                    year: year,
                    department_id: dept ?? 1
                },
                success: function(response) {
                    if (!response.data || response.data.length == 0) {
                        $(".sales_table").hide();
                        $("#sales_goal_msg").html(
                            '<p class="text-muted text-center pt-5">No goals found for this Department.</p>'
                        );
                        return;
                    } else {
                        $(".sales_table").show();
                        $("#sales_goal_msg").html('');
                    }

                    if (response.status === 200 && Array.isArray(response.data) && response.data.length > 0) {
                        let tableHtml = `<thead><tr>`;
                        let goalsetHtml = '';
                        const firstStaff = response.data[0];

                        tableHtml += `<th class="col-staff">Staff</th>`;
                        tableHtml += `<th class="col-work">Stage</th>`;

                        const checkFields = [{
                                check: 'conversion_check',
                                label: 'Conversion',
                                width: 'min-w-200px'
                            },
                            {
                                check: 'cr_check',
                                label: 'CR',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'abv_check',
                                label: 'ABV',
                                width: 'min-w-400px text-center'
                            },
                            {
                                check: 'acv_check',
                                label: 'ACV',
                                width: 'min-w-400px text-center'
                            },
                            {
                                check: 'avg_call_out_check',
                                label: 'Avg Call Out',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'no_of_walk_check',
                                label: 'Avg Walk-Ins',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'no_of_followup_check',
                                label: 'Avg Followup',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'working_hours_check',
                                label: 'Working hours',
                                width: 'min-w-350px text-center'
                            },
                            {
                                check: 'rework_check',
                                label: 'Rework',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'no_of_papers_check',
                                label: 'No Of Papers',
                                width: 'min-w-200px text-center'
                            },
                            {
                                check: 'harvesting_percentage_check',
                                label: 'Harvesting (%)',
                                width: 'min-w-200px text-center'
                            }
                        ];

                        checkFields.forEach(field => {
                            if (firstStaff[field.check] == 1) {
                                tableHtml += `<th class="day-col ${field.width}">${field.label}</th>`;
                            }
                        });

                        tableHtml += `<th class="col-action">Status</th></tr></thead><tbody id="goal_set_container">`;

                        let achievedCount = 0;
                        let Arr_sts = [];

                        response.data.forEach(function(staff) {
                            goalsetHtml += `
                                <tr>
                                    <td class="col-staff">
                                        <div class="d-flex align-items-center">
                                            <div class="symbol symbol-35px me-2">
                                                <div class="image-input image-input-circle">
                                                    ${staff.staff_image}
                                                </div>
                                            </div>
                                            <div class="ms-2">
                                                <div class="mb-0">
                                                    <span class="fs-6 fw-bold">${staff.staff_name}</span>
                                                </div>
                                                <div class="d-block">
                                                    <label class="text-dark fs-7 d-block">${staff.department_name}</label>
                                                </div>
                                                <div class="d-block">
                                                    <label class="text-black fs-8 badge ${getRoleColor(staff.role_name)}">${staff.role_name}</label>
                                                </div>
                                                ${staff.role_name && staff.role_name.toLowerCase().includes("team lead") ? `
                                                    <div class="d-flex align-items-center mt-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${staff.role_name} Target">
                                                        <span class="badge rounded-pill px-2 py-1" style="font-size: 0.65rem; background: linear-gradient(to right, #00a9ff, #ff00ea); color: white;">
                                                            ${staff.sales_lead_checks == 1 ? 'Self' : 'Team'}
                                                        </span>
                                                    </div>
                                                ` : ''}
                                            </div>
                                        </div>
                                    </td>
                                    <td class="col-work">
                                        ${staff.score_td}
                                    </td>
                            `;

                            let staffAchieved = true;
                            let allOverZero = true;

                            checkFields.forEach(field => {
                                if (staff[field.check] == 1) {
                                    const fieldName = field.check.replace('_check', '');
                                    const fieldNameActual = fieldName + '_actual';
                                    const overAllValue = staff[fieldName] ?? '';
                                    const actualValue = staff[fieldNameActual] ?? '';

                                    const Over = parseFloat(overAllValue) || 0;
                                    const Act = parseFloat(actualValue) || 0;

                                    let Bgc = 'danger';
                                    let BGB = '';

                                    if (Over === 0 && Act === 0) {
                                        Bgc = 'danger';
                                    } else if (Act === 0) {
                                        Bgc = 'danger';
                                        staffAchieved = false;
                                    } else if (Over === 0) {
                                        Bgc = 'danger';
                                        BGB = 'style="background-color: #c6fdeb;"';
                                    } else if (Over === Act || Act > Over) {
                                        Bgc = 'success';
                                        BGB = 'style="background-color: #c6fdeb;"';
                                    } else if (Act < Over) {
                                        staffAchieved = false;
                                    }

                                    if (fieldName === 'rework') {
                                        BGB = '';
                                        if (Over < Act) {
                                            Bgc = 'danger';
                                            staffAchieved = false;
                                        } else {
                                            BGB = 'style="background-color: #c6fdeb;"';
                                        }
                                    }

                                    if (Over > 0) {
                                        allOverZero = false;
                                    }

                                    goalsetHtml += `
                                        <td class="day-col" ${BGB}>
                                            <div class="row g-0">
                                                <div class="col-6 pe-1">
                                                    <div class="d-flex flex-column">
                                                        <small class="text-muted">Target</small>
                                                        <span class="fw-bold badge bg-label-secondary px-2 py-2" 
                                                            data-bs-toggle="tooltip" title="${formatNumber(Over)} Target">
                                                            ${formatNumber(Over)}
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-6 ps-1">
                                                    <div class="d-flex flex-column">
                                                        <small class="text-muted">Actual</small>
                                                        <span class="fw-bold badge bg-label-${Bgc} px-2 py-2" 
                                                            data-bs-toggle="tooltip" title="${formatNumber(Act)} Actual">
                                                            ${formatNumber(Act)}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    `;
                                }
                            });

                            let status = '';
                            let sts_color = '';

                            if (staff.goal_achievements == true) {
                                if (allOverZero) {
                                    status = 'Not Assigned';
                                    sts_color = 'danger';
                                } else {
                                    status = staffAchieved ? 'Goal Achieved' : 'On Progress';
                                    sts_color = staffAchieved ? 'success' : 'info';
                                    if (staffAchieved) achievedCount++;
                                }
                            } else {
                                status = staffAchieved ? '10X Achieved' : 'On Progress';
                                sts_color = staffAchieved ? 'success' : 'info';
                            }

                            if (staff.goal_completed == 1) {
                                if (!staffAchieved && staff.status_10x != 1) {
                                    status = 'Not Achieved';
                                    sts_color = 'danger';
                                } else {
                                    status = '10X Achieved';
                                    sts_color = 'success';
                                }

                                if (staff.sales_lead_checks != 1) {
                                    const role = staff.role_name.toLowerCase();
                                    if (role.includes("team lead")) {
                                        Arr_sts.push(status);
                                        if (Arr_sts.includes("On Progress") || Arr_sts.includes("Not Achieved")) {
                                            status = 'Team Not Achieved';
                                            sts_color = 'warning text-black';
                                        }
                                    }
                                }
                            }

                            goalsetHtml += `
                                <td class="col-action">
                                    <span class="badge bg-${sts_color} fs-6 p-2 w-100">${status}</span>
                                </td>
                            </tr>`;
                        });

                        tableHtml += goalsetHtml + `</tbody>`;
                        $(".sales_table").html(tableHtml).show();
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }
                },
                error: function(error) {
                    console.error('Error fetching staff:', error);
                    $(".sales_table").hide();
                    $("#sales_goal_msg").html(
                        '<p class="text-danger text-center pt-5">Failed to load sales data. Please try again.</p>'
                    );
                }
            });
        }

        // PRODUCTION GOAL TABLE - STAFF VIEW
        function fetchProductionStaff(month, year, dept = 2) {
            runAjax('production_staff', 'production', {
                url: "{{ route('staff_goal') }}",
                type: "GET",
                data: {
                    month_id: month,
                    year: year,
                    department_id: dept
                },
                success: function(response) {
                    if (!response.data || response.data.length == 0) {
                        $("#production-goal-table-body").html(
                            '<tr><td colspan="5" class="text-center py-4"><div class="text-muted">No production goals found for this month.</div></td></tr>'
                        );
                        return;
                    }

                    let tableBodyHtml = '';

                    response.data.forEach(function(staff) {
                        let status = '';
                        let statusClass = '';
                        let staffAchieved = true;
                        let allOverZero = true;

                        const workingHoursTarget = parseFloat(staff.working_hours) || 0;
                        const workingHoursActual = parseFloat(staff.working_hours_actual) || 0;
                        const reworkTarget = parseFloat(staff.rework) || 0;
                        const reworkActual = parseFloat(staff.rework_actual) || 0;

                        if (workingHoursTarget > 0) allOverZero = false;
                        if (reworkTarget > 0) allOverZero = false;

                        if (workingHoursActual < workingHoursTarget) {
                            staffAchieved = false;
                        }
                        if (reworkActual > reworkTarget) {
                            staffAchieved = false;
                        }

                        if (staff.goal_achievements == true) {
                            if (allOverZero) {
                                status = 'Not Assigned';
                                statusClass = 'danger';
                            } else {
                                status = staffAchieved ? 'Goal Achieved' : 'On Progress';
                                statusClass = staffAchieved ? 'success' : 'info';
                            }
                        } else {
                            status = staffAchieved ? '10X Achieved' : 'On Progress';
                            statusClass = staffAchieved ? 'success' : 'info';
                        }

                        if (staff.goal_completed == 1) {
                            if (!staffAchieved && staff.status_10x != 1) {
                                status = 'Not Achieved';
                                statusClass = 'danger';
                            } else {
                                status = '10X Achieved';
                                statusClass = 'success';
                            }
                        }

                        tableBodyHtml += `
                            <tr>
                                <td class="col-staff">
                                    <div class="d-flex align-items-center">
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle">
                                                ${staff.staff_image}
                                            </div>
                                        </div>
                                        <div class="ms-2">
                                            <div class="mb-0">
                                                <span class="fs-6 fw-bold">${staff.staff_name}</span>
                                            </div>
                                            <div class="d-block">
                                                <label class="text-dark fs-7 d-block">${staff.department_name}</label>
                                            </div>
                                            <div class="d-block">
                                                <label class="text-black fs-8 badge ${getRoleColor(staff.role_name)}">${staff.role_name}</label>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="col-work">
                                    ${staff.score_td}
                                </td>
                                <td class="day-col">
                                    <div class="d-flex flex-column align-items-center">
                                        <span class="badge bg-label-secondary mb-1 p-2 w-75">
                                            <small>Target</small><br>
                                            <strong>${formatNumber(workingHoursTarget)}</strong>
                                        </span>
                                        <span class="badge ${workingHoursActual >= workingHoursTarget ? 'bg-label-success' : 'bg-label-danger'} p-2 w-75">
                                            <small>Actual</small><br>
                                            <strong>${formatNumber(workingHoursActual)}</strong>
                                        </span>
                                    </div>
                                </td>
                                <td class="day-col">
                                    <div class="d-flex flex-column align-items-center">
                                        <span class="badge bg-label-secondary mb-1 p-2 w-75">
                                            <small>Target</small><br>
                                            <strong>${formatNumber(reworkTarget)}</strong>
                                        </span>
                                        <span class="badge ${reworkActual <= reworkTarget ? 'bg-label-success' : 'bg-label-danger'} p-2 w-75">
                                            <small>Actual</small><br>
                                            <strong>${formatNumber(reworkActual)}</strong>
                                        </span>
                                    </div>
                                </td>
                                <td class="col-action">
                                    <span class="badge bg-${statusClass} fs-6 p-2 w-100">${status}</span>
                                </td>
                            </tr>
                        `;
                    });

                    $("#production-goal-table-body").html(tableBodyHtml);
                    $('[data-bs-toggle="tooltip"]').tooltip();
                },
                error: function(error) {
                    console.error('Error fetching production staff:', error);
                    $("#production-goal-table-body").html(
                        '<tr><td colspan="5" class="text-center py-4"><div class="text-danger">Failed to load production data. Please try again.</div></td></tr>'
                    );
                }
            });
        }

        // JOURNAL GOAL TABLE - STAFF VIEW
        function fetchJournalStaff(month, year, dept = 14) {
            runAjax('journal_staff', 'journal', {
                url: "{{ route('staff_goal') }}",
                type: "GET",
                data: {
                    month_id: month,
                    year: year,
                    department_id: dept
                },
                success: function(response) {
                    if (!response.data || response.data.length == 0) {
                        $("#journal-goal-table-body").html(
                            '<tr><td colspan="4" class="text-center py-4"><div class="text-muted">No journal goals found for this month.</div></td></tr>'
                        );
                        return;
                    }

                    let tableBodyHtml = '';

                    response.data.forEach(function(staff) {
                        let status = '';
                        let statusClass = '';
                        let staffAchieved = true;
                        let allOverZero = true;

                        const papersTarget = parseFloat(staff.no_of_papers) || 0;
                        const papersActual = parseFloat(staff.no_of_papers_actual) || 0;

                        if (papersTarget > 0) allOverZero = false;

                        if (papersActual < papersTarget) {
                            staffAchieved = false;
                        }

                        if (staff.goal_achievements == true) {
                            if (allOverZero) {
                                status = 'Not Assigned';
                                statusClass = 'danger';
                            } else {
                                status = staffAchieved ? 'Goal Achieved' : 'On Progress';
                                statusClass = staffAchieved ? 'success' : 'info';
                            }
                        } else {
                            status = staffAchieved ? '10X Achieved' : 'On Progress';
                            statusClass = staffAchieved ? 'success' : 'info';
                        }

                        if (staff.goal_completed == 1) {
                            if (!staffAchieved && staff.status_10x != 1) {
                                status = 'Not Achieved';
                                statusClass = 'danger';
                            } else {
                                status = '10X Achieved';
                                statusClass = 'success';
                            }
                        }

                        tableBodyHtml += `
                            <tr>
                                <td class="col-staff">
                                    <div class="d-flex align-items-center">
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle">
                                                ${staff.staff_image}
                                            </div>
                                        </div>
                                        <div class="ms-2">
                                            <div class="mb-0">
                                                <span class="fs-6 fw-bold">${staff.staff_name}</span>
                                            </div>
                                            <div class="d-block">
                                                <label class="text-dark fs-7 d-block">${staff.department_name}</label>
                                            </div>
                                            <div class="d-block">
                                                <label class="text-black fs-8 badge ${getRoleColor(staff.role_name)}">${staff.role_name}</label>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="col-work">
                                    ${staff.score_td}
                                </td>
                                <td class="day-col">
                                    <div class="d-flex flex-column align-items-center">
                                        <span class="badge bg-label-secondary mb-1 p-2 w-75">
                                            <small>Target</small><br>
                                            <strong>${papersTarget}</strong>
                                        </span>
                                        <span class="badge ${papersActual >= papersTarget ? 'bg-label-success' : 'bg-label-danger'} p-2 w-75">
                                            <small>Actual</small><br>
                                            <strong>${papersActual}</strong>
                                        </span>
                                    </div>
                                </td>
                                <td class="col-action">
                                    <span class="badge bg-${statusClass} fs-6 p-2 w-100">${status}</span>
                                </td>
                            </tr>
                        `;
                    });

                    $("#journal-goal-table-body").html(tableBodyHtml);
                    $('[data-bs-toggle="tooltip"]').tooltip();
                },
                error: function(error) {
                    console.error('Error fetching journal staff:', error);
                    $("#journal-goal-table-body").html(
                        '<tr><td colspan="4" class="text-center py-4"><div class="text-danger">Failed to load journal data. Please try again.</div></td></tr>'
                    );
                }
            });
        }

        // Single comprehensive function for dashboard data loading
        function loadDashboardData(selectedDate) {
            $('#dashboard-loader').show();
            $('#dashboard-container').addClass('data-loading');
            
            // Show all skeletons
            showSkeleton('all');

            if (!/^[A-Za-z]{3}-\d{4}$/.test(selectedDate)) {
                console.error('Invalid date format. Expected: MMM-YYYY');
                selectedDate = new Date().toLocaleString('default', {
                    month: 'short'
                }) + '-' + new Date().getFullYear();
            }

            $('.date_view_class').html(selectedDate);

            $.ajax({
                url: "{{ route('ceo.dashboard.data') }}",
                method: "GET",
                data: {
                    date_filter: selectedDate,
                    _token: "{{ csrf_token() }}"
                },
                dataType: "json",
                success: function(response) {
                    if (response.success && response.data) {
                        const data = response.data;

                        // BUSINESS GOAL SET
                        if (data.business_goal) {
                            $('#business-target').text(formatCurrency(data.business_goal.target || 0));
                            $('#business-actual').text(formatCurrency(data.business_goal.actual || 0));
                            $('#post-sale-target').text(data.business_goal.post_sale_target || 0);
                            $('#post-sale-actual').text(data.business_goal.post_sale_actual || 0);
                            $('#pre-sale-target').text(data.business_goal.pre_sale_target || 0);
                            $('#pre-sale-actual').text(data.business_goal.pre_sale_actual || 0);
                        }

                        // SALES TARGETS
                        if (data.sales_targets) {
                            $('#conversion-target').text(data.sales_targets.conversion_target || 0);
                            $('#conversion-actual').text(data.sales_targets.conversion_actual || 0);
                            $('#conversion-rate-target').text(formatPercentage(data.sales_targets.conversion_rate_target || 0));
                            $('#conversion-rate-actual').text(formatPercentage(data.sales_targets.conversion_rate_actual || 0));
                            $('#avg-business-target').text(formatCurrency(data.sales_targets.avg_business_target || 0));
                            $('#avg-business-actual').text(formatCurrency(data.sales_targets.avg_business_actual || 0));
                            $('#avg-conversion-target').text(formatCurrency(data.sales_targets.avg_conversion_target || 0));
                            $('#avg-conversion-actual').text(formatCurrency(data.sales_targets.avg_conversion_actual || 0));
                        }

                        // ALERT SYSTEM
                        if (data.alerts) {
                            $('#attendance-target').text(data.alerts.attendance_target || 0);
                            $('#attendance-actual').text(data.alerts.attendance_actual || 0);
                            $('#outstanding-count').text(data.alerts.outstanding_count || 0);
                            $('#low-mpc-count').text(data.alerts.low_mpc_count || 0);
                            $('#payment_verification').text(data.alerts.customer_not_started || 0);
                        }

                        // APPROVAL PENDING
                        if (data.approval_pending) {
                            $('#drop-waiting').text(data.approval_pending.drop_waiting || 0);
                            $('#refund-waiting').text(data.approval_pending.refund_waiting || 0);
                            $('#accounts-confirmation').text(data.approval_pending.accounts_confirmation || 0);
                            $('#login-approval').text(data.approval_pending.login_approval || 0);
                        }

                        // LEAD STATUS
                        if (data.lead_status) {
                            $('#total-leads').text(data.lead_status.total || 0);
                            $('#active-leads').text(data.lead_status.active || 0);
                            $('#spam-leads').text(data.lead_status.spam || 0);
                            $('#dead-leads').text(data.lead_status.dead || 0);
                            $('#converted-customers').text(data.lead_status.converted || 0);
                        }

                        // SERVICE STATUS
                        if (data.service_status) {
                            $('#total-service').text(data.service_status.total || 0);
                            $('#staff-allocated').text(data.service_status.staff_allocated || 0);
                            $('#milestone-pending').text(data.service_status.milestone_pending || 0);
                            $('#unmapped-milestone').text(data.service_status.unmapped_milestone || 0);
                        }

                        // JOURNAL STATUS
                        if (data.journal_status) {
                            $('#with-editor').text(data.journal_status.with_editor || 0);
                            $('#under-review').text(data.journal_status.under_review || 0);
                            $('#rejected').text(data.journal_status.rejected || 0);
                            $('#revision').text(data.journal_status.revision || 0);
                            $('#eproofing').text(data.journal_status.eproofing || 0);
                            $('#accepted').text(data.journal_status.accepted || 0);
                            $('#submitted').text(data.journal_status.submitted || 0);
                            $('#published').text(data.journal_status.published || 0);
                        }

                        // REVISION STATUS
                        if (data.revision_status) {
                            $('#jtl-verification').text(data.revision_status.jtl_verification || 0);
                            $('#revision-staff-assigned').text(data.revision_status.staff_assigned || 0);
                            $('#revision-inprogress').text(data.revision_status.inprogress || 0);
                            $('#revision-completed').text(data.revision_status.completed || 0);
                            $('#waiting-documentation').text(data.revision_status.waiting_documentation || 0);
                            $('#pc-not-assign').text(data.revision_status.pc_not_assign || 0);
                            $('#revision-rework').text(data.revision_status.rework || 0);
                            $('#staff-not-assign').text(data.revision_status.staff_not_assign || 0);
                            $('#pc-pending-verification').text(data.revision_status.pc_pending_verification || 0);
                            $('#jtl-pending-verification').text(data.revision_status.jtl_pending_verification || 0);
                        }

                        fetchsalesStaff(data.month, data.year, 1);
                        fetchProductionStaff(data.month, data.year, 2);
                        fetchJournalStaff(data.month, data.year, 14);
                    } else {
                        loadFromCache(selectedDate);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Dashboard load error:', error);
                    loadFromCache(selectedDate);
                },
                complete: function() {
                    $('#dashboard-loader').hide();
                    $('#dashboard-container').removeClass('data-loading');
                    initializeTooltips();
                }
            });
        }

        function loadFromCache(selectedDate) {
            const cachedData = localStorage.getItem('dashboard_cache_' + selectedDate);
            if (cachedData) {
                try {
                    const data = JSON.parse(cachedData);
                    // Update UI with cached data
                } catch (e) {
                    console.error('Failed to parse cached data:', e);
                }
            }
        }

        function formatCurrency(amount) {
            if (typeof amount !== 'number') amount = parseFloat(amount) || 0;
            return '₹ ' + new Intl.NumberFormat('en-IN').format(Math.round(amount));
        }

        function formatNumber(amount) {
            if (typeof amount !== 'number') amount = parseFloat(amount) || 0;
            return new Intl.NumberFormat('en-IN').format(amount.toFixed(2));
        }

        function formatPercentage(num) {
            if (typeof num !== 'number') num = parseFloat(num) || 0;
            return num.toFixed(2) + '%';
        }

        function initializeTooltips() {
            if (typeof bootstrap !== 'undefined') {
                const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                tooltipTriggerList.forEach(tooltipTriggerEl => {
                    new bootstrap.Tooltip(tooltipTriggerEl);
                });
            }
        }

        // Initialize datepicker and event listener
        document.addEventListener("DOMContentLoaded", function() {
            $('.month_filter_common_class').datepicker({
                format: "M-yyyy",
                startView: "months",
                minViewMode: "months",
                autoclose: true,
                orientation: "bottom",
                templates: {
                    leftArrow: '<i class="mdi mdi-chevron-left"></i>',
                    rightArrow: '<i class="mdi mdi-chevron-right"></i>'
                }
            }).on('changeMonth', function(e) {
                loadDashboardData($(this).val());
            });

            loadDashboardData($('#ovr_year_fill').val());
        });
    </script>
@endsection