@extends('layouts/layoutMaster')

@section('title', 'Individual Add Payments')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')
<!-- Users List Table -->
<style>
    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>
 @php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ?? 16;
@endphp
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Invoice</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-1">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Customer Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Manage Customer</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <div class="col-lg-6">
                <!-- <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Registered Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">07-Mar-2025</label>
                </div> -->
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer Id</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{$customer->customer_id }}</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{$customer->cus_name }}</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Mobile No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{$customer->cus_mobile ?? '-' }}</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Email ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{$customer->cus_email_id ?? '-'}}</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Estimate / Validity Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-semibold">
                        <label id="estimate_date">16-Jun-2025</label>
                        <label class="ms-1 me-1 text-dark fw-bold">/</label>
                        <label class="text-danger" id="validity_date">19-Jun-2025</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Currency Format</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="currency_format"></label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <div class="col-lg-7 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Service Title<span class="text-danger">*</span></label>
                        <select id="proposal_id" class="select3 form-select" data-style="btn-default" data-live-search="true" onchange="change_proposal_func()">
                            
                            @if(isset($proposal_list))
                            @foreach($proposal_list as $proposal)
                            <option value="{{$proposal->sno}}">{{$proposal->service_title}}</option>
                            @endforeach
                            @endif
                        </select>
                    </div>
                   
                </div>
                <div class="row mb-4">
                    <div class="col-lg-12 d-flex align-items-center justify-content-between flex-wrap">
                        <div class="badge bg-secondary fw-semibold fs-6 rounded py-2 px-3">
                            <label class="text-white mb-2 fs-4 fw-semibold">Total Amount</label>
                            <div class="d-block">
                                <label class="text-white fs-4 fw-semibold"><span class="currency_symbol"></span> <span id="total_amount_label"></span></label>
                            </div>
                        </div>
                        <div class="badge bg-success fw-semibold fs-6 rounded py-2 px-3">
                            <label class="text-white mb-2 fs-4 fw-semibold">Paid Amount</label>
                            <div class="d-block">
                                <label class="text-white fs-4 fw-semibold"><span class="currency_symbol"></span> <span id="paid_amount_label"></span></label>
                            </div>
                        </div>
                        <div class="badge bg-danger fw-semibold fs-6 rounded py-2 px-3">
                            <label class="text-white mb-2 fs-4 fw-semibold">Balance Amount</label>
                            <div class="d-block">
                                <label class="text-white fs-4 fw-semibold"><span class="currency_symbol"></span> <span id="balance_amount_label"></span></label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table align-middle table-row-dashed gy-1 gs-2">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Slot</th>
                                <th class="min-w-100px">Scheduled <br>Amount</th>
                                <th class="min-w-100px">Payable<br>Amount</th>
                                <th class="min-w-100px">Paid Amount</th>
                                <th class="min-w-100px">Balance Amount</th>
                                <th class="min-w-100px">Paid Date</th>
                                <th class="min-w-100px">Status</th>
                                <th class="min-w-150px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-6" id="slot_pay_list">
                            
                          
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>




<!--begin::Modal - Send Invoice-->
<div class="modal fade" id="kt_modal_send_invoice" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Send Invoice</h3>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="send_lead_name">Priya</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Proposal No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="send_invoice_no">PRO-003669/03/2025</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Slot</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="send_slot_name">Slot 1</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold mt-2">Payable Amount<span class="text-danger">*</span></label>
                    <label class="col-1 text-black fs-6 fw-bold mt-2">:</label>
                    <div class="col-7 text-black fs-6 fw-bold">
                        <input type="text" class="form-control fw-semibold text-black" placeholder="Enter Payable Amount" value="" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" id="slot_amount" readonly/>
                        <div class="text-danger" id="slot_amount_err"></div>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-danger fs-6 fw-semibold mt-2">Invoice Due Date<span class="text-danger">*</span></label>
                    <label class="col-1 text-black fs-6 fw-bold mt-2">:</label>
                    <div class="col-7 text-black fs-6 fw-bold">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="invoice_due_date" placeholder="Select Date" class="form-control fw-bold text-danger common_date_class" value="<?php echo date('d-M-Y')?>" readonly>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Total Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-7 text-black fs-6 fw-bold">
                        <label class="badge bg-secondary text-white fs-5 fw-bold"><span class="currency_symbol"></span> <span id="send_invoice_total"></span></label>
                    </div>
                </div>
                 <div class="d-flex  gap-2 mt-4 mb-1">
                     <label class="text-black mb-1 fs-6 fw-semibold" id="old_cus_check_text">Skip Communication</label>
                    <input class="form-check-input" type="checkbox" id="old_cus_check" name="old_cus_check" value="1" checked onclick="old_cus_check_func();">
                </div>
                <div class="communication_check">
                    <div class="d-flex align-items-center justify-content-between mt-4 mb-1">
                        <div class="text-black fs-6 fw-semibold mb-1">Choose Communication</div>
                        <div class="badge bg-label-primary rounded-pill mb-1">
                            <i class="mdi mdi-link-variant mdi-14px me-1"></i>
                            <span class="align-middle fw-semibold">Invoice Generated</span>
                        </div>
                    </div>
                </div>
                <div class="row communication_check">
                    <div class="col-lg-12 mb-3">
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_whats_app" onclick="send_invoice_whatsapp_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/whatsapp.png')}}" alt="whatsapp" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Whats App</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_email" onclick="send_invoice_email_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/email.png')}}" alt="email" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Email</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_message" onclick="send_invoice_message_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/message.png')}}" alt="message" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Message</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                         <div class="text-danger" id="communication_err"></div>
                    </div>
                    <!--<div class="col-lg-12 mb-3">-->
                    <!--    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>-->
                    <!--    <textarea class="form-control" rows="3" placeholder="Enter Description" id="description"></textarea>-->
                    <!--</div>-->
                </div>
                <input type="hidden" name="send_invoice_id" id="send_invoice_id">
                <input type="hidden" name="send_invoice_whatsapp" id="send_invoice_whatsapp" value="0">
                <input type="hidden" name="send_invoice_email" id="send_invoice_email" value="0">
                <input type="hidden" name="send_invoice_sms" id="send_invoice_sms" value="0">
                <input type="hidden" name="send_proposal_id" id="send_proposal_id" >
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <a href="javascript:" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                    <button type="button" id="sendMessageBtn" class="btn btn-primary">Send Invoice</a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Send Invoice-->


<!--begin::Modal - Pay Now-->
<div class="modal fade" id="kt_modal_paynow_manual" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Payments Process</h3>
                </div>
                <div class="row mb-1">
                    <div class="col-lg-6 mb-1">
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold">Priya</label>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Proposal No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold">PRO-003669/03/2025</label>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Slot</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold">Slot 2</label>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-1">
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Total Amount</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7 text-black fs-6 fw-bold">
                                <label class="badge bg-secondary text-white fs-6 fw-semibold">&#8377; 1,11,574</label>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Balance Amount</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7 text-black fs-6 fw-bold">
                                <label class="badge bg-danger text-white fs-6 fw-semibold">&#8377; 56,574</label>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Payable Amount</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7 text-black fs-6 fw-bold">
                                <label class="badge bg-warning text-black fs-6 fw-semibold">&#8377; 56,574</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center flex-wrap py-2">
                    <div class="fv-row mb-4 me-2">
                        <label class="form-check form-check-inline form-check-solid is-invalid">
                            <input class="form-check-input mt-1" name="payment_mode" type="radio" id="cus_cash_chk" checked onclick="cus_payment_chk_func('cash');">
                            <span class="fw-semibold fs-5 text-black">Cash</span>
                        </label>
                    </div>
                    <div class="fv-row mb-4 me-2">
                        <label class="form-check form-check-inline form-check-solid is-invalid">
                            <input class="form-check-input mt-1" name="payment_mode" type="radio" id="cus_cheque_chk" onclick="cus_payment_chk_func('cheque');">
                            <span class="fw-semibold fs-5 text-black">Bank</span>
                        </label>
                    </div>
                    <div class="fv-row mb-4 me-2">
                        <label class="form-check form-check-inline form-check-solid is-invalid">
                            <input class="form-check-input mt-1" name="payment_mode" type="radio" id="cus_gpay_chk" onclick="cus_payment_chk_func('google_pay');">
                            <span class="fw-semibold fs-5 text-black">Google Pay</span>
                        </label>
                    </div>
                </div>
                <div id="cus_cash_tbox" style="display: block;">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black fs-6 fw-semibold mb-1">Cash Amount</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">&#8377; 56,574</div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                </div>
                <div id="cus_cheque_tbox" style="display: none;">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black fs-6 fw-semibold required mb-1">Bank Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-solid" placeholder="Enter Bank Name">
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black fs-6 fw-semibold required mb-1">Account No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-solid" placeholder="Enter Account No">
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black fs-6 fw-semibold required mb-1">Cheque No</label>
                            <input type="text" class="form-control form-control-solid" placeholder="Enter Cheque No">
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black fs-6 fw-semibold required mb-1">Amount</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">&#8377; 56,574</div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black fs-6 fw-semibold required mb-1">Receipt ID<span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-solid" placeholder="Enter Receipt ID">
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                </div>
                <div id="cus_gpay_tbox" style="display: none;">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black fs-6 fw-semibold required mb-1">Mobile No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-solid" placeholder="Enter Mobile No">
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black fs-6 fw-semibold required mb-1">Receipt ID<span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-solid" placeholder="Enter Receipt ID">
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black fs-6 fw-semibold required mb-1">UPI ID</label>
                            <input type="text" class="form-control form-control-solid" placeholder="Enter UPI ID">
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black fs-6 fw-semibold required mb-1">Amount</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">&#8377; 56,574</div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" placeholder="Enter Description"></textarea>
                        </div>
                        <!-- <div class="col-lg-12 mb-2">
                            <label class="text-dark fs-6 fw-semibold mb-1">Other Attachment<span class="text-danger">*</span></label>
                            <div action="/upload" class="dropzone needsclick dz-clickable" id="dropzone-multi">
                                <div class="dz-message needsclick fs-6">
                                    <div class="text-center me-3">Drop files here or click to upload</div>
                                </div>

                            </div>
                        </div> -->
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <a href="javascript:" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                    <a href="javascript:;" class="btn btn-primary">Paid</a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Pay Now-->


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
     
        .tags-inline.tagify__dropdown {
            z-index: 9999 !important; /* Ensure it is higher than the modal's z-index */
        }
    </style>
    
     <script>
      function sort_filter(val) {
        if (val != "") {
          $('.sorting_filter_class').val(val);
          $('#filter_form').submit();
        } else {
          $('.sorting_filter_class').val(10);
          $('#filter_form').submit();
        }
      }
    </script>



    <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>



<script>
    function send_invoice_whatsapp_func() {
       const box = document.getElementById("sd_prpl_whats_app");
        const input = document.getElementById("send_invoice_whatsapp");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_invoice_email_func() {
        const box = document.getElementById("sd_prpl_email");
        const input = document.getElementById("send_invoice_email");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_invoice_message_func() {
        const box = document.getElementById("sd_prpl_message");
        const input = document.getElementById("send_invoice_sms");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

</script>
<script>
    function cus_payment_chk_func(val) {
        var cus_cash_tbox = document.getElementById('cus_cash_tbox');
        var cus_cheque_tbox = document.getElementById('cus_cheque_tbox');
        var cus_gpay_tbox = document.getElementById('cus_gpay_tbox');

        if (val == 'cash') {
            cus_cash_tbox.style.display = "block";
            cus_cheque_tbox.style.display = "none";
            cus_gpay_tbox.style.display = "none";
        } else if (val == 'cheque') {
            cus_cash_tbox.style.display = "none";
            cus_cheque_tbox.style.display = "block";
            cus_gpay_tbox.style.display = "none";
        } else if (val == 'google_pay') {
            cus_cash_tbox.style.display = "none";
            cus_cheque_tbox.style.display = "none";
            cus_gpay_tbox.style.display = "block";
        } else {
            cus_cash_tbox.style.display = "none";
            cus_cheque_tbox.style.display = "none";
            cus_gpay_tbox.style.display = "none";
        }
    };
</script>
<script>
    function send_invoice_func(id,email,mobile,name,total,slotAmount,slot_name,proposal_id,proposal_sno){
        $('#send_lead_name').text(name);
        $('#send_invoice_no').text(proposal_id);
        $('#send_slot_name').text(slot_name);
        $('#send_invoice_total').text(formatCurrency(total));
        $('#slot_amount').val(slotAmount);
        $('#send_invoice_id').val(id);
        $('#send_proposal_id').val(proposal_sno);
        console.log(mobile)
         if (mobile && mobile.trim() !== "" && mobile.trim().toLowerCase() !== "null" && mobile.trim().toLowerCase() !== "undefined") {
            $('#sd_prpl_message').removeClass('d-none');
            $('#sd_prpl_whats_app').removeClass('d-none');
        } else {
            $('#sd_prpl_message').addClass('d-none');
            $('#sd_prpl_whats_app').addClass('d-none');
        }
    
        // Email check (show/hide Email button)
        if (email && email.trim() !== "" && email.trim().toLowerCase() !== "null" && email.trim().toLowerCase() !== "undefined") {
            $('#sd_prpl_email').removeClass('d-none');
        } else {
            $('#sd_prpl_email').addClass('d-none');
        }
    }
</script>


<script>
    var branch_minimum_amount =`{{$branch_data->min_amnt_receive ?? 0 }}`;


     $('#sendMessageBtn').on('click', function(e) {
        var err =0;
        e.preventDefault();
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        const proposal_id = $('#send_proposal_id').val();
        let sms = $('#send_invoice_sms').val();
        let email = $('#send_invoice_email').val();
        let whatsapp = $('#send_invoice_whatsapp').val();
        // const description = $('#description').val();

       let slotAmount=  $('#slot_amount').val();
       let balance_amount=  $('#balance_amount').val();
       let invoice_due_date=  $('#invoice_due_date').val();
       const slot_id=   $('#send_invoice_id').val();

       
        slotAmount = parseFloat(slotAmount);
        balance_amount = parseFloat(balance_amount);
        branch_minimum_amount = parseFloat(branch_minimum_amount);

        if (isNaN(slotAmount) || slotAmount <= 0) {
            $('#slot_amount_err').text('Enter Slot Amount');
            err++;
        }
        // else if (slotAmount < branch_minimum_amount) {
        //     $('#slot_amount_err').text('Slot Amount must be Greater than ' + branch_minimum_amount);
        //     err++;
        // }
        else if (slotAmount > balance_amount) {
              $('#slot_amount_err').text('Slot Amount must be Less Than Equal to ' + balance_amount);
            err++;
        } 
        else {
            $('#slot_amount_err').text('');
        }

   
         var old_cus_check = document.getElementById("old_cus_check");
        var old_customer_check =  0;
        if (old_cus_check.checked) {
            sms =0;
            email =0;
            whatsapp = 0;
            old_customer_check=1;
        }else{
             if(sms ==1 || email ==1 || whatsapp == 1){
                $('#communication_err').text('');
            }else{
                $('#communication_err').text('Please Select Any One Communication.!');
                err++;
            }
        }

        if(err == 0){
              $('#sendMessageBtn').prop('disabled', true);
               $('#sendMessageBtn').text('Sending...');
            $.ajax({
                url: '/send_invoice_message',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }, // Replace with your backend URL
                method: 'POST',
                data: JSON.stringify({
                    proposal_id: proposal_id,
                    sms: sms,
                    email: email,
                    whatsapp: whatsapp,
                    // description: description,
                    old_customer_check: old_customer_check,
                    slotAmount: slotAmount,
                    invoice_due_date: invoice_due_date,
                    slot_id: slot_id,
                }),
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        location.reload(); // Reload the page to update the UI
                        
                    } else {
                        toastr.error(response.message || 'Failed to send the message.');
                         $('#sendMessageBtn').prop('disabled', true);
                          resetButton();
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to send the message.';
                    toastr.error(errorMsg);
                     $('#sendMessageBtn').prop('disabled', true);
                      resetButton();
                }
            });
        }

         function resetButton() {
                $('#sendMessageBtn').prop('disabled', false);
                $('#sendMessageBtn').text('Send Invoice');
                $('#sendMessageBtn .spinner-border').addClass('d-none');
            }
    });

    function formatCurrency(amt) {
        var roundedAmt = parseFloat(amt);
        var isWhole = Number.isInteger(roundedAmt);
    
        return roundedAmt.toLocaleString('en-IN', {
            minimumFractionDigits: isWhole ? 0 : 2,
            maximumFractionDigits: isWhole ? 0 : 2
        });
    }
      function formatDate(dateString) {
            let date = new Date(dateString); 
            let day = String(date.getDate()).padStart(2, '0'); 
            let monthIndex = date.getMonth();
            let year = date.getFullYear(); 

            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            let month = months[monthIndex]; 

            return `${day}-${month}-${year}`;
        }
</script>

<script>
    change_proposal_func()
    function change_proposal_func(){
        $('#slot_pay_list').empty(); 
        $('#total_amount_label').text('0');
        $('#paid_amount_label').text('0');
        $('#balance_amount_label').text('0');

        var proposal_id=$('#proposal_id').val(); 
        console.log(proposal_id)
          $.ajax({
            url: "{{ route('payment_slot_invoice') }}",
            type: "GET",
            data:{id:proposal_id},
            success: function(response) {
                if (response.status === 200 ) {
                    
                    $('.currency_symbol').text(response.proposal.currency_symbol ? response.proposal.currency_symbol :'₹');
                    $('#estimate_date').text(response.proposal.estimate_date ? formatDate(response.proposal.estimate_date) :'-');
                    $('#validity_date').text(response.proposal.due_date ? formatDate(response.proposal.due_date) : '-');
                    $('#currency_format').text(response.proposal.currency_code + ' - '+ response.proposal.currency_symbol);
                    $('#total_amount_label').text(formatCurrency(response.proposal.total_amount));
                    $('#paid_amount_label').text(formatCurrency(response.total_paid));
                    $('#balance_amount_label').text(formatCurrency(response.total_balance));
                    $('#balance_amount').val(response.total_balance);
                    $('#send_proposal_id').val(response.proposal.sno);
                    let firstPendingPaymentFound = false;
                    if(response.data.length > 0){
                        response.data.forEach(function(data,index){
                            let print_url =`/receipt_print/ ${data.encrypt_slot_id}`;
                            let html = `
                                <tr>
                                    <td>
                                        <label class="fs-6 fw-semibold">${data.payment_slot_name || '-'}</label>
                                        ${data.temp_send_link ?
                                            `<span>
                                                <a href="${data.temp_send_link}" target="_blank" class="dropdown-item">
                                                    <span><i class="mdi mdi-link fs-5 text-primary fw-bold "></i></span>
                                                </a>
                                            </span>` 
                                            : ''
                                        }
                                        ${
                                            data.paid_status != 1 && data.due_date ? 
                                            `<div class="d-block">
                                                <label class="border border-danger rounded px-2 fs-7 text-danger fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Invoice Due Date">${data.due_date ? formatDate(data.due_date) : '-'}</label>
                                            </div>` : ``
                                        }
                                    </td>
                                    <td align="right">
                                        <label class="text-black fw-semibold fs-6">${response.proposal.currency_symbol || '₹'} ${data.payable_amount || '0'}</label>
                                    </td>
                                    <td align="right">
                                        <label class="text-black fw-semibold fs-6">${response.proposal.currency_symbol || '₹'} ${data.payable_amount || '0'}</label>
                                    </td>
                                    <td align="right">
                                        ${data.paid_status == 1 ? 
                                            `<label class="badge bg-success text-black fw-semibold fs-6">${response.proposal.currency_symbol || '₹'} ${data.paidAmount || '0'}</label>`
                                            : `-`
                                        }
                                       

                                    </td>
                                    <td align="right">
                                        <label class="badge bg-danger text-white fw-semibold fs-6">${response.proposal.currency_symbol || '₹'} ${data.balance_amount || '0'}</label>
                                    </td>
                                    <td></td>
                                    <td>
                                        ${data.paid_status == 1 ? 
                                            `<label class="badge bg-success fs-6 text-black rounded fw-semibold">Paid</label>
                                             <div class="d-block">
                                                <label class="fs-7 text-dark fw-semibold">${data.invoice_id}</label>
                                             </div>` 
                                            : `<label class="badge bg-warning fs-6 text-black rounded fw-semibold">Unpaid</label>`
                                        }
                                    </td>
                                    <td align="center">
                                        ${
                                            data.paid_status == 1 ? 
                                            `<span class="text-end">
                                                <a href="${print_url}" class="d-flex align-items-center justify-content-center pb-0">
                                                    <img src="{{asset('assets/phdizone_images/print.gif')}}" alt="print" class="w-45px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print Invoice" />
                                                </a>
                                            </span>` 
                                            : (!firstPendingPaymentFound ? (() => {
                                                firstPendingPaymentFound = true; // Set flag here
                                                return `<span class="text-end">
                                                    <button type="button" class="btn btn-sm btn-primary fs-5 px-4 py-1" 
                                                        data-bs-toggle="modal" data-bs-target="#kt_modal_send_invoice" 
                                                        ${data.generate_status == 1 ? '' : 'disabled'} 
                                                        onclick="send_invoice_func('${data.sno}', '${response.cus.cus_email_id}', '${response.cus.cus_mobile}', '${response.cus.cus_name}', '${response.proposal.total_amount}', '${data.payable_amount}', '${data.payment_slot_name}', '${response.proposal.proposal_id}', '${response.proposal.sno}')">
                                                        Generate Invoice
                                                    </button>
                                                </span>`;
                                            })() : `<a href="javascript:;" class="btn btn-sm btn-primary disabled" aria-disabled="true">Generate Invoice</a>`)
                                        }
                                    </td>
                                </tr>   
                            `;
                            $('#slot_pay_list').append(html);
                        });
                    }

                }
            },
            error: function(error) {
                console.error('Error fetching Package Data:', error);
            }
        });
    }
    
    
</script>

<script>
old_cus_check_func()
   function old_cus_check_func(){
        var old_cus_check = document.getElementById("old_cus_check");
     
        if (old_cus_check.checked) {
           $('.communication_check').hide();
            
        } else{
            $('.communication_check').show();
        }
    }
</script>

@endsection