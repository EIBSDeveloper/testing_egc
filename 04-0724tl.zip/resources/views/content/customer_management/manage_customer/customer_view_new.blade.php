@extends('layouts/layoutMaster')

@section('title', 'View Customer Details')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/toastr/toastr.scss',
'resources/assets/vendor/libs/animate-css/animate.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/clipboard/clipboard.js',
'resources/assets/vendor/libs/toastr/toastr.js'
])
@endsection

@section('page-script')
@endsection
@section('content')\
<style>
    .indv_cust_serv thead th,
    .indv_cust_serv tbody td {
        padding: 8px !important;
        border: 1px solid rgb(180, 180, 180) !important;
    }

    .proposal_table thead th,
    .proposal_table tbody td {
        border: 1px solid black !important;
        padding: 8px !important;
    }

    .common_table thead th,
    .common_table tbody td {
        /* border: 1px solid black !important; */
        padding: 8px !important;
    }
</style>

<style>
  .timeline-wrapper {
    width: 100%;
    margin: 20px auto;
  }

  .timeline-row {
      display: grid;
      grid-template-columns: 100px 40px 1fr;
      align-items: stretch; /* KEY FIX */
      /* margin-bottom: 25px; */
  }

  /* TIME */
  .timeline-time {
      text-align: right;
      padding-right: 10px;
      font-size: 14px;
      color: #555;
      font-weight: 500;
  }

  /* CENTER COLUMN FIX */
  .timeline-center {
      display: flex;
      flex-direction: column;
      align-items: center;
      height: 100%; /* Fills row height automatically */
      position: relative;
      /* border: 1px solid red; */
  }

  .timeline-dot {
      width: 14px;
      height: 14px;
      background: #0d6efd;
      border-radius: 50%;
      z-index: 2;
  }

  /* AUTO-ADJUSTING LINE */
  .timeline-line {
      width: 2px;
      background: #ced4da;
      flex-grow: 1; /* LINE AUTO ADJUSTS */
      margin-top: 4px;
  }

  /* Remove line from last item */
  .timeline-row:last-child .timeline-line {
      display: none;
  }

  /* CONTENT */
  .timeline-content {
      padding-left: 10px;
  }

</style>

<style>
    .chat-container {
    width: 930px;
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    font-family: Arial, sans-serif;
    }

    /* Header */
    .chat-header {
    background: #099DDA;
    color: white;
    padding: 10px;
    }

    /* Chat box */
    .chat-box {
    height: 500px;
    overflow-y: auto;
    background: #ece5dd;
    padding: 10px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    }

    /* Message bubbles */
    .chat-msg {
    max-width: 75%;
    padding: 8px 12px;
    border-radius: 12px;
    font-size: 14px;
    display: flex;
    flex-direction: column;
    }

    .sent {
    align-self: flex-end;
    background: #099DDA;
    color:white;
    }

    .received {
    align-self: flex-start;
    background: #ffffff;
    }

    /* Time */
    .chat-time {
    font-size: 11px;
    margin-top: 4px;
    text-align: right;
    color: #666;
    }

    /* Date divider */
    .chat-date {
    text-align: center;
    font-size: 12px;
    color: #666;
    margin: 10px 0;
    }

    .chat-date span {
    background: #d4d4d4;
    padding: 3px 10px;
    border-radius: 12px;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">View Customer Details</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Manage Customer</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element text-end">
            <div class="text-black fw-semibold fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Customer">Priya</div>
            <div class="d-block text-primary fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Customer Mobile No">( +91 ) 9876543210</div>
            <div class="d-block text-dark fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Customer ID">2025/MDU01/CUS2334</div>
        </div>
    </div>
    <div class="card-body py-0">
        <div class="row mt-2">
            <div class="col-lg-12">
                <div class="nav-align-top mb-2">
                    <ul class="nav nav-pills flex-nowrap bg-gray-100"  role="tablist">
                        <div class="scroll-container-wrapper">
                            <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                            <div class="scroll-container" id="scrollContainer">
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <button type="button" class="nav-link text-capitalize active border border-gray-500 rounded px-3 py-1 flex-column" role="tab" data-bs-toggle="tab" data-bs-target="#tab_customer_base_info" aria-controls="tab_customer_base_info" aria-selected="true">
                                            <span class="mdi mdi-account-box fs-1"></span>
                                            <div class="d-block text-start fw-semibold fs-7">Base Details</div>
                                        </button>
                                    </li>
                                </div>
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 flex-column" role="tab" data-bs-toggle="tab" data-bs-target="#tab_service_1" aria-controls="tab_service_1" aria-selected="true">
                                            <span class="mdi mdi-file-document fs-1"></span>
                                            <div class="d-block text-start text-truncate max-w-100px fw-semibold fs-7" >Service Details</div>
                                        </button>
                                    </li>
                                </div>
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 flex-column" role="tab" data-bs-toggle="tab" data-bs-target="#tab_service_2" aria-controls="tab_service_2" aria-selected="true">
                                            <span class="mdi mdi-text-box-outline fs-1"></span>
                                            <div class="d-block text-start text-truncate max-w-100px fw-semibold fs-7">Thesis Writing</div>
                                        </button>
                                        <!-- <span class="position-absolute badge bg-label-info rounded fw-semibold border-gray-400 fs-6 ms-n4 mt-n2">01</span> -->
                                    </li>
                                </div>
                            </div>
                            <button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                        </div>
                    </ul>
                </div>
            </div>
            <div class="col-lg-12 mt-3">
                <div class="tab-content p-0">
                    <div class="tab-pane fade show active" id="tab_customer_base_info" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-12 text-black fs-5 fw-bold">Basic Information</div>
                            <div class="col-lg-6 mt-4">
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Customer ID</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">2025/MDU01/CUS2334</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">Priya</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Gender</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">Female</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">DOB</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">24-Apr-1998</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <div class="col-7">
                                        <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="priya@gmail.com">priya@gmail.com</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 mt-2">
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">1, Bharathiyar Street, Madurai, Tamil Nadu, India - 625012</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">9876543210</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Alternate Mobile No</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">8976543210</label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <label class="text-black fs-5 fw-bold">Current Services Information</label>
                            </div>
                            <div class="col-lg-12 mt-4 mb-8">
                                <div class="table-responsive">
                                    <table class="table align-top gy-1 gs-2 indv_cust_serv">
                                        <thead>
                                            <tr class="text-start align-top bg-primary fs-6 gs-0">
                                                <th class="min-w-50px fw-semibold text-center">S.No</th>
                                                <th class="min-w-150px fw-semibold">Services</th>
                                                <th class="min-w-200px fw-semibold">Slots</th>
                                                <th class="min-w-100px text-center fw-semibold">Durations</th>
                                                <th class="min-w-100px text-center fw-semibold">Total Amt</th>
                                                <th class="min-w-100px text-center fw-semibold">Paid Amt</th>
                                                <th class="min-w-100px text-center fw-semibold">Balance Amt</th>
                                                <th class="min-w-100px fw-semibold">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                            <tr>
                                                <td align="center">1</td>
                                                <td>
                                                    <div class="mb-0">
                                                        <label class="fs-7">Thesis Writing</label>
                                                        <div class="d-block text-dark fs-8">Writing Products</div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                        <div class="mb-0 text-dark fs-7">Slot 01</div>
                                                        <div class="mb-0">
                                                            <label class="fw-semibold fs-7 text-black">&#8377; 55,000</label>
                                                            <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount Paid">
                                                                <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                    <g id="SVGRepo_iconCarrier">
                                                                        <defs>
                                                                            <style>
                                                                                .cls-1 {
                                                                                    fill: #699f4c;
                                                                                    fill-rule: evenodd;
                                                                                }
                                                                            </style>
                                                                        </defs>
                                                                        <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                    </g>
                                                                </svg>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                        <div class="mb-0 text-dark fs-7">Slot 02</div>
                                                        <div class="mb-0">
                                                            <label class="fw-semibold fs-7 text-black">&#8377; 56,574</label>
                                                            <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount Not Paid">
                                                                <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                    <g id="SVGRepo_iconCarrier">
                                                                        <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                        <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                    </g>
                                                                </svg>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td align="center">
                                                    <label class="badge bg-label-warning border border-gray-300 rounded fw-semibold text-black fs-7">90 Days</label>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">&#8377; 1,11,574</label>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">&#8377; 55,000</label>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">&#8377; 56,574</label>
                                                </td>
                                                <td>
                                                    <div class="badge bg-info text-black mb-1 fs-7 fw-semibold" style="background-color: #fea500 !important;">Service In Progress</div>
                                                    <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : 20%">
                                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td align="center">2</td>
                                                <td>
                                                    <div class="mb-0">
                                                        <label class="fs-7">Research Proposal</label>
                                                        <div class="d-block text-dark fs-8">Proposal Writing Products</div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                        <div class="mb-0 text-dark fs-7">Slot 01</div>
                                                        <div class="mb-0">
                                                            <label class="fw-semibold fs-7 text-black">&#8377; 30,000</label>
                                                            <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount Not Paid">
                                                                <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                    <g id="SVGRepo_iconCarrier">
                                                                        <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                        <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                    </g>
                                                                </svg>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                        <div class="mb-0 text-dark fs-7">Slot 02</div>
                                                        <div class="mb-0">
                                                            <label class="fw-semibold fs-7 text-black">&#8377; 20,000</label>
                                                            <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount Not Paid">
                                                                <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                    <g id="SVGRepo_iconCarrier">
                                                                        <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                        <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                    </g>
                                                                </svg>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td align="center">
                                                    <label class="badge bg-label-warning border border-gray-300 rounded fw-semibold text-black fs-7">60 Days</label>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">&#8377; 50,000</label>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">&#8377; 0</label>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">&#8377; 50,000</label>
                                                </td>
                                                <td>
                                                    <div class="badge bg-danger text-white mb-1 fs-7 fw-semibold">Waiting for Payment Approval</div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab_service_1" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-2">
                                <div class="nav-align-left nav-tabs-shadow">
                                    <ul class="nav nav-pills" role="tablist">
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize active border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-service_info"
                                                aria-controls="navs-service_info"
                                                aria-selected="true">
                                                Service Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-payment_info"
                                                aria-controls="navs-payment_info"
                                                aria-selected="false">
                                                Payment Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-appointment_info"
                                                aria-controls="navs-appointment_info"
                                                aria-selected="false">
                                                Appointment Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-requirements_info"
                                                aria-controls="navs-requirements_info"
                                                aria-selected="false">
                                                Requirements Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-task_info"
                                                aria-controls="navs-task_info"
                                                aria-selected="false">
                                                Task Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-deliverables_info"
                                                aria-controls="navs-deliverables_info"
                                                aria-selected="false">
                                                Deliverables Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-staff_info"
                                                aria-controls="navs-staff_info"
                                                aria-selected="false">
                                                Staff Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-journal_info"
                                                aria-controls="navs-journal_info"
                                                aria-selected="false">
                                                Journal Info
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-10">
                                <div class="tab-content px-0 py-0">
                                    <div class="tab-pane fade show active" id="navs-service_info">
                                        <!-- Begin :: Single Proposal (Single Services) -->
                                        <div class="divider divider-primary mt-4 mb-10">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">
                                                <label>( Single ) Services Information &emsp; - &emsp;</label>
                                                <label class="badge bg-info text-black mb-1 fs-5 fw-semibold" style="background-color: #fea500 !important;">Service In Progress</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 mb-3">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">Thesis Writing</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service Category</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">Writing Services</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Durations / Usage</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <div class="col-7">
                                                        <label class="badge bg-transparent border border-danger fw-semibold text-danger fs-7 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Durations">90 Days</label>
                                                        <label class="text-black fs-6 fw-bold ms-1 me-1">/</label>
                                                        <label class="badge bg-transparent border border-danger fw-semibold text-info fs-7 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Usage Hours">33 Hrs</label>
                                                    </div>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Currency / Slot</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <div class="col-7">
                                                        <label class="text-black fs-6 fw-semibold">₹ - INR</label>
                                                        <label class="text-black fs-6 fw-bold ms-1 me-1">/</label>
                                                        <label class="badge bg-secondary fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Slot">02</label>
                                                        <label class="text-dark fs-6 fw-semibold">( Partially Paid )</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <div class="mb-0 fw-semibold text-center text-black fs-5"><u>Deliverables</u></div>
                                                <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                    <div class="mb-0 fw-semibold text-dark fs-7">Slot 01</div>
                                                    <div class="mb-0">
                                                        <label class="fw-semibold fs-7 text-black">&#8377; 55,000</label>
                                                        <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered">
                                                            <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                <g id="SVGRepo_iconCarrier">
                                                                    <defs>
                                                                        <style>
                                                                            .cls-1 {
                                                                                fill: #699f4c;
                                                                                fill-rule: evenodd;
                                                                            }
                                                                        </style>
                                                                    </defs>
                                                                    <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                </g>
                                                            </svg>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                    <div class="mb-0 fw-semibold text-dark fs-7">Slot 02</div>
                                                    <div class="mb-0">
                                                        <label class="fw-semibold fs-7 text-black">&#8377; 56,574</label>
                                                        <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Progress">
                                                            <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                <g id="SVGRepo_iconCarrier">
                                                                    <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                    <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                </g>
                                                            </svg>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : 20%">
                                                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
                                                </div>
                                            </div>
                                            <div class="col-lg-8 d-flex align-items-center justify-content-center gap-5 flex-wrap mb-3">
                                                <div class="badge bg-secondary fw-semibold fs-6 rounded py-2 px-3">
                                                    <label class="text-white mb-2 fs-4 fw-semibold">Total Amount</label>
                                                    <div class="d-block">
                                                        <label class="text-white fs-4 fw-semibold">₹ 1,11,574</label>
                                                    </div>
                                                </div>
                                                <div class="badge bg-success fw-semibold fs-6 rounded py-2 px-3">
                                                    <label class="text-white mb-2 fs-4 fw-semibold">Paid Amount</label>
                                                    <div class="d-block">
                                                        <label class="text-white fs-4 fw-semibold">₹ 55,000</label>
                                                    </div>
                                                </div>
                                                <div class="badge bg-danger fw-semibold fs-6 rounded py-2 px-3">
                                                    <label class="text-white mb-2 fs-4 fw-semibold">Balance Amount</label>
                                                    <div class="d-block">
                                                        <label class="text-white fs-4 fw-semibold">₹ 56,574</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End :: Single Proposal (Single Services) -->


                                        <!-- Begin :: Single Proposal (Multiple Services) -->
                                        <div class="divider divider-primary mt-4 mb-10">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">
                                                <label>( Multiple ) Services Information &emsp; - &emsp;</label>
                                                <label class="badge bg-info text-black mb-1 fs-5 fw-semibold" style="background-color: #fea500 !important;">Service In Progress</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 mb-3">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">Thesis Writing</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service Category</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">Writing Services</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <div class="col-lg-4 mb-3">
                                                        <div class="mb-0 fw-semibold text-center text-black fs-5"><u>Deliverables</u></div>
                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                            <div class="mb-0 fw-semibold text-dark fs-7">Slot 01</div>
                                                            <div class="mb-0">
                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered">
                                                                    <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                        <g id="SVGRepo_iconCarrier">
                                                                            <defs>
                                                                                <style>
                                                                                    .cls-1 {
                                                                                        fill: #699f4c;
                                                                                        fill-rule: evenodd;
                                                                                    }
                                                                                </style>
                                                                            </defs>
                                                                            <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                        </g>
                                                                    </svg>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                            <div class="mb-0 fw-semibold text-dark fs-7">Slot 02</div>
                                                            <div class="mb-0">
                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Progress">
                                                                    <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                        <g id="SVGRepo_iconCarrier">
                                                                            <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                            <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                        </g>
                                                                    </svg>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : 20%">
                                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6 mb-3 d-flex align-items-center justify-content-center flex-column">
                                                        <div class="text-center border border-info border-dashed rounded px-3 py-2">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">Services</label>
                                                            <div class="d-block" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <label class="cursor-pointer text-info mb-1 fs-5 fw-semibold">03</label>
                                                                <a href="javascript:;" class="mb-1 me-n3"><i class="mdi mdi-menu-down text-black fs-3"></i></a>
                                                                <div class="dropdown-menu dropdown-menu-end w-25">
                                                                    <div class="text-dark fs-6 text-center my-2 fw-semibold">Services</div>
                                                                    <hr class="mt-0 mb-2 border-dark">
                                                                    <div class="scroll-y max-h-350px px-4 py-1 mb-2">
                                                                        <div class="d-flex align-items-start text-start mb-2">
                                                                            <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                            <div class="d-block">
                                                                                <div class="text-black fw-semibold text-justify fs-7">Thesis Writing</div>
                                                                                <div class="fw-semibold text-info fs-8">Writing Products</div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mb-0 fw-semibold text-center text-black fs-7"><u>Deliverables</u></div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 01</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered">
                                                                                    <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <defs>
                                                                                                <style>
                                                                                                    .cls-1 {
                                                                                                        fill: #699f4c;
                                                                                                        fill-rule: evenodd;
                                                                                                    }
                                                                                                </style>
                                                                                            </defs>
                                                                                            <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 02</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Progress">
                                                                                    <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                                            <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : 20%">
                                                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
                                                                        </div>
                                                                        <div class="border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pt-4 mb-3"></div>
                                                                        <div class="d-flex align-items-start text-start mb-2">
                                                                            <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                            <div class="d-block">
                                                                                <div class="text-black fw-semibold text-justify fs-7">Technical Research and Development Services</div>
                                                                                <div class="fw-semibold text-info fs-8">Developement Products</div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mb-0 fw-semibold text-center text-black fs-7"><u>Deliverables</u></div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 01</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered">
                                                                                    <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <defs>
                                                                                                <style>
                                                                                                    .cls-1 {
                                                                                                        fill: #699f4c;
                                                                                                        fill-rule: evenodd;
                                                                                                    }
                                                                                                </style>
                                                                                            </defs>
                                                                                            <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 02</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Progress">
                                                                                    <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                                            <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : 20%">
                                                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
                                                                        </div>
                                                                        <div class="border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pt-4 mb-3"></div>
                                                                        <div class="d-flex align-items-start text-start mb-2">
                                                                            <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                            <div class="d-block">
                                                                                <div class="text-black fw-semibold text-justify fs-7">Formatting and Referencing</div>
                                                                                <div class="fw-semibold text-info fs-8">Developement Products</div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mb-0 fw-semibold text-center text-black fs-7"><u>Deliverables</u></div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 01</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered">
                                                                                    <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <defs>
                                                                                                <style>
                                                                                                    .cls-1 {
                                                                                                        fill: #699f4c;
                                                                                                        fill-rule: evenodd;
                                                                                                    }
                                                                                                </style>
                                                                                            </defs>
                                                                                            <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 02</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Progress">
                                                                                    <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                                            <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : 20%">
                                                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
                                                                        </div>
                                                                        <div class="border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pt-4 mb-3"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Durations / Usage</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <div class="col-7">
                                                        <label class="badge bg-transparent border border-danger fw-semibold text-danger fs-7 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Durations">90 Days</label>
                                                        <label class="text-black fs-6 fw-bold ms-1 me-1">/</label>
                                                        <label class="badge bg-transparent border border-danger fw-semibold text-info fs-7 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Usage Hours">33 Hrs</label>
                                                    </div>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Currency</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <div class="col-7">
                                                        <label class="text-black fs-6 fw-semibold">₹ - INR</label>
                                                    </div>
                                                </div>
                                                <div class="row mb-4">
                                                    <div class="col-lg-12">
                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-3">
                                                            <div class="badge bg-secondary fw-semibold fs-6 rounded py-1 px-2">
                                                                <label class="text-white mb-2 fs-5 fw-semibold">Total Amount</label>
                                                                <div class="d-block">
                                                                    <label class="text-white fs-5 fw-semibold">₹ 1,11,574</label>
                                                                </div>
                                                            </div>
                                                            <div class="badge bg-success fw-semibold fs-6 rounded py-1 px-2">
                                                                <label class="text-white mb-2 fs-5 fw-semibold">Paid Amount</label>
                                                                <div class="d-block">
                                                                    <label class="text-white fs-5 fw-semibold">₹ 55,000</label>
                                                                </div>
                                                            </div>
                                                            <div class="badge bg-danger fw-semibold fs-6 rounded py-1 px-2">
                                                                <label class="text-white mb-2 fs-5 fw-semibold">Balance Amount</label>
                                                                <div class="d-block">
                                                                    <label class="text-white fs-5 fw-semibold">₹ 56,574</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End :: Single Proposal (Multiple Services) -->


                                        <div class="divider divider-primary mt-10 mb-10">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">
                                                <label>Proposal Information &emsp; - &emsp;</label>
                                                <label class="border border-success rounded px-2 text-success fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Accepted Date"><?php echo date("d-M-Y", strtotime("+3 days")); ?></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="shadow-lg border border-gray-800 rounded mb-4">
                                                    <div class="cursor-pointer d-flex align-items-center justify-content-between flex-wrap rounded px-4 py-2" id="accr_1" style="background-color: #DFDBDB;">
                                                        <div class="mb-4">
                                                            <label class="bg-label-success rounded-circle fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Accepted"><i class="mdi mdi-check-decagram fs-1 fw-bold opacity-1 text-success"></i></label>
                                                            <label class="badge bg-info fw-semibold fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Count">02</label>
                                                            <label class="text-black fs-5 fw-semibold ms-2">PRO-003670/05/2025-01</label>
                                                            <div class="d-block">
                                                                <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                                                <label class="badge bg-success fs-6 text-white rounded fw-semibold"><?php echo date("d-M-Y"); ?></label>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center justify-content-end mb-4">
                                                            <div class="cursor-pointer me-2">
                                                                <a href="{{url('/manage_proposal/proposal_print')}}" target="_blank" class="border border-dark rounded px-1 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                                                    <span><i class="mdi mdi-printer-pos-outline fs-1 text-black"></i></span>
                                                                </a>
                                                            </div>
                                                            <div class="mb-0">
                                                                <div class="d-block">
                                                                    <label class="fs-4 text-black fw-semibold">Total Amount &nbsp;-&nbsp;</label>
                                                                    <label class="fs-4 text-black rounded fw-bold">&#8377; 1,11,574</label>
                                                                </div>
                                                                <div class="d-block">
                                                                    <label class="fs-6 text-black fw-semibold">Validity Date &nbsp;-&nbsp;</label>
                                                                    <label class="badge bg-danger fs-6 text-white rounded fw-semibold"><?php echo date("d-M-Y", strtotime("+7 days")); ?></label>
                                                                </div>
                                                            </div>
                                                            <label class="cursor-pointer op_cl ms-3"><i class="mdi mdi-menu-down text-black fs-2"></i></label>
                                                        </div>
                                                    </div>
                                                    <div class="px-5 pb-4 pt-2" id="accr_1_tbox" style="display: none;">
                                                        <div class="fs-2 text-center text-black my-3 fw-bold">Service Details</div>
                                                        <div class="row">
                                                            <div class="col-lg-12 mb-2">
                                                                <table class="table align-top gy-1 gs-2 proposal_table">
                                                                    <thead>
                                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                            <th class="w-50px text-center">S.No</th>
                                                                            <th class="w-300px text-center">Work </th>
                                                                            <th class="w-50px text-center">Qty </th>
                                                                            <th class="w-100px text-center">Amount</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody class="text-gray-600">
                                                                        <tr>
                                                                            <td align="center">1</td>
                                                                            <td>
                                                                                <div>
                                                                                    <div class="text-black fw-semibold fs-6 mb-1">Thesis Writing ( &#8377; 82,000 )</div>
                                                                                    <div class="text-dark fw-semibold fs-7">Writing Services</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-dark fw-semibold fs-6 my-2">
                                                                                        <label>Total Costing &nbsp;:&nbsp;</label>
                                                                                        <label class="me-2">** &#8377; 1,11,574 /- **</label>
                                                                                        <label>Total Slots &nbsp;:&nbsp;</label>
                                                                                        <label class="me-2">02</label>
                                                                                        <label>(Includes 18% GST)</label>
                                                                                    </div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Tools</div>
                                                                                    <div class="d-block ms-3">1. LaTeX</div>
                                                                                    <div class="d-block ms-3">2. Scrivener</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Slot I : &#8377; 55,000 /-</div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Free Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Topic Suggestions - 03 Chapter</div>
                                                                                    <div class="d-block text-black ms-5">2. Sample Research Papers - 08 Pages</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Consultation (Into) - 30 Minutes</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Paid Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Plagiarism Check - 200 Pages( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">2. Thesis Writing - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                                                    <div class="d-block ms-3">1. Technical discussion</div>
                                                                                    <div class="d-block ms-3">2. Flow of the work ( Novelty and Data Set )</div>
                                                                                    <!-- <div class="d-block">3. Source Code</div>
                                                    <div class="d-block">4. Pseudo Code</div>
                                                    <div class="d-block">5. Demo through Running video</div>
                                                    <div class="d-block">6. Results As per client specification-As per the Description</div>
                                                    <div class="d-block">7. Software Installation</div> -->
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Note</div>
                                                                                    <div class="d-block ms-3">1. Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Slot 2 : &#8377; 56,574 /-</div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Free Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Topic Suggestions - 03 Chapter</div>
                                                                                    <div class="d-block text-black ms-5">2. Sample Research Papers - 08 Pages</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Consultation (Into) - 30 Minutes</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Paid Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Plagiarism Check - 200 Pages( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">2. Thesis Writing - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                                                    <div class="d-block ms-3">1. Technical discussion</div>
                                                                                    <div class="d-block ms-3">2. Flow of the work ( Novelty and Data Set )</div>
                                                                                    <!-- <div class="d-block">3. Source Code</div>
                                                    <div class="d-block">4. Pseudo Code</div>
                                                    <div class="d-block">5. Demo through Running video</div>
                                                    <div class="d-block">6. Results As per client specification-As per the Description</div>
                                                    <div class="d-block">7. Software Installation</div> -->
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Note</div>
                                                                                    <div class="d-block ms-3">1. Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="d-block">SUPPORT SECTION : Approval getting, Knowledge transfer, whatsapp group creation, and further doubts clearing support as well.</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">
                                                                                        <label>Duration &nbsp;:&nbsp;</label>
                                                                                        <label>90</label>
                                                                                        <label>working days</label>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                            <td align="center">
                                                                                <label class="fs-6 fw-bold">1</label>
                                                                            </td>
                                                                            <td align="right">
                                                                                <label class="fs-6 text-black fw-semibold">&#8377; 1,02,000</label>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <div class="border border-gray-700 rounded pb-2">
                                                                    <div class="d-flex align-items-center justify-content-between border-bottom rounded-top bg-label-info" style="background-color: #adff2f78 !important;">
                                                                        <div class="mb-0 ps-3 py-2">
                                                                            <label class="text-black fw-semibold fs-6">Additional Charges</label>
                                                                        </div>
                                                                        <div class="me-3">
                                                                            <div class="badge bg-secondary rounded fs-6">03</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="scroll-y max-h-200px px-3 py-2">
                                                                        <div class="row mt-2 px-3">
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">1.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>Bank's Inward Remittance Fee</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">2.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>GST on Foreign Exchange Services</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">3.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>Foreign Inward Remittance Certificate (FIRC) Charges</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-dark fs-5 me-13">Sub Total</label>
                                                                    <div class="fw-bold text-dark fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-dark"></i></span>
                                                                        <span class="fs-3">1,02,000</span>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-1 gap-5">
                                                                    <div class="d-flex align-items-center justify-content-end gap-5 mb-2">
                                                                        <div class="d-flex align-items-center fw-bold fs-5 me-13">
                                                                            <div class="me-0">
                                                                                <label>Discount</label>
                                                                                <label class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Discount Percentage">( 10% )</label><br>
                                                                                <label class="text-info fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Coupon Code">[ A7D9K2L3M0 ]</label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="fw-bold fs-2">
                                                                            <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                                                                            <span class="fs-3">10,200</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-black fs-4 me-9">Total Amount</label>
                                                                    <div class="fw-bold text-black fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-3 fw-bold text-black"></i></span>
                                                                        <span class="fs-2">91,800</span>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <div class="fw-bold fs-5 me-12">
                                                                        <div class="text-dark mb-1 fs-5 fw-semibold">
                                                                            <label>GST <span class="text-danger fw-bold">( 18% )</span></label>
                                                                            <div class="d-block fw-bold fs-8">[Exclusive]</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="fw-bold fs-2">
                                                                        <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                                                                        <label class="fs-3">16,524</label>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-dark text-end fs-5 me-13">Additional Charges<br><span class="text-danger fw-bold">( 3% )</span></label>
                                                                    <div class="fw-bold text-dark fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-dark"></i></span>
                                                                        <span class="fs-3">3,250</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                            <label class="fw-bold text-black fs-1 me-8">Grand Total</label>
                                                            <div class="fw-bold text-black fs-2">
                                                                <label><i class="mdi mdi-currency-rupee fs-2 fw-bold text-black"></i></label>
                                                                <label class="fs-1">1,11,574</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="shadow-lg border border-gray-800 rounded mb-4">
                                                    <div class="cursor-pointer d-flex align-items-center justify-content-between flex-wrap rounded px-4 py-2" id="accr_2" style="background-color: #DFDBDB;">
                                                        <div class="mb-4">
                                                            <label class="badge bg-info fw-semibold fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Count">01</label>
                                                            <label class="text-black fs-5 fw-semibold ms-2">PRO-003669/03/2025</label>
                                                            <div class="d-block">
                                                                <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                                                <label class="badge bg-success fs-6 text-white rounded fw-semibold"><?php echo date("d-M-Y", strtotime("-8 days")); ?></label>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center justify-content-end mb-4">
                                                            <div class="cursor-pointer me-2">
                                                                <a href="{{url('/manage_proposal/proposal_print')}}" target="_blank" class="border border-dark rounded px-1 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                                                    <span><i class="mdi mdi-printer-pos-outline fs-1 text-black"></i></span>
                                                                </a>
                                                            </div>
                                                            <div class="mb-0">
                                                                <div class="d-block">
                                                                    <label class="fs-4 text-black fw-semibold">Total Amount &nbsp;-&nbsp;</label>
                                                                    <label class="fs-4 text-black rounded fw-bold">&#8377; 1,43,434</label>
                                                                </div>
                                                                <div class="d-block">
                                                                    <label class="fs-6 text-black fw-semibold">Validity Date &nbsp;-&nbsp;</label>
                                                                    <label class="badge bg-danger fs-6 text-white rounded fw-semibold"><?php echo date("d-M-Y", strtotime("-1 days")); ?></label>
                                                                </div>
                                                            </div>
                                                            <label class="cursor-pointer op_cl ms-3"><i class="mdi mdi-menu-down text-black fs-2"></i></label>
                                                        </div>
                                                    </div>
                                                    <div class="px-5 pb-4 pt-2" id="accr_2_tbox" style="display: none;">
                                                        <div class="fs-2 text-center text-black my-3 fw-bold">Service Details</div>
                                                        <div class="row">
                                                            <div class="col-lg-12 mb-2">
                                                                <table class="table align-top gy-1 gs-2 proposal_table">
                                                                    <thead>
                                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                            <th class="w-50px text-center">S.No</th>
                                                                            <th class="w-300px text-center">Work </th>
                                                                            <th class="w-50px text-center">Qty </th>
                                                                            <th class="w-100px text-center">Amount</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody class="text-gray-600">
                                                                        <tr>
                                                                            <td align="center">1</td>
                                                                            <td>
                                                                                <div>
                                                                                    <div class="text-black fw-semibold fs-6 mb-1">Thesis Writing ( &#8377; 82,000 )</div>
                                                                                    <div class="text-dark fw-semibold fs-7">Writing Services</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-dark fw-semibold fs-6 my-2">
                                                                                        <label>Total Costing &nbsp;:&nbsp;</label>
                                                                                        <label class="me-2">** &#8377; 1,40,184 /- **</label>
                                                                                        <label>Total Slots &nbsp;:&nbsp;</label>
                                                                                        <label class="me-2">02</label>
                                                                                        <label>(Includes 18% GST)</label>
                                                                                    </div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Tools</div>
                                                                                    <div class="d-block ms-3">1. LaTeX</div>
                                                                                    <div class="d-block ms-3">2. Scrivener</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Slot I : &#8377; 80,000 /-</div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Free Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Topic Suggestions - 03 Chapter</div>
                                                                                    <div class="d-block text-black ms-5">2. Sample Research Papers - 08 Pages</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Consultation (Into) - 30 Minutes</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Paid Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Plagiarism Check - 200 Pages( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">2. Thesis Writing - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Proposal Writing - 5000 Words ( &#8377; 20,000 )</div>
                                                                                    <div class="d-block text-black ms-5">4. Thesis Formatting - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                                                    <div class="d-block ms-3">1. Technical discussion</div>
                                                                                    <div class="d-block ms-3">2. Flow of the work ( Novelty and Data Set )</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Note</div>
                                                                                    <div class="d-block">1. Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Slot 2 : &#8377; 60,184 /-</div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Free Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Topic Suggestions - 03 Chapter</div>
                                                                                    <div class="d-block text-black ms-5">2. Sample Research Papers - 08 Pages</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Consultation (Into) - 30 Minutes</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Paid Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Plagiarism Check - 200 Pages( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">2. Thesis Writing - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Proposal Writing - 5000 Words ( &#8377; 20,000 )</div>
                                                                                    <div class="d-block text-black ms-5">4. Thesis Formatting - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                                                    <div class="d-block ms-3">1. Technical discussion</div>
                                                                                    <div class="d-block ms-3">2. Flow of the work ( Novelty and Data Set )</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Note</div>
                                                                                    <div class="d-block">1. Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="d-block">SUPPORT SECTION : Approval getting, Knowledge transfer, whatsapp group creation, and further doubts clearing support as well.</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">
                                                                                        <label>Duration &nbsp;:&nbsp;</label>
                                                                                        <label>90</label>
                                                                                        <label>working days</label>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                            <td align="center">
                                                                                <label class="fs-6 fw-bold">1</label>
                                                                            </td>
                                                                            <td align="right">
                                                                                <label class="fs-6 text-black fw-semibold">&#8377; 1,32,000</label>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <div class="border border-gray-700 rounded pb-2">
                                                                    <div class="d-flex align-items-center justify-content-between border-bottom rounded-top bg-label-info" style="background-color: #adff2f78 !important;">
                                                                        <div class="mb-0 ps-3 py-2">
                                                                            <label class="text-black fw-semibold fs-6">Additional Charges</label>
                                                                        </div>
                                                                        <div class="me-3">
                                                                            <div class="badge bg-secondary rounded fs-6">03</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="scroll-y max-h-200px px-3 py-2">
                                                                        <div class="row mt-2 px-3">
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">1.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>Bank's Inward Remittance Fee</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">2.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>GST on Foreign Exchange Services</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">3.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>Foreign Inward Remittance Certificate (FIRC) Charges</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-dark fs-5 me-13">Sub Total</label>
                                                                    <div class="fw-bold text-dark fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-dark"></i></span>
                                                                        <span class="fs-3">1,32,000</span>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-1 gap-5">
                                                                    <div class="d-flex align-items-center justify-content-end gap-5 mb-2">
                                                                        <div class="d-flex align-items-center fw-bold fs-5 me-13">
                                                                            <div class="me-0">
                                                                                <label>Discount</label>
                                                                                <label class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Discount Percentage">( 10% )</label><br>
                                                                                <label class="text-info fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Coupon Code">[ A7D9K2L3M0 ]</label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="fw-bold fs-2">
                                                                            <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                                                                            <span class="fs-3">13,200</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-black fs-4 me-9">Total Amount</label>
                                                                    <div class="fw-bold text-black fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-3 fw-bold text-black"></i></span>
                                                                        <span class="fs-2">1,18,800</span>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <div class="fw-bold fs-5 me-12">
                                                                        <div class="text-dark mb-1 fs-5 fw-semibold">
                                                                            <label>GST <span class="text-danger fw-bold">( 18% )</span></label>
                                                                            <div class="d-block fw-bold fs-8">[Exclusive]</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="fw-bold fs-2">
                                                                        <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                                                                        <label class="fs-3">21,384</label>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-dark text-end fs-5 me-13">Additional Charges<br><span class="text-danger fw-bold">( 3% )</span></label>
                                                                    <div class="fw-bold text-dark fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-dark"></i></span>
                                                                        <span class="fs-3">3,250</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                            <label class="fw-bold text-black fs-1 me-8">Grand Total</label>
                                                            <div class="fw-bold text-black fs-2">
                                                                <label><i class="mdi mdi-currency-rupee fs-2 fw-bold text-black"></i></label>
                                                                <label class="fs-1">1,43,434</label>
                                                            </div>
                                                        </div>
                                                        <div class="mb-2">
                                                            <div class="text-black fw-semibold fs-5 mb-2"><u>Reason</u></div>
                                                            <div class="text-danger fw-semibold fs-6">&emsp;&emsp;&emsp; The cost is too high for my budget</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="divider divider-primary mt-10 mb-10">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Receipts Information</div>
                                        </div>
                                        <div class="row mb-6">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table align-middle table-row-dashed gy-1 gs-2 common_table">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                <th class="min-w-100px">Receipt No</th>
                                                                <th class="min-w-80px">Paid Amt</th>
                                                                <th class="min-w-80px">Mode</th>
                                                                <th class="min-w-80px text-center">NDA</th>
                                                                <th class="min-w-50px">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                                            <tr>
                                                                <td>
                                                                    <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Receipt No">INV-005003/05/2025</label>
                                                                    <div class="d-block">
                                                                        <label class="fs-8 text-dark fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Receipt Date">
                                                                            <?php echo date("d-M-Y"); ?>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td align="right">
                                                                    <label class="badge bg-success fs-7 text-black rounded fw-semibold">&#8377; 55,000</label>
                                                                </td>
                                                                <td>
                                                                    <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Receipt Date">Offline</label>
                                                                    <div class="d-block">
                                                                        <label class="fs-8 text-dark fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Transaction ID">TXN20250526ABC12345</label>
                                                                    </div>
                                                                </td>
                                                                <td class="text-center">
                                                                    <label class="text-danger fs-7">NDA Signed</label>
                                                                    <div class="d-block">
                                                                        <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="NDA ID">GC/IZONE/2024/02346/03615</label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <span class="text-end">
                                                                        <a href="{{url('/manage_invoice/invoice_print')}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print Receipt">
                                                                            <i class="mdi mdi-printer-pos-outline fs-3 text-black"></i>
                                                                        </a>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="divider divider-primary mt-10 mb-10">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">NDA Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table align-middle table-row-dashed gy-1 gs-2 common_table">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                <th class="min-w-100px">NDA ID</th>
                                                                <th class="min-w-80px">NDA Date</th>
                                                                <th class="min-w-100px">NDA Status</th>
                                                                <th class="min-w-50px">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                                            <tr>
                                                                <td>
                                                                    <label class="fs-7">GC/IZONE/2024/02346/03613</label>
                                                                </td>
                                                                <td>
                                                                    <label class="fs-7">28-Mar-2025</label>
                                                                </td>
                                                                <td>
                                                                    <label class="badge bg-success text-black fs-8 fw-semibold">NDA Signed</label>
                                                                </td>
                                                                <td>
                                                                    <span class="text-end">
                                                                        <a href="{{url('/manage_nda/nda_print')}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="NDA Print">
                                                                            <i class="mdi mdi-printer-pos-outline fs-3 text-black"></i>
                                                                        </a>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="divider divider-primary mt-3 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">
                                                <label>Work Order Information &emsp; - &emsp;</label>
                                                <label class="badge bg-info text-white mb-1 fs-5 fw-semibold" style="background-color: #218837 !important;">Verified Work Order</label>
                                            </div>
                                        </div>
                                        <div class="text-black fs-6 mb-3 fw-semibold"><u>Billable Details</u></div>
                                        <div class="row mb-4">
                                            <div class="col-lg-12 mb-3">
                                                <label class="text-end me-2">
                                                    <svg height="20px" width="20px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                        <g id="SVGRepo_iconCarrier">
                                                            <defs>
                                                                <style>
                                                                    .cls-1 {
                                                                        fill: #699f4c;
                                                                        fill-rule: evenodd;
                                                                    }
                                                                </style>
                                                            </defs>
                                                            <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                        </g>
                                                    </svg>
                                                </label>
                                                <label class="text-black fs-7 fw-semibold">Service Based Billable</label>
                                            </div>
                                        </div>
                                        <div class="text-black fs-6 mb-3 fw-semibold"><u>Checklist</u></div>
                                        <div class="scroll-y max-h-225px px-3 py-1 mb-4">
                                            <div class="row">
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Payment Confirmation</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Confirm the services (ex: Proposal, Thesis, Publication)</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Duration of the service</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">The preferred mode of communication (Email, WhatsApp, Call)</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Best time to contact</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">if any documents are pending from the client</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Inform about the turnaround time for deliverables</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Confirm if the client has any urgent deadlines</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-6">
                                            <div class="col-12 text-dark fs-6 fw-semibold">Description</div>
                                            <div class="col-12 text-black fs-6 fw-semibold">&emsp;&emsp;&emsp;-</div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-payment_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Payment Information</div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-6">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service Title</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-semibold">Priya Work 1</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Currency Format</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-semibold">INR - ₹</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-semibold">Thesis Writing</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service Category</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-semibold">Writing Services</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <div class="col-lg-12 d-flex align-items-center justify-content-center gap-5 flex-wrap">
                                                <div class="badge bg-secondary fw-semibold fs-6 rounded py-2 px-3">
                                                    <label class="text-white mb-2 fs-4 fw-semibold">Total Amount</label>
                                                    <div class="d-block">
                                                        <label class="text-white fs-4 fw-semibold">&#8377; 1,11,574</label>
                                                    </div>
                                                </div>
                                                <div class="badge bg-success fw-semibold fs-6 rounded py-2 px-3">
                                                    <label class="text-white mb-2 fs-4 fw-semibold">Paid Amount</label>
                                                    <div class="d-block">
                                                        <label class="text-white fs-4 fw-semibold">&#8377; 55,000</label>
                                                    </div>
                                                </div>
                                                <div class="badge bg-danger fw-semibold fs-6 rounded py-2 px-3">
                                                    <label class="text-white mb-2 fs-4 fw-semibold">Balance Amount</label>
                                                    <div class="d-block">
                                                        <label class="text-white fs-4 fw-semibold">&#8377; 56,574</label>
                                                    </div>
                                                </div>
                                                <!-- <div class="d-flex align-items-center justify-content-center flex-column">
                                                    <div class="text-center border border-info border-dashed rounded px-3 py-2">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">Services</label>
                                                        <div class="d-block" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <label class="cursor-pointer text-info mb-1 fs-5 fw-semibold">01</label>
                                                            <a href="javascript:;" class="mb-1 me-n3"><i class="mdi mdi-menu-down text-black fs-3"></i></a>
                                                            <div class="dropdown-menu dropdown-menu-end w-25">
                                                                <div class="text-dark fs-6 text-center my-2 fw-semibold">Services</div>
                                                                <hr class="mt-0 mb-2 border-dark">
                                                                <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                        <div class="d-block">
                                                                            <div class="text-black fw-semibold text-justify fs-7">Thesis Writing</div>
                                                                            <div class="fw-semibold text-info fs-8">Writing Products</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                        <div class="d-block">
                                                                            <div class="text-black fw-semibold text-justify fs-7">Technical Research and Development Services</div>
                                                                            <div class="fw-semibold text-info fs-8">Developement Products</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                        <div class="d-block">
                                                                            <div class="text-black fw-semibold text-justify fs-7">Formatting and Referencing</div>
                                                                            <div class="fw-semibold text-info fs-8">Developement Products</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> -->
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table align-top table-row-dashed gy-1 gs-2">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary common_table">
                                                                <th class="min-w-150px">Date & Time</th>
                                                                <th class="min-w-150px">Receipt ID</th>
                                                                <th class="min-w-150px">Mode</th>
                                                                <th class="min-w-150px">Paid Amt</th>
                                                                <th class="min-w-50px text-center">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-gray-600 fw-semibold fs-6">
                                                            <tr>
                                                                <td>
                                                                    <label class="fs-7 fw-semibold">
                                                                        <?php echo date("d-M-Y", strtotime("+3 days")); ?>
                                                                    </label>
                                                                    <div class="d-block">
                                                                        <label class="fs-8 fw-semibold">
                                                                            <?php date_default_timezone_set('Asia/Kolkata');
                                                                            echo date("h:i:s A"); ?>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Receipt ID">INV-005003/05/2025</label>
                                                                </td>
                                                                <td>
                                                                    <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Receipt Date">Offline</label>
                                                                    <div class="d-block">
                                                                        <label class="fs-8 text-dark fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Transaction ID">TXN20250526ABC12345</label>
                                                                    </div>
                                                                </td>
                                                                <td align="right">
                                                                    <label class="text-black fw-semibold fs-6">&#8377; 55,000</label>
                                                                </td>
                                                                <td align="center">
                                                                    <span class="text-end">
                                                                        <a href="{{url('/manage_invoice/invoice_print')}}" class="d-flex align-items-center justify-content-center pb-0">
                                                                            <img src="{{asset('assets/phdizone_images/print.gif')}}" alt="print" class="w-45px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print Receipt" />
                                                                        </a>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-appointment_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Appointment Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table align-middle table-row-dashed gy-1 gs-2 common_table">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                <th class="min-w-150px">Date & Time</th>
                                                                <th class="min-w-100px">Appointment Mode</th>
                                                                <th class="min-w-100px">Assigned Staff</th>
                                                                <th class="min-w-100px">Appointment Status</th>
                                                                <th class="min-w-50px text-center">Actions</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                                            <tr>
                                                                <td>
                                                                    <label class="fw-semibold fs-7 text-black">
                                                                        <?php $newTime = strtotime("+5 days +1 hours");
                                                                        echo date("d-M-Y h:i A",   $newTime); ?>
                                                                    </label>
                                                                </td>
                                                                <td>
                                                                    <div>
                                                                        <label class="text-black fs-7 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Connecting Way">Zoom</label>
                                                                        <a href="https://us02web.zoom.us/j/12345678901?pwd=abcdefghijklmno" class=" fs-10 text-black badge rounded" style="background-color:#ace0ac" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Meeting Link"><span class="mdi mdi-link-variant"></span></a>
                                                                    </div>
                                                                    <span class="fw-semibold fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Online">Online</span>
                                                                </td>
                                                                <td>
                                                                    <div class="avatar-group d-flex">
                                                                        <div class="avatar me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Assigned Staff">
                                                                            <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="avatar" class="rounded-circle border">
                                                                        </div>
                                                                        <span class="mt-2">Naveen</span>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="badge bg-warning rounded fw-semibold fs-8 text-black">Appointment Scheduled</div>
                                                                </td>
                                                                <td>
                                                                    <div class="text-center">
                                                                        <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_appointment">
                                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3 text-black"></i></span>
                                                                        </a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-requirements_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Requirements Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 common_table">
                                                    <thead>
                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                            <th class="min-w-250px">Requirements</th>
                                                            <th class="min-w-150px text-center">Documents</th>
                                                            <th class="min-w-150px text-center">Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                                        <tr>
                                                            <td>
                                                                <div class="text-black fw-semibold fs-7">I need to provide my exact PhD research topic or title.</div>
                                                            </td>
                                                            <td class="text-center">
                                                                <a href="javascript:;" class="mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="View Attachments" data-bs-original-title="View Attachments">
                                                                    <span><i class="mdi mdi-download-circle-outline text-success fs-2"></i></span>
                                                                </a>
                                                            </td>
                                                            <td class="text-center">
                                                                <label class="text-white bg-success border border-gray-400i rounded-pill px-2 fw-semibold fs-4" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed">&#10003;</label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <div class="text-black fw-semibold fs-7">I should share my university's thesis formatting rules (PDF or document). It includes margin size, font style, spacing, and referencing format. Following these ensures the thesis meets official standards.</div>
                                                            </td>
                                                            <td class="text-center">
                                                                <a href="javascript:;" class="mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="View Attachments" data-bs-original-title="View Attachments">
                                                                    <span><i class="mdi mdi-download-circle-outline text-success fs-2"></i></span>
                                                                </a>
                                                            </td>
                                                            <td class="text-center">
                                                                <label class="text-white bg-success border border-gray-400i rounded-pill px-2 fw-semibold fs-4" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed">&#10003;</label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <div class="text-black fw-semibold fs-7">If I have an approved proposal, I should send it. It explains my research idea, scope, and background. Writers use this to follow the approved research path.</div>
                                                            </td>
                                                            <td class="text-center">
                                                                <a href="javascript:;" class="mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="View Attachments" data-bs-original-title="View Attachments">
                                                                    <span><i class="mdi mdi-download-circle-outline text-success fs-2"></i></span>
                                                                </a>
                                                            </td>
                                                            <td class="text-center">
                                                                <label class="text-white bg-danger border border-gray-400i rounded-pill px-2 fw-semibold fs-4" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pending">&#10005;</label>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-task_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Task Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                                    <thead>
                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                            <th class="min-w-125px">Task</th>
                                                            <th class="min-w-125px">Assigned Date</th>
                                                            <th class="min-w-80px">Working /<br>Usage Hrs</th>
                                                            <th class="min-w-50px">Assigned To</th>
                                                            <th class="min-w-100px">Status</th>
                                                            <th class="min-w-50px">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                                        <tr>
                                                            <td>
                                                                <label class="text-black fw-semibold fs-7 text-wrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task">Thesis Writing Support</label>
                                                                <div class="d-block">
                                                                    <label class="text-dark fw-semibold fs-8 text-wrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Services">Thesis Writing</label>
                                                                </div>
                                                                <div class="progress border border-gray-400i rounded bg-label-primary w-175px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task Progress : 10%">
                                                                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 10%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100">10%</div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start  Date">
                                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                                    echo date("d-M-Y h:i A"); ?></label>
                                                                <div class="d-block">
                                                                    <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="End Date">
                                                                        <?php date_default_timezone_set('Asia/Kolkata');
                                                                        echo date("d-M-Y h:i A", strtotime("+15 days")); ?>
                                                                    </label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <label class="fw-semibold text-black fs-7">05 Hrs</label>
                                                                <div class="d-block">
                                                                    <label class="badge bg-transparent border border-info fw-semibold text-black fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Usage Hours">03 Hrs</label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="d-flex align-items-center avatar-group mb-4">
                                                                    <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                                                        <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                                                                    </div>
                                                                    <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Iswarya D">
                                                                        <img src="{{asset('assets/phdizone_images/staff_1.png')}}" alt="Staff" class="rounded-circle">
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="badge bg-info text-black fs-7 fw-semibold" style="background-color: #FFA500 !important;">Task In Progress</div>
                                                            </td>
                                                            <td>
                                                                <span class="text-center">
                                                                    <a href="javascript:;" class="text-black fw-bold" data-bs-toggle="modal" data-bs-target="#kt_modal_view_task">
                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3 text-black"></i></span>
                                                                    </a>
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <label class="text-black fw-semibold fs-7 text-wrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task">Literature Review</label>
                                                                <div class="d-block">
                                                                    <label class="text-dark fw-semibold fs-8 text-wrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Services">Thesis Writing</label>
                                                                </div>
                                                                <div class="progress border border-gray-400i rounded bg-label-primary w-175px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task Progress : 100%">
                                                                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start  Date">
                                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                                    echo date("d-M-Y h:i A", strtotime("-6 days")); ?></label>
                                                                <div class="d-block">
                                                                    <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="End Date">
                                                                        <?php date_default_timezone_set('Asia/Kolkata');
                                                                        echo date("d-M-Y h:i A", strtotime("-1 days")); ?>
                                                                    </label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <label class="fw-semibold text-black fs-7">06 Hrs</label>
                                                                <div class="d-block">
                                                                    <label class="badge bg-transparent border border-info fw-semibold text-black fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Usage Hours">06 Hrs</label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="d-flex align-items-center avatar-group mb-4">
                                                                    <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                                                        <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                                                                    </div>
                                                                    <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Iswarya D">
                                                                        <img src="{{asset('assets/phdizone_images/staff_1.png')}}" alt="Staff" class="rounded-circle">
                                                                    </div>
                                                                    <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Guberan J">
                                                                        <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="Staff" class="rounded-circle">
                                                                    </div>
                                                                    <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                        <span class="avatar-initial rounded-circle">+1</span>
                                                                    </div>
                                                                    <div class="dropdown-menu dropdown-menu-start w-250px">
                                                                        <div class="scroll-y max-h-200px px-3 py-1">
                                                                            <div class="d-flex align-items-center mb-2">
                                                                                <div class="symbol me-2">
                                                                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                                                                        <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="staff" class="image-input-wrapper w-px-40 h-px-40 border border-gray-700i rounded-circle" />
                                                                                    </div>
                                                                                </div>
                                                                                <div class="mb-0">
                                                                                    <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff">Naveen R</label>
                                                                                    <div class="d-block mt-n1">
                                                                                        <div class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Role">Junior Executive</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <hr class="mt-1 mb-1">
                                                                            <div class="d-flex align-items-center mb-2">
                                                                                <div class="symbol me-2">
                                                                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                                                                        <img src="{{asset('assets/phdizone_images/staff_1.png')}}" alt="staff" class="image-input-wrapper w-px-40 h-px-40 border border-gray-700i rounded-circle" />
                                                                                    </div>
                                                                                </div>
                                                                                <div class="mb-0">
                                                                                    <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff">Iswarya D</label>
                                                                                    <div class="d-block mt-n1">
                                                                                        <div class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Role">Junior Executive</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <hr class="mt-1 mb-1">
                                                                            <div class="d-flex align-items-center mb-2">
                                                                                <div class="symbol me-2">
                                                                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                                                                        <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="staff" class="image-input-wrapper w-px-40 h-px-40 border border-gray-700i rounded-circle" />
                                                                                    </div>
                                                                                </div>
                                                                                <div class="mb-0">
                                                                                    <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff">Guberan J</label>
                                                                                    <div class="d-block mt-n1">
                                                                                        <div class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Role">Senior Executive</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <hr class="mt-1 mb-1">
                                                                            <div class="d-flex align-items-center mb-2">
                                                                                <div class="symbol me-2">
                                                                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                                                                        <img src="{{asset('assets/phdizone_images/staff_3.png')}}" alt="staff" class="image-input-wrapper w-px-40 h-px-40 border border-gray-700i rounded-circle" />
                                                                                    </div>
                                                                                </div>
                                                                                <div class="mb-0">
                                                                                    <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff">Indhumathi K</label>
                                                                                    <div class="d-block mt-n1">
                                                                                        <div class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Role">Junior Executive</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="badge bg-info text-white fs-7 fw-semibold" style="background-color: #218838 !important;">Task Completed</div>
                                                            </td>
                                                            <td>
                                                                <span class="text-center">
                                                                    <a href="javascript:;" class="text-black fw-bold" data-bs-toggle="modal" data-bs-target="#kt_modal_view_task">
                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3 text-black"></i></span>
                                                                    </a>
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-deliverables_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Deliverable Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table align-top table-row-dashed gy-0 gs-1 common_table">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                <th class="min-w-125px">Date & Time</th>
                                                                <th class="min-w-125px">Services</th>
                                                                <th class="min-w-80px">Deliverables</th>
                                                                <th class="min-w-100px text-center">Delivered Task</th>
                                                                <th class="min-w-100px">Status</th>
                                                                <th class="min-w-50px text-center">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                                            <tr>
                                                                <td>
                                                                    <label class="fs-7">
                                                                        <?php date_default_timezone_set('Asia/Kolkata');
                                                                        echo date("d-M-Y"); ?>
                                                                    </label>
                                                                    <div class="d-block">
                                                                        <label class="fs-8 text-dark fw-semibold">
                                                                            <?php date_default_timezone_set('Asia/Kolkata');
                                                                            echo date("h:i A"); ?>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="fw-semibold text-black fs-7 text-wrap min-w-200px max-w-350px">Thesis Writing</div>
                                                                    <div class="d-block mb-1">
                                                                        <div class="fw-semibold text-dark fs-8 text-wrap min-w-200px max-w-350px">Writing Products</div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="text-black fw-semibold fs-7">Slot 01</div>
                                                                </td>
                                                                <td align="center">
                                                                    <label class="badge bg-transparent rounded-pill fw-semibold text-black fs-7" style="border:1px solid #08a34f;">01</label>
                                                                </td>
                                                                <td>
                                                                    <div class="badge bg-info text-white fs-7 fw-semibold" style="background-color: #117A65 !important;">Delivered</div>
                                                                </td>
                                                                <td>
                                                                    <div class="text-center">
                                                                        <a href="javascript:;" class="text-black fw-bold" data-bs-toggle="modal" data-bs-target="#kt_modal_view_deliverables">
                                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline text-black fs-3"></i></span>
                                                                        </a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-staff_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Staff Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                                    <thead>
                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                            <th class="min-w-50px">Staff</th>
                                                            <th class="min-w-125px">Services</th>
                                                            <th class="min-w-125px text-center">Task<br><span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total / Complete / Pending">(T / C / P)</span></th>
                                                            <th class="min-w-125px text-center">Total Allocated Hrs</th>
                                                            <th class="min-w-125px text-center">Total Usage Hrs</th>
                                                            <th class="min-w-100px">Progress</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                                        <tr>
                                                            <td>
                                                                <div class="d-flex align-items-center">
                                                                    <div class="symbol symbol-35px me-2">
                                                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                                                            <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="mb-0">
                                                                        <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff">Naveen R</label>
                                                                        <div class="d-block">
                                                                            <div class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Nick Name">Nirmal</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="fw-semibold text-black fs-7 text-wrap max-w-200px">Thesis Writing</div>
                                                                <div class="d-block mb-1">
                                                                    <div class="fw-semibold text-dark fs-8 text-wrap max-w-200px">Writing Products</div>
                                                                </div>
                                                            </td>
                                                            <td align="center">
                                                                <label class="badge bg-secondary rounded-pill fw-semibold text-white fs-7 me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Task">10</label>
                                                                <label class="badge bg-transparent rounded-pill fw-semibold text-black fs-7 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed Task" style="border:1px solid #08a34f;">01</label>
                                                                <label class="badge bg-danger rounded-pill fw-semibold text-white fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pending Task">09</label>
                                                            </td>
                                                            <td align="center">
                                                                <label class="fw-semibold text-black fs-7">05 Hrs</label>
                                                            </td>
                                                            <td align="center">
                                                                <label class="badge bg-transparent border border-info fw-semibold text-black fs-7">03 Hrs</label>
                                                            </td>
                                                            <td>
                                                                <div class="progress border border-gray-400i rounded bg-label-primary w-175px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Progress : 10%">
                                                                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 10%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100">10%</div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <div class="d-flex align-items-center">
                                                                    <div class="symbol symbol-35px me-2">
                                                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                                                            <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="mb-0">
                                                                        <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff">Guberan J</label>
                                                                        <div class="d-block">
                                                                            <div class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Nick Name">Sakthivel</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="fw-semibold text-black fs-7 text-wrap max-w-200px">Thesis Writing</div>
                                                                <div class="d-block mb-1">
                                                                    <div class="fw-semibold text-dark fs-8 text-wrap max-w-200px">Writing Products</div>
                                                                </div>
                                                            </td>
                                                            <td align="center">
                                                                <label class="badge bg-secondary rounded-pill fw-semibold text-white fs-7 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Task">15</label>
                                                                <label class="badge bg-transparent rounded-pill fw-semibold text-black fs-7 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed Task" style="border:1px solid #08a34f;">15</label>
                                                                <label class="badge bg-danger rounded-pill fw-semibold text-white fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pending Task">0</label>
                                                            </td>
                                                            <td align="center">
                                                                <label class="fw-semibold text-black fs-7">05 Hrs</label>
                                                            </td>
                                                            <td align="center">
                                                                <label class="badge bg-transparent border border-info fw-semibold text-black fs-7">04 Hrs</label>
                                                            </td>
                                                            <td>
                                                                <div class="progress border border-gray-400i rounded bg-label-primary w-175px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Progress : 100%">
                                                                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-journal_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Journal Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                                    <thead>
                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                            <th class="min-w-150px">Journal / Domain</th>
                                                            <th class="min-w-150px">Paper</th>
                                                            <th class="min-w-150px">Services</th>
                                                            <th class="min-w-100px text-center">Author / Published</th>
                                                            <th class="min-w-100px">Status</th>
                                                            <th class="min-w-50px text-center">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                                        <tr>
                                                            <td>
                                                                <label class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="IEEE Internet of Things Journal">IEEE Internet of Things Journal</label>
                                                                <div class="d-block mt-n2">
                                                                    <label class="fs-8 fw-semibold text-dark text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Internet of Things, Communications, Computer Science">Internet of Things, Communications, Computer Science</label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems">PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems</div>
                                                            </td>
                                                            <td>
                                                                <div class="fw-semibold text-black fs-7 text-wrap max-w-200px">Thesis Writing</div>
                                                                <div class="d-block mb-1">
                                                                    <div class="fw-semibold text-dark fs-8 text-wrap max-w-200px">Writing Products</div>
                                                                </div>
                                                            </td>
                                                            <td align="center">-</td>
                                                            <td>
                                                                <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color:#007BFF !important;">Submitted</div>
                                                            </td>
                                                            <td>
                                                                <div class="text-center">
                                                                    <a href="javascript:;" class="text-black fw-bold me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_view_journal_monitor">
                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3"></i></span>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <label class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="IEEE Internet of Things Journal">IEEE Internet of Things Journal</label>
                                                                <div class="d-block mt-n2">
                                                                    <label class="fs-8 fw-semibold text-dark text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Internet of Things, Communications, Computer Science">Internet of Things, Communications, Computer Science</label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems">PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems</div>
                                                            </td>
                                                            <td>
                                                                <div class="fw-semibold text-black fs-7 text-wrap max-w-200px">Thesis Writing</div>
                                                                <div class="d-block mb-1">
                                                                    <div class="fw-semibold text-dark fs-8 text-wrap max-w-200px">Writing Products</div>
                                                                </div>
                                                            </td>
                                                            <td align="center">-</td>
                                                            <td>
                                                                <div class="badge bg-info text-black mb-1 fs-7 fw-semibold" style="background-color:#FFA500 !important;">Reviewed</div>
                                                            </td>
                                                            <td>
                                                                <div class="text-center">
                                                                    <a href="javascript:;" class="text-black fw-bold me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_view_journal_monitor">
                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3"></i></span>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <label class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="IEEE Internet of Things Journal">IEEE Internet of Things Journal</label>
                                                                <div class="d-block mt-n2">
                                                                    <label class="fs-8 fw-semibold text-dark text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Internet of Things, Communications, Computer Science">Internet of Things, Communications, Computer Science</label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems">PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems</div>
                                                            </td>
                                                            <td>
                                                                <div class="fw-semibold text-black fs-7 text-wrap max-w-200px">Thesis Writing</div>
                                                                <div class="d-block mb-1">
                                                                    <div class="fw-semibold text-dark fs-8 text-wrap max-w-200px">Writing Products</div>
                                                                </div>
                                                            </td>
                                                            <td align="center">-</td>
                                                            <td>
                                                                <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color:#800080 !important;">Resubmitted</div>
                                                            </td>
                                                            <td>
                                                                <div class="text-center">
                                                                    <a href="javascript:;" class="text-black fw-bold me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_view_journal_monitor">
                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3"></i></span>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <label class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="IEEE Internet of Things Journal">IEEE Internet of Things Journal</label>
                                                                <div class="d-block mt-n2">
                                                                    <label class="fs-8 fw-semibold text-dark text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Internet of Things, Communications, Computer Science">Internet of Things, Communications, Computer Science</label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems">PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems</div>
                                                            </td>
                                                            <td>
                                                                <div class="fw-semibold text-black fs-7 text-wrap max-w-200px">Thesis Writing</div>
                                                                <div class="d-block mb-1">
                                                                    <div class="fw-semibold text-dark fs-8 text-wrap max-w-200px">Writing Products</div>
                                                                </div>
                                                            </td>
                                                            <td align="center">-</td>
                                                            <td>
                                                                <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color:#28A745 !important;">Accepted</div>
                                                            </td>
                                                            <td>
                                                                <div class="text-center">
                                                                    <a href="javascript:;" class="text-black fw-bold me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_view_journal_monitor">
                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3"></i></span>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <label class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="IEEE Internet of Things Journal">IEEE Internet of Things Journal</label>
                                                                <div class="d-block mt-n2">
                                                                    <label class="fs-8 fw-semibold text-dark text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Internet of Things, Communications, Computer Science">Internet of Things, Communications, Computer Science</label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems">PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems</div>
                                                            </td>
                                                            <td>
                                                                <div class="fw-semibold text-black fs-7 text-wrap max-w-200px">Thesis Writing</div>
                                                                <div class="d-block mb-1">
                                                                    <div class="fw-semibold text-dark fs-8 text-wrap max-w-200px">Writing Products</div>
                                                                </div>
                                                            </td>
                                                            <td align="center">-</td>
                                                            <td>
                                                                <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color:#DC3545 !important;">Rejected</div>
                                                            </td>
                                                            <td>
                                                                <div class="text-center">
                                                                    <a href="javascript:;" class="text-black fw-bold me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_view_journal_monitor">
                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3"></i></span>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <label class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="IEEE Internet of Things Journal">IEEE Internet of Things Journal</label>
                                                                <div class="d-block mt-n2">
                                                                    <label class="fs-8 fw-semibold text-dark text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Internet of Things, Communications, Computer Science">Internet of Things, Communications, Computer Science</label>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="fs-7 fw-semibold text-black text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems">PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems</div>
                                                            </td>
                                                            <td>
                                                                <div class="fw-semibold text-black fs-7 text-wrap max-w-200px">Thesis Writing</div>
                                                                <div class="d-block mb-1">
                                                                    <div class="fw-semibold text-dark fs-8 text-wrap max-w-200px">Writing Products</div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="d-flex align-items-center gap-1">
                                                                    <label class="fs-7 fw-semibold text-black text-truncate max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Khwaja Mansoor, Mehreen Afzal, Waseem Iqbal, Yawar Abbas, Shynar Mussiraliyeva, Abdellah Chehri">Khwaja Mansoor, Mehreen Afzal, Waseem Iqbal, Yawar Abbas, Shynar Mussiraliyeva, Abdellah Chehri</label>
                                                                    <a href="https://linkinghub.elsevier.com/retrieve/pii/S2542660524001690" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Link"><i class="mdi mdi-link-variant text-danger fs-4"></i></a>
                                                                </div>
                                                                <div class="d-block">
                                                                    <div class="fs-8 fw-semibold text-dark">June 2024</div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #17A2B8 !important;">Published</div>
                                                            </td>
                                                            <td>
                                                                <div class="text-center">
                                                                    <a href="javascript:;" class="text-black fw-bold me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_view_journal_monitor">
                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3"></i></span>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab_service_2" role="tabpanel">
                        <div class="row mt-2">
                            <div class="col-lg-2">
                                <div class="nav-align-left nav-tabs-shadow ">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item ">
                                            <button
                                                style="width:100%;"
                                                type="button"
                                                class="nav-link active"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-left-align-home"
                                                aria-controls="navs-left-align-home"
                                                aria-selected="true">
                                               
                                                <div class="d-flex align-items-center gap-2">
                                                    <span class="mdi mdi-clock-time-eight fs-3"></span>
                                                    <label class="">  Milestone 1</label>
                                                </div>
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-left-align-profile"
                                                aria-controls="navs-left-align-profile"
                                                aria-selected="false">
                                               
                                                <div class="d-flex align-items-center gap-2">
                                                    <span class="mdi mdi-clock-time-eight fs-3"></span>
                                                    <label class=""> Milestone 2</label>
                                                </div>
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-left-align-messages"
                                                aria-controls="navs-left-align-messages"
                                                aria-selected="false">
                                                
                                                <div class="d-flex align-items-center gap-2">
                                                    <span class="mdi mdi-book fs-3"></span>
                                                    <label class="">Journal</label>
                                                </div>
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-left-align-chat"
                                                aria-controls="navs-left-align-chat"
                                                aria-selected="false">
                                                <div class="d-flex align-items-center gap-2">
                                                    <span class="mdi mdi-chat-processing fs-3"></span>
                                                    <label class="">  Chat History</label>
                                                </div>
                                            </button>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-10 d-flex align-items-center justify-content-center ">
                                <div class="tab-content p-0 m-0">
                                    <div class="tab-pane fade show active" id="navs-left-align-home">
                                        <div class="d-flex align-items-center justify-content-center">
                                            <div class="timeline-wrapper " >

                                                <div class="timeline-row ">
                                                    <div class="timeline-time">11-Jan-2025 08:45 AM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Created As Lead </h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Created By <label class="fw-semibold">Praveen Kumar M K</label> - Sales Executive</label>
                                                            <!-- <span class="badge bg-label-secondary px-3 "> </span> -->
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="timeline-row ">
                                                    <div class="timeline-time">11-Jan-2025 09:30 AM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Proposal Generated </h6>
                                                        <div class="d-flex align-items-center gap-2 ">
                                                            <label>Generated By <label class="fw-semibold">Praveen Kumar M K</label> -  Business Head</label>
                                                        </div>
                                                        <div class="d-flex align-items-center gap-1 badge bg-dark mt-2 mb-4 " style="width:fit-content;">
                                                            <span class="mdi mdi-file-document"></span>
                                                            <label class="fs-6 fw-semibold" >Writing literature review summaries</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row ">
                                                    <div class="timeline-time">11-Jan-2025 09:30 AM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>CRE Assigned</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <div class="d-flex gap-2 align-items-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                                                                    alt="avatar"
                                                                    class="rounded-circle img-fluid "
                                                                    style="width: 50px; height: 50px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-start">
                                                                    <label >Saraswathi R</label>
                                                                    <label class="badge bg-label-info text-black">CRE</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 10:15 AM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Payment Paid</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Amount</label>
                                                            <span class="badge bg-label-success px-3 text-black fw-semibold fs-7">&#8377; 20,000</span>
                                                            <label>Paid for <label class="badge bg-label-danger px-2  text-black fw-semibold fs-7">Mile Stone 1</label></label>
                                                        </div>
                                                        <div class="d-flex align-items-center gap-3 mb-4">
                                                            <div class="d-flex flex-column align-items-center justify-content-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/Document.jpg') }}"
                                                                    alt="avatar"
                                                                    class=" img-fluid border rounded"
                                                                    style="width: 80px; height: 80px; object-fit: cover;"
                                                                >
                                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                                    <label for="">Img.jpg</label>
                                                                </div>
                                                            </div>
                                                            
                                                            
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 11:45 AM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Proposal Verified</h6>
                                                    <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Verified By <label class="fw-semibold">Praveen Kumar M K</label> -  Business Head</label>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Payment Verified</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Amount</label>
                                                            <span class="badge bg-label-success px-3 text-black fw-semibold fs-7">&#8377; 20,000</span>
                                                            <label>Verified for <label class="badge bg-label-danger px-2  text-black fw-semibold fs-7">Mile Stone 1</label></label>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6 class="badge fs-6 fw-semibold" style="background: linear-gradient(135deg, #1e3c72, #2a5298);">Converted As Customer</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Receipt Sent</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Waiting For 1st Call Confirmation</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Attended By <label class="fw-semibold">Mathes M</label> -  Business Head</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row ">
                                                    <div class="timeline-time">11-Jan-2025 09:30 AM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>PC Assigned</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <div class="d-flex gap-2 align-items-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                                                                    alt="avatar"
                                                                    class="rounded-circle img-fluid "
                                                                    style="width: 50px; height: 50px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-start">
                                                                    <label >Harini S K</label>
                                                                    <label class="badge bg-label-info text-black">PC</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Scheduled Dates</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label >Developement Date : <label class="fw-semibold">18/04/26</label></label>
                                                            <label >|</label>
                                                            <label >Delivery Date : <label class="fw-semibold">05/07/26</label></label>
                                                            <label >|</label>
                                                            <label >End Date : <label class="fw-semibold">20/07/26</label></label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Verified Work Order</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Product Added - <label class="fw-semibold me-1">Writing literature review summaries</label></h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Created By <label class="fw-semibold">Mathes M</label> -  Business Head</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Product Added - <label class="fw-semibold me-1">MileStone 1 Accpected</label></h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Accpected By <label class="fw-semibold">Mathes M</label> -  Business Head</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Product Added - <label class="fw-semibold me-1">MileStone 1 Unlocked</label></h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Unlocked By <label class="fw-semibold">Mathes M</label> -  Business Head</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                        <div class="timeline-center">
                                                            <span class="timeline-dot"></span>
                                                            <span class="timeline-line"></span>
                                                        </div>
                                                    <div class="timeline-content mb-4" style="width:100%;">
                                                        <h6>Assigned Production Staffs </h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <img
                                                                src="{{ asset('assets/phdizone_images/user_3.png') }}"
                                                                alt="avatar"
                                                                class="rounded-circle img-fluid pull-up"
                                                                style="width: 40px; height: 40px; object-fit: cover;"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Sarvesh K (Developer)"
                                                            >
                                                            <img
                                                                src="{{ asset('assets/phdizone_images/user_3.png') }}"
                                                                alt="avatar"
                                                                class="rounded-circle img-fluid pull-up"
                                                                style="width: 40px; height: 40px; object-fit: cover;"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Priya L (Content Writer)"
                                                            >
                                                        </div>
                                                        <label>Assigned By <label class="fw-semibold">Nithish Kumar A</label> -  Process Coordinator</label>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Tasked Assigned</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Assigned By <label class="fw-semibold">Nithish Kumar A</label> -  Process Coordinator</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Service In Progress</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Documents Attached</h6>
                                                        <div class="d-flex align-items-center gap-3 mb-4">
                                                            <div class="d-flex flex-column align-items-center justify-content-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/Document.jpg') }}"
                                                                    alt="avatar"
                                                                    class=" img-fluid border rounded"
                                                                    style="width: 80px; height: 80px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                                    <label for="">Refreance(1)</label>
                                                                    <label for="">.ppt</label>
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="d-flex flex-column align-items-center justify-content-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/Document.jpg') }}"
                                                                    alt="avatar"
                                                                    class=" img-fluid border rounded"
                                                                    style="width: 80px; height: 80px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                                    <label for="">Refreance(2)</label>
                                                                    <label for="">.pdf</label>
                                                                </div>
                                                            </div>
                                                            <div class="d-flex flex-column align-items-center justify-content-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/Document.jpg') }}"
                                                                    alt="avatar"
                                                                    class=" img-fluid border rounded"
                                                                    style="width: 80px; height: 80px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                                    <label for="">Refreance(3)</label>
                                                                    <label for="">.xlxx</label>
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="d-flex flex-column align-items-center justify-content-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/Document.jpg') }}"
                                                                    alt="avatar"
                                                                    class=" img-fluid border rounded"
                                                                    style="width: 80px; height: 80px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                                    <label for="">Refreance(4)</label>
                                                                    <label for="">.ppt</label>
                                                                </div>
                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Verify Completion</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Delivery Checklist Verified By <label class="fw-semibold">Nithish Kumar A</label> -  Process Coordinator</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6 class="badge px-3 fs-6 fw-semibold" style="background: linear-gradient(to right, #00b09b, #96c93d);" >Moved To Delivery</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            
                                                        </div>
                                                    </div>
                                                </div>



                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-left-align-profile">
                                        <div class="d-flex align-items-center justify-content-center">
                                            <div class="timeline-wrapper " >
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Verified Work Order</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Product Added - <label class="fw-semibold me-1">Writing literature review summaries</label></h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Created By <label class="fw-semibold">Mathes M</label> -  Business Head</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Product Added - <label class="fw-semibold me-1">MileStone 2 Accpected</label></h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Accpected By <label class="fw-semibold">Mathes M</label> -  Business Head</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Product Added - <label class="fw-semibold me-1">MileStone 2 Unlocked</label></h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Unlocked By <label class="fw-semibold">Mathes M</label> -  Business Head</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                        <div class="timeline-center">
                                                            <span class="timeline-dot"></span>
                                                            <span class="timeline-line"></span>
                                                        </div>
                                                    <div class="timeline-content mb-4" style="width:100%;">
                                                        <h6>Assigned Production Staffs </h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <img
                                                                src="{{ asset('assets/phdizone_images/user_3.png') }}"
                                                                alt="avatar"
                                                                class="rounded-circle img-fluid pull-up"
                                                                style="width: 40px; height: 40px; object-fit: cover;"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Sarvesh K (Developer)"
                                                            >
                                                            <img
                                                                src="{{ asset('assets/phdizone_images/user_3.png') }}"
                                                                alt="avatar"
                                                                class="rounded-circle img-fluid pull-up"
                                                                style="width: 40px; height: 40px; object-fit: cover;"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Priya L (Content Writer)"
                                                            >
                                                        </div>
                                                        <label>Assigned By <label class="fw-semibold">Nithish Kumar A</label> -  Process Coordinator</label>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Tasked Assigned</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Assigned By <label class="fw-semibold">Nithish Kumar A</label> -  Process Coordinator</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Service In Progress</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Documents Attached</h6>
                                                        <div class="d-flex align-items-center gap-3 mb-4">
                                                            <div class="d-flex flex-column align-items-center justify-content-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/Document.jpg') }}"
                                                                    alt="avatar"
                                                                    class=" img-fluid border rounded"
                                                                    style="width: 80px; height: 80px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                                    <label for="">Refreance(1)</label>
                                                                    <label for="">.ppt</label>
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="d-flex flex-column align-items-center justify-content-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/Document.jpg') }}"
                                                                    alt="avatar"
                                                                    class=" img-fluid border rounded"
                                                                    style="width: 80px; height: 80px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                                    <label for="">Refreance(2)</label>
                                                                    <label for="">.pdf</label>
                                                                </div>
                                                            </div>
                                                            <div class="d-flex flex-column align-items-center justify-content-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/Document.jpg') }}"
                                                                    alt="avatar"
                                                                    class=" img-fluid border rounded"
                                                                    style="width: 80px; height: 80px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                                    <label for="">Refreance(3)</label>
                                                                    <label for="">.xlxx</label>
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="d-flex flex-column align-items-center justify-content-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/Document.jpg') }}"
                                                                    alt="avatar"
                                                                    class=" img-fluid border rounded"
                                                                    style="width: 80px; height: 80px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                                    <label for="">Refreance(4)</label>
                                                                    <label for="">.ppt</label>
                                                                </div>
                                                            </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Verify Completion</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <label>Delivery Checklist Verified By <label class="fw-semibold">Nithish Kumar A</label> -  Process Coordinator</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6 class="badge px-3 fs-6 fw-semibold" style="background: linear-gradient(to right, #00b09b, #96c93d);" >Moved To Delivery</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            
                                                        </div>
                                                    </div>
                                                </div>



                                            </div>
                                        </div>    
                                    </div>
                                    <div class="tab-pane fade" id="navs-left-align-messages">
                                        <div class="d-flex align-items-center justify-content-center">
                                            <div class="timeline-wrapper " >

                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>Ssda_aoa: Stacked Sparse Denoising Autoencoder With Archimedes Optimization Algorithm Based Oral Cancer Detection On Histopathological Images</h6>
                                                        <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center gap-2 ">
                                                                <label>Ayurveda</label>
                                                                <label>|</label>
                                                                <label>Scopus-Q1</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>PC Assigned</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <div class="d-flex gap-2 align-items-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                                                                    alt="avatar"
                                                                    class="rounded-circle img-fluid "
                                                                    style="width: 50px; height: 50px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-start">
                                                                    <label >Saraswathi R</label>
                                                                    <label class="badge bg-label-info text-black">PC</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center  ">
                                                                <label>Assigned By <label class="fw-semibold">Praveen Kumar M K</label> -  Business Head</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6 class="badge px-3 bg-label-success fw-semibold fs-6">PC Verify & Approve The Requriment</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>JTL Assigned</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <div class="d-flex gap-2 align-items-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                                                                    alt="avatar"
                                                                    class="rounded-circle img-fluid "
                                                                    style="width: 50px; height: 50px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-start">
                                                                    <label >Saraswathi R</label>
                                                                    <label class="badge bg-label-info text-black">JTL</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center  ">
                                                                <label>Assigned By <label class="fw-semibold">Praveen Kumar M K</label> -  Project Coordinator</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6 class="badge px-3 bg-label-success fw-semibold fs-6">JTL Verify & Approve The Requriment</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6>JE Assigned</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            <div class="d-flex gap-2 align-items-center">
                                                                <img
                                                                    src="{{ asset('assets/phdizone_images/user_3.png') }}"
                                                                    alt="avatar"
                                                                    class="rounded-circle img-fluid "
                                                                    style="width: 50px; height: 50px; object-fit: cover;"
                                                                    
                                                                >
                                                                <div class="d-flex flex-column align-items-start">
                                                                    <label >Krithiga J S</label>
                                                                    <label class="badge bg-label-info text-black">JE</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center  ">
                                                                <label>Assigned By <label class="fw-semibold">Seshanand S</label> -  Journal TL</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6 class="badge px-3 bg-label-success fw-semibold fs-6">JE Verify & Approve The Requriment</h6>
                                                        <div class="d-flex align-items-center gap-2 mb-4">
                                                            
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <div class="d-flex align-items-center justify-content-between">
                                                            <h6> <label class="badge text-white fs-7" style="background:#099DDA;">Submitted</label></h6>
                                                           
                                                        </div>
                                                        <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center gap-2 ">
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-book-open-blank-variant"></span>
                                                                    <label>Neural Computing & Applications</label>
                                                                </div>
                                                                <label>|</label>
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-alpha-i-box"></span>
                                                                    <label>Computer Science Engineering</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6> <label  class="badge text-white fs-7" style="background:#A8AB14;">With Editor</label></h6>
                                                         <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center gap-2 ">
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-book-open-blank-variant"></span>
                                                                    <label>Neural Computing & Applications</label>
                                                                </div>
                                                                <label>|</label>
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-alpha-i-box"></span>
                                                                    <label>Computer Science Engineering</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6> <label  class="badge text-white fs-7" style="background:#ED9900;">Under Reviewer</label></h6>
                                                        <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center gap-2 ">
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-book-open-blank-variant"></span>
                                                                    <label>Neural Computing & Applications</label>
                                                                </div>
                                                                <label>|</label>
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-alpha-i-box"></span>
                                                                    <label>Computer Science Engineering</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6> <label  class="badge text-white fs-7" style="background:#00AD6D;">Revision</label></h6>
                                                        <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center gap-2 ">
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-book-open-blank-variant"></span>
                                                                    <label>Neural Computing & Applications</label>
                                                                </div>
                                                                <label>|</label>
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-alpha-i-box"></span>
                                                                    <label>Computer Science Engineering</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6> <label  class="badge text-white fs-7" style="background:#007BFF;">Accepted</label></h6>
                                                        <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center gap-2 ">
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-book-open-blank-variant"></span>
                                                                    <label>Neural Computing & Applications</label>
                                                                </div>
                                                                <label>|</label>
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-alpha-i-box"></span>
                                                                    <label>Computer Science Engineering</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6> <label  class="badge text-white fs-7" style="background:#FF4D49;">Rejected</label></h6>
                                                        <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center gap-2 ">
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-book-open-blank-variant"></span>
                                                                    <label>Neural Computing & Applications</label>
                                                                </div>
                                                                <label>|</label>
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-alpha-i-box"></span>
                                                                    <label>Computer Science Engineering</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6> <label  class="badge text-white fs-7" style="background:#940097;">E-Proofing</label></h6>
                                                        <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center gap-2 ">
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-book-open-blank-variant"></span>
                                                                    <label>Neural Computing & Applications</label>
                                                                </div>
                                                                <label>|</label>
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-alpha-i-box"></span>
                                                                    <label>Computer Science Engineering</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="timeline-row">
                                                    <div class="timeline-time">11-Jan-2025 12:30 PM</div>
                                                    <div class="timeline-center">
                                                        <span class="timeline-dot"></span>
                                                        <span class="timeline-line"></span>
                                                    </div>
                                                    <div class="timeline-content mb-4">
                                                        <h6> <label  class="badge text-white fs-7" style="background:#7239EA;">Published	</label></h6>
                                                        <div class="d-flex align-items-center mb-4">
                                                            <div class="d-flex align-items-center gap-2 ">
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-book-open-blank-variant"></span>
                                                                    <label>Neural Computing & Applications</label>
                                                                </div>
                                                                <label>|</label>
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <span class="mdi mdi-alpha-i-box"></span>
                                                                    <label>Computer Science Engineering</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                               
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-left-align-chat">
                                        <div class="row">
                                            <div class="col-lg-12 mb-5 " style="width: 1027px;">
                                                <div class="chat-container" style="width: 1027px;">
                                                    <div class="chat-header d-flex align-items-center gap-2">
                                                        <img
                                                        src="{{ asset('assets/phdizone_images/user_3.png') }}"
                                                        class="rounded-circle"
                                                        style="width:40px;height:40px;object-fit:cover;"
                                                        >

                                                        <div class="d-flex flex-column">
                                                        <label class="fw-semibold">Praveen Kumar S K</label>
                                                        <label style="font-size:12px;">CRE</label>
                                                        </div>
                                                    </div>

                                                    <div id="chatBox" class="chat-box">

                                                        <div class="chat-date"><span>Today</span></div>

                                                        <div class="chat-msg sent">
                                                        Could you please share the current status?
                                                        <div class="chat-time text-white">02:12 AM</div>
                                                        </div>

                                                        <div class="chat-msg received">
                                                        We have completed the initial data collection and analysis phase.
                                                        <div class="chat-time">02:14 AM</div>
                                                        </div>

                                                        <div class="chat-msg sent">
                                                        That sounds good. What is the expected completion timeline?
                                                        <div class="chat-time text-white">02:15 AM</div>
                                                        </div>

                                                        <div class="chat-msg received">
                                                        The draft report will be ready by tomorrow evening for your review.
                                                        <div class="chat-time">02:17 AM</div>
                                                        </div>

                                                        <div class="chat-msg sent">
                                                        Great. Please ensure all key metrics are included in the report.
                                                        <div class="chat-time text-white">02:18 AM</div>
                                                        </div>

                                                        <div class="chat-msg received">
                                                        Absolutely. We will include performance metrics, risk analysis, and recommendations.
                                                        <div class="chat-time">02:20 AM</div>
                                                        </div>

                                                        <div class="chat-msg sent">
                                                        Perfect. Also, kindly share a summary once the draft is ready.
                                                        <div class="chat-time text-white">02:21 AM</div>
                                                        </div>

                                                        <div class="chat-msg received">
                                                        Sure, we will notify you immediately and share the summary along with the draft.
                                                        <div class="chat-time">02:22 AM</div>
                                                        </div>

                                                        <div class="chat-msg sent">
                                                        Thank you for the update.
                                                        <div class="chat-time text-white">02:23 AM</div>
                                                        </div>

                                                        <div class="chat-msg received">
                                                        You're welcome. Please let us know if you need any additional support.
                                                        <div class="chat-time">02:24 AM</div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                                        
                </div>
            </div>
        </div>
    </div>
</div>






<!--begin::Modal - View Appointment-->
<div class="modal fade" id="kt_modal_view_appointment" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">
                        <span>View Customer Appointment</span>
                        <span class="ms-1 me-1">-</span>
                        <span class="badge bg-warning rounded text-black fw-semibold fs-5">Scheduled</span>
                    </h3>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Appointment Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-6">
                        <label class="badge bg-warning text-black fs-6 fw-bold">15-Jun-2025 10:00 AM</label>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">Priya</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">+91 9876543210</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Appointment Category">Appointment Mode </label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">Online</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Appointment Category">Appointment Conecting Way </label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold d-flex"> <span class="me-2">Zoom</span>
                        <a href="https://us02web.zoom.us/j/12345678901?pwd=abcdefghijklmno" class=" fs-10 text-black badge rounded" style="background-color:#ace0ac" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Meeting Link"><span class="mdi mdi-link-variant"></span></a>
                    </label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Assigned Staff</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">Naveen</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Appointment Reason</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">Initial Discussion</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Description</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">-</label>
                </div>
                <hr>
                <div class="mb-8 text-center">
                    <h4 class="text-center mb-4 text-black">
                        <span>Complete</span>
                    </h4>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Describe Appointment</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">The appointment was completed successfully with professionalism and clear communication. All objectives were met, making the session productive and valuable.</label>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-6">
                        <div class="row mb-4">
                            <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Online video</label>
                            <div class="col-12 mb-1">
                                <div class="border border-gray-600i border-dashed rounded py-1 px-1">
                                    <div class="d-flex mb-1 align-items-center flex-wrap">
                                        <div class="d-block overlay text-center me-1 px-2 py-2">
                                            <video class="w-100" poster="https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-HD.jpg" id="plyr-video-player" playsinline controls download>
                                                <source src="https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-576p.mp4" type="video/mp4" />
                                            </video>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row mb-4">
                            <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Attachment</label>
                            <div class="col-12 mb-1">
                                <div class="border border-gray-600i border-dashed rounded py-1 px-1">
                                    <div class="d-flex mb-1 align-items-center flex-wrap">
                                        <div class="d-block overlay text-center me-1 px-2 py-2">
                                            <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded w-75px h-75px border border-gray-600i rounded" download>
                                                <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}" class="h-75px w-75px" />
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="mb-8 text-center">
                    <h4 class="text-center mb-4 text-black">
                        <span>Re-Shedule</span>
                    </h4>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Cencelled Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">09-Jun-2025 10:00 AM.</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Cencelled Reason</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">The meeting is cancelled due to unforeseen circumstances.</label>
                </div>
                <hr>
                <div class="mb-8 text-center">
                    <h4 class="text-center mb-4 text-black">
                        <span>Cancelled</span>
                    </h4>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Cencelled Reason</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">The meeting is cancelled due to unforeseen circumstances.</label>
                </div>

            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Appointment -->

<!--begin::Modal - View Task-->
<div class="modal fade" id="kt_modal_view_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">
                        <label>View Task Details</label>
                        <label class="ms-1 me-1">-</label>
                        <label class="badge bg-info text-black rounded fw-semibold fs-5" style="background-color: #FFA500 !important;">Task In Progress</label>
                    </h3>
                </div>
                <div class="row mb-4">
                    <div class="col-lg-12 text-black fs-5 mb-1 fw-semibold">
                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task">Thesis Writing Support</span>
                    </div>
                    <div class="col-lg-12">
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <div class="bg-gray-200i border-gray-300i rounded px-1 mb-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Working Hours">
                                <label class="me-1"><i class="mdi mdi-timer-outline text-dark fs-5"></i></label>
                                <label class="text-secondary fw-semibold fs-7">05 Hours</label>
                            </div>
                            <div class="bg-gray-200i border-gray-300i rounded px-1 mb-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Per Hour Cost">
                                <label class="me-1"><i class="mdi mdi-clock-time-three-outline text-dark fs-5"></i></label>
                                <label class="text-info fw-semibold fs-7">&#8377; 1,200</label>
                            </div>
                            <div class="bg-gray-200i border-gray-300i rounded px-1 mb-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assigned Start Date">
                                <label class="me-1"><i class="mdi mdi-timer-play-outline text-dark fs-5"></i></label>
                                <label class="fw-semibold fs-7" style="color: #107a64;"><?php echo date("d-M-Y"); ?></label>
                            </div>
                            <div class="bg-gray-200i border-gray-300i rounded px-1 mb-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assigned End Date">
                                <label class="me-1"><i class="mdi mdi-timer-remove-outline text-dark fs-5"></i></label>
                                <label class="text-danger fw-semibold fs-7"><?php echo date("d-M-Y", strtotime("+15 days")); ?></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Services</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Thesis Writing</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya <span class="fs-7 text-primary">( 2025/MDU01/CUS2334 )</span></label>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black fs-7 fw-semibold">&emsp;&emsp; You will assist in writing and organizing thesis chapters according to the guidelines.</label>
                </div>

                <div class="row mb-8">
                    <div class="col-lg-9 mb-1">
                        <div class="text-dark fs-6 fw-semibold mb-3">Assigned To <span class="text-black fw-bold">&</span> Logged Details</div>
                        <div class="d-flex align-items-center avatar-group gap-3 flex-wrap mb-1">
                            <div class="mb-1">
                                <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                </div>
                                <div class="dropdown-menu w-lg-300px w-sm-100" style="box-shadow: 0px 5px 15px -3px rgba(0, 0, 0, 0.2), 0px 8px 15px 1px rgba(0, 0, 0, 0.14), 0px 3px 15px 2px rgba(0, 0, 0, 0.12) !important;">
                                    <div class="text-black text-center fw-semibold fs-8 px-3 py-2"><u>Naveen R - Logged Details</u></div>
                                    <div class="px-2 border-bottom">
                                        <div class="row">
                                            <div class="col-5 pe-0">
                                                <div class="text-black fw-semibold fs-9">Start Time</div>
                                            </div>
                                            <div class="col-5 pe-0">
                                                <div class="text-black fw-semibold fs-9">End Time</div>
                                            </div>
                                            <div class="col-2 pe-0 ps-0 text-center">
                                                <div class="text-black fw-semibold fs-9">Hours</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="scroll-y max-h-200px px-3 py-lg-2 py-1">
                                        <div class="row bg-hov mb-2">
                                            <div class="col-5">
                                                <div class="text-dark fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="text-danger fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-2 text-center">
                                                <div class="text-info fw-semibold fs-9">03 Hrs</div>
                                            </div>
                                        </div>
                                        <div class="row bg-hov mb-2">
                                            <div class="col-5">
                                                <div class="text-dark fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="text-danger fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-2 text-center">
                                                <div class="text-info fw-semibold fs-9">01 Hrs</div>
                                            </div>
                                        </div>
                                        <div class="row bg-hov mb-2">
                                            <div class="col-5">
                                                <div class="text-dark fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="text-danger fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-2 text-center">
                                                <div class="text-info fw-semibold fs-9">03 Hrs</div>
                                            </div>
                                        </div>
                                        <div class="row bg-hov mb-2">
                                            <div class="col-5">
                                                <div class="text-dark fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="text-danger fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-2 text-center">
                                                <div class="text-info fw-semibold fs-9">01 Hrs</div>
                                            </div>
                                        </div>
                                        <div class="row bg-hov mb-2">
                                            <div class="col-5">
                                                <div class="text-dark fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="text-danger fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-2 text-center">
                                                <div class="text-info fw-semibold fs-9">01 Hrs</div>
                                            </div>
                                        </div>
                                        <div class="row bg-hov mb-2">
                                            <div class="col-5">
                                                <div class="text-dark fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="text-danger fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-2 text-center">
                                                <div class="text-info fw-semibold fs-9">01 Hrs</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row px-3 pt-1 pb-2">
                                        <div class="col-8">
                                            <div class="text-black fw-semibold fs-9">Completed Date & Time</div>
                                            <div class="d-block text-dark fw-bold fs-9">
                                                <?php date_default_timezone_set('Asia/Kolkata');
                                                echo date("d-M-Y h:i A"); ?>
                                            </div>
                                        </div>
                                        <div class="col-4 text-center">
                                            <div class="text-black fw-semibold fs-9">Total Hours</div>
                                            <div class="text-info fw-bold fs-9">03 Hrs</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-1">
                                <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="{{asset('assets/phdizone_images/staff_1.png')}}" alt="Staff" class="rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Iswarya D">
                                </div>
                                <div class="dropdown-menu w-lg-300px w-sm-100" style="box-shadow: 0px 5px 15px -3px rgba(0, 0, 0, 0.2), 0px 8px 15px 1px rgba(0, 0, 0, 0.14), 0px 3px 15px 2px rgba(0, 0, 0, 0.12) !important;">
                                    <div class="text-black text-center fw-semibold fs-8 px-3 py-2"><u>Iswarya D - Logged Details</u></div>
                                    <div class="px-2 border-bottom">
                                        <div class="row">
                                            <div class="col-5 pe-0">
                                                <div class="text-black fw-semibold fs-9">Start Time</div>
                                            </div>
                                            <div class="col-5 pe-0">
                                                <div class="text-black fw-semibold fs-9">End Time</div>
                                            </div>
                                            <div class="col-2 pe-0 ps-0 text-center">
                                                <div class="text-black fw-semibold fs-9">Hours</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="scroll-y max-h-200px px-3 py-lg-2 py-1">
                                        <!-- <div class="row bg-hov mb-2">
                                            <div class="col-5">
                                                <div class="text-dark fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="text-danger fw-semibold fs-9">
                                                    <?php date_default_timezone_set('Asia/Kolkata');
                                                    echo date("d-M-Y") . "<br>" . date("h:i A"); ?>
                                                </div>
                                            </div>
                                            <div class="col-2 text-center">
                                                <div class="text-info fw-semibold fs-9">03 Hrs</div>
                                            </div>
                                        </div> -->
                                    </div>
                                    <div class="row px-3 pt-1 pb-2">
                                        <div class="col-8">
                                            <div class="text-black fw-semibold fs-9">Completed Date & Time</div>
                                            <div class="d-block text-dark fw-bold fs-9">-
                                                <!-- < ?php date_default_timezone_set('Asia/Kolkata');
                                                echo date("d-M-Y h:i A"); ?> -->
                                            </div>
                                        </div>
                                        <div class="col-4 text-center">
                                            <div class="text-black fw-semibold fs-9">Total Hours</div>
                                            <div class="text-info fw-bold fs-9">-</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 mb-1 text-center">
                        <lable class="text-black fs-7 fw-semibold">Total Usage Hours</lable>
                        <div class="text-primary border border-gray-400i rounded-pill fs-4 fw-bold mb-1">
                            <span>03</span><span class="fs-7 fw-semibold">&nbsp;Hrs</span>
                        </div>
                    </div>
                </div>

                <div class="px-3">
                    <div class="row">
                        <div class="col-lg-9 mb-1 text-black fs-6 fw-semibold">
                            <label class="text-black fs-6 fw-semibold me-1">Checklist</label>
                            <label class="badge bg-secondary fs-7 fw-semibold py-2 rounded me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Checklist">10</label>
                            <label class="text-black fs-7 fw-semibold px-2 py-1 rounded me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed Checklist" style="border:1px solid #08a34f;">01</label>
                            <label class="badge bg-danger text-white fs-7 fw-semibold py-2 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pending Checklist" style="background-color: #ff4d49eb;">09</label>
                        </div>
                        <div class="col-lg-3 mb-1 text-black fs-6 fw-semibold">Percentage</div>
                    </div>
                </div>
                <hr class="mt-1 mb-2">
                <div class="scroll-y max-h-300px px-3 py-2">
                    <div class="row mb-1 pt-1 rounded" style="border:1px solid #08a34f;">
                        <div class="col-lg-9 d-flex align-items-center mb-1">
                            <label class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></label>
                            <label class="text-black fs-7 fw-semibold text-wrap">Understand Thesis Requirements</label>
                        </div>
                        <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                            <label class="text-black fs-7 fw-semibold">100%</label>
                            <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                            </div>
                        </div>
                    </div>
                    <div class="row mb-1 pt-1 rounded" style="background-color: #ff4d49eb;">
                        <div class="col-lg-9 d-flex align-items-center mb-1">
                            <label class="text-white fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-remove-outline text-white fs-4"></i></label>
                            <label class="text-white fs-7 fw-semibold text-wrap">Develop Thesis Outline</label>
                        </div>
                        <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                            <label class="text-white fs-7 fw-semibold">0%</label>
                            <!-- <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                            </div> -->
                        </div>
                    </div>
                    <div class="row mb-1 pt-1 rounded" style="background-color: #ff4d49eb;">
                        <div class="col-lg-9 d-flex align-items-center mb-1">
                            <label class="text-white fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-remove-outline text-white fs-4"></i></label>
                            <label class="text-white fs-7 fw-semibold text-wrap">Conduct Literature Review</label>
                        </div>
                        <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                            <label class="text-white fs-7 fw-semibold">0%</label>
                            <!-- <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                            </div> -->
                        </div>
                    </div>
                    <div class="row mb-1 pt-1 rounded" style="background-color: #ff4d49eb;">
                        <div class="col-lg-9 d-flex align-items-center mb-1">
                            <label class="text-white fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-remove-outline text-white fs-4"></i></label>
                            <label class="text-white fs-7 fw-semibold text-wrap">Draft Thesis Chapters</label>
                        </div>
                        <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                            <label class="text-white fs-7 fw-semibold">0%</label>
                            <!-- <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                            </div> -->
                        </div>
                    </div>
                    <div class="row mb-1 pt-1 rounded" style="background-color: #ff4d49eb;">
                        <div class="col-lg-9 d-flex align-items-center mb-1">
                            <label class="text-white fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-remove-outline text-white fs-4"></i></label>
                            <label class="text-white fs-7 fw-semibold text-wrap">Incorporate Data and Analysis</label>
                        </div>
                        <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                            <label class="text-white fs-7 fw-semibold">0%</label>
                            <!-- <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                            </div> -->
                        </div>
                    </div>
                    <div class="row mb-1 pt-1 rounded" style="background-color: #ff4d49eb;">
                        <div class="col-lg-9 d-flex align-items-center mb-1">
                            <label class="text-white fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-remove-outline text-white fs-4"></i></label>
                            <label class="text-white fs-7 fw-semibold text-wrap">Edit and Proofread</label>
                        </div>
                        <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                            <label class="text-white fs-7 fw-semibold">0%</label>
                            <!-- <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                            </div> -->
                        </div>
                    </div>
                    <div class="row mb-1 pt-1 rounded" style="background-color: #ff4d49eb;">
                        <div class="col-lg-9 d-flex align-items-center mb-1">
                            <label class="text-white fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-remove-outline text-white fs-4"></i></label>
                            <label class="text-white fs-7 fw-semibold text-wrap">Format Document</label>
                        </div>
                        <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                            <label class="text-white fs-7 fw-semibold">0%</label>
                            <!-- <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                            </div> -->
                        </div>
                    </div>
                    <div class="row mb-1 pt-1 rounded" style="background-color: #ff4d49eb;">
                        <div class="col-lg-9 d-flex align-items-center mb-1">
                            <label class="text-white fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-remove-outline text-white fs-4"></i></label>
                            <label class="text-white fs-7 fw-semibold text-wrap">Incorporate Feedback</label>
                        </div>
                        <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                            <label class="text-white fs-7 fw-semibold">0%</label>
                            <!-- <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                            </div> -->
                        </div>
                    </div>
                    <div class="row mb-1 pt-1 rounded" style="background-color: #ff4d49eb;">
                        <div class="col-lg-9 d-flex align-items-center mb-1">
                            <label class="text-white fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-remove-outline text-white fs-4"></i></label>
                            <label class="text-white fs-7 fw-semibold text-wrap">Check for Plagiarism</label>
                        </div>
                        <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                            <label class="text-white fs-7 fw-semibold">0%</label>
                            <!-- <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                            </div> -->
                        </div>
                    </div>
                    <div class="row mb-1 pt-1 rounded" style="background-color: #ff4d49eb;">
                        <div class="col-lg-9 d-flex align-items-center mb-1">
                            <label class="text-white fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-remove-outline text-white fs-4"></i></label>
                            <label class="text-white fs-7 fw-semibold text-wrap">Prepare Final Submission</label>
                        </div>
                        <div class="col-lg-3 d-flex align-items-center justify-content-between text-center mb-1">
                            <label class="text-white fs-7 fw-semibold">0%</label>
                            <!-- <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" title="Naveen R">
                                <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="Staff" class="rounded-circle">
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Task-->

<!--begin::Modal - View Deliverables-->
<div class="modal fade" id="kt_modal_view_deliverables" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8">
                    <h3 class="text-center text-black">View Deliverables Details</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Date & Time</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">
                        <?php date_default_timezone_set('Asia/Kolkata');
                        echo date("d-M-Y h:i A"); ?>
                    </label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Services</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Thesis Writing</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya <span class="fs-7 text-primary">( 2025/MDU01/CUS2334 )</span></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Deliverables</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-info fs-7 fw-semibold">Slot 01</label>
                    </div>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black fs-7 fw-semibold">&emsp;&emsp; You will assist in writing and organizing thesis chapters according to the guidelines.</label>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-1 text-black fs-6 fw-semibold">
                        <label class="text-black fs-6 fw-semibold me-1">Overall Task</label>
                    </div>
                </div>
                <hr class="mt-1 mb-2">
                <div class="scroll-y max-h-250px px-3 py-2">
                    <div class="row mb-1 pt-1 rounded" style="border:1px solid #08a34f;">
                        <div class="col-lg-12 d-flex align-items-start mb-1">
                            <label class="me-2 text-success fs-4">&#9989;</label>
                            <label class="text-black fs-7 mt-1 fw-semibold text-wrap">Understand Thesis Requirements</label>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Deliverables-->

<!--begin::Modal - View Journal Monitor-->
<div class="modal fade" id="kt_modal_view_journal_monitor" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">
                        <span>View Journal Details</span>
                        <span class="ms-1 me-1">-</span>
                        <span class="badge bg-info fw-semibold fs-5" style="background-color: #007BFF !important;">Submitted</span>
                    </h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya <span class="fs-7 text-primary">( 2025/MDU01/CUS2334 )</span></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Services</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Thesis Writing ( Writing Products )</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Journal</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">IEEE Internet of Things Journal</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Domain</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Internet of Things, Communications, Computer Science</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Paper</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">PQCAIE: Post quantum cryptographic authentication scheme for IoT-based e-health systems</label>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black fs-7 fw-semibold">&emsp;&emsp; You will assist in writing and organizing thesis chapters according to the guidelines.</label>
                </div>
                <div class="row mb-6">
                    <div class="col-lg-12">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Submitted Documents</label>
                        <div class="border border-gray-600i border-dashed rounded py-3 px-2">
                            <div class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">
                                <div class="mb-2">
                                    <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded border border-gray-300i rounded w-80px h-80px" download>
                                        <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}" class="h-80px w-80px" />
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="divider divider-primary mb-6">
                    <div class="divider-text fs-5 text-black fw-semibold">Reviewed</div>
                </div>
                <div class="row mb-6">
                    <div class="col-lg-12">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reviewed Documents</label>
                        <div class="border border-gray-600i border-dashed rounded py-3 px-2">
                            <div class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">
                                <div class="mb-2">
                                    <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded border border-gray-300i rounded w-80px h-80px" download>
                                        <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}" class="h-80px w-80px" />
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Reviewer Comments</label>
                    <label class="col-12 text-black text-justify fs-7 fw-semibold">&emsp;&emsp; We have carefully addressed the reviewers’ suggestions by enhancing the security analysis of the PQCAIE scheme, optimizing the authentication protocol for better efficiency in IoT environments, and clarifying the implementation details with additional experimental results. These changes improve the robustness and practical applicability of the proposed solution in e-health systems.</label>
                </div>
                <div class="divider divider-primary mb-6">
                    <div class="divider-text fs-5 text-black fw-semibold">Rejected</div>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Rejected Reason</label>
                    <label class="col-12 text-black text-justify fs-7 fw-semibold">&emsp;&emsp; Thank you for your valuable feedback and the opportunity to submit our work. We understand the concerns raised and will use the suggestions to significantly improve our research. We hope to address these issues thoroughly and consider resubmission in the future.</label>
                </div>
                <div class="divider divider-primary mb-6">
                    <div class="divider-text fs-5 text-black fw-semibold">Published</div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold"><?php echo date("d-M-Y"); ?></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Paper</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">TinyWolf — Efficient on-device TinyML training for IoT using enhanced Grey Wolf Optimization</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Author</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Khwaja Mansoor, Mehreen Afzal, Waseem Iqbal, Yawar Abbas, Shynar Mussiraliyeva, Abdellah Chehri</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">URL</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-semibold">
                        <a href="https://linkinghub.elsevier.com/retrieve/pii/S2542660524001690" class="badge bg-body rounded px-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Link"><i class="mdi mdi-link-variant text-danger fs-4"></i></a>
                    </div>
                </div>
                <div class="row mb-6">
                    <div class="col-lg-12">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Published Documents</label>
                        <div class="border border-gray-600i border-dashed rounded py-3 px-2">
                            <div class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">
                                <div class="mb-2">
                                    <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded border border-gray-300i rounded w-80px h-80px" download>
                                        <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}" class="h-80px w-80px" />
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black text-justify fs-7 fw-semibold">&emsp;&emsp; -</label>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Journal Monitor-->

<script>
    $('#accr_1').click(function() {
        $('#accr_1_tbox').slideToggle('slow');

        // Toggle the icon class
        let icon = $(this).find('.op_cl i'); // Find the icon inside the clicked element
        if (icon.hasClass('mdi-menu-up')) {
            icon.removeClass('mdi-menu-up').addClass('mdi-menu-down');
        } else {
            icon.removeClass('mdi-menu-down').addClass('mdi-menu-up');
        }
    });

    $('#accr_2').click(function() {
        $('#accr_2_tbox').slideToggle('slow');

        let icon = $(this).find('.op_cl i'); // Find the icon inside the clicked element
        if (icon.hasClass('mdi-menu-down')) {
            icon.removeClass('mdi-menu-down').addClass('mdi-menu-up');
        } else {
            icon.removeClass('mdi-menu-up').addClass('mdi-menu-down');
        }
    });
</script>
<script>
    document.querySelectorAll('button[data-bs-toggle="tab"]').forEach(tab => {
        tab.addEventListener('shown.bs.tab', function(event) {
            const complt_serv = document.getElementById("complt_serv");

            if (complt_serv.classList.contains('active')) {
                document.getElementById("complt_serv_txt").setAttribute("style", "Color:rgb(0, 0, 0) !important;");
                complt_serv.setAttribute("style", "background-color: #00ef8c !important;");
            } else {
                document.getElementById("complt_serv_txt").setAttribute("style", "Color:#4b4b4b !important;");
                complt_serv.setAttribute("style", "background-color: #0ed884 !important;");
            }
        });
    });
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>



<script>
    let lastMessageDate = null;

    function formatDateLabel(date) {
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    const msgDate = new Date(date);

    if (msgDate.toDateString() === today.toDateString()) return "Today";
    if (msgDate.toDateString() === yesterday.toDateString()) return "Yesterday";

    return msgDate.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });
    }

    function insertDateDivider(chatBox, date) {
    const divider = document.createElement("div");
    divider.className = "chat-date";
    divider.innerHTML = `<span>${formatDateLabel(date)}</span>`;
    chatBox.appendChild(divider);
    }

    function initDateDivider() {
    const chatBox = document.getElementById("chatBox");
    const now = new Date();

    insertDateDivider(chatBox, now);
    lastMessageDate = now;
    }

    function sendMessage() {
    let input = document.getElementById("chatInput");
    let chatBox = document.getElementById("chatBox");

    let msg = input.value.trim();
    if (!msg) return;

    const now = new Date();

    if (!lastMessageDate ||
        new Date(lastMessageDate).toDateString() !== now.toDateString()) {
        insertDateDivider(chatBox, now);
        lastMessageDate = now;
    }

    let bubble = document.createElement("div");
    bubble.className = "chat-msg sent";
    bubble.textContent = msg;

    chatBox.appendChild(bubble);

    input.value = "";
    chatBox.scrollTop = chatBox.scrollHeight;
    }

    // Enter key send
    document.getElementById("chatInput").addEventListener("keydown", function(e) {
    if (e.key === "Enter") sendMessage();
    });

    // Initialize divider on load
    initDateDivider();
</script>



<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

@endsection