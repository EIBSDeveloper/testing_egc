@extends('layouts/layoutMaster')

@section('title', 'View Customer Details')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/toastr/toastr.scss',
'resources/assets/vendor/libs/animate-css/animate.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/clipboard/clipboard.js',
'resources/assets/vendor/libs/toastr/toastr.js'
])
@endsection

@section('page-script')
@endsection
@section('content')
<style>
    .indv_cust_serv thead th,
    .indv_cust_serv tbody td {
        padding: 8px !important;
        border: 1px solid rgb(180, 180, 180) !important;
    }

    .proposal_table thead th,
    .proposal_table tbody td {
        border: 1px solid black !important;
        padding: 8px !important;
    }

    .common_table thead th,
    .common_table tbody td {
        /* border: 1px solid black !important; */
        padding: 8px !important;
    }
</style>

   @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id ?? 16;
        $user_data=$helper->get_staff_data($user_id);
    @endphp
    @php
                               
        $fullAddress = collect([
        $customer->door_no ?? null,
        $customer->address ?? null,
        $customer->city_name ?? null,
        $customer->state_name ?? null,
        $customer->country_name ?? null
    ])->filter()->implode(', ');
    @endphp
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">View Customer Details</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Manage Customer</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element text-end">
            <div class="text-black fw-semibold fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Customer">{{$customer->cus_name ??''}}</div>
            <div class="d-block text-primary fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Customer Mobile No">( +{{$customer->country_code ??''}} ) {{$customer->cus_mobile ??''}}</div>
            <div class="d-block text-dark fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Customer ID">{{$customer->customer_id ??''}}</div>
        </div>
    </div>
    <div class="card-body py-0">
        <div class="row mt-2">
            <div class="col-lg-12">
                <div class="nav-align-top mb-2">
                    <ul class="nav nav-pills flex-nowrap" style="background-color: #dfdfdf;" role="tablist">
                        <div class="scroll-container-wrapper">
                            <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                            <div class="scroll-container" id="scrollContainer">
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <button type="button" class="nav-link text-capitalize active border border-gray-500 rounded px-3 py-1 flex-column" role="tab" data-bs-toggle="tab" data-bs-target="#tab_customer_base_info" aria-controls="tab_customer_base_info" aria-selected="true">
                                            <img src="{{asset('assets/phdizone_images/base_info_2.ico')}}" alt="Base Info Icon" class="w-55px h-45px text-black fw-bold mb-2">
                                            <div class="d-block text-start fw-semibold fs-7">Base Details</div>
                                        </button>
                                    </li>
                                </div>
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 flex-column" role="tab" data-bs-toggle="tab" data-bs-target="#tab_service_1" aria-controls="tab_service_1" aria-selected="true">
                                            <img src="{{asset('assets/phdizone_images/services_1.ico')}}" alt="Base Info Icon" class="w-55px h-45px text-black fw-bold mb-2">
                                            <div class="d-block text-start text-truncate max-w-100px fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$customer->proposal_names}}">{{$customer->proposal_names}}</div>
                                        </button>
                                    </li>
                                </div>
                                <!--<div class="item">-->
                                <!--    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">-->
                                <!--        <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 flex-column" role="tab" data-bs-toggle="tab" data-bs-target="#tab_service_2" aria-controls="tab_service_2" aria-selected="true">-->
                                <!--            <img src="{{asset('assets/phdizone_images/package_1.ico')}}" alt="Base Info Icon" class="w-55px h-45px text-black fw-bold mb-2">-->
                                <!--            <div class="d-block text-start text-truncate max-w-100px fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Research Proposal">Research Proposal</div>-->
                                <!--        </button>-->
                                <!--         <span class="position-absolute badge bg-label-info rounded fw-semibold border-gray-400 fs-6 ms-n4 mt-n2">01</span> -->
                                <!--    </li>-->
                                <!--</div>-->
                                <!--<div class="item">-->
                                <!--    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">-->
                                <!--        <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 flex-column" role="tab" data-bs-toggle="tab" data-bs-target="#tab_service_3_completed" aria-controls="tab_service_3_completed" aria-selected="true" id="complt_serv" style="background-color:#0ed884 !important;">-->
                                <!--            <img src="{{asset('assets/phdizone_images/services_1.ico')}}" alt="Base Info Icon" class="w-55px h-45px text-black fw-bold mb-2">-->
                                <!--            <div class="d-block text-start text-truncate max-w-100px fw-semibold fs-7 complt_serv_txt" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Technical Research and Development Services , Formatting and Referencing">Technical Research and Development Services , Formatting and Referencing</div>-->
                                <!--        </button>-->
                                <!--        <span class="position-absolute badge bg-label-info rounded-circle fw-semibold border-gray-400 fs-6 ms-n4 mt-n2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Count">02</span>-->
                                <!--    </li>-->
                                <!--</div>-->
                            </div>
                            <button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                        </div>
                    </ul>
                </div>
            </div>
            <div class="col-lg-12 mt-3">
                <div class="tab-content p-0">
                    <div class="tab-pane fade show active" id="tab_customer_base_info" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-12 text-black fs-5 fw-bold">Basic Information</div>
                            <div class="col-lg-6 mt-4">
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Customer ID</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">{{$customer->customer_id ??''}}</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">{{$customer->cus_name ??''}}</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Gender</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">{{$customer->cus_gender == 1 ? 'Male' :($customer->cus_gender == 2 ? 'Female' :'-')}}</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">DOB</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">{{ $customer->cus_dob ? date($common_date_format, strtotime($customer->cus_dob)) :'-' }}</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <div class="col-7">
                                        <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$customer->cus_email_id ??'-'}}">{{$customer->cus_email_id ??'-'}}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 mt-2">
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">{{$fullAddress}}{{$customer->pincode ? ' - '.$customer->pincode:''}}</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">{{$customer->cus_mobile ?? ''}}</label>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Alternate Mobile No</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">{{$customer->cus_alternate_mobile ?? ''}}</label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <label class="text-black fs-5 fw-bold">Current Services Information</label>
                            </div>
                            <div class="col-lg-12 mt-4 mb-8">
                                <div class="table-responsive">
                                    <table class="table align-top gy-1 gs-2 indv_cust_serv">
                                        <thead>
                                            <tr class="text-start align-top bg-primary fs-6 gs-0">
                                                <th class="min-w-50px fw-semibold text-center">S.No</th>
                                                <th class="min-w-150px fw-semibold">Services</th>
                                                <th class="min-w-200px fw-semibold">Slots</th>
                                                <th class="min-w-100px text-center fw-semibold">Durations</th>
                                                <th class="min-w-100px text-center fw-semibold">Total Amt</th>
                                                <th class="min-w-100px text-center fw-semibold">Paid Amt</th>
                                                <th class="min-w-100px text-center fw-semibold">Balance Amt</th>
                                                <th class="min-w-100px fw-semibold">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                            @if(isset($proposal_data))
                                            @foreach($proposal_data as $indxPr=> $proposal)
                                            @php
                                                $rowspan = ($proposal->product_package == 1 && isset($proposal->services)) 
                                                    ? count($proposal->services) 
                                                    : 1;
                                                    $percentage = $helper->completed_service_percentage($proposal->customer_service_id);
                                            @endphp 
                                            @if($proposal->product_package==2)
                                            <tr>
                                                <td align="center">{{$indxPr+1}}</td>
                                                <td>
                                                    <div class="mb-0">
                                                        <label class="fs-7">{{$proposal->package_name}}</label>
                                                    </div>
                                                </td>
                                                <td>
                                                    @if(isset($proposal->package_slot))
                                                        @foreach($proposal->package_slot as $iSlt=>$slot)
                                                    <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                        <div class="mb-0 text-dark fs-7">Slot {{$iSlt+1}}</div>
                                                        <div class="mb-0">
                                                            <label class="fw-semibold fs-7 text-black">{{$customer->currency_symbol}} {{number_format($slot->payable_amount)}}</label>
                                                            @if($slot->paid_status == 1)
                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount Paid">
                                                                <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                    <g id="SVGRepo_iconCarrier">
                                                                        <defs>
                                                                            <style>
                                                                                .cls-1 {
                                                                                    fill: #699f4c;
                                                                                    fill-rule: evenodd;
                                                                                }
                                                                            </style>
                                                                        </defs>
                                                                        <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                    </g>
                                                                </svg>
                                                            </label>
                                                             @else
                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Amount Not Paid" data-bs-original-title="Amount Not Paid">
                                                                <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                    <g id="SVGRepo_iconCarrier">
                                                                        <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                        <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                    </g>
                                                                </svg>
                                                            </label>
                                                            @endif
                                                        </div>
                                                    </div>
                                                     @endforeach
                                                    @endif
                                                </td>
                                                <td align="center">
                                                    <label class="badge bg-label-warning border border-gray-300 rounded fw-semibold text-black fs-7 mb-2">{{$proposal->delivery_duration}} Days to {{$proposal->delivery_duration_end}} days</label>
                                                    <div class="d-block  fs-8">
                                                        <span class="badge bg-info text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment Registered Date">
                                                            {{  date($common_date_format, strtotime($helper->getFirstPaymentDate($proposal->sno)))}}
                                                        </span>
                                                    </div>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">{{$customer->currency_symbol}} {{number_format($slot->total_amount)}}</label>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">{{$customer->currency_symbol}} {{number_format($proposal->product_slots_paid)}}</label>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">{{$customer->currency_symbol}} {{number_format($proposal->total_amount - $proposal->product_slots_paid)}}</label>
                                                </td>
                                                <td>
                                                    <div class="badge bg-info text-black mb-1 fs-7 fw-semibold" style="background-color: #fea500 !important;">Service In Progress</div>
                                                    <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : {{$percentage}}%">
                                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: {{$percentage}}%" aria-valuenow="{{$percentage}}" aria-valuemin="0" aria-valuemax="100">{{$percentage}}%</div>
                                                    </div>
                                                </td>
                                            </tr>
                                            @else
                                            @foreach($proposal->services as $indxSr => $service)
                                                @php
                                                    $slotCount = count($proposal->product_slot);
                                                    $servicesCount = count($proposal->services);
                                                @endphp

                                               @foreach($proposal->product_slot as $slotIndex => $slot)
                                                    <tr>
                                                        @if($slotIndex === 0)
                                                            <td align="center" rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">{{ $indxSr == 0 ? $indxPr + 1 :'' }}</td>
                                                            <td rowspan="{{ $slotCount }}">
                                                                <div class="mb-0">
                                                                    <label class="fs-7">{{ $service->product_name }}</label>
                                                                    <div class="d-block text-dark fs-8">{{ $service->product_category_name }}</div>
                                                                </div>
                                                            </td>
                                                        @endif

                                                        <td style="{{ ( $slotCount - 1 == $slotIndex) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                            <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                <div class="mb-0 text-dark fs-7">{{$slot->payment_slot_name}}</div>
                                                                <div class="mb-0">
                                                                    <label class="fw-semibold fs-7 text-black">{{$customer->currency_symbol}} {{ number_format($slot->payable_amount) }}</label>
                                                                    @if($slot->paid_status == 1)
                                                                    <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount Paid">
                                                                        <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                            <g id="SVGRepo_iconCarrier">
                                                                                <defs>
                                                                                    <style>
                                                                                        .cls-1 {
                                                                                            fill: #699f4c;
                                                                                            fill-rule: evenodd;
                                                                                        }
                                                                                    </style>
                                                                                </defs>
                                                                                <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                            </g>
                                                                        </svg>
                                                                    </label>
                                                                    @else
                                                                    <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Amount Not Paid" data-bs-original-title="Amount Not Paid">
                                                                        <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                            <g id="SVGRepo_iconCarrier">
                                                                                <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                                <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                            </g>
                                                                        </svg>
                                                                    </label>
                                                                    @endif
                                                                </div>
                                                            </div>
                                                        </td>

                                                        @if($slotIndex === 0 )
                                                            <td align="center" rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                                @if($indxSr == 0)
                                                                <label class="badge bg-label-warning border border-gray-300 rounded fw-semibold text-black fs-7 mb-2">{{$proposal->delivery_duration}} Days to {{$proposal->delivery_duration_end}} Days</label>
                                                                 <div class="d-block  fs-8">
                                                                     <span class="badge bg-info text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment Registered Date">
                                                                     {{  date($common_date_format, strtotime($helper->getFirstPaymentDate($proposal->sno)))}}
                                                                     </span>
                                                                 </div>
                                                                @endif
                                                            </td>
                                                            <td align="right" rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                                 @if($indxSr == 0)
                                                                <label class="fw-semibold text-black fs-7">{{$customer->currency_symbol}} {{$proposal->total_amount}}</label>
                                                                @endif
                                                            </td>
                                                            <td align="right" rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                                 @if($indxSr == 0)
                                                                <label class="fw-semibold text-black fs-7">{{$customer->currency_symbol}} {{$proposal->product_slots_paid}}</label>
                                                                @endif
                                                            </td>
                                                            <td align="right" rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                                 @if($indxSr == 0)
                                                                <label class="fw-semibold text-black fs-7">{{$customer->currency_symbol}} {{$proposal->total_amount - $proposal->product_slots_paid}}</label>
                                                                @endif
                                                            </td>
                                                            <td rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                                 @if($indxSr == 0)
                                                                    @if($customer->status==1)
                                                                        <div class="badge bg-danger text-white mb-1 fs-7 fw-semibold">Waiting for Payment Approval</div>
                                                                        
                                                                    @elseif($customer->status ==0)
                                                                     <div class="badge bg-info text-black mb-1 fs-7 fw-semibold" style="background-color: #fea500 !important;">Service In Progress</div>
                                                                        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Service Progress : {{$percentage}}%">
                                                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: {{$percentage}}%" aria-valuenow="{{$percentage}}" aria-valuemin="0" aria-valuemax="100">{{$percentage}}%</div>
                                                                        </div>
                                                                    @endif
                                                                @endif
                                                            </td>
                                                        @endif
                                                    </tr>
                                                @endforeach
                                            @endforeach
                                            @endif
                                            @endforeach
                                            @endif
                                            <!--<tr>-->
                                            <!--    <td align="center">2</td>-->
                                            <!--    <td>-->
                                            <!--        <div class="mb-0">-->
                                            <!--            <label class="fs-7">Research Proposal</label>-->
                                            <!--            <div class="d-block text-dark fs-8">Proposal Writing Products</div>-->
                                            <!--        </div>-->
                                            <!--    </td>-->
                                            <!--    <td>-->
                                            <!--        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">-->
                                            <!--            <div class="mb-0 text-dark fs-7">Slot 01</div>-->
                                            <!--            <div class="mb-0">-->
                                            <!--                <label class="fw-semibold fs-7 text-black">&#8377; 30,000</label>-->
                                            <!--                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount Not Paid">-->
                                            <!--                    <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">-->
                                            <!--                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>-->
                                            <!--                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>-->
                                            <!--                        <g id="SVGRepo_iconCarrier">-->
                                            <!--                            <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>-->
                                            <!--                            <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>-->
                                            <!--                        </g>-->
                                            <!--                    </svg>-->
                                            <!--                </label>-->
                                            <!--            </div>-->
                                            <!--        </div>-->
                                            <!--        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">-->
                                            <!--            <div class="mb-0 text-dark fs-7">Slot 02</div>-->
                                            <!--            <div class="mb-0">-->
                                            <!--                <label class="fw-semibold fs-7 text-black">&#8377; 20,000</label>-->
                                            <!--                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount Not Paid">-->
                                            <!--                    <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">-->
                                            <!--                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>-->
                                            <!--                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>-->
                                            <!--                        <g id="SVGRepo_iconCarrier">-->
                                            <!--                            <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>-->
                                            <!--                            <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>-->
                                            <!--                        </g>-->
                                            <!--                    </svg>-->
                                            <!--                </label>-->
                                            <!--            </div>-->
                                            <!--        </div>-->
                                            <!--    </td>-->
                                            <!--    <td align="center">-->
                                            <!--        <label class="badge bg-label-warning border border-gray-300 rounded fw-semibold text-black fs-7">60 Days</label>-->
                                            <!--    </td>-->
                                            <!--    <td align="right">-->
                                            <!--        <label class="fw-semibold text-black fs-7">&#8377; 50,000</label>-->
                                            <!--    </td>-->
                                            <!--    <td align="right">-->
                                            <!--        <label class="fw-semibold text-black fs-7">&#8377; 0</label>-->
                                            <!--    </td>-->
                                            <!--    <td align="right">-->
                                            <!--        <label class="fw-semibold text-black fs-7">&#8377; 50,000</label>-->
                                            <!--    </td>-->
                                            <!--    <td>-->
                                            <!--        <div class="badge bg-danger text-white mb-1 fs-7 fw-semibold">Waiting for Payment Approval</div>-->
                                            <!--    </td>-->
                                            <!--</tr>-->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab_service_1" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-2">
                                <div class="nav-align-left nav-tabs-shadow">
                                    <ul class="nav nav-pills" role="tablist">
                                        <!--<li class="nav-item">-->
                                        <!--    <button-->
                                        <!--        type="button"-->
                                        <!--        class="nav-link text-capitalize active border border-gray-400i rounded px-3 py-1 mb-2"-->
                                        <!--        role="tab"-->
                                        <!--        data-bs-toggle="tab"-->
                                        <!--        data-bs-target="#navs-service_info"-->
                                        <!--        aria-controls="navs-service_info"-->
                                        <!--        aria-selected="true">-->
                                        <!--        Service Info-->
                                        <!--    </button>-->
                                        <!--</li>-->
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize active border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-payment_info"
                                                aria-controls="navs-payment_info"
                                                aria-selected="false">
                                                Payment Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-appointment_info"
                                                aria-controls="navs-appointment_info"
                                                aria-selected="false">
                                                Appointment Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-requirements_info"
                                                aria-controls="navs-requirements_info"
                                                aria-selected="false">
                                                Requirements Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-task_info"
                                                aria-controls="navs-task_info"
                                                aria-selected="false">
                                                Task Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-deliverables_info"
                                                aria-controls="navs-deliverables_info"
                                                aria-selected="false">
                                                Deliverables Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-staff_info"
                                                aria-controls="navs-staff_info"
                                                aria-selected="false">
                                                Staff Info
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button
                                                type="button"
                                                class="nav-link text-capitalize border border-gray-400i rounded px-3 py-1 mb-2"
                                                role="tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#navs-journal_info"
                                                aria-controls="navs-journal_info"
                                                aria-selected="false">
                                                Journal Info
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-10">
                                <div class="tab-content px-0 py-0">
                                    <div class="tab-pane fade  " id="navs-service_info">
                                        <!-- Begin :: Single Proposal (Single Services) -->
                                        <!--<div class="divider divider-primary mt-4 mb-10">-->
                                        <!--    <div class="divider-text text-black mb-2 fs-5 fw-semibold">-->
                                        <!--        <label>( Single ) Services Information &emsp; - &emsp;</label>-->
                                        <!--        <label class="badge bg-info text-black mb-1 fs-5 fw-semibold" style="background-color: #fea500 !important;">Service In Progress</label>-->
                                        <!--    </div>-->
                                        <!--</div>-->
                                        <!--<div class="row">-->
                                        <!--    <div class="col-lg-6 mb-3">-->
                                        <!--        <div class="row mb-4">-->
                                        <!--            <label class="col-4 text-dark fs-6 fw-semibold">Service</label>-->
                                        <!--            <label class="col-1 text-black fs-6 fw-bold">:</label>-->
                                        <!--            <label class="col-7 text-black fs-6 fw-bold">Thesis Writing</label>-->
                                        <!--        </div>-->
                                        <!--        <div class="row mb-4">-->
                                        <!--            <label class="col-4 text-dark fs-6 fw-semibold">Service Category</label>-->
                                        <!--            <label class="col-1 text-black fs-6 fw-bold">:</label>-->
                                        <!--            <label class="col-7 text-black fs-6 fw-bold">Writing Services</label>-->
                                        <!--        </div>-->
                                        <!--    </div>-->
                                        <!--    <div class="col-lg-6 mb-3">-->
                                        <!--        <div class="row mb-4">-->
                                        <!--            <label class="col-4 text-dark fs-6 fw-semibold">Durations / Usage</label>-->
                                        <!--            <label class="col-1 text-black fs-6 fw-bold">:</label>-->
                                        <!--            <div class="col-7">-->
                                        <!--                <label class="badge bg-transparent border border-danger fw-semibold text-danger fs-7 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Durations">90 Days</label>-->
                                        <!--                <label class="text-black fs-6 fw-bold ms-1 me-1">/</label>-->
                                        <!--                <label class="badge bg-transparent border border-danger fw-semibold text-info fs-7 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Usage Hours">33 Hrs</label>-->
                                        <!--            </div>-->
                                        <!--        </div>-->
                                        <!--        <div class="row mb-4">-->
                                        <!--            <label class="col-4 text-dark fs-6 fw-semibold">Currency / Slot</label>-->
                                        <!--            <label class="col-1 text-black fs-6 fw-bold">:</label>-->
                                        <!--            <div class="col-7">-->
                                        <!--                <label class="text-black fs-6 fw-semibold">₹ - INR</label>-->
                                        <!--                <label class="text-black fs-6 fw-bold ms-1 me-1">/</label>-->
                                        <!--                <label class="badge bg-secondary fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Slot">02</label>-->
                                        <!--                <label class="text-dark fs-6 fw-semibold">( Partially Paid )</label>-->
                                        <!--            </div>-->
                                        <!--        </div>-->
                                        <!--    </div>-->
                                        <!--    <div class="col-lg-4 mb-3">-->
                                        <!--        <div class="mb-0 fw-semibold text-center text-black fs-5"><u>Deliverables</u></div>-->
                                        <!--        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">-->
                                        <!--            <div class="mb-0 fw-semibold text-dark fs-7">Slot 01</div>-->
                                        <!--            <div class="mb-0">-->
                                        <!--                <label class="fw-semibold fs-7 text-black">&#8377; 55,000</label>-->
                                        <!--                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered">-->
                                        <!--                    <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">-->
                                        <!--                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>-->
                                        <!--                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>-->
                                        <!--                        <g id="SVGRepo_iconCarrier">-->
                                        <!--                            <defs>-->
                                        <!--                                <style>-->
                                        <!--                                    .cls-1 {-->
                                        <!--                                        fill: #699f4c;-->
                                        <!--                                        fill-rule: evenodd;-->
                                        <!--                                    }-->
                                        <!--                                </style>-->
                                        <!--                            </defs>-->
                                        <!--                            <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>-->
                                        <!--                        </g>-->
                                        <!--                    </svg>-->
                                        <!--                </label>-->
                                        <!--            </div>-->
                                        <!--        </div>-->
                                        <!--        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">-->
                                        <!--            <div class="mb-0 fw-semibold text-dark fs-7">Slot 02</div>-->
                                        <!--            <div class="mb-0">-->
                                        <!--                <label class="fw-semibold fs-7 text-black">&#8377; 56,574</label>-->
                                        <!--                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Progress">-->
                                        <!--                    <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">-->
                                        <!--                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>-->
                                        <!--                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>-->
                                        <!--                        <g id="SVGRepo_iconCarrier">-->
                                        <!--                            <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>-->
                                        <!--                            <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>-->
                                        <!--                        </g>-->
                                        <!--                    </svg>-->
                                        <!--                </label>-->
                                        <!--            </div>-->
                                        <!--        </div>-->
                                        <!--        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : 20%">-->
                                        <!--            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>-->
                                        <!--        </div>-->
                                        <!--    </div>-->
                                        <!--    <div class="col-lg-8 d-flex align-items-center justify-content-center gap-5 flex-wrap mb-3">-->
                                        <!--        <div class="badge bg-secondary fw-semibold fs-6 rounded py-2 px-3">-->
                                        <!--            <label class="text-white mb-2 fs-4 fw-semibold">Total Amount</label>-->
                                        <!--            <div class="d-block">-->
                                        <!--                <label class="text-white fs-4 fw-semibold">₹ 1,11,574</label>-->
                                        <!--            </div>-->
                                        <!--        </div>-->
                                        <!--        <div class="badge bg-success fw-semibold fs-6 rounded py-2 px-3">-->
                                        <!--            <label class="text-white mb-2 fs-4 fw-semibold">Paid Amount</label>-->
                                        <!--            <div class="d-block">-->
                                        <!--                <label class="text-white fs-4 fw-semibold">₹ 55,000</label>-->
                                        <!--            </div>-->
                                        <!--        </div>-->
                                        <!--        <div class="badge bg-danger fw-semibold fs-6 rounded py-2 px-3">-->
                                        <!--            <label class="text-white mb-2 fs-4 fw-semibold">Balance Amount</label>-->
                                        <!--            <div class="d-block">-->
                                        <!--                <label class="text-white fs-4 fw-semibold">₹ 56,574</label>-->
                                        <!--            </div>-->
                                        <!--        </div>-->
                                        <!--    </div>-->
                                        <!--</div>-->
                                        <!-- End :: Single Proposal (Single Services) -->


                                        <!-- Begin :: Single Proposal (Multiple Services) -->
                                        <div class="divider divider-primary mt-4 mb-10">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">
                                                <label>Services Information &emsp; - &emsp;</label>
                                                <label class="badge bg-info text-black mb-1 fs-5 fw-semibold" style="background-color: #fea500 !important;">Service In Progress</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 mb-3">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">Thesis Writing</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service Category</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">Writing Services</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <div class="col-lg-4 mb-3">
                                                        <div class="mb-0 fw-semibold text-center text-black fs-5"><u>Deliverables</u></div>
                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                            <div class="mb-0 fw-semibold text-dark fs-7">Slot 01</div>
                                                            <div class="mb-0">
                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered">
                                                                    <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                        <g id="SVGRepo_iconCarrier">
                                                                            <defs>
                                                                                <style>
                                                                                    .cls-1 {
                                                                                        fill: #699f4c;
                                                                                        fill-rule: evenodd;
                                                                                    }
                                                                                </style>
                                                                            </defs>
                                                                            <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                        </g>
                                                                    </svg>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                            <div class="mb-0 fw-semibold text-dark fs-7">Slot 02</div>
                                                            <div class="mb-0">
                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Progress">
                                                                    <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                        <g id="SVGRepo_iconCarrier">
                                                                            <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                            <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                        </g>
                                                                    </svg>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : 20%">
                                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6 mb-3 d-flex align-items-center justify-content-center flex-column">
                                                        <div class="text-center border border-info border-dashed rounded px-3 py-2">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">Services</label>
                                                            <div class="d-block" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <label class="cursor-pointer text-info mb-1 fs-5 fw-semibold">03</label>
                                                                <a href="javascript:;" class="mb-1 me-n3"><i class="mdi mdi-menu-down text-black fs-3"></i></a>
                                                                <div class="dropdown-menu dropdown-menu-end w-25">
                                                                    <div class="text-dark fs-6 text-center my-2 fw-semibold">Services</div>
                                                                    <hr class="mt-0 mb-2 border-dark">
                                                                    <div class="scroll-y max-h-350px px-4 py-1 mb-2">
                                                                        <div class="d-flex align-items-start text-start mb-2">
                                                                            <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                            <div class="d-block">
                                                                                <div class="text-black fw-semibold text-justify fs-7">Thesis Writing</div>
                                                                                <div class="fw-semibold text-info fs-8">Writing Products</div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mb-0 fw-semibold text-center text-black fs-7"><u>Deliverables</u></div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 01</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered">
                                                                                    <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <defs>
                                                                                                <style>
                                                                                                    .cls-1 {
                                                                                                        fill: #699f4c;
                                                                                                        fill-rule: evenodd;
                                                                                                    }
                                                                                                </style>
                                                                                            </defs>
                                                                                            <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 02</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Progress">
                                                                                    <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                                            <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : 20%">
                                                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
                                                                        </div>
                                                                        <div class="border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pt-4 mb-3"></div>
                                                                        <div class="d-flex align-items-start text-start mb-2">
                                                                            <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                            <div class="d-block">
                                                                                <div class="text-black fw-semibold text-justify fs-7">Technical Research and Development Services</div>
                                                                                <div class="fw-semibold text-info fs-8">Developement Products</div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mb-0 fw-semibold text-center text-black fs-7"><u>Deliverables</u></div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 01</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered">
                                                                                    <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <defs>
                                                                                                <style>
                                                                                                    .cls-1 {
                                                                                                        fill: #699f4c;
                                                                                                        fill-rule: evenodd;
                                                                                                    }
                                                                                                </style>
                                                                                            </defs>
                                                                                            <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 02</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Progress">
                                                                                    <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                                            <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : 20%">
                                                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
                                                                        </div>
                                                                        <div class="border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pt-4 mb-3"></div>
                                                                        <div class="d-flex align-items-start text-start mb-2">
                                                                            <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                            <div class="d-block">
                                                                                <div class="text-black fw-semibold text-justify fs-7">Formatting and Referencing</div>
                                                                                <div class="fw-semibold text-info fs-8">Developement Products</div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mb-0 fw-semibold text-center text-black fs-7"><u>Deliverables</u></div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 01</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered">
                                                                                    <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <defs>
                                                                                                <style>
                                                                                                    .cls-1 {
                                                                                                        fill: #699f4c;
                                                                                                        fill-rule: evenodd;
                                                                                                    }
                                                                                                </style>
                                                                                            </defs>
                                                                                            <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                            <div class="mb-0 fw-semibold text-dark fs-8">Slot 02</div>
                                                                            <div class="mb-0">
                                                                                <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="On Progress">
                                                                                    <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                                        <g id="SVGRepo_iconCarrier">
                                                                                            <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                                            <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                                        </g>
                                                                                    </svg>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : 20%">
                                                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
                                                                        </div>
                                                                        <div class="border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pt-4 mb-3"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Durations / Usage</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <div class="col-7">
                                                        <label class="badge bg-transparent border border-danger fw-semibold text-danger fs-7 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Durations">90 Days</label>
                                                        <label class="text-black fs-6 fw-bold ms-1 me-1">/</label>
                                                        <label class="badge bg-transparent border border-danger fw-semibold text-info fs-7 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Usage Hours">33 Hrs</label>
                                                    </div>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Currency</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <div class="col-7">
                                                        <label class="text-black fs-6 fw-semibold">₹ - INR</label>
                                                    </div>
                                                </div>
                                                <div class="row mb-4">
                                                    <div class="col-lg-12">
                                                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-3">
                                                            <div class="badge bg-secondary fw-semibold fs-6 rounded py-1 px-2">
                                                                <label class="text-white mb-2 fs-5 fw-semibold">Total Amount</label>
                                                                <div class="d-block">
                                                                    <label class="text-white fs-5 fw-semibold">₹ 1,11,574</label>
                                                                </div>
                                                            </div>
                                                            <div class="badge bg-success fw-semibold fs-6 rounded py-1 px-2">
                                                                <label class="text-white mb-2 fs-5 fw-semibold">Paid Amount</label>
                                                                <div class="d-block">
                                                                    <label class="text-white fs-5 fw-semibold">₹ 55,000</label>
                                                                </div>
                                                            </div>
                                                            <div class="badge bg-danger fw-semibold fs-6 rounded py-1 px-2">
                                                                <label class="text-white mb-2 fs-5 fw-semibold">Balance Amount</label>
                                                                <div class="d-block">
                                                                    <label class="text-white fs-5 fw-semibold">₹ 56,574</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End :: Single Proposal (Multiple Services) -->


                                        <div class="divider divider-primary mt-10 mb-10">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">
                                                <label>Proposal Information &emsp; - &emsp;</label>
                                                <label class="border border-success rounded px-2 text-success fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Accepted Date"><?php echo date("d-M-Y", strtotime("+3 days")); ?></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="shadow-lg border border-gray-800 rounded mb-4">
                                                    <div class="cursor-pointer d-flex align-items-center justify-content-between flex-wrap rounded px-4 py-2" id="accr_1" style="background-color: #DFDBDB;">
                                                        <div class="mb-4">
                                                            <label class="bg-label-success rounded-circle fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Accepted"><i class="mdi mdi-check-decagram fs-1 fw-bold opacity-1 text-success"></i></label>
                                                            <label class="badge bg-info fw-semibold fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Count">02</label>
                                                            <label class="text-black fs-5 fw-semibold ms-2">PRO-003670/05/2025-01</label>
                                                            <div class="d-block">
                                                                <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                                                <label class="badge bg-success fs-6 text-white rounded fw-semibold"><?php echo date("d-M-Y"); ?></label>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center justify-content-end mb-4">
                                                            <div class="cursor-pointer me-2">
                                                                <a href="{{url('/manage_proposal/proposal_print')}}" target="_blank" class="border border-dark rounded px-1 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                                                    <span><i class="mdi mdi-printer-pos-outline fs-1 text-black"></i></span>
                                                                </a>
                                                            </div>
                                                            <div class="mb-0">
                                                                <div class="d-block">
                                                                    <label class="fs-4 text-black fw-semibold">Total Amount &nbsp;-&nbsp;</label>
                                                                    <label class="fs-4 text-black rounded fw-bold">&#8377; 1,11,574</label>
                                                                </div>
                                                                <div class="d-block">
                                                                    <label class="fs-6 text-black fw-semibold">Validity Date &nbsp;-&nbsp;</label>
                                                                    <label class="badge bg-danger fs-6 text-white rounded fw-semibold"><?php echo date("d-M-Y", strtotime("+7 days")); ?></label>
                                                                </div>
                                                            </div>
                                                            <label class="cursor-pointer op_cl ms-3"><i class="mdi mdi-menu-down text-black fs-2"></i></label>
                                                        </div>
                                                    </div>
                                                    <div class="px-5 pb-4 pt-2" id="accr_1_tbox" style="display: none;">
                                                        <div class="fs-2 text-center text-black my-3 fw-bold">Service Details</div>
                                                        <div class="row">
                                                            <div class="col-lg-12 mb-2">
                                                                <table class="table align-top gy-1 gs-2 proposal_table">
                                                                    <thead>
                                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                            <th class="w-50px text-center">S.No</th>
                                                                            <th class="w-300px text-center">Work </th>
                                                                            <th class="w-50px text-center">Qty </th>
                                                                            <th class="w-100px text-center">Amount</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody class="text-gray-600">
                                                                        <tr>
                                                                            <td align="center">1</td>
                                                                            <td>
                                                                                <div>
                                                                                    <div class="text-black fw-semibold fs-6 mb-1">Thesis Writing ( &#8377; 82,000 )</div>
                                                                                    <div class="text-dark fw-semibold fs-7">Writing Services</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-dark fw-semibold fs-6 my-2">
                                                                                        <label>Total Costing &nbsp;:&nbsp;</label>
                                                                                        <label class="me-2">** &#8377; 1,11,574 /- **</label>
                                                                                        <label>Total Slots &nbsp;:&nbsp;</label>
                                                                                        <label class="me-2">02</label>
                                                                                        <label>(Includes 18% GST)</label>
                                                                                    </div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Tools</div>
                                                                                    <div class="d-block ms-3">1. LaTeX</div>
                                                                                    <div class="d-block ms-3">2. Scrivener</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Slot I : &#8377; 55,000 /-</div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Free Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Topic Suggestions - 03 Chapter</div>
                                                                                    <div class="d-block text-black ms-5">2. Sample Research Papers - 08 Pages</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Consultation (Into) - 30 Minutes</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Paid Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Plagiarism Check - 200 Pages( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">2. Thesis Writing - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                                                    <div class="d-block ms-3">1. Technical discussion</div>
                                                                                    <div class="d-block ms-3">2. Flow of the work ( Novelty and Data Set )</div>
                                                                                    <!-- <div class="d-block">3. Source Code</div>
                                                    <div class="d-block">4. Pseudo Code</div>
                                                    <div class="d-block">5. Demo through Running video</div>
                                                    <div class="d-block">6. Results As per client specification-As per the Description</div>
                                                    <div class="d-block">7. Software Installation</div> -->
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Note</div>
                                                                                    <div class="d-block ms-3">1. Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Slot 2 : &#8377; 56,574 /-</div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Free Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Topic Suggestions - 03 Chapter</div>
                                                                                    <div class="d-block text-black ms-5">2. Sample Research Papers - 08 Pages</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Consultation (Into) - 30 Minutes</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Paid Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Plagiarism Check - 200 Pages( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">2. Thesis Writing - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                                                    <div class="d-block ms-3">1. Technical discussion</div>
                                                                                    <div class="d-block ms-3">2. Flow of the work ( Novelty and Data Set )</div>
                                                                                    <!-- <div class="d-block">3. Source Code</div>
                                                    <div class="d-block">4. Pseudo Code</div>
                                                    <div class="d-block">5. Demo through Running video</div>
                                                    <div class="d-block">6. Results As per client specification-As per the Description</div>
                                                    <div class="d-block">7. Software Installation</div> -->
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Note</div>
                                                                                    <div class="d-block ms-3">1. Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="d-block">SUPPORT SECTION : Approval getting, Knowledge transfer, whatsapp group creation, and further doubts clearing support as well.</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">
                                                                                        <label>Duration &nbsp;:&nbsp;</label>
                                                                                        <label>90</label>
                                                                                        <label>working days</label>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                            <td align="center">
                                                                                <label class="fs-6 fw-bold">1</label>
                                                                            </td>
                                                                            <td align="right">
                                                                                <label class="fs-6 text-black fw-semibold">&#8377; 1,02,000</label>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <div class="border border-gray-700 rounded pb-2">
                                                                    <div class="d-flex align-items-center justify-content-between border-bottom rounded-top bg-label-info" style="background-color: #adff2f78 !important;">
                                                                        <div class="mb-0 ps-3 py-2">
                                                                            <label class="text-black fw-semibold fs-6">Additional Charges</label>
                                                                        </div>
                                                                        <div class="me-3">
                                                                            <div class="badge bg-secondary rounded fs-6">03</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="scroll-y max-h-200px px-3 py-2">
                                                                        <div class="row mt-2 px-3">
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">1.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>Bank's Inward Remittance Fee</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">2.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>GST on Foreign Exchange Services</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">3.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>Foreign Inward Remittance Certificate (FIRC) Charges</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-dark fs-5 me-13">Sub Total</label>
                                                                    <div class="fw-bold text-dark fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-dark"></i></span>
                                                                        <span class="fs-3">1,02,000</span>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-1 gap-5">
                                                                    <div class="d-flex align-items-center justify-content-end gap-5 mb-2">
                                                                        <div class="d-flex align-items-center fw-bold fs-5 me-13">
                                                                            <div class="me-0">
                                                                                <label>Discount</label>
                                                                                <label class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Discount Percentage">( 10% )</label><br>
                                                                                <label class="text-info fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Coupon Code">[ A7D9K2L3M0 ]</label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="fw-bold fs-2">
                                                                            <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                                                                            <span class="fs-3">10,200</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-black fs-4 me-9">Total Amount</label>
                                                                    <div class="fw-bold text-black fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-3 fw-bold text-black"></i></span>
                                                                        <span class="fs-2">91,800</span>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <div class="fw-bold fs-5 me-12">
                                                                        <div class="text-dark mb-1 fs-5 fw-semibold">
                                                                            <label>GST <span class="text-danger fw-bold">( 18% )</span></label>
                                                                            <div class="d-block fw-bold fs-8">[Exclusive]</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="fw-bold fs-2">
                                                                        <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                                                                        <label class="fs-3">16,524</label>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-dark text-end fs-5 me-13">Additional Charges<br><span class="text-danger fw-bold">( 3% )</span></label>
                                                                    <div class="fw-bold text-dark fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-dark"></i></span>
                                                                        <span class="fs-3">3,250</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                            <label class="fw-bold text-black fs-1 me-8">Grand Total</label>
                                                            <div class="fw-bold text-black fs-2">
                                                                <label><i class="mdi mdi-currency-rupee fs-2 fw-bold text-black"></i></label>
                                                                <label class="fs-1">1,11,574</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="shadow-lg border border-gray-800 rounded mb-4">
                                                    <div class="cursor-pointer d-flex align-items-center justify-content-between flex-wrap rounded px-4 py-2" id="accr_2" style="background-color: #DFDBDB;">
                                                        <div class="mb-4">
                                                            <label class="badge bg-info fw-semibold fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Count">01</label>
                                                            <label class="text-black fs-5 fw-semibold ms-2">PRO-003669/03/2025</label>
                                                            <div class="d-block">
                                                                <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                                                <label class="badge bg-success fs-6 text-white rounded fw-semibold"><?php echo date("d-M-Y", strtotime("-8 days")); ?></label>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center justify-content-end mb-4">
                                                            <div class="cursor-pointer me-2">
                                                                <a href="{{url('/manage_proposal/proposal_print')}}" target="_blank" class="border border-dark rounded px-1 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                                                    <span><i class="mdi mdi-printer-pos-outline fs-1 text-black"></i></span>
                                                                </a>
                                                            </div>
                                                            <div class="mb-0">
                                                                <div class="d-block">
                                                                    <label class="fs-4 text-black fw-semibold">Total Amount &nbsp;-&nbsp;</label>
                                                                    <label class="fs-4 text-black rounded fw-bold">&#8377; 1,43,434</label>
                                                                </div>
                                                                <div class="d-block">
                                                                    <label class="fs-6 text-black fw-semibold">Validity Date &nbsp;-&nbsp;</label>
                                                                    <label class="badge bg-danger fs-6 text-white rounded fw-semibold"><?php echo date("d-M-Y", strtotime("-1 days")); ?></label>
                                                                </div>
                                                            </div>
                                                            <label class="cursor-pointer op_cl ms-3"><i class="mdi mdi-menu-down text-black fs-2"></i></label>
                                                        </div>
                                                    </div>
                                                    <div class="px-5 pb-4 pt-2" id="accr_2_tbox" style="display: none;">
                                                        <div class="fs-2 text-center text-black my-3 fw-bold">Service Details</div>
                                                        <div class="row">
                                                            <div class="col-lg-12 mb-2">
                                                                <table class="table align-top gy-1 gs-2 proposal_table">
                                                                    <thead>
                                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                            <th class="w-50px text-center">S.No</th>
                                                                            <th class="w-300px text-center">Work </th>
                                                                            <th class="w-50px text-center">Qty </th>
                                                                            <th class="w-100px text-center">Amount</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody class="text-gray-600">
                                                                        <tr>
                                                                            <td align="center">1</td>
                                                                            <td>
                                                                                <div>
                                                                                    <div class="text-black fw-semibold fs-6 mb-1">Thesis Writing ( &#8377; 82,000 )</div>
                                                                                    <div class="text-dark fw-semibold fs-7">Writing Services</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-dark fw-semibold fs-6 my-2">
                                                                                        <label>Total Costing &nbsp;:&nbsp;</label>
                                                                                        <label class="me-2">** &#8377; 1,40,184 /- **</label>
                                                                                        <label>Total Slots &nbsp;:&nbsp;</label>
                                                                                        <label class="me-2">02</label>
                                                                                        <label>(Includes 18% GST)</label>
                                                                                    </div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Tools</div>
                                                                                    <div class="d-block ms-3">1. LaTeX</div>
                                                                                    <div class="d-block ms-3">2. Scrivener</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Slot I : &#8377; 80,000 /-</div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Free Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Topic Suggestions - 03 Chapter</div>
                                                                                    <div class="d-block text-black ms-5">2. Sample Research Papers - 08 Pages</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Consultation (Into) - 30 Minutes</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Paid Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Plagiarism Check - 200 Pages( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">2. Thesis Writing - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Proposal Writing - 5000 Words ( &#8377; 20,000 )</div>
                                                                                    <div class="d-block text-black ms-5">4. Thesis Formatting - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                                                    <div class="d-block ms-3">1. Technical discussion</div>
                                                                                    <div class="d-block ms-3">2. Flow of the work ( Novelty and Data Set )</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Note</div>
                                                                                    <div class="d-block">1. Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Slot 2 : &#8377; 60,184 /-</div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Free Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Topic Suggestions - 03 Chapter</div>
                                                                                    <div class="d-block text-black ms-5">2. Sample Research Papers - 08 Pages</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Consultation (Into) - 30 Minutes</div>
                                                                                    <div class="text-black fw-semibold fs-7 my-4 ms-3">Paid Services</div>
                                                                                    <div class="d-block text-black ms-5">1. Plagiarism Check - 200 Pages( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">2. Thesis Writing - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="d-block text-black ms-5">3. Research Proposal Writing - 5000 Words ( &#8377; 20,000 )</div>
                                                                                    <div class="d-block text-black ms-5">4. Thesis Formatting - 100 Pages ( &#8377; 10,000 )</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                                                    <div class="d-block ms-3">1. Technical discussion</div>
                                                                                    <div class="d-block ms-3">2. Flow of the work ( Novelty and Data Set )</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">Note</div>
                                                                                    <div class="d-block">1. Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.</div>
                                                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                                                    <div class="d-block">SUPPORT SECTION : Approval getting, Knowledge transfer, whatsapp group creation, and further doubts clearing support as well.</div>
                                                                                    <div class="my-4"></div>
                                                                                    <div class="text-black fw-semibold fs-6 my-2">
                                                                                        <label>Duration &nbsp;:&nbsp;</label>
                                                                                        <label>90</label>
                                                                                        <label>working days</label>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                            <td align="center">
                                                                                <label class="fs-6 fw-bold">1</label>
                                                                            </td>
                                                                            <td align="right">
                                                                                <label class="fs-6 text-black fw-semibold">&#8377; 1,32,000</label>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <div class="border border-gray-700 rounded pb-2">
                                                                    <div class="d-flex align-items-center justify-content-between border-bottom rounded-top bg-label-info" style="background-color: #adff2f78 !important;">
                                                                        <div class="mb-0 ps-3 py-2">
                                                                            <label class="text-black fw-semibold fs-6">Additional Charges</label>
                                                                        </div>
                                                                        <div class="me-3">
                                                                            <div class="badge bg-secondary rounded fs-6">03</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="scroll-y max-h-200px px-3 py-2">
                                                                        <div class="row mt-2 px-3">
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">1.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>Bank's Inward Remittance Fee</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">2.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>GST on Foreign Exchange Services</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="d-flex align-items-start mb-2">
                                                                                <div class="text-black fw-semibold fs-7 me-2">3.</div>
                                                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                                                    <span>Foreign Inward Remittance Certificate (FIRC) Charges</span>
                                                                                    <span class="ms-1 text-danger fw-semibold fs-6">( 1% )</span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-dark fs-5 me-13">Sub Total</label>
                                                                    <div class="fw-bold text-dark fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-dark"></i></span>
                                                                        <span class="fs-3">1,32,000</span>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-1 gap-5">
                                                                    <div class="d-flex align-items-center justify-content-end gap-5 mb-2">
                                                                        <div class="d-flex align-items-center fw-bold fs-5 me-13">
                                                                            <div class="me-0">
                                                                                <label>Discount</label>
                                                                                <label class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Discount Percentage">( 10% )</label><br>
                                                                                <label class="text-info fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Coupon Code">[ A7D9K2L3M0 ]</label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="fw-bold fs-2">
                                                                            <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                                                                            <span class="fs-3">13,200</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-black fs-4 me-9">Total Amount</label>
                                                                    <div class="fw-bold text-black fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-3 fw-bold text-black"></i></span>
                                                                        <span class="fs-2">1,18,800</span>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <div class="fw-bold fs-5 me-12">
                                                                        <div class="text-dark mb-1 fs-5 fw-semibold">
                                                                            <label>GST <span class="text-danger fw-bold">( 18% )</span></label>
                                                                            <div class="d-block fw-bold fs-8">[Exclusive]</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="fw-bold fs-2">
                                                                        <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                                                                        <label class="fs-3">21,384</label>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                                    <label class="fw-bold text-dark text-end fs-5 me-13">Additional Charges<br><span class="text-danger fw-bold">( 3% )</span></label>
                                                                    <div class="fw-bold text-dark fs-2">
                                                                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-dark"></i></span>
                                                                        <span class="fs-3">3,250</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                                            <label class="fw-bold text-black fs-1 me-8">Grand Total</label>
                                                            <div class="fw-bold text-black fs-2">
                                                                <label><i class="mdi mdi-currency-rupee fs-2 fw-bold text-black"></i></label>
                                                                <label class="fs-1">1,43,434</label>
                                                            </div>
                                                        </div>
                                                        <div class="mb-2">
                                                            <div class="text-black fw-semibold fs-5 mb-2"><u>Reason</u></div>
                                                            <div class="text-danger fw-semibold fs-6">&emsp;&emsp;&emsp; The cost is too high for my budget</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="divider divider-primary mt-10 mb-10">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Receipts Information</div>
                                        </div>
                                        <div class="row mb-6">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table align-middle table-row-dashed gy-1 gs-2 common_table">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                <th class="min-w-100px">Receipt No</th>
                                                                <th class="min-w-80px">Paid Amt</th>
                                                                <th class="min-w-80px">Mode</th>
                                                                <th class="min-w-80px text-center">NDA</th>
                                                                <th class="min-w-50px">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                                            <tr>
                                                                <td>
                                                                    <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Receipt No">INV-005003/05/2025</label>
                                                                    <div class="d-block">
                                                                        <label class="fs-8 text-dark fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Receipt Date">
                                                                            <?php echo date("d-M-Y"); ?>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td align="right">
                                                                    <label class="badge bg-success fs-7 text-black rounded fw-semibold">&#8377; 55,000</label>
                                                                </td>
                                                                <td>
                                                                    <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Receipt Date">Offline</label>
                                                                    <div class="d-block">
                                                                        <label class="fs-8 text-dark fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Transaction ID">TXN20250526ABC12345</label>
                                                                    </div>
                                                                </td>
                                                                <td class="text-center">
                                                                    <label class="text-danger fs-7">NDA Signed</label>
                                                                    <div class="d-block">
                                                                        <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="NDA ID">GC/IZONE/2024/02346/03615</label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <span class="text-end">
                                                                        <a href="{{url('/manage_invoice/invoice_print')}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print Receipt">
                                                                            <i class="mdi mdi-printer-pos-outline fs-3 text-black"></i>
                                                                        </a>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="divider divider-primary mt-10 mb-10">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">NDA Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table align-middle table-row-dashed gy-1 gs-2 common_table">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                <th class="min-w-100px">NDA ID</th>
                                                                <th class="min-w-80px">NDA Date</th>
                                                                <th class="min-w-100px">NDA Status</th>
                                                                <th class="min-w-50px">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                                            <tr>
                                                                <td>
                                                                    <label class="fs-7">GC/IZONE/2024/02346/03613</label>
                                                                </td>
                                                                <td>
                                                                    <label class="fs-7">28-Mar-2025</label>
                                                                </td>
                                                                <td>
                                                                    <label class="badge bg-success text-black fs-8 fw-semibold">NDA Signed</label>
                                                                </td>
                                                                <td>
                                                                    <span class="text-end">
                                                                        <a href="{{url('/manage_nda/nda_print')}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="NDA Print">
                                                                            <i class="mdi mdi-printer-pos-outline fs-3 text-black"></i>
                                                                        </a>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="divider divider-primary mt-3 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">
                                                <label>Work Order Information &emsp; - &emsp;</label>
                                                <label class="badge bg-info text-white mb-1 fs-5 fw-semibold" style="background-color: #218837 !important;">Verified Work Order</label>
                                            </div>
                                        </div>
                                        <div class="text-black fs-6 mb-3 fw-semibold"><u>Billable Details</u></div>
                                        <div class="row mb-4">
                                            <div class="col-lg-12 mb-3">
                                                <label class="text-end me-2">
                                                    <svg height="20px" width="20px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                        <g id="SVGRepo_iconCarrier">
                                                            <defs>
                                                                <style>
                                                                    .cls-1 {
                                                                        fill: #699f4c;
                                                                        fill-rule: evenodd;
                                                                    }
                                                                </style>
                                                            </defs>
                                                            <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                        </g>
                                                    </svg>
                                                </label>
                                                <label class="text-black fs-7 fw-semibold">Service Based Billable</label>
                                            </div>
                                        </div>
                                        <div class="text-black fs-6 mb-3 fw-semibold"><u>Checklist</u></div>
                                        <div class="scroll-y max-h-225px px-3 py-1 mb-4">
                                            <div class="row">
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Payment Confirmation</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Confirm the services (ex: Proposal, Thesis, Publication)</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Duration of the service</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">The preferred mode of communication (Email, WhatsApp, Call)</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Best time to contact</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">if any documents are pending from the client</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Inform about the turnaround time for deliverables</div>
                                                </div>
                                                <div class="col-lg-12 d-flex align-items-start mb-1">
                                                    <div class="text-black fs-7 fw-semibold me-2"><i class="mdi mdi-text-box-check-outline text-dark fs-4"></i></div>
                                                    <div class="text-black fs-7 fw-semibold text-wrap">Confirm if the client has any urgent deadlines</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-6">
                                            <div class="col-12 text-dark fs-6 fw-semibold">Description</div>
                                            <div class="col-12 text-black fs-6 fw-semibold">&emsp;&emsp;&emsp;-</div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade active show" id="navs-payment_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Payment Information</div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-6">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service Title</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-semibold">{{$payment_list->service_title ?? ''}}</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Currency Format</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-semibold">{{$payment_list->currency_code}} - {{$payment_list->currency_symbol}}</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-semibold">Thesis Writing</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Service Category</label>
                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-semibold">Writing Services</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <div class="col-lg-12 d-flex align-items-center justify-content-center gap-5 flex-wrap">
                                                <div class="badge bg-secondary fw-semibold fs-6 rounded py-2 px-3">
                                                    <label class="text-white mb-2 fs-4 fw-semibold">Total Amount</label>
                                                    <div class="d-block">
                                                        <label class="text-white fs-4 fw-semibold">{{$customer->currency_symbol}}  {{number_format($payment_list->TotalAmount)}}</label>
                                                    </div>
                                                </div>
                                                <div class="badge bg-success fw-semibold fs-6 rounded py-2 px-3">
                                                    <label class="text-white mb-2 fs-4 fw-semibold">Paid Amount</label>
                                                    <div class="d-block">
                                                        <label class="text-white fs-4 fw-semibold">{{$customer->currency_symbol}} {{number_format($payment_list->TotalPaidAmount)}}</label>
                                                    </div>
                                                </div>
                                                @php
                                                $balanceAmount=$payment_list->TotalAmount > $payment_list->TotalPaidAmount ? $payment_list->TotalAmount - $payment_list->TotalPaidAmount : 0 ;
                                                @endphp
                                                <div class="badge bg-danger fw-semibold fs-6 rounded py-2 px-3">
                                                    <label class="text-white mb-2 fs-4 fw-semibold">Balance Amount</label>
                                                    <div class="d-block">
                                                        <label class="text-white fs-4 fw-semibold">{{$customer->currency_symbol}} {{number_format($balanceAmount)}}</label>
                                                    </div>
                                                </div>
                                                <!-- <div class="d-flex align-items-center justify-content-center flex-column">
                                                    <div class="text-center border border-info border-dashed rounded px-3 py-2">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">Services</label>
                                                        <div class="d-block" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <label class="cursor-pointer text-info mb-1 fs-5 fw-semibold">01</label>
                                                            <a href="javascript:;" class="mb-1 me-n3"><i class="mdi mdi-menu-down text-black fs-3"></i></a>
                                                            <div class="dropdown-menu dropdown-menu-end w-25">
                                                                <div class="text-dark fs-6 text-center my-2 fw-semibold">Services</div>
                                                                <hr class="mt-0 mb-2 border-dark">
                                                                <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                        <div class="d-block">
                                                                            <div class="text-black fw-semibold text-justify fs-7">Thesis Writing</div>
                                                                            <div class="fw-semibold text-info fs-8">Writing Products</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                        <div class="d-block">
                                                                            <div class="text-black fw-semibold text-justify fs-7">Technical Research and Development Services</div>
                                                                            <div class="fw-semibold text-info fs-8">Developement Products</div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                                                        <div class="d-block">
                                                                            <div class="text-black fw-semibold text-justify fs-7">Formatting and Referencing</div>
                                                                            <div class="fw-semibold text-info fs-8">Developement Products</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> -->
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table align-top table-row-dashed gy-1 gs-2">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary common_table">
                                                                <th class="min-w-150px">Date & Time</th>
                                                                <th class="min-w-150px">Service Title</th>
                                                                <th class="min-w-150px">Receipt ID</th>
                                                                <th class="min-w-150px">Mode</th>
                                                                <th class="min-w-150px">Paid Amt</th>
                                                                <th class="min-w-50px text-center">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-gray-600 fw-semibold fs-6">
                                                            @if(count($payment_list->transaction)>0)
                                                            @foreach($payment_list->transaction as $pay)
                                                            @php
                                                            $encryptedValue = $helper->encrypt_decrypt($pay->slot_id,'encrypt',);
                                                            $print_url = url('/receipt_print/' . $encryptedValue,);
                                                            @endphp
                                                            <tr>
                                                                <td>
                                                                    <label class="fs-7 fw-semibold">
                                                                      {{ $pay->transaction_date ? date($common_date_format, strtotime($pay->transaction_date)) :'' }}
                                                                    </label>
                                                                </td>
                                                                <td>
                                                                     <label
                                                                        class="fs-7 fw-semibold text-black text-truncate max-w-150px"
                                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                        title="{{$pay->service_title}}">{{$pay->service_title}}</label>
                                                                </td>
                                                                <td>
                                                                    <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Receipt ID">{{$pay->invoice_id}}</label>
                                                                </td>
                                                                <td>
                                                                    <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Receipt Date">{{$pay->payment_mode ==1 ?'Online' :'Offline'}}</label>
                                                                    <div class="d-block">
                                                                        <label class="fs-8 text-dark fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Transaction ID">{{$pay->transaction_id}}</label>
                                                                    </div>
                                                                </td>
                                                                <td align="right">
                                                                    <label class="text-black fw-semibold fs-6">{{$pay->currency_symbol}} {{number_format($pay->paidAmount)}}</label>
                                                                </td>
                                                                <td align="center">
                                                                    <span class="text-end">
                                                                        <a href="{{$print_url}}" class="d-flex align-items-center justify-content-center pb-0">
                                                                            <img src="{{asset('assets/phdizone_images/print.gif')}}" alt="print" class="w-45px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print Receipt" />
                                                                        </a>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                            @endforeach
                                                            @else
                                                            <tr class="text-center">
                                                                <td colspan="6">No data Found</td>
                                                            </tr>
                                                            @endif
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-appointment_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Appointment Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table align-middle table-row-dashed gy-1 gs-2 common_table">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                <th class="min-w-150px">Date & Time</th>
                                                                <th class="min-w-100px">Appointment Mode</th>
                                                                <th class="min-w-100px">Assigned Staff</th>
                                                                <th class="min-w-100px">Appointment Status</th>
                                                                <th class="min-w-50px text-center">Actions</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                                            @if(count($appointments)>0)
                                                            @foreach ($appointments as $app)
                                                                <tr>
                                                                    <td>
                                                                        @php
                                                                        $dt = \Carbon\Carbon::parse($app->appointment_date);
                                                                        @endphp
                                                                        <span class="fw-semibold fs-7 text-black" data-bs-toggle="tooltip" title="Appointment Date & Time">
                                                                            {{ $dt->format('d-M-Y') }} <span class="ms-2">{{ $dt->format('h:i A') }}</span>
                                                                        </span>                                   
                                                                    </td>
                                                                    <td>
                                                                        <div>
                                                                            <label class="text-black fs-7 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                                title="Connecting Way">{{$app->con_name}}</label>
                                                                            @if (!empty($app->connecting_link))
                                                                                <a href="{{ $app->connecting_link }}" target="_blank" class="badge text-black fs-10 rounded"
                                                                                    style="background-color:#ace0ac;" title="Meeting Link">
                                                                                    <i class="mdi mdi-link-variant"></i>
                                                                                </a>                                      
                                                                            @endif
                                                                        </div>
                                                                        <span class="fw-semibold fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                            title="{{$app->appointment_mode_name}}">{{$app->appointment_mode_name}}</span>
                                                                    </td>
                                                                    <td>
                                                                        <div class="avatar-group d-flex">
                                                                            @if ($app->staff_image != '' && $app->staff_image != null && file_exists(public_path('staff_images/' .$app->staff_image)))
                                                                                <div class="symbol symbol-35px me-2">
                                                                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                                                                        <img src="{{ asset('staff_images/' . $app->staff_image) }}" alt="user-avatar"
                                                                                            class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                                                                    </div>
                                                                                </div>
                                                                            @else
                                                                                <div class="symbol symbol-35px me-2">
                                                                                    @php
                                                                                    $initial = strtoupper(substr($app->staff_name, 0, 1)); // Only keeps and
                                                                                    // capitalizes the first
                                                                                    echo $helper->name_image($initial, $app->gender);
                                                                                    @endphp
                                                                                </div>
                                                                            @endif
                                                                            <span class="mt-2">{{$app->staff_name}}</span>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        @if ($app->status == 0)
                                                                            <div class="badge bg-warning rounded fw-semibold fs-8 text-black">
                                                                                Appointment Scheduled
                                                                            </div>
                                                                        @elseif($app->status == 1)
                                                                            <span class="badge bg-success text-black fw-semibold fs-8">Appointment Completed</span>
                                                                        @elseif($app->status == 3)
                                                                            <span class="badge bg-danger text-white fw-semibold fs-8">Appointment Cancelled</span>
                                                                        @elseif ($app->status == 4)
                                                                            <span class="badge bg-info text-white fw-semibold fs-8">Appointment Re-Scheduled</span>
                                                                        @endif                                                                        
                                                                    </td>
                                                                    <td>
                                                                        <div class="text-center">
                                                                            <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal" onclick="viewAppointment('{{ $app->sno }}')"
                                                                                data-bs-target="#kt_modal_view_appointment">
                                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i
                                                                                        class="mdi mdi-eye-outline fs-3 text-black"></i></span>
                                                                            </a>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            @endforeach   
                                                            @else
                                                        <tr class="text-center">
                                                            <th colspan="5" class="text-black">No Data Found</th>
                                                        </tr>
                                                        @endif
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-requirements_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Requirements Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 common_table">
                                                    <thead>
                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                            <th class="min-w-250px">Requirements</th>
                                                            <th class="min-w-150px text-center">Documents</th>
                                                            <th class="min-w-150px text-center">Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                                        @if(count($requirements)>0)
                                                        @foreach ($requirements as $req) 
                                                            <tr>
                                                                <td>
                                                                    <div class="text-black fw-semibold fs-7">{{$req->requirement_name}}</div>
                                                                </td>
                                                                <td class="text-center">
                                                                    <a href="{{ asset('requirement_documents/' . $req->document_url) }}" class="mb-0" data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom" aria-label="View Attachments" data-bs-original-title="View Attachments">
                                                                        <span><i class="mdi mdi-download-circle-outline text-success fs-2"></i></span>
                                                                    </a>                   
                                                                </td>
                                                                <td class="text-center">
                                                                    @if($req->requirement_doc_status == 1)
                                                                    <label class="text-white bg-success border border-gray-400i rounded-pill px-2 fw-semibold fs-4"
                                                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed">&#10003;</label>
                                                                    @elseif ($req->requirement_doc_status == 0)
                                                                    <label class="text-white bg-danger border border-gray-400i rounded-pill px-2 fw-semibold fs-4"
                                                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pending">&#10005;</label>
                                                                    @endif                   
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                        @else
                                                        <tr class="text-center">
                                                            <th colspan="3" class="text-black">No Data Found</th>
                                                        </tr>
                                                        @endif
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-task_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Task Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                                    <thead>
                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                            <th class="min-w-125px">Task</th>
                                                            <th class="min-w-125px">Assigned Date</th>
                                                            <th class="min-w-80px">Working /<br>Usage Hrs</th>
                                                            <th class="min-w-50px">Assigned To</th>
                                                            <th class="min-w-100px">Status</th>
                                                            <th class="min-w-50px">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                                        @foreach($tasks as $task)
                                                            <tr>
                                                                <td>
                                                                    @php
                                                                        $percentage = $helper->completed_task_percentage($task->sno);
                                                                        $task_usage_hours = $helper->task_usage_hours($task->sno);
                                                                    @endphp
                                                                    <label class="text-black fw-semibold fs-7 text-wrap"
                                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                        title="Task">{{$task->task_name}}</label>
                                                                    <div class="d-block">
                                                                        <label class="text-dark fw-semibold fs-8 text-wrap"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Services">{{$task->product_name}}</label>
                                                                    </div>
                                                                    <div class="progress border border-gray-400i rounded bg-label-primary w-175px h-15px"
                                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                        title="Task Progress : {{$percentage}}%">
                                                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8"
                                                                            role="progressbar" style="width: {{$percentage}}%"
                                                                            aria-valuenow="{{$percentage}}" aria-valuemin="{{$percentage}}"
                                                                            aria-valuemax="{{$percentage}}">{{$percentage}}%</div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <label class="fs-7" data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom" title="Start  Date">
                                                                        <?php echo $task->start_date_time ? date("d-M-Y h:i A", strtotime($task->start_date_time)) : '-'; ?>
                                                                    </label>
                                                                    <div class="d-block">
                                                                        <label class="badge bg-danger fs-8"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom" title="End Date">
                                                                            <?php echo $task->end_date_time ? date("d-M-Y h:i A", strtotime($task->end_date_time)) : '-'; ?>
                                                                        </label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <label class="fw-semibold text-black fs-7">{{$task->working_hours}}
                                                                        Hrs</label>
                                                                    <div class="d-block">
                                                                        <label
                                                                            class="badge bg-transparent border border-info fw-semibold text-black fs-7"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Total Usage Hours">{{$task_usage_hours}} Hrs</label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    @php
                                                                    $staff_list = json_decode($task->assign_staffs, true);
                                                                    $staff_count = is_array($staff_list) ? count($staff_list) : 0;
                                                                    @endphp
                                                                
                                                                    <div class="d-flex align-items-center avatar-group mb-4">
                                                                        {{-- Show first 3 avatars only --}}
                                                                        @foreach ($staff_list as $index => $staff_id)
                                                                        @php
                                                                        $staff_details = $helper->staff_details($staff_id);
                                                                        $staff_name = $staff_details->staff_name ?? "-";
                                                                        $staff_image = $staff_details->staff_image ?? "";
                                                                        $job_position_name = $staff_details->job_position_name ?? "-";
                                                                        $gender = $staff_details->gender ?? 0;
                                                                        @endphp
                                                                
                                                                        @if ($index < 3) <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle"
                                                                            data-bs-toggle="tooltip" data-bs-placement="top" title="{{ $staff_name }}">
                                                                            @if ($staff_image && file_exists(public_path('staff_images/' . $staff_image)))
                                                                            <img src="{{ asset('staff_images/' . $staff_image) }}" alt="Staff" class="rounded-circle">
                                                                            @else
                                                                            {!! $helper->name_image(strtoupper(substr($staff_name, 0, 1)), $gender) !!}
                                                                            @endif
                                                                    </div>
                                                                    @endif
                                                                    @endforeach
                                                                
                                                                    {{-- Dropdown trigger always shown if more than 0 --}}
                                                                    @if ($staff_count > 3)
                                                                    <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle" data-bs-toggle="dropdown"
                                                                        aria-haspopup="true" aria-expanded="false">
                                                                        <span class="avatar-initial rounded-circle">+{{ $staff_count - 3 }}</span>
                                                                    </div>
                                                                
                                                                    <div class="dropdown-menu dropdown-menu-start w-250px">
                                                                        <div class="scroll-y max-h-200px px-3 py-1">
                                                                            @foreach ($staff_list as $staff_id)
                                                                            @php
                                                                            $staff_details = $helper->staff_details($staff_id);
                                                                            $staff_name = $staff_details->staff_name ?? "-";
                                                                            $staff_image = $staff_details->staff_image ?? "";
                                                                            $job_position_name = $staff_details->job_position_name ?? "-";
                                                                            $gender = $staff_details->gender ?? "Male";
                                                                            @endphp
                                                                
                                                                            <div class="d-flex align-items-center mb-2">
                                                                                <div class="symbol me-2">
                                                                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                                                                        @if ($staff_image && file_exists(public_path('staff_images/' . $staff_image)))
                                                                                        <img src="{{ asset('staff_images/' . $staff_image) }}" alt="Staff"
                                                                                            class="image-input-wrapper w-px-40 h-px-40 border border-gray-700i rounded-circle">
                                                                                        @else
                                                                                        {!! $helper->name_image(strtoupper(substr($staff_name, 0, 1)), $gender) !!}
                                                                                        @endif
                                                                                    </div>
                                                                                </div>
                                                                                <div class="mb-0">
                                                                                    <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                                        title="Staff">{{ $staff_name }}</label>
                                                                                    <div class="d-block mt-n1">
                                                                                        <div class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Role">{{
                                                                                            $job_position_name }}</div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            @if (!$loop->last)
                                                                            <hr class="mt-1 mb-1">
                                                                            @endif
                                                                            @endforeach
                                                                        </div>
                                                                    </div>
                                                                    @endif
                                                                    </div>                       
                                                                </td>
                                                                <td>
                                                                    @php

                                                                        $check_list = json_decode($task->task_check_list_ids, true);
                                                                        $check_list_count = is_array($check_list) ? count($check_list) : 0;
                                                                        $completed_count = $helper->completed_task_details($task->sno)??0;
                                                                        $balance_count = $check_list_count - $completed_count;

                                                                        if($task->status == 1 && $balance_count != 0){
                                                                            $task_name = 'In Progress';
                                                                            $task_color = '#FFA500';
                                                                            $task_text_color = 'text-black';
                                                                        }elseif ($task->status == 5 && $balance_count == 0){
                                                                            $task_name = 'QC Verified';
                                                                            $task_color = '#6F42C1';
                                                                            $task_text_color = 'text-white';
                                                                        }elseif ($balance_count == 0 && $task->status != 4 && $task->status != 5){
                                                                            $task_name = 'Completed';
                                                                            $task_color = '#218838';
                                                                            $task_text_color = 'text-white';
                                                                        }elseif ($task->status == 4){
                                                                            $task_name = 'Verified';
                                                                            $task_color = '#004085';
                                                                            $task_text_color = 'text-white';
                                                                        }
                                                                        else {
                                                                            $task_name = 'Not Yet Started';
                                                                            $task_color = '#117A65';
                                                                            $task_text_color = 'text-white';
                                                                        }
                                                                    @endphp

                                                                    <div class="badge bg-info {{$task_text_color}} fs-7 fw-semibold"
                                                                        style="background-color: {{$task_color}} !important;">Task {{$task_name}}</div>
                                                                </td>
                                                                <td>
                                                                    <span class="text-center">
                                                                        <a href="javascript:;" class="text-black fw-bold"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_view_task" onclick="view_task({{$task->sno}},'{{$task_name}}','{{$task_color}}','{{$task_text_color}}')">
                                                                            <span data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom" title="View"><i
                                                                                    class="mdi mdi-eye-outline fs-3 text-black"></i></span>
                                                                        </a>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-deliverables_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Deliverable Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table align-top table-row-dashed gy-0 gs-1 common_table">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                <th class="min-w-125px">Date & Time</th>
                                                                <th class="min-w-125px">Services</th>
                                                                <th class="min-w-80px">Deliverables</th>
                                                                <th class="min-w-100px text-center">Delivered Task</th>
                                                                <th class="min-w-100px">Status</th>
                                                                <th class="min-w-50px text-center">Action</th>
                                                            </tr>
                                                        </thead>
                                                       <tbody class="text-gray-600 fw-semibold fs-7">
                                                            @if(count($delivarables)>0)
                                                                @foreach($delivarables as $del)
                                                                    <tr>
                                                                        <td>
                                                                            @php
                                                                            $start_date = isset($del->created_at) ? date('d-M-Y', strtotime($del->created_at)) : '-';
                                                                            $start_time = isset($del->created_at) ? date('h:i A', strtotime($del->created_at)) : '';
                                                                            @endphp
                                                                            <label class="fs-7">
                                                                                <?php echo $start_date . "<br>" . $start_time; ?>
                                                                            </label>                   
                                                                        </td>
                                                                        <td>
                                                                            <div
                                                                                class="fw-semibold text-black fs-7 text-wrap min-w-200px max-w-350px">
                                                                                {{$del->product_name}}</div>
                                                                            <div class="d-block mb-1">
                                                                                <div
                                                                                    class="fw-semibold text-dark fs-8 text-wrap min-w-200px max-w-350px">
                                                                                    {{$del->product_category_name}}</div>
                                                                            </div>
                                                                        </td>
                                                                        <td>
                                                                            <div class="text-black fw-semibold fs-7">{{$del->payment_slot_name}}
                                                                            </div>
                                                                        </td>
                                                                        <td align="center">
                                                                            @php
                                                                                $task_list = json_decode($del->task_ids, true);
                                                                                $task_list_count = is_array($task_list) ? count($task_list) : 0;
                                                                            @endphp
                                                                            <label
                                                                                class="badge bg-transparent rounded-pill fw-semibold text-black fs-7"
                                                                                style="border:1px solid #08a34f;">{{ str_pad($task_list_count??0, 2, '0', STR_PAD_LEFT)??'0' }}</label>
                                                                        </td>
                                                                        <td>
                                                                            <div class="badge bg-info text-white fs-7 fw-semibold"
                                                                                style="background-color: #117A65 !important;">
                                                                                Delivered</div>
                                                                        </td>
                                                                        <td>
                                                                            <div class="text-center">
                                                                                <a href="javascript:;" onclick="Viewmodel('{{ $del->sno }}')"
                                                                                    class="text-black fw-bold"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_view_deliverables">
                                                                                    <span data-bs-toggle="tooltip"
                                                                                        data-bs-placement="bottom"
                                                                                        title="View"><i
                                                                                            class="mdi mdi-eye-outline text-black fs-3"></i></span>
                                                                                </a>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                @endforeach
                                                            @else
                                                                <tr class="text-center">
                                                                    <th colspan="6" class="text-black">No Data Found</th>
                                                                </tr>
                                                            @endif
                                                            
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-staff_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Staff Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                                    <thead>
                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                            <th class="min-w-50px">Staff</th>
                                                            <th class="min-w-125px">Services</th>
                                                            <th class="min-w-125px text-center">Task<br><span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total / Complete / Pending">(T / C / P)</span></th>
                                                            <th class="min-w-125px text-center">Total Allocated Hrs</th>
                                                            <th class="min-w-125px text-center">Total Usage Hrs</th>
                                                            <th class="min-w-100px">Progress</th>
                                                        </tr>
                                                    </thead>
                                                     <tbody class="text-gray-600 fw-semibold fs-7">
                                                        @foreach($staffs as $staff)
                                                        @php
                                                            $percentage = $helper->completed_task_percentage($staff['sno']);
                                                            $task_usage_hours = $helper->task_usage_hours($staff['sno']);
                                                        @endphp
                                                            <tr>
                                                                @php
                                                                    $staff_image = $staff['staff_image'] ?? "";
                                                                    $staff_name = $staff['staff_name'] ?? "A";
                                                                    $gender = $staff['gender'] ?? 0;
                                                                @endphp
                                                                <td>
                                                                    <div class="d-flex align-items-center">
                                                                        <div class="symbol symbol-35px me-2">
                                                                            <div class="image-input image-input-circle" data-kt-image-input="true">
                                                                                @if ($staff_image && file_exists(public_path('staff_images/' . $staff_image)))
                                                                                <img src="{{ asset('staff_images/' . $staff_image) }}" alt="Staff"
                                                                                    class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                                                                @else
                                                                                {!! $helper->name_image(strtoupper(substr($staff_name, 0, 1)), $gender) !!}
                                                                                @endif
                                                                            </div>
                                                                        </div>
                                                                        <div class="mb-0">
                                                                            <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                                title="Staff">{{ $staff['staff_name'] }}</label>
                                                                            <div class="d-block">
                                                                                <div class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                                    title="Staff Nick Name">{{ $staff['nick_name'] }}</div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div
                                                                        class="fw-semibold text-black fs-7 text-wrap max-w-200px">
                                                                        {{$staff['product_name']}}</div>
                                                                    <div class="d-block mb-1">
                                                                        <div
                                                                            class="fw-semibold text-dark fs-8 text-wrap max-w-200px">
                                                                            {{$staff['product_category_name']}}</div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    @php
                                                                        $check_list = json_decode($staff['task_check_list_ids'], true);
                                                                        $check_list_count = is_array($check_list) ? count($check_list) : 0;
                                                                        $completed_count = $helper->completed_task_details($staff['sno'])??0;
                                                                        $balance_count = $check_list_count - $completed_count;
                                                                    @endphp
                                                                    <label class="badge bg-secondary rounded-pill fw-semibold text-white fs-7 me-1" data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom" title="Total Checklist">{{ str_pad($check_list_count??0, 2, '0', STR_PAD_LEFT)??'0' }}</label>
                                                                    <label class="badge bg-transparent rounded-pill fw-semibold text-black fs-7 me-2" data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom" title="Completed Checklist" style="border:1px solid #08a34f;">{{ str_pad($completed_count??0, 2, '0', STR_PAD_LEFT)??'0' }}</label>
                                                                    <label class="badge bg-danger rounded-pill fw-semibold text-white fs-7" data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom" title="Pending Checklist">{{ str_pad($balance_count??0, 2, '0', STR_PAD_LEFT)??'0' }}</label>                           
                                                                </td>
                                                                <td align="center">
                                                                    <label class="fw-semibold text-black fs-7">{{$staff['working_hours']}}
                                                                        Hrs</label>
                                                                </td>
                                                                <td align="center">
                                                                    <label
                                                                        class="badge bg-transparent border border-info fw-semibold text-black fs-7">{{$task_usage_hours}}
                                                                        Hrs</label>
                                                                </td>
                                                                <td>
                                                                    <div class="progress border border-gray-400i rounded bg-label-primary w-175px h-15px"
                                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                        title="Staff Progress : {{$percentage}}%">
                                                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8"
                                                                            role="progressbar" style="width: {{$percentage}}%"
                                                                            aria-valuenow="{{$percentage}}" aria-valuemin="{{$percentage}}"
                                                                            aria-valuemax="{{$percentage}}">{{$percentage}}%</div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                         
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="navs-journal_info">
                                        <div class="divider divider-primary mt-4 mb-4">
                                            <div class="divider-text text-black mb-2 fs-5 fw-semibold">Journal Information</div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                                    <thead>
                                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                            <th class="min-w-150px">Journal / Domain</th>
                                                            <th class="min-w-150px">Paper</th>
                                                            <th class="min-w-150px">Services</th>
                                                            <th class="min-w-100px text-center">Author / Published</th>
                                                            <th class="min-w-100px">Status</th>
                                                            <th class="min-w-50px text-center">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                                        @foreach($journals as $journal)
                                                            <tr>
                                                                <td>
                                                                    <label
                                                                        class="fs-7 fw-semibold text-black text-truncate max-w-150px"
                                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                        title="{{$journal->journal_name}}">{{$journal->journal_name}}</label>
                                                                    <div class="d-block mt-n2">
                                                                        <label
                                                                            class="fs-8 fw-semibold text-dark text-truncate max-w-150px"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="{{ implode(', ', $journal->domain_names) }}">{{ implode(', ', $journal->domain_names) }}</label>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="fs-7 fw-semibold text-black text-truncate max-w-150px"
                                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                        title="{{$journal->paper_name}}">
                                                                        {{$journal->paper_name}}</div>
                                                                </td>
                                                                <td>
                                                                    <div
                                                                        class="fw-semibold text-black fs-7 text-wrap max-w-200px">
                                                                        {{$journal->service_name}}</div>
                                                                    <div class="d-block mb-1">
                                                                        <div
                                                                            class="fw-semibold text-dark fs-8 text-wrap max-w-200px">
                                                                            {{$journal->category_name}}</div>
                                                                    </div>
                                                                </td>
                                                                <td align="center">
                                                                    @if (!empty($journal->published_url))
                                                                        <div class="fw-semibold text-dark fs-8 text-wrap max-w-200px">
                                                                            {{ $journal->author_name ?? '-' }}
                                                                        </div>
                                                                        <a href="{{ $journal->published_url }}" class="badge bg-body rounded px-2" data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom" title="Published Link">
                                                                            <i class="mdi mdi-link-variant text-danger fs-4"></i>                                
                                                                        </a>
                                                                    @else
                                                                        -
                                                                    @endif
                                                                </td>
                                                                <td>
                                                                    @if ($journal->status == 0)
                                                                        <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color:#007BFF !important;">
                                                                            Submitted
                                                                        </div>
                                                                    @elseif ($journal->status == 1)
                                                                        <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: 	#FFA500 !important;">
                                                                            Reviewed
                                                                        </div>
                                                                    @elseif ($journal->status == 2)
                                                                        <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color:#DC3545 !important;">Rejected</div>
                                                                    @elseif ($journal->status == 3)
                                                                        <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #800080 !important;">Resubmitted</div>
                                                                    @elseif($journal->status == 4)
                                                                        <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color:#28A745 !important;">Submitted</div>
                                                                    @elseif ($journal->status == 5)
                                                                        <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #17A2B8 !important;">Published</div>
                                                                    @endif                                                                    
                                                                </td>
                                                                <td>
                                                                    <div class="text-center">
                                                                        <a href="javascript:;"
                                                                            class="text-black fw-bold me-1" onclick="viewDataFetch('{{$journal->sno}}')"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_view_journal_monitor">
                                                                            <span data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom" title="View"><i
                                                                                    class="mdi mdi-eye-outline fs-3"></i></span>
                                                                        </a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                       
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab_service_2" role="tabpanel">

                    </div>
                    <div class="tab-pane fade" id="tab_service_3_completed" role="tabpanel">

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>






<!--begin::Modal - View Appointment-->
<div class="modal fade" id="kt_modal_view_appointment" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">
                        <span>View Customer Appointment</span>
                        <span class="ms-1 me-1">-</span>
                        <span class="badge bg-warning rounded text-black fw-semibold fs-5"
                            id="title-main">Scheduled</span>
                    </h3>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Appointment Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-6">
                        <label class="badge bg-warning text-black fs-6 fw-bold" id="view_app_date"></label>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="view_cus_name"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="cus_num"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Appointment Category">Appointment Mode </label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="view_app_name"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Appointment Category">Appointment Conecting Way </label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold d-flex"> <span class="me-2" id="view_con_name"></span>
                        <span id="viewLinkWrapper">
                            <a id="view_link" href="https://us02web.zoom.us/j/12345678901?pwd=abcdefghijklmno"
                                class=" fs-10 text-black badge rounded" style="background-color:#ace0ac"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Meeting Link"><span
                                    class="mdi mdi-link-variant"></span>
                            </a>
                        </span>
                    </label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Assigned Staff</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="view_staff_name"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Appointment Reason</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="view_app_reason"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Description</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="view_app_desc"></label>
                </div>
                <div class="re-schedule-container">
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Re-Scheduled Date</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="cancel-schedule-date">09-Jun-2025 10:00
                            Am.</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Re-Scheduled Reason</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="view_app_cancel_reason"></label>
                    </div>
                </div>
                <div class="cancelled-container">
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Cancelled Reason</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="cancel-app-reason">The meeting is cancelled due
                            to unforeseen
                            circumstances.</label>
                    </div>
                </div>
                <div class="completed-container">
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Describe Appointment</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black text-justify fs-6 fw-bold" id="completed-app-reason">
                            The appointment was completed successfully with professionalism and
                            clear communication. All objectives were met, making the session productive and valuable.
                        </label>
                    </div>
                    <div class="col-lg-6">
                        <div class="row mb-4">
                            <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Attachment</label>
                            <div class="col-12 mb-1">
                                <div class="border border-gray-600i border-dashed rounded py-1 px-1">
                                    <div id="attachmentContainer" class="d-flex mb-1 align-items-center flex-wrap">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Appointment -->

<!--begin::Modal - View Task-->
<div class="modal fade" id="kt_modal_view_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">
                        <label>View Task Details</label>
                        <label class="ms-1 me-1">-</label>
                        <label id="view_badge"></label>
                    </h3>
                </div>
                <div id="view_data_div"></div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Task-->

<!--begin::Modal - View Deliverables-->
<div class="modal fade" id="kt_modal_view_deliverables" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8">
                    <h3 class="text-center text-black">View Deliverables Details</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Date & Time</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="created_view">-</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Services</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="product_name_view"></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold"><span id="cus_name_view"></span> - <span
                            class="fs-7 text-primary">( <span id="cus_id_view"></span> )</span></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Deliverables</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-info fs-7 fw-semibold" id="slot_name_view">-</label>
                    </div>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black fs-7 fw-semibold">&emsp;&emsp; <span id="view_desc"></span></label>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-1 text-black fs-6 fw-semibold">
                        <label class="text-black fs-6 fw-semibold me-1">Overall Task</label>
                    </div>
                </div>
                <hr class="mt-1 mb-2">
                <div class="scroll-y max-h-250px px-3 py-2" id="task_view_div">

                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Deliverables-->

<!--begin::Modal - View Journal Monitor-->
<div class="modal fade" id="kt_modal_view_journal_monitor" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">
                        <span>View Journal Details</span>
                        <span class="ms-1 me-1">-</span>
                        <span class="badge bg-info fw-semibold fs-5" style="background-color: #007BFF !important;"
                            id="view_title">Submitted</span>
                    </h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold"><span id="view_customer"></span> <span
                            class="fs-7 text-primary" id="view_customer_id"></span></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Services</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold"><span id="view_services"></span> <span
                            id="view_services_category"></span></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Journal</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="view_journal"></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Domain</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="view_domain_names"></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Paper</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="view_paper"></label>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black fs-7 fw-semibold" id="view_desc"></label>
                </div>
                <div class="row mb-6" id="view_submitted_row">
                    <div class="col-lg-12">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Submitted Documents</label>
                        <div class="border border-gray-600i border-dashed rounded py-3 px-2">
                            <div id="submitted_document_container"
                                class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">

                            </div>
                        </div>
                    </div>
                </div>
                <div id="view_reviewed_row">
                    <div class="divider divider-primary mb-6">
                        <div class="divider-text fs-5 text-black fw-semibold">Reviewed</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-12">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Reviewed Documents</label>
                            <div class="border border-gray-600i border-dashed rounded py-3 px-2">
                                <div id="reviewed_document_container"
                                    class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Reviewer Comments</label>
                        <label class="col-12 text-black text-justify fs-7 fw-semibold"
                            id="view_reviewed_comments"></label>
                    </div>
                </div>
                <div id="view_rejected_row">
                    <div class="divider divider-primary mb-6">
                        <div class="divider-text fs-5 text-black fw-semibold">Rejected</div>
                    </div>
                    <div class="row mb-6">
                        <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Rejected Reason</label>
                        <label class="col-12 text-black text-justify fs-7 fw-semibold"
                            id="view_rejected_reason"></label>
                    </div>
                </div>
                <div id="view_published_row">
                    <div class="divider divider-primary mb-6">
                        <div class="divider-text fs-5 text-black fw-semibold">Published</div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Date</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold">
                            <?php echo date("d-M-Y"); ?>
                        </label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Paper</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="view_published_paper"></label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Author</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="view_published_author"></label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">URL</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <div class="col-8 text-black fs-6 fw-semibold">
                            <a href="" class="badge bg-body rounded px-2" data-bs-toggle="tooltip"
                                data-bs-placement="bottom" title="Published Link" id="view_published_url"><i
                                    class="mdi mdi-link-variant text-danger fs-4"></i></a>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-12">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Published Documents</label>
                            <div class="border border-gray-600i border-dashed rounded py-3 px-2">
                                <div id="published_documents_container"
                                    class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                        <label class="col-12 text-black text-justify fs-7 fw-semibold" id="view_published_desc"></label>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Journal Monitor-->










<script>
    $('#accr_1').click(function() {
        $('#accr_1_tbox').slideToggle('slow');

        // Toggle the icon class
        let icon = $(this).find('.op_cl i'); // Find the icon inside the clicked element
        if (icon.hasClass('mdi-menu-up')) {
            icon.removeClass('mdi-menu-up').addClass('mdi-menu-down');
        } else {
            icon.removeClass('mdi-menu-down').addClass('mdi-menu-up');
        }
    });


    $('#accr_2').click(function() {
        $('#accr_2_tbox').slideToggle('slow');

        let icon = $(this).find('.op_cl i'); // Find the icon inside the clicked element
        if (icon.hasClass('mdi-menu-down')) {
            icon.removeClass('mdi-menu-down').addClass('mdi-menu-up');
        } else {
            icon.removeClass('mdi-menu-up').addClass('mdi-menu-down');
        }
    });
</script>
<script>
    document.querySelectorAll('button[data-bs-toggle="tab"]').forEach(tab => {
        tab.addEventListener('shown.bs.tab', function(event) {
            // const complt_serv = document.getElementById("complt_serv");

            // if (complt_serv.classList.contains('active')) {
            //     document.getElementById("complt_serv_txt").setAttribute("style", "Color:rgb(0, 0, 0) !important;");
            //     complt_serv.setAttribute("style", "background-color: #00ef8c !important;");
            // } else {
            //     document.getElementById("complt_serv_txt").setAttribute("style", "Color:#4b4b4b !important;");
            //     complt_serv.setAttribute("style", "background-color: #0ed884 !important;");
            // }
        });
    });
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
     // View Appointment
    function viewAppointment(id){
        fetch(`/view_manage_appointments/${id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        })
        .then(response => response.json())
        .then(data => {
            if(data.status === 200){
                var app = data.data;

                // Formatting Date
                var rawDate = new Date(app.appointment_date);

                function formatDate(date) {
                    const months = [
                        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
                    ];

                    let day = date.getDate().toString().padStart(2, '0');
                    let month = months[date.getMonth()];
                    let year = date.getFullYear();

                    let hours = date.getHours();
                    let minutes = date.getMinutes().toString().padStart(2, '0');

                    let ampm = hours >= 12 ? 'PM' : 'AM';
                    hours = hours%12;
                    hours = hours ? hours : 12;
                    hours = hours.toString().padStart(2, '0');

                    return `${day}-${month}-${year} ${hours}:${minutes} ${ampm}`;
                }

                var formattedDate = formatDate(rawDate);

                // Cancelation date
                var cancelDate = new Date(app.reschedule_date);
                
                function formatsDate(date) {
                const months = [
                'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
                ];
                
                let day = date.getDate().toString().padStart(2, '0');
                let month = months[date.getMonth()];
                let year = date.getFullYear();
                
                let hours = date.getHours();
                let minutes = date.getMinutes().toString().padStart(2, '0');
                
                let ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours%12;
                hours = hours ? hours : 12;
                hours = hours.toString().padStart(2, '0');
                
                return `${day}-${month}-${year} ${hours}:${minutes} ${ampm}`;
                }
                
                var formatteDate = formatsDate(cancelDate);

                // Fetch data
                $('#view_app_date').text(formattedDate);
                $('#view_cus_name').html(app.name);
                $('#cus_num').html(app.cus_mobile);
                $('#view_app_name').html(app.appointment_mode_name);
                $('#view_con_name').html(app.con_name);

                if(app.connecting_link && app.connecting_link.trim() !== ''){
                    $('#view_link').attr('href', app.connecting_link);
                    $('#viewLinkWrapper').show();
                } else {
                    $('#viewLinkWrapper').hide();
                }

                $('#view_staff_name').html(app.staff_name);
                $('#view_app_reason').html(app.appointment_reason);
                $('#view_app_desc').html(app.appointment_desc ?? '-');
                $('#view_app_cancel_reason').html(app.reschedule_reason);
                $('#cancel-app-reason').html(app.appointment_cancel_reason);
                $('#completed-app-reason').html(app.appointment_summary)

                if(app.status === 4){
                    $('#title-main').text('Re-Scheduled');
                    $('#cancel-schedule-date').text(formatteDate);
                    $('#title-main').removeClass('bg-warning text-black').addClass('bg-info text-white');
                    $('.re-schedule-container').show();
                    $('.cancelled-container').hide();
                    $('.completed-container').hide();
                } else {
                    $('.re-schedule-container').hide();
                }

                if(app.status == 3){
                    $('#title-main').text('Cancelled');
                    $('#title-main').removeClass('bg-warning text-black').addClass('bg-danger text-white');
                    $('.cancelled-container').show();
                    $('.completed-container').hide();
                    $('.re-schedule-container').hide();
                } else {
                    $('.cancelled-container').hide();
                }

                if(app.status == 1){
                    $('#title-main').text('Completed');
                    $('#title-main').removeClass('bg-warning').addClass('bg-success');
                    $('.completed-container').show();
                    $('.cancelled-container').hide();
                    $('.re-schedule-container').hide();
                } else {
                    $('.completed-container').hide();
                }

                if(app.status === 0){
                    $('.completed-container').hide();
                    $('.cancelled-container').hide();
                    $('.re-schedule-container').hide();
                }

                const projectAttachments = document.getElementById('attachmentContainer');
                projectAttachments.innerHTML = '';

                console.log('Appointment attachments:', app.uploaded_files);

                let attachmentsArray = [];

                if (app.uploaded_files) {
                    if (Array.isArray(app.uploaded_files)) {
                        attachmentsArray = app.uploaded_files;
                    } else if (typeof app.uploaded_files === 'string') {
                        attachmentsArray = [app.uploaded_files];
                    } else {
                        console.warn('Unexpected attachments data type:', typeof app.uploaded_files);
                        attachmentsArray = [];
                    }
                }

                if (attachmentsArray.length > 0) {
                attachmentsArray.forEach(file => {
                if (typeof file !== 'string') {
                console.error('Attachment file is not a string:', file);
                return; // Skip invalid file entries
                }
                
                // Remove quotes and brackets from filename
                const cleanFile = file.trim().replace(/["'\[\]]/g, '');
                if (!cleanFile) {
                console.warn('Empty filename after cleaning:', file);
                return;
                }
                
                const extension = cleanFile.split('.').pop().toLowerCase();
                const fileUrl = `/appointments/${encodeURIComponent(cleanFile)}`;
                console.log(fileUrl);
                
                let attachmentHTML = '';
                
                if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(extension)) {
                attachmentHTML = `
                <div class="d-block overlay text-center me-1 px-2 py-2">
                    <a href="${fileUrl}" target="_blank" download
                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                        <img src="${fileUrl}" alt="Image Attachment" class="h-75px w-75px" />
                    </a>
                </div>`;
                } else if (extension === 'pdf') {
                attachmentHTML = `
                <div class="d-block overlay text-center me-1 px-2 py-2">
                    <a href="${fileUrl}" target="_blank" download
                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                        <img src="/assets/phdizone_images/def_pdf.png" alt="PDF" class="h-75px w-75px" />
                    </a>
                </div>`;
                } else if (['doc', 'docx'].includes(extension)) {
                attachmentHTML = `
                <div class="d-block overlay text-center me-1 px-2 py-2">
                    <a href="${fileUrl}" target="_blank" download
                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                        <img src="/assets/phdizone_images/def_doc.png" alt="DOC" class="h-75px w-75px" />
                    </a>
                </div>`;
                } else if (['xls', 'xlsx'].includes(extension)) {
                attachmentHTML = `
                <div class="d-block overlay text-center me-1 px-2 py-2">
                    <a href="${fileUrl}" target="_blank" download
                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                        <img src="/assets/phdizone_images/def_excel.png" alt="Excel" class="h-75px w-75px" />
                    </a>
                </div>`;
                } else if (['sql', 'txt', 'csv', 'json'].includes(extension)) {
                attachmentHTML = `
                <div class="d-block overlay text-center me-1 px-2 py-2">
                    <a href="${fileUrl}" target="_blank" download
                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                        <img src="/assets/phdizone_images/def_code.png" alt="Text File" class="h-75px w-75px" />
                    </a>
                </div>`;
                } else {
                // Fallback: default file preview
                attachmentHTML = `
                <div class="d-block overlay text-center me-1 px-2 py-2">
                    <a href="${fileUrl}" target="_blank" download
                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                        <img src="/assets/phdizone_images/def_file.jpeg" alt="File" class="h-75px w-75px" />
                    </a>
                </div>`;
                }
                
                projectAttachments.insertAdjacentHTML('beforeend', attachmentHTML);
                });
                } else {
                projectAttachments.innerHTML = '<span class="text-muted">No submitted documents found.</span>';
                }
            }
        })
        .catch(error => {
            console.log('Error Fetching Data :', error);
        });
    }
</script>

<script>
    function view_task(id,task_name,color,text_color) {

        $('#view_badge').html(`
                            <span class="badge bg-info ${text_color || ''} rounded fw-semibold fs-5" 
                                    style="background-color: ${color || ''} !important;">
                                ${task_name || ''}
                            </span>
                            `);
        fetch('/manage_production/task_view/' + id, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    var com = data.data;
                    $('#view_data_div').empty().append(data.data.html);
                    $('[data-bs-toggle="tooltip"]').tooltip();

                    const containers = document.getElementById('product_variant_container');
                        containers.innerHTML = '';
                
                        data.data.product_list.forEach(product => {
                            const productDiv = document.createElement('div');
                            productDiv.classList.add('col-lg-12', 'mb-3');
                
                            // Create the main product label
                            productDiv.innerHTML = `
                            <label class="text-black fs-6 fw-semibold">
                                <i class="mdi mdi-star-three-points-outline text-primary fs-3"></i>
                            </label>
                            <label class="text-black fs-6 fw-semibold text-wrap">
                                <span>${product.product_name ?? 'N/A'}</span>
                                <span class="text-danger fs-7 ms-1">${product.product_category_name ? `(${product.product_category_name})` : ''}</span>
                            </label>
                            `;
                
                            // Create dropdown wrapper
                            const dropdownWrapper = document.createElement('div');
                            dropdownWrapper.classList.add('position-relative', 'd-inline-block');
                
                            // Create the icon that toggles dropdown
                            const icon = document.createElement('span');
                            icon.classList.add('mdi', 'mdi-package-variant-closed', 'text-primary', 'fs-5', 'ms-2', 'cursor-pointer');
                            icon.setAttribute('data-bs-toggle', 'dropdown');
                            icon.setAttribute('aria-haspopup', 'true');
                            icon.setAttribute('aria-expanded', 'false');
                            icon.setAttribute('title', 'Product Variant');
                
                            dropdownWrapper.appendChild(icon);
                
                            // Create dropdown menu
                            const dropdownMenu = document.createElement('div');
                            dropdownMenu.classList.add('dropdown-menu', 'dropdown-menu-end', 'w-md-300px', 'w-sm-100', 'mt-2', 'p-3');
                            dropdownMenu.style.boxShadow = '0px 5px 15px -3px rgba(0,0,0,0.2), 0px 8px 15px 1px rgba(0,0,0,0.14), 0px 3px 15px 2px rgba(0,0,0,0.12)';
                
                            // Add header inside dropdown
                            dropdownMenu.innerHTML = '<div class="text-black text-center fw-semibold fs-7 mb-2"><u>Product Variant Info</u></div>';
                
                            if (product.variant_variable_data && product.variant_variable_data.length > 0) {
                            product.variant_variable_data.forEach((item, index) => {
                                const variantBlock = document.createElement('div');
                                variantBlock.classList.add('mb-2');
                
                                variantBlock.innerHTML = `
                                <div class="text-dark fw-semibold fs-8">Variant Name:</div>
                                <div class="text-black">${item.variant ?? '-'}</div>
                                <div class="text-dark fw-semibold fs-8 mt-1">Details Variable:</div>
                                <div class="text-black">${item.variable ?? '-'}</div>
                                `;
                
                                dropdownMenu.appendChild(variantBlock);
                
                                if (index !== product.variant_variable_data.length - 1) {
                                const hr = document.createElement('hr');
                                hr.classList.add('my-2');
                                dropdownMenu.appendChild(hr);
                                }
                            });
                            } else {
                            const noData = document.createElement('div');
                            noData.classList.add('text-muted', 'fs-8', 'text-center');
                            noData.textContent = 'No variant data available.';
                            dropdownMenu.appendChild(noData);
                            }
                
                            dropdownWrapper.appendChild(dropdownMenu);
                            productDiv.appendChild(dropdownWrapper);
                            containers.appendChild(productDiv);
                        });
                } else {
                    console.log(data.error_msg);
                }
            })
            .catch(error => {
                console.log('Error:', error);
            });
    }
</script>

<script>
    function Viewmodel(id) {
            fetch('/Deliverables_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        // console.log(data.data);
                        var com = data.data;
                        $('#product_name_view').html(com.product_name).attr('title', com.product_name);
                        let createdDate = new Date(com.created_at);
                        let formattedDate = createdDate.toLocaleString('en-GB', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                            hour12: true
                        });
                        $('#created_view').html(formattedDate);

                        $('#cus_id_view').html(com.cus_id);
                        $('#cus_name_view').html(com.cus_name).attr('title', com.cus_name);
                        $('#slot_name_view').html(com.payment_slot_name).attr('title', com.payment_slot_name);
                        $('#view_desc').html(com.deliverables_desc||'-').attr('title', com.deliverables_desc);
                        $('#task_view_div').html(data.task_data);
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        // console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    // console.error('Error:', error);
              });
             
        }
</script>
<!--journanl script-->
<script>
     // View Journal
    function viewDataFetch(id) {
        fetch(`/view_journal/${id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{csrf_token()}}'
            }
        })
        .then(res => res.json())
        .then(data => {
            if(data.status == 200){
                var monitor = data.data;
                
                $('#view_customer').html(monitor.cus_name);
                $('#view_customer_id').html(`( ${monitor.customer_id} )`);
                $('#view_services').html(monitor.service_name);
                $('#view_services_category').html(`( ${monitor.category_name} )`);
                $('#view_journal').html(monitor.journal_name);
                $('#view_domain_names').html(monitor.domain_names.join(', '));
                $('#view_paper').html(monitor.paper_name);
                $('#view_desc').html(monitor.manage_journal_desc ?? '-');

                // Hide all rows initially
                $('#view_submitted_row').hide();
                $('#view_published_row').hide();
                $('#view_rejected_row').hide();
                $('#view_reviewed_row').hide();

                const title = document.getElementById('view_title');

                // Submitted Row (status 0)
                if(monitor.journal_monitor_status === 0){

                    title.textContent = 'Submitted';
                    title.style.setProperty('background-color', '#007BFF', 'important');

                    const submittedContainer = document.getElementById('submitted_document_container');
                    submittedContainer.innerHTML = '';

                    if(monitor.submitted_files && monitor.submitted_files.length > 0){
                        monitor.submitted_files.forEach(file => {
                            let extension = file.split('.').pop().toLowerCase();
                            let fileUrl = `/journals/${file}`; // adjust folder path
                            
                            let attachmentHTML = '';
                            
                            if(['jpg','jpeg','png','gif','bmp','webp'].includes(extension)){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="${fileUrl}" alt="Attachment" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else if(extension === 'pdf'){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_pdf.png" alt="PDF" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else {
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_file.png" alt="File" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            }
                            
                            submittedContainer.insertAdjacentHTML('beforeend', attachmentHTML);
                        });
                    } else {
                        submittedContainer.innerHTML = '<span class="text-muted">No submitted documents found.</span>';
                    }
                    
                    $('#view_submitted_row').show();
                }

                // Reviewed Row (status 1)
                else if(monitor.journal_monitor_status === 1){

                    title.textContent = 'Reviewed';
                    title.style.setProperty('background-color', '#FFA500', 'important');

                    const reviewedContainer = document.getElementById('reviewed_document_container');
                    reviewedContainer.innerHTML = '';
                    
                    if(monitor.reviewed_files && monitor.reviewed_files.length > 0){
                        monitor.reviewed_files.forEach(file => {
                            let extension = file.split('.').pop().toLowerCase();
                            let fileUrl = `/reviewed_journals/${file}`; // adjust folder path
                            
                            let attachmentHTML = '';
                            
                            if(['jpg','jpeg','png','gif','bmp','webp'].includes(extension)){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="${fileUrl}" alt="Attachment" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else if(extension === 'pdf'){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_pdf.png" alt="PDF" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else {
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_file.png" alt="File" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            }
                            
                            reviewedContainer.insertAdjacentHTML('beforeend', attachmentHTML);
                        });
                    } else {
                        reviewedContainer.innerHTML = '<span class="text-muted">No reviewed documents found.</span>';
                    }

                    $('#view_reviewed_comments').html(monitor.reviewer_comment ?? '-');

                    $('#view_reviewed_row').show();
                }

                // Rejected Row (status 2)
                else if(monitor.journal_monitor_status === 2){

                    title.textContent = 'Rejected';
                    title.style.setProperty('background-color', '#DC3545', 'important');

                    $('#view_rejected_reason').html(monitor.rejected_reason ?? '-');
                    $('#view_rejected_row').show();
                }

                // Published Row (status 5)
                else if(monitor.journal_monitor_status === 5){

                    title.textContent = 'Published';
                    title.style.setProperty('background-color', '#17A2B8', 'important');

                    $('#view_published_paper').html(monitor.journal_monitor_paper);
                    $('#view_published_author').html(monitor.author_name ?? '-');
                    $('#view_published_url').attr('href', monitor.published_url ?? '#');
                    $('#view_published_desc').html(monitor.published_desc ?? '-');

                    const publishedContainer = document.getElementById('published_documents_container');
                    publishedContainer.innerHTML = '';

                    if(monitor.uploaded_files && monitor.uploaded_files.length > 0){
                        monitor.uploaded_files.forEach(file => {
                            let extension = file.split('.').pop().toLowerCase();
                            let fileUrl = `/published_journals/${file}`;

                            let attachmentHTML = '';

                            if(['jpg','jpeg','png','gif','bmp','webp'].includes(extension)){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="${fileUrl}" alt="Attachment" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else if(extension === 'pdf'){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_pdf.png" alt="PDF" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else {
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_file.png" alt="File" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            }

                            publishedContainer.insertAdjacentHTML('beforeend', attachmentHTML);
                        });
                    } else {
                        publishedContainer.innerHTML = '<span class="text-muted">No attachments found.</span>';
                    }

                    // Date formatting function
                    function formatDate(dateString) {
                        if (!dateString) return '-';
                        const options = { day: '2-digit', month: 'short', year: 'numeric' };
                        const date = new Date(dateString);
                        // format: 19-Jun-2025
                        return date.toLocaleDateString('en-GB', options).replace(/ /g, '-');
                    }

                    const formattedDate = formatDate(monitor.published_date);
                    $('#view_published_date').html(formattedDate);

                    $('#view_published_row').show();
                }

                
                else if(monitor.journal_monitor_status === 3){
                    title.textContent = 'Resubmitted';
                    title.style.setProperty('background-color', '#800080', 'important');
                }
                
                else if(monitor.journal_monitor_status === 4){
                    title.textContent = 'Accepted';
                    title.style.setProperty('background-color', '#28A745', 'important');
                }

            } else {
                console.log('Data Not Fetched !');
            }
        })
        .catch(error => {
            console.log('Error Fetching Data :', error);
        });
    }
</script>
@endsection