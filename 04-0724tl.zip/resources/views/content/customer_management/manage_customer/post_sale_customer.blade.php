@extends('layouts/layoutMaster')

@section('title', 'Manage Customer')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
    .customer_table thead th,
    .customer_table tbody td {
        padding: 8px !important;
    }

    .indv_cust_serv thead th,
    .indv_cust_serv tbody td {
        padding: 8px !important;
        border: 1px solid rgb(180, 180, 180) !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>
 @php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ?? 16;
    $user_data=$helper->get_staff_data($user_id);
    @endphp
<!-- Customer List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Post Sale Customer</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center flex-wrap">
                <!-- <a href="javascript:;" class="btn btn-sm fw-bold text-white btn-primary me-2 mb-2" title="Export">
                    <i class="mdi mdi-calendar-export-outline"></i>
                </a>
                <a href="javascript:;" class="btn btn-sm fw-bold text-white btn-primary me-2 mb-2" id="filter" title="Filter">
                    <i class="mdi mdi-filter-outline text-center"></i>
                </a> -->
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="filter_tbox" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Customer ID</label>
                    <input type="text" class="form-control" placeholder="Enter Customer ID" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Priya</option>
                        <option value="2">Iniya</option>
                        <option value="3">Sabana</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Gender</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Male</option>
                        <option value="2">Female</option>
                        <option value="3">Others</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Mobile No</label>
                    <input type="text" class="form-control" placeholder="Enter Mobile No" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Course Type</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Professional</option>
                        <option value="2">Tesbo</option>
                        <option value="3">Slash</option>
                        <option value="4">Classic</option>
                        <option value="5">Crash</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Course</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Python For Data Science</option>
                        <option value="2">Core Java</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Batch</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Batch 1</option>
                        <option value="2">Batch 2</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Slot</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Morning Slot</option>
                        <option value="2">Evening Slot</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Slot Type</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Weekday Slot</option>
                        <option value="2">Weekend Slot</option>
                        <option value="3">Alternate Slot</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                <button class="btn btn-secondary btn-sm me-3 waves-effect waves-light">Reset</button>
                <a href="javascript:;" class="btn btn-primary btn-sm waves-effect waves-light">Go</a>
            </div>
        </div>
        <div class="d-flex justify-content-between align-items-center">
            <div class="mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div>
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
            </div>
            <div class="">
                <form id="search_form" method="POST" action="/post_sale_customer">
                @csrf
                <div class="d-flex align-items-center gap-2">
                    <div class="mb-1">
                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                    <input type="hidden" name="filter_on" value="1">
                    <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                    <input
                        type="text"
                        class="form-control"
                        id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                        placeholder="Enter Customer - Name/Mob/Email/INV"
                    />
                    </div>
                    
                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mb-1" onclick="search_filter_func()">Search</button>
                    <a href="{{ url('/post_sale_customer') }}" type="button"
                            class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span class="mdi mdi-refresh fs-6"></span>
                        </a>
                </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <!-- <div class="table-responsive"> -->
                <table class="table align-middle table-row-dashed gy-1 gs-2 customer_table">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th style="min-width: 35% !important;max-width: 35% !important;">Customer</th>
                            <th style="min-width: 10% !important;max-width: 10% !important;" class="text-center">Services</th>
                            <th style="min-width: 20% !important;max-width: 20% !important;">Mobile / Email ID</th>
                            <th style="min-width: 10% !important;max-width: 10% !important;">Currency Format</th>
                            <th style="min-width: 25% !important;max-width: 25% !important;">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                          @if(isset($customers))
                           @foreach($customers as $i => $list)
                           @php
                                $encryptedValue = $helper->encrypt_decrypt($list->sno,'encrypt',);
                                $create_invoice_url = url('/manage_customer/customer_invoice/' . $encryptedValue,);
                                $view_url = url('/manage_customer/customer_view/' . $encryptedValue,);
                                  $new_service_url = url('/add_new_services/' . $encryptedValue,);
                            @endphp
                            <tr id="indv_cust_hd_{{$i}}">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="me-2 cursor-pointer">
                                            <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-2 py-2" onclick="indv_cust_func('{{$i}}');">
                                                <i class="mdi mdi-plus fs-4" id="indv_cust_{{$i}}_plus_btton"></i>
                                            </a>
                                        </div>
                                        <div class="mb-1">
                                            <label class="text-black fw-semibold fs-7 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="{{$list->cus_name}}">{{$list->cus_name}}</label>
                                             @if($list->status ==1)
                                            <label class="badge bg-danger border border-gray-300 rounded fw-semibold text-white fs-7 ms-3 mb-1">Waiting for Payment Approval</label>
                                            @endif
                                            <div class="d-block">
                                                <div class="text-info fw-semibold fs-8 mt-n1">{{$list->customer_id}}</div>
                                            </div>
                                           
                                        </div>
                                       
                                    </div>
                                </td>
                                <td class="text-center">
                                    <label class="badge bg-warning text-black fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Current Services">{{count($list->proposal_data)}}</label>
                                    <label class="badge bg-success fw-semibold fs-7 ms-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed Services">{{count($list->completed_proposal)}}</label>
                                </td>
                                <td>
                                    @if($list->cus_mobile)
                                    <div class="text-black fw-semibold fs-7">
                                        <label>( +{{$list->country_code}} )</label>
                                        <label>{{$list->cus_mobile}}</label>
                                    </div>
                                    @endif
                                    @if($list->cus_email_id)
                                    <div class="d-block mt-n1">
                                        <div class="text-dark fw-semibold fs-8 break-all">{{$list->cus_email_id}}</div>
                                    </div>
                                    @endif
                                </td>
                                <td>
                                    <label class="text-black fw-semibold fs-7">{{$list->currency_symbol}}</label>
                                    <label class="text-black fw-semibold fs-7 ms-2 me-2">-</label>
                                    <label class="text-black fw-semibold fs-7">{{$list->currency_code}} </label>
                                    <div class="d-block mt-n1">
                                        <div class="text-dark fw-semibold fs-8">{{$list->currency_country_name}}</div>
                                    </div>
                                </td>
                                <td>
                                    <span class="text-end">
                                        <a href="{{$view_url}}" class="text-black fw-bold me-3">
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3"></i></span>
                                        </a>
                                     
                                    </span>
                                </td>
                            </tr>
                            <tr id="indv_cust_{{$i}}_tbox" style="display:none;background-color: #efffdd52;">
                                <td colspan="5">
                                    <table class="table align-top gy-1 gs-2 indv_cust_serv">
                                        <thead>
                                            <tr class="text-start align-top fs-6 gs-0">
                                                <th class="min-w-50px text-black fw-semibold text-center">S.No</th>
                                                <th class="min-w-150px text-black fw-semibold">Services</th>
                                                <th class="min-w-200px text-black fw-semibold">Slots</th>
                                                <th class="min-w-100px text-black text-center fw-semibold">Durations</th>
                                                <th class="min-w-100px text-black text-center fw-semibold">Total Amt</th>
                                                <th class="min-w-100px text-black text-center fw-semibold">Paid Amt</th>
                                                <th class="min-w-100px text-black text-center fw-semibold">Balance Amt</th>
                                                <th class="min-w-100px text-black fw-semibold">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                            @if(isset($list->proposal_data))
                                            @foreach($list->proposal_data as $indxPr=> $proposal)
                                            @php
                                                $rowspan = ($proposal->product_package == 1 && isset($proposal->services)) 
                                                    ? count($proposal->services) 
                                                    : 1;
                                                    $percentage = $helper->completed_service_percentage($proposal->customer_service_id);
                                            @endphp
                                            @if($proposal->product_package==2)
                                            <tr>
                                                <td align="center">{{$indxPr+1}}</td>
                                                <td>
                                                    <div class="mb-0">
                                                        <label class="fs-7">{{$proposal->package_name}}</label>
                                                    </div>
                                                    @php
                                                        $domain_names = $helper->get_domain_by_proposalId($proposal->sno);
                                                    @endphp
                                                    @if($indxPr == 0)
                                                        @if($domain_names && count($domain_names) > 0)
                                                            <div class="d-flex flex-wrap gap-1 mt-1">
                                                                @foreach($domain_names as $domain)
                                                                    <span class="badge bg-info text-white fs-7 fw-bold">{{ $domain }}</span>
                                                                @endforeach
                                                            </div>
                                                        @endif
                                                    @endif


                                                </td>
                                                <td>
                                                    @if(isset($proposal->package_slot))
                                                        @foreach($proposal->package_slot as $iSlt=>$slot)
                                                            <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                <div class="mb-0 text-dark fs-7">Milestone {{$iSlt+1}}</div>
                                                                <div class="mb-0">
                                                                    <label class="fw-semibold fs-7 text-black">&#8377; {{$slot->payable_amount}}</label>
                                                                    @if($slot->paid_status == 1)
                                                                    <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount Paid">
                                                                        <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                            <g id="SVGRepo_iconCarrier">
                                                                                <defs>
                                                                                    <style>
                                                                                        .cls-1 {
                                                                                            fill: #699f4c;
                                                                                            fill-rule: evenodd;
                                                                                        }
                                                                                    </style>
                                                                                </defs>
                                                                                <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                            </g>
                                                                        </svg>
                                                                    </label>
                                                                    @else
                                                                    <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Amount Not Paid" data-bs-original-title="Amount Not Paid">
                                                                        <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                            <g id="SVGRepo_iconCarrier">
                                                                                <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                                <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                            </g>
                                                                        </svg>
                                                                    </label>
                                                                    @endif
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                        @endif
                                                </td>
                                                <td align="center">
                                                    <label class="badge bg-label-warning border border-gray-300 rounded fw-semibold text-black fs-7">{{$proposal->delivery_duration}} Days</label>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">₹ {{$proposal->total_amount}}</label>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">₹ {{$proposal->product_slots_paid}}</label>
                                                </td>
                                                <td align="right">
                                                    <label class="fw-semibold text-black fs-7">₹ {{$proposal->total_amount - $proposal->product_slots_paid}}</label>
                                                </td>
                                                <td>
                                                    <div class="badge bg-info text-black mb-1 fs-7 fw-semibold" style="background-color: #fea500 !important;">Service In Progress</div>
                                                    <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Service Progress : {{$percentage}}%">
                                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: {{$percentage}}%" aria-valuenow="{{$percentage}}" aria-valuemin="0" aria-valuemax="100">{{$percentage}}%</div>
                                                    </div>
                                                </td>
                                            </tr>
                                            @else
                                            @foreach($proposal->services as $indxSr => $service)
                                                @php
                                                    $slotCount = count($proposal->product_slot);
                                                    $servicesCount = count($proposal->services);
                                                @endphp

                                                @foreach($proposal->product_slot as $slotIndex => $slot)
                                                    <tr>
                                                        @if($slotIndex === 0)
                                                            <td align="center" rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">{{ $indxSr == 0 ? $indxPr + 1 :'' }}</td>
                                                            <td rowspan="{{ $slotCount }}">
                                                                <div class="mb-0">
                                                                    <label class="fs-7">{{ $service->product_name }}</label>
                                                                    <div class="d-block text-dark fs-8">{{ $service->product_category_name }}</div>
                                                                </div>
                                                                
                                                                @php
                                                                    $domain_names = $helper->get_domain_by_proposalId($service->proposal_id);
                                                                @endphp
                                                                @if($indxSr == 0)
                                                                    @if($domain_names && count($domain_names) > 0)
                                                                        <div class="d-flex flex-wrap gap-1 mt-1">
                                                                            @foreach($domain_names as $domain)
                                                                                <span class="badge bg-info text-white fs-7 fw-bold">{{ $domain }}</span>
                                                                            @endforeach
                                                                        </div>
                                                                    @endif
                                                                @endif
                                                                
                                                            </td>
                                                        @endif

                                                        <td style="{{ ( $slotCount - 1 == $slotIndex) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                            <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                                <div class="mb-0 text-dark fs-7">{{$slot->payment_slot_name}}</div>
                                                                <div class="mb-0">
                                                                    <label class="fw-semibold fs-7 text-black">₹ {{ number_format($slot->slot_amount) }}</label>
                                                                    @if($slot->paid_status == 1)
                                                                    <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Amount Paid">
                                                                        <svg height="18px" width="18px" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" fill="#000000" style="margin-left: 3px !important;">
                                                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                            <g id="SVGRepo_iconCarrier">
                                                                                <defs>
                                                                                    <style>
                                                                                        .cls-1 {
                                                                                            fill: #699f4c;
                                                                                            fill-rule: evenodd;
                                                                                        }
                                                                                    </style>
                                                                                </defs>
                                                                                <path class="cls-1" d="M800,510a30,30,0,1,1,30-30A30,30,0,0,1,800,510Zm-16.986-23.235a3.484,3.484,0,0,1,0-4.9l1.766-1.756a3.185,3.185,0,0,1,4.574.051l3.12,3.237a1.592,1.592,0,0,0,2.311,0l15.9-16.39a3.187,3.187,0,0,1,4.6-.027L817,468.714a3.482,3.482,0,0,1,0,4.846l-21.109,21.451a3.185,3.185,0,0,1-4.552.03Z" id="check" transform="translate(-770 -450)"></path>
                                                                            </g>
                                                                        </svg>
                                                                    </label>
                                                                    @else
                                                                    <label class="text-end" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Amount Not Paid" data-bs-original-title="Amount Not Paid">
                                                                        <svg height="21px" width="21px" fill="#000000" viewBox="0 0 24 24" id="cross-circle" data-name="Flat Color" xmlns="http://www.w3.org/2000/svg" class="icon flat-color">
                                                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                                            <g id="SVGRepo_iconCarrier">
                                                                                <circle id="primary" cx="12" cy="12" r="10" style="fill: #ff0000;"></circle>
                                                                                <path id="secondary" d="M13.41,12l2.3-2.29a1,1,0,0,0-1.42-1.42L12,10.59,9.71,8.29A1,1,0,0,0,8.29,9.71L10.59,12l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l2.29,2.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" style="fill: #ffffff;"></path>
                                                                            </g>
                                                                        </svg>
                                                                    </label>
                                                                    @endif
                                                                </div>
                                                            </div>
                                                        </td>

                                                        @if($slotIndex === 0 )
                                                            <td align="center" rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                                @if($indxSr == 0)
                                                                <label class="badge bg-label-warning border border-gray-300 rounded fw-semibold text-black fs-7">{{$proposal->delivery_duration}} Days</label>
                                                                @endif
                                                            </td>
                                                            <td align="right" rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                                 @if($indxSr == 0)
                                                                <label class="fw-semibold text-black fs-7">₹ {{$proposal->total_amount}}</label>
                                                                @endif
                                                            </td>
                                                            <td align="right" rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                                 @if($indxSr == 0)
                                                                <label class="fw-semibold text-black fs-7">₹ {{$proposal->product_slots_paid}}</label>
                                                                @endif
                                                            </td>
                                                            <td align="right" rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                                 @if($indxSr == 0)
                                                                <label class="fw-semibold text-black fs-7">₹ {{$proposal->total_amount - $proposal->product_slots_paid}}</label>
                                                                @endif
                                                            </td>
                                                            <td rowspan="{{ $slotCount }}" style="{{ ($servicesCount - 1 == $indxSr) ? '' : 'border-bottom-style: hidden !important;' }}">
                                                                 @if($indxSr == 0)
                                                                    @if($list->status==1)
                                                                        <div class="badge bg-danger text-white mb-1 fs-7 fw-semibold">Waiting for Payment Approval</div>
                                                                        
                                                                    @elseif($list->status ==0)
                                                                     <div class="badge bg-info text-black mb-1 fs-7 fw-semibold" style="background-color: #fea500 !important;">Service In Progress</div>
                                                                        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Service Progress : {{$percentage}}%">
                                                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: {{$percentage}}%" aria-valuenow="{{$percentage}}" aria-valuemin="0" aria-valuemax="100">{{$percentage}}%</div>
                                                                        </div>
                                                                    @else
                                                                        <div class="badge bg-success text-white mb-1 fs-7 fw-semibold" style="background-color: #117A65 !important;">Delivered</div>
                                                                        <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px" data-bs-toggle="tooltip" title="Service Progress : 100%">
                                                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: 100%">100%</div>
                                                                        </div>
                                                                    @endif
                                                                @endif
                                                            </td>
                                                        @endif
                                                    </tr>
                                                @endforeach
                                            @endforeach
                                            @endif
                                            @endforeach
                                            @endif
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                                            
                         @endforeach
                         @endif
                    </tbody>
                </table>
                <!-- </div> -->
            </div>
            <div class="mt-4">
                {{ $customers->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Delete Customer-->
<div class="modal fade" id="kt_modal_delete_customer" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                delete Customer ?
                <!-- <div class="d-block fw-bold fs-5 py-2">
                    <label>Priya</label>
                    <span class="ms-2 me-2">-</span>
                    <label>EACUS-0001/24</label>
                </div> -->
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Customer-->

<!--begin::Modal - Add Service-->
<div class="modal fade" id="kt_modal_add_service" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Add Service</h3>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-12 mt-4">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="quotation" name="quotation" onclick="quotation_sts_func();" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Generate Quotation</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="invoice" name="quotation" onclick="invoice_sts_func();" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Generate Invoice</label>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4" id="quotation_tbox" style="display: none!important;">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="/manage_proposal/proposal_add" target="_blank" class="btn btn-primary">Create Quotation</a>
                    </div>
                    <!-- <div class="d-flex justify-content-center align-items-center mt-4" id="invoice_tbox" style="display: none!important;">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="/manage_proposal/proposal_add" target="_blank" class="btn btn-primary">Create Invoice</a>
                    </div> -->
                </div>

            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Service-->

<!--begin::Modal - Update Requirements-->
<div class="modal fade" id="kt_modal_customer_requirements" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Update Requirments</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6 mb-1">
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-semibold break-all">Priya</label>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-1">
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-semibold">+91 9876543210</label>
                        </div>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-lg-12 mb-1">
                        <label class="text-black mb-1 fs-6 fw-semibold">Services<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Services</option>
                            <option value="1">Thesis Writing ( Writing Products )</option>
                            <option value="2">Technical Research and Development Services ( Developement Products )</option>
                            <option value="2">Formatting and Referencing ( Developement Products )</option>
                        </select>
                    </div>
                </div>
                <div class="form-repeater_reqts mt-3">
                    <div data-repeater-list="group-a_led_question">
                        <div data-repeater-item>
                            <div class="row mt-2">
                                <div class="col-lg-7 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Requirements 1<span class="text-danger">*</span></label>
                                    <textarea class="form-control" rows="3" placeholder="Enter Requirements 1"></textarea>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Attachments</label>
                                    <div class="d-flex align-items-sm-center">
                                        <img src="{{asset('assets/phdizone_images/Document.jpg')}}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo" />
                                        <div class="ms-1 button-wrapper">
                                            <div class="d-flex align-items-start mt-2 mb-2">
                                                <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Logo">
                                                    <i class="mdi mdi-tray-arrow-up"></i>
                                                    <input type="file" id="upload" class="file-in" hidden accept="image/png, image/jpeg" />
                                                </label>
                                                <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Logo">
                                                    <i class="mdi mdi-reload"></i>
                                                </button>
                                            </div>
                                            <div class="small fs-8">Allowed JPG, PNG, PDF, CSV. Max size of 5MB</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_reqts_del" id="staff_reqts_del" style="display: none !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-1 mt-1">
                    <button class="btn btn-sm btn-primary staff_reqts_add px-2 py-1" data-repeater-create id="staff_reqts_add">
                        <i class="mdi mdi-plus me-1"></i>Add More
                    </button>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="javascript:;" class="btn btn-primary me-3" data-bs-dismiss="modal">Update Requirments</a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Assign Requirements- -->

<!--begin::Modal - Update Customer-->
<div class="modal fade" id="kt_modal_customer_edit" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Customer</h3>
                </div>
                <form id="leadEditForm" action="{{route('customer-management-update-customer')}}" method="POST" novalidate autocomplete="off">
                    @csrf
                    <input type="hidden" id="lead_id_edit" name="edit_id">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Lead Name" id="lead_name_edit"
                                name="edit_cus_name"
                                oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                            <div class="text-danger" id="lead_name_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold d-block">Gender<span
                                    class="text-danger">*</span></label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="edit_cus_gender" id="inlineRadio1edit"
                                    value="1" checked />
                                <label class="form-check-label" for="inlineRadio1edit">Male</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="edit_cus_gender" id="inlineRadio2edit"
                                    value="2" />
                                <label class="form-check-label" for="inlineRadio2edit">Female</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="edit_cus_gender" id="inlineRadio3edit"
                                    value="3" />
                                <label class="form-check-label" for="inlineRadio3edit">Others</label>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Date of Birth</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="lead_dob_up" name="edit_cus_dob" placeholder="Select Date"
                                    class="form-control">

                            </div>
                            <div class="text-danger" id="lead_dob_up_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <div class="mb-1">
                                <input class="form-check-input" type="checkbox" id="mobile_no_chk_edit" value="1"
                                    name="mobile_check" onclick="mobile_no_func_edit();" />
                                <label class="text-black fs-6 fw-semibold">Mobile Number<span class="text-danger"
                                        style="display: none ;" id="mob_req_edit">*</span></label>
                            </div>
                            <div id="mob_no_edit" style="display: none ;">
                                <div class="input-group">
                                    <button class="btn btn-outline-primary dropdown-toggle border border-gray-400i"
                                        type="button" data-bs-toggle="dropdown" aria-expanded="false"
                                        id="countryDropdownButton_edit" name="countryDropdownButton">IN - +91</button>
                                    <ul class="dropdown-menu" id="countryDropdownMenu_edit"
                                        name="countryDropdownMenu_edit" style="max-height: 250px; overflow-y: auto;">
                                        <li>
                                            <input type="text" id="countrySearch_edit" name="countrySearch"
                                                class="form-control border-1" placeholder="Search Country/Code"
                                                style="width: 100%; border: none; padding: 5px;">
                                        </li>
                                    </ul>
                                    <input type="text" class="form-control" id="lead_mobile_edit" name="cus_edit_mobile"
                                        maxlength="10" onkeyup="mobile_chk_edit(this.value)"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                        placeholder="Enter Mobile Number">
                                    <input type="hidden" id="country_code_name_edit" name="country_code_name_edit"
                                        value="91">
                                </div>
                            </div>

                            <div class="text-danger" id="lead_mobile_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <div class="mb-1">
                                <input class="form-check-input" type="checkbox" id="email_chk_edit" value="1"
                                    name="email_check" onclick="email_func_edit();" />
                                <label class="text-black fs-6 fw-semibold">Email ID<span class="text-danger"
                                        style="display: none ;" id="email_req_edit">*</span></label>
                            </div>
                            <div id="email_tbox_edit" style="display: none ;">
                                <input type="text" class="form-control me-2" placeholder="Enter Email ID"
                                    name="edit_cus_email" id="lead_email_edit" onkeyup="email_chk_edit(this.value)"
                                    oninput=" this.value = this.value.toLowerCase();" />
                            </div>
                            <div class="text-danger" id="lead_email_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                            <input type="text" class="form-control me-2" id="lead_alternate_edit"
                                placeholder="Enter Alternate Mobile Number" name="cus_edit_alt_mobile" maxlength="10"
                                oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country</label>
                            <select class="select3 form-select" id="country_id_edit" name="country_edit">
                                <option value="">Select Country</option>
                            </select>
                            <div class="text-danger" id="country_id_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State</label>
                            <select class="select3 form-select" id="state_edit" name="state_edit">
                                <option value="">Select State</option>

                            </select>
                            <div class="text-danger" id="state_edit_err"></div>

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City</label>
                            <select class="select3 form-select" id="city_edit" name="city_edit">
                                <option value="">Select City</option>

                            </select>
                            <div class="text-danger" id="city_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door No / Flat No</label>
                            <input type="text" class="form-control me-2" id="lead_door_no_edit" name="door_no"
                                placeholder="Enter Door No / Flat No">
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street</label>
                            <input type="text" class="form-control me-2" id="lead_address_edit" name="address"
                                placeholder="Enter Area / Street" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode</label>
                            <input type="text" class="form-control me-2" id="lead_pincode_edit" name="pincode"
                                placeholder="Enter Pincode">
                        </div>
                     </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="submit_lead_edit"
                            onclick="EditvalidateForm()">Update Country</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Customer-->

<!--begin::Modal - Customer Credential -->
<div class="modal fade" id="kt_modal_customer_credential" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Pass Locker</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                        <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                            id="customer_credential_name"></div>
                    </div>
                    <div class="col-lg-12 mb-3" id="cus_cred_cont">
                        <label class="text-black mb-1 fs-6 fw-semibold" id="customer_cred_num">Phone Number</label>
                        <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                            id="customer_credential_number"></div>
                    </div>

                    <div class="col-lg-12 mt-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Created Credentials</label>
                    </div>
                    <!-- Credential Header -->
                    <div class="credential-header rounded-top px-3 pt-3 pb-2 mt-2 bg-success text-white fw-semibold">
                        <div class="row">
                            <div class="col-lg-3 mb-1">Type</div>
                            <div class="col-lg-3 mb-1">Link</div>
                            <div class="col-lg-3 mb-1">User Name</div>
                            <div class="col-lg-3 mb-1">Password</div>
                        </div>
                    </div>

                    <!-- Credential List -->
                    <div class="scroll-y border border-secondary-subtle px-3 pt-2 mb-4 bg-white rounded-bottom">
                        <div id="credentialContainer"></div>
                    </div>
                </div>
                <form action="{{ route('add_customer_credentials') }}" method="POST" id="add_customer_credentials">
                    @csrf
                    <input type="hidden" name="customer_id" id="customer_id">
                    <div class=" px-3 pt-2 mt-4 mb-4">
                        <div class="form-repeater_jorn_bklt_create">
                            <div data-repeater-list="group-a_jorn_bklt">
                                <div data-repeater-item>
                                    <div class="row booklet_row border border-gray-300i pt-2">
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Type<span
                                                    class="text-danger">*</span></label>
                                            <select class="select3 form-select type_id" name="type[]" id="">
                                                <option value="">Select Type</option>
                                                @foreach ($types as $type)
                                                <option value="{{ $type->sno }}">{{ $type->type_name }}</option>
                                                @endforeach
                                            </select>
                                            <p class="text-danger mt-1 type_error"></P>
                                        </div>
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Link<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control journal_link"
                                                placeholder="Enter Link" name="link[]" />
                                            <p class="text-danger mt-1 link_error"></p>
                                        </div>
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control journal_email"
                                                placeholder="Enter Email ID" name="email[]" />
                                            <p class="text-danger mt-1 email_error"></p>
                                        </div>
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control journal_pass"
                                                placeholder="Enter Password" name="password[]" />
                                            <p class="text-danger mt-1 pass_error"></p>
                                        </div>
                                        <div class="col-lg-2 mb-1">
                                            <a href="javascript:;"
                                                class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_create_del"
                                                id="jorn_bklt_create_del" style="display: none !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="bookletContainer"></div>
                    </div>
                    <div class="mb-4 mt-1">
                        <button type="button" class="btn btn-sm btn-primary jorn_bklt_create_add fs-8 px-2 py-1"
                            data-repeater-create id="jorn_bklt_create_add">
                            <i class="mdi mdi-plus me-1"></i> Add More
                        </button>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-8">
                        <button type="submit" class="btn btn-primary">Add</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Customer Credential-->


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
</style>

<script>
  function sort_filter(val) {
    if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#search_form').submit();
    } else {
      $('.sorting_filter_class').val(10);
      $('#search_form').submit();
    }
  }
</script>


<script>
    let logofile = document.getElementById('uploadedlogo');
    const fileInput = document.querySelector('.file-in'),
        resetFileInput = document.querySelector('.file-reset');

    if (logofile) {
        const resetImage = logofile.src;
        fileInput.onchange = () => {
            if (fileInput.files[0]) {
                logofile.src = window.URL.createObjectURL(fileInput.files[0]);
            }
        };
        resetFileInput.onclick = () => {
            fileInput.value = '';
            logofile.src = resetImage;
        };
    }
</script>
<script>
    $('.staff_reqts_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_reqts').length);
        let $clone = $('.form-repeater_reqts').first().clone().hide();
        $clone.insertBefore('.form-repeater_reqts:first').slideDown();
        if (bt == 1) {
            $('.staff_reqts_del').attr('style', 'display: block !important');
        } else {
            $('.staff_reqts_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_reqts .staff_reqts_del', e => {
        var bt = parseFloat($('.staff_reqts_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_reqts').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.staff_reqts_del').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    function indv_cust_func(val) {

     
            const tbox = document.getElementById(`indv_cust_${val}_tbox`);
            const button = document.getElementById(`indv_cust_${val}_plus_btton`);
            const header = document.getElementById(`indv_cust_hd_${val}`);

            if (tbox.style.display === "none" || tbox.style.display === "") {
                const isVisible = tbox.style.display === "table-row";

                // Toggle: if visible, hide; else show
                tbox.style.display = isVisible ? "none" : "table-row";
                button.classList.toggle("mdi-minus", !isVisible);
                button.classList.toggle("mdi-plus", isVisible);
                header.style.backgroundColor = isVisible ? "" : "#f9f3c5db";
            } else {
                // Hide all other rows
                tbox.style.display = "none";
                button.classList.remove("mdi-minus");
                button.classList.add("mdi-plus");
                header.removeAttribute("style");
            }
       
    }
</script>
<script>
    function quotation_sts_func() {
        var quotation = document.getElementById('quotation');
        var quotation_tbox = document.getElementById('quotation_tbox');
        var invoice = document.getElementById('invoice');
        var invoice_tbox = document.getElementById('invoice_tbox');
        if (quotation.click) {
            document.getElementById("quotation_tbox").style.display = "block";
            document.getElementById("invoice_tbox").style.display = "none";
        } else {

        }
    }
</script>
<script>
    function invoice_sts_func() {
        var quotation = document.getElementById('quotation');
        var quotation_tbox = document.getElementById('quotation_tbox');
        var invoice = document.getElementById('invoice');
        var invoice_tbox = document.getElementById('invoice_tbox');
        if (invoice.click) {
            document.getElementById("invoice").style.display = "block";
            document.getElementById("quotation_tbox").style.display = "none";
        } else {

        }

    }
</script>
<script>
    function fsc_sts_func(val) {

        if (val == "reject") {
            document.getElementById("rejct_tbox").style.display = "block";
            document.getElementById("smt_butt").innerHTML = "Create Invoice";
        } else if (val == "accept") {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Create Quotation";

        } else {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Create Invoice";
        }
    }
</script>

<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
{{-- Fetch Edit --}}
<script>

    $(document).ready(function() {
            var selectedCountryId = null;
            var selectedStateId = null;
            var selectedCityId = null;
            
            
            // Fetch and populate countries for Add
            $.ajax({
                url: "{{ route('country') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('select[name="country"]');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Country</option>');
                        response.data.forEach(function(country) {
                            countryDropdown.append($('<option></option>').attr('value', country.id).text(country.name));
                        });
                        countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change

                        $('select[name="country"]').val({{ $login_branch_data->country_id ?? 0 }}).change();
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });

            // Event listener for country change for Add
            $('select[name="country"]').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('select[name="state"]');
                var cityDropdown = $('select[name="city"]');

                stateDropdown.empty().append('<option value="">Select State</option>');
                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country for Add
                    $.ajax({
                        url: "{{ route('state') }}",
                        type: "GET",
                        data: { country_id: countryId },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                                });
                                stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change

                                $('select[name="state"]').val({{ $login_branch_data->state_id ?? 0}}).change();
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });

            // Event listener for state change for Add
            $('select[name="state"]').on('change', function() {
                var stateId = $(this).val();
                var countryId = $('select[name="country"]').val();
                var cityDropdown = $('select[name="city"]');

                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId && stateId) {
                    // Fetch and populate cities based on selected state and country for Add
                    $.ajax({
                        url: "{{ route('city') }}",
                        type: "GET",
                        data: { country_id: countryId, state_id: stateId },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(city) {
                                    cityDropdown.append($('<option></option>').attr('value', city.id).text(city.name));
                                });
                                cityDropdown.val(selectedCityId); // Set the selected city
                                // console.log('{{ $login_branch_data->city_id ?? 0}}')
                                $('select[name="city"]').val('{{ $login_branch_data->city_id ?? 0}}').change();
                            }

                        },
                        error: function(error) {
                            console.error('Error fetching cities:', error);
                        }
                    });
                }
            });

            // Fetch and populate countries for Edit
            $.ajax({
                url: "{{ route('country') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('select[name="country_edit"]');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Country</option>');
                        response.data.forEach(function(country) {
                            countryDropdown.append($('<option></option>').attr('value', country.id).text(country.name));
                        });
                        countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });


            // Event listener for country change for Edit
            $('select[name="country_edit"]').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('select[name="state_edit"]');
                var cityDropdown = $('select[name="city_edit"]');

                stateDropdown.empty().append('<option value="">Select State</option>');
                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country for Edit
                    $.ajax({
                        url: "{{ route('state') }}",
                        type: "GET",
                        data: { country_id: countryId },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                                });
                                stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });

            // Event listener for state change for Edit
            $('select[name="state_edit"]').on('change', function() {
                var stateId = $(this).val();
                var countryId = $('select[name="country_edit"]').val();
                var cityDropdown = $('select[name="city_edit"]');

                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId && stateId) {
                    // Fetch and populate cities based on selected state and country for Edit
                    $.ajax({
                        url: "{{ route('city') }}",
                        type: "GET",
                        data: { country_id: countryId, state_id: stateId },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(city) {
                                    cityDropdown.append($('<option></option>').attr('value', city.id).text(city.name));
                                });
                                cityDropdown.val(selectedCityId); // Set the selected city
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching cities:', error);
                        }
                    });
                }
            });
            
        });

        function populateEditModal(id) {
            var categoryId = id;
            fetch(`/edit_manage_customer/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const lead = data.data;
        
                        if(lead.cus_mobile){
                            $('#mobile_no_chk_edit').prop('checked',true);
                        }
                            if(lead.cus_email_id){
                            $('#email_chk_edit').prop('checked',true);
                        }
                        // Populate input fields
                        $('#lead_id_edit').val(lead.sno);
                        $('#lead_name_edit').val(lead.cus_name);
                        $('#lead_mobile_edit').val(lead.cus_mobile);
                        $('#lead_alternate_edit').val(lead.cus_alternate_mobile);
                        $('#lead_email_edit').val(lead.cus_email_id);
                        $('#lead_dob_up').val(lead.cus_dob);
                        $('#lead_address_edit').val(lead.address);
                        $('#lead_door_no_edit').val(lead.door_no || '');
                        $('#lead_pincode_edit').val(lead.pincode || '');

                        mobile_no_func_edit()
                        email_func_edit()
                        
        
                        // Initialize country code dropdown and selection
                        const selectedCountryId = lead.country;
                        const selectedStateId = lead.state;
                        const selectedCityId = lead.city;
        
                        // Fetch and populate countries for Edit
                        $.ajax({
                            url: "{{ route('country') }}",
                            type: "GET",
                            success: function(response) {
                                if (response.status === 200 && response.data) {
                                    const countryDropdown = $('#country_id_edit');
                                    countryDropdown.empty().append('<option value="">Select Country</option>');
                                    response.data.forEach(function(country) {
                                        countryDropdown.append($('<option></option>').attr('value', country.id).text(country.name));
                                    });
                                    countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
        
                                    // Fetch and populate states based on selected country
                                    $.ajax({
                                        url: "{{ route('state') }}",
                                        type: "GET",
                                        data: { country_id: selectedCountryId },
                                        success: function(response) {
                                            if (response.status === 200 && response.data) {
                                                const stateDropdown = $('#state_edit');
                                                stateDropdown.empty().append('<option value="">Select State</option>');
                                                response.data.forEach(function(state) {
                                                    stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                                                });
                                                stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
        
                                                // Fetch and populate cities based on selected state
                                                $.ajax({
                                                    url: "{{ route('city') }}",
                                                    type: "GET",
                                                    data: { country_id: selectedCountryId, state_id: selectedStateId },
                                                    success: function(response) {
                                                        if (response.status === 200 && response.data) {
                                                            const cityDropdown = $('#city_edit');
                                                            cityDropdown.empty().append('<option value="">Select City</option>');
                                                            response.data.forEach(function(city) {
                                                                cityDropdown.append($('<option></option>').attr('value', city.id).text(city.name));
                                                            });
                                                            cityDropdown.val(selectedCityId); // Set the selected city
                                                        }
                                                    },
                                                    error: function(error) {
                                                        console.error('Error fetching cities:', error);
                                                    }
                                                });
                                            }
                                        },
                                        error: function(error) {
                                            console.error('Error fetching states:', error);
                                        }
                                    });
                                }
                            },
                            error: function(error) {
                                console.error('Error fetching countries:', error);
                            }
                        });
        
                        var country_code = $('#country_code_name_edit').val(); 
        
                        $.ajax({
                            url: "{{ route('country') }}", 
                            type: "GET",
                            success: function(response) {
                                if (response.status === 200 && response.data) {
                                    var countryDropdownMenu = $('#countryDropdownMenu_edit');
                                    countryDropdownMenu.empty();
                                    // console.log(response.data);
        
                                    // Add the search input to the dropdown menu
                                    countryDropdownMenu.append('<li><input type="text" id="countrySearch_edit" name="countrySearch_edit" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;"></li>');
        
                                    // Loop through the countries and add them to the dropdown
                                    response.data.forEach(function(country) {
                                        countryDropdownMenu.append(
                                            $('<li></li>').append(
                                                $('<a></a>')
                                                    .addClass('dropdown-item waves-effect')
                                                    .attr('href', 'javascript:void(0);')
                                                    .data('id', country.id)
                                                    .data('phonecode', country.phonecode)
                                                    .text(country.sortname + ' - ' + '+' + country.phonecode) // Display country name and phone code
                                            )
                                        );
                                    });
        
                                    // Pre-select country based on the initial selection (if any)
                                    var selectedCountryId = country_code; 
                                    if(country_code == 0){
                                        country_code = 91;
                                    }
                                    $('#countryDropdownButton_edit').text('+' + country_code);
                                    $('#country_code_name_edit').val(country_code);
                                    
                                    if (selectedCountryId) {
                                        // Find the country matching the phone code
                                        var selectedCountry = response.data.find(function(country) {
                                            return country.phonecode === selectedCountryId;  // Match based on the phone code
                                        });
        
                                        if (selectedCountry) {
                                            // Set the initial country/phone code in the dropdown button
                                            $('#countryDropdownButton_edit').text(selectedCountry.sortname + ' - +' + selectedCountry.phonecode);
                                            $('#country_code_name_edit').val(selectedCountry.phonecode); // Ensure the hidden input gets updated as well
                                            $('#lead_mobile_edit').attr('maxlength', 10); // Set maxlength based on country
                                        }
                                    }
        
                                    // Search functionality
                                    $('#countrySearch_edit').on('input', function() {
                                        var searchValue = $(this).val().toLowerCase();
                                        $('#countryDropdownMenu_edit li a').each(function() {
                                            var countryText = $(this).text().toLowerCase();
                                            if (countryText.indexOf(searchValue) === -1) {
                                                $(this).parent().hide(); // Hide countries that don't match the search term
                                            } else {
                                                $(this).parent().show(); // Show countries that match
                                            }
                                        });
                                    });
                                }
                            },
                            error: function(error) {
                                console.error('Error fetching countries:', error);
                            }
                        });
                        $('#countryDropdownButton_edit').text('+' +country_code);
        
                        $('#countryDropdownMenu_edit').on('click', '.dropdown-item', function() {
                            var countryId = $(this).data('id');
                            var phoneCode = $(this).data('phonecode');
                            var countryName = $(this).text();
        
                            // Update dropdown button text with selected country
                            $('#countryDropdownButton_edit').text(countryName);
                            // Update the country code hidden input
                            $('#country_code_name_edit').val(phoneCode); 
        
                            // Handle max length if needed based on country
                            var selectedCountryId = {{ $login_branch_data->country_id ?? 0 }};
                            if (countryId === selectedCountryId) {
                                $('#lead_mobile_edit').attr('maxlength', 10);  // Set max length for a specific country
                            } else {
                                $('#lead_mobile_edit').removeAttr('maxlength'); // Remove max length if country changes
                            }
                        });
        
        
                        // Gender radio button selection
                        $('input[name="edit_cus_gender"]').prop('checked', false); // Uncheck all
                        if (lead.cus_gender == 1) {
                            $('#inlineRadio1edit').prop('checked', true);
                        } else if (lead.cus_gender == 2) {
                            $('#inlineRadio2edit').prop('checked', true);
                        } else {
                            $('#inlineRadio3edit').prop('checked', true);
                        }                  
        
                    } else {
                        console.error('Error fetching lead data:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching lead data:', error);
                });
        }

</script>

{{-- Date Picker --}}
<script>
    $(document).ready(function() {
    
        $(".common_date_time_class").flatpickr({
            dateFormat: 'Y-m-d', // 12-hour format with AM/PM
            defaultDate: new Date(),
            time_24hr: false // Ensure 12-hour clock
        });
    });
</script>

{{-- Mobile and Email Toggle --}}
<script>
    function mobile_no_func_edit() {
        var mobile_no_chk_edit = document.getElementById("mobile_no_chk_edit");
        var mob_no_edit = document.getElementById("mob_no_edit");
        var mob_req_edit = document.getElementById("mob_req_edit");
        if (mobile_no_chk_edit.checked) {
            mob_no_edit.style.display = "block";
            mob_req_edit.style.display = "inline";
        } else {
            mob_no_edit.style.display = "none";
            mob_req_edit.style.display = "none";
        }
    }

    function email_func_edit() {
        var email_chk_edit = document.getElementById("email_chk_edit");
        var email_tbox_edit = document.getElementById("email_tbox_edit");
        var email_req_edit = document.getElementById("email_req_edit");
        if (email_chk_edit.checked) {
            email_tbox_edit.style.display = "block";
            email_req_edit.style.display = "inline";
        } else {
            email_tbox_edit.style.display = "none";
            email_req_edit.style.display = "none";
        }
    }
</script>

<script>
    function EditvalidateForm() {
        var err = 0;

        // Validate knowledge Name
        var lead_name_edit = document.getElementById("lead_name_edit").value.trim();
        if (lead_name_edit === "") {
            document.getElementById('lead_name_edit_err').innerHTML = 'Customer Name is required...!';
            err++;
        } else {
            document.getElementById('lead_name_edit_err').innerHTML = '';
        }
        
       var mobile_no_chk_edit = document.getElementById("mobile_no_chk_edit");
        var email_chk_edit = document.getElementById("email_chk_edit");
        var lead_mobile_edit = document.getElementById("lead_mobile_edit").value.trim();
        
        if(mobile_no_chk_edit.checked || email_chk_edit.checked){
             document.getElementById('lead_mobile_edit_err').innerHTML = '';
        }else{
             document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile Number or Email Id is Required !';
             err++;
        }
       
       if(mobile_no_chk_edit.checked){

        var countryDropdownMenu = $('#country_code_name_edit');
       
        if(countryDropdownMenu == 'IN - +91'){
            var lead_mobile_edit = document.getElementById("lead_mobile_edit").value.trim();
            var mobilePattern = /^\d{10}$/;

            if (lead_mobile_edit === "") {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number is required...!';

                err++;
            } else if (!mobilePattern.test(lead_mobile_edit)) {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number must be 10 digits...!';

                err++;
            } else {

                document.getElementById('lead_mobile_edit_err').innerHTML = '';
            }
        }else{
            if (lead_mobile_edit === "") {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number is required...!';
                err++;
            }else {
                document.getElementById('lead_mobile_edit_err').innerHTML = '';
            }
        }
          
    
            if (lead_mobile_edit === "") {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number is required...!';
                err++;
            } else {
                document.getElementById('lead_mobile_edit_err').innerHTML = '';
            }
        
       }
        
      
        if(email_chk_edit.checked){

        var lead_email_edit = document.getElementById("lead_email_edit").value.trim();
          if (lead_email_edit === "") {
               document.getElementById('lead_email_edit_err').innerHTML = 'Email is required...!';
               err++;
          } else {
            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/;
            if (filter.test(lead_email_edit)) {
              document.getElementById('lead_email_edit_err').innerHTML = '';
            } else {
              document.getElementById('lead_email_edit_err').innerHTML = 'Enter a valid email address <br> (e.g., lead@gmail.com)..!';
              err++;

            }
          }
        }else{
            document.getElementById('lead_email_edit_err').innerHTML = '';
        }


        if (err === 0) {
            $('#leadEditForm').submit();
            $('#submit_lead_edit').prop('disabled', true);
        } else {
            $('#submit_lead_edit').prop('disabled', false);
        }
    }
</script>
<style>
    .credential-row:hover {
        background-color: #f8f9fa;
        transition: background 0.2s ease;
    }

    .copy-icon,
    .toggle-password {
        cursor: pointer;
        font-size: 1rem;
    }

    .copy-icon:hover,
    .toggle-password:hover {
        color: #007bff;
    }

    .scroll-y {
        max-height: 300px;
        overflow-y: auto;
    }

    .form-control[readonly] {
        background-color: #f1f1f1;
    }
</style>

<script>
    // Renders each credential row with copy/show features
    function createCredentialRow(item) {
        const type = item.status === 1 ? "Journal" : item.type_name;
        const uniqueId = Math.random().toString(36).substring(7);
        
        return `
        <div class="row border-bottom py-2 align-items-center credential-row">
            <div class="col-lg-3">
                <span class="badge bg-primary">${type}</span>
            </div>
        
            <div class="col-lg-3 d-flex align-items-center">
                <span class="d-inline-block text-truncate me-2" style="max-width: 140px;" title="${item.link}">
                    ${item.link}
                </span>
                <i class="mdi mdi-content-copy text-secondary copy-icon ms-1" style="cursor:pointer;" title="Copy Link"
                    data-copy="${item.link}"></i>
            </div>
        
            <div class="col-lg-3 d-flex align-items-center">
                <span class="d-inline-block text-truncate me-2" style="max-width: 140px;" title="${item.user_name}">
                    ${item.user_name}
                </span>
                <i class="mdi mdi-content-copy text-secondary copy-icon ms-1" style="cursor:pointer;" title="Copy Username"
                    data-copy="${item.user_name}"></i>
            </div>
        
            <div class="col-lg-3 d-flex align-items-center">
                <input type="password" class="form-control form-control-sm me-2 flex-grow-1" id="pass-${uniqueId}"
                    value="${item.password}" readonly>
                <i class="mdi mdi-eye-off-outline text-secondary toggle-password me-2" data-target="pass-${uniqueId}"
                    style="cursor:pointer;" title="Show/Hide Password"></i>
                <i class="mdi mdi-content-copy text-secondary copy-icon" data-copy="${item.password}" style="cursor:pointer;"
                    title="Copy Password"></i>
            </div>
        </div>
        `;
    }

    // Fetch and render credentials
    function fetchCredentials(customerId) {
        const container = $('#credentialContainer');
        container.html('<div class="text-muted text-center py-3">Loading...</div>');

        $.ajax({
            url: `/customer_credentials/${customerId}`,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.status === 200 && response.data) {
                    $('#customer_credential_name').text(response.data.customer.cus_name ?? '-');
                    $('#cus_cred_cont').show();
                    $('#customer_id').val(response.data.customer.sno);

                    if(response.data.customer.cus_mobile) {
                        $('#customer_cred_num').text('Phone Number');
                        $('#customer_credential_number').text(response.data.customer.cus_mobile ?? '-');
                    } else if(response.data.customer.cus_email_id) {
                        $('#customer_cred_num').text('Email ID');
                        $('#customer_credential_number').text(response.data.customer.cus_email_id ?? '-');
                    } else {
                        $('#cus_cred_cont').hide();
                    }

                    // Populate Credentials
                    const creds = response.data.credentials ?? [];
                    container.empty();

                    if (creds.length > 0) {
                        creds.forEach(item => {
                            const rowHTML = createCredentialRow(item);
                            container.append(rowHTML);
                        });
                    } else {
                        container.html('<div class="text-muted text-center py-3">No Credentials Available. Please Add</div>');
                    }
                } else {
                    $('#customer_credential_name').text('-');
                    $('#customer_credential_number').text('-');
                    container.html('<div class="text-muted text-center py-3">No Records Found.</div>');
                }
            },
            error: function() {
                container.html('<div class="text-danger text-center py-3">Failed to load credentials.</div>');
            }
        });
    }

    // Clip Board Copy
    $(document).on('click', '.copy-icon', function () {
        const text = $(this).data('copy');
        if (!text) return;

        const el = $(this);
        const originalTitle = el.attr('title');

        // Modern clipboard API
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text.toString()).then(() => {
                el.attr('title', 'Copied!');
                setTimeout(() => el.attr('title', originalTitle), 1000);
            }).catch(() => {
                fallbackCopy(text);
            });
        } else {
            fallbackCopy(text);
        }
    });

    // Fallback using temporary input
    function fallbackCopy(text) {
        const tempInput = document.createElement("input");
        document.body.appendChild(tempInput);
        tempInput.value = text;
        tempInput.select();
        try {
            document.execCommand("copy");
        } catch (err) {
            console.log("Failed to copy. Please copy manually.");
        }
        document.body.removeChild(tempInput);
    }


    // 👁️ Toggle password visibility
    $(document).on('click', '.toggle-password', function () {
        const targetId = $(this).data('target');
        const input = document.getElementById(targetId);
        if (input.type === "password") {
            input.type = "text";
            $(this)
                .removeClass('mdi-eye-off-outline')
                .addClass('mdi-eye-outline');
        } else {
            input.type = "password";
            $(this)
                .removeClass('mdi-eye-outline')
                .addClass('mdi-eye-off-outline');
        }
    });

    // Validation
    $('#add_customer_credentials').on('submit', (e) => {
        let isValid = true;
        $('.email_error, .pass_error, .link_error, .type_error').text('');

        $('.booklet_row').each(function (index) {
            let emailField = $(this).find('.journal_email');
            let passField = $(this).find('.journal_pass');
            let linkField = $(this).find('.journal_link');
            let typeField = $(this).find('.type_id');
            let type = typeField.val();
            let email = emailField.val().trim();
            let link = linkField.val().trim();
            let pass = passField.val().trim();

            // Validate Email
            if(email === '') {
                emailField.next('.email_error').text('Email is Required.');
                isValid = false;
            } else if(!validateEmail(email)) {
                emailField.next('.email_error').text('Invalid Email Format.');
                isValid = false;
            }

            if(pass === '') {
                passField.next('.pass_error').text('Password is Required');
                isValid = false;
            }

            if(link === '') {
                linkField.next('.link_error').text('Link is Required');
                isValid = false;
            }

            if(type === '') {
                typeField.closest('.col-lg-5').find('.type_error').text('Type is Required.');
                isValid = false;
            }
        });

        if(!isValid) {
            e.preventDefault();
        }
    })
</script>

@endsection