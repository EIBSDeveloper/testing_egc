@extends('layouts/blankLayout')

<title>NDA | {{$edit->cus_name }} | PhDiZone | {{$nda->nda_id}}</title>

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
])
@endsection

@section('page-script')
@endsection

@section('content')

<style>
    @page {
        size: A4;
        background: white !important;
    }

    @media print {
        .noprint {
            display: none;
        }

        #agr_butt {
            display: none !important;
        }

        .sign_box {
            border: 0px !important;
        }

        .sig_txt,
        button {
            display: none !important;
        }

        body {
            background: white !important;
        }

        .page-break {
            page-break-before: auto;
        }
    }

    table th,
    tr,
    td {
        border-collapse: collapse;
        border: 1px solid #ddd;
        padding: 5px;
        /* color: black; */
    }

    body {
        font-family: Arial, sans-serif;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
        background-color: #f0f0f0;
    }

    .signature-pad {
        background-color: #fff;
        margin: 50px;
        /* border: 1px solid #ccc;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); */
        padding: 20px;
        text-align: center;
    }
    .signature-branch {
        background-color: #fff;
        margin: 50px;
        padding: 20px;
        text-align: center;
    }

    .signature-pad_1 {
        background-color: #fff;
        margin: 50px;
        /* border: 1px solid #ccc;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); */
        padding: 20px;
        text-align: center;
    }
    
    #agreeBtn{
        margin-right:30px;
        display: flex;
        align-items:center;
        justify-content:end;
        padding-bottom:20px;
    }
    
    #last_page{
        padding-top:80px
    }

    #signatureCanvas {
        border: 1px solid #ccc;
        margin-bottom: 10px;
    }

    #signatureCanvas_1 {
        border: 1px solid #ccc;
        margin-bottom: 10px;
    }

    #signatureCanvas_2 {
        border: 1px solid #ccc;
        margin-bottom: 10px;
    }

    #signatureCanvas_all {
        border: 1px solid #ccc;
        margin-bottom: 10px;
    }

    .signature-pad-footer {
        margin-top: 10px;
    }

    button {
        padding: 5px 10px;
        background-color: #007bff;
        color: #fff;
        border: none;
        cursor: pointer;
        font-size: 16px;
    }

    button:hover {
        background-color: #0056b3;
    }

    button:active {
        background-color: #0056b3;
    }
    
    .signature_container{
        width:100%;
        display:flex;
        justify-content:space-between;
        flex-wrap: wrap;
        /*margin-left:200px;*/
    }
    
    @media only screen and (max-width: 768px) {
    body {
        padding: 4px;
        font-size: 14px;
    }

    .signature-branch,
    .signature-pad,
    .signature-pad_1 {
        margin: 20px auto;
        width: 100%;
        padding: 10px;
    }
    .signature_container{
        width:100%;
        display:flex;
        justify-content:space-between;
       flex-wrap: wrap;
        
        /*margin-left:100px;*/
    }

    canvas {
        width: 100% !important;
        height: auto !important;
    }
    #agreeBtn{
        width:100%;
        display:flex;
        justify-content:flex-end;
        padding-right:20px;
        padding-bottom:20px;
        
    }
    #last_page{
        padding-top:40px
    }
    
}

</style>
    @php
        $prefix = $edit->cus_gender == 1 ? 'Mr.' : ($edit->cus_gender == 2 ? 'Ms.' : 'Mr/Ms.');
        $fullAddress = collect([
        $edit->door_no ?? null,
        $edit->address ?? null,
        $edit->customer_city_name ?? null,
        $edit->customer_state_name ?? null,
        $edit->customer_country_name ?? null
    ])->filter()->implode(', ');
    @endphp
    @php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ?? 16;
    $user_data=$helper->get_staff_data($user_id);
    @endphp
    
<page size="A4" class="container">
    <center>
        <form  method="POST"  enctype="multipart/form-data" autocomplete="off" id="addNdaForm">
         @csrf
        <div style="width:100%;max-width: 210mm;background-color:#ffffff !important;">
            <div class="header">
                <div style="font-size:18px; font-weight:bold;color:red;text-align:center;margin-left:30px;padding-top:30px;font-family:monospace;">
                    Privileged & Confidential
                </div>
            </div>
            <div>
                <div style="font-size:15px; font-weight:bold;color:black;text-align:center;margin-left:30px;padding-top:10px;">
                    <label><?php echo date('jS F - Y');?></label>
                </div>
                <div style="border-top:dashed 1px black;margin-top:60px;margin-right:160px;margin-left:160px;"></div>
                <div style="font-size:18px; font-weight:bold;color:black;text-align:center;margin-left:30px;padding-top:25px;"></div>
                <label style="font-weight:bold;color:black;">DELIVERY PARTNER AGREEMENT</label>
                <div style="border-top:dashed 1px black;margin-top:25px;margin-right:160px;margin-left:160px;"></div>
                <div style="font-size:15px; font-weight:400;color:black;text-align:center;margin-left:30px;padding-top:80px;">
                    <label>By and Amongst</label>
                </div>
                <div style="font-size:28px; font-weight:bold;color:black;text-align:center;margin-left:30px;padding-top:50px;">
                    <label>PhDiZone</label>
                </div>
                <div style="font-size:22px; font-weight:500;color:black;text-align:center;margin-left:30px;padding-top:10px;">
                    <label>[A part of Elysium Technologies Private Limited]</label>
                </div>
                <div style="font-size:20px; font-weight:500;color:black;text-align:center;margin-left:30px;padding-top:80px;">
                    <label>AND</label>
                </div>
                <div>
                    <label style="font-size:16px; font-weight:500;color:black;text-align:center;margin-left:30px;padding-top:80px;">Name</label>
                    <label>:</label>
                    <label style="font-size:24px; font-weight:bold;color:black;text-align:center;padding-top:80px;">{{ $prefix }} {{ $edit->cus_name ?? ''}}</label>
                </div>
              @if($edit->cus_email_id)
                <div style="padding-top:12px;">
                    <label style="font-size:16px; font-weight:500;color:black;text-align:center;margin-left:30px;">Mail</label>
                    <label>:</label>
                    <label style="font-size:16px; font-weight:bold;color:black;text-align:center;">
                        <a href="mailto:{{ $list->cus_email_id ?? '-'}}">{{ $edit->cus_email_id ?? '-'}}</a></label>
                </div>
                @endif
                <div style="padding-top:12px;">
                    <label style="font-size:16px; font-weight:500;color:black;text-align:center;margin-left:30px;">NDA ID</label>
                    <label>:</label>
                    <label style="font-size:16px; font-weight:bold;color:black;text-align:center;">{{$nda->nda_id}}</label>
                </div>
                <div style="margin-top:100px;border:solid black;border-width:0.5px;margin-right:120px;margin-left:120px;"></div>
            </div>
            <hr class="noprint">
            <div style="break-before:page;">
                <div style="padding-top:100px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;<span>{{$edit->branch_name}}, a part of Elysium Technologies private Limited</span> company incorporated under the laws of Indian government, having its registered office at <span>{{$edit->branch_door}}, {{$edit->area_street}}, {{$edit->branch_city_name}} – {{$edit->pincode}}, {{$edit->branch_state_name}}, {{$edit->branch_country_name}}</span> (Here in after called the “iZone”) and which term shall unless excluded by or repugnant to the context mean and includes its heirs, successors, administrators, etc. acting through its authorized signatory <span>Mr/Mrs.{{$edit->staff_name}}</span> of the FIRST PART;</p>
                </div>
                <div style="font-size:16px; font-weight:bold;color:black;text-align:center;margin-left:30px;">
                    <label>AND</label>
                </div>
                <div style="margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;<span>{{ $prefix }} {{ $edit->cus_name ?? ''}} </span>an individual/partnership under the laws of Indian government, having its registered office/residence at <span>{{$fullAddress}}.</span> (Here in after called the “iClient”) and which term shall unless excluded by or repugnant to the context mean and include its heirs, successors, administrators etc. acting through as authorized signatory, <span>Mr/Mrs.{{$edit->cus_name}}</span> duly authorized as the SECOND PART</p>
                </div>
                <div style="font-size:18px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>WHEREAS</label>
                </div>
                <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:50px;margin-right:50px;text-align: justify !important">
                    <ul>
                        <li>iClient is engaged in getting service from iZone for their research assistance</li>
                        <li>iZone carries on the business of providing the Services and has necessary manpower,
                            resources, and expertise to provide the Services; and</li>
                    </ul>
                </div>
                <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>NOW THEREFORE THIS AGREEMENT WITNESSETH as follows:</label>
                </div>
                <div style="font-size:15px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>1.<span style="padding-left:10px;text-decoration: underline;text-underline-offset: 2px;text-decoration-thickness: 2px">PURPOSE</span></label>
                </div>
                <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:50px;margin-right:50px;text-align: justify !important">
                    <label>&emsp;&emsp;&emsp;&emsp;
                        Purpose of this Agreement is to set forth the terms and conditions under
                        which the “iZone”and“iClient” mentioned in Annexure A.
                    </label>
                </div>
                <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>2.<span style="padding-left:10px;text-decoration: underline;text-underline-offset: 2px;text-decoration-thickness: 2px">SCOPE</span></label>
                </div>
                <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:50px;margin-right:50px;text-align: justify !important">
                    <label>&emsp;&emsp;&emsp;&emsp;
                        This agreement applies to the Services mentioned in Annexure A.
                    </label>
                </div>
                <div style="font-size:15px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>3.<span style="padding-left:10px;text-decoration: underline;text-underline-offset: 2px;text-decoration-thickness: 2px">TERMS OF AGREEMENT</span></label>
                </div>
                <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:50px;margin-right:50px;text-align: justify !important">
                    <label>&emsp;&emsp;&emsp;&emsp;
                        This agreement applies to the Services mentioned in Annexure A.
                    </label>
                </div>
                <div style="font-size:15px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>a.<span style="padding-left:10px;">Confidentiality:</span></label>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;Confidential information provided under the Service Agreement must be treated as
                        confidential by the “iClient” and “iZone”
                        Parties shall treat any data and information, whether written, oral or visual, disclosed to it
                        or which comes into its possession or knowledge in connection with this Agreement as
                        confidential and shall not disclose the same to any others - except as may be required by
                        law or as may be required to be disclosed on a "Need-to-Know" basis for implementing
                        this Agreement.</p>
                </div>
                <div style="" class="signature_container">
                    <div class="signature-branch" style="margin-top:20px;">
                        <img src="{{asset('terms_condition_signature')}}/{{$terms->nda_signature}}" alt="Header" class="signature-image" style="height: 80px; width:200px;">
                        <div>
                            <label class="sig_txt_branch" style="font-size:14px;font-weight:bold;color:black;">Authority Signature</label>
                        </div>
                    </div>
                    <div class="signature-pad" style="margin-top:20px;">
                        <canvas class="sign_box" id="signatureCanvas" name="signatureCanvas" width="280" height="80" onclick="fun_btn_btn_add();"></canvas>
                        <div>
                            <label class="sig_txt" style="font-size:14px;font-weight:bold;color:black;">Draw Your Signature</label>
                        </div>
                        <div class="text-danger" id="signatureCanvas_err"></div>
                        <div class="signature-pad-footer" style="display:none;" id="clear_btn_fn" name="clear_btn_fn">
                            <button type="button" id="clr_btn">Clear</button>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="noprint">
            <div style="break-before:page;">
                <div style="padding-top:100px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;If Parties has access to the other Party’s confidential information, the party who has been
                        given access to the confidential information will not disclose it to a third party without
                        the prior written consent of the other Party, unless:</p>
                </div>
                <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:50px;margin-right:50px;text-align: justify !important">
                    <ul>
                        <li>The disclosure of the confidential information is required by law or by the Service
                            Agreement; or</li>
                        <li>The disclosure is reasonably required by any person performing their obligations under
                            the Service Agreement; or</li>
                        <li>The disclosure is to a party's own professional advisers or its insurer; or</li>
                        <li>If the disclosure of the information is requested by the Auditor-General, the
                            Ombudsman, or the Minister responsible for the portfolio under which the service
                            operate.</li>
                    </ul>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">Subject to the above, each party to the Service Agreement will ensure that any third party
                        to which it discloses confidential information is made aware of the confidential nature of
                        that information.</p>
                </div>
                <div style="padding-top:5px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">iZone will use information regarding this Agreement only in the performance of this
                        Agreement the same applies to clients as well.</p>
                </div>
                <div style="padding-top:5px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">All written and oral information and material disclosed or provided by the “iClient” to
                        the “iZone” under this Agreement are Confidential Information regardless of whether it
                        was provided before or after the date of this Agreement or how it was provided to the
                        Company.</p>
                </div>
                <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>b.<span style="padding-left:10px;">Confidentiality:</span></label>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;<b>Relationship & Non-Exclusivity: </b>Nothing contained in this Agreement is
                        intended to create, nor shall it be construed to create, a relationship between the Parties
                        other than that of two independent Parties contracting with each other solely for the
                        purpose of effectuating the provision of this Agreement.</p>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;&emsp;&emsp;<b>Term and Termination: </b>This Agreement shall commence on the Effective Date
                        and shall continue in force for a period of <b><span>(120 days) </span>(As per estimate and invoice)</b>
                        unless terminated in accordance with the terms of this Agreement. Any renewal or
                        extension shall be subject to the written agreement of both Parties.</p>
                </div>
                <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                    <label>c.<span style="padding-left:10px;">General:</span></label>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:10px;"><b>i. Entire Agreement: </b></span>Nothing contained in this Agreement is
                        intended to create, nor shall it be construed to create, a relationship between the Parties
                        other than that of two independent Parties contracting with each other solely for the
                        purpose of effectuating the provision of this Agreement.</p>
                  
                </div>
                <div style="" class="signature_container">
                    <div class="signature-branch" style="margin-top:20px;">
                        <img src="{{asset('terms_condition_signature')}}/{{$terms->nda_signature}}" alt="Header" class="signature-image" style="height: 80px; width:200px;">
                        <div>
                            <label class="sig_txt_branch" style="font-size:14px;font-weight:bold;color:black;">Authority Signature</label>
                        </div>
                    </div>
                    <div class="signature-pad" style="margin-top:20px;">
                        <canvas class="sign_box" id="signatureCanvas_1" name="signatureCanvas_1" width="280" height="80" onclick="func_btn_btn_add();"></canvas>
                        <div>
                            <label class="sig_txt" style="font-size:14px;font-weight:bold;color:black;">Draw Your Signature</label>
                        </div>
                        <div class="text-danger" id="signatureCanvas_1_err"></div>
                        <div class="signature-pad-footer" style="display:none;" id="clear_btn_btn" name="clear_btn_btn">
                            <button type="button" id="clearButtonbtn_all">Clear</button>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="noprint">
            <div style="break-before:page;">
                <div style="padding-top:100px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:10px;"><b>ii.Amendments: </b></span>This agreement is effective as of the date of signature by all authorized
                        representatives indicated below and shall last until terminated in accordance with the
                        specific Party requirements described herein. The Agreement may be amended by
                        mutual agreement of the Parties. Either Party may terminate this agreement upon thirty
                        (30) days written notice to the other Party in accordance with the above terms, after first
                        pursuing a good faith effort to resolve any issues prompting termination.</p>
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:10px;"><b>iii.Notices and Communications: </b></span>Any notice, consent or approval required or permitted
                        to be given in connection with this Agreement (in this Section referred to as a “Notice”)
                        must be in writing and is sufficiently given if delivered (whether in person, by email or
                        other personal method of delivery). Social Media acknowledgement is not acceptable.</p>
                </div>
                <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:10px;"><b>iii.Dispute Resolution: </b></span></p>
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:5px;"></span>
                            Any and all claims, disputes, questions or controversies involving the Parties and
                            arising out of or in connection with this Agreement, or the execution, interpretation,
                            validity, performance, breach or termination hereof (collectively, “Dispute(s)”) that
                            cannot be finally resolved by the Parties within thirty (30) calendar days of the arising
                            of a Dispute by amicable negotiation and conciliation shall first be submitted for
                            settlement by informal arbitration to an arbitral panel consisting of the senior authorities.
                    </p>
                    <p style="text-align:justify;">&emsp;&emsp;<span style="margin-right:5px;"></span>
                            Arbitration - Any dispute which is not settled pursuant to Article 37(A) shall be
                            referred to a panel of arbitrators consisting of one arbitrator appointed by the petitioner
                            in party or parties, as the case may be, one arbitrator appointed by the respondent party
                            or respondent parties as the case may be and both the arbitrators shall appoint the
                            presiding arbitrator and the arbitration shall be conducted in accordance with the Indian
                            Arbitration and Conciliation Act, 1996 as amended from time to time. The venue of
                            Arbitration shall be <i>Madurai, Tamil Nadu, India.</i>
                    </p>
                </div>
                <div style='display:flex;margin-left:10px;padding-right:30px;padding-left:30px;margin-top:30px;'>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:500;">For the above <b>iZone</b> through its duly
                            authorized signatory</label>
                    </div>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:500;">For the <b>iClient</b> through its duly
                            authorized signatory</label>
                    </div>
                </div>
                <div style='display:flex;margin-left:10px;padding-right:30px;padding-left:30px;margin-top:30px;'>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:bold;">Mr/Mrs.{{$edit->nick_name ?? $edit->staff_name}}</label>
                    </div>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:bold;">{{ $prefix }} {{ $edit->cus_name ?? ''}}</label>
                    </div>
                </div>
                <div style='display:flex;margin-left:10px;padding-right:30px;padding-left:30px;margin-top:10px;'>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:bold;">
                            Date :</label>
                        <label style="font-size:16px;color:black;font-weight:bold;">
                            {{ $nda->nda_date ? date($common_date_format, strtotime($nda->nda_date)) :'-' }}</label>
                    </div>
                    <div style="width:50%">
                        <label style="font-size:16px;color:black;font-weight:bold;">
                            Date :</label>
                        <label style="font-size:16px;color:black;font-weight:bold;">
                            {{ $nda->nda_date ? date($common_date_format, strtotime($nda->nda_date)) :'-' }}</label>
                    </div>
                </div>
                <div style="" class="signature_container">
                    <div class="signature-branch" style="margin-top:20px;">
                        <img src="{{asset('terms_condition_signature')}}/{{$terms->nda_signature}}" alt="Header" class="signature-image" style="height: 80px; width:200px;">
                        <div>
                            <label class="sig_txt_branch" style="font-size:14px;font-weight:bold;color:black;">Authority Signature</label>
                        </div>
                    </div>
                    <div class="signature-pad" style="margin-top:20px;">
                        <canvas class="sign_box" id="signatureCanvas_2" name="signatureCanvas_2" width="280" height="80" onclick="func_btn_add();"></canvas>
                        <div>
                            <label class="sig_txt" style="font-size:14px;font-weight:bold;color:black;">Draw Your Signature</label>
                        </div>
                        <div class="text-danger" id="signatureCanvas_2_err"></div>
                        <div class="signature-pad-footer" style="display:none;" id="clear_btn" name="clear_btn">
                            <button type="button" id="clearButton">Clear</button>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="noprint">
            <div style="break-before:page;">
                <div Style="" id="last_page">
                    <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:20px;">
                        <label><span style="padding-left:10px;text-decoration: underline;text-underline-offset: 2px;text-decoration-thickness: 2px">Scope of The Agreement</span></label>
                    </div>
                    <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                        <label><span style="padding-left:10px;text-decoration: underline;text-underline-offset: 2px;text-decoration-thickness: 2px">Providing Research Guidance on Appointment Basis</span></label>
                    </div>
                    <div style="padding-top:10px;margin-left:50px;margin-right:50px;color:black;">
                        <p style="text-align:justify;margin-left:10px;"><b>Background: </b>Experience and Skill Trained People for providing service to the client by
                            technical, reference, development and through document creation.</p>
                        <p style="text-align:justify;margin-left:10px;"><b>{{$edit->branch_name}} Solution: </b>{{$edit->branch_name}} is one of the leading research guidance providers all over
                            the world providing through Technology, Scholars opinion and Ideas. <b>Payments for
                                service will be confirmed through email only</b></p>
                    </div>
                    <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                        <label><span style="padding-left:10px;">Responsibilities of iClient</span></label>
                    </div>
                    <div style="font-size:14px; font-weight:500;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                        <ol>
                            <li>Register with iZone.</li>
                            <li>Confirm all their requirements and through email only</li>
                            <li>No personal information neither iZone staff nor yourself will not be acceptable</li>
                            <li>Required documents must be provided to iZone only to the email provided for
                                communication & SPOC (Single Point of Contact).</li>
                            <li>Every Step of service and payment to be acknowledged</li>
                            <li>All payments in the favor of Elysium Technologies Private Limited only</li>
                            <li>Only registered iClient has rights to fix appointments for communication getting prior
                                approval from the business team.</li>
                            <li>Acknowledgment must be reverted back in a maximum of 15-20days.</li>
                            <li>Follow the terms & conditions of iZone. Duration of service is only dependent on your
                                acknowledgement through email.</li>
                        </ol>
                    </div>
                    <div style="font-size:16px; font-weight:bold;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                        <label><span style="padding-left:10px;">Responsibilities of {{$edit->branch_name}}</span></label>
                    </div>
                    <div style="font-size:14px; font-weight:500;color:black;text-align:left;margin-left:50px;padding-top:10px;">
                        <ol>
                            <li>Provide. Support through digital platforms or in person for supporting demand for
                                guidance.</li>
                            <li>Provide. Explanation of guidance document.</li>
                            <li>Provide. Source code and related documents after acknowledgement and NOC (No
                                Objection Certificate).</li>
                            <li>Provide NOC (No Objection Certificate) based on acknowledgement and payments.</li>
                            <li>Provide. SPOC (Single point of contact for communication).</li>
                            <li>Once acknowledged by iClient the paid money will not be returned back.</li>
                            <li>Update of the work will be provided as accepted through email by both parties.</li>
                            <li>Appointment Confirmation only provided by iZone.</li>
                            <li>No. of Reviews/correction and changes will be accepted only through email only.</li>
                            <li>iZone will not disclose your personal information/technical details of your work
                                without acceptance of written format to any third party.</li>
                        </ol>
                    </div>
                    <div style="" class="signature_container">
                        <div class="signature-branch" style="margin-top:20px;">
                            <img src="{{asset('terms_condition_signature')}}/{{$terms->nda_signature}}" alt="Header" class="signature-image" style="height: 80px; width:200px;">
                            <div>
                                <label class="sig_txt_branch" style="font-size:14px;font-weight:bold;color:black;">Authority Signature</label>
                            </div>
                        </div>
                        <div class="signature-pad" style="margin-top:20px;margin-bottom:20px !important;">
                            <canvas class="sign_box" id="signatureCanvas_all" name="signatureCanvas_all" width="280" height="80" onclick="func_btn_add_all();"></canvas>
                            <div>
                                <label class="sig_txt" style="font-size:14px;font-weight:bold;color:black;">Draw Your Signature</label>
                            </div>
                             <div class="text-danger" id="signatureCanvas_all_err"></div>
                            <div class="signature-pad-footer" style="display:none;" id="clear_btn_all" name="clear_btn_all">
                                <button type="button" id="clearButton_all">Clear</button>
                                <button type="button" id="saveButton_all" style="background-color: transparent !important;cursor:context-menu !important;">Ok</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" name="nda_id" id="nda_id" value="{{$nda->sno}}">
            <input type="hidden" name="signature_1" id="signature_1">
            <input type="hidden" name="signature_2" id="signature_2">
            <input type="hidden" name="signature_3" id="signature_3">
            <input type="hidden" name="signature_4" id="signature_4">
            <div style="" id="agreeBtn">
                <button type="button" class="btn btn-sm btn-primary" id="agr_butt" onclick="agree_nda_func()">I Agree</button>
            </div>
        </div>
        </form>
    </center>
</page>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
     
        .tags-inline.tagify__dropdown {
            z-index: 9999 !important; /* Ensure it is higher than the modal's z-index */
        }
    </style>
  <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var canvas = document.getElementById('signatureCanvas_2');
        var ctx = canvas.getContext("2d");
        var isDrawing = false;

        canvas.addEventListener("mousedown", startDrawing);
        canvas.addEventListener("mousemove", draw);
        canvas.addEventListener("mouseup", stopDrawing);
        canvas.addEventListener("mouseout", stopDrawing);

        function startDrawing(e) {
            isDrawing = true;
            draw(e);
        }

        function draw({
            offsetX: x,
            offsetY: y
        }) {
            if (!isDrawing) return;
            ctx.lineWidth = 2;
            ctx.lineCap = "round";
            ctx.strokeStyle = "#000";
            ctx.lineTo(x, y);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(x, y);
        }

        function stopDrawing() {
            isDrawing = false;
            ctx.beginPath();
        }

        document.getElementById('clearButton').addEventListener('click', function() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        });
    });
</script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var canvas = document.getElementById('signatureCanvas_all');
        var ctx = canvas.getContext("2d");
        var isDrawing = false;

        canvas.addEventListener("mousedown", startDrawing);
        canvas.addEventListener("mousemove", draw);
        canvas.addEventListener("mouseup", stopDrawing);
        canvas.addEventListener("mouseout", stopDrawing);

        function startDrawing(e) {
            isDrawing = true;
            draw(e);
        }

        function draw({
            offsetX: x,
            offsetY: y
        }) {
            if (!isDrawing) return;
            ctx.lineWidth = 2;
            ctx.lineCap = "round";
            ctx.strokeStyle = "#000";
            ctx.lineTo(x, y);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(x, y);
        }

        function stopDrawing() {
            isDrawing = false;
            ctx.beginPath();
        }

        document.getElementById('clearButton_all').addEventListener('click', function() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        });
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        var canvas = document.getElementById('signatureCanvas');
        var ctx = canvas.getContext("2d");
        var isDrawing = false;

        canvas.addEventListener("mousedown", startDrawing);
        canvas.addEventListener("mousemove", draw);
        canvas.addEventListener("mouseup", stopDrawing);
        canvas.addEventListener("mouseout", stopDrawing);

        function startDrawing(e) {
            isDrawing = true;
            draw(e);
        }

        function draw({
            offsetX: x,
            offsetY: y
        }) {
            if (!isDrawing) return;
            ctx.lineWidth = 2;
            ctx.lineCap = "round";
            ctx.strokeStyle = "#000";
            ctx.lineTo(x, y);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(x, y);
        }

        function stopDrawing() {
            isDrawing = false;
            ctx.beginPath();
        }
        document.getElementById('clr_btn').addEventListener('click', function() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        });
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        var canvas = document.getElementById('signatureCanvas_1');
        var ctx = canvas.getContext("2d");
        var isDrawing = false;

        canvas.addEventListener("mousedown", startDrawing);
        canvas.addEventListener("mousemove", draw);
        canvas.addEventListener("mouseup", stopDrawing);
        canvas.addEventListener("mouseout", stopDrawing);

        function startDrawing(e) {
            isDrawing = true;
            draw(e);
        }

        function draw({
            offsetX: x,
            offsetY: y
        }) {
            if (!isDrawing) return;
            ctx.lineWidth = 2;
            ctx.lineCap = "round";
            ctx.strokeStyle = "#000";
            ctx.lineTo(x, y);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(x, y);
        }

        function stopDrawing() {
            isDrawing = false;
            ctx.beginPath();
        }
        document.getElementById('clearButtonbtn_all').addEventListener('click', function() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        });
    });
</script>
<script>
    function func_btn_add() {
        var signatureCanvas = document.getElementById("signatureCanvas_2");
        if (signatureCanvas.click) {
            clear_btn.style.display = "block";
            $('#signatureCanvas_2_err').text('');
        } else {
            hints_tbox_add.style.display = "none";
        }
    }
</script>
<script>
    function func_btn_add_all() {
        var signatureCanvas_all = document.getElementById("signatureCanvas_all");
        if (signatureCanvas_all.click) {
            clear_btn_all.style.display = "block";
            $('#signatureCanvas_all_err').text('');
        } else {
            hints_tbox_add.style.display = "none";
        }
    }
</script>

<script>
    function func_btn_btn_add() {
        var signatureCanvas_all = document.getElementById("signatureCanvas_1");
        if (signatureCanvas_all.click) {
            clear_btn_btn.style.display = "block";
            $('#signatureCanvas_1_err').text('');
        } else {
            hints_tbox_add.style.display = "none";
        }
    }
</script>

<script>
    function fun_btn_btn_add() {
        var signatureCanvas_all = document.getElementById("signatureCanvas");
        if (signatureCanvas_all.click) {
            clear_btn_fn.style.display = "block";
            $('#signatureCanvas_err').text('');
        } else {
            hints_tbox_add.style.display = "none";
        }
    }
</script>
<script>
    function agree_nda_func() {
    var err = 0;
    var firstErrorElem = null;

    function isCanvasBlank(canvas) {
        var blank = document.createElement('canvas');
        blank.width = canvas.width;
        blank.height = canvas.height;
        return canvas.toDataURL() === blank.toDataURL();
    }

    // Signature Canvas 1
    var canvas1 = document.getElementById('signatureCanvas');
    if (isCanvasBlank(canvas1)) {
        $('#signatureCanvas_err').text('Signature is required.');
        $(canvas1).addClass('error');
        if (!firstErrorElem) firstErrorElem = $('#signatureCanvas_err');
        err++;
    } else {
        $('#signatureCanvas_err').text('');
        $(canvas1).removeClass('error');
    }

    // Signature Canvas 2
    var canvas2 = document.getElementById('signatureCanvas_1');
    if (isCanvasBlank(canvas2)) {
        $('#signatureCanvas_1_err').text('Signature is required.');
        $(canvas2).addClass('error');
        if (!firstErrorElem) firstErrorElem = $('#signatureCanvas_1_err');
        err++;
    } else {
        $('#signatureCanvas_1_err').text('');
        $(canvas2).removeClass('error');
    }

    // Signature Canvas 3
    var canvas3 = document.getElementById('signatureCanvas_2');
    if (isCanvasBlank(canvas3)) {
        $('#signatureCanvas_2_err').text('Signature is required.');
        $(canvas3).addClass('error');
        if (!firstErrorElem) firstErrorElem = $('#signatureCanvas_2_err');
        err++;
    } else {
        $('#signatureCanvas_2_err').text('');
        $(canvas3).removeClass('error');
    }

    // Signature Canvas 4
    var canvas4 = document.getElementById('signatureCanvas_all');
    if (isCanvasBlank(canvas4)) {
        $('#signatureCanvas_all_err').text('Signature is required.');
        $(canvas4).addClass('error');
        if (!firstErrorElem) firstErrorElem = $('#signatureCanvas_all_err');
        err++;
    } else {
        $('#signatureCanvas_all_err').text('');
        $(canvas4).removeClass('error');
    }

    // Scroll to first error element
    if (err > 0 && firstErrorElem) {
        $('html, body').animate({
            scrollTop: firstErrorElem.offset().top - 100
        }, 600);
        $('#agr_butt').prop('disabled', false);
    } else {
        // Store canvas data in hidden inputs
        document.getElementById('signature_1').value = canvas1.toDataURL();
        document.getElementById('signature_2').value = canvas2.toDataURL();
        document.getElementById('signature_3').value = canvas3.toDataURL();
        document.getElementById('signature_4').value = canvas4.toDataURL();

        nda_submit_func();
        $('#agr_butt').prop('disabled', true);
    }
}

</script>
<script>
function nda_submit_func() {
    let form = document.getElementById('addNdaForm');
    let formData = new FormData(form);

    fetch("{{ route('nda_signed') }}", {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            toastr.success(data.message);
              const newTabUrl = '/nda_success/' + data.id;
             const newTab = window.open(newTabUrl, '_blank');
        
                setTimeout(() => {
                    // Close current tab (works if it was opened via JS)
                    window.close();
                }, 100);
        } else {
            toastr.error(data.message || 'Something went wrong.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        toastr.error('Submission failed.');
    });
}
</script>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const signatureConfigs = [
        {
            canvasId: "signatureCanvas",
            clearBtnId: "clr_btn",
            errorId: "signatureCanvas_err",
            clearContainerId: "clear_btn_fn"
        },
        {
            canvasId: "signatureCanvas_1",
            clearBtnId: "clearButtonbtn_all",
            errorId: "signatureCanvas_1_err",
            clearContainerId: "clear_btn_btn"
        },
        {
            canvasId: "signatureCanvas_2",
            clearBtnId: "clearButton",
            errorId: "signatureCanvas_2_err",
            clearContainerId: "clear_btn"
        },
        {
            canvasId: "signatureCanvas_all",
            clearBtnId: "clearButton_all",
            errorId: "signatureCanvas_all_err",
            clearContainerId: "clear_btn_all"
        }
    ];

    signatureConfigs.forEach(config => {
        const canvas = document.getElementById(config.canvasId);
        const ctx = canvas.getContext("2d");
        const clearBtn = document.getElementById(config.clearBtnId);
        const clearContainer = document.getElementById(config.clearContainerId);
        const errorText = document.getElementById(config.errorId);
        let isDrawing = false;

        function getPosition(e) {
            if (e.touches && e.touches.length > 0) {
                return {
                    x: e.touches[0].clientX - canvas.getBoundingClientRect().left,
                    y: e.touches[0].clientY - canvas.getBoundingClientRect().top
                };
            } else {
                return {
                    x: e.offsetX,
                    y: e.offsetY
                };
            }
        }

        function startDrawing(e) {
            e.preventDefault();
            isDrawing = true;
            const pos = getPosition(e);
            ctx.beginPath();
            ctx.moveTo(pos.x, pos.y);
            // Show the clear button and hide error
            if (clearContainer) clearContainer.style.display = "block";
            if (errorText) errorText.innerText = '';
        }

        function draw(e) {
            if (!isDrawing) return;
            e.preventDefault();
            const pos = getPosition(e);
            ctx.lineWidth = 2;
            ctx.lineCap = "round";
            ctx.strokeStyle = "#000";
            ctx.lineTo(pos.x, pos.y);
            ctx.stroke();
        }

        function stopDrawing(e) {
            if (!isDrawing) return;
            e.preventDefault();
            isDrawing = false;
            ctx.beginPath();
        }

        // Mouse events
        canvas.addEventListener("mousedown", startDrawing);
        canvas.addEventListener("mousemove", draw);
        canvas.addEventListener("mouseup", stopDrawing);
        canvas.addEventListener("mouseout", stopDrawing);

        // Touch events
        canvas.addEventListener("touchstart", startDrawing);
        canvas.addEventListener("touchmove", draw);
        canvas.addEventListener("touchend", stopDrawing);
        canvas.addEventListener("touchcancel", stopDrawing);

        // Clear button
        if (clearBtn) {
            clearBtn.addEventListener("click", function () {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            });
        }

        // Optional: show clear button on click if not drawing yet
        canvas.addEventListener("click", function () {
            if (clearContainer) clearContainer.style.display = "block";
            if (errorText) errorText.innerText = '';
        });
    });
});
</script>

@endsection