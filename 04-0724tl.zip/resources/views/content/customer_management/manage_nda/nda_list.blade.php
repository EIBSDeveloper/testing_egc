@extends('layouts/layoutMaster')

@section('title', 'Manage NDA')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/toastr/toastr.scss',
'resources/assets/vendor/libs/animate-css/animate.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/clipboard/clipboard.js',
'resources/assets/vendor/libs/toastr/toastr.js'
])
@endsection

@section('page-script')
@endsection
@section('content')

@php
$helper = new \App\Helpers\Helpers();
@endphp
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 8px !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>
<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage NDA</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                            class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body px-4 py-0">
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-100px">NDA No</th>
                            <th class="min-w-80px">NDA Date</th>
                            <th class="min-w-100px">Customer</th>
                            <th class="min-w-100px">Address</th>
                            <!--<th class="min-w-100px">NDA Link</th>-->
                            <th class="min-w-50px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        @if(!$ndas->isEmpty())
                            @foreach($ndas as $nda)
                            @php
                               
                                $fullAddress = collect([
                                $nda->door_no ?? null,
                                $nda->address ?? null,
                                $nda->city_name ?? null,
                                $nda->state_name ?? null,
                                $nda->name ?? null
                            ])->filter()->implode(', ');
                            @endphp
                                <tr>
                                    <td>
                                        <label class="fs-7">{{$nda->nda_id}}</label>
                                        <div class="d-block">
                                            <div class="d-flex gap-2">
                                                @if ($nda->status == 0)
                                                <label class="badge bg-info text-white fs-8 fw-semibold">NDA Shared</label>
                                                @if($nda->old_customer_check ==1)
                                                     @if($nda->nda_link)
                                                        <span>
                                                            <a href="{{$nda->nda_link}}" target="_blank" class="dropdown-item">
                                                                <span><i class="mdi mdi-link fs-5 text-primary fw-bold "></i></span>
                                                            </a>
                                                        </span>
                                                     @endif
                                                 @endif
                                                @elseif ($nda->status == 1)
                                                <label class="badge bg-success text-black fs-8 fw-semibold">NDA Signed</label>
                                                @endif
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <label class="fs-7">
                                            {{\Carbon\Carbon::parse($nda->nda_date)->format('d-M-Y')}}
                                        </label>
                                    </td>
                                    <td>
                                        <label class="fs-7">{{$nda->cus_name}}</label>
                                        <div class="d-block">
                                            <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Email ID">{{$nda->cus_email_id}}</label>
                                        </div>
                                    </td>
                                    <td>
                                        <label class="fs-7 text-wrap max-w-300px">{{$fullAddress}}</label>
                                    </td>
                                    <!--<td>-->
                                    <!--    @if ($nda->status == 0)-->
                                    <!--    <label class="text-info fs-7 fw-bold me-1">Link is here</label>-->
                                    <!--    <input type="hidden" id="coup_code_val_td_1"-->
                                    <!--        value="{{$nda->nda_link}}" />-->
                                    <!--    <a href="javascript:;" class="cpy-btn btn btn-sm btn-label-primary px-2 py-1"-->
                                    <!--        data-clipboard-action="copy" data-clipboard-target="#coup_code_val_td_1">-->
                                    <!--        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Copy"><i-->
                                    <!--                class="mdi mdi-content-copy fs-6 text-black"></i></span>-->
                                    <!--    </a>-->
                                    <!--    @elseif ($nda->status == 1)-->
                                    <!--    <label class="text-danger fs-7 fw-bold me-1">Link Expired</label>-->
                                    <!--    @endif-->
                                    <!--</td>-->
                                    <td>
                                        @php
                                            $encryptedValue = $helper->encrypt_decrypt($nda->sno, 'encrypt');
                                            $url = ('/manage_nda_view/' . $encryptedValue);
                                            $nda_url = ('/nda_download/' . $encryptedValue);
                                            $print_url = ('/manage_nda_print/' . $encryptedValue)
                                        @endphp
                                        <span class="text-end">
                                           
                                            <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false">
                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                            </a>
                                             @if($nda->status == 1)
                                            <a href="{{$nda_url}}}" class="btn btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-placement="bottom"  title="Download Nda">
                                                <i class="mdi mdi-download-circle fs-3 text-black"></i>
                                            </a> @endif
                                            <div class="dropdown-menu dropdown-menu-end">
                                                 @if($nda->status == 0)
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_send_nda" onclick="send_nda_func('{{$nda->proposal_id}}','{{$nda->cus_email_id}}','{{$nda->cus_mobile}}','{{$nda->cus_id}}','{{$nda->cus_name}}','{{$nda->invoice_id}}','{{$nda->cus_id}}')">
                                                    <span><i class="mdi mdi-file-document-edit-outline fs-3 text-black me-1"></i>Send NDA</span>
                                                </a>
                                                @endif
                                                <!--<a href="{{$url}}}" target="_blank" class="dropdown-item">-->
                                                <!--    <span> <i-->
                                                <!--            class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>-->
                                                 @if($nda->status == 1)
                                                <a href="{{$print_url}}" target="_blank"
                                                    class="dropdown-item">
                                                    <span> <i
                                                            class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i>Print</span>
                                                </a>
                                                 
                                                  @endif
                                            </div>
                                        </span>
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Send NDA-->
<div class="modal fade" id="kt_modal_send_nda" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Send NDA</h3>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Customer Id</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="send_customer_id"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="send_cus_name">Priya</label>
                </div>
                <!--<div class="row mb-3">-->
                <!--    <label class="col-4 text-dark fs-6 fw-semibold">Receipt No</label>-->
                <!--    <label class="col-1 text-black fs-6 fw-bold">:</label>-->
                <!--    <label class="col-7 text-black fs-6 fw-bold" id="send_invoice_id">INV-005003/05/2025</label>-->
                <!--</div>-->
                <div class="d-flex  gap-2 mt-4 mb-1">
                     <label class="text-black mb-1 fs-6 fw-semibold" id="old_cus_check_text">Skip Communication</label>
                    <input class="form-check-input" type="checkbox" id="old_cus_check" name="old_cus_check" value="1" checked onclick="old_cus_check_func();">
                </div>
                <div class="communication_check">
                    <div class="d-flex align-items-center justify-content-between mt-4 mb-1">
                        <div class="text-black fs-6 fw-semibold mb-1">Choose Communication</div>
                        <div class="badge bg-label-primary rounded-pill mb-1">
                            <i class="mdi mdi-link-variant mdi-14px me-1"></i>
                            <span class="align-middle fw-semibold">NDA Attached</span>
                        </div>
                    </div>
                </div>
                <div class="row communication_check">
                    <div class="col-lg-12 mb-3">
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_whats_app" onclick="send_proposal_whatsapp_func();">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/whatsapp.png')}}" alt="whatsapp" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Whats App</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_email" onclick="send_proposal_email_func();">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/email.png')}}" alt="email" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Email</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_message" onclick="send_proposal_message_func();">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/message.png')}}" alt="message" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Message</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="text-danger" id="communication_err"></div>
                    </div>
                    <input type="hidden" name="send_customer_id" id="send_customer_id">
                    <input type="hidden" name="send_proposal_id" id="send_proposal_id">
                    <input type="hidden" name="send_proposal_whatsapp" id="send_proposal_whatsapp" value="0">
                    <input type="hidden" name="send_proposal_email" id="send_proposal_email" value="0">
                    <input type="hidden" name="send_proposal_sms" id="send_proposal_sms" value="0">
                    <!--<div class="col-lg-12 mb-3">-->
                    <!--    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>-->
                    <!--    <textarea class="form-control" rows="3" placeholder="Enter Description" id="description" name="description"></textarea>-->
                    <!--</div>-->
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="sendMessageBtn" class="btn btn-primary">Send NDA</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Send NDA-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
     
        .tags-inline.tagify__dropdown {
            z-index: 9999 !important; /* Ensure it is higher than the modal's z-index */
        }
    </style>
    <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>


<script>
    function send_proposal_whatsapp_func() {
         const box = document.getElementById("sd_prpl_whats_app");
        const input = document.getElementById("send_proposal_whatsapp");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_email_func() {
        const box = document.getElementById("sd_prpl_email");
        const input = document.getElementById("send_proposal_email");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_message_func() {
         const box = document.getElementById("sd_prpl_message");
        const input = document.getElementById("send_proposal_sms");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }
</script>

<script>
    function send_nda_func(id,email,mobile,customer_id,name,invoice_id,cus_id){
        $('#send_cus_name').text(name);
        $('#send_customer_id').text(customer_id);
        // $('#send_invoice_id').text(invoice_id);
        $('#send_proposal_id').val(id);
        $('#send_customer_id').val(cus_id);
        
        if (mobile && mobile.trim() !== "") {
            $('#sd_prpl_message').removeClass('d-none');
            $('#sd_prpl_whats_app').removeClass('d-none');
        } else {
            $('#sd_prpl_message').addClass('d-none');
            $('#sd_prpl_whats_app').addClass('d-none');
        }
    
        // Email check (show/hide Email button)
        if (email && email.trim() !== "") {
            $('#sd_prpl_email').removeClass('d-none');
        } else {
            $('#sd_prpl_email').addClass('d-none');
        }
    }
</script>

<script>
     $('#sendMessageBtn').on('click', function(e) {
        var err =0;
        e.preventDefault();
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        const proposal_id = $('#send_proposal_id').val();
        const customer_id = $('#send_customer_id').val();
        let sms = $('#send_proposal_sms').val();
        let email = $('#send_proposal_email').val();
        let whatsapp = $('#send_proposal_whatsapp').val();
        // const description = $('#description').val();

         var old_cus_check = document.getElementById("old_cus_check");
            var old_customer_check =  0;
            if (old_cus_check.checked) {
                sms =0;
                email =0;
                whatsapp = 0;
                old_customer_check=1;
            }else{
                 if(sms ==1 || email ==1 || whatsapp == 1){
                    $('#communication_err').text('');
                }else{
                    $('#communication_err').text('Please Select Any One Communication.!');
                    err++;
                }
            }

   

        if(err == 0){
              $('#sendMessageBtn').prop('disabled', true);
               $('#sendMessageBtn').text('Sending...');
            $.ajax({
                url: '/nda_message',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }, // Replace with your backend URL
                method: 'POST',
                data: JSON.stringify({
                    proposal_id: proposal_id,
                    customer_id: customer_id,
                    sms: sms,
                    email: email,
                    whatsapp: whatsapp,
                    old_customer_check: old_customer_check,
                    // description: description,
                }),
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        location.reload(); // Reload the page to update the UI
                        console.log(response)
                    } else {
                        toastr.error(response.message || 'Failed to send the message.');
                         $('#sendMessageBtn').prop('disabled', true);
                          resetButton();
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to send the message.';
                    toastr.error(errorMsg);
                     $('#sendMessageBtn').prop('disabled', true);
                      resetButton();
                }
            });
        }

         function resetButton() {
                $('#sendMessageBtn').prop('disabled', false);
                $('#sendMessageBtn').text('Send NDA');
            }
    });

    function formatCurrency(amt) {
        var roundedAmt = parseFloat(amt);
        var isWhole = Number.isInteger(roundedAmt);
    
        return roundedAmt.toLocaleString('en-IN', {
            minimumFractionDigits: isWhole ? 0 : 2,
            maximumFractionDigits: isWhole ? 0 : 2
        });
    }
      function formatDate(dateString) {
            let date = new Date(dateString); 
            let day = String(date.getDate()).padStart(2, '0'); 
            let monthIndex = date.getMonth();
            let year = date.getFullYear(); 

            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            let month = months[monthIndex]; 

            return `${day}-${month}-${year}`;
        }
</script>
<script>
old_cus_check_func()
   function old_cus_check_func(){
        var old_cus_check = document.getElementById("old_cus_check");
     
        if (old_cus_check.checked) {
           $('.communication_check').hide();
            
        } else{
            $('.communication_check').show();
        }
    }
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const clipboardList = [].slice.call(document.querySelectorAll('.cpy-btn'));

        if (ClipboardJS) {
            clipboardList.map(function(clipboardEl) {
                const clipboard = new ClipboardJS(clipboardEl);
                clipboard.on('success', function(e) {
                    if (e.action == 'copy') {
                        toastr['success']('', 'Copied to Clipboard!!');
                    }
                });
            });
        } else {
            clipboardList.map(function(clipboardEl) {
                clipboardEl.setAttribute('disabled', true);
            });
        }
    });
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

@endsection