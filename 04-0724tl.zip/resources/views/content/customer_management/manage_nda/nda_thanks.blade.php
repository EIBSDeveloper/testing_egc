@extends('layouts/blankLayout')

@section('title', 'Proposal Confirmation')
@section('content')

<style>


        .header {
            background: #D5CDFF;
            border-top-right-radius: 5px;
            border-top-left-radius: 5px;
            border-bottom-right-radius: 0px;
            border-bottom-left-radius: 0px;
        }



    table th,
    tr,
    td {
        border-collapse: collapse;
        border: 1px solid #ddd;
        padding: 5px;
    }

    @media (max-width: 576px) {
        .w-xs-25 {
            width: 25% !important;
        }

        .w-xs-50 {
            width: 50% !important;
        }

        .w-xs-75 {
            width: 75% !important;
        }

        .w-xs-100 {
            width: 100% !important;
        }

        h6.fs-1 {
            font-size: 1.5rem !important; /* smaller than desktop */
        }

        span.fs-5 {
            font-size: 0.9rem !important;
        }

        span.fs-6 {
            font-size: 0.8rem !important;
        }

        .responsive-img {
            width: 120px !important;
            height: 120px !important;
        }

        .p-5 {
            padding: 1.5rem !important; /* reduce padding on small screens */
        }

        .border {
            padding: 1rem !important;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) {

        .w-sm-25 {
            width: 25% !important;
        }

        .w-sm-50 {
            width: 50% !important;
        }

        .w-sm-75 {
            width: 75% !important;
        }

        .w-sm-100 {
            width: 100% !important;
        }

        .text-sm-center {
            text-align: center !important;
        }
    }

    /* Medium devices (tablets, 768px and up) */
    @media (min-width: 768px) {
        .w-md-25 {
            width: 25% !important;
        }

        .w-md-50 {
            width: 50% !important;
        }

        .w-md-75 {
            width: 75% !important;
        }

        .w-md-100 {
            width: 100% !important;
        }

        .text-md-center {
            text-align: center !important;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) {

        .w-lg-25 {
            width: 25% !important;
        }

        .w-lg-45 {
            width: 45% !important;
        }

        .w-lg-50 {
            width: 50% !important;
        }

        .w-lg-75 {
            width: 75% !important;
        }

        .w-lg-100 {
            width: 100% !important;
        }
    }

    .responsive-img {
        width: 200px;
        height: 200px;
    }

    @media (min-width: 768px) {
        .responsive-img {
            width: 500px;
            height: 500px;
        }
    }

    @media (min-width: 1024px) {
        .responsive-img {
            width: 300px;
            height: 300px;
        }
    }
</style>
<center>
  <div class="p-5 mt-0 w-lg-45 w-md-100 w-sm-100 bg-white">
    <div class="border border-gray-500i rounded p-10" style="position: relative;">

      <!-- Small logo at top-left corner -->
      <div class="mb-0" style="margin-left: 10px;">
          <img
            src="{{ asset('assets/phdizone_images/Agreement_Certificate.gif') }}"
            alt="NDA Signed"
            class="responsive-img image-input-wrapper"
            id="showlogo"
            style="max-width: 250px; height: auto;"
          >
      </div>


      <h6 class="text-center text-black fw-bold fs-1">NDA Agreement Confirmed</h6>

      <div class="mt-2">
         <span class="text-black text-center fs-5 d-block">
             <strong>Thank you!</strong> We sincerely appreciate your cooperation in completing the Non-Disclosure Agreement.
         </span>
         <span class="text-black text-center fs-5 d-block mt-2">
             Your trust is valued, and we're now ready to move forward securely and confidently.
         </span>
          <span class="text-center fs-7 d-block mt-2" style="color: red; font-weight: bold;">
            Your signed NDA PDF document will download shortly. You can view it after the download completes.
          </span>
      </div>
    </div>
  </div>
</center>

<script>
document.addEventListener("DOMContentLoaded", function() {
        let downloadUrl = @json($download_url); 
        // Automatically trigger download
        window.location.href = downloadUrl;
    });
</script>

@endsection
