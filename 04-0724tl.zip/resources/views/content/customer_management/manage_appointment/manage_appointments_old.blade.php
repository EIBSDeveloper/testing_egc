@extends('layouts/layoutMaster')

@section('title', 'Manage Appointments')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/plyr/plyr.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/libs/plyr/plyr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms_file_upload.js')
@vite('resources/assets/js/forms_tagify.js')
@endsection
@section('content')

@php
    $helper = new \App\Helpers\Helpers();
    $module_name = 'Customer Management';
    $menu_name = 'Customer Appointment';
    $loginStaff = auth()->user()->user_id;
@endphp

<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 7px !important;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Appointments</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center">
                            <i class="mdi mdi-home-outline text-body fs-4"></i>
                        </a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="{{ url('customer_management/manage_appointments') }}"
                            class="d-flex align-items-center">
                            Customer Management
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                @if(auth()->user()->hasPermission($module_name, 'Filter', $menu_name))
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1" id="filter" title="Filter">
                        <i class="mdi mdi-filter-outline text-white"></i>
                    </a>
                @endif
                @if(auth()->user()->hasPermission($module_name, 'Add', $menu_name))
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_apt_add">
                        <i class="mdi mdi-plus me-2"></i>Add Customer Appointment
                    </a>
                @endif
            </div>
        </div>
    </div>

    <div class="card-body px-4 py-0">
        <!-- Filter -->
        <div class="row mt-2">
            <div class="col-12">
                <div class="filter_tbox" style="display: none;">
                    <form id="filter_form" method="POST" action="/customer_management/manage_appointments">
                        @csrf
                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                        <input type="hidden" name="filter_on" value="1">
                        <input type="hidden" name="fill_chk" value="1">
                        <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter">
                        <div class="row py-1">
                            <input type="hidden" name="page" value="">
                            <div class="col-lg-3 mb-2">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Customer Name</label>
                                <select class="select3 form-select" id="customer_type_fill" name="customer_type_fill">
                                    <option value="">All</option>
                                    @if (!$customers->isEmpty())
                                    @foreach ($customers as $customer)
                                        <option value="{{$customer->sno}}" @if($customer_type_fill == $customer->sno) selected @endif >{{$customer->cus_name}} - {{$customer->customer_id}}</option>
                                    @endforeach
                                        
                                    @endif
                                </select>
                            </div>
                            <div class="col-lg-3 mb-2">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Appointment Mode</label>
                                <select class="select3 form-select" id="appointment_type_fill" name="appointment_type_fill">
                                    <option value="">All</option>
                                    @if (!$apps->isEmpty())
                                    @foreach ($apps as $app)
                                        <option value="{{$app->sno}}" @if($appointment_type_fill == $app->sno) selected @endif >{{$app->appointment_mode_name}}</option>
                                    @endforeach                                        
                                    @endif
                                </select>
                            </div>
                            <div class="col-lg-3 mb-2">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Connecting Way</label>
                                <select class="select3 form-select" id="connecting_type_fill" name="connecting_type_fill">
                                    <option value="">All</option>
                                    @if (!$ways->isEmpty())
                                    @foreach ($ways as $way)
                                        <option value="{{$way->sno}}" @if($connecting_type_fill == $way->sno) selected @endif >{{$way->connecting_way_name}}</option>
                                    @endforeach                                        
                                    @endif
                                </select>
                            </div>
                            <div class="col-lg-3 mb-2">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Staff Name</label>
                                <select class="select3 form-select" id="staff_type_fill" name="staff_type_fill">
                                    <option value="">All</option>
                                    @if (!$staffs->isEmpty())
                                    @foreach ($staffs as $staff)
                                        <option value="{{$staff->sno}}" @if($staff_type_fill == $staff->sno) selected @endif >{{$staff->staff_name}}</option>
                                    @endforeach                                        
                                    @endif
                                </select>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end mb-4 align-items-center">
                            <a href="{{ url('/customer_management/manage_appointments') }}"
                                class="btn btn-sm btn-secondary me-2 fw-semibold fs-6">Reset</a>
                            <button type="submit" class="btn btn-sm btn-primary">Go</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Table -->
        <div class="row">
            <div class="col-12 mb-2">
                @php $perpage_count = $perpage ?? 1; @endphp
                <span>Show</span>
                <br>
                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                    onchange="sort_filter(this.value);">
                    @foreach([10, 25, 100, 500] as $option)
                    <option value="{{ $option }}" {{ $perpage_count==$option ? 'selected' : '' }}>{{ $option }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                    <thead>
                        <tr class="bg-primary text-start align-top fw-bold fs-6">
                            <th class="min-w-150px">Date & Time</th>
                            <th class="min-w-100px">Customer</th>
                            <th class="min-w-100px">Appointment Mode</th>
                            <th class="min-w-100px">Assigned Staff</th>
                            @if(auth()->user()->hasPermission($module_name, 'Status Change', $menu_name))
                                <th class="min-w-100px">Appointment Status</th>
                            @endif
                            <th class="min-w-50px text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                            @foreach($appointments as $appointment)
                            <tr>
                                <td>
                                    @php
                                    $dt = \Carbon\Carbon::parse($appointment->appointment_date);
                                    @endphp
                                    <span class="fw-semibold fs-7 text-black" data-bs-toggle="tooltip"
                                        title="Appointment Date & Time">
                                        {{ $dt->format('d-M-Y') }} <span class="ms-2">{{ $dt->format('h:i A') }}</span>
                                    </span>
                                </td>
                                <td>
                                    <div class="text-black fw-semibold">{{ $appointment->name }}</div>
                                    <div class="fs-8 text-dark" title="Customer ID">{{ $appointment->id }}</div>
                                </td>
                                <td>
                                    <div>
                                        <span class="text-black fs-7 me-2">{{ $appointment->con_name }}</span>
                                        @if (!empty($appointment->connecting_link))
                                        <a href="{{ $appointment->connecting_link }}" target="_blank"
                                            class="badge text-black fs-10 rounded" style="background-color:#ace0ac;"
                                            title="Meeting Link">
                                            <i class="mdi mdi-link-variant"></i>
                                        </a>
                                        @endif
                                    </div>
                                    <div class="fs-8 text-dark fw-semibold">{{ $appointment->appointment_mode_name }}</div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        @if ($appointment->staff_image && file_exists(public_path('staff_images/' .
                                        $appointment->staff_image)))
                                        <img src="{{ asset('staff_images/' . $appointment->staff_image) }}" alt="Staff"
                                            class="rounded-circle me-2" width="35">
                                        @else
                                        <div class="symbol symbol-35px me-2">
                                            @php
                                            $initial = strtoupper(substr($appointment->nick_name, 0, 1));
                                            echo $helper->name_image($initial, $appointment->gender);
                                            @endphp
                                        </div>
                                        @endif
                                        <span class="mt-1">{{ $appointment->staff_name }}</span>
                                    </div>
                                </td>
                                @if(auth()->user()->hasPermission($module_name, 'Status Change', $menu_name))
                                    @php
                                        $status = $appointment->status ?? 0;
                                    @endphp
                                    @if($loginStaff == $appointment->staff_id)
                                        <td>
                                            @if($status == 0)
                                                <div class="dropdown">
                                                    <a href="javascript:;" class="badge bg-warning text-black fw-semibold fs-8" data-bs-toggle="dropdown">
                                                        Appointment Scheduled
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-end">
                                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_apt_completed" onclick="getAppointmentDetails('{{$appointment->sno}}')">
                                                            Appointment Completed
                                                        </a>
                                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" onclick="getAppointmentDetails('{{$appointment->sno}}')" data-bs-target="#kt_modal_apt_cancelled">
                                                            Appointment Cancelled
                                                        </a>
                                                    </div>
                                                </div>
                                            @elseif($status == 3)
                                            <div class="dropdown">
                                                <a href="javascript:;" class="badge bg-danger text-white fw-semibold fs-8" data-bs-toggle="dropdown">Appointment
                                                    Cancelled</a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        onclick="getAppointmentDetails('{{$appointment->sno}}')"
                                                        data-bs-target="#kt_modal_apt_Re_schedule">Reschedule Appointment</a>
                                                </div>
                                            </div>
                                            @elseif($status == 1)
                                            <span class="badge bg-success text-black fw-semibold fs-8">Appointment Completed</span>
                                            @elseif($status == 4)
                                            <span class="badge bg-info text-white fw-semibold fs-8">Appointment Re-Scheduled</span>
                                            @endif
                                        </td>
                                    @else
                                        <td>
                                            @if ($status == 0)
                                                <a href="javascript:;" class="badge bg-warning text-black fw-semibold fs-8">
                                                    Appointment Scheduled
                                                </a>
                                            @elseif ($status == 3)
                                                <a href="javascript:;" class="badge bg-danger text-white fw-semibold fs-8" data-bs-toggle="dropdown">Appointment
                                                    Cancelled</a>
                                            @elseif ($status == 1)
                                                <span class="badge bg-success text-black fw-semibold fs-8">Appointment Completed</span>
                                            @elseif ($status == 4)
                                                <span class="badge bg-info text-white fw-semibold fs-8">Appointment Re-Scheduled</span>
                                            @endif
                                        </td>
                                    @endif
                                @endif                        
                                <td class="text-end">
                                    @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                        <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_view_appointment"
                                            onclick="viewAppointment('{{ $appointment->sno }}')">
                                            <i class="mdi mdi-eye-outline fs-3 text-black" title="View"></i>
                                        </a>
                                    @endif
                                    @if(auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                                        <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" onclick="editAppointment('{{$appointment->sno}}')" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_apt_edit">
                                            <i class="mdi mdi-square-edit-outline fs-3 text-black" title="Edit"></i>
                                        </a>
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
                <div class="mt-4">
                    {{ $appointments->appends(request()->except(['page', '_token']))->links() }}
                </div>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Appointment Add-->
<div class="modal fade" id="kt_modal_apt_add" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-8 text-black">Create Customer Appointment </h3>
                </div>
                <form action="{{route('create_customer_appointments')}}" method="POST" id="add_appointment_form">
                    @csrf
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Date & Time<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="appointment_date" name="appointment_date" placeholder="Select Date"
                                    class="form-control common_date_time_class" />
                                </div>
                            <p id="date_error" class="text-danger"></p>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer<span
                                    class="text-danger">*</span></label>
                            <select id="customer_id" name="customer_id" class="select3 form-select">
                                <option value="">Select Customer</option>
                                @foreach ($customers as $customer)
                                <option value="{{$customer->sno}}">{{$customer->cus_name}} - {{$customer->customer_id}}</option>                                
                                @endforeach
                            </select>
                            <p id="customer_error" class="text-danger"></p>
                        </div>
                        <div class="col-lg-6 mb-3 ">
                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Mode<span
                                    class="text-danger">*</span></label>
                            <select id="appointment_mode_id" name="appointment_mode_id" class="select3 form-select">
                                <option value="">Select Appointment Mode</option>
                                @foreach ($apps as $app)
                                <option value="{{$app->sno}}">{{$app->appointment_mode_name}}</option>                                
                                @endforeach
                            </select>
                            <p id="app_error" class="text-danger"></p>
                        </div>
                        <div class="col-lg-6 mb-3 connecting-fields">
                            <label class="text-black mb-1 fs-6 fw-semibold">Connecting Way<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="connecting_way_id" name="connecting_way_id">
                                <option value="">Select Connecting Way</option>
                                @foreach($ways as $way)
                                <option value="{{$way->sno}}">{{$way->connecting_way_name}}</option>
                                @endforeach
                            </select>
                            <p id="connect_error" class="text-danger"></p>
                        </div>
                        <div class="col-lg-6 mb-3 connecting-fields" id="connectingLinkWrapper" style="display:none;">
                            <label class="text-black mb-1 fs-6 fw-semibold">Connecting Link<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="connectingLink" name="connectingLink"
                                placeholder="Enter Connecting Link" />
                            <p id="url_error" class="text-danger"></p>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select id="staff_id" name="staff_id" class="select3 form-select">
                                <option value="">Select Assigned Staff</option>
                                @foreach($staffs as $staff)
                                    <option value="{{$staff->sno}}">{{$staff->staff_name}}</option>
                                @endforeach
                            </select>
                            <p id="staff_error" class="text-danger"></p>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="1" id="appointment_reason" name="appointment_reason" placeholder="Enter Appointment Reason"></textarea>
                            <p id="reason_error" class="text-danger"></p>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="3" id="" name="appointment_desc" placeholder="Enter Your Description"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create Customer
                            Appointment</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Appointment Add -->

<!--begin::Modal - Appointment Completed-->
<div class="modal fade" id="kt_modal_apt_completed" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Appointment Completed</h3>
                </div>
                <form action="{{route('complete_appointments')}}" method="POST" enctype="multipart/form-data" id="completed_form">
                    @csrf
                    <input type="hidden" name="uploaded_files" id="uploaded_files">
                    <div class="row mb-3">
                        <input type="hidden" name="completed_id" id="completed_id">
                        <label class="col-4 text-dark fs-6 fw-semibold">Appointment Date & Time</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <div class="col-6">
                            <label class="badge bg-warning text-black fs-6 fw-bold" id="completed_date">15-Jun-2025 10:00 AM</label>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="completed_cus_name">Priya</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="completed_cus_num">+91 9876543210</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Appointment Category">Appointment Mode </label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="completed_app">Online</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Appointment Category">Appointment Conecting Way </label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold d-flex"> <span class="me-2" id="completed_con">Zoom</span>
                            <div id="completedLinkWrapper">
                                <a href="https://us02web.zoom.us/j/12345678901?pwd=abcdefghijklmno" id="completed_link"
                                    class=" fs-10 text-black badge rounded" style="background-color:#ace0ac"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Meeting Link"><span
                                        class="mdi mdi-link-variant"></span>
                                </a>
                            </div>
                        </label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Assigned Staff</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="completed_staff">Naveen</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Appointment Reason</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="completed_reason">Initial Discussion</label>
                    </div>
                    <div class="row  px-1 py-2">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Appoinment Summary<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3" id="" name="summary" placeholder="Enter Description"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Documents<span class="text-danger">*</span></label>
                            <div id="dropArea" class="border border-4 border-dashed p-5 text-center rounded">
                                <p class="mb-2">Drag & Drop your files here or click to select</p>
                                <!-- REMOVE name="file_upload[]" here -->
                                <input type="file" id="fileInput" class="d-none" multiple />
                                <button type="button" class="btn btn-outline-primary"
                                    onclick="document.getElementById('fileInput').click()">Browse Files</button>
                            </div>
                            <div id="fileList" class="text-muted mt-2"></div>
                            <div class="text-danger" id="err_mssg"></div>              
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Appointment Completed</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Appointment Completed -->

<!--begin::Modal - Appointment Cancelled-->
<div class="modal fade" id="kt_modal_apt_cancelled" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Appointment Cancelled</h3>
                </div>
                <form id="cancellAppointmentForm">
                    <div class="row mb-3">
                        <input type="hidden" name="cancel_id" id="cancel_id">
                        <label class="col-4 text-dark fs-6 fw-semibold">Appointment Date</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <div class="col-6">
                            <label class="badge bg-warning text-black fs-6 fw-bold" id="cancel_date">15-Jun-2025 10:00 AM</label>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="cancel_cus_name">Priya</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="cancel_cus_num">+91 9876543210</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Appointment Category">Appointment Mode </label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="cancel_app">Online</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Appointment Category">Appointment Conecting Way </label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold d-flex"> <span class="me-2" id="cancel_con">Zoom</span>
                            <div id="cancelLinkWrapper">
                            <a href="https://us02web.zoom.us/j/12345678901?pwd=abcdefghijklmno" id="cancel_link"
                                class=" fs-10 text-black badge rounded" style="background-color:#ace0ac"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Meeting Link"><span
                                    class="mdi mdi-link-variant"></span></a>
                                </div>
                        </label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Assigned Staff</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="cancel_staff">Naveen</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Appointment Reason</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="cancel_reason">Initial Discussion</label>
                    </div>
                    <div class="row mt-6">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Cancel Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3"
                                placeholder="Enter Appointment Cancel Reason" name="appointment_cancel" id="appointment_cancel"></textarea>
                            <p id="cancel_reason_err" class="text-danger"></p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Appointment Cancelled</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Appointment Cancelled -->

<!--begin::Modal - Appointment Re-schedule-->
<div class="modal fade" id="kt_modal_apt_Re_schedule" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Appointment Re-schedule</h3>
                </div>
                <form id="reschedule_form">
                    <div class="row mb-3">
                        <input type="hidden" id="reschedule_id" name="reschedule_name">
                        <label class="col-4 text-dark fs-6 fw-semibold">Appointment Date</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <div class="col-6">
                            <label class="badge bg-warning text-black fs-6 fw-bold" id="reschedule_date">15-Jun-2025 10:00 AM</label>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="reschedule_cus_name">Priya</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="reschedule_cus_num">+91 9876543210</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Appointment Category">Appointment Mode </label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="reschedule_app">Online</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Appointment Category">Appointment Conecting Way </label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold d-flex"> <span class="me-2" id="reschedule_con">Zoom</span>
                            <div id="rescheduleLinkWrapper">
                                <a href="https://us02web.zoom.us/j/12345678901?pwd=abcdefghijklmno" id="reschedule_link"
                                class=" fs-10 text-black badge rounded" style="background-color:#ace0ac"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Meeting Link"><span
                                class="mdi mdi-link-variant"></span></a>
                            </div>
                        </label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Assigned Staff</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="reschedule_staff">Naveen</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Appointment Reason</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="reschedule_reason">Initial Discussion</label>
                    </div>
                    <div class="row mt-6">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Re-schedule Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3"
                                placeholder="Enter Appointment Re-schedule Reason" name="appointment_reschedule_reason" id="appointment_reschedule_reason"></textarea>
                            <p id="reschedule_reason_err" class="text-danger"></p>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Appointment Re-Schedule Date & Time<span
                                class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="re-schedule_appointment_detail" name="appointment_reschedule_date"
                                class="form-control common_date_time_class" />
                            <p id="reschedule_date_err" class="text-danger"></p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Appointment Re-Schedule</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Appointment Re-schedule -->

<!--begin::Modal - View Appointment-->
<div class="modal fade" id="kt_modal_view_appointment" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">
                        <span>View Customer Appointment</span>
                        <span class="ms-1 me-1">-</span>
                        <span class="badge bg-warning rounded text-black fw-semibold fs-5" id="title-main">Scheduled</span>
                    </h3>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Appointment Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-6">
                        <label class="badge bg-warning text-black fs-6 fw-bold" id="view_app_date"></label>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="view_cus_name"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="cus_num"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Appointment Category">Appointment Mode </label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="view_app_name"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Appointment Category">Appointment Conecting Way </label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold d-flex"> <span class="me-2" id="view_con_name"></span>
                        <span id="viewLinkWrapper">
                            <a id="view_link" href="https://us02web.zoom.us/j/12345678901?pwd=abcdefghijklmno"
                                class=" fs-10 text-black badge rounded" style="background-color:#ace0ac"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Meeting Link"><span
                                    class="mdi mdi-link-variant"></span>
                            </a>
                         </span>
                    </label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Assigned Staff</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="view_staff_name"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Appointment Reason</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="view_app_reason"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Description</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold" id="view_app_desc"></label>
                </div>
                <div class="re-schedule-container">
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Re-Scheduled Date</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="cancel-schedule-date">09-Jun-2025 10:00 Am.</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Re-Scheduled Reason</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="view_app_cancel_reason"></label>
                    </div>
                </div>
                <div class="cancelled-container">
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Cancelled Reason</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold" id="cancel-app-reason">The meeting is cancelled due to unforeseen
                            circumstances.</label>
                    </div>
                </div>
                <div class="completed-container">
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Describe Appointment</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-6 text-black text-justify fs-6 fw-bold" id="completed-app-reason">
                            The appointment was completed successfully with professionalism and
                            clear communication. All objectives were met, making the session productive and valuable.
                        </label>
                    </div>
                    <div class="col-lg-6">
                        <div class="row mb-4">
                            <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Attachment</label>
                            <div class="col-12 mb-1">
                                <div class="border border-gray-600i border-dashed rounded py-1 px-1">
                                    <div id="attachmentContainer" class="d-flex mb-1 align-items-center flex-wrap">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>        
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Appointment -->

<!--begin::Modal - View complete Appointment-->
<div class="modal fade" id="kt_modal_view_com_appointment" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">
                        <span>View Customer Appointment</span>
                        <span class="ms-1 me-1">-</span>
                        <span class="badge bg-success rounded text-black fw-semibold fs-5">completed</span>
                </div>
                <div class="row mb-3">
                    <label class="col-5 text-dark fs-6 fw-semibold">Appointment Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-6">
                        <label class="badge bg-warning text-black fs-6 fw-bold">10-Jun-2025 12:00 AM</label>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-5 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">Monish</label>
                </div>
                <div class="row mb-3">
                    <label class="col-5 text-dark fs-6 fw-semibold">Mobile</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">+91 9876543210</label>
                </div>
                <div class="row mb-3">
                    <label class="col-5 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Appointment Category">Appointment Mode </label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">Online</label>
                </div>
                <div class="row mb-3">
                    <label class="col-5 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Appointment way">Appointment Conecting Way </label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">Zoom</label>
                </div>
                <div class="row mb-3">
                    <label class="col-5 text-dark fs-6 fw-semibold">Assigned Staff</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">Naveen</label>
                </div>
                <div class="row mb-3">
                    <label class="col-5 text-dark fs-6 fw-semibold">Appointment Reason</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">Initial Discussion</label>
                </div>
                <div class="row mb-3">
                    <label class="col-5 text-dark fs-6 fw-semibold">Describe Appointment</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">The appointment was completed successfully with
                        professionalism and clear communication. All objectives were met, making the session productive
                        and valuable.</label>
                </div>
                    
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View complete Appointment -->

<!--begin::Modal - edit Appointment-->

<div class="modal fade" id="kt_modal_apt_edit" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-8 text-black">Update Customer Appointment</h3>
                </div>
                <form action="{{route('update_manage_appointments')}}" method="POST" id="edit_appointment_form">
                    @csrf
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <input type="hidden" name="edit_id" id="edit_id">
                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Date & Time<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline  fs-4"></i></span>
                                <input type="text" id="edit_appointment_date" name="edit_appointment_date" placeholder="Select Date"
                                    class="form-control common_date_time_class" />
                                    <p id="edit_date_err" class="text-danger"></p>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer<span
                                    class="text-danger">*</span></label>
                            <select id="edit_customer_id" name="edit_customer_name" class="select3 form-select">
                                <option value="">Select Customer</option>
                                @foreach ($customers as $customer)
                                    <option value="{{$customer->sno}}">{{$customer->cus_name}}</option>
                                @endforeach
                            </select>
                            <p id="edit_cus_err" class="text-danger"></p>
                        </div>
                        <div class="col-lg-6 mb-3 ">
                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Mode<span
                                    class="text-danger">*</span></label>
                            <select id="edit_appointment_id" name="edit_appointment_id" class="select3 form-select">
                                <option value="">Select Appointment Mode</option>
                                @foreach ($apps as $app)
                                    <option value="{{$app->sno}}">{{$app->appointment_mode_name}}</option>
                                @endforeach
                            </select>
                            <p id="edit_app_err" class="text-danger"></p>
                        </div>
                        <div class="col-lg-6 mb-3 connecting-fields-edit">
                            <label class="text-black mb-1 fs-6 fw-semibold">Connecting Way<span
                                    class="text-danger">*</span></label>
                            <select id="edit_connecting_way_id" name="edit_connecting_way_id" class="select3 form-select">
                                <option value="">Select Connecting Way</option>
                                @foreach ($ways as $way)
                                    <option value="{{$way->sno}}">{{$way->connecting_way_name}}</option>
                                @endforeach
                            </select>
                            <p id="edit_con_err" class="text-danger"></p>
                        </div>
                        <div class="col-lg-6 mb-3 connecting-fields-edit" id="edit_selectWrapper" style="display:none;">
                            <label class="text-black mb-1 fs-6 fw-semibold">Connecting Link<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="edit_connectingLink" name="edit_connectingLink" placeholder="Enter Connecting Link"
                                value="www.googleZoomMeeting.com" />
                            <p id="edit_link_err" class="text-danger"></p>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select id="edit_staff_id" name="edit_staff_id" class="select3 form-select">
                                <option value="">Select Assigned Staff</option>
                                @foreach ($staffs as $staff)
                                    <option value="{{$staff->sno}}">{{$staff->staff_name}}</option>
                                @endforeach
                            </select>
                            <p id="edit_staff_err" class="text-danger"></p>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                            <textarea class="form-control" rows="1" id="edit_reason" name="edit_reason"
                                placeholder="Enter Reason">Intial Discussion</textarea>
                            <p id="edit_reason_err" class="text-danger"></p>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="3" name="edit_desc" id="edit_desc">-</textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Customer
                            Appointment</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - edit Appointment -->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr container */
    .toast {
        background-color: #313f46;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
</style>
<script>
    // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
</script>

<script>
    document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
      el.addEventListener('click', function () {
        // Small delay to allow modal animation to finish
        setTimeout(() => {
          location.reload();
        }, 150);
      });
    });
</script>

<script>
$(document).ready(function() {

    $(".common_date_time_class").flatpickr({
        enableTime: true,
        dateFormat: 'Y-m-d h:i K', // 12-hour format with AM/PM
        defaultDate: new Date(),
        time_24hr: false // Ensure 12-hour clock
    });
});
</script>

<script>
    $(document).ready(function() {
        @if($filter_on ?? '')
        $('.filter_tbox').slideToggle('fast');
        // });
        @endif
    });

    // Toggle branch filter section
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });

</script>

<script>
    function sort_filter(val) {
          if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#filter_form').submit();
          } else {
            $('.sorting_filter_class').val(25);
            $('#filter_form').submit();
          }
        }
</script>

<script>
    $(".list_page").DataTable({
      "ordering": false,
      "paging": false,
      // "aaSorting":[],
      "language": {
          "lengthMenu": "Show _MENU_"
      , }
      ,"dom": "<'row mb-3'" +
        //   "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
        //   "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
          ">" +

          "<'table-responsive'tr>" +

          "<'row'" +
        //   "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
        //   "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
          ">"
    });
</script>


<script>
    $(document).ready(function() {
    $('#appointmentMode2').on('change', function() {
      const selectedMode = $(this).val();
      if (selectedMode === '1') {
        $('.connecting-fields-edit').show();
      } else {
        $('.connecting-fields-edit').hide();
      }
    });
  })
</script>
<script>
    $(document).ready(function() {
    // Listen for change on any radio button with name 'appointment_mode'
    $('input[name="appointment_mode"]').on('change', function() {
      if ($('input[name="appointment_mode"]:checked').val() === '1') {
        $('.connecting-fields').show();
      } else {
        $('.connecting-fields').hide();
      }
    });

    // Optionally, trigger change event on page load to set initial state
    $('input[name="appointment_mode"]:checked').trigger('change');
  });
</script>
<script>
    $(document).ready(function() {
    // Listen for change on any radio button with name 'appointment_mode_edit'
    $('input[name="appointment_mode_edit"]').on('change', function() {
      if ($('input[name="appointment_mode_edit"]:checked').val() === '1') {
        $('.edit_connecting-fields').show();
      } else {
        $('.edit_connecting-fields').hide();
      }
    });

    // Trigger change event on page load to set initial state
    $('input[name="appointment_mode_edit"]:checked').trigger('change');
  });
</script>

<script>
    $(document).ready(function() {
        $('#connecting_way_id').on('select2:select', function (e) {
            const selectedId = $(this).val();
            
            const selectWrapper = document.getElementById('connectingLinkWrapper');
            
            if (!selectedId) {
                selectWrapper.style.display = 'none';
                return;
            }
            
            fetch(`/connecting_way_fetch/${selectedId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
            })
            .then(response => response.json())
            .then(data => {
                if (data.url_link === 1) {
                    selectWrapper.style.display = 'block';
                } else {
                    selectWrapper.style.display = 'none';
                }
            })
            .catch(error => {
                console.error('Error Fetching:', error);
                selectWrapper.style.display = 'none';
            });
        });
    });
</script>

<script>
    $(document).ready(function(){
        $('#add_appointment_form').on('submit', (e) => {
            let isValid = true;

            // Date Validation
            $('#date_error').text('');
            const dateVal = $('#appointment_date').val();
            if(!dateVal){
                $('#date_error').text('Please Select The Appointment Date');
                isValid = false;
            } else {
                const parsedDate = Date.parse(dateVal);
                if(isNaN(parsedDate)){
                    $('#date_error').text('Please Enter A Valid Date And Time.');
                    isValid = false;
                }
            }

            // Customer Validation
            $('#customer_error').text('');
            if($('#customer_id').val() === '' ){
                $('#customer_error').text('Please Select The Customer.');
                isValid = false;
            }

            // Appointment Mode Validation
            $('#app_error').text('');
            if($('#appointment_mode_id').val() === ''){
                $('#app_error').text('Please Select The Appointment Mode.');
                isValid = false;
            }

            // Connecting Way Validation
            $('#connect_error').text('');
            if($('#connecting_way_id').val() === ''){
                $('#connect_error').text('Please Select The Connecting Way.');
                isValid = false;
            }

            // Connecting URL Validation
            $('#url_error').text('');
            if($('#connectingLinkWrapper').is(':visible')){
                const urlVal = $('#connectingLink').val().trim();
                if(urlVal === ''){
                    $('#url_error').text('Please Enter The Connecting URL.');
                    isValid = false;
                } else {
                    try{
                        new URL(urlVal);
                    } catch (_){
                        $('#url_error').text('Please Enter A Valid URL.');
                        isValid = false;
                    }
                }
            }

            // Staff Validation
            $('#staff_error').text('');
            if($('#staff_id').val() === ''){
                $('#staff_error').text('Please Select The Staff.');
                isValid = false;
            }

            // Appointment Reason Validation
            $('#reason_error').text('');
            if($('#appointment_reason').val() === ''){
                $('#reason_error').text('Please Enter The Appointment Reason.');
                isValid = false;
            }

            // Stop Submitting Form
            if(!isValid){
                e.preventDefault();
            }
        });
    });

</script>

<script>
    // View Appointment
    function viewAppointment(id) {
    fetch(`/view_manage_appointments/${id}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(response => response.json())
    .then(data => {
        if(data.status === 200) {
            var app = data.data;

            function formatDate(date) {
                const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                let day = date.getDate().toString().padStart(2, '0');
                let month = months[date.getMonth()];
                let year = date.getFullYear();

                let hours = date.getHours();
                let minutes = date.getMinutes().toString().padStart(2, '0');

                let ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12;
                hours = hours.toString().padStart(2, '0');

                return `${day}-${month}-${year} ${hours}:${minutes} ${ampm}`;
            }

            var formattedDate = formatDate(new Date(app.appointment_date));
            var formatteDate = formatDate(new Date(app.reschedule_date));

            $('#view_app_date').text(formattedDate);
            $('#view_cus_name').html(app.name);
            $('#cus_num').html(app.cus_mobile);
            $('#view_app_name').html(app.appointment_mode_name);
            $('#view_con_name').html(app.con_name);

            if(app.connecting_link && app.connecting_link.trim() !== '') {
                $('#view_link').attr('href', app.connecting_link);
                $('#viewLinkWrapper').show();
            } else {
                $('#viewLinkWrapper').hide();
            }

            $('#view_staff_name').html(app.staff_name);
            $('#view_app_reason').html(app.appointment_reason);
            $('#view_app_desc').html(app.appointment_desc ?? '-');
            $('#view_app_cancel_reason').html(app.reschedule_reason);
            $('#cancel-app-reason').html(app.appointment_cancel_reason);
            $('#completed-app-reason').html(app.appointment_summary);

            if(app.status === 4) {
                $('#title-main').text('Re-Scheduled')
                    .removeClass('bg-warning text-black')
                    .addClass('bg-info text-white');
                $('#cancel-schedule-date').text(formatteDate);
                $('.re-schedule-container').show();
                $('.cancelled-container, .completed-container').hide();
            } else if(app.status === 3) {
                $('#title-main').text('Cancelled')
                    .removeClass('bg-warning text-black')
                    .addClass('bg-danger text-white');
                $('.cancelled-container').show();
                $('.completed-container, .re-schedule-container').hide();
            } else if(app.status === 1) {
                $('#title-main').text('Completed')
                    .removeClass('bg-warning')
                    .addClass('bg-success');
                $('.completed-container').show();
                $('.cancelled-container, .re-schedule-container').hide();
            } else {
                $('.completed-container, .cancelled-container, .re-schedule-container').hide();
            }

            // ATTACHMENTS:
            const projectAttachments = document.getElementById('attachmentContainer');
            projectAttachments.innerHTML = '';

            // Your uploaded_files is a JSON string, parse if needed
            let attachmentsArray = [];
            if (app.uploaded_files) {
                if (typeof app.uploaded_files === 'string') {
                    try {
                        attachmentsArray = JSON.parse(app.uploaded_files);
                    } catch (e) {
                        console.error('Error parsing uploaded_files:', e);
                    }
                } else if (Array.isArray(app.uploaded_files)) {
                    attachmentsArray = app.uploaded_files;
                }
            }

            function getStoredFilename(originalName) {
                // Example heuristic to fix filename:
                // This must match your storage naming convention!
                // Here: take last 12 chars before extension + extension
                const ext = originalName.split('.').pop();
                const base = originalName.slice(-16, -4); // Adjust this based on your real pattern
                if(!base) return originalName; // fallback
                return base + '.' + ext;
            }

            if (attachmentsArray.length > 0) {
                attachmentsArray.forEach(file => {
                    if (typeof file !== 'string') return;

                    const storedFile = getStoredFilename(file.trim());
                    const extension = storedFile.split('.').pop().toLowerCase();
                    const fileUrl = `/appointments/${encodeURIComponent(storedFile)}`;

                    let attachmentHTML = '';

                    if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(extension)) {
                        attachmentHTML = `
                        <div class="d-block overlay text-center me-1 px-2 py-2">
                            <a href="${fileUrl}" target="_blank" download
                                class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                <img src="${fileUrl}" alt="Image Attachment" class="h-75px w-75px" />
                            </a>
                        </div>`;
                    } else if (extension === 'pdf') {
                        attachmentHTML = `
                        <div class="d-block overlay text-center me-1 px-2 py-2">
                            <a href="${fileUrl}" target="_blank" download
                                class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                <img src="/assets/phdizone_images/def_pdf.png" alt="PDF" class="h-75px w-75px" />
                            </a>
                        </div>`;
                    } else if (['doc', 'docx'].includes(extension)) {
                        attachmentHTML = `
                        <div class="d-block overlay text-center me-1 px-2 py-2">
                            <a href="${fileUrl}" target="_blank" download
                                class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                <img src="/assets/phdizone_images/def_doc.png" alt="DOC" class="h-75px w-75px" />
                            </a>
                        </div>`;
                    } else if (['xls', 'xlsx'].includes(extension)) {
                        attachmentHTML = `
                        <div class="d-block overlay text-center me-1 px-2 py-2">
                            <a href="${fileUrl}" target="_blank" download
                                class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                <img src="/assets/phdizone_images/def_excel.png" alt="Excel" class="h-75px w-75px" />
                            </a>
                        </div>`;
                    } else if (['sql', 'txt', 'csv', 'json'].includes(extension)) {
                        attachmentHTML = `
                        <div class="d-block overlay text-center me-1 px-2 py-2">
                            <a href="${fileUrl}" target="_blank" download
                                class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                <img src="/assets/phdizone_images/def_code.png" alt="Text File" class="h-75px w-75px" />
                            </a>
                        </div>`;
                    } else {
                        attachmentHTML = `
                        <div class="d-block overlay text-center me-1 px-2 py-2">
                            <a href="${fileUrl}" target="_blank" download
                                class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                <img src="/assets/phdizone_images/def_file.jpeg" alt="File" class="h-75px w-75px" />
                            </a>
                        </div>`;
                    }

                    projectAttachments.insertAdjacentHTML('beforeend', attachmentHTML);
                });
            } else {
                projectAttachments.innerHTML = '<span class="text-muted">No submitted documents found.</span>';
            }
        }
    })
    .catch(error => {
        console.log('Error Fetching Data :', error);
    });
}


</script>

<script>
    // Edit Appointment
    function editAppointment(id){
        fetch(`/edit_manage_appointments/${id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        })
        .then(response => response.json())
        .then(data => {
            if(data.status === 200){
                var appointment = data.data;

                $('#edit_id').val(appointment.sno);
                $('#edit_customer_id').val(appointment.customer_id).change();
                $('#edit_appointment_id').val(appointment.appointment_mode_id).change();
                $('#edit_connecting_way_id').val(appointment.connecting_way_id).change();
                $('#edit_connectingLink').val(appointment.connecting_link);
                $('#edit_staff_id').val(appointment.staff_id).change();
                $('#edit_reason').val(appointment.appointment_reason);
                $('#edit_desc').val(appointment.appointment_desc ?? '-' );

                if(appointment.appointment_date){
                    const fp = document.querySelector('#edit_appointment_date')._flatpickr;
                    if(fp){
                        fp.setDate(new Date(appointment.appointment_date), true, "Y-m-d h:i K");
                    } else {
                        $('#edit_appointment_date').val(appointment.appointment_date);
                    }
                }

            } else {
                console.log('ERROR :', data.error_msg);
            }
        })
        .catch(error => {
            console.log('Error Fetching Data :', error);
        });
    }
</script>

<script>
    $(document).ready(function() {
        $('#edit_connecting_way_id').on('select2:select', function (e) {
            const selectedId = $(this).val();
            const selectWrapper = document.getElementById('edit_selectWrapper');
            const connectingLinkInput = document.getElementById('edit_connectingLink');

            if (!selectedId) {
                selectWrapper.style.display = 'none';
                connectingLinkInput.value = ''; // Clear the input
                return;
            }

            fetch(`/edit_connecting_way_fetch/${selectedId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.url_link === 1) {
                    selectWrapper.style.display = 'block';
                } else {
                    selectWrapper.style.display = 'none';
                    connectingLinkInput.value = ''; // Clear the input
                }
            })
            .catch(error => {
                console.error('Error Fetching:', error);
                connectingLinkInput.value = ''; // Clear on error too
            });
        });
    });
</script>

<script>
    // Edit Validation
    $(document).ready(function(){
        $('#edit_appointment_form').on('submit', (e) => {
            let isValid = true;
            
            // Date Validation
            $('#edit_date_err').text('');
            const dateVal = $('#edit_appointment_date').val();
            if(!dateVal){
                $('#edit_date_err').text('Please Select The Appointment Date');
                isValid = false;
            } else {
                const parsedDate = Date.parse(dateVal);
                if(isNaN(parsedDate)){
                    $('#edit_date_err').text('Please Enter A Valid Date And Time.');
                    isValid = false;
                }
            }
            
            // Customer Validation
            $('#edit_cus_err').text('');
            if($('#edit_customer_id').val() === '' ){
                $('#edit_cus_err').text('Please Select The Customer.');
                isValid = false;
            }
            
            // Appointment Mode Validation
            $('#edit_app_err').text('');
            if($('#edit_appointment_id').val() === ''){
                $('#edit_app_err').text('Please Select The Appointment Mode.');
                isValid = false;
            }
            
            // Connecting Way Validation
            $('#edit_con_err').text('');
            if($('#edit_connecting_way_id').val() === ''){
                $('#edit_con_err').text('Please Select The Connecting Way.');
                isValid = false;
            }
            
            // Connecting URL Validation
            $('#edit_link_err').text('');
            if($('#edit_selectWrapper').is(':visible')){
                const urlVal = $('#edit_connectingLink').val().trim();
                if(urlVal === ''){
                    $('#edit_link_err').text('Please Enter The Connecting URL.');
                    isValid = false;
                } else {
                    try{
                        new URL(urlVal);
                    } catch (_){
                        $('#edit_link_err').text('Please Enter A Valid URL.');
                        isValid = false;
                    }
                }
            }
            
            // Staff Validation
            $('#edit_staff_err').text('');
            if($('#edit_staff_id').val() === ''){
                $('#edit_staff_err').text('Please Select The Staff.');
                isValid = false;
            }
            
            // Appointment Reason Validation
            $('#edit_reason_err').text('');
            if($('#edit_reason').val() === ''){
                $('#edit_reason_err').text('Please Enter The Appointment Reason.');
                isValid = false;
            }
            
            // Stop Submitting Form
            if(!isValid){
                e.preventDefault();
            }
        });
    });
</script>

<script>
    function getAppointmentDetails(id){
        fetch(`/getAppointmentDetails/${id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        })
        .then(response => response.json())
        .then(data => {
            if(data.status === 200){
                    var app = data.data;
                    
                    // Formatting Date
                    var rawDate = new Date(app.appointment_date);
                    
                    function formatDate(date) {
                    const months = [
                    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
                    ];
                    
                    let day = date.getDate().toString().padStart(2, '0');
                    let month = months[date.getMonth()];
                    let year = date.getFullYear();
                    
                    let hours = date.getHours();
                    let minutes = date.getMinutes().toString().padStart(2, '0');
                    
                    let ampm = hours >= 12 ? 'PM' : 'AM';
                    hours = hours%12;
                    hours = hours ? hours : 12;
                    hours = hours.toString().padStart(2, '0');
                    
                    return `${day}-${month}-${year} ${hours}:${minutes} ${ampm}`;
                    }
                    
                    var formattedDate = formatDate(rawDate);
                    
                    // Fetch data for appointment cancelled
                    $('#cancel_id').val(app.sno);
                    $('#cancel_date').text(formattedDate);
                    $('#cancel_cus_name').html(app.name);
                    $('#cancel_cus_num').html(app.cus_mobile);
                    $('#cancel_app').html(app.appointment_mode_name);
                    $('#cancel_con').html(app.con_name);
                    
                    if(app.connecting_link && app.connecting_link.trim() !== ''){
                        $('#cancel_link').attr('href', app.connecting_link);
                        $('#cancelLinkWrapper').show();
                    } else {
                        $('#cancelLinkWrapper').hide();
                    }
                    
                    $('#cancel_staff').html(app.staff_name);
                    $('#cancel_reason').html(app.appointment_reason);

                    // Fetch data for appointment completed
                    $('#completed_id').val(app.sno);
                    $('#completed_date').text(formattedDate);
                    $('#completed_cus_name').html(app.name);
                    $('#completed_cus_num').html(app.cus_mobile);
                    $('#completed_app').html(app.appointment_mode_name);
                    $('#completed_con').html(app.con_name);
                    
                    if(app.connecting_link && app.connecting_link.trim() !== ''){
                        $('#completed_link').attr('href', app.connecting_link);
                        $('#completedLinkWrapper').show();
                    } else {
                        $('#completedLinkWrapper').hide();
                    }
                    
                    $('#completed_staff').html(app.staff_name);
                    $('#completed_reason').html(app.appointment_reason);

                    // Fetch data for appointment reschedule
                    $('#reschedule_id').val(app.sno);
                    $('#reschedule_date').text(formattedDate);
                    $('#reschedule_cus_name').html(app.name);
                    $('#reschedule_cus_num').html(app.cus_mobile);
                    $('#reschedule_app').html(app.appointment_mode_name);
                    $('#reschedule_con').html(app.con_name);
                    
                    if(app.connecting_link && app.connecting_link.trim() !== ''){
                        $('#reschedule_link').attr('href', app.connecting_link);
                        $('#rescheduleLinkWrapper').show();
                    } else {
                        $('#rescheduleLinkWrapper').hide();
                    }
                    
                    $('#reschedule_staff').html(app.staff_name);
                    $('#reschedule_reason').html(app.appointment_reason);
                }
            })
            .catch(error => {
            console.log('Error Fetching Data :', error);
            });
    }
</script>

<script>
    document.getElementById('cancellAppointmentForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const id = document.getElementById('cancel_id').value;
    const reason = document.getElementById('appointment_cancel').value;

    document.getElementById('cancel_reason_err').textContent = '';

    if(!reason){
        document.getElementById('cancel_reason_err').textContent = 'Please Enter Appointment Cancel Reason.';
    }

    fetch(`/cancel_appointment/${id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'  // Laravel csrf token
        },
        body: JSON.stringify({ appointment_cancel: reason })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 200) {
            toastr.success('Appointment cancelled successfully!');
            // Optionally close the modal here
            $('#kt_modal_apt_cancelled').modal('hide');
            // Reload the page
            location.reload();
        }
    })
    .catch(err => {
        console.error(err);
        toastr.error('Error while cancelling appointment.');
    });
    });

    $('#appointment_cancel').on('input', () => {
        $('#cancel_reason_err').text('');
    });

</script>

<script>
    document.getElementById('reschedule_form').addEventListener('submit', function(e) {
        e.preventDefault();

        const id = document.getElementById('reschedule_id').value;
        const reason = document.getElementById('appointment_reschedule_reason').value;
        const date = document.getElementById('re-schedule_appointment_detail').value;

        // Validate on client-side
        document.getElementById('reschedule_reason_err').textContent = '';
        if (!reason.trim()) {
            document.getElementById('reschedule_reason_err').textContent = 'Please Enter the Re-Schedule Reason.';
            return;
        }
        
        document.getElementById('reschedule_date_err').textContent = '';
        if (!date.trim()) {
            document.getElementById('reschedule_date_err').textContent = 'Please Select the Re-Schedule Date.';
            return;
        }

        fetch(`/reschedule_appointment/${id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'  // Laravel csrf token
            },
            body: JSON.stringify({ 
                appointment_reschedule_reason: reason ,
                appointment_reschedule_date: date
            })
        })
        .then(res => res.json())
        .then(data => {
            if(data.status === 200) {
                toastr.success('Appointment Re-Scheduled successfully!');
                // Optionally close the modal here
                $('#kt_modal_apt_Re_schedule').modal('hide');
                // Reload the page
                location.reload();
            }
        })
        .catch(err => {
            console.error(err);
            toastr.error('Error while cancelling appointment.');
        });
    });

</script>

<style>
    #dropArea {
        cursor: pointer;
    }

    #dropArea.bg-light {
        background-color: #f8f9fa;
    }

    #fileList p {
        margin: 0;
        font-size: 0.8rem;
    }
</style>
<script>
    const dropArea = document.getElementById("dropArea");
    const fileInput = document.getElementById("fileInput");
    const fileList = document.getElementById("fileList");
    const uploadedFilesInput = document.getElementById("uploaded_files");
    let uploadedFiles = [];

    // Drag events
    dropArea.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropArea.classList.add("bg-light");
    });
    dropArea.addEventListener("dragleave", () => {
        dropArea.classList.remove("bg-light");
    });
    dropArea.addEventListener("drop", (e) => {
        e.preventDefault();
        dropArea.classList.remove("bg-light");
        if (e.dataTransfer.files.length > 0) {
            uploadFiles(Array.from(e.dataTransfer.files));
        }
    });

    fileInput.addEventListener("change", (e) => {
        if (e.target.files.length > 0) {
            uploadFiles(Array.from(e.target.files));
        }
    });

    function displayFileNames(files) {
        fileList.innerHTML = files
            .map((file, index) => `<div>${index + 1}. ${file}</div>`)
            .join("");
    }

    function uploadFiles(files) {
        const formData = new FormData();
        files.forEach(file => formData.append('file_upload[]', file));

        fetch("{{ route('upload_journal') }}", {
            method: "POST",
            headers: {
                "X-CSRF-TOKEN": document.querySelector('input[name="_token"]').value
            },
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                uploadedFiles = uploadedFiles.concat(data.files);
                uploadedFilesInput.value = JSON.stringify(uploadedFiles);
                displayFileNames(uploadedFiles);
            } else {
                alert("Upload failed: " + (data.message || "Unknown error"));
            }
        })
        .catch(error => {
            console.error("Upload error:", error);
            alert("An error occurred during upload.");
        });
    }
</script>

<script>
    document.getElementById('completed_form').addEventListener('submit', function (e) {
        const uploadedFilesInput = document.getElementById('uploaded_files');
        const summary = document.querySelector('textarea[name="summary"]');
        const errMsg = document.getElementById('err_mssg');
        let hasError = false;

        // Clear previous errors
        errMsg.textContent = '';
        summary.classList.remove('is-invalid');

        // Check summary field
        if (!summary.value.trim()) {
            summary.classList.add('is-invalid');
            errMsg.textContent = 'Appointment summary is required.';
            hasError = true;
        }

        // Check if files are uploaded
        try {
            const uploadedFiles = JSON.parse(uploadedFilesInput.value || '[]');
            if (uploadedFiles.length === 0) {
                errMsg.textContent = errMsg.textContent
                    ? errMsg.textContent + ' Also, please upload at least one document.'
                    : 'Please upload at least one document.';
                hasError = true;
            }
        } catch (err) {
            errMsg.textContent = 'Invalid uploaded file data.';
            hasError = true;
        }

        if (hasError) {
            e.preventDefault(); // Prevent form submission
        }
    });
</script>
@endsection