@extends('layouts/blankLayout')
@section('title', 'Customer Feedback Form')
@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection
@section('content')
    <style>
        @page {
            size: A4;
            margin: 0;
        }

        .print-container {
            box-sizing: border-box;
            width: 100%;
        }

        .header_wrapper {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }

        .header {
            display: flex;
            align-items: end;
            justify-content: end;
            flex-direction: column;
        }

        @media print {
            body {
                margin: 0px !important;
                padding: 0px !important;
                page-break-before: auto;
                overflow-x: hidden;
            }

            .print-container::before {
                content: "";
                display: block;
            }

            .start_cont {
                background: none !important;
            }

            .page-break {
                page-break-before: auto !important;
            }

            table {
                width: 100%;
                border-collapse: collapse;
            }

            th,
            tr,
            td {
                border: 1px solid #ddd;
                padding: 5px;
                page-break-inside: always !important;
            }
        }

        table th,
        tr,
        td {
            border-collapse: collapse;
            border: 1px solid #ddd;
            padding: 5px;
        }

        @media (max-width: 576px) {
            body {
                overflow-x: hidden;
            }

            .w-xs-25 {
                width: 25% !important;
            }

            .w-xs-50 {
                width: 50% !important;
            }

            .w-xs-75 {
                width: 75% !important;
            }

            .w-xs-100 {
                width: 100% !important;
            }

            .header_wrapper {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                gap: 3px;
            }

            .header {
                display: flex;
                align-items: center;
                justify-content: center;
                flex-direction: column;
                gap: 5px;
            }
        }

        /* Small devices (landscape phones, 576px and up) */
        @media (min-width: 576px) {
            body {
                overflow-x: hidden;
            }

            .rating-wrapper {
                width: 100%;
                max-width: 700px;
                margin: 20px auto;
                position: relative;
            }

            .w-sm-25 {
                width: 25% !important;
            }

            .w-sm-50 {
                width: 50% !important;
            }

            .w-sm-75 {
                width: 75% !important;
            }

            .w-sm-100 {
                width: 100% !important;
            }

            .text-sm-center {
                text-align: center !important;
            }

            .header_wrapper {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 15px;
            }

            .header {
                display: flex;
                align-items: end;
                justify-content: end;
                flex-direction: column;
            }
        }

        /* Medium devices (tablets, 768px and up) */
        @media (min-width: 768px) {
            body {
                overflow-x: hidden;
            }

            .w-md-25 {
                width: 25% !important;
            }

            .w-md-50 {
                width: 50% !important;
            }

            .w-md-75 {
                width: 75% !important;
            }

            .w-md-100 {
                width: 100% !important;
            }
        }

        /* Large devices (desktops, 992px and up) */
        @media (min-width: 992px) {
            body {
                overflow-x: hidden;
            }

            .w-lg-25 {
                width: 25% !important;
            }

            .w-lg-45 {
                width: 45% !important;
            }

            .w-lg-50 {
                width: 50% !important;
            }

            .w-lg-75 {
                width: 75% !important;
            }

            .w-lg-100 {
                width: 100% !important;
            }
        }

        .emoji-container {
            display: flex;
            gap: 16px;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
        }

        .emoji-box {
            background: #fff;
            border: 1.5px solid #e2e5ea;
            border-radius: 12px;
            padding: 18px 10px;
            text-align: center;
            cursor: pointer;
            transition: all 0.25s ease;
            width: 100px;
            height: auto;
        }

        .emoji-box img {
            width: 42px;
            height: 42px;
            padding: 8px;
            border-radius: 50%;
            background: #f8f9fa;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
            transition: all 0.25s ease;
        }

        .emoji-label {
            margin-top: 8px;
            font-size: 13px;
            font-weight: 500;
            color: #555;
        }

        /* Hover */
        .emoji-box:hover {
            border-color: #AB2B22;
            background: #ffe0dd93;
        }

        .emoji-box:hover .emoji-icon {
            color: #AB2B22;
        }

        /* Selected */
        .emoji-box.selected {
            border-color: #AB2B22;
            background: #ffe0dd93;
        }

        .emoji-box.selected .emoji-label {
            color: #AB2B22;
            font-weight: 600;
        }

        .emoji-box.selected .emoji-icon {
            color: #AB2B22;
        }

        @keyframes blink {

            0%,
            50%,
            100% {
                opacity: 1;
            }

            25%,
            75% {
                opacity: 0;
            }
        }

        .blink {
            animation: blink 1s infinite;
        }

        /* Slider Styles */
        .rating-wrapper {
            width: 100%;
            max-width: 700px;
            margin: 20px auto;
            position: relative;
        }

        .emoji-item {
            position: absolute;
            top: 38px;
            transform: translate(-50%, -100%);
            opacity: 0;
            transition: opacity 0.25s ease;
            pointer-events: none;
        }

        .emoji-item.active {
            opacity: 1;
        }

        /* Slider */
        .rating-slider {
            width: 100%;
            appearance: none;
            height: 8px;
            border-radius: 5px;
            background: #e0e0e0;
            outline: none;
            margin-top: 45px;
        }

        .rating-slider::-webkit-slider-thumb {
            appearance: none;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #fff;
            border: 4px solid #ffc107;
            cursor: pointer;
        }

        /* Labels */
        .rating-labels {
            display: flex;
            justify-content: space-between;
            font-size: 14px;
            margin-top: 10px;
            font-weight: bold;
        }

        .rating-labels span {
            color: gray;
            text-align: center;
        }

        .rating-labels span.active {
            color: #1da1f2;
        }

        /* Validation error styles */
        .rating-wrapper.error .rating-slider {
            border: 2px solid #ff3860;
            border-radius: 5px;
        }

        .question-wrapper.error {
            border-left-color: #ff3860 !important;
            box-shadow: 0 3px 3px rgba(255, 56, 96, 0.3) !important;
            animation: shake 0.5s ease-in-out;
        }

        @keyframes shake {

            0%,
            100% {
                transform: translateX(0);
            }

            10%,
            30%,
            50%,
            70%,
            90% {
                transform: translateX(-5px);
            }

            20%,
            40%,
            60%,
            80% {
                transform: translateX(5px);
            }
        }

        .error-message {
            color: #ff3860;
            font-size: 14px;
            margin-top: 5px;
            display: none;
        }

        .error-message.show {
            display: block;
        }
    </style>

    <center>
        <div style="margin-bottom:20px;" class="w-lg-45 w-md-100 w-sm-100 print-container bg-transparent">
            <div class=""
                style="background-image: url('{{ asset('assets/egc_images/feedback_bg.png') }}');transform: scaleX(1); background-size: cover;background-repeat: no-repeat; background-position: center; padding: 20px; border-radius: 8px; margin-bottom: 10px; box-shadow: 0 3px 3px rgb(177,177,177,0.8); border: 1px solid #e9ecef;">
                <div class="header_wrapper ">
                    <img src="{{ asset('assets/phdizone_images/phdizone_logo.png') }}" class="rounded" width="180"
                        alt="EGC Logo">
                    <div class="header">
                        <label style="font-size: 20px; font-weight: 500; color: #000000;">
                            Customer Feedback Form
                        </label>
                        <label style="font-size: 14px; font-weight: 500; color: #000000;">
                            Share Your Valuable Feedback
                        </label>
                    </div>
                </div>
            </div>

            <!-- Form for submitting feedback -->
            <form id="feedbackForm" method="POST" action="{{ route('feedback.submit') }}">
                @csrf
                <!-- Hidden field for reference ID -->
                <input type="hidden" name="reference_id" value="{{ $reference_id }}">

                <!-- Loop through questions -->
                @foreach ($questions as $index => $question)
                    @php
                        // Parse slider configuration from question_option
                        $sliderConfig = [];
                        if (!empty($question->question_option)) {
                            $sliderConfig = json_decode($question->question_option, true);
                        }
                        $minValue = $sliderConfig['min'] ?? 1;
                        $maxValue = $sliderConfig['max'] ?? 5;
                        $labels = ['Very Poor', 'Poor', 'Average', 'Good', 'Excellent'];
                    @endphp

                    <div class="question-wrapper"
                        style="padding: 5px 20px;background-color: #fff; border-radius: 10px;box-shadow: 0 3px 3px rgb(177,177,177, 0.8);margin-bottom: 20px; border-left:5px solid #fd9800;"
                        data-question-index="{{ $index }}">
                        <div style="margin-bottom:10px;margin-top:20px;text-align: left;">
                            <div class="d-flex gap-2 align-items-start justify-content-start">
                                <span class="text-black">{{ $question->question_name }}</span>
                            </div>

                            <!-- Hidden input to store the question ID -->
                            <input type="hidden" name="questions[{{ $index }}][id]" value="{{ $question->sno }}">

                            <div class="rating-wrapper">
                                <!-- Emoji items -->
                                @for ($i = 1; $i <= 5; $i++)
                                    <span class="emoji-item">
                                        <div style="width:45px; height:45px;">
                                            @switch($i)
                                                @case(1)
                                                    <img src="{{ asset('assets/phdizone_images/feedback/Crying Emoticon.gif') }}"
                                                        alt="Very Poor" class="w-100 h-100" />
                                                @break

                                                @case(2)
                                                    <img src="{{ asset('assets/phdizone_images/feedback/Bored.gif') }}"
                                                        alt="Poor" class="w-100 h-100" />
                                                @break

                                                @case(3)
                                                    <img src="{{ asset('assets/phdizone_images/feedback/Cute Smiley.gif') }}"
                                                        alt="Average" class="w-100 h-100" />
                                                @break

                                                @case(4)
                                                    <img src="{{ asset('assets/phdizone_images/feedback/Blushed.gif') }}"
                                                        alt="Good" class="w-100 h-100" />
                                                @break

                                                @case(5)
                                                    <img src="{{ asset('assets/phdizone_images/feedback/Big Smiley.gif') }}"
                                                        alt="Excellent" class="w-100 h-100" />
                                                @break
                                            @endswitch
                                        </div>
                                    </span>
                                @endfor

                                <!-- Slider input -->
                                <input type="range" min="{{ $minValue }}" max="{{ $maxValue }}" step="1"
                                    value="" class="rating-slider" name="questions[{{ $index }}][rating]"
                                    data-question-index="{{ $index }}" required>

                                <!-- Rating labels -->
                                <div class="rating-labels">
                                    @for ($i = $minValue; $i <= $maxValue; $i++)
                                        <span>
                                            @if (isset($labels[$i - 1]))
                                                {{ $labels[$i - 1] }}
                                            @else
                                                {{ $i }}
                                            @endif
                                        </span>
                                    @endfor
                                </div>

                                <!-- Error message -->
                                <div class="error-message" id="error-{{ $index }}">
                                    Please rate this question
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach

                <!-- Optional suggestion textarea -->
                <div
                    style="padding: 5px 20px;background-color: #fff; border-radius: 10px;box-shadow: 0 3px 3px rgb(177,177,177, 0.8);margin-bottom: 20px; border-left:5px solid #fd9800;">
                    <div style="margin-bottom:10px;margin-top:20px;text-align: left;">
                        <label style="font-weight: semibold;font-size:16px;color; #000000;">
                            <span>Do you have any suggestions to help us improve further?</span>
                        </label>
                        <div style="display:block;margin-top:4px;">
                            <textarea class="form-control" name="suggestions" id="suggestions" rows="2" placeholder="Enter suggestions"></textarea>
                        </div>
                    </div>
                </div>

                <!-- Submit button -->
                <button type="button" id="submitFeedbackBtn"
                    class="btn btn-lg btn-primary waves-effect waves-light my-3 d-flex align-items-center justify-content-center"
                    style="width: fit-content;">
                    <label class="text-white fs-5 fw-semibold">Submit Feedback</label>
                    <span class="mdi mdi-send ms-2 text-white mb-2" style="rotate: -30deg;"></span>
                </button>
            </form>
        </div>
    </center>

    <!-- Include SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {

            /* ===============================
               TRACK ANSWERED QUESTIONS
            =============================== */
            const answeredQuestions = new Set();

            /* ===============================
               INITIALIZE SLIDERS
            =============================== */
            document.querySelectorAll('.rating-slider').forEach(slider => {

                // Reset visuals
                slider.style.background = '#e0e0e0';

                const wrapper = slider.closest('.rating-wrapper');
                wrapper.querySelectorAll('.emoji-item').forEach(e => e.style.display = 'none');
                wrapper.querySelectorAll('.rating-labels span').forEach(l => l.classList.remove('active'));

                initializeSlider(slider);
            });

            /* ===============================
               SLIDER LOGIC
            =============================== */
            function initializeSlider(slider) {

                const wrapper = slider.closest('.rating-wrapper');
                const emojis = wrapper.querySelectorAll('.emoji-item');
                const labels = wrapper.querySelectorAll('.rating-labels span');
                const labelsContainer = wrapper.querySelector('.rating-labels');
                const qIndex = slider.dataset.questionIndex;

                function updateSlider() {
                    const min = parseInt(slider.min);
                    const max = parseInt(slider.max);
                    const value = parseInt(slider.value);
                    const index = value - min;

                    // Mark answered
                    answeredQuestions.add(qIndex);

                    // Remove error
                    const qWrap = slider.closest('.question-wrapper');
                    qWrap.classList.remove('error');
                    wrapper.classList.remove('error');
                    qWrap.querySelector('.error-message').classList.remove('show');

                    // Emojis
                    emojis.forEach((emoji, i) => {
                        emoji.style.display = 'block';
                        emoji.classList.toggle('active', i === index);

                        if (i === index) {
                            const labelRect = labels[i].getBoundingClientRect();
                            const containerRect = labelsContainer.getBoundingClientRect();
                            emoji.style.left =
                                (labelRect.left - containerRect.left + labelRect.width / 2) + 'px';
                        }
                    });

                    // Labels
                    labels.forEach((label, i) => {
                        label.classList.toggle('active', i === index);
                    });

                    // Slider background
                    const percent = (value - min) / (max - min) * 100;
                    slider.style.background = `
                linear-gradient(
                    to right,
                    #1da1f2 0%,
                    #1da1f2 ${percent}%,
                    #e0e0e0 ${percent}%,
                    #e0e0e0 100%
                )`;
                }

                slider.addEventListener('input', updateSlider);

                // Click on labels
                labels.forEach((label, i) => {
                    label.addEventListener('click', () => {
                        slider.value = parseInt(slider.min) + i;
                        updateSlider();
                    });
                });
            }

            /* ===============================
               FORM SUBMIT VALIDATION
            =============================== */
            document.getElementById('submitFeedbackBtn').addEventListener('click', function() {

                let valid = true;
                let firstError = null;

                document.querySelectorAll('.question-wrapper').forEach(qWrap => {
                    const slider = qWrap.querySelector('.rating-slider');
                    const qIndex = slider.dataset.questionIndex;

                    if (!answeredQuestions.has(qIndex)) {
                        valid = false;
                        qWrap.classList.add('error');
                        qWrap.querySelector('.rating-wrapper').classList.add('error');
                        qWrap.querySelector('.error-message').classList.add('show');

                        if (!firstError) firstError = qWrap;
                    }
                });

                /* ❌ NOT VALID */
                if (!valid) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Incomplete Feedback',
                        text: 'Please rate all questions before submitting.',
                        confirmButtonText: 'OK',
                        showCancelButton: false,
                        showDenyButton: false
                    }).then(() => {
                        firstError?.scrollIntoView({
                            behavior: 'smooth',
                            block: 'center'
                        });
                    });
                    return;
                }

                var suggestions = document.getElementById('suggestions').value.trim();

                if (suggestions === '') {
                    Swal.fire({
                        icon: 'error',
                        title: 'Suggestions Required',
                        text: 'Please give suggestions before submitting.',
                        confirmButtonText: 'OK',
                        showCancelButton: false,
                        showDenyButton: false
                    }).then(() => {
                        document.getElementById('suggestions').focus();
                    });
                    return;
                }


                /* ✅ CONFIRM SUBMIT */
                Swal.fire({
                    title: 'Submit Feedback?',
                    text: 'You cannot change your feedback after submission.',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Submit',
                    cancelButtonText: 'Review Again'
                }).then(result => {
                    if (result.isConfirmed) {
                        document.getElementById('feedbackForm').submit();
                    }
                });
            });

            /* ===============================
               REPOSITION EMOJIS ON RESIZE
            =============================== */
            window.addEventListener('resize', repositionEmojis);
            window.addEventListener('orientationchange', () => setTimeout(repositionEmojis, 300));

            function repositionEmojis() {
                document.querySelectorAll('.rating-slider').forEach(slider => {
                    if (!slider.value) return;

                    const wrapper = slider.closest('.rating-wrapper');
                    const emojis = wrapper.querySelectorAll('.emoji-item');
                    const labels = wrapper.querySelectorAll('.rating-labels span');
                    const labelsContainer = wrapper.querySelector('.rating-labels');
                    const index = parseInt(slider.value) - parseInt(slider.min);

                    if (!emojis[index]) return;

                    const labelRect = labels[index].getBoundingClientRect();
                    const containerRect = labelsContainer.getBoundingClientRect();
                    emojis[index].style.left =
                        (labelRect.left - containerRect.left + labelRect.width / 2) + 'px';
                });
            }

        });
    </script>

@endsection
