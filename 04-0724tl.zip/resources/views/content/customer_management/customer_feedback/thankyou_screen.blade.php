@extends('layouts/blankLayout')
@section('title', 'Form Submitted')
@section('content')

<style>
    body {
        background-color: #ebebebff;
    }

    .confirmation-box {
        max-width: 600px;
        background-color: #ffffff;
        padding: 40px 30px;
        border-radius: 16px;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
        margin: 40px auto;
        text-align: center;
    }

    .confirmation-title {
        font-size: 22px;
        font-weight: bold;
        color: #01AF31;
    }

    .confirmation-message {
        font-size: 16px;
        color: #333;
    }

    .responsive-img {
        width: 200px;
        margin-bottom: 20px;
    }

    @media (min-width: 768px) {
        .responsive-img {
            width: 280px;
        }
    }
</style>

<div class="confirmation-box">
    <img src="{{ asset('assets/phdizone_images/feedback/Correct.gif') }}" alt="Tick Mark" class="responsive-img">
    <h6 class="confirmation-title">Feedback Submitted Successfully !</h6>
    <p class="confirmation-message">
        <medium>Thank you, for sharing your </medium><br>
        <b>Valuable Feedback</b>
    </p>
</div>

@endsection
