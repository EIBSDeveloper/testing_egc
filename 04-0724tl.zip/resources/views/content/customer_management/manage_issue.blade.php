@extends('layouts/layoutMaster')

@section('title', 'Manage Issue')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/nouislider/nouislider.js', 'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js', 'resources/assets/vendor/js/dropdown-hover.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

@php
    $module_name = 'Customer Management';
    $menu_name = 'Manage Issue';
    $loginStaff = auth()->user()->user_id;
@endphp

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Issue</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Customer Care</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center mb-2">
                    {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-1" id="filter">
                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i
                                class="mdi mdi-filter-outline text-center"></i></span>
                    </a> --}}
                    @if(auth()->user()->hasPermission($module_name, 'Add', $menu_name))
                        <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_add_issue"
                            class="btn btn-sm fw-bold text-white btn-primary">
                            <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Issue
                        </a>
                    @endif
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="filter_tbox" style="display: none;">
                <div class="row py-1">
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">customer ID</label>
                        <input type="text" class="form-control" id="" placeholder="Enter customer ID" />
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                        <select id="" class="select3 form-select">
                            <option value="" selected>All</option>
                            <option value="1">Priya - 2025/MDU01/CUS2334</option>
                            <option value="2">Selvin R - 2025/MDU01/CUS2333</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                        <select id="" class="select3 form-select">
                            <option value="" selected>All</option>
                            <option value="1">Open</option>
                            <option value="2">Closed</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
                        <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt"
                            onchange="date_fill_issue_rpt();">
                            <option value="all">All</option>
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="monthly">This Month</option>
                            <option value="custom_date">Custom Date</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">Today</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i
                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_care_service_today_dt_fill" placeholder="Select Date"
                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i
                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_care_service_week_st_dt_fill" placeholder="Select Date"
                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i
                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_care_service_week_ed_dt_fill" placeholder="Select Date"
                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">This Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="ovr_month_fill" placeholder="Select Date" class="form-control"
                                value="<?php echo date(' M-Y'); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_care_service_from_dt_fill" placeholder="Select Date"
                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_care_service_to_dt_fill" placeholder="Select Date"
                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" />
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                    <button class="btn btn-secondary btn-sm me-3">Reset</button>
                    <a href="javascript:;" class="btn btn-primary btn-sm">Go</a>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px">Date & Time</th>
                                <th class="min-w-100px">Customer</th>
                                <th class="min-w-150px">Issue</th>
                                <th class="min-w-100px">Assigned staff</th>
                                @if(auth()->user()->hasPermission($module_name, 'Status Change', $menu_name))
                                    <th class="min-w-100px">Status</th>
                                @endif
                                <th class="min-w-80px">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7">
                            @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                                @foreach ($issues as $i)
                                    <tr>
                                        <td>
                                            @if ($i->issue_close_date)
                                                <div class="mb-4 mt-2 " data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    data-bs-original-title="Issue Open Date">
                                                    <span
                                                        class="border w-150px p-2 rounded fs-7 text-dark bg-label-warning border-warning">
                                                        <label class="fw-semibold fs-7 text-black">
                                                            {{ \Carbon\Carbon::parse($i->issue_date)->format('d-M-Y h:i A') }}
                                                        </label>
                                                    </span>
                                                </div>
                                                <div class="mb-4 mt-2 " data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    data-bs-original-title="Issue Closed Date">
                                                    <span
                                                        class="border w-150px p-2 rounded fs-7 text-dark bg-label-success border-success">
                                                        <label class="fw-semibold fs-7 text-black">
                                                            {{ \Carbon\Carbon::parse($i->issue_close_date)->format('d-M-Y h:i A') }}
                                                        </label>
                                                    </span>
                                                </div>
                                            @else
                                                <div class="mb-4 mt-2 " data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    data-bs-original-title="Issue Open Date">
                                                    <span
                                                        class="border w-150px p-2 rounded fs-7 text-dark bg-label-warning border-warning">
                                                        <label class="fw-semibold fs-7 text-black">
                                                            {{ \Carbon\Carbon::parse($i->issue_date)->format('d-M-Y h:i A') }}
                                                        </label>
                                                    </span>
                                                </div>
                                            @endif
                                        </td>
                                        <td>
                                            <label class="fw-semibold fs-7 text-black">{{ $i->cus_name }}</label>
                                            <div class="d-block">
                                                <div class="fw-semibold fs-8 text-info" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="{{ $i->customer_id }}">
                                                    {{ $i->customer_id }}</div>
                                            </div>
                                        </td>
                                        <td>
                                            <div>
                                                <span class="fs-7">{{ $i->issue_reason }}</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="list-unstyled avatar-group d-flex">
                                                @if ($i->staff_image)
                                                    <div data-bs-toggle="tooltip" data-popup="tooltip-custom"
                                                        data-bs-placement="bottom" title="Assigned Staff"
                                                        class="avatar me-2">
                                                        <img class="rounded-circle border border-black border-2 bg-danger"
                                                            src="/staff_images/{{ $i->staff_image }}" alt="avatar">
                                                    </div>
                                                @else
                                                    @php
                                                        $initial = $i->staff_name
                                                            ? strtoupper(substr($i->staff_name, 0, 1))
                                                            : '?';
                                                    @endphp
                                                    <div class="rounded-circle border border-black border-2 bg-danger d-flex justify-content-center align-items-center"
                                                        style="width: 40px; height: 40px; color: white;"
                                                        data-bs-toggle="tooltip" data-popup="tooltip-custom"
                                                        data-bs-placement="bottom" title="Assigned Staff">
                                                        {{ $initial }}
                                                    </div>
                                                @endif
                                                <span class="mt-2">{{ $i->staff_name }}</span>
                                            </div>
                                        </td>
                                        @if(auth()->user()->hasPermission($module_name, 'Status Change', $menu_name))
                                            <td>
                                                @if($loginStaff == $i->attend_staff_id)
                                                    @if ($i->status == 0)
                                                        <a href="javascript:;"
                                                            class="badge bg-warning rounded fw-semibold fs-7 text-black"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">Open</a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item text-center"
                                                                data-bs-toggle="modal" data-bs-target="#kt_modal_issue_closed"
                                                                onclick="completeIssue('{{ $i->sno }}')">Closed</a>
                                                        </div>
                                                    @elseif ($i->status == 1)
                                                        <span class="badge bg-success rounded fw-semibold fs-7 text-black"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">Closed</span>
                                                    @endif
                                                @else
                                                    @if($i->status == 0)
                                                        <div class="badge bg-warning rounded fw-semibold fs-7 text-black">Open</div>
                                                    @elseif ($i->status == 1)
                                                        <div class="badge bg-success rounded fw-semibold fs-7 text-black">Closed</div>
                                                    @endif
                                                @endif
                                            </td>                                        
                                        @endif
                                        <td>
                                            @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                                <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2"
                                                    data-bs-toggle="modal" onclick="viewData('{{ $i->sno }}')"
                                                    data-bs-target="#kt_modal_view_issue_2">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i
                                                            class="mdi mdi-eye-outline fs-3 text-black"></i></span>
                                                </a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <!--begin::Modal - add issue-->
    <div class="modal fade" id="kt_modal_add_issue" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Create Issue</h3>
                    </div>
                    <form action="{{ route('create_manage_issue') }}" method="POST" id="add_issue_form">
                        @csrf
                        <div class="row">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Create issue Date & Time<span
                                        class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="issue_date" name="issue_date" placeholder="Select Date" class="form-control common_date_time_class" />
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="customer_id" name="customer_id">
                                    <option value="">Select Customer Name</option>
                                    @foreach ($customers as $customer)
                                        <option value="{{ $customer->sno }}">{{ $customer->cus_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Attend Staff<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="attend_staff_id" name="attend_staff_id">
                                    <option value="">Select Attend Staff</option>
                                    @foreach ($staffs as $staff)
                                        <option value="{{ $staff->sno }}">{{ $staff->staff_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="assign_staff_id" name="assign_staff_id">
                                    <option value="">Select Assigned Staff</option>
                                    @foreach ($staffs as $staff)
                                        <option value="{{ $staff->sno }}">{{ $staff->staff_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Issue Reason<span
                                        class="text-danger">*</span></label>
                                <textarea class="form-control" rows="1" placeholder="Enter Issue Reason" name="issue_reason" id="issue_reason"></textarea>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Create Issue</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - add issue-->

    <!--begin::Modal - View issue 2-->
    <div class="modal fade" id="kt_modal_view_issue_2" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">View Issue -<span
                                class=" ms-3 badge bg-success text-black border rounded"
                                id="view_status_title">Closed</span></h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="row">
                                <span class="col-4 fw-semibold">Attend Staff</span>
                                <span class="col-1 fw-semibold text-black">:</span>
                                <div class="col-7 fw-bold text-black ">
                                    <div class="d-flex">
                                        <ul class="list-unstyled avatar-group me-2">
                                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom"
                                                data-bs-placement="top" title="vinnie mostowy" class="avatar"
                                                id="view_attend_staff_title">
                                                <img class="rounded-circle"
                                                    src="{{ asset('assets/phdizone_images/user_2.png') }}"
                                                    id="view_attend_staff_img" alt="avatar">
                                                <div id="view_attend_staff_letter"
                                                    style="display:none; width: 100%; border-radius: 50% !important; height: 100%; text-align: center; line-height: 40px;">
                                                </div>
                                            </li>
                                        </ul>
                                        <div>
                                            <span id="view_attend_staff"> Ragu</span>
                                            <br> <span class="fs-9 fw-semibold text-dark "
                                                id="view_staff_position"></span>
                                        </div>
                                    </div>
                                    <div class="d-block">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-12 mb-4 d-flex justify-content-between">
                            <div class="p-1">
                                <span class="badge bg-danger fs-6 rounded" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Issue Status">Open</span>
                            </div>
                            <div class="p-1">

                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row">
                                <span class="col-5 fw-semibold">Customer</span>
                                <span class="col-1 fw-semibold text-black">:</span>
                                <div class="col-6 fw-bold text-black"><span id="view_customer"></span><br><span
                                        class="overflow-hidden text-truncate fs-8 text-info" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" id="view_customer_id"></span></div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row">
                                <span class="col-5 fw-semibold">Issue Open Date</span>
                                <span class="col-1 fw-semibold text-black">:</span>
                                <div class="col-6 fw-bold text-black"><span
                                        class="badge bg-label-warning border border-warning text-black rounded fs-7 fw-semibold"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="Issue Open Date"
                                        id="view_issue_date">
                                    </span></div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <label class="mb-2 fw-semibold ">Issue</label><br>
                            <div class="border rounded p-2 bg-label-danger border-danger">
                                <span class="ms-3 text-black fw-bold " id="view_issue_reason"></span>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row" id="view_issue_close_container">
                        <div class="col-lg-12 mb-4 d-flex justify-content-between">
                            <div class="p-1">
                                <span class="badge bg-success fs-6 rounded text-black fw-semibold"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Issue Status">closed</span>
                            </div>
                            <div class="p-1">

                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row">
                                <span class="col-5 fw-semibold">Assigned Staff</span>
                                <span class="col-1 fw-semibold text-black">:</span>
                                <div class="col-6 fw-bold text-black ">
                                    <div class="d-flex">
                                        <ul class="list-unstyled avatar-group">
                                            <li data-bs-toggle="tooltip" data-popup="tooltip-custom"
                                                data-bs-placement="top" title="priye" class="avatar"
                                                id="view_assign_staff_title">
                                                <img class="rounded-circle"
                                                    src="{{ asset('assets/phdizone_images/user_1.png') }}" alt="avatar"
                                                    id="view_assign_staff_image">
                                                <div id="view_assign_staff_letter"
                                                    style="display:none; width: 100%; height: 100%; text-align: center; line-height: 40px; border-radius: 50% !important;">
                                                </div>
                                            </li>
                                        </ul>
                                        <div>
                                            <span id="view_assign_staff">Naveen</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row">
                                <span class="col-5 fw-semibold">Issue Closed Date</span>
                                <span class="col-1 fw-semibold text-black">:</span>
                                <div class="col-6 fw-bold text-black"><span id="view_issue_closed_date"
                                        class="badge bg-label-success border border-success text-black rounded fs-7 fw-semibold"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="Issue Open Date">
                                    </span></div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <label class="mb-2 fw-semibold ">Solution</label><br>
                            <div class="border rounded p-2 bg-label-success border-success">
                                <span class="ms-3 text-black fw-bold " id="view_solution"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->

            <!--end::Modal dialog-->
        </div>
    </div>
    <!--end::Modal - View issue2-->

    <!--begin::Modal - complete issue-->
    <div class="modal fade" id="kt_modal_issue_closed" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">Are you sure you
                    want to Change Status Closed Issue ?
                    <div class="d-block fw-bold text-black fs-6 py-2 mb-3 mt-3">
                        <label id="complete_date_show"></label>
                    </div>
                    <form action="{{ route('complete_issue') }}" method="POST" id="complete_form">
                        @csrf
                        <div class="ms-6">
                            <input type="hidden" name="complete_id" id="complete_id">
                            <input type="hidden" name="complete_date" id="complete_date">
                            <div class="col-lg-12 mb-3 text-start">
                                <label class="text-black mb-1 fs-6 fw-semibold">Solution<span
                                        class="text-danger">*</span></label>
                                <textarea class="form-control" rows="3" id="solution" name="solution" placeholder="Enter Solutions"></textarea>
                                <P id="solution_err" class="text-danger mt-1"></P>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center pt-6 pb-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary ">Closed Issue</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
    </div>
    <!--end::Modal - complete issue-->


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>

    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>


    <script>
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>
    <script>
        $(".list_page").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    <script>
        function date_fill_issue_rpt() {
            var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
            var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
            var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
            var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
            var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
            var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
            var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_issue_rpt == "today") {
                today_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "week") {
                today_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "block";
                week_to_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#week_from_date_fil').val(firstday);
                $('#week_to_date_fil').val(lastday);

            } else if (dt_fill_issue_rpt == "monthly") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "block";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "custom_date") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "block";
                to_dt_iss_rpt.style.display = "block";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            }
        }
    </script>

    {{-- Date Picker --}}
    <script>
        $(document).ready(function() {

            $(".common_date_time_class").flatpickr({
                enableTime: true, // enable time picker
                dateFormat: "Y-m-d h:i K",
                defaultDate: new Date(),
                time_24hr: false // Ensure 12-hour clock
            });
        });
    </script>

    {{-- Validation --}}
    <script>
        // Add Issue Validation
        $('#add_issue_form').on('submit', (e) => {
            let isValid = true;

            $('#issue_date_err').text('');
            $('#customer_id_err').text('');
            $('#attend_staff_err').text('');
            $('#assign_staff_err').text('');
            $('#issue_reason_err').text('');

            if ($('#issue_date').val().trim() === '') {
                isValid = false;
                $('#issue_date_err').text('Select Issue Date.');
            }

            if ($('#customer_id').val() === '') {
                isValid = false;
                $('#customer_id_err').text('Select Customer.');
            }

            if ($('#attend_staff_id').val() === '') {
                isValid = false;
                $('#attend_staff_err').text('Select Attend Staff.');
            }

            if ($('#assign_staff_id').val() === '') {
                isValid = false;
                $('#assign_staff_err').text('Select Assign Staff.');
            }

            if ($('#issue_reason').val() === '') {
                isValid = false;
                $('#issue_reason_err').text('Enter Issue Reason.');
            }

            if (!isValid) {
                e.preventDefault();
            }
        });

        // Complete Issue Validation
        $('#complete_form').on('submit', (event) => {

            $('#solution_err').text('');

            if ($('#solution').val() === '') {
                event.preventDefault();
                $('#solution_err').text('Enter Your Solution.');
            }
        });
    </script>

    {{-- Prevent Attend Staff in Assign Staff --}}
    <script>
        $(document).ready(function() {
            const $attendStaff = $('#attend_staff_id');
            const $assignStaff = $('#assign_staff_id');

            const allOptions = $assignStaff.html();

            $attendStaff.change(function() {
                const selectedStaff = $(this).val();

                const updatedOptions = $(allOptions).filter(function() {
                    return $(this).val() !== selectedStaff;
                });

                $assignStaff.html(updatedOptions).trigger('change');
            });
        });
    </script>

    {{-- Complete Issue --}}
    <script>
        function completeIssue(sno) {
            $('#complete_id').val(sno);

            function formatCurrentDateTime() {
                const now = new Date();

                const day = String(now.getDate()).padStart(2, '0');

                // Array of short month names
                const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                const month = months[now.getMonth()]; // getMonth() is zero-based

                const year = now.getFullYear();

                // 12-hour format hour
                let hours = now.getHours();
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // hour '0' should be '12'
                const strHours = String(hours).padStart(2, '0');

                const minutes = String(now.getMinutes()).padStart(2, '0');

                return `${day}-${month}-${year} ${strHours}:${minutes} ${ampm}`;
            }

            $('#complete_date_show').html(formatCurrentDateTime());
            $('#complete_date').val(formatCurrentDateTime());
        }
    </script>

    {{-- View Issue --}}
    <script>
        function viewData(id) {
            fetch(`/view_issue/${id}`, {
                    method: 'GET',
                    headers: {
                        'CONTENT-TYPE': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;

                        // Format Date
                        function formatDateTime(dateString) {
                            if (!dateString) return '';

                            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                            ];

                            const dateObj = new Date(dateString);

                            if (isNaN(dateObj)) return '';

                            const day = dateObj.getDate();
                            const month = months[dateObj.getMonth()];
                            const year = dateObj.getFullYear();

                            let hours = dateObj.getHours();
                            const minutes = dateObj.getMinutes().toString().padStart(2, '0');

                            // Format 12-hour time with AM/PM
                            const ampm = hours >= 12 ? 'PM' : 'AM';
                            hours = hours % 12;
                            hours = hours ? hours : 12; // the hour '0' should be '12'
                            const hoursStr = hours.toString().padStart(2, '0');

                            return `${day}-${month}-${year} ${hoursStr}:${minutes} ${ampm}`;
                        }


                        $('#view_attend_staff').html(com.attend_staff_name);
                        $('#view_staff_position').html(`( ${com.job_position_name} )`);
                        $('#view_customer').html(com.cus_name);
                        $('#view_customer_id').html(com.customer_id);
                        $('#view_issue_date').html(formatDateTime(com.issue_date));
                        $('#view_issue_reason').html(com.issue_reason);

                        let tooltipEl = bootstrap.Tooltip.getInstance(document.getElementById(
                            'view_attend_staff_title'));
                        if (tooltipEl) {
                            tooltipEl.setContent({
                                '.tooltip-inner': com.attend_staff_name
                            });
                        } else {
                            new bootstrap.Tooltip(document.getElementById('view_attend_staff_title'));
                        }

                        if (com.attend_staff_image) {
                            $('#view_attend_staff_letter').hide();
                            $('#view_attend_staff_img').attr('src', `/staff_images/${com.attend_staff_image}`);
                        } else {
                            $('#view_attend_staff_img').hide();

                            // Get first letter of the staff name and show it
                            var firstLetter = com.attend_staff_name ? com.attend_staff_name.charAt(0).toUpperCase() :
                            '';
                            $('#view_attend_staff_letter').html(firstLetter).addClass('bg-success rounded').show();
                        }

                        if (com.status === 0) {

                            $('#view_issue_close_container').hide();
                            $('#view_status_title').html('Open').removeClass('bg-success').addClass('bg-warning');

                        } else if (com.status === 1) {

                            $('#view_issue_close_container').show();
                            $('#view_status_title').html('Closed').removeClass('bg-warning').addClass('bg-success');
                            $('#view_assign_staff').html(com.assign_staff_name);

                            if (com.assign_staff_image) {
                                $('#view_assign_staff_letter').hide();
                                $('#view_assign_staff_image').attr('src', `/staff_images/${com.assign_staff_image}`);
                            } else {
                                $('#view_assign_staff_image').hide();

                                // Get first letter of the staff name and show it
                                var firstLetter = com.assign_staff_name ? com.assign_staff_name.charAt(0)
                                .toUpperCase() : '';
                                $('#view_assign_staff_letter').html(firstLetter).addClass('bg-success rounded').show();
                            }

                            $('#view_issue_closed_date').html(formatDateTime(com.issue_close_date));
                            $('#view_solution').html(com.solution);

                            let tooltipEl = bootstrap.Tooltip.getInstance(document.getElementById(
                                'view_assign_staff_title'));
                            if (tooltipEl) {
                                tooltipEl.setContent({
                                    '.tooltip-inner': com.assign_staff_name
                                });
                            } else {
                                new bootstrap.Tooltip(document.getElementById('view_assign_staff_title'));
                            }

                        }
                    } else {
                        console.log('Error Fetching Data!');
                    }
                })
                .catch(err => {
                    console.error('Error Fetching Data:', err);
                });
        }
    </script>
    <script>
        document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
            el.addEventListener('click', function() {
                // Small delay to allow modal animation to finish
                setTimeout(() => {
                    location.reload();
                }, 150);
            });
        });
    </script>

@endsection
