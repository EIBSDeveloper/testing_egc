@extends('layouts/layoutMaster')

@section('title', 'Manage Ticket')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }

        .select2-results__group {
            color: #F0913D !important;
        }

        .timeline-wrapper {
            width: 100%;
            margin: 20px auto;
            margin-top: 0px;
        }

        .timeline-row {
            display: grid;
            grid-template-columns: 100px 40px 1fr;
            align-items: stretch;
        }

        .timeline-time {
            text-align: right;
            padding-right: 10px;
            font-size: 14px;
            color: #555;
            font-weight: 500;
        }

        .timeline-center {
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100%;
            position: relative;
        }

        .timeline-dot {
            width: 14px;
            height: 14px;
            background: #0d6efd;
            border-radius: 50%;
            z-index: 2;
        }

        .timeline-line {
            width: 2px;
            background: #ced4da;
            flex-grow: 1;
            margin-top: 4px;
        }

        .timeline-row:last-child .timeline-line {
            display: none;
        }

        .timeline-content {
            padding-left: 10px;
        }

        .overlay-wrapper:hover .overlay-layer {
            opacity: 1 !important;
            transition: 0.3s ease;
        }

        .toast-success {
            background-color: green !important;
        }

        .toast-error {
            background-color: red !important;
        }

        .cursor-pointer {
            cursor: pointer;
        }

        .file-list-item {
            background: #f8f9fa;
            border-radius: 5px;
            padding: 8px;
            margin-bottom: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .file-list-item .file-name {
            font-size: 12px;
            color: #333;
        }

        .file-list-item .remove-file {
            color: red;
            cursor: pointer;
            margin-left: 10px;
        }
    </style>

    @php
        $helper = new \App\Helpers\Helpers();
    @endphp

    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Ticket</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-3"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-3"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="card-body">
            <div class="row g-3">
                <!-- Statistics Cards -->
                <div class="col-lg-10">
                    <div class="row g-3">
                        <div class="col-lg-2">
                            <div class="card rounded border" style="box-shadow:2px 2px #B2CDFF;">
                                <div class="d-flex align-items-center justify-content-between py-3 px-2">
                                    <div class="d-flex flex-column align-items-start justify-content-start">
                                        <label class="fw-medium fs-8" style="color:#b71c1c;">Total Tickets</label>
                                        <label
                                            class="text-black fw-semibold fs-3">{{ sprintf('%02d', $total_ticket ?? 0) }}</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="card rounded border" style="box-shadow:2px 2px #F7DB91;">
                                <div class="d-flex align-items-center justify-content-between py-3 px-2">
                                    <div class="d-flex flex-column align-items-start justify-content-start">
                                        <label class="fw-medium fs-8" style="color:#b71c1c;">Accepted Tickets</label>
                                        <label
                                            class="text-black fw-semibold fs-3">{{ sprintf('%02d', $accepted_ticket ?? 0) }}</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="card rounded border" style="box-shadow:2px 2px #ABE7B2;">
                                <div class="d-flex align-items-center justify-content-between py-3 px-2">
                                    <div class="d-flex flex-column align-items-start justify-content-start">
                                        <label class="fw-medium fs-8" style="color:#b71c1c;">Closed Tickets</label>
                                        <label
                                            class="text-black fw-semibold fs-3">{{ sprintf('%02d', $closed_ticket ?? 0) }}</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="card rounded border" style="box-shadow:2px 2px #A6AEBF;">
                                <div class="d-flex align-items-center justify-content-between py-3 px-2">
                                    <div class="d-flex flex-column align-items-start justify-content-start">
                                        <label class="fw-medium fs-8" style="color:#b71c1c;">Rejected Tickets</label>
                                        <label
                                            class="text-black fw-semibold fs-3">{{ sprintf('%02d', $rejected_ticket ?? 0) }}</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="card rounded border" style="box-shadow:2px 2px #EDA35A;">
                                <div class="d-flex align-items-center justify-content-between py-3 px-2">
                                    <div class="d-flex flex-column align-items-start justify-content-start">
                                        <label class="fw-medium fs-8" style="color:#b71c1c;">Reopen Tickets</label>
                                        <label
                                            class="text-black fw-semibold fs-3">{{ sprintf('%02d', $reopen_ticket ?? 0) }}</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="card rounded border" style="box-shadow:2px 2px #88C162;">
                                <div class="d-flex align-items-center justify-content-between py-3 px-2">
                                    <div class="d-flex flex-column align-items-start justify-content-start">
                                        <label class="fw-medium fs-8" style="color:#b71c1c;">Completed Tickets</label>
                                        <label
                                            class="text-black fw-semibold fs-3">{{ sprintf('%02d', $completed_ticket ?? 0) }}</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card rounded border" style="box-shadow:2px 2px #E3F2FD;">
                                <div class="d-flex align-items-center justify-content-between py-3 px-2">
                                    <div class="d-flex flex-column">
                                        <label class="fw-medium fs-8" style="color:#0d47a1;">CRE Department</label>
                                        <label
                                            class="text-black fw-semibold fs-3">{{ sprintf('%02d', $cre_department ?? 0) }}</label>
                                    </div>
                                    <div class="p-3 rounded bg-gray-100" style="color:#0d47a1;">
                                        <span class="mdi mdi-account-cog fs-3"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card rounded border" style="box-shadow:2px 2px #E3F2FD;">
                                <div class="d-flex align-items-center justify-content-between py-3 px-2">
                                    <div class="d-flex flex-column">
                                        <label class="fw-medium fs-8" style="color:#0d47a1;">Production Department</label>
                                        <label
                                            class="text-black fw-semibold fs-3">{{ sprintf('%02d', $pc_department ?? 0) }}</label>
                                    </div>
                                    <div class="p-3 rounded bg-gray-100" style="color:#0d47a1;">
                                        <span class="mdi mdi-progress-wrench fs-3"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card rounded border" style="box-shadow:2px 2px #E3F2FD;">
                                <div class="d-flex align-items-center justify-content-between py-3 px-2">
                                    <div class="d-flex flex-column">
                                        <label class="fw-medium fs-8" style="color:#0d47a1;">Journal Department</label>
                                        <label
                                            class="text-black fw-semibold fs-3">{{ sprintf('%02d', $jtl_department ?? 0) }}</label>
                                    </div>
                                    <div class="p-3 rounded bg-gray-100" style="color:#0d47a1;">
                                        <span class="mdi mdi-file-document fs-3"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-2">
                    <div class="card rounded d-flex align-items-center justify-content-center border"
                        style="box-shadow:2px 2px #FFB2B2; color:#b71c1c; height:170px;">
                        <div class="d-flex align-items-center justify-content-center py-3 px-2">
                            <div class="d-flex flex-column align-items-center justify-content-center">
                                <label class="text-black fw-semibold"
                                    style="font-size:4rem;">{{ sprintf('%02d', $open_ticket ?? 0) }}</label>
                                <label class="fw-medium fs-8" style="color:#b71c1c;">Open Tickets</label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Search and Table Section -->
                <div class="col-lg-12 table-responsive">
                    <div class="row mb-2 mt-2">
                        <div class="col-lg-2">
                            @php $perpage_count = $perpage ? $perpage : 10; @endphp
                            <div>
                                <span>Show</span>
                                <br>
                                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                    onchange="sort_filter(this.value);">
                                    @php $options = [10, 25, 100, 500]; @endphp
                                    @foreach ($options as $option)
                                        <option value="{{ $option }}"
                                            {{ $perpage_count == $option ? 'selected' : '' }}>{{ $option }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-10 d-flex align-items-end justify-content-end">
                            <form id="search_form" method="POST" action="/manage_customer_ticket">
                                @csrf
                                <div class="d-flex align-items-center gap-2">
                                    <div>
                                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                        <input type="hidden" name="filter_on" value="1">
                                        <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                            id="sorting_filter" value="{{ $perpage ?? 25 }}" />
                                        <input type="text" class="form-control" id="search_fill" name="search_fill"
                                            value="{{ $search_fill ?? '' }}" placeholder="Enter Search" />
                                    </div>
                                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6">Search</button>
                                    <a href="{{ url('/manage_customer_ticket') }}" type="button"
                                        class="me-2 btn btn-sm btn-secondary fw-semibold mb-1">
                                        <span class="mdi mdi-refresh fs-6"></span>
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>

                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th style="min-width: 163px;">Ticket ID</th>
                                <th class="min-w-150px">Service</th>
                                <th class="min-w-150px">Customer</th>
                                <th class="min-w-150px">Requirement</th>
                                <th class="min-w-80px">CRE</th>
                                <th class="min-w-50px">Documents</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-50px text-start">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                            @if (count($tableRecords) > 0)
                                @foreach ($tableRecords as $i => $list)
                                    <tr>
                                        <td>
                                            <div class="d-flex flex-column align-items-start justify-content-start gap-1">
                                                <label class="text-danger fs-7">{{ $list->ticket_id }}</label>
                                                <label class="fs-7 fw-semibold text-truncate" style="max-width:200px;"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Ticket Relevant">{{ $list->relevant_name }}</label>
                                                @if ($list->department_id == 15)
                                                    <span class="px-2"
                                                        style="border-radius:3px; background:#e3f2fd; color:#0d47a1; border:1px solid #0d47a1; font-weight:600;">Production</span>
                                                @elseif($list->department_id == 16)
                                                    <span class="px-2"
                                                        style="border-radius:3px; background:#e3fde3; color:#0da14f; border:1px solid #0da186; font-weight:600;">CRE
                                                        Team</span>
                                                @elseif($list->department_id == 33)
                                                    <span class="px-2"
                                                        style="border-radius:3px; background:#fdf4e3; color:#a15f0d; border:1px solid #a1810d; font-weight:600;">Journal
                                                        Team</span>
                                                @endif
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-truncate max-w-150px">{{ $list->service_name }}</label>
                                                @php
                                                    $year = date('Y', strtotime($list->service_created_at));
                                                    $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
                                                    $service_id = "SR-{$id}/{$year}";
                                                @endphp
                                                <label class="fs-8 text-info">{{ $service_id }}</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label>{{ $list->cus_name }}</label>
                                                <label class="text-info fs-8">{{ $list->cus_ai_id }}</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7 fw-semibold text-truncate" style="max-width:150px;"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="{!! $list->subject !!}">{!! $list->subject !!}</label>
                                        </td>
                                        <td>
                                            @php
                                                $assign_staff_details = $helper->staff_details($list->assign_staff);
                                            @endphp
                                            @if ($list->assign_staff == 0)
                                                <span class="bg-primary p-2 animation-blink ms-1" data-bs-toggle="modal"
                                                    data-bs-target="#kt_modal_add_staff_confirmation"
                                                    style="border-radius:5px; cursor:pointer;"
                                                    onclick="openStaffModal({{ $list->sno }},'{{ $list->ticket_id }}','{{ $list->department_id }}')">
                                                    <span class="mdi mdi-account-plus text-white fs-3"></span>
                                                </span>
                                            @elseif (
                                                $assign_staff_details &&
                                                    $assign_staff_details->staff_image != '' &&
                                                    file_exists(public_path('staff_images/' . $assign_staff_details->staff_image)))
                                                <div class="avatar avatar-lg" data-bs-toggle="tooltip"
                                                    data-bs-placement="top"
                                                    title="CRE: {{ $assign_staff_details->staff_name }}">
                                                    <img src="{{ asset('staff_images/' . $assign_staff_details->staff_image) }}"
                                                        alt="avatar" class="rounded-circle img-fluid"
                                                        style="width: 40px; height: 40px;">
                                                </div>
                                            @elseif ($assign_staff_details)
                                                <div class="symbol symbol-35px me-2" data-bs-toggle="tooltip"
                                                    data-bs-placement="top"
                                                    title="CRE: {{ $assign_staff_details->staff_name }}">
                                                    @php
                                                        $initial = strtoupper(
                                                            substr($assign_staff_details->staff_name, 0, 1),
                                                        );
                                                        echo $helper->name_image(
                                                            $initial,
                                                            $assign_staff_details->gender,
                                                        );
                                                    @endphp
                                                </div>
                                            @else
                                                <div class="symbol symbol-35px me-2" data-bs-toggle="tooltip"
                                                    data-bs-placement="top"
                                                    title="Invalid Staff ID: {{ $list->assign_staff }}">
                                                    <span
                                                        class="bg-secondary rounded-circle d-flex align-items-center justify-content-center"
                                                        style="width: 35px; height: 35px;">?</span>
                                                </div>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="dropdown position-relative">
                                                @php
                                                    $isDocuments = json_decode($list->attachments, true);
                                                @endphp
                                                @if ($isDocuments && !empty($isDocuments))
                                                    <button type="button"
                                                        class="btn btn-outline-primary text-nowrap d-inline-block position-relative dropdown-toggle d-flex align-items-center"
                                                        data-bs-toggle="dropdown">
                                                        <i class="mdi mdi-tray-arrow-down me-2"></i>
                                                        @if (count($isDocuments) > 1)
                                                            <span
                                                                class="badge text-bg-danger position-absolute top-0 start-100 translate-middle">{{ count($isDocuments) }}</span>
                                                        @endif
                                                    </button>
                                                    <ul class="dropdown-menu" style="max-width: 300px;">
                                                        @foreach ($isDocuments as $index => $document)
                                                            @php
                                                                $driveLink = asset($document['file_path']);
                                                                $fileName =
                                                                    $document['file_name'] ??
                                                                    'document_' . ($index + 1);
                                                                $fileExtension = pathinfo(
                                                                    $fileName,
                                                                    PATHINFO_EXTENSION,
                                                                );
                                                                $iconClass = match (strtolower($fileExtension)) {
                                                                    'pdf' => 'mdi mdi-file-pdf text-danger',
                                                                    'doc', 'docx' => 'mdi mdi-file-word text-primary',
                                                                    'xls', 'xlsx' => 'mdi mdi-file-excel text-success',
                                                                    'jpg',
                                                                    'jpeg',
                                                                    'png',
                                                                    'gif',
                                                                    'bmp'
                                                                        => 'mdi mdi-file-image text-info',
                                                                    'txt' => 'mdi mdi-file-document text-secondary',
                                                                    default => 'mdi mdi-file',
                                                                };
                                                            @endphp
                                                            <li>
                                                                <a class="dropdown-item" href="{{ $driveLink }}"
                                                                    download
                                                                    style="white-space: normal; word-wrap: break-word;">
                                                                    <i class="{{ $iconClass }} me-2"></i>
                                                                    {{ $fileName }}
                                                                    <small class="text-muted d-block">Click to
                                                                        download</small>
                                                                </a>
                                                            </li>
                                                        @endforeach
                                                    </ul>
                                                @else
                                                    <img src="{{ asset('assets/phdizone_images/newmultiply.png') }}"
                                                        alt="avatar" class="rounded-circle img-fluid"
                                                        style="width: 40px; height: 40px; object-fit: cover;"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="No Documents Uploaded">
                                                @endif
                                            </div>
                                        </td>
                                        <td>
                                            @if ($list->assign_staff == 0)
                                                <label class="badge bg-info text-white fw-semibold fs-8 px-2 py-1"
                                                    style="border-radius: 3px;">Staff Not Assigned</label>
                                            @elseif ($list->status == 0)
                                                <a href="javascript:;"
                                                    class="badge bg-danger text-white rounded fw-semibold fs-8 px-3"
                                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Open <span class="mdi mdi-chevron-down"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirement_accept"
                                                        onclick="StatusChangeTicket('{{ $list->ticket_sno }}', 1)">Accept</a>
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirement_reject"
                                                        onclick="StatusChangeTicket('{{ $list->ticket_sno }}', 2)">Reject</a>
                                                </div>
                                            @elseif($list->status == 1)
                                                <a href="javascript:;"
                                                    class="badge bg-warning text-black rounded fw-semibold fs-8 px-3"
                                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Accepted <span class="mdi mdi-chevron-down"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirement_close"
                                                        onclick="StatusChangeTicket('{{ $list->ticket_sno }}', 3)">Close</a>
                                                </div>
                                            @elseif($list->status == 2)
                                                <label class="badge bg-dark text-white fw-semibold fs-8 px-3"
                                                    style="border-radius: 3px;">Rejected</label>
                                            @elseif($list->status == 3)
                                                <label class="badge text-white fw-semibold fs-8 px-3"
                                                    style="border-radius: 3px; background:darkgreen;">Closed</label>
                                            @elseif($list->status == 4)
                                                <a href="javascript:;"
                                                    class="badge text-black rounded fw-semibold fs-8 px-3"
                                                    style="background: linear-gradient(to right, #f09819, #ff512f);"
                                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Reopen <span class="mdi mdi-chevron-down"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirement_accept"
                                                        onclick="StatusChangeTicket('{{ $list->ticket_sno }}', 1)">Accept</a>
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirement_reject"
                                                        onclick="StatusChangeTicket('{{ $list->ticket_sno }}', 2)">Reject</a>
                                                </div>
                                            @elseif($list->status == 5)
                                                <label class="badge text-white fw-semibold fs-8 px-3"
                                                    style="border-radius: 3px; background:rgb(78, 199, 78);">Completed</label>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="cursor-pointer"
                                                onclick="ViewTicketHistory('{{ $list->ticket_sno }}')"
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_ticket_history">
                                                <span class="mdi mdi-clipboard-text-clock-outline fs-3"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="History"></span>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                    <div class="mt-4">
                        {{ $tableRecords->appends(request()->except(['page', '_token']))->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal - View History -->
    <div class="modal fade" id="kt_modal_ticket_history" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <div class="modal-dialog modal-lg">
            <div class="modal-content rounded">
                <div class="modal-header justify-content-end border-0 pb-0">
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                    </div>
                </div>
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Ticket History</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Ticket ID</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-primary fs-6 fw-semibold" id="history_ticket_id">-</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Customer</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_customer_name">-</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Mobile</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_customer_mobile">-</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Service</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_service">-</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Service ID</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_services_id">-</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Subject</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-danger fs-6 fw-semibold" id="history_requirement">-</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Description</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_description">-</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Created Date</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_created_at">-</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Current Status</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_status">-</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">CRE</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_cre">-</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-12">
                        <div class="text-secondary fs-4 fw-semibold mb-3">Updates</div>
                        <div class="timeline-wrapper scroll-y pe-3" style="max-height: 400px;" id="history_timeline">
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="text-secondary fs-4 fw-semibold mb-3">Attachment</div>
                        <div class="col-lg-12 d-flex align-items-center justify-content-start gap-4 flex-wrap"
                            id="history_attachments"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal - Accept -->
    <div class="modal fade" id="kt_modal_requirement_accept" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <div class="modal-dialog modal-md">
            <div class="modal-content rounded">
                <div class="modal-body pt-0 pb-9 px-9 px-xl-10">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                                <div class="swal2-icon-content">?</div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="swal2-html-container" style="display: block;">
                                <div class="message_cnt"></div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="2" placeholder="Enter Reason"></textarea>
                            <div class="message_err text-danger"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center pt-8">
                        <button type="button" class="btn btn-danger me-3 approve_btn" onclick="Ticket_Status(1)">Yes,
                            Accept</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal - Reject -->
    <div class="modal fade" id="kt_modal_requirement_reject" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <div class="modal-dialog modal-md">
            <div class="modal-content rounded">
                <div class="modal-body pt-0 pb-9 px-9 px-xl-10">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                                <div class="swal2-icon-content">?</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <div class="swal2-html-container" style="display: block;">
                                <div class="message_cnt"></div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="2" placeholder="Enter Reason"></textarea>
                            <div class="message_err text-danger"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center pt-8">
                        <button type="button" class="btn btn-danger me-3 reject_btn" onclick="Ticket_Status(2)">Yes,
                            Reject</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal - Close with AJAX Upload -->
    <!-- Modal - Close with AJAX Upload -->
    <div class="modal fade" id="kt_modal_requirement_close" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <div class="modal-dialog modal-md">
            <div class="modal-content rounded">
                <div class="modal-body pt-0 pb-9 px-9 px-xl-10">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                                <div class="swal2-icon-content">✔</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <div class="swal2-html-container" style="display: block;">
                                <div class="message_cnt"></div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="2" id="close_reason" placeholder="Enter Reason"></textarea>
                            <div class="message_err text-danger"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Attachments (Max 10 files, 25MB each)</label>

                            <!-- Custom File Upload Area -->
                            <div class="file-upload-area border rounded p-3" style="background: #f8f9fa;">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <div class="btn-group">
                                        <label class="btn btn-primary btn-sm" for="close_attachments">
                                            <i class="mdi mdi-folder-open me-1"></i> Browse Files
                                        </label>
                                        <button type="button" class="btn btn-danger btn-sm" id="reset_attachments"
                                            style="display: none;">
                                            <i class="mdi mdi-refresh me-1"></i> Reset All
                                        </button>
                                    </div>
                                    <span class="text-muted small" id="file_count_display">No files selected</span>
                                </div>

                                <input type="file" id="close_attachments" name="close_attachments[]" multiple
                                    accept=".jpg,.jpeg,.png,.gif,.bmp,.pdf,.doc,.docx,.xls,.xlsx,.txt"
                                    style="display: none;">

                                <!-- Selected Files List -->
                                <div id="selected_files_list" class="mt-2"
                                    style="max-height: 200px; overflow-y: auto;"></div>
                            </div>

                            <!-- Upload Progress & Results -->
                            <div id="uploaded_files_list" class="mt-2"></div>
                            <div class="text-center text-muted mt-2">
                                <small><i class="mdi mdi-information-outline"></i> Supported formats: JPG, PNG, PDF, DOC,
                                    XLS, TXT | Max 25MB per file</small>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center pt-8">
                        <button type="button" class="btn btn-success me-3 close_btn" onclick="closeTicketWithFiles()">
                            <i class="mdi mdi-check-circle me-1"></i> Yes, Close Ticket
                        </button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="mdi mdi-cancel me-1"></i> Cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        /* File Upload Styles */
        .file-upload-area {
            transition: all 0.3s ease;
            border: 1px solid #dee2e6 !important;
        }

        .file-upload-area:hover {
            background: #f1f3f5 !important;
        }

        .selected-file-item {
            background: white;
            border-radius: 5px;
            padding: 8px 12px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-left: 3px solid #0d6efd;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            transition: all 0.2s ease;
        }

        .selected-file-item:hover {
            background: #e3f2fd;
            transform: translateX(2px);
        }

        .selected-file-item .file-info {
            display: flex;
            align-items: center;
            gap: 10px;
            flex: 1;
            overflow: hidden;
        }

        .selected-file-item .file-icon {
            font-size: 20px;
            min-width: 24px;
        }

        .selected-file-item .file-name {
            font-size: 13px;
            font-weight: 500;
            color: #333;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .selected-file-item .file-size {
            font-size: 11px;
            color: #666;
            margin-left: 10px;
        }

        .selected-file-item .remove-file-btn {
            background: none;
            border: none;
            color: #dc3545;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: 4px;
            transition: all 0.2s ease;
            font-size: 16px;
        }

        .selected-file-item .remove-file-btn:hover {
            background: #dc3545;
            color: white;
        }

        .upload-progress {
            background: #e9ecef;
            border-radius: 5px;
            padding: 10px;
            margin-top: 10px;
        }

        .upload-progress .progress-bar-custom {
            height: 4px;
            background: #0d6efd;
            border-radius: 2px;
            transition: width 0.3s ease;
        }

        .file-badge {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 10px;
            font-weight: 600;
            margin-left: 8px;
        }

        .file-badge.image {
            background: #e3f2fd;
            color: #0d6efd;
        }

        .file-badge.pdf {
            background: #ffebee;
            color: #dc3545;
        }

        .file-badge.document {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .file-badge.excel {
            background: #fff3e0;
            color: #ed6c02;
        }

        .file-badge.other {
            background: #f3e5f5;
            color: #9c27b0;
        }
    </style>

    <!-- Modal - Add Staff Confirmation -->
    <div class="modal fade" id="kt_modal_add_staff_confirmation" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <div class="modal-dialog modal-md">
            <div class="modal-content rounded">
                <div class="modal-header justify-content-end border-0 pb-0">
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                    </div>
                </div>
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-2 text-danger" id="ticket_ids"></h3>
                        <h3 class="text-center mb-4 text-black">Add Staff</h3>
                    </div>
                    <input type="hidden" id="current_ticket_id" name="current_ticket_id">
                    <input type="hidden" id="current_ticket_no" name="current_ticket_no">
                    <input type="hidden" id="current_department" name="current_department">
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Staff<span
                                    class="text-danger">*</span></label>
                            <select id="staff_add" name="staff_add" class="select3 form-select">
                                <option value="" selected>Select Staff</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary me-3" id="btnAddStaff">Add Staff</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('page-script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script>
        // Global variables
        let uploadedCloseFiles = [];
        let currentTicketData = {};
        let currentTicketIdForClose = null;
        let selectedFiles = [];

        // File type icons mapping
        function getFileIcon(filename) {
            const ext = filename.split('.').pop().toLowerCase();
            const icons = {
                'jpg': 'mdi mdi-file-image text-primary',
                'jpeg': 'mdi mdi-file-image text-primary',
                'png': 'mdi mdi-file-image text-primary',
                'gif': 'mdi mdi-file-image text-primary',
                'bmp': 'mdi mdi-file-image text-primary',
                'pdf': 'mdi mdi-file-pdf text-danger',
                'doc': 'mdi mdi-file-word text-primary',
                'docx': 'mdi mdi-file-word text-primary',
                'xls': 'mdi mdi-file-excel text-success',
                'xlsx': 'mdi mdi-file-excel text-success',
                'txt': 'mdi mdi-file-document text-secondary',
                'ppt': 'mdi mdi-file-powerpoint text-warning',
                'pptx': 'mdi mdi-file-powerpoint text-warning',
                'zip': 'mdi mdi-file-zip text-secondary',
                'rar': 'mdi mdi-file-zip text-secondary'
            };
            return icons[ext] || 'mdi mdi-file';
        }

        function getFileBadge(filename) {
            const ext = filename.split('.').pop().toLowerCase();
            if (['jpg', 'jpeg', 'png', 'gif', 'bmp'].includes(ext)) return '<span class="file-badge image">Image</span>';
            if (ext === 'pdf') return '<span class="file-badge pdf">PDF</span>';
            if (['doc', 'docx'].includes(ext)) return '<span class="file-badge document">Word</span>';
            if (['xls', 'xlsx'].includes(ext)) return '<span class="file-badge excel">Excel</span>';
            return '<span class="file-badge other">File</span>';
        }

        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        // Update selected files display
        function updateSelectedFilesDisplay() {
            const container = $('#selected_files_list');
            const countDisplay = $('#file_count_display');
            const resetBtn = $('#reset_attachments');

            if (selectedFiles.length === 0) {
                container.html(
                    '<div class="text-muted text-center py-3"><i class="mdi mdi-cloud-upload fs-1"></i><br><small>No files selected. Click "Browse Files" to upload.</small></div>'
                );
                countDisplay.text('No files selected');
                resetBtn.hide();
                return;
            }

            let html = '';
            selectedFiles.forEach((file, index) => {
                const fileIcon = getFileIcon(file.name);
                const fileBadge = getFileBadge(file.name);
                const fileSize = formatFileSize(file.size);

                html += `
            <div class="selected-file-item" data-index="${index}">
                <div class="file-info">
                    <i class="${fileIcon} file-icon"></i>
                    <div class="flex-grow-1">
                        <div class="file-name" title="${file.name}">
                            ${file.name.length > 40 ? file.name.substring(0, 37) + '...' : file.name}
                            ${fileBadge}
                        </div>
                        <small class="text-muted">${fileSize}</small>
                    </div>
                </div>
                <button type="button" class="remove-file-btn" onclick="removeSelectedFile(${index})" title="Remove file">
                    <i class="mdi mdi-close"></i>
                </button>
            </div>
        `;
            });

            container.html(html);
            countDisplay.text(`${selectedFiles.length} file(s) selected (${formatFileSize(getTotalFileSize())})`);
            resetBtn.show();
        }

        function getTotalFileSize() {
            return selectedFiles.reduce((total, file) => total + file.size, 0);
        }

        function removeSelectedFile(index) {
            selectedFiles.splice(index, 1);
            updateSelectedFilesDisplay();

            // Update the actual file input
            const dataTransfer = new DataTransfer();
            selectedFiles.forEach(file => {
                dataTransfer.items.add(file);
            });
            document.getElementById('close_attachments').files = dataTransfer.files;
        }

        function resetAllFiles() {
            selectedFiles = [];
            updateSelectedFilesDisplay();
            $('#close_attachments').val('');
            $('#uploaded_files_list').html('');
            // toastr.info('All files have been cleared');
        }

        // Handle file selection
        $(document).ready(function() {
            // File input change handler
            $('#close_attachments').on('change', function(e) {
                const files = Array.from(e.target.files);
                const maxSize = 25 * 1024 * 1024; // 25MB
                const maxFiles = 10;

                // Check max files
                if (selectedFiles.length + files.length > maxFiles) {
                    toastr.error(
                        `Maximum ${maxFiles} files allowed. You already have ${selectedFiles.length} file(s).`
                    );
                    return;
                }

                // Validate each file
                let validFiles = [];
                for (let file of files) {
                    if (file.size > maxSize) {
                        toastr.error(`File "${file.name}" exceeds 25MB limit`);
                        continue;
                    }
                    validFiles.push(file);
                }

                if (validFiles.length > 0) {
                    selectedFiles = [...selectedFiles, ...validFiles];
                    updateSelectedFilesDisplay();
                }

                // Clear the input to allow re-selecting the same files
                $(this).val('');
            });

            // Reset button handler
            $('#reset_attachments').on('click', function() {
                resetAllFiles();
            });

            // Initialize Select2
            $('.select3').select2({
                dropdownParent: $('#kt_modal_add_staff_confirmation'),
                placeholder: "Select Staff",
                allowClear: true
            });

            // Add Staff button handler
            $('#btnAddStaff').on('click', function() {
                var staffId = $('#staff_add').val();
                var ticketId = $('#current_ticket_id').val();
                var ticketNo = $('#current_ticket_no').val();

                if (!staffId) {
                    toastr.warning('Please select a staff member');
                    return;
                }
                updateAssignStaff(ticketId, ticketNo, staffId);
            });

            // Reset add staff modal
            $('#kt_modal_add_staff_confirmation').on('hidden.bs.modal', function() {
                $('#staff_add').val('').trigger('change');
                $('#current_ticket_id').val('');
                $('#current_ticket_no').val('');
                $('#ticket_ids').html('');
                $('#current_department').val('');
            });

            // Reset close modal
            $('#kt_modal_requirement_close').on('hidden.bs.modal', function() {
                $('#close_reason').val('');
                resetAllFiles();
                $('#uploaded_files_list').html('');
                $('.message_err').html('');
                uploadedCloseFiles = [];
                currentTicketIdForClose = null;
            });
        });

        // Search and filter functions
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(25);
                $('#search_form').submit();
            }
        }

        // Status change functions
        function StatusChangeTicket(id, type) {
            fetch(`/customer-management/ticket_details/${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        if (type == 1) {
                            let btn = document.querySelector('#kt_modal_requirement_accept .approve_btn');
                            btn.setAttribute('data-id', id);
                            $('#kt_modal_requirement_accept .message_cnt').html(`
                        Are you sure you want to accept this ticket?
                        <br><br>
                        <b class="text-success fw-bold fs-4">${data.data.ticket_id}</b><br>
                    `);
                        } else if (type == 2) {
                            let btn = document.querySelector('#kt_modal_requirement_reject .reject_btn');
                            btn.setAttribute('data-id', id);
                            $('#kt_modal_requirement_reject .message_cnt').html(`
                        Are you sure you want to reject this ticket?
                        <br><br>
                        <b class="text-danger fw-bold fs-4">${data.data.ticket_id}</b><br>
                    `);
                        } else if (type == 3) {
                            currentTicketIdForClose = id;
                            let btn = document.querySelector('#kt_modal_requirement_close .close_btn');
                            btn.setAttribute('data-id', id);
                            $('#kt_modal_requirement_close .message_cnt').html(`
                        Are you sure you want to close this ticket?
                        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
                            ${data.data.ticket_id}
                        </div>
                    `);
                            // Reset everything when opening modal
                            resetAllFiles();
                            $('#close_reason').val('');
                            $('#uploaded_files_list').html('');
                            $('.message_err').html('');
                            uploadedCloseFiles = [];
                        }
                    }
                })
                .catch(error => {
                    console.error('Error fetching:', error);
                    toastr.error('Failed to load ticket details');
                });
        }

        // AJAX File Upload Function with Progress
        function uploadFiles(files) {
            return new Promise((resolve, reject) => {
                if (!files || files.length === 0) {
                    resolve([]);
                    return;
                }

                let formData = new FormData();
                for (let i = 0; i < files.length; i++) {
                    formData.append('file[]', files[i]);
                }
                formData.append('_token', '{{ csrf_token() }}');

                // Show uploading indicator with progress
                $('#uploaded_files_list').html(`
            <div class="upload-progress">
                <div class="d-flex justify-content-between mb-1">
                    <small>Uploading ${files.length} file(s)...</small>
                    <small class="upload-percent">0%</small>
                </div>
                <div class="progress-bar-custom" style="width: 0%"></div>
            </div>
        `);

                $.ajax({
                    url: '/customer-management/upload-ticket-attachment',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    xhr: function() {
                        const xhr = new window.XMLHttpRequest();
                        xhr.upload.addEventListener('progress', function(e) {
                            if (e.lengthComputable) {
                                const percent = Math.round((e.loaded / e.total) * 100);
                                $('.upload-progress .progress-bar-custom').css('width',
                                    percent + '%');
                                $('.upload-percent').text(percent + '%');
                            }
                        });
                        return xhr;
                    },
                    success: function(response) {
                        if (response.status === 'success') {
                            // Display uploaded files list
                            let filesHtml =
                                '<div class="alert alert-success alert-sm mb-2">✅ Uploaded successfully:</div><div class="list-group list-group-flush" style="max-height: 150px; overflow-y: auto;">';
                            response.files.forEach(file => {
                                const fileIcon = getFileIcon(file.file_name);
                                filesHtml += `
                            <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-1">
                                <div>
                                    <i class="${fileIcon} me-2"></i>
                                    <small>${file.file_name.length > 30 ? file.file_name.substring(0, 27) + '...' : file.file_name}</small>
                                </div>
                                <span class="badge bg-success rounded-pill">${formatFileSize(file.file_size)}</span>
                            </div>
                        `;
                            });
                            filesHtml += '</div>';
                            $('#uploaded_files_list').html(filesHtml);
                            toastr.success(response.message);
                            resolve(response.files);
                        } else {
                            $('#uploaded_files_list').html('<div class="alert alert-danger">❌ ' +
                                response.message + '</div>');
                            toastr.error(response.message);
                            reject(response.message);
                        }
                    },
                    error: function(xhr) {
                        let errorMsg = xhr.responseJSON?.message || 'Upload failed';
                        $('#uploaded_files_list').html('<div class="alert alert-danger">❌ ' + errorMsg +
                            '</div>');
                        toastr.error(errorMsg);
                        reject(errorMsg);
                    }
                });
            });
        }

        // Close ticket with file uploads
        async function closeTicketWithFiles() {
            let message = $('#close_reason').val();
            let files = selectedFiles; // Use selectedFiles instead of direct input

            if (message == '') {
                $('.message_err').html('Reason is required!');
                return false;
            }

            $('.message_err').html('');
            let btn = $('.close_btn');
            let originalText = btn.html();
            btn.html('<i class="mdi mdi-loading mdi-spin me-1"></i> Processing...').prop('disabled', true);

            try {
                let uploadedFiles = [];
                if (files.length > 0) {
                    if (files.length > 10) {
                        toastr.error('Maximum 10 files allowed');
                        btn.html(originalText).prop('disabled', false);
                        return;
                    }
                    uploadedFiles = await uploadFiles(files);
                }

                // Update ticket status
                let response = await fetch('/customer-management/update_ticket/' + currentTicketIdForClose, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        status: 3,
                        message: message,
                        who: 0,
                        attachments: uploadedFiles
                    })
                });

                let data = await response.json();

                if (data.status === 200) {
                    $('#kt_modal_requirement_close').modal('hide');
                    toastr.success(data.message);
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                } else {
                    toastr.error(data.message || 'Something went wrong!');
                }
            } catch (error) {
                console.error('Error:', error);
                toastr.error('Something went wrong!');
            } finally {
                btn.html(originalText).prop('disabled', false);
            }
        }

        function Ticket_Status(status) {
            let modalId = '';
            let btnSelector = '';

            if (status == 1) {
                modalId = '#kt_modal_requirement_accept';
                btnSelector = '.approve_btn';
            } else if (status == 2) {
                modalId = '#kt_modal_requirement_reject';
                btnSelector = '.reject_btn';
            }

            let btn = document.querySelector(modalId + ' ' + btnSelector);
            let TicketId = btn.getAttribute('data-id');

            $(modalId + ' .message_err').html('');
            let message = $(modalId + ' textarea').val() || '';

            if (message == '') {
                $(modalId + ' .message_err').html('Reason is required!');
                return false;
            }

            let originalText = $(modalId + ' ' + btnSelector).text();
            $(modalId + ' ' + btnSelector).text('Processing...').prop('disabled', true);

            fetch('/customer-management/update_ticket/' + TicketId, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        status: status,
                        message: message,
                        who: 0,
                        attachments: []
                    })
                })
                .then(response => response.json())
                .then(data => {
                    $(modalId + ' ' + btnSelector).text(originalText).prop('disabled', false);

                    if (data.status === 200) {
                        $(modalId).modal('hide');
                        toastr.success(data.message);
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        toastr.error(data.message || 'Something went wrong!');
                    }
                })
                .catch(error => {
                    $(modalId + ' ' + btnSelector).text(originalText).prop('disabled', false);
                    console.error('Error:', error);
                    toastr.error('Something went wrong!');
                });
        }

        // Ticket history functions (keep your existing functions)
        function ViewTicketHistory(ticketId) {
            fetch(`/customer-management/ticket-history/${ticketId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        populateTicketHistory(data.data);
                        $('#kt_modal_ticket_history').modal('show');
                    } else {
                        toastr.error('Failed to load ticket history');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    toastr.error('Something went wrong!');
                });
        }

        function populateTicketHistory(data) {
            const ticket = data.ticket;
            const customer = data.customer;
            const cre = data.cre;
            const history = data.history;
            const customerAttachments = data.customer_attachments || [];
            const staffAttachments = data.staff_attachments || [];

            // Basic ticket information
            $('#history_customer_name').text(customer?.name || 'N/A');
            $('#history_customer_mobile').text(customer?.mobile || 'N/A');
            $('#history_requirement').text(ticket.subject || 'N/A');
            $('#history_description').text(ticket.ticket_description || 'N/A');
            $('#history_services_id').text(ticket.services_id || 'N/A');
            $('#history_service').text(ticket.service_name || 'N/A');
            $('#history_ticket_id').text(ticket.ticket_id || ticket.ticket_sno || 'N/A');
            $('#history_cre').text(cre?.user_name || cre?.name || ticket.cre_id || 'N/A');
            $('#history_created_at').text(formatDate(ticket.created_at));
            $('#history_status').html(getStatusBadge(ticket.status));

            // Build attachments HTML with separate sections
            let attachmentsHtml = '';

            // ========== CUSTOMER ATTACHMENTS SECTION ==========
            if (customerAttachments.length > 0) {
                attachmentsHtml += `
            <div class="attachments-section mb-4">
                <div class="d-flex align-items-center mb-3 pb-2 border-bottom">
                    <i class="mdi mdi-account-circle text-primary me-2 fs-4"></i>
                    <strong class="text-primary fs-5">Customer Attachments</strong>
                    <span class="badge bg-primary ms-2">${customerAttachments.length}</span>
                </div>
                <div class="d-flex flex-wrap gap-3">
        `;

                customerAttachments.forEach((doc, index) => {
                    const fileIcon = getFileIcon(doc.file_name);
                    const fileSize = formatFileSize(doc.file_size || 0);
                    const fileExt = doc.file_name.split('.').pop().toLowerCase();
                    const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp'].includes(fileExt);

                    attachmentsHtml += `
                <div class="attachment-item position-relative text-center" style="width: 110px;" data-index="${index}">
                    ${isImage ? `
                                <a href="/${doc.file_path}" target="_blank" class="text-decoration-none">
                                    <div class="attachment-icon-wrapper bg-light rounded p-2 text-center position-relative">
                                        <img src="/${doc.file_path}" alt="${doc.file_name}" 
                                             style="width: 60px; height: 60px; object-fit: cover; border-radius: 5px;"
                                             onerror="this.src='/assets/images/no-image.png'">
                                    </div>
                                    <small class="d-block text-truncate mt-1" style="max-width: 100px;" title="${doc.file_name}">
                                        ${doc.file_name.length > 15 ? doc.file_name.substring(0, 12) + '...' : doc.file_name}
                                    </small>
                                    <small class="text-muted" style="font-size: 10px;">${fileSize}</small>
                                </a>
                            ` : `
                                <a href="/${doc.file_path}" download class="text-decoration-none">
                                    <div class="attachment-icon-wrapper bg-light rounded p-2 text-center">
                                        <i class="${fileIcon} fs-1"></i>
                                    </div>
                                    <small class="d-block text-truncate mt-1" style="max-width: 100px;" title="${doc.file_name}">
                                        ${doc.file_name.length > 15 ? doc.file_name.substring(0, 12) + '...' : doc.file_name}
                                    </small>
                                    <small class="text-muted" style="font-size: 10px;">${fileSize}</small>
                                </a>
                            `}
                    <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-1 view-file-btn" 
                            onclick="viewFile('${doc.file_path}', '${doc.file_name}')" 
                            style="font-size: 10px;">
                        <i class="mdi mdi-eye"></i> View
                    </button>
                </div>
            `;
                });

                attachmentsHtml += `
                </div>
            </div>
        `;
            }

            // ========== STAFF ATTACHMENTS SECTION ==========
            if (staffAttachments.length > 0) {
                attachmentsHtml += `
            <div class="attachments-section mb-4">
                <div class="d-flex align-items-center mb-3 pb-2 border-bottom">
                    <i class="mdi mdi-account-tie text-success me-2 fs-4"></i>
                    <strong class="text-success fs-5">Staff Attachments</strong>
                    <span class="badge bg-success ms-2">${staffAttachments.length}</span>
                </div>
                <div class="d-flex flex-wrap gap-3">
        `;

                staffAttachments.forEach((doc, index) => {
                    const fileIcon = getFileIcon(doc.file_name);
                    const fileSize = formatFileSize(doc.file_size || 0);
                    const fileExt = doc.file_name.split('.').pop().toLowerCase();
                    const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp'].includes(fileExt);

                    attachmentsHtml += `
                <div class="attachment-item position-relative text-center" style="width: 110px;" data-index="${index}">
                    ${isImage ? `
                                <a href="/${doc.file_path}" target="_blank" class="text-decoration-none">
                                    <div class="attachment-icon-wrapper bg-light rounded p-2 text-center position-relative">
                                        <img src="/${doc.file_path}" alt="${doc.file_name}" 
                                             style="width: 60px; height: 60px; object-fit: cover; border-radius: 5px;"
                                             onerror="this.src='/assets/images/no-image.png'">
                                    </div>
                                    <small class="d-block text-truncate mt-1" style="max-width: 100px;" title="${doc.file_name}">
                                        ${doc.file_name.length > 15 ? doc.file_name.substring(0, 12) + '...' : doc.file_name}
                                    </small>
                                    <small class="text-muted" style="font-size: 10px;">${fileSize}</small>
                                </a>
                            ` : `
                                <a href="/${doc.file_path}" download class="text-decoration-none">
                                    <div class="attachment-icon-wrapper bg-light rounded p-2 text-center">
                                        <i class="${fileIcon} fs-1"></i>
                                    </div>
                                    <small class="d-block text-truncate mt-1" style="max-width: 100px;" title="${doc.file_name}">
                                        ${doc.file_name.length > 15 ? doc.file_name.substring(0, 12) + '...' : doc.file_name}
                                    </small>
                                    <small class="text-muted" style="font-size: 10px;">${fileSize}</small>
                                </a>
                            `}
                    <button type="button" class="btn btn-sm btn-link text-primary p-0 mt-1 view-file-btn" 
                            onclick="viewFile('${doc.file_path}', '${doc.file_name}')" 
                            style="font-size: 10px;">
                        <i class="mdi mdi-eye"></i> View
                    </button>
                </div>
            `;
                });

                attachmentsHtml += `
                </div>
            </div>
        `;
            }

            // No attachments message
            if (customerAttachments.length === 0 && staffAttachments.length === 0) {
                attachmentsHtml = `
            <div class="text-center text-muted py-4">
                <i class="mdi mdi-paperclip fs-1 mb-2 d-block"></i>
                <p>No attachments found for this ticket</p>
            </div>
        `;
            }

            $('#history_attachments').html(attachmentsHtml);

            // ========== TIMELINE SECTION ==========
            let timelineHtml = '';
            if (history && history.length > 0) {
                [...history].reverse().forEach((item, index) => {
                    const isLast = index === history.length - 1;
                    const statusBadge = getStatusBadge(item.status);
                    const createdDate = formatDate(item.created_at);
                    const froms = item.who == 0 ? 'Staff' : 'Customer';
                    const fromIcon = item.who == 0 ? 'mdi-account-tie' : 'mdi-account-circle';
                    const fromColor = item.who == 0 ? 'text-success' : 'text-primary';

                    timelineHtml += `
                <div class="timeline-row">
                    <div class="timeline-time ${!isLast ? 'pb-5' : ''}">${createdDate}</div>
                    <div class="timeline-center">
                        <span class="timeline-dot" style="background: ${item.who == 0 ? '#28a745' : '#0d6efd'}"></span>
                        ${!isLast ? '<span class="timeline-line"></span>' : ''}
                    </div>
                    <div class="timeline-content">
                        <div class="d-flex align-items-center gap-3 pb-1">
                            <i class="mdi ${fromIcon} ${fromColor} fs-5"></i>
                            <label class="fs-6 text-dark fw-semibold pb-0">${escapeHtml(froms)}</label>
                            ${statusBadge}
                        </div>
                        ${item.message ? `<p class="mb-0 mt-2">${escapeHtml(item.message)}</p>` : ''}
                    </div>
                </div>
            `;
                });
            } else {
                timelineHtml = '<div class="text-center text-muted py-4">No history available</div>';
            }
            $('#history_timeline').html(timelineHtml);
        }

        // Function to view file in modal or new tab
        function viewFile(filePath, fileName) {
            // Open in new tab
            window.open('/' + filePath, '_blank');
        }

        // Staff assignment functions (keep your existing functions)
        function openStaffModal(ticketId, ticketNo, department) {
            currentTicketData = {
                ticket_id: ticketId,
                ticket_no: ticketNo,
                department: department
            };

            $('#current_ticket_id').val(ticketId);
            $('#current_ticket_no').val(ticketNo);
            $('#ticket_ids').html(ticketNo);
            $('#current_department').val(department);

            loadStaffList(department);
            $('#kt_modal_add_staff_confirmation').modal('show');
        }

        function loadStaffList(department) {
            $('#staff_add').html('<option value="">Loading staff...</option>');
            $('#staff_add').prop('disabled', true);

            $.ajax({
                url: "{{ route('get_staff_list') }}",
                type: "GET",
                data: {
                    dept: department
                },
                success: function(response) {
                    var staffDropdown = $('#staff_add');
                    staffDropdown.empty();
                    staffDropdown.prop('disabled', false);

                    if (response.status === 200 && response.data && response.data.length > 0) {
                        staffDropdown.append('<option value="">Select Staff</option>');
                        response.data.forEach(function(staff) {
                            var staffName = staff.staff_name.charAt(0).toUpperCase() +
                                staff.staff_name.slice(1).toLowerCase() +
                                " - " + staff.nick_name;
                            staffDropdown.append($('<option></option>')
                                .attr('value', staff.sno)
                                .text(staffName));
                        });
                    } else {
                        staffDropdown.append('<option value="">No staff available</option>');
                        toastr.warning('No staff found for this department');
                    }
                },
                error: function(error) {
                    console.error('Error fetching staff list:', error);
                    $('#staff_add').empty();
                    $('#staff_add').append('<option value="">Error loading staff</option>');
                    $('#staff_add').prop('disabled', false);
                    toastr.error('Failed to load staff list');
                }
            });
        }

        function updateAssignStaff(ticketId, ticketNo, staffId) {
            $.ajax({
                url: "{{ route('update_assign_staff_ticket') }}",
                type: "POST",
                data: {
                    ticket_id: ticketId,
                    ticket_no: ticketNo,
                    staff_id: staffId,
                    _token: "{{ csrf_token() }}"
                },
                beforeSend: function() {
                    $('#btnAddStaff').html(
                        '<span class="spinner-border spinner-border-sm me-2"></span>Assigning...');
                    $('#btnAddStaff').prop('disabled', true);
                },
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        $('#kt_modal_add_staff_confirmation').modal('hide');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(error) {
                    console.error('Error updating staff:', error);
                    toastr.error('Failed to assign staff');
                },
                complete: function() {
                    $('#btnAddStaff').html('Add Staff');
                    $('#btnAddStaff').prop('disabled', false);
                }
            });
        }

        function formatDate(dateString) {
            if (!dateString) return 'N/A';
            const date = new Date(dateString);
            return date.toLocaleString('en-IN', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        function getStatusBadge(status) {
            const badges = {
                0: '<span class="badge bg-danger text-white">Open</span>',
                1: '<span class="badge bg-warning text-dark">Accepted</span>',
                2: '<span class="badge bg-dark text-white">Rejected</span>',
                3: '<span class="badge" style="background:darkgreen; color:white;">Closed</span>',
                4: '<span class="badge" style="background:linear-gradient(135deg, #667eea 0%, #764ba2 100%); color:white;">Reopened</span>',
                5: '<span class="badge bg-success text-white">Completed</span>'
            };
            return badges[status] || '<span class="badge bg-secondary">Unknown</span>';
        }

        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    </script>
    <style>
        /* Attachment Styles */
        .attachments-section {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .attachments-section:last-child {
            margin-bottom: 0;
        }

        .attachment-item {
            transition: all 0.3s ease;
            background: white;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .attachment-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .attachment-icon-wrapper {
            width: 80px;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            margin: 0 auto;
            overflow: hidden;
        }

        .attachment-item:hover .attachment-icon-wrapper {
            background: #e3f2fd !important;
        }

        .view-file-btn {
            opacity: 0.7;
            transition: opacity 0.3s ease;
        }

        .view-file-btn:hover {
            opacity: 1;
            text-decoration: underline;
        }

        /* Timeline enhancements */
        .timeline-row {
            margin-bottom: 5px;
        }

        .timeline-content {
            background: #f8f9fa;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin-bottom: 5px;
        }

        .timeline-content:hover {
            background: #e9ecef;
        }

        /* Border bottom for sections */
        .border-bottom {
            border-bottom: 2px solid #dee2e6 !important;
        }

        /* Image preview */
        .attachment-icon-wrapper img {
            transition: transform 0.3s ease;
        }

        .attachment-icon-wrapper img:hover {
            transform: scale(1.05);
        }
    </style>
@endsection
