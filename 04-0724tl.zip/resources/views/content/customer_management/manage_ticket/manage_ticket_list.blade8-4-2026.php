@extends('layouts/layoutMaster')

@section('title', 'Manage Ticket')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }

        .select2-results__group {
            color: #F0913D !important;
        }
    </style>
    <style>
        .timeline-wrapper {
            width: 100%;
            margin: 20px auto;
            margin-top: 0px;
        }

        .timeline-row {
            display: grid;
            grid-template-columns: 100px 40px 1fr;
            align-items: stretch;
            /* KEY FIX */
            /* margin-bottom: 25px; */
        }

        /* TIME */
        .timeline-time {
            text-align: right;
            padding-right: 10px;
            font-size: 14px;
            color: #555;
            font-weight: 500;
        }

        /* CENTER COLUMN FIX */
        .timeline-center {
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100%;
            /* Fills row height automatically */
            position: relative;
            /* border: 1px solid red; */
        }

        .timeline-dot {
            width: 14px;
            height: 14px;
            background: #0d6efd;
            border-radius: 50%;
            z-index: 2;
        }

        /* AUTO-ADJUSTING LINE */
        .timeline-line {
            width: 2px;
            background: #ced4da;
            flex-grow: 1;
            /* LINE AUTO ADJUSTS */
            margin-top: 4px;
        }

        /* Remove line from last item */
        .timeline-row:last-child .timeline-line {
            display: none;
        }

        /* CONTENT */
        .timeline-content {
            padding-left: 10px;
        }
    </style>
    <style>
        .overlay-wrapper:hover .overlay-layer {
            opacity: 1 !important;
            transition: 0.3s ease;
        }
    </style>

    @php
        $helper = new \App\Helpers\Helpers();
    @endphp
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Ticket</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-3"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-3"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="d-flex flex-wrap align-items-center gap-3">
                    <!-- Total Tickets -->
                    <div class="card rounded border bg-white flex-grow-1"
                        style="box-shadow:2px 2px #b2cdff; min-width:160px; max-width:200px;">
                        <div class="d-flex align-items-center justify-content-between py-3 px-2">
                            <div class="d-flex flex-column">
                                <label class="text-secondary fw-medium fs-8">Total Tickets</label>
                                <label class="text-black fw-semibold fs-3">{{ sprintf('%02d', $total_ticket ?? 0) }}</label>
                            </div>
                            <div class="bg-gray-100 p-3 rounded">
                                <span class="mdi mdi-text-box text-info fs-3"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Open Tickets -->
                    <div class="card rounded border bg-white flex-grow-1"
                        style="box-shadow:2px 2px #FFB2B2; min-width:160px; max-width:200px;">
                        <div class="d-flex align-items-center justify-content-between py-3 px-2">
                            <div class="d-flex flex-column">
                                <label class="text-secondary fw-medium fs-8">Open Tickets</label>
                                <label class="text-black fw-semibold fs-3">{{ sprintf('%02d', $open_ticket ?? 0) }}</label>
                            </div>
                            <div class="bg-gray-100 p-3 rounded">
                                <span class="mdi mdi-ticket-confirmation text-danger fs-3"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Accepted Tickets -->
                    <div class="card rounded border bg-white flex-grow-1"
                        style="box-shadow:2px 2px #F7DB91; min-width:160px; max-width:200px;">
                        <div class="d-flex align-items-center justify-content-between py-3 px-2">
                            <div class="d-flex flex-column">
                                <label class="text-secondary fw-medium fs-8">Accepted Tickets</label>
                                <label
                                    class="text-black fw-semibold fs-3">{{ sprintf('%02d', $accepted_ticket ?? 0) }}</label>
                            </div>
                            <div class="bg-gray-100 p-3 rounded">
                                <span class="mdi mdi-clock-time-four fs-3" style="color:#FFBC4C;"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Rejected Tickets -->
                    <div class="card rounded border bg-white flex-grow-1"
                        style="box-shadow:2px 2px #A6AEBF; min-width:160px; max-width:200px;">
                        <div class="d-flex align-items-center justify-content-between py-3 px-2">
                            <div class="d-flex flex-column">
                                <label class="text-secondary fw-medium fs-8">Rejected Tickets</label>
                                <label
                                    class="text-black fw-semibold fs-3">{{ sprintf('%02d', $rejected_ticket ?? 0) }}</label>
                            </div>
                            <div class="bg-gray-100 p-3 rounded">
                                <span class="mdi mdi-alpha-x-circle text-secondary fs-3"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Closed Tickets -->
                    <div class="card rounded border bg-white flex-grow-1"
                        style="box-shadow:2px 2px #ABE7B2; min-width:160px; max-width:200px;">
                        <div class="d-flex align-items-center justify-content-between py-3 px-2">
                            <div class="d-flex flex-column">
                                <label class="text-secondary fw-medium fs-8">Closed Tickets</label>
                                <label
                                    class="text-black fw-semibold fs-3">{{ sprintf('%02d', $closed_ticket ?? 0) }}</label>
                            </div>
                            <div class="bg-gray-100 p-3 rounded">
                                <span class="mdi mdi-check-circle text-success fs-3"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Reopen Tickets -->
                    <div class="card rounded border bg-white flex-grow-1"
                        style="box-shadow:2px 2px #EDA35A; min-width:160px; max-width:200px;">
                        <div class="d-flex align-items-center justify-content-between py-3 px-2">
                            <div class="d-flex flex-column">
                                <label class="text-secondary fw-medium fs-8">Reopen Tickets</label>
                                <label
                                    class="text-black fw-semibold fs-3">{{ sprintf('%02d', $reopen_ticket ?? 0) }}</label>
                            </div>
                            <div class="bg-gray-100 p-3 rounded">
                                <span class="mdi mdi-ticket fs-3" style="color:#FFA239;"></span>
                            </div>
                        </div>
                    </div>
                    <!-- Complete Tickets -->
                    <div class="card rounded border bg-white flex-grow-1"
                        style="box-shadow:2px 2px #88c162; min-width:160px; max-width:200px;">
                        <div class="d-flex align-items-center justify-content-between py-3 px-2">
                            <div class="d-flex flex-column">
                                <label class="text-secondary fw-medium fs-8">Completed Tickets</label>
                                <label
                                    class="text-black fw-semibold fs-3">{{ sprintf('%02d', $completed_ticket ?? 0) }}</label>
                            </div>
                            <div class="bg-gray-100 p-3 rounded">
                                <span class="mdi mdi-text-box-check fs-3" style="color:#449a4e;"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="row mb-2 mt-2">
                        <div class="col-lg-2">
                            @php $perpage_count = $perpage ? $perpage : 10; @endphp
                            <div>
                                <span>Show</span>
                                <br>
                                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                    onchange="sort_filter(this.value);">
                                    @php
                                        $options = [10, 25, 100, 500]; // Define available options
                                    @endphp
                                    @foreach ($options as $option)
                                        <option value="{{ $option }}"
                                            @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                            @php echo $option; @endphp
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-10 d-flex align-items-end justify-content-end">
                            <form id="search_form" method="POST" action="/manage_customer_ticket">
                                @csrf
                                <div class="d-flex align-items-center gap-2">
                                    <div class="">
                                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                        <input type="hidden" name="filter_on" value="1">
                                        <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                            id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                        <input type="text" class="form-control" id="search_fill" name="search_fill"
                                            value="{{ $search_fill ?? '' }}" placeholder="Enter Search" />
                                    </div>
                                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                        onclick="search_filter_func()">Search</button>
                                    <a href="{{ url('/manage_customer_ticket') }}" type="button"
                                        class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span
                                            class="mdi mdi-refresh fs-6"></span>
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th style="min-width: 163px;">Ticket ID</th>
                                <th class="min-w-150px">Service</th>
                                <th class="min-w-150px">Customer</th>
                                <th class="min-w-150px">Requirement</th>
                                <th class="min-w-80px">
                                    <label class="ps-2">CRE</label>
                                </th>
                                <th class="min-w-50px">Documents</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-50px text-start">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">

                            @if (count($List) > 0)
                                @foreach ($List as $i => $list)
                                    <tr>
                                        <td>
                                            <label class="text-danger fs-7">{{ $list->ticket_id }}</label>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-truncate max-w-150px" data-bs-toggle="tooltip"
                                                    data-bs-placement="top"
                                                    data-bs-original-title="{{ $list->service_name }}">{{ $list->service_name }}</label>
                                                @php
                                                    $year = date('Y', strtotime($list->service_created_at));
                                                    $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
                                                    $service_id = "SR-{$id}/{$year}";
                                                @endphp
                                                <label class="fs-8 text-info">{{ $service_id }}</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label>{{ $list->cus_name }}</label>
                                                <label class="text-info fs-8">{{ $list->cus_ai_id }}</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-7 fw-semibold text-truncate" style="max-width:150px;"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="{!! $list->subject !!}">{!! $list->subject !!}</label>
                                        </td>
                                        <td>
                                            @php
                                                $cre_staff_details = $helper->staff_details($list->cre_id);
                                            @endphp
                                            @if (
                                                $cre_staff_details->staff_image != '' &&
                                                    file_exists(public_path('staff_images/' . $cre_staff_details->staff_image)))
                                                <div class="avatar avatar-lg" data-bs-toggle="tooltip"
                                                    data-bs-placement="top"
                                                    title="Cre: {{ $cre_staff_details->staff_name }}">
                                                    <img src="{{ asset('staff_images/' . $cre_staff_details->staff_image) }}"
                                                        alt="avatar" class="rounded-circle img-fluid">
                                                </div>
                                            @else
                                                <div class="symbol symbol-35px me-2" data-bs-toggle="tooltip"
                                                    data-bs-placement="top"
                                                    title="Cre: {{ $cre_staff_details->staff_name }}">
                                                    @php
                                                        $initial = strtoupper(
                                                            substr($cre_staff_details->staff_name, 0, 1),
                                                        ); // Only keeps and
                                                        // capitalizes the first
                                                        echo $helper->name_image($initial, $cre_staff_details->gender);
                                                    @endphp
                                                </div>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="dropdown position-relative">
                                                @php
                                                    // Decode the JSON string to array
                                                    $isDocuments = json_decode($list->attachments, true);
                                                @endphp
                                                @if ($isDocuments && !empty($isDocuments))
                                                    <div class="dropdown position-relative">
                                                        <button type="button"
                                                            class="btn btn-outline-primary text-nowrap d-inline-block position-relative dropdown-toggle d-flex align-items-center"
                                                            type="button" data-bs-toggle="dropdown">
                                                            <i class="mdi mdi-tray-arrow-down me-2"></i>
                                                            @if (count($isDocuments) > 1)
                                                                <span
                                                                    class="badge text-bg-danger position-absolute top-0 start-100 translate-middle">{{ count($isDocuments) }}</span>
                                                                <span class="visually-hidden">Documents Count</span>
                                                            @endif
                                                        </button>

                                                        <ul class="dropdown-menu" style="max-width: 300px;">
                                                            @foreach ($isDocuments as $index => $document)
                                                                @php
                                                                    $driveLink = asset($document['file_path']);
                                                                    $fileName =
                                                                        $document['file_name'] ??
                                                                        'document_' . ($index + 1);
                                                                    $fileExtension = pathinfo(
                                                                        $fileName,
                                                                        PATHINFO_EXTENSION,
                                                                    );

                                                                    // Simple icon mapping if helper not available
                                                                    $iconClass = match (strtolower($fileExtension)) {
                                                                        'pdf' => 'mdi mdi-file-pdf text-danger',
                                                                        'doc',
                                                                        'docx'
                                                                            => 'mdi mdi-file-word text-primary',
                                                                        'xls',
                                                                        'xlsx'
                                                                            => 'mdi mdi-file-excel text-success',
                                                                        'jpg',
                                                                        'jpeg',
                                                                        'png',
                                                                        'gif',
                                                                        'bmp'
                                                                            => 'mdi mdi-file-image text-info',
                                                                        'txt' => 'mdi mdi-file-document text-secondary',
                                                                        default => 'mdi mdi-file',
                                                                    };
                                                                @endphp
                                                                <li>
                                                                    <a class="dropdown-item" href="{{ $driveLink }}"
                                                                        download
                                                                        style="white-space: normal; word-wrap: break-word;">
                                                                        <i class="{{ $iconClass }} me-2"></i>
                                                                        {{ $fileName }}
                                                                        <small class="text-muted d-block">Click to
                                                                            download</small>
                                                                    </a>
                                                                </li>
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                @else
                                                    <img src="{{ asset('assets/phdizone_images/newmultiply.png') }}"
                                                        alt="avatar" class="rounded-circle img-fluid"
                                                        style="width: 40px; height: 40px; object-fit: cover;"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="No Documents Uploaded">
                                                @endif
                                            </div>
                                        </td>
                                        <td>
                                            @if ($list->status == 0)
                                                {{-- Open --}}
                                                <a href="javascript:;"
                                                    class="badge bg-danger text-white rounded fw-semibold fs-8 px-3"
                                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Open <span class="mdi mdi-chevron-down"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirement_accept"
                                                        onclick="StatusChangeTicket('{{ $list->ticket_sno }}', 1)">Accept</a>
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirement_reject"
                                                        onclick="StatusChangeTicket('{{ $list->ticket_sno }}', 2)">Reject</a>
                                                </div>
                                            @elseif($list->status == 1)
                                                {{-- Accepted --}}
                                                <a href="javascript:;"
                                                    class="badge bg-warning text-black rounded fw-semibold fs-8 px-3"
                                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Accepted <span class="mdi mdi-chevron-down"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirement_close"
                                                        onclick="StatusChangeTicket('{{ $list->ticket_sno }}', 3)">Close</a>
                                                </div>
                                            @elseif($list->status == 2)
                                                {{-- Rejected --}}
                                                <label class="badge bg-dark text-white fw-semibold fs-8 px-3"
                                                    style="border-radius: 3px;">Rejected</label>
                                            @elseif($list->status == 3)
                                                {{-- Closed --}}
                                                <label class="badge text-white fw-semibold fs-8 px-3"
                                                    style="border-radius: 3px; background:darkgreen;">Closed</label>
                                            @elseif($list->status == 4)
                                                {{-- Reopen --}}
                                                <a href="javascript:;"
                                                    class="badge text-black rounded fw-semibold fs-8 px-3"
                                                    style="background: linear-gradient(to right, #f09819, #ff512f);"
                                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Reopen <span class="mdi mdi-chevron-down"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirement_accept"
                                                        onclick="StatusChangeTicket('{{ $list->ticket_sno }}', 1)">Accept</a>
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirement_reject"
                                                        onclick="StatusChangeTicket('{{ $list->ticket_sno }}', 2)">Reject</a>
                                                </div>
                                            @elseif($list->status == 5)
                                                {{-- Closed --}}
                                                <label class="badge text-white fw-semibold fs-8 px-3"
                                                    style="border-radius: 3px; background:rgb(78, 199, 78);">Completed</label>
                                            @endif

                                        </td>
                                        <td>
                                            <div class="" onclick="ViewTicketHistory('{{ $list->ticket_sno }}')"
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_ticket_history">
                                                <span class="mdi mdi-clipboard-text-clock-outline fs-3 cursor-pointer"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="History"></span>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                    <div class="mt-4">
                        {{ $List->appends(request()->except(['page', '_token']))->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--begin::Modal - View History-->
    <div class="modal fade" id="kt_modal_ticket_history" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->

                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Ticket History</h3>
                    </div>


                    <div class="row">

                        <!-- Ticket ID -->
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Ticket ID</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-primary fs-6 fw-semibold" id="history_ticket_id">-</div>
                            </div>
                        </div>

                        <!-- Customer -->
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Customer</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_customer_name">-</div>
                            </div>
                        </div>

                        <!-- Mobile -->
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Mobile</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_customer_mobile">-</div>
                            </div>
                        </div>

                        <!-- Service -->
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Service</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_service">-</div>
                            </div>
                        </div>

                        <!-- Service ID -->
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Service ID</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_services_id">-</div>
                            </div>
                        </div>

                        <!-- Requirement -->
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Subject</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-danger fs-6 fw-semibold" id="history_requirement">-</div>
                            </div>
                        </div>

                        <!-- description  -->
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Description</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_description">-</div>
                            </div>
                        </div>

                        <!-- Created Date -->
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Created Date</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_created_at">-</div>
                            </div>
                        </div>

                        <!-- Current Status -->
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">Current Status</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_status">-</div>
                            </div>
                        </div>

                        <!-- CRE -->
                        <div class="col-lg-12 mb-4">
                            <div class="row">
                                <div class="col-3 text-dark fs-6 fw-semibold">CRE</div>
                                <div class="col-1 text-black fs-6 fw-bold">:</div>
                                <div class="col-8 text-black fs-6 fw-semibold" id="history_cre">-</div>
                            </div>
                        </div>
                    </div>

                    <!-- Attachments Section -->
                    <div class="col-lg-12 mb-3">
                        <div class="text-secondary fs-4 fw-semibold mb-3">Attachment</div>
                        <div class="col-lg-12 d-flex align-items-center justify-content-start gap-4 flex-wrap"
                            id="history_attachments">
                            <!-- Dynamic attachments will be loaded here -->
                        </div>
                    </div>

                    <!-- Updates Timeline Section -->
                    <div class="col-lg-12">
                        <div class="text-secondary fs-4 fw-semibold mb-3">Updates</div>
                        <div class="timeline-wrapper scroll-y pe-3" style="max-height: 260px;" id="history_timeline">
                            <!-- Dynamic timeline will be loaded here -->
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View History-->

    <!--begin::Modal - Accept Model-->
    <div class="modal fade" id="kt_modal_requirement_accept" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">

                <div class="modal-body pt-0 pb-9 px-9 px-xl-10">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                                <div class="swal2-icon-content">?</div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                                <div class="message_cnt"></div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="2" id="" placeholder="Enter Reason "></textarea>
                            <div class="message_err text-danger"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center pt-8 ">
                        <button type="submit" class="btn btn-danger me-3 approve_btn"
                            onclick="Ticket_Status(1)">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Accept Model-->

    <!--begin::Modal - Reject Model-->
    <div class="modal fade" id="kt_modal_requirement_reject" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">

                <div class="modal-body pt-0 pb-9 px-9 px-xl-10">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                                <div class="swal2-icon-content">?</div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                                <div class="message_cnt"></div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="2" id="" placeholder="Enter Reason "></textarea>
                            <div class="message_err text-danger"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center pt-8 ">
                        <button type="submit" class="btn btn-danger me-3 reject_btn"
                            onclick="Ticket_Status(2)">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Reject Model-->

    <!--begin::Modal - Close Model-->
    <div class="modal fade" id="kt_modal_requirement_close" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">

                <div class="modal-body pt-0 pb-9 px-9 px-xl-10">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                                <div class="swal2-icon-content">✔ </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                                <div class="message_cnt"></div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="2" id="" placeholder="Enter Reason"></textarea>
                            <div class="message_err text-danger"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center pt-8 ">
                        <button type="submit" class="btn btn-success me-3 close_btn"
                            onclick="Ticket_Status(3)">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Close Model-->

    <!-- end Bootstrap old Modal for showing messages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .tags-inline.tagify__dropdown {
            z-index: 9999 !important;
            /* Ensure it is higher than the modal's z-index */
        }
    </style>

    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>

    <script>
        $(".list_page").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    <script>
        function StatusChangeTicket(id, type) {
            fetch(`/ticket_details/${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {

                        if (type == 1) { // Accept
                            let btn = document.querySelector('#kt_modal_requirement_accept .approve_btn');
                            btn.setAttribute('data-id', id);
                            $('#kt_modal_requirement_accept .message_cnt').html(`
                        Are you sure you want to accept this ticket?
                        <br><br>
                        <b class="text-success fw-bold fs-4">${data.data.ticket_id}</b><br>
                        <b class="text-black fw-bold fs-6">${data.data.created_at}</b>
                    `);

                        } else if (type == 2) { // Reject
                            let btn = document.querySelector('#kt_modal_requirement_reject .reject_btn');
                            btn.setAttribute('data-id', id);
                            $('#kt_modal_requirement_reject .message_cnt').html(`
                        Are you sure you want to reject this ticket?
                        <br><br>
                        <b class="text-danger fw-bold fs-4">${data.data.ticket_id}</b><br>
                        <b class="text-black fw-bold fs-6">${data.data.created_at}</b>
                    `);

                        } else if (type == 3) { // Close
                            let btn = document.querySelector('#kt_modal_requirement_close .close_btn');
                            btn.setAttribute('data-id', id);
                            $('#kt_modal_requirement_close .message_cnt').html(`
                        Are you sure you want to 
                        <span class="text-success fw-semibold">Close This Ticket?</span>
                        <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
                            ${data.data.ticket_id}
                        </div>
                    `);
                        }

                    }
                })
                .catch(error => {
                    console.error('Error fetching:', error);
                });
        }

        function Ticket_Status(status) {
            // 1 -> Accept, 2 -> Reject, 3 -> Close

            let modalId = '';
            let btnSelector = '';

            if (status == 1) {
                modalId = '#kt_modal_requirement_accept';
                btnSelector = '.approve_btn';
            } else if (status == 2) {
                modalId = '#kt_modal_requirement_reject';
                btnSelector = '.reject_btn';
            } else if (status == 3) {
                modalId = '#kt_modal_requirement_close';
                btnSelector = '.close_btn';
            }

            let btn = document.querySelector(modalId + ' ' + btnSelector);
            let TicketId = btn.getAttribute('data-id');

            // Clear previous error message
            $(modalId + ' .message_err').html('');

            let message = $(modalId + ' textarea').val() || '';

            // Validate message
            if (message == '') {
                $(modalId + ' .message_err').html('Reason is required ..!');
                return false;
            }

            fetch('/update_ticket/' + TicketId, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        status: status,
                        message: message,
                        who: 0
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        $(modalId).modal('hide');
                        toastr.success(data.message);
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        toastr.error(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    toastr.error('Something went wrong!');
                });
        }
    </script>
    <script>
        function ViewTicketHistory(ticketId) {
            fetch(`/ticket-history/${ticketId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        populateTicketHistory(data.data);
                        $('#kt_modal_ticket_history').modal('show');
                    } else {
                        toastr.error('Failed to load ticket history');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    toastr.error('Something went wrong!');
                });
        }

        function populateTicketHistory(data) {
            const ticket = data.ticket;
            const customer = data.customer;
            const cre = data.cre;
            const history = data.history;
            const attachments = data.attachments;
            // Populate ticket details
            $('#history_customer_name').text(customer?.name || 'N/A');
            $('#history_customer_mobile').text(customer?.mobile || 'N/A');
            $('#history_requirement').text(ticket.subject || 'N/A');
            $('#history_description').text(ticket.ticket_description);
            $('#history_services_id').text(ticket.services_id || 'N/A');
            $('#history_service').text(ticket.service_name || 'N/A');
            $('#history_ticket_id').text(ticket.ticket_id || ticket.ticket_sno || 'N/A');
            $('#history_cre').text(cre?.name || cre?.user_name || ticket.cre_id || 'N/A');
            $('#history_created_at').text(formatDate(ticket.created_at));
            $('#history_status').html(getStatusBadge(ticket.status));

            // Populate attachments
            let attachmentsHtml = '';
            if (attachments && attachments.length > 0) {
                // Show first few images
                const imageAttachments = attachments.filter(doc => {
                    const ext = doc.file_name.split('.').pop().toLowerCase();
                    return ['jpg', 'jpeg', 'png', 'gif', 'bmp'].includes(ext);
                }).slice(0, 3);

                imageAttachments.forEach(doc => {
                    attachmentsHtml += `
                <div class="position-relative text-center">
                    <div class="overlay-wrapper position-relative w-75px h-75px">
                        <img src="/${doc.file_path}" alt="attachment" 
                            class="w-75px h-75px rounded border border-gray-600 border-solid object-fit-cover" 
                            onerror="this.src='/assets/phdizone_images/def_img.png'" />
                        <div class="overlay-layer position-absolute top-0 start-0 w-100 h-100
                                d-flex align-items-center justify-content-center
                                rounded bg-dark bg-opacity-75 opacity-0 hover-opacity-100 transition">
                            <a href="/${doc.file_path}" download class="text-white">
                                <i class="mdi mdi-download fs-2 text-hover-success"></i>
                            </a>
                        </div>
                    </div>
                </div>
            `;
                });

                // Add dropdown for all attachments if more than 3
                if (attachments.length > 3) {
                    attachmentsHtml += `
                <div class="position-relative text-center">
                    <div class="dropdown position-relative">
                        <button class="btn btn-outline-primary btn-sm dropdown-toggle d-flex align-items-center"
                            type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="mdi mdi-tray-arrow-down me-2"></i>
                            +${attachments.length - 3} more
                        </button>
                        <ul class="dropdown-menu" style="max-width: 300px;">
                            ${attachments.map((doc, index) => {
                                const fileExt = doc.file_name.split('.').pop();
                                const iconClass = getFileIcon(fileExt);
                                return `
                                        <li>
                                            <a class="dropdown-item" href="/${doc.file_path}" target="_blank"
                                                style="white-space: normal; word-wrap: break-word;">
                                                <i class="${iconClass} me-2"></i>
                                                ${doc.file_name}
                                                <small class="text-muted d-block">Click to download</small>
                                            </a>
                                        </li>
                                    `;
                            }).join('')}
                        </ul>
                    </div>
                </div>
            `;
                } else if (attachments.length > 0) {
                    // Show all as dropdown if 3 or less
                    attachmentsHtml += `
                <div class="position-relative text-center">
                    <div class="dropdown position-relative">
                        <button class="btn btn-outline-primary btn-sm dropdown-toggle d-flex align-items-center"
                            type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="mdi mdi-tray-arrow-down me-2"></i>
                            All Files
                        </button>
                        <ul class="dropdown-menu" style="max-width: 300px;">
                            ${attachments.map((doc, index) => {
                                const fileExt = doc.file_name.split('.').pop();
                                const iconClass = getFileIcon(fileExt);
                                return `
                                        <li>
                                            <a class="dropdown-item" href="/${doc.file_path}" target="_blank"
                                                style="white-space: normal; word-wrap: break-word;">
                                                <i class="${iconClass} me-2"></i>
                                                ${doc.file_name}
                                                <small class="text-muted d-block">Click to download</small>
                                            </a>
                                        </li>
                                    `;
                            }).join('')}
                        </ul>
                    </div>
                </div>
            `;
                }
            } else {
                attachmentsHtml = `
            <div class="text-center">
                <img src="/assets/phdizone_images/newmultiply.png" alt="no attachments"
                    class="rounded-circle img-fluid"
                    style="width: 40px; height: 40px; object-fit: cover;"
                    data-bs-toggle="tooltip" title="No Documents Uploaded">
            </div>
        `;
            }
            $('#history_attachments').html(attachmentsHtml);

            // Populate timeline
            let timelineHtml = '';
            if (history && history.length > 0) {
                history.forEach((item, index) => {
                    const isLast = index === history.length - 1;
                    const statusBadge = getStatusBadge(item.status);
                    const createdDate = formatDate(item.created_at);
                    var froms = 'Customer';
                    if (item.who == 0) {
                        froms = 'Staff';
                    }
                    timelineHtml += `
                <div class="timeline-row">
                    <div class="timeline-time ${!isLast ? 'pb-5' : ''}">${createdDate}</div>
                    <div class="timeline-center">
                        <span class="timeline-dot"></span>
                        ${!isLast ? '<span class="timeline-line"></span>' : ''}
                    </div>
                    <div class="timeline-content">
                        <div class="d-flex align-items-center gap-3 pb-1">
                            <label class="fs-6 text-dark fw-semibold pb-0">${froms || 'System'}</label>
                            ${item.status ? statusBadge : ''}
                        </div>
                        ${item.message ? `<p>${item.message}</p>` : ''}
                    </div>
                </div>
            `;
                });
            } else {
                timelineHtml = '<div class="text-center text-muted py-4">No history available</div>';
            }
            $('#history_timeline').html(timelineHtml);
        }

        // Helper function to format date
        function formatDate(dateString) {
            if (!dateString) return 'N/A';
            const date = new Date(dateString);
            return date.toLocaleString('en-IN', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        function getFileIcon(extension) {
            const icons = {
                'pdf': 'mdi mdi-file-pdf text-danger',
                'doc': 'mdi mdi-file-word text-primary',
                'docx': 'mdi mdi-file-word text-primary',
                'xls': 'mdi mdi-file-excel text-success',
                'xlsx': 'mdi mdi-file-excel text-success',
                'jpg': 'mdi mdi-file-image text-info',
                'jpeg': 'mdi mdi-file-image text-info',
                'png': 'mdi mdi-file-image text-info',
                'gif': 'mdi mdi-file-image text-info',
                'txt': 'mdi mdi-file-document text-secondary'
            };
            return icons[extension?.toLowerCase()] || 'mdi mdi-file';
        }

        function getStatusBadge(status) {
            const badges = {
                0: '<span class="badge bg-danger text-white fs-7">Open</span>',
                1: '<span class="badge bg-warning text-black fs-7">Accepted</span>',
                2: '<span class="badge bg-dark text-white fs-7">Rejected</span>',
                3: '<span class="badge" style="background:darkgreen; color:white; font-size:0.85rem;">Closed</span>',
                4: '<span class="badge" style="background:linear-gradient(to right, #f09819, #ff512f); color:black; font-size:0.85rem;">Reopen</span>',
                5: '<span class="bg-success text-white fs-7 p-1">Completed</span>'
            };
            return badges[status] || '<span class="badge bg-secondary">Unknown</span>';
        }
    </script>
@endsection
