@extends('layouts/layoutMaster')

@section('title', 'Manage Review')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/rateyo/rateyo.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js',
'resources/assets/vendor/libs/rateyo/rateyo.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
    td {
        border: 1px solid black
    }

    th {
        border: 1px solid black
    }
</style>

@php
    $module_name = 'Customer Management';
    $menu_name = 'Manage Review';
@endphp
<!-- Customer List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Reviews</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Customer Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center flex-wrap">
                @if(auth()->user()->hasPermission($module_name, 'Add', $menu_name))
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white waves-effect waves-light"
                        data-bs-toggle="modal" data-bs-target="#kt_modal_add_review">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Reviews
                    </a>
                @endif
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="filter_tbox" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Priya</option>
                        <option value="2">Iniya</option>
                        <option value="3">Sabana</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Gender</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Male</option>
                        <option value="2">Female</option>
                        <option value="3">Others</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Mobile No</label>
                    <input type="text" class="form-control" placeholder="Enter Mobile No" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Project Title</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Smart Attendance System - Python</option>
                        <option value="2">E- Library Management System</option>
                        <option value="3">Health Monitoring System</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Artificial Intelligence (AI)</option>
                        <option value="2">Web Development</option>
                        <option value="3">IoT (Internet of Things)</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Language</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Python</option>
                        <option value="2">Java</option>
                        <option value="3">Node Js</option>
                        <option value="4">C</option>
                        <option value="5">C++</option>
                        <option value="6">C#</option>
                        <option value="7">Php</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Database</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Sql</option>
                        <option value="2">My Sql</option>
                        <option value="3">Database</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt"
                        onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date"
                            class="form-control this_month_dt_fill" value="<?php echo date(" M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" />
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                <button class="btn btn-secondary btn-sm me-3 waves-effect waves-light">Reset</button>
                <a href="javascript:;" class="btn btn-primary btn-sm waves-effect waves-light">Go</a>
            </div>
        </div>
        <div class="row mb-4">
            <div class="col-lg-12 d-flex flex-wrap fs-6">
                <div class="col-lg-2 text-center p-2">
                    <div class=" bg-label-secondary p-2 rounded">
                        <label class="text-black fw-bold mb-2">Total Reviews</label><br>
                        <span class="badge bg-secondary rounded fs-6">{{ $total_reviews }}</span>
                    </div>
                </div>
                <div class="col-lg-2 text-center p-2">
                    <div class=" bg-label-success p-2 rounded">
                        <label class="text-black fw-bold mb-2">5 Star Reviews</label><br>
                        <span class="badge bg-success rounded fs-6">{{ $star_5 }}</span>
                    </div>
                </div>
                <div class="col-lg-2 text-center p-2">
                    <div class=" bg-label-info p-2 rounded">
                        <label class="text-black fw-bold mb-2">4 Star Reviews</label><br>
                        <span class="badge bg-info rounded fs-6 ">{{ $star_4 }}</span>
                    </div>
                </div>
                <div class="col-lg-2 text-center p-2">
                    <div class="p-2 rounded" style="background-color: #f5eae1;">
                        <label class="text-black fw-bold mb-2">3 Star Reviews</label><br>
                        <span class="badge fw-semibold text-black rounded fs-6"
                            style="background-color:rgb(243, 201, 167);">{{ $star_3 }}</span>
                    </div>
                </div>
                <div class="col-lg-2 text-center p-2">
                    <div class="p-2 rounded" style="background-color:rgb(202, 219, 255);">
                        <label class="text-black fw-bold mb-2">2 Star Reviews</label><br>
                        <span class="badge rounded fs-6" style="background-color:rgb(130, 166, 243);">{{ $star_2 }}</span>
                    </div>
                </div>
                <div class="col-lg-2 text-center p-2">
                    <div class=" bg-label-danger p-2 rounded">
                        <label class="text-black fw-bold mb-2">1 Star Reviews</label><br>
                        <span class="badge bg-danger rounded fs-6 ">{{ $star_1 }}</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Customer</th>
                            <th class="min-w-150px">Google Review</th>
                            @foreach ($reviews as $rev)                            
                            <th class="min-w-150px">{{ $rev->review_link }}</th>
                            @endforeach
                            <th class="min-w-50px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                            @foreach($records as $i =>$rec)
                                <tr>
                                    <td style="vertical-align: top;">
                                        <div class="">
                                            <label>{{ $rec->cus_name }}</label><br>
                                            <span class="text-info fs-8 fw-semibold" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Customer Id">{{ $rec->customer_id }}</span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="max-w-250px">
                                            <span class=" text-justify">"{{ $rec->review }}"</span><br>
                                            <div class="d-flex align-items-center">
                                                <div class="student_rat_table{{$i}} z-0 mb-1" data-rateyo-read-only="true"></div>
                                                <div class="ms-2 me-2 fs-7 text-dark fw-semibold text-center">
                                                    <label class="badge bg-info">{{$rec->ratings}} / 5</label>
                                                </div>
                                                @if($rec->review_image == 1)
                                                <label class="fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Google Review Image Uploaded"
                                                    data-bs-original-title="Google Review Image Uploaded">
                                                    <i class="mdi mdi-image-check text-dark fs-3"></i>
                                                </label>
                                                @endif
                                            </div>
                                        </div>
                                    </td>
                                    @if (isset($reviews))
                                    @php
                                    // Decode JSON review list and get array of link IDs as strings
                                    $review_ids = $rec->review_list
                                    ? collect(json_decode($rec->review_list))->pluck('link')->map(fn($link) => (string) $link)->toArray()
                                    : [];
                                    @endphp
                                    
                                    @foreach ($reviews as $rev)
                                    <td>
                                        @if (in_array((string) $rev->sno, $review_ids))
                                        <!-- Checkmark SVG -->
                                        <a href="javascript:;" class="btn btn-icon btn-sm" title="Selected">
                                            <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 500 500" viewBox="0 0 500 500"
                                                style="width:100%!important;">
                                                <rect width="500" height="500" fill="#fff0f0" display="none"></rect>
                                                <g>
                                                    <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                                    <path fill="#39ba77" d="M220.8,379.9c-7.9-0.4-28.3-4.9-48.3-39.7l-0.2-0.4c-1.3-2.4-32.6-59.8-53-102.2l-0.6-1.3-0.4-1.3
                                                                    c-4-12.6-5.3-37.3,15.5-49.9c6.5-3.9,13.8-5.8,21.2-5.5c19.5,0.9,32.8,16.4,35.3,19.4l0.3,0.4l26.7,37.1
                                                                    c24.6-43.5,78.6-124.3,165.2-176.5c3.2-2,17-9.9,34.4-9.1c13.7,0.6,25.9,6.5,35.4,17.1c3.3,3.5,12.7,15.3,11.1,33.8
                                                                    c-1.8,20.9-17.1,41.3-45.5,60.6l-0.2,0.1c-0.6,0.4-66.6,44.8-117,117.9c-10.9,15.8-21.3,34.1-31.7,55.9
                                                                    c-14.3,29.7-29.6,44-47,43.8l-0.2,0L220.8,379.9z">
                                                    </path>
                                                    <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                                    c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                                    c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z">
                                                    </path>
                                                </g>
                                            </svg>
                                        </a>
                                        @else
                                        <!-- Cross SVG -->
                                        <a href="javascript:;" class="btn btn-icon btn-sm" title="Not Selected">
                                            <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 500 500" viewBox="0 0 500 500"
                                                style="width:100%!important;">
                                                <rect width="500" height="500" fill="#fff0f0" display="none"></rect>
                                                <g>
                                                    <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                                    <path fill="#f32f45" d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                    l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                    c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                    c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                    c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                    c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                    C345.6,381.2,345.6,381.2,345.6,381.2z">
                                                    </path>
                                                    <path fill="#fff"
                                                        d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                    </path>
                                                </g>
                                            </svg>
                                        </a>
                                        @endif
                                    </td>
                                    @endforeach
                                    @endif
                                    <td style="vertical-align: top;">
                                        <div class=" justify-content-between">
                                            @if(auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                                                <a href="javascript:;" class="me-2" data-bs-toggle="modal" onclick="editReview('{{ $rec->sno }}')"
                                                    data-bs-target="#kt_modal_edit_review">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i
                                                            class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                                </a>
                                            @endif
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <td>Unauthorised Access</td>
                                <td></td>
                                @foreach ($reviews as $rev)
                                    <td></td>
                                @endforeach
                                <td></td>
                            </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>





<!--begin::Modal - Add review-->
<div class="modal fade" id="kt_modal_add_review" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Create Reviews</h3>
                </div>
                <form action="{{ route('create_manage_review') }}" method="POST" id="add_review_form">
                    @csrf
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="customer_id" name="customer_id">
                                <option value="">Select Customer</option>
                                @foreach ($customers as $cus)
                                    <option value="{{ $cus->sno }}">{{ $cus->cus_name }}</option>
                                @endforeach
                            </select>
                            <p id="customer_id_err" class="text-danger mt-1"></p>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <input type="hidden" name="rating_value" id="rating_value">
                            <label class="text-black mb-1 fs-6 fw-semibold">Google Ratings<span
                                    class="text-danger">*</span></label>
                            <div class="d-flex">
                                <div class="student_rat_table z-0 mb-1" data-rateyo-read-only="false"></div>
                                <div class="ms-4 fw-bold text-black">
                                    <span id="star-count" class="fs-5">0</span>/<span class="fs-5">5</span>
                                </div>
                            </div>
                            <div id="rating_err" class="text-danger mt-1"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Google Review<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="2" id="google_review" name="google_review" placeholder="Enter Google Review"></textarea>
                            <div id="google_review_err" class="text-danger mt-1"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <div class="form-check mt-4">
                                <input class="form-check-input" type="checkbox" id="review_image" name="review_image" value="1" />
                                <label class="form-check-label fw-semibold fs-6 text-dark" for="review_image">
                                    Upload Google Review Image
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3 d-flex">
                            @foreach($reviews as $i => $rev)
                                <div class="form-check me-3 mt-4">
                                    <input class="form-check-input" type="checkbox" id="review_link_{{$i}}" name="review_links[]" value="{{$rev->sno}}" />
                                    <label class="form-check-label fw-semibold fs-6 text-dark" for="review_link_{{$i}}">{{$rev->review_link}}</label>
                                </div>
                            @endforeach
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create Reviews</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add review-->


<!--begin::Modal - edit review-->
<div class="modal fade" id="kt_modal_edit_review" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Reviews</h3>
                </div>
                <form action="{{ route('update_manage_review') }}" method="POST" id="update_review_form">
                @csrf
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <input type="hidden" name="edit_id" id="edit_id">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="upd_customer_id" name="upd_customer_id">
                                <option value="">Select Customer</option>
                                @foreach ($customers as $cus)
                                    <option value="{{ $cus->sno }}">{{ $cus->cus_name }}</option>
                                @endforeach
                            </select>
                            <div id="upd_customer_err" class="text-danger mt-1"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <div class="fw-semibold fs-6 mb-1 text-dark">Google Ratings<span class="text-danger">*</span></div>
                            <div class="d-flex align-items-center gap-1">
                                <label class="student_ratings_update fs-2hx" data-rateyo-full-star="true"></label>
                                <label class="fs-5 text-black fw-semibold rating_val_update">3 / 5</label>
                                <input type="hidden" id="upd_student_ratings_hidden" name="upd_student_ratings_hidden">
                                <div class="text-danger" id="upd_student_ratings_hidden_err"></div>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Google Review<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="2"
                                placeholder="Enter Google Review" id="upd_gogle_review" name="upd_gogle_review"></textarea>
                                <div id="upd_google_review_err" class="text-danger mt-1"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <div class="form-check mt-4">
                                <input class="form-check-input" type="checkbox" id="review_image_update" name="review_image_update" value="1" />
                                <label class="form-check-label fw-semibold fs-6 text-dark" for="review_image_update">
                                    Upload Google Review Image
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3 d-flex">
                            @foreach($reviews as $i => $rev)
                            <div class="form-check me-3 mt-4">
                                <input class="form-check-input" type="checkbox" id="upd_str_rat_{{$rev->sno}}" name="links[]"
                                    value="{{$rev->sno}}" />
                                <label class="form-check-label fw-semibold fs-6 text-dark"
                                    for="upd_str_rat_{{$rev->sno}}">{{$rev->review_link}}</label>
                            </div>
                            @endforeach
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Reviews</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - edit review-->




<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
</style>

<script>
    // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
</script>

@if (isset($records))
@foreach ($records as $i => $list2)
<script>
    document.addEventListener('DOMContentLoaded', function() {
            $('.student_rat_table{{$i}}').rateYo({
                rating: {{$list2->ratings}}, 
                starWidth: "20px"
            });
        });
</script>
@endforeach
@endif


<script>
    document.addEventListener('DOMContentLoaded', function() {
    $(".student_rat_table").rateYo({
      rating: 0, // Start empty
      starWidth: "30px",
      fullStar: true, // Allow only whole stars
      onChange: function(rating, rateYoInstance) {
        document.getElementById('star-count').textContent = Math.round(rating);
        document.getElementById('rating_value').value = Math.round(rating);
      }
    });
  });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        $(".student_ratings_update").rateYo({
            rating: 5,
            starWidth: "30px",
            fullStar: true,
            onSet: function(rating, rateYoInstance) {
                // Update hidden input field with selected rating
                $('#upd_student_ratings_hidden').val(Math.round(rating));
                $('.rating_val_update').text(Math.round(rating) + " / 5");
            }
        });
    });
</script>

<script>
    $('#filter').click(function() {
    $('.filter_tbox').slideToggle('slow');
  });
</script>
<script>
    function date_fill_issue_rpt() {
    var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
    var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
    var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
    var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
    var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
    var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
    var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
    var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
    var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

    if (dt_fill_issue_rpt == "today") {
      today_dt_iss_rpt.style.display = "block";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else if (dt_fill_issue_rpt == "week") {
      today_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "block";
      week_to_dt_iss_rpt.style.display = "block";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";

      var curr = new Date; // get current date
      var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
      var last = first + 6; // last day is the first day + 6

      var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
      firstday = firstday.split("-").reverse().join("-");
      var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
      lastday = lastday.split("-").reverse().join("-");
      $('#week_from_date_fil').val(firstday);
      $('#week_to_date_fil').val(lastday);

    } else if (dt_fill_issue_rpt == "monthly") {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "block";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else if (dt_fill_issue_rpt == "custom_date") {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "block";
      to_dt_iss_rpt.style.display = "block";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    }
  }
</script>
<script>
    $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>

{{-- Validation --}}
<script>
    // Add Review Validation
    $('#update_review_form').on('submit', (e) => {
        let isValid = true;

        $('#upd_customer_err').text('');

        if($('#upd_customer_id').val() === ''){
            isValid = false;
            $('#upd_customer_err').text('Select the Customer.');
        }

        $('#upd_student_ratings_hidden_err').text('');

        if($('#upd_student_ratings_hidden').val() === '' || $('#upd_student_ratings_hidden').val() === 0){
            isValid = false;
            $('#upd_student_ratings_hidden_err').text('Select a Rating.');
        }

        $('#upd_google_review_err').text('');

        if($('#upd_gogle_review').val() === ''){
            isValid = false;
            $('#upd_google_review_err').text('Enter Google Review.');
        }

        if(!isValid){
            e.preventDefault();
        }
    });

    $('#add_review_form').on('submit', (e) => {
        let isValid = true;

        $('#customer_id_err').text('');

        if($('#customer_id').val() === ''){
            isValid = false;
            $('#customer_id_err').text('Select the Customer.');
        }

        $('#rating_err').text('');

        if($('#rating_value').val() === '' || $('#rating_value').val() === 0){
            isValid = false;
            $('#rating_err').text('Select a Rating.');
        }

        $('#google_review_err').text('');

        if($('#google_review').val() === ''){
            isValid = false;
            $('#google_review_err').text('Enter Google Review.');
        }

        if(!isValid){
            e.preventDefault();
        }
    });
</script>

<script>
    function editReview(id) {
        $.ajax({
            url: '/edit_review/' + id, // Adjust the URL as needed
            type: 'GET',
            success: function(response) {
                if (response.status === 200) {
                    const data = response.data;

                    // Populate fields in the modal
                    $('#upd_customer_id').val(data.customer_id).change(); // Customer ID
                    $('#edit_id').val(data.sno); // Rating (hidden input)
                    
                        
                    // Update the visual rating display (assuming you're using rateYo plugin)
                    $('.student_ratings_update').rateYo("rating", data.ratings);
                    $('.rating_val_update').text(data.ratings + " / 5");
                    $('#upd_student_ratings_hidden').val(data.ratings); // Rating (hidden input)

                    // Set review text
                    $('#upd_gogle_review').val(data.review);

                    // Set the checkbox for review image
                    if(data.review_image==1){
                        $('#review_image_update').prop('checked', true);
                    }
                    // return data.review_list;
                    // Handle dynamic review links if any
                    if (data.review_list) {
                        const reviewLinks = JSON.parse(data.review_list);
                        console.log(reviewLinks);
                        reviewLinks.forEach(link => {                        
                            // Ensure the corresponding checkbox and description fields are available
                            $('#upd_str_rat_' + link.link).prop('checked', true);
                            // star_rating_func_1_edit(link.link);     
                            // $('#upd_link_desc_' + link.link).val(link.desc);
                        });
                    }
                } else {
                    alert("Failed to load review data.");
                }
            },
            error: function() {
                alert("An error occurred while fetching review data.");
            }
        });
    }
</script>
<script>
  document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
    el.addEventListener('click', function () {
      // Small delay to allow modal animation to finish
      setTimeout(() => {
        location.reload();
      }, 150);
    });
  });
</script>
@endsection