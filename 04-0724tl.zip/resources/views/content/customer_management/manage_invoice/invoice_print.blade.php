@extends('layouts/blankLayout')

@section('title', 'Print Receipt')
@section('content')


<style>
    @media print {
        /* .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: white;
            padding: 10px;
            z-index: 1000;

        }

        .footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            background-color: white;
            color: black;
            text-align: right;
            page-break-before: always;
            counter-increment: page;
        } */

        body {
            background-color: white !important;
            margin: 0px !important;
            padding: 0px !important;
            page-break-before: auto;
            /* padding-top: 220px; */
            /* counter-reset: page; */
        }

        .print-container::before {
            content: "";
            display: block;
            height: 150px;
        }

        .start_cont {
            background: none !important;
            /* padding-top: 180px; */
            /* counter-reset: page; */
        }

        .page-break {
            page-break-before: auto !important;
        }

        /* .page-break-after {
            padding-top: 220px;
        } */

        /* .blank_row {
            page-break-inside: avoid;
            page-break-after: auto;
            line-height: 270px;
        } */

        table {
            width: 100%;
            border-collapse: collapse;
            /* overflow-x: visible !important; */
        }

        th,
        tr,
        td {
            border: 1px solid #ddd;
            padding: 5px;
            page-break-inside: always !important;
            /* break-inside: avoid !important; */
        }
    }


    table th,
    tr,
    td {
        border-collapse: collapse;
        border: 1px solid #ddd;
        padding: 5px;
    }
</style>
@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ?? 16;
@endphp
<center>
    <div style="width: 210mm !important;height: 297mm !important;">
        <div class="header">
            <div style="font-size:30px; font-weight:bold;color:black;text-align:center;margin-left:30px;padding-top:30px;">Receipt</div>
            <div style='display:flex;align-items:start !important;margin-left:10px;margin-right:10px;padding-top:10px;'>
                <div style="width:100% !important;margin-left: 10px !important;margin-right: 10px !important;">
                    <table style='width:100% !important;'>
                        <thead>
                            <tr>
                                <th rowspan="3" style="width: 25% !important;">
                                    <img src="{{asset('assets/phdizone_images/phdizone_logo.png')}}" style="height: 80px;width: 180px;">
                                </th>
                                <th style="text-align: center; width: 50% !important;" colspan="2">
                                    <label style="font-size:16px;font-weight:700;color:black;"># {{$proposal->invoice_id}}</label>
                                </th>
                                <th style="text-align: center; width: 25% !important;">
                                    <label style="font-size:15px;font-weight:700;color:black;">
                                        <!--<span>Partially Paid</span>-->
                                        <!--<span>-</span>-->
                                        <span style="color:green;">Pay Receipt</span>
                                    </label>
                                </th>
                            </tr>
                            <tr>
                                <th colspan="2"  style="text-align: center !important;width: 20% !important;">
                                    <label style="font-size:14px;font-weight:500;color:black;">Receipt Date</label>
                                    <div style="display: block !important;">
                                        <label style="font-size:13px;font-weight:700;color:black;">{{ $proposal->transaction_date ? date($common_date_format, strtotime($proposal->transaction_date)) :'-' }}</label>
                                    </div>
                                </th>
                                
                                <th style="text-align: center !important;width: 60% !important;">
                                    <label style="font-size:14px;font-weight:500;color:black;">Sale Agent</label>
                                    <div style="display: block !important;">
                                        <label style="font-size:13px;font-weight:700;color:black;">{{$proposal->nick_name ?? $proposal->staff_name}}</label>
                                    </div>
                                </th>
                            </tr>
                            <tr>
                                <th colspan="3" style="text-align: start !important;width: 100% !important;">
                                    <div style="font-size:13px;font-weight:600;color:black;padding-left:15px !important;">
                                        <lable></lable>
                                        <lable></lable>
                                    </div>
                                </th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <div class="start_cont" style='text-align:left;display:flex; margin-top:10px;margin-left:20px;margin-right:20px;'>
            <div style="width: 50%; border: 1px solid #ccc; border-radius: 4px; padding: 20px;margin-right:30px;background-color:#e0f3f9;">
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:700;color:black;">Proposal By</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:600;color:black;">{{$proposal->entity_name ?? 'PhDiZone'}}</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">
                         {{ $proposal->door_no ? $proposal->door_no . ', ' : '' }}
                        {{ $proposal->area_street ? $proposal->area_street . ', ' : '' }}
                    </label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">
                      {{ $proposal->city_name ? $proposal->city_name . ', ' : '' }}
                        {{ $proposal->state_name ? $proposal->state_name . ', ' : '' }}
                        {{ $proposal->country_name ? $proposal->country_name : '' }}
                    </label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Email ID</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">{{$proposal->branch_mail }}</label>
                </div>
                <div style="margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Phone No</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%;">
                         {{$proposal->branch_mobile}}</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">GST Number</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">{{$proposal->gst_no}}</label>
                </div>
            </div>
            <div style="width: 50%; border: 1px solid #ccc; border-radius: 4px; padding: 20px;background-color:#e0f3f9;">
                    <div style="margin-bottom:4px;">
                        <label style="font-size:16px;font-weight:700;color:black;">Proposal To</label>
                    </div>
                    <div style="margin-bottom:4px;">
                        <label style="font-size:16px;font-weight:700;color:black;">{{$proposal->lead_name }}</label>
                    </div>
                    <div style="margin-bottom:4px;">
                        <label style="font-size:13px;font-weight:600;color:black;">
                         {{ $proposal->lead_door_no ? $proposal->lead_door_no . ', ' : '' }}
                            {{ $proposal->lead_address ? $proposal->lead_address . ', ' : '' }}
                        </label>
                    </div>
                    <div style=" margin-bottom:4px;">
                        <label style="font-size:13px;font-weight:600;color:black;">
                         {{ $proposal->lead_city_name ? $proposal->lead_city_name . ', ' : '' }}
                            {{ $proposal->lead_state_name ? $proposal->lead_state_name . ', ' : '' }}
                            {{ $proposal->lead_country_name ? $proposal->lead_country_name : '' }}
                        </label>
                    </div>
                    <div style=" margin-bottom:4px;display:flex;">
                        <label style="font-size:14px;font-weight:700;color:black;width:40%">Email ID</label>
                        <label style="font-size:13px;font-weight:600;color:black;width:60%">{{$proposal->lead_mail ?? '-'}}</label>
                    </div>
                    <div style="margin-bottom:4px;display:flex;">
                        <label style="font-size:14px;font-weight:700;color:black;width:40%">Phone No</label>
                        <label style="font-size:13px;font-weight:600;color:black;width:60%">
                            {{$proposal->lead_mobile ?? '-' }}</label>
                    </div>
                    <div style=" margin-bottom:4px;display:flex;">
                        <label style="font-size:14px;font-weight:700;color:black;width:40%">Currency Format</label>
                        <label style="font-size:13px;font-weight:600;color:black;width:60%">{{$proposal->currency_code}} - {{$proposal->currency_symbol}}</label>
                    </div>
                </div>
        </div>
        <div style="font-size:20px; font-weight:bold;color:black;margin-top:10px;text-align:left;margin-left:20px;margin-right:20px;">
            <label>Service Details</label>
        </div>
        <div style="margin-left:20px;margin-right:20px;margin-top:10px;">
            
            <table style="width:100%;border-collapse:collapse;border: 1px solid #ddd;padding:30px;">
                <thead style="font-weight:bold; font-size:16px;background-color:#1397c7;color:white;vertical-align:top !important;">
                    <tr>
                        <th style="width:5%;text-align:center;">S.No</th>
                        <th style="width:70%;text-align:center;">Work</th>
                        <th style="width:10%;text-align:center;">Qty</th>
                        <th style="width:15%;text-align:center;">Amount</th>
                    </tr>
                </thead>
               <tbody style="vertical-align:top !important;">
                        @if($proposal->product_package == 1)
                             @foreach($proposal->products as $index=> $product)
                                        @php
                                            $variant_name = [];
                                        
                                            foreach ($product->cart_variants ?? [] as $variants) {
                                                foreach ($variants as $variant) {
                                                    if (!empty($variant)) {
                                                        $variant_name[] = trim($variant);
                                                    }
                                                }
                                            }
                                        
                                            $variant_view_name = implode(', ', $variant_name);
                                        @endphp
                            <tr style="color:black">
                                <td style="text-align:center; border-bottom-style: hidden !important;" >{{$index+1}}</td>
                                <td style="border-bottom-style: hidden !important;">
                                    @if($index == 0 )
                                   <div style="font-weight:600;margin:10px 0px 0px 0px;font-size:13px;color:#363535;">
                                        <label>{{$proposal->service_title}} </label>
                                        <div>Total Costing &nbsp;:&nbsp; <label class="">** &#8377; {{number_format($proposal->total_amount) }} /- **</label> </div>
                                        
                                        <div class="text-black fw-bold fs-7 my-1">
                                            <label class="">Total Milestone &nbsp;:&nbsp;</label>
                                            <label style="font-weight:600;margin:10px 0px 0px 0px;font-size:13px;color:#363535;">{{$proposal->slotCount}}</label>
                                            <label class="">(Includes {{$proposal->gst_perc}}% GST)</label>
                                        </div>
                                       
                                    </div>
                                    @endif
                                    <!--<div style="font-weight:600;font-size:15px;">{{$product->product_name}} ( {{$proposal->currency_symbol }} {{number_format($product->total_amount_cart) }} )</div>-->
                                    <!--@if(!empty($variant_name))-->
                                    <!--<div style="font-weight:600;font-size:13px;">({{$variant_view_name}})</div>-->
                                    <!--@endif-->
                                    <!--<div style="font-weight:600;font-size:13px;">{{$product->product_category_name}}</div>-->
                                    <div style="margin:10px 0px 10px 0px;font-size:12px;"></div>
                                    <div style="font-weight:600;margin:10px 0px 0px 0px;font-size:13px;color:#363535;">
                                        @if( count($proposal->products) ==1)
                                        <label>Total Costing &nbsp;:&nbsp;</label>
                                        <label>** {{$proposal->currency_symbol }} {{number_format($proposal->total_amount) }} /- **</label>
                                        @endif
                                        <label style="margin-left:20px;">Total Milestone &nbsp;:&nbsp;</label>
                                        <label>{{$proposal->slotCount}}</label>
                                        <label>(Includes {{$proposal->gst_perc}}% GST)</label>
                                    </div>
                                    @if(count($product->tools_name)>0)
                                    <div style="font-weight:600;margin:10px 0px 5px 0px;font-size:15px;">Tools</div>
                                    <div style="font-weight:400;margin:0px 0px 5px 0px;font-size:13px;">
                                        @foreach($product->tools_name as $inxTl=> $tools)
                                        <div style="margin-left: 25px;">{{$inxTl+1}}.{{$tools}}</div>
                                        @endforeach
                                    </div>
                                    @endif
                                </td>
                                <td style="text-align:center; border-bottom-style: hidden !important;" >{{count($product->cart_quantities)}}</td>
                                <td align="right" style="border-bottom-style: hidden !important;" >{{$proposal->currency_symbol }} {{number_format($product->product_amount)}}</td>
                            </tr>
                            @foreach($product->cart_slots as $indexslt=> $slot)
                            <tr style="color:black">
                                <td style="border-bottom-style: hidden !important;" ></td>
                                <td style="border-bottom-style: hidden !important;">
                                    <div style="font-weight:600;margin:0px 0px 10px 0px;font-size:15px;">
                                        <label style="background-color:#daa520; padding:0px 10px 0px 10px;">
                                            <span>{{$slot['payment_slot_name'] ?? ''}}  &nbsp;:&nbsp;</span>
                                            <span>{{$proposal->currency_symbol }}  {{number_format($slot['slot_amount'] ?? 0) }}  /-</span>
                                        </label>
                                    </div>
                                </td>
                                <td style="border-bottom-style: hidden !important;" ></td>
                                <td style="border-bottom-style: hidden !important;" ></td>
                            </tr>
                            <tr style="color:black; border-bottom: 1px solid black !important;">
                                <td style="@if($loop->last) @else border-bottom-style: hidden @endif ; " ></td>
                                <td style="@if($loop->last) @else border-bottom-style: hidden @endif ;">
                                    <div style="font-weight:600;margin:0px 0px 5px 0px;font-size:15px;">Deliverables</div>
                                    <div style="font-weight:400;margin:0px 0px 5px 0px;font-size:13px;">
                                    
                                        @foreach($slot['deliverables'] ?? [] as $variantName => $deliverList)
                                                                @php
                                                                    $DeliverablevariantNames = $helper->get_variant_and_varibale_name($variantName);
                                                                    $iDelv = 1; 
                                                                @endphp
                                         <div tyle="margin-left: 28px;">{{ $DeliverablevariantNames }}</div>
                                         @foreach($deliverList as $deliver)
                                        <div style="margin-left: 25px;{{$iDelv != count($slot['deliverables'])-1 ? 'margin-bottom: 8px;' :'' }}"><strong>{{ $iDelv++ }}. </strong>{!! nl2br(e($deliver)) !!}</div>
                                       
                                        @endforeach
                                   @endforeach
                                    </div>
                                    <div style="font-weight:600;margin:0px 0px 5px 0px;font-size:15px;">Note</div>
                                    <div style="font-weight:400;margin:0px 0px 5px 0px;font-size:13px;">
                                         @foreach($slot['slot_notes'] ?? [] as $variantName => $notesList)
                                                                @php
                                                                    $slotvariantNames = $helper->get_variant_and_varibale_name($variantName);
                                                                    $iNote = 1; // ✅ Reset note counter per variant
                                                                @endphp
                                        <div tyle="margin-left: 28px;">{{ $DeliverablevariantNames }}</div>
                                        @foreach($notesList as $note)
                                        <div style="margin-left: 25px;{{$iNote != count($slot['slot_notes'])-1 ? 'margin-bottom: 8px;' :'' }}"><strong>{{ $iNote++ }}. </strong>{!! nl2br(e($note)) !!}</div>
                                        @endforeach
                                                            @endforeach
                                    </div>
                                    <div style="font-weight:400;margin:0px 0px 10px 0px;font-size:14px;">{{$slot->slot_description??''}}</div>
                                </td>
                                <td style="@if($loop->last) @else border-bottom-style: hidden @endif ;" ></td>
                                <td style="@if($loop->last) @else border-bottom-style: hidden @endif ;" ></td>
                            </tr>
                            @endforeach
                            @endforeach
                            
                                <tr style="color:black">
                                    <td></td>
                                    <td style="border-bottom-style: hidden !important;">
                                        @if(count($proposal->productAddon)>0)
                                        <div style="font-weight:600;font-size:15px;">Add On Services</div>

                                        @if(count($proposal->freeAddonProducts)>0)
                                            <div style="font-weight:600;margin:0px 0px 5px 15px;font-size:14px;">Free Services</div>
                                            <div style="font-weight:400;margin:0px 0px 5px 0px;font-size:13px;">
                                                @foreach($proposal->freeAddonProducts as $freeindex => $addon)
                                                    <div style="margin-left: 25px;">
                                                        {{ $freeindex + 1 }}. {{ $addon->addon_name }} - {{ $addon->addon_variablename }}
                                                        <span style="background-color: #994646;color:white;border-radius:4px;padding:0px 10px;font-weight:400;">
                                                            <del>{{$proposal->currency_symbol }} {{ number_format($addon->addon_amount) }}</del>
                                                        </span>
                                                    </div>
                                                @endforeach
                                            </div>
                                        @endif

                                        @if(count($proposal->paidAddonProducts)>0)
                                            <div style="font-weight:600;margin:0px 0px 5px 15px;font-size:14px;">Paid Services</div>
                                            <div style="font-weight:400;margin:0px 0px 5px 0px;font-size:13px;">
                                                @foreach($proposal->paidAddonProducts as $paidindex => $addon)
                                                    <div style="margin-left: 25px;">
                                                        {{ $paidindex + 1 }}. {{ $addon->addon_name }} - {{ $addon->addon_variablename }}
                                                        <span style="background-color: #8a2be2;color:white;border-radius:4px;padding:0px 10px;font-weight:400;">
                                                            {{$proposal->currency_symbol }} {{ number_format($addon->addon_amount) }}
                                                        </span>
                                                    </div>
                                                @endforeach
                                            </div>
                                        @endif
                                        @endif
                                        <div style="font-weight:600;margin:0px 0px 5px 0px;font-size:15px;">
                                            <label>Duration &nbsp;:&nbsp;</label>
                                            <label>{{$proposal->delivery_duration}} to {{$proposal->delivery_duration_end}} Working Days</label>
                                        </div>
                                    </td>
                                    <td></td>
                                    <td></td>
                                </tr>
                        @else
                        
                            <tr style="color:black">
                                <td style="text-align:center; border-bottom-style: hidden !important;" >1</td>
                                <td style="border-bottom-style: hidden !important;">
                                    <div style="font-weight:600;font-size:15px;">{{$packages->package_name}} ( 
                                        @php
                                            $product_name = [];
                                            $product_view_name = '';
                                            foreach ($packages->product_name as $packge_prod) {
                                                if ($packge_prod) {
                                                    $name = $packge_prod ?? '';
                                                    $product_name[] = trim($name, ',');
                                                }
                                            }
                                            if (!empty($product_name)) {
                                                $product_view_name = implode(', ', $product_name);
                                            }
                                        @endphp
                                        <span>{{$product_view_name}}</span>
                                        )</div>
                                    <div style="margin:10px 0px 10px 0px;font-size:12px;"></div>
                                    <div style="font-weight:600;margin:10px 0px 0px 0px;font-size:13px;color:#363535;">
                                        
                                        <label>Total Costing &nbsp;:&nbsp;</label>
                                        <label>** {{$proposal->currency_symbol }} {{number_format($proposal->grant_total_amount) }} /- **</label>
                                        <label style="margin-left:20px;">Total Slots &nbsp;:&nbsp;</label>
                                        <label>{{count($packages->slots)}}</label>
                                        <label>(Includes {{$proposal->gst_perc}}% GST)</label>
                                    </div>
                                </td>
                                <td style="text-align:center; border-bottom-style: hidden !important;" >1</td>
                                <td align="right" style="border-bottom-style: hidden !important;" >{{$proposal->currency_symbol }} {{number_format($packages->package_amount)}}</td>
                            </tr>
                            @foreach($packages->slots as $indexslt=> $slot)
                            <tr style="color:black">
                                <td style="border-bottom-style: hidden !important;" ></td>
                                <td style="border-bottom-style: hidden !important;">
                                    <div style="font-weight:600;margin:0px 0px 10px 0px;font-size:15px;">
                                        <label style="background-color:#daa520; padding:0px 10px 0px 10px;">
                                            <span>{{$slot->payment_slot_name}} &nbsp;:&nbsp;</span>
                                            <span>{{$proposal->currency_symbol }} {{number_format($slot->slot_amount) }} /-</span>
                                        </label>
                                    </div>
                                </td>
                                <td style="border-bottom-style: hidden !important;" ></td>
                                <td style="border-bottom-style: hidden !important;" ></td>
                            </tr>
                            <tr style="color:black; border-bottom: 1px solid black !important;">
                                <td style="border-bottom-style: hidden !important  ; " ></td>
                                <td style="border-bottom-style: hidden !important  ;">
                                    <div style="font-weight:600;margin:0px 0px 5px 0px;font-size:15px;">Deliverables</div>
                                    <div style="font-weight:400;margin:0px 0px 5px 0px;font-size:13px;">
                                    
                                        @foreach($slot->deliverables as $iDelv=> $deliver)
                                        <div style="margin-left: 25px;{{$iDelv != count($slot->deliverables)-1 ? 'margin-bottom: 8px;' :'' }}"><bold>{{$iDelv+1}}. </bold>{{$deliver}}</div>
                                        @endforeach
                                    </div>
                                    <div style="font-weight:600;margin:0px 0px 5px 0px;font-size:15px;">Note</div>
                                    <div style="font-weight:400;margin:0px 0px 5px 0px;font-size:13px;">
                                        @foreach($slot->slot_notes as $isltNt=> $slotNotes)
                                        <div style="margin-left: 25px;{{$isltNt != count($slot->slot_notes)-1 ? 'margin-bottom: 8px;' :'' }}"><bold>{{$isltNt+1}}. </bold>{{$slotNotes}}</div>
                                        @endforeach
                                    </div>
                                    <div style="font-weight:400;margin:0px 0px 10px 0px;font-size:14px;">{{$slot->slot_description??''}}</div>
                                </td>
                                <td style="border-bottom-style: hidden !important ;" ></td>
                                <td style="border-bottom-style: hidden !important;" ></td>
                            </tr>
                            @endforeach
                            
                            <tr style="color:black">
                                <td></td>
                                <td style="">
                                    <div style="font-weight:600;margin:0px 0px 5px 0px;font-size:15px;">
                                        <label>Duration &nbsp;:&nbsp;</label>
                                        <label>{{$proposal->delivery_duration}} to {{$proposal->delivery_duration_end}} Working Days</label>
                                    </div>
                                </td>
                                <td></td>
                                <td></td>
                            </tr>
                        
                        @endif
                    </tbody>
            </table>
            <table style="width:100%;border-collapse:collapse;border: 1px solid #ddd;padding:30px;">
                <thead>
                      @php
                            $discountLabel = '';
                            if (!empty($proposal->discount_type) && !empty($proposal->discount_value)) {
                                if ($proposal->discount_type == '2') {
                                    $discountLabel = '&#8377; ' . $proposal->discount_value;
                                } elseif ($proposal->discount_type == '1') {
                                    $discountLabel = $proposal->discount_value . '%';
                                }
                            }
                        @endphp
                    <tr>
                        <th style="width:85% !important;font-size:16px;color:black;text-align:end;font-weight:600;">Sub Total</th>
                        <th style="width:15%  !important;font-size:16px;color:black;text-align:end;font-weight:600;">{{$proposal->currency_symbol }} {{number_format($proposal->sub_total) }}</th>
                    </tr>
                    <tr style="background-color: #ffe4c4;">
                        <th style="width:85% !important;font-size:14px;color:#2c2c2c;text-align:end;font-weight:600;"> Discount {!! $discountLabel ? "($discountLabel)" : '' !!}</th>
                        <th style="width:15%  !important;font-size:16px;color:#2c2c2c;text-align:end;font-weight:600;">{{$proposal->currency_symbol }} {{number_format($proposal->discount_amount) }}</th>
                    </tr>
                    <tr style="background-color: #f0e68cf2;">
                        <th style="width:85% !important;font-size:14px;color:#2c2c2c;text-align:end;font-weight:600;">Additional Charges ( {{$proposal->additional_charge_perc }}% )</th>
                        <th style="width:15%  !important;font-size:16px;color:#2c2c2c;text-align:end;font-weight:600;">{{$proposal->currency_symbol }} {{number_format($proposal->additional_charge_amount) }}</th>
                    </tr>
                    <tr>
                        <th style="width:85% !important;font-size:16px;color:black;text-align:end;font-weight:600;">Total Amount</th>
                        <th style="width:15%  !important;font-size:16px;color:black;text-align:end;font-weight:600;">{{$proposal->currency_symbol }} {{number_format($proposal->total_amount) }}</th>
                    </tr>
                    <tr style="background-color: #a9a9a961;">
                        <th style="width:85% !important;font-size:14px;color:#2c2c2c;text-align:end;font-weight:600;">GST ( {{$proposal->gst_perc }}% )</th>
                        <th style="width:15%  !important;font-size:16px;color:#2c2c2c;text-align:end;font-weight:600;">{{$proposal->currency_symbol }} {{number_format($proposal->gst_amount) }}</th>
                    </tr>
                    <tr>
                        <th style="width:85% !important;font-size:19px;color:black;text-align:end;font-weight:600;">Grand Total</th>
                        <th style="width:15%  !important;font-size:19px;color:black;text-align:end;font-weight:600;">{{$proposal->currency_symbol }} {{number_format($proposal->grant_total_amount) }}</th>
                    </tr>
                    <tr style="background-color: #51ce8a91;">
                        <th style="width:85% !important;font-size:14px;color:#000000;text-align:end;font-weight:600;">Total Paid</th>
                        <th style="width:15%  !important;font-size:16px;color:#000000;text-align:end;font-weight:600;">{{$proposal->currency_symbol }} {{number_format($paySlots->paidAmount) }}</th>
                    </tr>
                    <tr style="background-color: #ff0000c2;">
                        <th style="width:85% !important;font-size:14px;color:#ffffff;text-align:end;font-weight:500;">Total Due Amount</th>
                        <th style="width:15%  !important;font-size:16px;color:#ffffff;text-align:end;font-weight:500;">{{$proposal->currency_symbol }} {{number_format($paySlots->due_amount) }}</th>
                    </tr>
                    <tr>
                        <th colspan="2" style="width:100%;font-size:14px;color:#2c2c2c;text-align:start;font-weight:600;">
                            <label>Amount In Words &nbsp;:&nbsp;</label>
                            <label style="color:black">{{ ($helper->convertNumberToWords($paySlots->paidAmount)) }} Only</label>
                        </th>
                    </tr>
                </thead>
            </table>
        </div>
        <div class="page-break-after" style="page-break-inside: avoid !important;">
            <div style="font-size:16px; font-weight:bold;color:black;margin-top:20px;text-align:left;margin-left:20px;margin-right:20px;">
                Transactions Details :
            </div>
            <div style="margin-left:20px;margin-right:20px;margin-top:10px;">
                <table style="width:100%;border-collapse:collapse;border: 1px solid #ddd;padding:10px;">
                    <thead style="font-weight:bold; font-size:14px;color:black;">
                        <tr>
                            <th style="width:25%;text-align:center;">Payment ID</th>
                            <th style="width:25%;text-align:center;">Payment Mode</th>
                            <th style="width:25%;text-align:center;">Date</th>
                            <th style="width:25%;text-align:center;">Amount</th>
                        </tr>
                    </thead>
                    <tr style="color:black;font-weight:600 !important;">
                        <td>
                            <div style="text-align:center;">{{$proposal->pay_id }}</div>
                        </td>
                        <td>
                            <div style="text-align:center;">{{$proposal->payment_mode == 1 ?'Online' :'Offline' }}</div>
                        </td>
                        <td>
                            <div style="text-align:center;">{{ $proposal->transaction_date ? date($common_date_format, strtotime($proposal->transaction_date)) :'-' }}</div>
                        </td>
                        <td align="right">
                            <div>{{$proposal->currency_symbol }} {{number_format($paySlots->paidAmount) }}</div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        @if($proposal->payment_mode == 2)
        <div class="page-break" style="page-break-inside: avoid !important;">
            <div style="font-size:16px; font-weight:bold;color:black;margin-top:15px;text-align:left;margin-left:20px;margin-right:20px;">Offline Payment :
            </div>
            <div style="font-size:14px; font-weight:500;color:black;margin-top:10px;text-align:left;margin-left:40px;margin-right:20px;">
                <div style="font-size:14px; font-weight:700;color:black;margin-bottom:5px;">ELYSIUM TECHNOLOGIES PRIVATE LIMITED</div>
                <div style="display: flex;align-items:center;margin-bottom:5px;">
                    <div style="width: 12% !important;">Bank</div>
                    <div style="width: 5% !important;text-align:center !important;">:</div>
                    <div style="width: 83% !important;font-weight:700;color:black;">{{$branch_data->bank_name ??''}}</div>
                </div>
                <div style="display: flex;align-items:center;margin-bottom:5px;">
                    <div style="width: 12% !important;">Account No</div>
                    <div style="width: 5% !important;text-align:center !important;">:</div>
                    <div style="width: 83% !important;font-weight:700;color:black;">{{$branch_data->bank_account_no ??''}}</div>
                </div>
                <div style="display: flex;align-items:center;margin-bottom:5px;">
                    <div style="width: 12% !important;">Branch</div>
                    <div style="width: 5% !important;text-align:center !important;">:</div>
                    <div style="width: 83% !important;font-weight:700;color:black;">{{$branch_data->bank_branch ??''}}</div>
                </div>
                <div style="display: flex;align-items:center;margin-bottom:5px;">
                    <div style="width: 12% !important;">IFSC Code</div>
                    <div style="width: 5% !important;text-align:center !important;">:</div>
                    <div style="width: 20% !important;font-weight:700;color:black;">{{$branch_data->bank_ifsc ??''}}</div>

                    @if(isset($branch_data->bank_micr_no))
                    <div style="width: 5% !important;">MICR</div>
                    <div style="width: 5% !important;text-align:center !important;">:</div>
                    <div style="width: 53% !important;font-weight:700;color:black;">{{$branch_data->bank_micr_no ??''}}</div>
                    @endif
                </div>
            </div>
        </div>
        @endif
        <div class="page-break" style="width:100%;page-break-inside: avoid !important;">
            @if(isset($proposal_note))
            <div style="font-size:16px;font-weight:bold;color:black;margin-top:10px;text-align:left !important;margin-left:20px;margin-right:20px;">Note:
            </div>
            <div>
                <label style="font-size:14px;color:black;margin-top:5px;text-align:left;margin-left:20px;margin-right:20px;font-weight:500;">&emsp;&nbsp;{{$proposal_note}}</label>
            </div>
             @endif
              @if(isset($proposal_terms))
            <div style="font-size:16px; font-weight:bold;color:black;margin-top:10px;text-align:left !important;margin-left:20px;margin-right:20px;">Terms & Conditions:
            </div>
            <div style="font-size:14px; font-weight:500;color:black;margin-top:5px;text-align:left !important;margin-left:20px;margin-right:20px;">
                <ul>
                     @foreach($proposal_terms as $terms)
                    <li>{{$terms}}</li>
                    @endforeach
                </ul>
            </div>
            @endif
            @if($signature)
            <div style="margin-left:20px;margin-right:20px;margin-top:5px;float: right !important;">
                <img src="{{asset('terms_condition_signature')}}/{{$signature}}" style="width:250px;" alt="user-avatar" id="uploadedlogo" />
                <div style="display:block !important;font-size:16px;font-weight:600;color:black;margin-top:5px;margin-bottom:10px;margin-left:20px;margin-right:20px;">Authorized Signature</div>
            </div>
            @endif
        </div>
    </div>
</center>
@endsection