@extends('layouts/layoutMaster')

@section('title', 'Manage Chat')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

    <style>
        .list_page thead th,
        .list_page tbody td {
            padding: 7px !important;
        }

        .chat-msg {
            max-width: 75%;
            padding: 8px 12px;
            border-radius: 12px;
            font-size: 14px;
            word-wrap: break-word;
        }

        .chat-msg.sent {
            align-self: flex-end;
            background: #099dda;
            color: white;
        }

        .chat-msg.received {
            align-self: flex-start;
            background: #e9ecef;
        }

        .chat-date {
            text-align: center;
            font-size: 12px;
            color: #666;
            margin: 10px 0;
            position: relative;
        }

        .chat-date span {
            background: #e9ecef;
            padding: 3px 10px;
            border-radius: 12px;
        }

        .customer-item {
            transition: all 0.3s ease;
            border-radius: 6px;
            margin-bottom: 2px;
        }

        .customer-item:hover {
            background-color: #f0f0f0 !important;
        }

        .customer-item.active {
            background-color: #e3f2fd !important;
            border-left: 3px solid #099dda;
        }

        .search-box {
            position: relative;
        }

        .search-box .mdi-magnify {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
            z-index: 10;
        }

        .search-box input {
            padding-left: 35px;
        }

        .no-results {
            text-align: center;
            padding: 20px;
            color: #6c757d;
            font-style: italic;
        }

        .customer-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50px;
            background: #4B4B4B;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 16px;
            object-fit: cover;
        }

        .customer-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .loading-spinner {
            text-align: center;
            padding: 20px;
            color: #099dda;
        }

        .chat-loading {
            text-align: center;
            padding: 20px;
            color: #6c757d;
        }

        .customer-info {
            flex: 1;
            min-width: 0;
        }

        .customer-name {
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .customer-mobile {
            font-size: 12px;
            color: #6c757d;
        }

        .last-message {
            font-size: 11px;
            color: #999;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 150px;
        }

        .unread-badge {
            background: #099dda;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 600;
        }

        .service-item {
            transition: all 0.3s ease;
            border-radius: 6px;
            cursor: pointer;
            position: relative;
        }

        .service-item:hover {
            background-color: #f0f0f0 !important;
        }

        .service-item.active {
            background-color: #e3f2fd !important;
            border-left: 3px solid #099dda;
        }

        .service-header {
            background-color: #f8f9fa;
            border-radius: 4px;
            margin: 5px 0;
        }

        .service-type-badge {
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            margin-left: 5px;
        }

        .service-unread-badge {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: #099dda;
            color: white;
            border-radius: 12px;
            padding: 2px 8px;
            font-size: 11px;
            font-weight: 600;
        }

        .last-message-time {
            font-size: 10px;
            color: #999;
            margin-top: 2px;
        }

        /* Scroll to top indicator */
        .scroll-top-indicator {
            position: sticky;
            top: 0;
            z-index: 100;
            background: linear-gradient(to bottom, #f8f9fa, transparent);
            padding: 5px;
            text-align: center;
            font-size: 11px;
            color: #099dda;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .scroll-top-indicator:hover {
            color: #0a7eb5;
        }

        /* Loading more indicator */
        .loading-more {
            text-align: center;
            padding: 10px;
            background: rgba(9, 157, 218, 0.1);
            border-radius: 20px;
            margin: 10px auto;
            font-size: 12px;
            color: #099dda;
        }
    </style>

    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Chat</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Chat Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="card-body px-4 pb-0 pt-2">
            <div class="row my-3">
                <!-- Customers List Column -->
                <div class="col-lg-4">
                    <div class="row g-2 border px-2 rounded">
                        <div class="col-lg-12 d-flex align-items-center justify-content-between pt-2">
                            <label class="text-black fw-semibold fs-3">Customers</label>
                            <span class="badge bg-primary" id="customerCount">0</span>
                        </div>
                        <div class="col-lg-12">
                            <!-- Search Box -->
                            <div class="search-box mb-2">
                                <span class="mdi mdi-magnify"></span>
                                <input type="text" id="customerSearch" class="form-control"
                                    placeholder="Search by name or mobile..." autocomplete="off">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="scroll-y px-3"
                                style="border-radius: 6px; max-height:480px; min-height:480px; overflow-x:hidden;">
                                <div class="row" id="customerList">
                                    <!-- Loading indicator -->
                                    <div class="col-lg-12 text-center py-4" id="customerLoading">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                        <p class="mt-2">Loading customers...</p>
                                    </div>

                                    <!-- No results message -->
                                    <div class="col-lg-12 no-results" style="display: none;">
                                        No customers found matching your search
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Services List Column -->
                <div class="col-lg-4">
                    <div class="row g-2 border px-2 rounded">
                        <div class="col-lg-12 d-flex align-items-center justify-content-between pt-2">
                            <label class="text-black fw-semibold fs-3">Services</label>
                            <div class="badge d-flex align-items-center gap-1 text-bg-dark" id="selectedCustomer">
                                <span class="mdi mdi-account text-white"></span>
                                <span class="text-white">Select a customer</span>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="scroll-y px-3"
                                style="border-radius: 6px; max-height:530px; min-height:530px; overflow-x:hidden;">
                                <div class="row" id="serviceList">
                                    <!-- Loading indicator for services -->
                                    <div class="col-lg-12 text-center py-4" id="serviceLoading" style="display: none;">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                        <p class="mt-2">Loading services...</p>
                                    </div>

                                    <!-- Default message when no customer selected -->
                                    <div class="col-lg-12 text-center py-4" id="noCustomerSelected">
                                        <span class="mdi mdi-account-off" style="font-size: 48px; color: #ccc;"></span>
                                        <p class="mt-2 text-muted">Select a customer to view services</p>
                                    </div>

                                    <!-- No services message -->
                                    <div class="col-lg-12 no-results" id="noServices" style="display: none;">
                                        No services found for this customer
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Chat Column -->
                <div class="col-lg-4">
                    <div class="row g-2 px-2 rounded border" style="max-height:580px; min-height:580px;">
                        <div
                            class="col-lg-12 bg-primary py-2 text-white text-center d-flex flex-column align-items-center justify-content-center">
                            <label class="fw-semibold fs-7 d-block" id="selectedService">
                                Select a service
                            </label>
                            <label class="fw-semibold fs-7" id="selectedServiceId">
                                to start chatting
                            </label>
                        </div>
                        <div class="col-lg-12">
                            <div id="chatBox" class="px-3 py-2 d-flex flex-column gap-2"
                                style="border-radius:6px; height:430px; overflow-y:auto; background:#f8f9fa;">
                                <!-- Chat messages will be loaded here -->
                                <div class="text-center text-muted py-4" id="chatPlaceholder">
                                    <span class="mdi mdi-chat" style="font-size: 48px; color: #ccc;"></span>
                                    <p class="mt-2">Select a service to view chat history</p>
                                </div>
                            </div>
                            <div class="row pt-2 pb-2">
                                <div class="col-lg-12">
                                    <div class="input-group">
                                        <input type="text" id="chatInput" class="form-control"
                                            placeholder="Type message..." disabled>
                                        <span class="input-group-text bg-primary text-white"
                                            style="cursor:pointer; opacity: 0.5;" id="sendButton" onclick="sendMessage()">
                                            <span class="mdi mdi-send"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Global variables
        let selectedCustomerId = null;
        let selectedServiceSno = null;
        let selectedServiceType = null;
        let selectedServiceName = '';
        let selectedServiceCode = '';
        let customers = [];
        let filteredCustomers = [];
        let refreshInterval = null;
        let isCustomerListLoaded = false;

        // Chat pagination variables
        let currentChatPage = 1;
        let hasMoreChats = false;
        let isLoadingChats = false;
        let chatContainer = null;
        let previousScrollHeight = 0;
        let initialLoadComplete = false;
        let isAtBottom = true;

        // Load customers on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadCustomers();
            chatContainer = document.getElementById('chatBox');

            // Setup search input
            const searchInput = document.getElementById('customerSearch');
            searchInput.addEventListener('input', filterCustomers);

            // Setup enter key for chat
            document.getElementById("chatInput").addEventListener("keydown", function(e) {
                if (e.key === "Enter") sendMessage();
            });

            // Setup scroll event for infinite scroll
            if (chatContainer) {
                chatContainer.addEventListener('scroll', handleChatScroll);
            }

            // Start auto-refresh for customer list (every 5 seconds)
            startAutoRefresh();
        });

        // Handle chat scroll for infinite scroll
        function handleChatScroll() {
            if (!chatContainer) return;

            // Check if scrolled to top
            if (chatContainer.scrollTop < 50 && !isLoadingChats && hasMoreChats) {
                loadMoreChats();
            }

            // Track if we're at bottom for auto-scroll after new messages
            isAtBottom = (chatContainer.scrollHeight - chatContainer.scrollTop - chatContainer.clientHeight) < 50;
        }

        // Load more chat messages (previous/older messages)
        function loadMoreChats() {
            if (!selectedServiceSno || !selectedServiceType || !hasMoreChats || isLoadingChats) return;

            isLoadingChats = true;
            currentChatPage++;

            // Store current scroll height before loading
            previousScrollHeight = chatContainer.scrollHeight;

            // Show loading indicator at top
            showLoadingMoreIndicator();

            // Convert type string to number
            const typeValue = selectedServiceType === 'proposal' ? 0 : 1;

            axios.post('{{ route('customer.chat.history') }}', {
                    service_id: selectedServiceSno,
                    type: typeValue,
                    page: currentChatPage,
                    limit: 25
                })
                .then(function(response) {
                    // Remove loading indicator
                    removeLoadingMoreIndicator();

                    if (response.data.status === 'success') {
                        const newMessages = response.data.chats || [];
                        hasMoreChats = response.data.pagination.has_more;

                        if (newMessages.length > 0) {
                            // Prepend new messages to chat container
                            prependMessagesToChat(newMessages);

                            // Restore scroll position
                            const newScrollHeight = chatContainer.scrollHeight;
                            const scrollDifference = newScrollHeight - previousScrollHeight;
                            chatContainer.scrollTop = scrollDifference + 20;
                        }

                        // If no more messages, show a subtle indicator
                        if (!hasMoreChats && newMessages.length > 0) {
                            showNoMoreMessagesIndicator();
                        }
                    }
                    isLoadingChats = false;
                })
                .catch(function(error) {
                    console.error('Error loading more chats:', error);
                    removeLoadingMoreIndicator();
                    isLoadingChats = false;
                    currentChatPage--; // Revert page increment on error

                    // Show error briefly
                    showErrorIndicator('Failed to load older messages');
                });
        }

        // Show loading more indicator
        function showLoadingMoreIndicator() {
            const loadingDiv = document.createElement('div');
            loadingDiv.className = 'text-center py-2 loading-more';
            loadingDiv.id = 'chatLoadingMore';
            loadingDiv.innerHTML = `
                <div class="spinner-border spinner-border-sm text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <span class="ms-2">Loading older messages...</span>
            `;
            chatContainer.insertBefore(loadingDiv, chatContainer.firstChild);
        }

        // Remove loading more indicator
        function removeLoadingMoreIndicator() {
            const loadingElement = document.getElementById('chatLoadingMore');
            if (loadingElement) loadingElement.remove();
        }

        // Show no more messages indicator
        function showNoMoreMessagesIndicator() {
            const noMoreDiv = document.createElement('div');
            noMoreDiv.className = 'text-center py-2 text-muted small';
            noMoreDiv.id = 'noMoreMessages';
            noMoreDiv.innerHTML = 'No more messages';
            chatContainer.insertBefore(noMoreDiv, chatContainer.firstChild);

            setTimeout(() => {
                if (noMoreDiv.parentNode) noMoreDiv.remove();
            }, 3000);
        }

        // Show error indicator
        function showErrorIndicator(message) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'text-center py-2 text-danger small';
            errorDiv.textContent = message;
            chatContainer.insertBefore(errorDiv, chatContainer.firstChild);

            setTimeout(() => {
                if (errorDiv.parentNode) errorDiv.remove();
            }, 2000);
        }

        // Prepend messages to chat (for older messages)
        function prependMessagesToChat(messages) {
            if (!messages || messages.length === 0) return;

            // Group messages by date
            let currentDate = null;
            let fragment = document.createDocumentFragment();

            messages.forEach(msg => {
                const msgDate = new Date(msg.created_at).toDateString();

                if (currentDate !== msgDate) {
                    currentDate = msgDate;
                    const divider = createDateDivider(new Date(msg.created_at));
                    fragment.appendChild(divider);
                }

                const bubble = createMessageBubble(msg);
                fragment.appendChild(bubble);
            });

            // Prepend all new messages
            chatContainer.prepend(fragment);
        }

        // Load chat history (initial load)
        function loadChatHistory(serviceSno, type, page = 1) {
            const chatBox = document.getElementById('chatBox');
            const chatPlaceholder = document.getElementById('chatPlaceholder');

            // Clear chat and show loading
            chatBox.innerHTML = '';
            if (chatPlaceholder) chatPlaceholder.style.display = 'none';

            // Reset pagination variables
            currentChatPage = page;
            isLoadingChats = false;
            hasMoreChats = false;

            // Show loading
            const loadingDiv = document.createElement('div');
            loadingDiv.className = 'text-center py-4 chat-loading';
            loadingDiv.id = 'chatLoading';
            loadingDiv.innerHTML = `
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Loading chat history...</p>
            `;
            chatBox.appendChild(loadingDiv);

            // Convert type string to number
            const typeValue = type === 'proposal' ? 0 : 1;

            axios.post('{{ route('customer.chat.history') }}', {
                    service_id: serviceSno,
                    type: typeValue,
                    page: page,
                    limit: 25
                })
                .then(function(response) {
                    const loadingElement = document.getElementById('chatLoading');
                    if (loadingElement) loadingElement.remove();

                    if (response.data.status === 'success') {
                        const messages = response.data.chats || [];
                        const pagination = response.data.pagination;

                        hasMoreChats = pagination.has_more;

                        if (messages.length === 0) {
                            if (chatPlaceholder) {
                                chatPlaceholder.style.display = 'block';
                                const p = chatPlaceholder.querySelector('p');
                                if (p) p.textContent = 'No messages yet';
                                chatBox.appendChild(chatPlaceholder);
                            }
                            return;
                        }

                        // Group messages by date
                        let currentDate = null;

                        messages.forEach(msg => {
                            const msgDate = new Date(msg.created_at).toDateString();

                            if (currentDate !== msgDate) {
                                currentDate = msgDate;
                                insertDateDivider(chatBox, new Date(msg.created_at));
                            }

                            const bubble = createMessageBubble(msg);
                            chatBox.appendChild(bubble);
                        });

                        // Scroll to bottom for latest messages
                        chatBox.scrollTop = chatBox.scrollHeight;

                        // After loading chat, refresh services to update unread counts
                        if (selectedCustomerId) {
                            setTimeout(() => {
                                refreshCustomerServices(selectedCustomerId);
                            }, 500);
                        }

                        initialLoadComplete = true;
                    }
                })
                .catch(function(error) {
                    console.error('Error loading chat history:', error);
                    const loadingElement = document.getElementById('chatLoading');
                    if (loadingElement) loadingElement.remove();

                    // Show error in chat
                    const errorDiv = document.createElement('div');
                    errorDiv.className = 'text-center py-4 text-danger';
                    errorDiv.innerHTML = 'Failed to load chat history. Please try again.';
                    chatBox.appendChild(errorDiv);
                });
        }

        // Create message bubble element
        function createMessageBubble(msg) {
            const bubble = document.createElement('div');
            bubble.className = `chat-msg ${msg.message_type} d-flex flex-column`;
            bubble.setAttribute('data-message-id', msg.sno || msg.id);
            bubble.setAttribute('data-message-time', msg.formatted_datetime);

            if (msg.message_type === 'received') {
                bubble.innerHTML = `
                    <span>${escapeHtml(msg.message_content)}</span>
                    <span class="text-muted small align-self-end">${msg.formatted_time}</span>
                `;
            } else {
                bubble.innerHTML = `
                    <span>${escapeHtml(msg.message_content)}</span>
                    <span class="text-white-50 small align-self-end">${msg.formatted_time}</span>
                `;
            }

            return bubble;
        }

        // Escape HTML to prevent XSS
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Create date divider
        function createDateDivider(date) {
            const divider = document.createElement("div");
            divider.className = "chat-date";
            divider.innerHTML = `<span>${formatDateLabel(date)}</span>`;
            return divider;
        }

        // Insert date divider in chat
        function insertDateDivider(chatBox, date) {
            chatBox.appendChild(createDateDivider(date));
        }

        // Format date label for chat dividers
        function formatDateLabel(date) {
            const today = new Date();
            const yesterday = new Date();
            yesterday.setDate(today.getDate() - 1);

            const msgDate = new Date(date);

            if (msgDate.toDateString() === today.toDateString()) return "Today";
            if (msgDate.toDateString() === yesterday.toDateString()) return "Yesterday";

            return msgDate.toLocaleDateString("en-GB", {
                day: "2-digit",
                month: "short",
                year: "numeric"
            });
        }

        // Clear chat area
        function clearChat() {
            const chatBox = document.getElementById('chatBox');
            const chatPlaceholder = document.getElementById('chatPlaceholder');

            chatBox.innerHTML = '';
            if (chatPlaceholder) {
                chatPlaceholder.style.display = 'block';
                const p = chatPlaceholder.querySelector('p');
                if (p) p.textContent = 'Select a service to view chat history';
                chatBox.appendChild(chatPlaceholder);
            }

            // Reset pagination variables
            currentChatPage = 1;
            hasMoreChats = false;
            isLoadingChats = false;
            initialLoadComplete = false;

            // Disable chat input
            const chatInput = document.getElementById('chatInput');
            const sendButton = document.getElementById('sendButton');

            if (chatInput) chatInput.disabled = true;
            if (sendButton) {
                sendButton.style.opacity = '0.5';
                sendButton.style.cursor = 'default';
            }

            // Reset selected service display
            const selectedService = document.getElementById('selectedService');
            const selectedServiceId = document.getElementById('selectedServiceId');

            if (selectedService) selectedService.textContent = 'Select a service';
            if (selectedServiceId) selectedServiceId.textContent = 'to start chatting';
        }

        // Select a customer
        function selectCustomer(customer) {
            // Remove active class from all customers
            document.querySelectorAll('.customer-item').forEach(item => {
                item.classList.remove('active');
            });

            // Add active class to selected customer
            const selectedElement = document.querySelector(`[data-customer-id="${customer.customer_id}"]`);
            if (selectedElement) {
                selectedElement.classList.add('active');
            }

            // Update selected customer badge
            const selectedCustomerSpan = document.querySelector('#selectedCustomer span:last-child');
            if (selectedCustomerSpan) {
                selectedCustomerSpan.textContent = customer.cus_name || 'Selected Customer';
            }

            // Store selected customer ID
            selectedCustomerId = customer.customer_id;

            // Load customer services
            loadCustomerServices(customer.customer_id);
        }

        // Load customer services
        function loadCustomerServices(customerId) {
            const serviceList = document.getElementById('serviceList');
            const noCustomerSelected = document.getElementById('noCustomerSelected');
            const serviceLoading = document.getElementById('serviceLoading');
            const noServices = document.getElementById('noServices');

            if (noCustomerSelected) noCustomerSelected.style.display = 'none';
            if (noServices) noServices.style.display = 'none';
            if (serviceLoading) serviceLoading.style.display = 'block';

            removeServiceItems();
            clearChat();

            axios.post('{{ route('customer.chat.services') }}', {
                    customer_id: customerId
                })
                .then(function(response) {
                    if (serviceLoading) serviceLoading.style.display = 'none';

                    if (response.data.status === 'success') {
                        updateServiceList(response.data);
                    }
                })
                .catch(function(error) {
                    console.error('Error loading services:', error);
                    if (serviceLoading) serviceLoading.style.display = 'none';
                    showError('Failed to load services');

                    const errorDiv = document.createElement('div');
                    errorDiv.className = 'col-lg-12 text-center py-4 text-danger';
                    errorDiv.innerHTML = 'Failed to load services. Please try again.';
                    serviceList.appendChild(errorDiv);
                });
        }

        // Select a service
        function selectService(service, type) {
            document.querySelectorAll('.service-item').forEach(item => {
                item.classList.remove('active');
            });

            const selectedElement = document.querySelector(`[data-service-sno="${service.sno}"]`);
            if (selectedElement) {
                selectedElement.classList.add('active');
            }

            const selectedService = document.getElementById('selectedService');
            const selectedServiceId = document.getElementById('selectedServiceId');

            if (selectedService) {
                selectedService.textContent = service.product_name || 'Service';
            }
            if (selectedServiceId) {
                selectedServiceId.textContent = service.service_id || `SR-${String(service.sno).padStart(5, '0')}`;
            }

            selectedServiceSno = service.sno;
            selectedServiceType = type;
            selectedServiceName = service.product_name || 'Service';
            selectedServiceCode = service.service_id || '';

            // Reset pagination for new service
            currentChatPage = 1;
            hasMoreChats = false;
            isLoadingChats = false;

            const chatInput = document.getElementById('chatInput');
            const sendButton = document.getElementById('sendButton');

            if (chatInput) chatInput.disabled = false;
            if (sendButton) {
                sendButton.style.opacity = '1';
                sendButton.style.cursor = 'pointer';
            }

            loadChatHistory(service.sno, type);
        }

        // Send message function
        function sendMessage() {
            let input = document.getElementById("chatInput");
            let chatBox = document.getElementById("chatBox");
            let chatPlaceholder = document.getElementById("chatPlaceholder");

            let msg = input.value.trim();
            if (!msg || !selectedServiceSno || !selectedServiceType) return;

            if (chatPlaceholder && chatPlaceholder.parentNode === chatBox) {
                chatPlaceholder.remove();
            }

            const now = new Date();
            const lastMessageElement = chatBox.querySelector('.chat-msg:last-child');
            let lastMessageDate = null;

            if (lastMessageElement) {
                const lastMessageTime = lastMessageElement.getAttribute('data-message-time');
                if (lastMessageTime) {
                    lastMessageDate = new Date(lastMessageTime);
                }
            }

            if (!lastMessageDate || lastMessageDate.toDateString() !== now.toDateString()) {
                insertDateDivider(chatBox, now);
            }

            const typeValue = selectedServiceType === 'proposal' ? 0 : 1;

            const sendButton = document.getElementById('sendButton');
            const originalHtml = sendButton.innerHTML;
            sendButton.innerHTML =
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
            sendButton.style.pointerEvents = 'none';
            input.disabled = true;

            axios.post('{{ route('customer.chat.send') }}', {
                    customer_id: selectedCustomerId,
                    service_id: selectedServiceSno,
                    message: msg,
                    type: typeValue
                })
                .then(function(response) {
                    if (response.data.status === 'success') {
                        const sentMsg = response.data.chat;

                        let bubble = document.createElement("div");
                        bubble.className = "chat-msg sent d-flex flex-column";
                        bubble.setAttribute('data-message-id', sentMsg.id);
                        bubble.setAttribute('data-message-time', new Date().toISOString());
                        bubble.innerHTML = `
                            <span>${escapeHtml(msg)}</span>
                            <span class="text-white-50 small align-self-end">${sentMsg.formatted_time}</span>
                        `;

                        chatBox.appendChild(bubble);
                        input.value = "";
                        chatBox.scrollTop = chatBox.scrollHeight;

                        setTimeout(() => {
                            refreshCustomerList();
                        }, 500);
                    }
                })
                .catch(function(error) {
                    console.error('Error sending message:', error);
                    showError('Failed to send message');
                })
                .finally(function() {
                    sendButton.innerHTML = originalHtml;
                    sendButton.style.pointerEvents = 'auto';
                    input.disabled = false;
                    input.focus();
                });
        }

        // Start auto-refresh interval
        function startAutoRefresh() {
            if (refreshInterval) {
                clearInterval(refreshInterval);
            }
            refreshInterval = setInterval(function() {
                if (isCustomerListLoaded) {
                    refreshCustomerList();
                }
            }, 5000);
        }

        // Refresh customer list
        function refreshCustomerList() {
            axios.get('{{ route('customer.chat.list') }}')
                .then(function(response) {
                    if (response.data.status === 'success') {
                        const newCustomers = response.data.list || [];
                        customers = newCustomers;

                        const searchTerm = document.getElementById('customerSearch').value.toLowerCase().trim();
                        if (searchTerm === '') {
                            filteredCustomers = [...customers];
                        } else {
                            filteredCustomers = customers.filter(customer => {
                                const name = (customer.cus_name || '').toLowerCase();
                                const mobile = (customer.cus_mobile || '').toLowerCase();
                                const customerId = (customer.cus_ai_id || '').toString();
                                return name.includes(searchTerm) || mobile.includes(searchTerm) || customerId
                                    .includes(searchTerm);
                            });
                        }

                        renderCustomerList();

                        if (selectedCustomerId) {
                            const selectedCustomer = customers.find(c => c.customer_id === selectedCustomerId);
                            if (selectedCustomer) {
                                const selectedCustomerSpan = document.querySelector(
                                '#selectedCustomer span:last-child');
                                if (selectedCustomerSpan) {
                                    selectedCustomerSpan.textContent = selectedCustomer.cus_name || 'Selected Customer';
                                }
                                refreshCustomerServices(selectedCustomerId);
                            }
                        }
                    }
                })
                .catch(function(error) {
                    console.error('Error refreshing customers:', error);
                });
        }

        // Refresh customer services
        function refreshCustomerServices(customerId) {
            axios.post('{{ route('customer.chat.services') }}', {
                    customer_id: customerId
                })
                .then(function(response) {
                    if (response.data.status === 'success') {
                        updateServiceList(response.data);
                    }
                })
                .catch(function(error) {
                    console.error('Error refreshing services:', error);
                });
        }

        // Update service list
        function updateServiceList(data) {
            const serviceList = document.getElementById('serviceList');
            const noCustomerSelected = document.getElementById('noCustomerSelected');
            const noServices = document.getElementById('noServices');

            if (noCustomerSelected) {
                noCustomerSelected.style.display = 'none';
            }

            const proposalServices = data.Proposal || [];
            const publicationServices = data.Publication || [];

            if (proposalServices.length === 0 && publicationServices.length === 0) {
                if (noServices) {
                    noServices.style.display = 'block';
                }
                removeServiceItems();
                return;
            }

            if (noServices) {
                noServices.style.display = 'none';
            }

            removeServiceItems();

            if (proposalServices.length > 0) {
                const proposalHeader = document.createElement('div');
                proposalHeader.className = 'col-lg-12 py-2 service-header';
                proposalHeader.innerHTML = '<h6 class="mb-0 text-primary">Proposal Services</h6>';
                serviceList.appendChild(proposalHeader);

                proposalServices.forEach((service) => {
                    const serviceItem = createServiceElement(service, 'proposal');
                    serviceList.appendChild(serviceItem);
                });

                if (publicationServices.length > 0) {
                    const separator = document.createElement('div');
                    separator.className = 'col-lg-12 my-2';
                    separator.innerHTML = '<hr class="my-1">';
                    serviceList.appendChild(separator);
                }
            }

            if (publicationServices.length > 0) {
                const publicationHeader = document.createElement('div');
                publicationHeader.className = 'col-lg-12 py-2 service-header';
                publicationHeader.innerHTML = '<h6 class="mb-0 text-success">Publication Services</h6>';
                serviceList.appendChild(publicationHeader);

                publicationServices.forEach((service) => {
                    const serviceItem = createServiceElement(service, 'publication');
                    serviceList.appendChild(serviceItem);
                });
            }

            if (selectedServiceSno) {
                const selectedElement = document.querySelector(`[data-service-sno="${selectedServiceSno}"]`);
                if (selectedElement) {
                    selectedElement.classList.add('active');
                }
            }
        }

        // Create service element
        function createServiceElement(service, type) {
            const div = document.createElement('div');
            div.className = 'col-lg-12 py-2 cursor-pointer service-item position-relative';
            div.setAttribute('data-service-sno', service.sno);
            div.setAttribute('data-service-type', type);

            const typeBadgeClass = type === 'proposal' ? 'bg-primary' : 'bg-success';

            const serviceId = service.service_id ||
                `SR-${String(service.sno).padStart(5, '0')}/${new Date(service.created_at).getFullYear()}`;

            const unreadBadge = service.unread_count ?
                `<span class="service-unread-badge">${service.unread_count}</span>` : '';

            div.innerHTML = `
                <div class="d-flex flex-column pe-4">
                    <div class="d-flex align-items-center gap-2 flex-wrap">
                        <span class="text-black fw-semibold small">${service.product_name || 'Service'}</span>
                        <span class="badge ${typeBadgeClass}" style="font-size: 9px;">${type}</span>
                    </div>
                    <span class="text-info small">${serviceId}</span>
                    ${service.last_message ? `<div class="last-message small text-muted text-truncate mt-1">${escapeHtml(service.last_message)}</div>` : ''}
                    ${service.last_message_time ? `<div class="last-message-time small text-muted">${service.last_message_time}</div>` : ''}
                </div>
                ${unreadBadge}
            `;

            div.style.borderBottom = '1px solid #f0f0f0';

            div.addEventListener('click', function(e) {
                e.preventDefault();
                selectService(service, type);
            });

            return div;
        }

        // Remove all service items
        function removeServiceItems() {
            const serviceList = document.getElementById('serviceList');
            const itemsToRemove = [];
            serviceList.childNodes.forEach(node => {
                if (node.nodeType === 1) {
                    if (node.classList.contains('service-item') ||
                        node.classList.contains('service-header') ||
                        node.classList.contains('my-2') ||
                        node.classList.contains('text-danger')) {
                        itemsToRemove.push(node);
                    }
                }
            });
            itemsToRemove.forEach(node => node.remove());
        }

        // Load customers from API
        function loadCustomers() {
            const customerList = document.getElementById('customerList');
            const loadingEl = document.getElementById('customerLoading');
            const noResults = document.querySelector('.no-results');

            if (loadingEl) loadingEl.style.display = 'block';
            if (noResults) noResults.style.display = 'none';

            removeCustomerItems();

            axios.get('{{ route('customer.chat.list') }}')
                .then(function(response) {
                    if (response.data.status === 'success') {
                        customers = response.data.list || [];
                        filteredCustomers = [...customers];
                        renderCustomerList();
                        isCustomerListLoaded = true;
                    }
                    if (loadingEl) loadingEl.style.display = 'none';
                })
                .catch(function(error) {
                    console.error('Error loading customers:', error);
                    if (loadingEl) loadingEl.style.display = 'none';
                    showError('Failed to load customers');

                    const errorDiv = document.createElement('div');
                    errorDiv.className = 'col-lg-12 text-center py-4 text-danger';
                    errorDiv.innerHTML = 'Failed to load customers. Please refresh the page.';
                    customerList.appendChild(errorDiv);
                });
        }

        // Remove all customer items
        function removeCustomerItems() {
            const customerList = document.getElementById('customerList');
            const itemsToRemove = [];
            customerList.childNodes.forEach(node => {
                if (node.nodeType === 1 && (node.classList.contains('customer-item') || node.classList.contains(
                        'customer-divider'))) {
                    itemsToRemove.push(node);
                }
            });
            itemsToRemove.forEach(node => node.remove());
        }

        // Show error message
        function showError(message) {
            // You can implement a toast notification here
            console.error(message);
        }

        // Render customer list
        function renderCustomerList() {
            const customerList = document.getElementById('customerList');
            const noResults = document.querySelector('.no-results');
            const customerCount = document.getElementById('customerCount');

            removeCustomerItems();

            if (filteredCustomers.length === 0) {
                if (noResults) noResults.style.display = 'block';
                if (customerCount) customerCount.textContent = '0';
                return;
            }

            if (noResults) noResults.style.display = 'none';
            if (customerCount) customerCount.textContent = filteredCustomers.length;

            filteredCustomers.forEach((customer, index) => {
                const customerItem = createCustomerElement(customer);
                customerList.appendChild(customerItem);

                if (index < filteredCustomers.length - 1) {
                    const divider = document.createElement('hr');
                    divider.className = 'my-1 customer-divider opacity-25';
                    customerList.appendChild(divider);
                }
            });

            if (selectedCustomerId) {
                const selectedElement = document.querySelector(`[data-customer-id="${selectedCustomerId}"]`);
                if (selectedElement) {
                    selectedElement.classList.add('active');
                }
            }
        }

        // Create customer element
        function createCustomerElement(customer) {
            const div = document.createElement('div');
            div.className = 'col-lg-12 py-2 cursor-pointer d-flex gap-2 align-items-center customer-item position-relative';
            div.setAttribute('data-customer-id', customer.customer_id);
            div.setAttribute('data-name', customer.cus_name || '');
            div.setAttribute('data-mobile', customer.cus_mobile || '');

            const initials = customer.cus_name ? customer.cus_name.charAt(0).toUpperCase() : '?';

            const avatarHtml = customer.cus_pic ?
                `<img src="${customer.cus_pic}" alt="${customer.cus_name}" class="customer-avatar" onerror="this.onerror=null; this.src=''; this.parentElement.innerHTML='<span class=\'customer-avatar\'>${initials}</span>'">` :
                `<span class="customer-avatar">${initials}</span>`;

            let timeDisplay = '';
            if (customer.last_message_time_formatted) {
                timeDisplay =
                    `<div class="last-message-time small text-muted">${customer.last_message_time_formatted}</div>`;
            }

            div.innerHTML = `
                <div style="min-width: 40px;">
                    ${avatarHtml}
                </div>
                <div class="customer-info flex-grow-1" style="min-width: 0;">
                    <div class="customer-name d-flex justify-content-between align-items-center">
                        <span class="text-truncate fw-semibold">${customer.cus_name || 'Unknown'}</span>
                        ${customer.unread_count ? `<span class="unread-badge ms-1">${customer.unread_count}</span>` : ''}
                    </div>
                    <div class="customer-mobile small text-muted">${customer.cus_mobile || 'No mobile'}</div>
                    <div class="last-message small text-muted text-truncate" style="max-width: 180px;">
                        ${customer.last_message ? escapeHtml(customer.last_message) : 'No messages yet'}
                    </div>
                    ${timeDisplay}
                </div>
            `;

            div.addEventListener('click', function(e) {
                e.preventDefault();
                selectCustomer(customer);
            });

            return div;
        }

        // Filter customers based on search
        function filterCustomers() {
            const searchTerm = document.getElementById('customerSearch').value.toLowerCase().trim();

            if (searchTerm === '') {
                filteredCustomers = [...customers];
            } else {
                filteredCustomers = customers.filter(customer => {
                    const name = (customer.cus_name || '').toLowerCase();
                    const mobile = (customer.cus_mobile || '').toLowerCase();
                    const customerId = (customer.cus_ai_id || '').toString();

                    return name.includes(searchTerm) ||
                        mobile.includes(searchTerm) ||
                        customerId.includes(searchTerm);
                });
            }

            renderCustomerList();
        }

        // Clean up interval on page unload
        window.addEventListener('beforeunload', function() {
            if (refreshInterval) {
                clearInterval(refreshInterval);
            }
        });
    </script>

@endsection
