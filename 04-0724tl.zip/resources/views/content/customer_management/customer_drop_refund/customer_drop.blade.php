@extends('layouts/layoutMaster')

@section('title', 'Customer Drop (or) Refund')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'])
@endsection

@section('content')
    <style>
        .service-card {
            transition: all 0.3s ease;
            border: 2px solid #e9ecef;
        }

        .service-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .checklist-item:hover {
            background-color: #f8f9fa;
        }

        .checklist-item:has(input:checked) {
            background-color: #e7f1ff;
            border-color: #0d6efd;
        }

        .detail-item {
            border-bottom: 1px solid #f0f0f0;
            padding-bottom: 8px;
        }

        .detail-item:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }

        .sticky-top {
            position: sticky;
            z-index: 10;
        }

        .service-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .is-valid {
            border-color: #198754 !important;
            box-shadow: 0 0 0 0.2rem rgba(25, 135, 84, 0.25) !important;
        }

        .is-invalid {
            border-color: #dc3545 !important;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25) !important;
        }

        .refund-not-eligible {
            background-color: #f8d7da !important;
            border-color: #f5c6cb !important;
        }
    </style>

    @php
        $date_format = $genaral_settings->date_format ?? 'd-M-y';
        if(isset($services[0]->currency_id) && $services[0]->currency_id == 70){
            $balance_amount = $customer_details->paid_amount - $genaral_settings->min_deducted_amount;
            $min_deducted_amount = $genaral_settings->min_deducted_amount ?? 0;
        }else{
            $balance_amount = $customer_details->paid_amount;
            $min_deducted_amount = 0;
        }
        $currency_symbol = $services[0]->currency_symbol ? $services[0]->currency_symbol : '₹' ;
        $is_refund_eligible = $balance_amount > 0;
        
    @endphp

    <div class="card card-action">
        <div class="card-header border-bottom pb-0 flex-wrap">
            <div class="card-action-title text-black fs-5 fw-bold mb-1">
                <h5 class="card-title mb-1">Customer Drop (or) Refund</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="/dashboards" class="d-flex align-items-center"><i
                                    class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="/manage_customer" class="d-flex align-items-center fw-semibold">Customer Management</a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center fw-semibold">Manage Customer</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element mb-1 gap-2 flex-wrap">
                <div class="customer-avatar d-flex align-items-center px-1">
                    <div class="customer-info">
                        <label class="text-black fs-5 fw-bold">{{ $customer_details->cus_name ?? '-' }}</label>
                        <div class="d-block fs-7 fw-bold text-dark">( {{ $customer_details->customer_id ?? '-' }} )</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="row">
                <input type="hidden" id="customer_id" name="customer_id" value="{{ $customer_details->sno }}">
                <input type="hidden" id="is_refund_eligible" value="{{ $is_refund_eligible ? '1' : '0' }}">

                <!-- Left Column - Services & Drop Checklist -->
                <div class="col-lg-8">
                    <!-- Services Section -->
                    <div class="card mb-4">
                        <div class="card-header service-header">
                            <h6 class="card-title mb-0 d-flex align-items-center text-white">
                                <i class="mdi mdi-cube-outline me-2"></i>
                                Select Services
                            </h6>
                            <span class="badge bg-warning text-dark ms-auto">
                                {{ str_pad(count($services), 2, '0', STR_PAD_LEFT) }}
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="row g-3" style="max-height: 400px; overflow-y: auto;">
                                @foreach ($services as $si => $cs)
                                    <div class="col-md-6">
                                        <div class="service-card card h-100" id="services_div{{ $si }}">
                                            <div class="card-body p-3">
                                                <!-- Service Details -->
                                                <div class="service-details">
                                                    <div class="detail-item mb-2">

                                                        <small
                                                            class="text-dark">{{ str_pad($si + 1, 2, '0', STR_PAD_LEFT) }}
                                                            Product</small>
                                                        <div class="row">
                                                            <div class="col-lg-10">
                                                                <span
                                                                    class="fw-bold text-primary">{{ $cs->product_name }}</span>
                                                            </div>
                                                            <div class="col-lg-2">
                                                                <div class="d-flex justify-content-end align-items-end flex-column" >
                                                                    <input type="checkbox"
                                                                    class="form-check-input services_checkbox"
                                                                    id="services_checkbox{{ $si }}"
                                                                    name="services_checkbox[]"
                                                                    onclick="SelectColor({{ $si }})"
                                                                    value="{{ $cs->sno }}">
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <div class="detail-item mb-2">
                                                        <small class="text-dark">Category</small>
                                                        <div class="fw-semibold">{{ $cs->product_category_name }}</div>
                                                    </div>

                                                    <div class="detail-item mb-2">
                                                        <small class="text-dark">Variant</small>
                                                        <div class="fw-semibold">{{ $cs->variant_name }}</div>
                                                    </div>

                                                    <div class="detail-item mb-2">
                                                        <small class="text-dark">Variables</small>
                                                        <div>
                                                            <span
                                                                class="badge bg-light text-dark me-1">{{ $cs->variable_name }}</span>
                                                        </div>
                                                    </div>

                                                    @php
                                                        $status = $cs->status;
                                                        $statuses = [
                                                            0 => [
                                                                'text' => 'Not Yet Started',
                                                                'color' => '#6C757D',
                                                                'text_color' => 'text-white',
                                                            ],
                                                            1 => [
                                                                'text' => 'In Progress',
                                                                'color' => '#FFA500',
                                                                'text_color' => 'text-black',
                                                            ],
                                                            2 => [
                                                                'text' => 'Completed',
                                                                'color' => '#218838',
                                                                'text_color' => 'text-white',
                                                            ],
                                                            3 => [
                                                                'text' => 'Delayed',
                                                                'color' => '#FFC107',
                                                                'text_color' => 'text-black',
                                                            ],
                                                            4 => [
                                                                'text' => 'Hold',
                                                                'color' => '#FD7E14',
                                                                'text_color' => 'text-white',
                                                            ],
                                                            5 => [
                                                                'text' => 'Not Completed',
                                                                'color' => '#C82333',
                                                                'text_color' => 'text-white',
                                                            ],
                                                            6 => [
                                                                'text' => 'Verified',
                                                                'color' => '#004085',
                                                                'text_color' => 'text-white',
                                                            ],
                                                            7 => [
                                                                'text' => 'QC Verified',
                                                                'color' => '#6F42C1',
                                                                'text_color' => 'text-white',
                                                            ],
                                                            8 => [
                                                                'text' => 'Delivered',
                                                                'color' => '#117A65',
                                                                'text_color' => 'text-white',
                                                            ],
                                                        ];
                                                        $statusDetails = $statuses[$status] ?? [
                                                            'text' => 'Unknown',
                                                            'color' => '#6C757D',
                                                            'text_color' => 'text-white',
                                                        ];
                                                    @endphp

                                                    <div class="detail-item">
                                                        <small class="text-dark">Status</small>
                                                        <div>
                                                            <span class="badge"
                                                                style="background-color: {{ $statusDetails['color'] }}; color: {{ $statusDetails['text_color'] }};">
                                                                {{ $statusDetails['text'] }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>

                    <!-- Drop Checklist Section -->
                    <div class="card">
                        <div class="card-header bg-light">
                            <h6 class="card-title mb-0 d-flex align-items-center">
                                <i class="mdi mdi-format-list-checks me-2 text-primary"></i>
                                Drop Refund Checklist
                            </h6>
                            <span class="badge bg-warning text-dark ms-auto">
                                <span id="check_list_count">00</span> /
                                {{ str_pad(count($check_list), 2, '0', STR_PAD_LEFT) }}
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="checklist-container" style="max-height: 300px; overflow-y: auto;">
                                @foreach ($check_list as $ci => $chlist)
                                    <div class="checklist-item form-check mb-3 px-10 py-3 rounded border">
                                        <input class="form-check-input checklist-checkbox" type="checkbox"
                                            id="check_{{ $ci }}">
                                        <label class="form-check-label fw-semibold ms-2" for="check_{{ $ci }}">
                                            {{ $chlist->refund_checklist_name }}
                                        </label>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right Column - Drop Action -->
                <div class="col-lg-4">
                    <div class="sticky-top" style="top: 20px;">
                        <!-- Action Section -->
                        <div class="card">
                            <div class="card-header bg-light">
                                <h6 class="card-title mb-0 d-flex align-items-center">
                                    <i class="mdi mdi-cancel me-2 text-primary"></i>
                                    Drop Action
                                </h6>
                                <div class="form-check form-switch ms-auto">
                                    <input class="form-check-input" type="checkbox" id="refund_toggle"
                                        {{ !$is_refund_eligible ? 'disabled' : '' }}>
                                    <label class="form-check-label small {{ !$is_refund_eligible ? 'text-muted' : '' }}"
                                        for="refund_toggle">
                                        Include Refund
                                        @if (!$is_refund_eligible)
                                            <span class="badge bg-danger ms-1">Not Eligible</span>
                                        @endif
                                    </label>
                                </div>
                            </div>
                            <div class="card-body">
                                @if (!$is_refund_eligible)
                                    <div class="alert alert-warning mb-3">
                                        <i class="mdi mdi-alert-circle-outline me-2"></i>
                                        <strong>Refund Not Eligible:</strong> Possible eligible amount is negative or zero.
                                        You can only drop customer without refund.
                                    </div>
                                @endif

                                <!-- Drop Reason - Only shown when NOT requesting refund -->
                                <div id="drop_reason_section" class="mb-4">
                                    <label class="form-label fw-semibold">Reason for Drop <span
                                            class="text-danger">*</span></label>
                                    <textarea class="form-control" rows="3" id="drop_reason" name="drop_reason"
                                        placeholder="Please provide reason for dropping Customer..."></textarea>
                                </div>

                                <!-- Refund Section - Only shown when requesting refund -->
                                <div id="refund_section" style="display: none;">
                                    <div
                                        class="refund-calculation mb-4 p-3 border rounded {{ !$is_refund_eligible ? 'refund-not-eligible' : '' }}">
                                        <h6 class="text-center mb-3 text-primary">Refund Calculation</h6>

                                        <div
                                            class="calculation-row d-flex justify-content-between align-items-center mb-3">
                                            <div class="calculation-label">
                                                <span class="fw-semibold">Total Paid Amount</span>
                                                <small class="d-block text-dark">[With GST]</small>
                                            </div>
                                            <div class="calculation-value fw-bold fs-6 text-success">
                                                {{ $currency_symbol }} {{ number_format($customer_details->paid_amount ?? 0) }}
                                            </div>
                                        </div>

                                        <div
                                            class="calculation-row d-flex justify-content-between align-items-center mb-3">
                                            <div class="calculation-label">
                                                <input type="hidden" name="min_deducted_amount" id="min_deducted_amount"
                                                    value="{{ $min_deducted_amount ?? 0 }}">
                                                <span class="fw-semibold">Min. Deducted Amount</span>
                                                <small class="d-block text-dark">Service charges</small>
                                            </div>
                                            <div class="calculation-value fw-bold fs-6 text-danger">
                                                - {{ $currency_symbol }} {{ number_format($min_deducted_amount ?? 0) }}
                                            </div>
                                        </div>

                                        <div
                                            class="calculation-row d-flex justify-content-between align-items-center mb-3 p-2 {{ $is_refund_eligible ? 'bg-success bg-opacity-10' : 'bg-danger bg-opacity-10' }} rounded">
                                            <div class="calculation-label">
                                                <span
                                                    class="fw-bold {{ $is_refund_eligible ? 'text-success' : 'text-danger' }}">Possible
                                                    Eligible Amount</span>
                                            </div>
                                            <div
                                                class="calculation-value fw-bold fs-5 {{ $is_refund_eligible ? 'text-success' : 'text-danger' }}">
                                                {{ $currency_symbol }} {{ number_format($balance_amount ?? 0) }}
                                            </div>
                                        </div>

                                        @if ($is_refund_eligible)
                                            <!-- Refund Input with validation feedback -->
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">Refund Amount <span
                                                        class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <span class="input-group-text bg-primary text-white">{{ $currency_symbol }}</span>
                                                    <input type="text" class="form-control" id="refund_amount"
                                                        value="{{ $balance_amount }}" style="background-color: #f8f9fa;">
                                                </div>
                                                <small class="text-dark">Eligible refund amount is automatically
                                                    calculated. Maximum: {{ $currency_symbol }}{{ number_format($balance_amount ?? 0) }}</small>
                                            </div>

                                            <div
                                                class="calculation-row d-flex justify-content-between align-items-center mb-3 p-2 bg-danger bg-opacity-10 rounded">
                                                <div class="calculation-label">
                                                    <span class="fw-bold text-danger">Max.Refund Date</span>
                                                </div>
                                                <div class="calculation-value fw-bold fs-5 text-danger">
                                                    <span><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <?php
                                                    $currentDate = new DateTime();
                                                    $days = $genaral_settings->max_refund_days ?? 7;
                                                    $currentDate->modify('+' . $days . ' days');
                                                    $futureDate = $currentDate->format('d-M-Y');
                                                    ?>
                                                    <label class="fs-5 fw-bold text-center"><?php echo $futureDate; ?></label>
                                                    <input type="hidden" name="max_refund_date" id="max_refund_date"
                                                        value="<?php echo $futureDate; ?>">
                                                </div>
                                            </div>

                                            <!-- Refund Reason - Only shown when requesting refund -->
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">Refund Reason <span
                                                        class="text-danger">*</span></label>
                                                <textarea class="form-control" rows="3" id="refund_reason" placeholder="Please provide reason for refund..."></textarea>
                                            </div>
                                        @else
                                            <div class="alert alert-danger text-center">
                                                <i class="mdi mdi-alert-circle-outline fs-2 mb-2"></i>
                                                <h6 class="alert-heading">Refund Not Eligible</h6>
                                                <p class="mb-0">Possible eligible amount is negative or zero. Refund
                                                    cannot be processed.</p>
                                            </div>
                                        @endif
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <div class="d-grid">
                                    <button type="button" class="btn btn-primary btn-lg" id="submit_btn">
                                        <i class="mdi mdi-cancel me-1"></i> Drop Customer
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmation_modal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title text-center w-100">
                        <i class="mdi mdi-help-circle-outline text-warning fs-1 me-2"></i>
                        <span id="modal_title">Confirm Service Drop</span>
                    </h5>
                </div>
                <div class="modal-body pt-0">
                    <div class="text-center mb-4">
                        <h5 id="modal_message" class="text-dark">Are you sure you want to drop the Customer and request
                            refund?</h5>
                    </div>

                    <div class="customer-summary bg-light rounded p-3 mb-4">
                        <div class="row g-2">
                            <div class="col-6">
                                <small class="text-dark">Customer</small>
                                <div class="fw-bold">{{ $customer_details->cus_name ?? '-' }}</div>
                            </div>
                            <div class="col-6">
                                <small class="text-dark">Customer ID</small>
                                <div class="fw-bold">( {{ $customer_details->customer_id ?? '-' }} )</div>
                            </div>
                        </div>
                    </div>

                    <!-- Make sure this element exists with the correct ID -->
                    <div id="refund_summary_section" class="refund-summary bg-light rounded p-3" style="display: none;">
                        <h6 class="text-center mb-3 text-primary">Refund Summary</h6>
                        <div class="refund-breakdown">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Total Paid Amount:</span>
                                <span class="fw-bold">{{ $currency_symbol }} {{ number_format($customer_details->paid_amount ?? 0) }}</span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Min. Deducted Amount:</span>
                                <span class="fw-bold text-danger">- {{ $currency_symbol }}
                                    {{ number_format($min_deducted_amount ?? 0) }}</span>
                            </div>
                            <div class="d-flex justify-content-between mb-3 pt-2 border-top">
                                <span class="fw-bold text-success">Possible Eligible Amount:</span>
                                <span class="fw-bold text-success">{{ $currency_symbol }} {{ number_format($balance_amount ?? 0) }}</span>
                            </div>
                            <div class="d-flex justify-content-between p-2 bg-primary bg-opacity-10 rounded">
                                <span class="fw-bold text-white">Refund Amount:</span>
                                <span class="fw-bold text-white">{{ $currency_symbol }} {{ number_format($balance_amount ?? 0) }}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="mdi mdi-close me-1"></i> Cancel
                    </button>
                    <button type="button" id="confirm_action_btn" class="btn btn-primary">
                        <i class="mdi mdi-check me-1"></i> Confirm Drop (or) Refund
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Checklist Counter
            const checkboxes = document.querySelectorAll('.checklist-checkbox');

            const countDisplay = document.getElementById('check_list_count');
            const totalCheckboxes = checkboxes.length;
            let checkListCount = 0;

            // Refund eligibility
            const isRefundEligible = document.getElementById('is_refund_eligible').value === '1';
            const refundToggle = document.getElementById('refund_toggle');
            const refundSection = document.getElementById('refund_section');
            const dropReasonSection = document.getElementById('drop_reason_section');
            const submitBtn = document.getElementById('submit_btn');

            // Update count display initially
            updateCount();

            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    if (this.checked) {
                        checkListCount++;
                    } else {
                        checkListCount--;
                    }
                    updateCount();
                    validateForm();
                });
            });


            function updateCount() {
                countDisplay.textContent = String(checkListCount).padStart(2, '0');
            }

            // Refund Toggle - Only enable if refund is eligible
            if (isRefundEligible) {
                refundToggle.addEventListener('change', function() {
                    if (this.checked) {
                        refundSection.style.display = 'block';
                        dropReasonSection.style.display = 'none';
                        submitBtn.innerHTML =
                            '<i class="mdi mdi-cash-refund me-1"></i> Drop Customer with Refund';
                        submitBtn.classList.remove('btn-primary');
                        submitBtn.classList.add('btn-success');
                        document.getElementById('drop_reason').value = '';
                    } else {
                        refundSection.style.display = 'none';
                        dropReasonSection.style.display = 'block';
                        submitBtn.innerHTML = '<i class="mdi mdi-cancel me-1"></i> Drop Customer';
                        submitBtn.classList.remove('btn-success');
                        submitBtn.classList.add('btn-primary');
                        document.getElementById('refund_reason').value = '';
                    }
                    validateForm();
                });
            }

            // Form Input Listeners
            const dropReasonInput = document.getElementById('drop_reason');
            const refundReasonInput = document.getElementById('refund_reason');
            const refundAmountInput = document.getElementById('refund_amount');

            dropReasonInput.addEventListener('input', validateForm);

            if (isRefundEligible) {
                refundReasonInput.addEventListener('input', validateForm);
                refundAmountInput.addEventListener('input', function() {
                    validateRefundAmount();
                    validateForm();
                });
            }

            // Refund Amount Validation - Only if eligible
            function validateRefundAmount() {
                if (!isRefundEligible) return;

                const refundAmount = parseFloat(refundAmountInput.value) || 0;
                const possibleEligibleAmount = {{ $balance_amount }};

                if (refundAmount > possibleEligibleAmount) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Invalid Refund Amount',
                        text: `Refund amount cannot exceed possible eligible amount ({{ $currency_symbol }}${possibleEligibleAmount.toLocaleString()})`,
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#0d6efd',
                        customClass: {
                            confirmButton: 'btn btn-primary'
                        }
                    });
                    refundAmountInput.value = possibleEligibleAmount;
                }

                if (refundAmount < 0) {
                    refundAmountInput.value = 0;
                }
            }

            // Submit Button - Comprehensive Validation
            submitBtn.addEventListener('click', function() {
                if (!validateAllFields()) {
                    return;
                }
                submitDropRequest(isRefundEligible && refundToggle.checked);
            });

            // Comprehensive validation function
            function validateAllFields() {
                const withRefund = isRefundEligible && refundToggle.checked;
                const dropReason = dropReasonInput.value.trim();
                const refundReason = refundReasonInput ? refundReasonInput.value.trim() : '';
                const refundAmount = refundAmountInput ? parseFloat(refundAmountInput.value) || 0 : 0;
                const possibleEligibleAmount = {{ $balance_amount }};
                const services_checkbox = document.querySelectorAll('.services_checkbox');

                // Check 1: service checkbox
                let scheckedCount = 0;

                services_checkbox.forEach(cb => {
                    if (cb.checked) {
                        scheckedCount++;
                    }
                });
                if (scheckedCount === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Services Checklist Incomplete',
                        text: 'Please select at least one service checkbox before proceeding.',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#0d6efd',
                        customClass: {
                            confirmButton: 'btn btn-primary'
                        }
                    });
                    return false;
                }

                // Check 2: Drop Reason Validation (ALWAYS required when refund is not eligible)
                if (!isRefundEligible || !withRefund) {
                    if (dropReason === '') {
                        Swal.fire({
                            icon: 'error',
                            title: 'Missing Information',
                            text: 'Please provide a reason for dropping Customer.',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#0d6efd',
                            customClass: {
                                confirmButton: 'btn btn-primary'
                            }
                        });
                        dropReasonInput.focus();
                        return false;
                    }
                }

                // Check 3: Refund Validation - Only if eligible and selected
                if (isRefundEligible && withRefund) {
                    if (refundReason === '') {
                        Swal.fire({
                            icon: 'error',
                            title: 'Missing Information',
                            text: 'Please provide a reason for refund request.',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#0d6efd',
                            customClass: {
                                confirmButton: 'btn btn-primary'
                            }
                        });
                        refundReasonInput.focus();
                        return false;
                    }

                    if (refundAmount <= 0) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Invalid Refund Amount',
                            text: 'Please enter a valid refund amount greater than 0.',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#0d6efd',
                            customClass: {
                                confirmButton: 'btn btn-primary'
                            }
                        });
                        refundAmountInput.focus();
                        return false;
                    }

                    if (refundAmount > possibleEligibleAmount) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Invalid Refund Amount',
                            text: `Refund amount cannot exceed possible eligible amount ({{ $currency_symbol }}${possibleEligibleAmount.toLocaleString()})`,
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#0d6efd',
                            customClass: {
                                confirmButton: 'btn btn-primary'
                            }
                        });
                        refundAmountInput.focus();
                        return false;
                    }
                }

                // Check 3: All checklist items must be checked
                if (checkListCount !== totalCheckboxes) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Drop Refund Checklist Incomplete',
                        text: `Please complete all ${totalCheckboxes} checklist items before proceeding.`,
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#0d6efd',
                        customClass: {
                            confirmButton: 'btn btn-primary'
                        }
                    });
                    return false;
                }

                return true;
            }

            function validateForm() {
                const dropReason = dropReasonInput.value.trim();
                const refundReason = refundReasonInput ? refundReasonInput.value.trim() : '';
                const refundAmount = refundAmountInput ? parseFloat(refundAmountInput.value) || 0 : 0;
                const withRefund = isRefundEligible && refundToggle.checked;
                const possibleEligibleAmount = {{ $balance_amount }};

                const allCheckboxesChecked = checkListCount === totalCheckboxes;
                let isValid = allCheckboxesChecked;

                // Remove all validation classes first
                dropReasonInput.classList.remove('is-valid', 'is-invalid');
                if (refundReasonInput) refundReasonInput.classList.remove('is-valid', 'is-invalid');
                if (refundAmountInput) refundAmountInput.classList.remove('is-valid', 'is-invalid');

                // When refund is NOT eligible OR refund toggle is off
                if (!isRefundEligible || !withRefund) {
                    // Only validate drop reason
                    const isDropReasonValid = dropReason !== '';
                    isValid = isValid && isDropReasonValid;

                    // Apply validation styling to drop reason
                    if (dropReason !== '') {
                        dropReasonInput.classList.add('is-valid');
                    } else {
                        dropReasonInput.classList.add('is-invalid');
                    }
                }

                // When refund IS eligible AND toggle is on
                if (isRefundEligible && withRefund) {
                    // Validate refund fields
                    const isRefundReasonValid = refundReason !== '';
                    const isRefundAmountValid = refundAmount > 0 && refundAmount <= possibleEligibleAmount;

                    isValid = isValid && isRefundReasonValid && isRefundAmountValid;

                    // Apply validation styling
                    if (refundReason !== '') {
                        refundReasonInput.classList.add('is-valid');
                    } else {
                        refundReasonInput.classList.add('is-invalid');
                    }

                    if (refundAmount > 0 && refundAmount <= possibleEligibleAmount) {
                        refundAmountInput.classList.add('is-valid');
                    } else if (refundAmount > 0) {
                        refundAmountInput.classList.add('is-invalid');
                    }
                }

                // Update submit button state
                if (isValid) {
                    // submitBtn.disabled = false;
                    if (isRefundEligible && withRefund) {
                        submitBtn.classList.remove('btn-secondary', 'btn-primary');
                        submitBtn.classList.add('btn-success');
                    } else {
                        submitBtn.classList.remove('btn-secondary', 'btn-success');
                        submitBtn.classList.add('btn-primary');
                    }
                } else {
                    // submitBtn.disabled = true;
                    submitBtn.classList.remove('btn-primary', 'btn-success');
                    submitBtn.classList.add('btn-secondary');
                }
            }

            function submitDropRequest(withRefund) {
                if (!validateAllFields()) {
                    return;
                }
                showConfirmationModal(withRefund);
            }

            function showConfirmationModal(withRefund) {
                if (withRefund && isRefundEligible) {
                    document.getElementById('modal_title').textContent = 'Confirm Drop with Refund';
                    document.getElementById('modal_message').textContent =
                        'Are you sure you want to drop the Customer and request refund?';

                    const refundAmount = document.getElementById('refund_amount').value;
                    // Update the refund amount in the modal
                    const refundAmountElement = document.querySelector(
                        '#refund_summary_section .fw-bold.text-white:last-child');
                    if (refundAmountElement) {
                        refundAmountElement.textContent = '{{ $currency_symbol }} ' + parseFloat(refundAmount).toLocaleString('en-IN', {
                            minimumFractionDigits: 2
                        });
                    }

                    const refundSummarySection = document.getElementById('refund_summary_section');
                    if (refundSummarySection) {
                        refundSummarySection.style.display = 'block';
                    }
                } else {
                    document.getElementById('modal_title').textContent = 'Confirm Customer Drop';
                    document.getElementById('modal_message').textContent =
                        'Are you sure you want to drop the Customer?';

                    const refundSummarySection = document.getElementById('refund_summary_section');
                    if (refundSummarySection) {
                        refundSummarySection.style.display = 'none';
                    }
                }

                const modal = new bootstrap.Modal(document.getElementById('confirmation_modal'));
                modal.show();
            }

            // Confirm Action - AJAX Submission
            document.getElementById('confirm_action_btn').addEventListener('click', function() {
                const withRefund = isRefundEligible && refundToggle.checked;
                const confirmBtn = document.getElementById('confirm_action_btn');

                // Final validation before submission
                if (!validateAllFields()) {
                    return;
                }

                confirmBtn.disabled = true;
                confirmBtn.innerHTML = '<i class="mdi mdi-loading mdi-spin me-1"></i> Processing...';

                const formData = new FormData();

                formData.append('customer_id', document.getElementById('customer_id').value.trim());
                formData.append('branch_id', '1');
                formData.append('type', withRefund ? '1' : '0');

                if (withRefund) {
                    formData.append('drop_refund_reason', document.getElementById('refund_reason').value
                        .trim());
                    formData.append('refund_amount', document.getElementById('refund_amount').value);
                    formData.append('paid_amount', '{{ $customer_details->paid_amount ?? 0 }}');
                    formData.append('min_deducted_amount',
                        '{{ $min_deducted_amount ?? 0 }}');
                    formData.append('costing_amount', '0.00');
                    formData.append('costing_hours', '0');
                    formData.append('posible_eligible_amount', document.getElementById('refund_amount')
                        .value);

                    const maxRefundDate = new Date();
                    maxRefundDate.setDate(maxRefundDate.getDate() + 30);
                    formData.append('max_refund_date', maxRefundDate.toISOString().split('T')[0]);
                } else {
                    formData.append('drop_refund_reason', document.getElementById('drop_reason').value
                        .trim());
                }

                let checklistHTML = '';
                checkboxes.forEach((checkbox, index) => {
                    if (checkbox.checked) {
                        const label = checkbox.nextElementSibling.textContent.trim();
                        checklistHTML += `
                        <div class="col-lg-12 mb-2">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input checklist-checkbox" type="checkbox" checked="checked">
                                <label class="form-check-label fw-semibold fs-7">${label}</label>
                            </div>
                        </div>`;
                    }
                });

                formData.append('check_list', checklistHTML);
                $('.services_checkbox:checked').each(function () {
                    formData.append('services_checkbox[]', $(this).val());
                });

                formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute(
                    'content'));

                fetch('{{ route('customer.drop.submit') }}', {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest',
                            'Accept': 'application/json',
                        }
                    })
                    .then(response => {
                        if (!response.ok) {
                            // throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            const modal = bootstrap.Modal.getInstance(document.getElementById(
                                'confirmation_modal'));
                            modal.hide();

                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                html: `
                                <div class="text-center">
                                    <h5>${data.message}</h5>
                                    <div class="mt-3 p-3 bg-light rounded">
                                        <strong>Reference No:</strong> ${data.data.reference_number}<br>
                                        <strong>Type:</strong> ${data.data.type}<br>
                                        <strong>Submitted At:</strong> ${data.data.submitted_at}
                                    </div>
                                </div>
                            `,
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#0d6efd',
                                showCancelButton: false, // This disables the cancel button
                                customClass: {
                                    confirmButton: 'btn btn-primary'
                                }
                            }).then(() => {
                                window.location.href = '/manage_customer';
                            });


                            resetForm();
                        } else {
                            throw new Error(data.message || 'Submission failed');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);

                        Swal.fire({
                            icon: 'error',
                            title: 'Submission Failed',
                            text: error.message ||
                                'There was an error submitting your request. Please try again.',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#0d6efd',
                            customClass: {
                                confirmButton: 'btn btn-primary'
                            }
                        });

                        confirmBtn.disabled = false;
                        confirmBtn.innerHTML = '<i class="mdi mdi-check me-1"></i> Confirm Drop';
                    });
            });

            function resetForm() {
                // Clear form values
                document.getElementById('drop_reason').value = '';
                if (document.getElementById('refund_reason')) {
                    document.getElementById('refund_reason').value = '';
                }
                if (document.getElementById('refund_amount')) {
                    document.getElementById('refund_amount').value = '{{ $balance_amount }}';
                }

                // Clear validation classes
                document.getElementById('drop_reason').classList.remove('is-invalid', 'is-valid');
                if (document.getElementById('refund_reason')) {
                    document.getElementById('refund_reason').classList.remove('is-invalid', 'is-valid');
                }
                if (document.getElementById('refund_amount')) {
                    document.getElementById('refund_amount').classList.remove('is-invalid', 'is-valid');
                }

                // Reset checkboxes
                checkboxes.forEach(checkbox => checkbox.checked = false);
                checkListCount = 0;
                updateCount();

                // Reset toggle state (only if refund is eligible)
                if (isRefundEligible) {
                    refundToggle.checked = false;
                    refundSection.style.display = 'none';
                    dropReasonSection.style.display = 'block';
                }

                // Reset submit button
                submitBtn.innerHTML = '<i class="mdi mdi-cancel me-1"></i> Drop Customer';
                submitBtn.classList.remove('btn-success');
                submitBtn.classList.add('btn-primary');

                // Re-validate form
                validateForm();
            }

            // Initialize form validation
            validateForm();
        });
    </script>
    <script>
        function SelectColor(id) {
            var checkbox = $('#services_checkbox' + id);
            if (checkbox.is(':checked')) {
                $('#services_div' + id).addClass('bg-label-success');
            } else {
                $('#services_div' + id).removeClass('bg-label-success');
            }
        }
    </script>
@endsection
