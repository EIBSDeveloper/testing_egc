@extends('layouts/layoutMaster')

@section('title', 'Manage Refund')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection
@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

<style>
  .list_page tbody td {
    padding: 5px !important;
  }
</style>
@section('content')
<div class="card card-action">
  <div class="card-header border-bottom pb-0 flex-wrap">
    <div class="card-action-title text-black fs-5 fw-bold mb-1">
      <h5 class="card-title mb-1">Manage Refund</h5>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-1">
          <li class="breadcrumb-item">
            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
          </li>
          <span class="text-dark opacity-75 me-1 ms-1">
            <i class="mdi mdi-chevron-double-right fs-4"></i>
          </span>
          <li class="breadcrumb-item">
            <a href="javascript:;" class="d-flex align-items-center fw-semibold">Customer Management</a>
          </li>
        </ol>
      </nav>
    </div>
    <div class="card-action-element mb-1 text-center">
      <div class="d-flex justify-content-end align-items-center flex-wrap gap-2">
        {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" title="Exports">
          <span><i class="mdi mdi-export text-center"></i></span>
        </a>
        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="filter" title="Filter">
          <span><i class="mdi mdi-filter-outline text-center text-center"></i></span>
        </a> --}}
      </div>
    </div>
  </div>
  <div class="card-body pt-2">
    <div class="row mb-4">
      @php $perpage_count = $perpage ? $perpage : 10; @endphp
      <div class="col-lg-2">
          <span>Show</span>
          <br>
          <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
              @php
              $options = [10, 25, 100, 500]; // Define available options
              @endphp
              @php foreach ($options as $option): @endphp
              <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                  @php echo $option; @endphp
              </option>
              @php endforeach; @endphp
          </select>
      </div>
      <div class="col-lg-10 d-flex align-items-end justify-content-end">
          <form id="search_form" method="POST" action="/manage_customer_refund">
              @csrf
            <div class="d-flex align-items-center gap-2 mt-2">
              <div>
                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                <input type="hidden" name="filter_on" value="1">
                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                <input
                  type="text"
                  class="form-control"
                  id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                  placeholder="Enter Search"
                />
              </div>
              <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
            </div>
          </form>
      </div>
    </div>
    <div class="row">
      @php
      $helper = new \App\Helpers\Helpers();
      $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
      @endphp
      <div class="col-lg-12">
        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
          <thead>
            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
              <th class="min-w-100px">Customer</th>
              <th class="min-w-150px">Services / Payment Progress</th>
              <th class="min-w-50px">Authority Status</th>
              <th class="min-w-80px">A/c Status</th>
              <th class="min-w-50px">Actions</th>
            </tr>
          </thead>
          <tbody class="text-black fw-semibold fs-7">
            @if (isset($customers))
              @foreach ($customers as $i=> $cus)
                <tr @if ($cus->ac_status == 2) style="background-color:#c6ebdc!important;" @endif >
                   <td>
                        <div class="d-flex align-items-center px-1">
                            <div class="mb-0 align-items-center">
                                <label>
                                    <span class="fs-7 me-1">{{ $cus->cus_name }}</span>
                                </label>
                                <div class="d-block text-primary fs-8" title="Email ID">{{ $cus->cus_email_id ?? '-' }}</div>
                                <div class="d-block mt-1">
                                    <label class="fw-semibold fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Requested Date">{{ date($common_date_format, strtotime($cus->created_at)) }}</label>
                                </div>
                            </div>
                        </div>
                    </td>
                  <td>
                        @php
                            $proposal_details = json_decode($cus->proposal_details, true);
                        @endphp
                        @php
                            $Progress = $cus->paid_percentage; // Placeholder value for progress
                            $pay_per = $cus->paid_percentage;  // Placeholder value for payment percentage
                            $payable_amount = $cus->payable_amount; // Placeholder value for paid amount
                            $paid_amount = $cus->paid_amount; // Placeholder value for paid amount
                            $balance_amount = $cus->balance_amount; // Placeholder value for paid amount
                            $present_days = 0; // Placeholder value for present days
                            
                            // Set color based on progress value
                            if ($Progress <= 20) {
                                $color = '#ec0b03'; // Red
                            } elseif ($Progress >= 90) {
                                $color = '#16af08'; // Green
                            } else {
                                $color = '#ffa500'; // Orange
                            }
                        @endphp

                        <div id="carouselExample{{$i}}" class="carousel slide" data-bs-ride="carousel" style="max-height: 200px;">
                            <div class="carousel-inner pb-5 ps-5">
                                @foreach ($proposal_details as $index => $proposal)
                                 
                                <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                                    <div class="text-center text-info mb-1 ms-n5">Proposal ID - {{ $proposal['proposal_ids'] }}</div>
                                    <div class="d-flex px-1 align-items-center gap-1">
                                        <!-- Payment Progress -->
                                        <a href="javascript:;" class="d-inline-flex position-relative text-decoration-none">
                                            <div class="progress rounded h-80px w-40px rotate-180 border border-gray-400 shadow-lg"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $pay_per }} % Payment Progress">
                                                <div class="progress-bar progress-bar-striped progress-bar-animated  w-100 rotate-180"
                                                    role="progressbar" aria-valuenow="{{ $pay_per }}" aria-valuemin="0" aria-valuemax="100" style="background: {{ $color }}; height: {{ $pay_per }}%" >
                                                    <span class="text-black fw-bold mb-1 rotate-270 d-block">{{ $pay_per }}%</span>
                                                </div>
                                            </div>
                                        </a>
                                        <label class="txt_vertical">Payment %</label>

                                        <!-- Service Details -->
                                        <div class="ms-2">
                                            <div class="row w-350px">
                                                <div class="col-12">
                                                    <div class="row align-items-center">
                                                        <label class="col-4 text-dark fs-8 fw-semibold mb-0">Type</label>
                                                        <label class="col-1 text-dark fs-8 fw-semibold mb-0">:</label>
                                                        <label class="col-7 text-black fs-8 fw-bold mb-0 text-truncate">@if($proposal['product_package'] == 1) Product @else Package @endif</label>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="row align-items-center">
                                                        <label class="col-4 text-dark fs-8 fw-semibold mb-0">{{ str_pad($index + 1 , 2, '0', STR_PAD_LEFT) }} Product</label>
                                                        <label class="col-1 text-dark fs-8 fw-semibold mb-0">:</label>
                                                        <label class="col-7 text-black fs-8 fw-semibold mb-0 text-truncate custom-text" 
                                                              data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $proposal['product_name'] }}">
                                                            {{ $proposal['product_name'] }} <!-- This would be dynamic data if needed -->
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="row align-items-center">
                                                        <label class="col-4 text-dark fs-8 fw-semibold mb-0">Variant</label>
                                                        <label class="col-1 text-dark fs-8 fw-semibold mb-0">:</label>
                                                        <label class="col-7 text-black fs-8 fw-semibold mb-0 text-truncate custom-text" 
                                                              data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $proposal['variant_name'] }}">
                                                            {{ $proposal['variant_name'] }} <!-- This would be dynamic data if needed -->
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="row align-items-center">
                                                        <label class="col-4 text-dark fs-8 fw-semibold mb-0">Variable</label>
                                                        <label class="col-1 text-dark fs-8 fw-semibold mb-0">:</label>
                                                        <label class="col-7 text-black fs-8 fw-semibold mb-0 text-truncate custom-text" 
                                                              data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $proposal['variable_name'] }}">
                                                            {{ $proposal['variable_name'] }} <!-- This would be dynamic data if needed -->
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- End Carousel Item -->
                                @endforeach
                            </div><!-- End Carousel Inner -->

                            <!-- Carousel Indicators -->
                            <div class="carousel-indicators position-absolute mb-0" style="bottom: 10px;">
                                @foreach ($proposal_details as $index => $proposal)
                                    <button type="button" data-bs-target="#carouselExample{{$i}}" data-bs-slide-to="{{ $index }}" class="{{ $index == 0 ? 'active' : '' }} bg-dark" style="width: 8px; height: 8px; border-radius: 50%;"></button>
                                @endforeach
                            </div><!-- End Carousel Indicators -->
                        </div><!-- End Carousel -->
                    </td>
                  <td>
                    @if($cus->bh_status==0)
                    <a href="javascript:;" class="badge bg-warning text-black fw-bold fs-8" @if(auth()->user()->role_id == 1)data-bs-toggle="dropdown" @endif aria-haspopup="true" aria-expanded="false">Waiting for Approval</a>
                    <div class="dropdown-menu dropdown-menu-end">
                      <a href="javascript:;" class="dropdown-item fs-7 py-2" data-bs-toggle="modal" data-bs-target="#kt_modal_refund_accept_bh" onclick="status_change(1 , {{ json_encode($cus ?? [])}},{{ $Progress }},{{ $pay_per }}, {{count($cus->proposal_details)}})">Refund Accept</a>
                      <a href="javascript:;" class="dropdown-item fs-7 py-2" data-bs-toggle="modal" data-bs-target="#kt_modal_refund_accept_bh" onclick="status_change(2 , {{ json_encode($cus ?? [])}},{{ $Progress }},{{ $pay_per }}, {{count($cus->proposal_details)}})">Refund Reject</a>
                    </div>
                    @elseif ($cus->bh_status==1)
                    <div class="badge bg-danger text-white fw-bold fs-8" >Accepted</div>
                    <div class="d-block mt-1">
                      <label class="fw-semibold fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Request Accepted Date">{{ $cus->bh_status_date ? date($common_date_format, strtotime($cus->bh_status_date)) :'-' }}</label>
                    </div>
                    @elseif ($cus->bh_status==2)
                    <div class="badge  text-white fw-bold fs-8" style="background-color:#50cd89 !important;">Rejected</div>
                      <a href="javascript:;" class="fw-bold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $cus->bh_reject_reason??'-' }}"><i class="mdi mdi-information fs-7 text-black fw-bold"></i></a>
                    @endif
                  </td>
                  <td align="center">
                    @if ($cus->bh_status == 1)
                          @if ($cus->ac_status == 0)
                              <a href="javascript:;" class="badge bg-warning text-black fw-bold fs-8"
                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Waiting for Approval
                              </a>
                              <div class="dropdown-menu dropdown-menu-end">
                                  <a href="javascript:;" class="dropdown-item fs-7 py-2"
                                    data-bs-toggle="modal" data-bs-target="#kt_modal_refund_accept_acc"
                                    onclick="ac_status_change(1, {{ json_encode($cus ?? []) }}, {{ $Progress }}, {{ $pay_per }}, {{count($cus->proposal_details)}})">
                                    A/c - Refund Accept
                                  </a>
                              </div>
                          @elseif ($cus->ac_status == 1)
                              <a  href="javascript:;" class="badge bg-info text-white fw-bold fs-8"  data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  A/C - Accepted
                              </a>
                              <div class="dropdown-menu dropdown-menu-end">
                                  <a href="javascript:;" class="dropdown-item fs-7 py-2"
                                    data-bs-toggle="modal" data-bs-target="#kt_modal_refund_acc"
                                    onclick="ac_status_change_refund(1, {{ json_encode($cus ?? []) }}, {{ $Progress }}, {{ $pay_per }})">
                                    Amount Refunded
                                  </a>

                                  {{-- <a href="javascript:;" class="dropdown-item fs-7 py-2">
                                    Amount Refunded
                                  </a> --}}
                              </div>
                              <div class="d-block mt-1">
                                  <label class="fw-semibold fs-8 text-dark"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                        title="Request Accepted Date">
                                      {{ $cus->ac_status_date ? date($common_date_format, strtotime($cus->ac_status_date)) : '-' }}
                                  </label>
                              </div>
                          @elseif ($cus->ac_status == 2)
                              <div>
                                <span class="badge bg-danger text-white fw-bold fs-8">Amount Refunded</span>
                              </div>
                              <div class="d-block mt-1">
                                <label class="fw-semibold fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Refunded Date">{{ $cus->refunded_date ? date($common_date_format, strtotime($cus->refunded_date)) : '-' }}</label>
                              </div>
                          @else
                              -
                          @endif
                      @else
                          -
                      @endif
                  </td>
                  <td align="center">
                    <span class="text-end">
                      <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_refund_view" onclick="view_drop_refund({{ json_encode($cus ?? [])}},{{ $Progress }},{{ $pay_per }})">
                        <i class="mdi mdi-eye-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"></i>
                      </a>
                    </span>
                  </td>
                </tr>
              @endforeach
            @endif
          </tbody>
        </table>
      </div>
      <div class="mt-4">
          {{ $customers->appends(request()->except(['page', '_token']))->links() }}
      </div>
    </div>
  </div>
</div>
<!--begin::Modal - Refund View-->
<div class="modal fade" id="kt_modal_refund_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div id="view_drop_refundContent"></div>

      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Refund View-->

<!--begin::Modal - Refund Request BH Accepted-->
<div class="modal fade" id="kt_modal_refund_accept_bh" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <form id="cus_drp_form" action="{{ route('customer_refund_status_change') }}" method="POST" enctype="multipart/form-data" autocomplete="off" onsubmit="return status_change_validation()">
          @csrf
          <div id="statusModalContent"></div>
          <div class="d-flex justify-content-end align-items-center mt-6 gap-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
              <button type="submit" class="btn btn-primary" id="status_submit_btn">Refund</button>
          </div>
        </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Refund Request BH Accepted-->

<!--begin::Modal - Refund Request Accounts Accepted-->
<div class="modal fade" id="kt_modal_refund_accept_acc" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <form id="cus_drp_form" action="{{ route('customer_refund_ac_status_change') }}" method="POST" enctype="multipart/form-data" autocomplete="off">
          @csrf
          <div id="AC_statusModalContent"></div>
          <div class="d-flex justify-content-end align-items-center mt-6 gap-3">
            <a href="javascript:;" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</a>
            <button type="submit" class="btn btn-primary" >A/c - Refund Accepted</button>
          </div>
        </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Refund Request Accounts Accepted-->

<!--begin::Modal - Refund Request Accounts Rejected-->
<div class="modal fade" id="kt_modal_refund_acc" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <form id="cus_drp_form" action="{{ route('customer_refunded_status_change') }}" method="POST" enctype="multipart/form-data" autocomplete="off" onsubmit="return refund_status_change_validation()">
          @csrf
          <div id="AC_refund_statusModalContent"></div>
          
          <div class="d-flex justify-content-end align-items-center mt-6 gap-3">
            <a href="javascript:;" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</a>
            <button type="submit" class="btn btn-primary" >A/c - Refund Accepted</button>
          </div>
        </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Refund Request Accounts Rejected-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
  /* Customize Toastr notification */
  .toast-success {
      background-color: green;
  }

  /* Customize Toastr notification */
  .toast-error {
      background-color: rgb(196, 3, 3);
  }
  .error_msg {
      border: solid 2px red !important;
      border-color: red !important;
  }
</style>
<script>
  // Display Toastr messages
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
  toastr[type](message);
  @endif
</script>
<script>
  $('#filter').click(function() {
      $('.filter_tbox').slideToggle('slow');
  });
  $(document).ready(function() {
      @if ($filter_on ?? '')
          // $('.customer_tbox').slideToggle('fast');
          $('.filter_tbox').slideToggle('fast');
          // });
      @endif
  });
</script>
<script>
  function formatDateTime(dateString) {
      const date = new Date(dateString);

      // Check if the date is valid
      if (isNaN(date.getTime())) {
          return '-'; // Return '-' if the date is invalid
      }

      const options = {
          year: 'numeric',
          month: 'short',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true
      };

      return date.toLocaleString('en-GB', options).replace(',', '');
  }
  function formatDate(dateString) {
      const date = new Date(dateString);

      // Check if the date is valid
      if (isNaN(date.getTime())) {
          return '-'; // Return '-' if the date is invalid
      }

      // Get the day, month (abbreviated), and year
      const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
      const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
      const year = date.getFullYear(); // Get full year

      // Construct and return the formatted date string
      return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
  }
  function Currecncy_format(Number) {
    var Currecncy = (Number || 0).toLocaleString('en-IN', {
                    maximumFractionDigits: 2,
                    currency: 'INR'
                });
    return Currecncy;
  }
 function status_change(type, data, pay , products) {
    console.log(data);
    // Determine the status (Accepted/Rejected)
    const status = type === 1 ? 'Accepted' : 'Rejected';
    const statusColor = type === 1 ? 'success' : 'danger';
    const statusIcon = type === 1 ? 'fa-check-circle' : 'fa-times-circle';

    if (type == 1) {
        var bh_status = '<span class="status-badge status-accepted">Accepted</span>';
    } else if (type == 2) {
        var bh_status = '<span class="status-badge status-rejected">Rejected</span>';
    } else {
        var bh_status = '<span class="status-badge status-pending">Waiting for Approval</span>';
    }

    var ac_type = data.ac_status;
    if (ac_type == 1) {
        var ac_status = '<span class="status-badge status-accepted">Accepted</span>';
    } else if (ac_type == 2) {
        var ac_status = '<span class="status-badge status-rejected">Rejected</span>';
    } else {
        var ac_status = '<span class="text-muted">-</span>';
    }

    // Calculate checked and total checklist items
    const parser = new DOMParser();
    const checklistDoc = parser.parseFromString(data.check_list, 'text/html');
    const allCheckboxes = checklistDoc.querySelectorAll('.checklist-checkbox');
    const checkedCount = checklistDoc.querySelectorAll('.checklist-checkbox:checked').length;
    const totalCount = allCheckboxes.length;
    const formattedDateTime = formatDateTime(data.created_at);
    const formattedDate = formatDate(data.created_at);
    const bhformattedDateTime = formatDateTime(data.bh_status_date);
    const acformattedDateTime = formatDateTime(data.ac_status_date);

    // Staff information templates
    var bh = `<div class="staff-info">
                <div class="text-muted fs-7">Not assigned</div>
              </div>`;
    if (data.bh_staff_name) {
        bh = `<div class="staff-info">
                <div class="staff-name">${data.bh_staff_name || '-'}</div>
                <div class="staff-time">${bhformattedDateTime}</div>
                <div class="staff-status">${bh_status}</div>
              </div>`;
    }

    var ac = `<div class="staff-info">
                <div class="text-muted fs-7">Not assigned</div>
              </div>`;
    if (data.ac_staff_name) {
        ac = `<div class="staff-info">
                <div class="staff-name">${data.ac_staff_name || '-'}</div>
                <div class="staff-time">${acformattedDateTime}</div>
                <div class="staff-status">${ac_status}</div>
              </div>`;
    }

    
    // Disable all checkboxes
    allCheckboxes.forEach(checkbox => (checkbox.disabled = true));

    // Generate dynamic HTML content
    const html = `
      <div class="refund-view-container">
        <!-- Confirmation Header -->
        <div class="confirmation-header text-center mb-4">
          <div class="confirmation-icon bg-${statusColor}">
            <i class="fas ${statusIcon}"></i>
          </div>
          <h3 class="confirmation-title">Confirm Refund ${status}</h3>
          <p class="confirmation-message">Are you sure you want to mark this refund as <strong>${status}</strong>?</p>
          <input type="hidden" id="sts_change_type" name="sts_change_type" value="${type}"/>
          <input type="hidden" id="sts_change_id" name="sts_change_id" value="${data.sno}"/>
        </div>

        <div class="row g-4">
          <!-- Customer Details Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-user-circle me-2"></i>
                Customer Details
              </div>
              <div class="card-body">
                <div class="customer-main">
                  <div class="customer-avatar">
                      <i class="fas fa-user"></i>
                  </div>
                  <div class="customer-info">
                    <div class="customer-name">${data.cus_name}</div>
                    <div class="customer-id">${data.cus_customer_id}</div>
                  </div>
                </div>
                
                <div class="detail-item">
                  <div class="detail-label">
                    <i class="fas fa-calendar me-1"></i>
                    Created Date
                  </div>
                  <div class="detail-value">${formattedDate}</div>
                </div>
                
                <div class="detail-item">
                  <div class="detail-label">
                    <i class="fa-solid fa-cubes me-1"></i>
                    Total Products
                  </div>
                  <div class="detail-value">${products}</div>
                </div>
                
                <div class="detail-item">
                  <div class="detail-label">
                    <i class="fas fa-user-tie me-1"></i>
                    Sales Staff
                  </div>
                  <div class="detail-value">${data.sales_satff}</div>
                </div>
                
                
                
                <div class="detail-item">
                  <div class="detail-label">
                    <i class="fas fa-chart-line me-1"></i>
                    Payment Progress
                  </div>
                  <div class="detail-value">
                    <div class="progress-container">
                      <div class="progress-bar-wrapper">
                        <div class="progress-bar" style="width: ${pay}%">
                          <span class="progress-text">${pay}%</span>
                        </div>
                      </div>
                      <div class="progress-stats">${pay}% Completed</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Checklist Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-tasks me-2"></i>
                Checklist
                <span class="checklist-count">${checkedCount}/${totalCount}</span>
              </div>
              <div class="card-body">
                <div class="checklist-container">
                  ${checklistDoc.body.innerHTML}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row g-4 mt-2">
          <!-- Payment Details Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-money-bill-wave me-2"></i>
                Payment Details
              </div>
              <div class="card-body">
                <div class="payment-item">
                  <div class="payment-label">
                    <span>Paid Amount</span>
                    <small class="text-warning">Without GST</small>
                  </div>
                  <div class="payment-amount amount-paid">${data.currency_symbol}${Currecncy_format(data.paid_amount)}</div>
                </div>
                
                <div class="payment-item">
                  <div class="payment-label">Min. Deducted Amount</div>
                  <div class="payment-amount amount-deducted">${data.currency_symbol}${Currecncy_format(data.min_deducted_amount)}</div>
                </div>
                
                <div class="payment-item">
                  <div class="payment-label">Possible Eligible Amount</div>
                  <div class="payment-amount amount-eligible">${data.currency_symbol}${Currecncy_format(data.posible_eligible_amount)}</div>
                </div>
                
                <div class="payment-item highlight">
                  <div class="payment-label">Refund Amount</div>
                  <div class="payment-amount amount-refund">${data.currency_symbol}${Currecncy_format(data.refund_amount)}</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Approval Flow Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-users me-2"></i>
                Approval Flow
              </div>
              <div class="card-body">
                <div class="approval-flow">
                  <div class="approval-step">
                    <div class="step-icon cre">
                      <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="step-content">
                      <div class="step-title">Requester</div>
                      <div class="step-info">
                        <div class="staff-name">${data.created_staff_name}</div>
                        <div class="staff-time">${formattedDateTime}</div>
                        <span class="status-badge status-requested">Requested</span>
                      </div>
                    </div>
                  </div>
                  
                  <div class="approval-step">
                    <div class="step-icon authority">
                      <i class="fas fa-user-shield"></i>
                    </div>
                    <div class="step-content">
                      <div class="step-title">Authority</div>
                      <div class="step-info">${bh}</div>
                    </div>
                  </div>
                  
                  <div class="approval-step">
                    <div class="step-icon accounts">
                      <i class="fas fa-calculator"></i>
                    </div>
                    <div class="step-content">
                      <div class="step-title">Accounts Head</div>
                      <div class="step-info">${ac}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Reasons Section -->
        <div class="row g-4 mt-2">
          <div class="col-12">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-comment-dots me-2"></i>
                Reasons & Notes
              </div>
              <div class="card-body">
                <div class="reason-section">
                  <div class="reason-item">
                    <div class="reason-title">
                      <i class="fas fa-user-edit me-2"></i>
                      Requester Reason
                    </div>
                    <div class="reason-content">${data.drop_refund_reason}</div>
                  </div>
                  
                  ${type === 2 ? `
                  <div class="reason-item">
                    <div class="reason-title text-danger">
                      <i class="fas fa-times-circle me-2"></i>
                      Reject Reason
                      <span class="text-danger">*</span>
                    </div>
                    <div class="reason-input">
                      <textarea class="form-control rejection-textarea" rows="3" id="bhreject_reason" name="bhreject_reason" placeholder="Please provide the reason for rejecting this refund application..."></textarea>
                      <div class="text-danger mt-1" id="bhreject_reason_err"></div>
                    </div>
                  </div>` : ''}
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Action Buttons -->
      </div>
    `;
    $('#status_submit_btn').html(`Authority - Refund ${status}`);

    // Add CSS styles
    const styles = `
      <style>
        #statusModalContent .refund-view-container {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        #statusModalContent .confirmation-header {
         
          border-radius: 12px;
          color: white;
          margin-bottom: 2rem;
        }
        
        #statusModalContent .confirmation-icon {
          width: 80px;
          height: 80px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 1rem;
          font-size: 2rem;
        }
        
        #statusModalContent .confirmation-title {
          font-size: 1.75rem;
          font-weight: 700;
          margin-bottom: 0.5rem;
        }
        
        #statusModalContent .confirmation-message {
          font-size: 1.1rem;
          opacity: 0.9;
          margin-bottom: 0;
        }
        
        #statusModalContent .detail-card {
          background: white;
          border-radius: 12px;
          box-shadow: 0 2px 12px rgba(0,0,0,0.08);
          border: 1px solid #e9ecef;
          overflow: hidden;
          height: 100%;
        }
        
        #statusModalContent .card-header {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 1rem 1.5rem;
          font-weight: 600;
          display: flex;
          align-items: center;
          font-size: 1.1rem;
        }
        
        #statusModalContent .card-body {
          padding: 1.5rem;
        }
        
        #statusModalContent .customer-main {
          display: flex;
          align-items: center;
          margin-bottom: 1.5rem;
          padding-bottom: 1rem;
          border-bottom: 1px solid #e9ecef;
        }
        
        #statusModalContent .customer-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
            margin-right: 1rem;
          }
        
        #statusModalContent .customer-profile-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        
        #statusModalContent .customer-name {
          font-size: 1.25rem;
          font-weight: 700;
          color: #2c3e50;
          margin-bottom: 0.25rem;
        }
        
        #statusModalContent .customer-id {
          font-size: 0.9rem;
          color: #6c757d;
          font-weight: 500;
        }
        
        #statusModalContent .detail-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
          padding: 0.75rem;
          background: #f8f9fa;
          border-radius: 8px;
        }
        
        #statusModalContent .detail-label {
          flex: 1;
          font-weight: 600;
          color: #495057;
          display: flex;
          align-items: center;
        }
        
        #statusModalContent .detail-value {
          flex: 1;
          text-align: right;
          font-weight: 700;
          color: #2c3e50;
        }
        
        #statusModalContent .progress-container {
          width: 100%;
        }
        
        #statusModalContent .progress-bar-wrapper {
          width: 100%;
          height: 24px;
          background: #e9ecef;
          border-radius: 12px;
          overflow: hidden;
          margin-bottom: 0.5rem;
          border: 1px solid #dee2e6;
        }
        
        #statusModalContent .progress-bar {
          height: 100%;
          background: linear-gradient(90deg, #ffa500, #ffb732);
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          position: relative;
          transition: width 0.3s ease;
        }
        
        #statusModalContent .progress-bar.bg-info {
          background: linear-gradient(90deg, #17a2b8, #20c997) !important;
        }
        
        #statusModalContent .progress-text {
          color: #000;
          font-weight: 700;
          font-size: 0.8rem;
          text-shadow: 0 1px 1px rgba(255,255,255,0.5);
        }
        
        #statusModalContent .progress-stats {
          font-size: 0.8rem;
          color: #6c757d;
          text-align: center;
          font-weight: 500;
        }
        
        #statusModalContent .checklist-count {
          background: rgba(255,255,255,0.2);
          padding: 0.25rem 0.75rem;
          border-radius: 20px;
          font-size: 0.9rem;
          margin-left: auto;
        }
        
        #statusModalContent .checklist-container {
          max-height: 358px;
          overflow-y: auto;
          padding: 1rem;
          background: #f8f9fa;
          border-radius: 8px;
          border: 1px solid #e9ecef;
        }
        
        #statusModalContent .payment-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem;
          margin-bottom: 0.75rem;
          border-radius: 8px;
          background: #f8f9fa;
          border-left: 4px solid #dee2e6;
        }
        
        #statusModalContent .payment-item.highlight {
          background: #fff3cd;
          border-left-color: #ffc107;
          border: 2px solid #ffc107;
        }
        
        #statusModalContent .payment-label {
          flex: 1;
          font-weight: 600;
          color: #495057;
        }
        
        #statusModalContent .payment-label small {
          display: block;
          font-size: 0.75rem;
          font-weight: 500;
        }
        
        #statusModalContent .payment-amount {
          font-weight: 700;
          font-size: 1.1rem;
        }
        
        #statusModalContent .amount-paid { color: #28a745; }
        #statusModalContent .amount-deducted { color: #dc3545; }
        #statusModalContent .amount-eligible { color: #17a2b8; }
        #statusModalContent .amount-refund { color: #dc3545; font-size: 1.3rem !important; }
        
        #statusModalContent .approval-flow {
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }
        
        #statusModalContent .approval-step {
          display: flex;
          align-items: flex-start;
          gap: 1rem;
        }
        
        #statusModalContent .step-icon {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 1.2rem;
          flex-shrink: 0;
        }
        
        #statusModalContent .step-icon.cre { background: #6f42c1; }
        #statusModalContent .step-icon.authority { background: #e83e8c; }
        #statusModalContent .step-icon.accounts { background: #20c997; }
        
        #statusModalContent .step-content {
          flex: 1;
        }
        
        #statusModalContent .step-title {
          font-weight: 600;
          color: #495057;
          margin-bottom: 0.5rem;
        }
        
        #statusModalContent .staff-info {
          padding: 0.75rem;
          background: #f8f9fa;
          border-radius: 8px;
          border: 1px solid #e9ecef;
        }
        
        #statusModalContent .staff-name {
          font-weight: 700;
          color: #2c3e50;
          margin-bottom: 0.25rem;
        }
        
        #statusModalContent .staff-time {
          font-size: 0.8rem;
          color: #6c757d;
          margin-bottom: 0.5rem;
        }
        
        #statusModalContent .status-badge {
          padding: 0.35rem 0.75rem;
          border-radius: 20px;
          font-size: 0.8rem;
          font-weight: 600;
          display: inline-block;
        }
        
        #statusModalContent .status-accepted { background: #d4edda; color: #155724; }
        #statusModalContent .status-rejected { background: #f8d7da; color: #721c24; }
        #statusModalContent .status-pending { background: #fff3cd; color: #856404; }
        #statusModalContent .status-requested { background: #d1ecf1; color: #0c5460; }
        
        #statusModalContent .reason-section {
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }
        
        #statusModalContent .reason-item {
          padding: 1.25rem;
          border-radius: 8px;
          background: #f8f9fa;
          border-left: 4px solid #6f42c1;
        }
        
        #statusModalContent .reason-title {
          font-weight: 700;
          color: #495057;
          margin-bottom: 0.75rem;
          display: flex;
          align-items: center;
        }
        
        #statusModalContent .reason-content {
          color: #6c757d;
          line-height: 1.6;
          background: white;
          padding: 1rem;
          border-radius: 6px;
          border: 1px solid #e9ecef;
        }
        
        #statusModalContent .reason-input {
          margin-top: 0.5rem;
        }
        
        #statusModalContent .rejection-textarea {
          border: 2px solid #e9ecef;
          border-radius: 8px;
          padding: 1rem;
          font-size: 0.9rem;
          resize: vertical;
          min-height: 100px;
        }
        
        #statusModalContent .rejection-textarea:focus {
          border-color: #dc3545;
          box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25);
        }
        
        #statusModalContent .action-buttons {
          padding: 2rem;
          background: #f8f9fa;
          border-radius: 12px;
          border: 1px solid #e9ecef;
        }
        
        #statusModalContent .action-buttons .btn {
          padding: 0.75rem 2rem;
          font-weight: 600;
          border-radius: 8px;
          font-size: 1.1rem;
        }
        
        @media (max-width: 768px) {
          #statusModalContent .approval-step {
            flex-direction: column;
            text-align: center;
          }
          
          #statusModalContent .step-icon {
            align-self: center;
          }
          
          #statusModalContent .action-buttons .btn {
            width: 100%;
            margin-bottom: 1rem;
          }
        }
      </style>
    `;

    // Render the generated HTML into the modal or target container
    document.getElementById('statusModalContent').innerHTML = styles + html;
}
  function ac_status_change(type, data, pay, products) {
    console.log(data);
    // Determine the status (Accepted/Rejected)
    const status = type === 1 ? 'Accepted' : 'Rejected';
    const statusColor = type === 1 ? 'success' : 'danger';
    const statusIcon = type === 1 ? 'fa-check-circle' : 'fa-times-circle';

    if (type == 1) {
        var bh_status = '<span class="status-badge status-accepted">Accepted</span>';
    } else if (type == 2) {
        var bh_status = '<span class="status-badge status-rejected">Rejected</span>';
    } else {
        var bh_status = '<span class="status-badge status-pending">Waiting for Approval</span>';
    }

    var ac_type = data.ac_status;
    if (ac_type == 1) {
        var ac_status = '<span class="status-badge status-accepted">Accepted</span>';
    } else if (ac_type == 2) {
        var ac_status = '<span class="status-badge status-rejected">Rejected</span>';
    } else {
        var ac_status = '<span class="text-muted">-</span>';
    }

    // Calculate checked and total checklist items
    const parser = new DOMParser();
    const checklistDoc = parser.parseFromString(data.check_list, 'text/html');
    const allCheckboxes = checklistDoc.querySelectorAll('.checklist-checkbox');
    const checkedCount = checklistDoc.querySelectorAll('.checklist-checkbox:checked').length;
    const totalCount = allCheckboxes.length;
    const formattedDateTime = formatDateTime(data.created_at);
    const formattedDate = formatDate(data.created_at);
    const bhformattedDateTime = formatDateTime(data.bh_status_date);
    const acformattedDateTime = formatDateTime(data.ac_status_date);

    // Staff information templates
    var bh = `<div class="staff-info">
                <div class="text-muted fs-7">Not assigned</div>
              </div>`;
    if (data.bh_staff_name) {
        bh = `<div class="staff-info">
                <div class="staff-name">${data.bh_staff_name || '-'}</div>
                <div class="staff-time">${bhformattedDateTime}</div>
                <div class="staff-status">${bh_status}</div>
              </div>`;
    }

    var ac = `<div class="staff-info">
                <div class="text-muted fs-7">Not assigned</div>
              </div>`;
    if (data.ac_staff_name) {
        ac = `<div class="staff-info">
                <div class="staff-name">${data.ac_staff_name || '-'}</div>
                <div class="staff-time">${acformattedDateTime}</div>
                <div class="staff-status">${ac_status}</div>
              </div>`;
    }

    // Disable all checkboxes
    allCheckboxes.forEach(checkbox => (checkbox.disabled = true));

    // Generate dynamic HTML content
    const html = `
      <div class="refund-view-container">
        <!-- Confirmation Header -->
        <div class="confirmation-header text-center mb-4">
          <div class="confirmation-icon bg-${statusColor}">
            <i class="fas ${statusIcon}"></i>
          </div>
          <h3 class="confirmation-title">Confirm Refund ${status}</h3>
          <p class="confirmation-message">Are you sure you want to mark this refund as <strong>${status}</strong>?</p>
          <input type="hidden" id="sts_change_type" name="sts_change_type" value="${type}"/>
          <input type="hidden" id="sts_change_id" name="sts_change_id" value="${data.sno}"/>
        </div>

        <div class="row g-4">
          <!-- Customer Details Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-user-circle me-2"></i>
                Customer Details
              </div>
              <div class="card-body">
                <div class="customer-main">
                  <div class="customer-avatar">
                    <i class="fas fa-user"></i>
                  </div>
                  <div class="customer-info">
                    <div class="customer-name">${data.cus_name}</div>
                    <div class="customer-id">${data.cus_customer_id}</div>
                  </div>
                  </div>

                  <div class="detail-item">
                    <div class="detail-label">
                      <i class="fa-solid fa-cubes me-1"></i>
                      Products
                    </div>
                    <div class="detail-value">${products}</div>
                  </div>
                  
                  <div class="detail-item">
                    <div class="detail-label">
                      <i class="fas fa-user-tie me-1"></i>
                      Sales Staff
                    </div>
                    <div class="detail-value">${data.sales_satff}</div>
                  </div>

                <div class="detail-item">
                  <div class="detail-label">
                    <i class="fas fa-calendar me-1"></i>
                    Refund Created Date
                  </div>
                  <div class="detail-value">${formattedDate}</div>
                </div>                
                
                <div class="detail-item">
                  <div class="detail-label">
                    <i class="fas fa-chart-line me-1"></i>
                    Payment Progress
                  </div>
                  <div class="detail-value">
                    <div class="progress-container">
                      <div class="progress-bar-wrapper">
                        <div class="progress-bar" style="width: ${pay}%">
                          <span class="progress-text">${pay}%</span>
                        </div>
                      </div>
                      <div class="progress-stats">${pay}% Completed</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Checklist Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-tasks me-2"></i>
                Checklist
                <span class="checklist-count">${checkedCount}/${totalCount}</span>
              </div>
              <div class="card-body">
                <div class="checklist-container">
                  ${checklistDoc.body.innerHTML}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row g-4 mt-2">
          <!-- Payment Details Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-money-bill-wave me-2"></i>
                Payment Details
              </div>
              <div class="card-body">
                <div class="payment-item">
                  <div class="payment-label">
                    <span>Paid Amount</span>
                    <small class="text-warning">Without GST</small>
                  </div>
                  <div class="payment-amount amount-paid">${data.currency_symbol}${Currecncy_format(data.paid_amount)}</div>
                </div>
                
                <div class="payment-item">
                  <div class="payment-label">Min. Deducted Amount</div>
                  <div class="payment-amount amount-deducted">${data.currency_symbol}${Currecncy_format(data.min_deducted_amount)}</div>
                </div>
                
                <div class="payment-item">
                  <div class="payment-label">Possible Eligible Amount</div>
                  <div class="payment-amount amount-eligible">${data.currency_symbol}${Currecncy_format(data.posible_eligible_amount)}</div>
                </div>
                
                <div class="payment-item highlight">
                  <div class="payment-label">Refund Amount</div>
                  <div class="payment-amount amount-refund">${data.currency_symbol}${Currecncy_format(data.refund_amount)}</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Approval Flow Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-users me-2"></i>
                Approval Flow
              </div>
              <div class="card-body">
                <div class="approval-flow">
                  <div class="approval-step">
                    <div class="step-icon cre">
                      <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="step-content">
                      <div class="step-title">Requester</div>
                      <div class="step-info">
                        <div class="staff-name">${data.created_staff_name}</div>
                        <div class="staff-time">${formattedDateTime}</div>
                        <span class="status-badge status-requested">Requested</span>
                      </div>
                    </div>
                  </div>
                  
                  <div class="approval-step">
                    <div class="step-icon authority">
                      <i class="fas fa-user-shield"></i>
                    </div>
                    <div class="step-content">
                      <div class="step-title">Authority</div>
                      <div class="step-info">${bh}</div>
                    </div>
                  </div>
                  
                  <div class="approval-step">
                    <div class="step-icon accounts">
                      <i class="fas fa-calculator"></i>
                    </div>
                    <div class="step-content">
                      <div class="step-title">Accounts Head</div>
                      <div class="step-info">
                        <div class="staff-info">
                          <div class="text-muted fs-7">Pending your action</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Reasons Section -->
        <div class="row g-4 mt-2">
          <div class="col-12">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-comment-dots me-2"></i>
                Reasons & Notes
              </div>
              <div class="card-body">
                <div class="reason-section">
                  <div class="reason-item">
                    <div class="reason-title">
                      <i class="fas fa-user-edit me-2"></i>
                      Requester Reason
                    </div>
                    <div class="reason-content">${data.drop_refund_reason}</div>
                  </div>
                  
                  ${type === 2 ? `
                  <div class="reason-item">
                    <div class="reason-title text-danger">
                      <i class="fas fa-times-circle me-2"></i>
                      Reject Reason
                      <span class="text-danger">*</span>
                    </div>
                    <div class="reason-input">
                      <textarea class="form-control rejection-textarea" rows="3" id="bhreject_reason" name="bhreject_reason" placeholder="Please provide the reason for rejecting this refund application..."></textarea>
                      <div class="text-danger mt-1" id="bhreject_reason_err"></div>
                    </div>
                  </div>` : ''}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    // Add CSS styles
    const styles = `
      <style>
        #AC_statusModalContent .refund-view-container {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        #AC_statusModalContent .confirmation-header {
         
          border-radius: 12px;
          color: white;
          margin-bottom: 2rem;
        }
        
        #AC_statusModalContent .confirmation-icon {
          width: 80px;
          height: 80px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 1rem;
          font-size: 2rem;
        }
        
        #AC_statusModalContent .confirmation-title {
          font-size: 1.75rem;
          font-weight: 700;
          margin-bottom: 0.5rem;
        }
        
        #AC_statusModalContent .confirmation-message {
          font-size: 1.1rem;
          opacity: 0.9;
          margin-bottom: 0;
        }
        
        #AC_statusModalContent .detail-card {
          background: white;
          border-radius: 12px;
          box-shadow: 0 2px 12px rgba(0,0,0,0.08);
          border: 1px solid #e9ecef;
          overflow: hidden;
          height: 100%;
        }
        
        #AC_statusModalContent .card-header {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 1rem 1.5rem;
          font-weight: 600;
          display: flex;
          align-items: center;
          font-size: 1.1rem;
        }
        
        #AC_statusModalContent .card-body {
          padding: 1.5rem;
        }
        
        #AC_statusModalContent .customer-main {
          display: flex;
          align-items: center;
          margin-bottom: 1.5rem;
          padding-bottom: 1rem;
          border-bottom: 1px solid #e9ecef;
        }
        
        #AC_statusModalContent .customer-avatar {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 1.2rem;
          margin-right: 1rem;
        }
        
        #AC_statusModalContent .customer-name {
          font-size: 1.25rem;
          font-weight: 700;
          color: #2c3e50;
          margin-bottom: 0.25rem;
        }
        
        #AC_statusModalContent .customer-id {
          font-size: 0.9rem;
          color: #6c757d;
          font-weight: 500;
        }
        
        #AC_statusModalContent .detail-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
          padding: 0.75rem;
          background: #f8f9fa;
          border-radius: 8px;
        }
        
        #AC_statusModalContent .detail-label {
          flex: 1;
          font-weight: 600;
          color: #495057;
          display: flex;
          align-items: center;
        }
        
        #AC_statusModalContent .detail-value {
          flex: 1;
          text-align: right;
          font-weight: 700;
          color: #2c3e50;
        }
        
        #AC_statusModalContent .progress-container {
          width: 100%;
        }
        
        #AC_statusModalContent .progress-bar-wrapper {
          width: 100%;
          height: 24px;
          background: #e9ecef;
          border-radius: 12px;
          overflow: hidden;
          margin-bottom: 0.5rem;
          border: 1px solid #dee2e6;
        }
        
        #AC_statusModalContent .progress-bar {
          height: 100%;
          background: linear-gradient(90deg, #ffa500, #ffb732);
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          position: relative;
          transition: width 0.3s ease;
        }
        
        #AC_statusModalContent .progress-bar.bg-info {
          background: linear-gradient(90deg, #17a2b8, #20c997) !important;
        }
        
        #AC_statusModalContent .progress-text {
          color: #000;
          font-weight: 700;
          font-size: 0.8rem;
          text-shadow: 0 1px 1px rgba(255,255,255,0.5);
        }
        
        #AC_statusModalContent .progress-stats {
          font-size: 0.8rem;
          color: #6c757d;
          text-align: center;
          font-weight: 500;
        }
        
        #AC_statusModalContent .checklist-count {
          background: rgba(255,255,255,0.2);
          padding: 0.25rem 0.75rem;
          border-radius: 20px;
          font-size: 0.9rem;
          margin-left: auto;
        }
        
        #AC_statusModalContent .checklist-container {
          max-height: 358px;
          overflow-y: auto;
          padding: 1rem;
          background: #f8f9fa;
          border-radius: 8px;
          border: 1px solid #e9ecef;
        }
        
        #AC_statusModalContent .payment-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem;
          margin-bottom: 0.75rem;
          border-radius: 8px;
          background: #f8f9fa;
          border-left: 4px solid #dee2e6;
        }
        
        #AC_statusModalContent .payment-item.highlight {
          background: #fff3cd;
          border-left-color: #ffc107;
          border: 2px solid #ffc107;
        }
        
        #AC_statusModalContent .payment-label {
          flex: 1;
          font-weight: 600;
          color: #495057;
        }
        
        #AC_statusModalContent .payment-label small {
          display: block;
          font-size: 0.75rem;
          font-weight: 500;
        }
        
        #AC_statusModalContent .payment-amount {
          font-weight: 700;
          font-size: 1.1rem;
        }
        
        #AC_statusModalContent .amount-paid { color: #28a745; }
        #AC_statusModalContent .amount-deducted { color: #dc3545; }
        #AC_statusModalContent .amount-eligible { color: #17a2b8; }
        #AC_statusModalContent .amount-refund { color: #dc3545; font-size: 1.3rem !important; }
        
        #AC_statusModalContent .approval-flow {
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }
        
        #AC_statusModalContent .approval-step {
          display: flex;
          align-items: flex-start;
          gap: 1rem;
        }
        
        #AC_statusModalContent .step-icon {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 1.2rem;
          flex-shrink: 0;
        }
        
        #AC_statusModalContent .step-icon.cre { background: #6f42c1; }
        #AC_statusModalContent .step-icon.authority { background: #e83e8c; }
        #AC_statusModalContent .step-icon.accounts { background: #20c997; }
        
        #AC_statusModalContent .step-content {
          flex: 1;
        }
        
        #AC_statusModalContent .step-title {
          font-weight: 600;
          color: #495057;
          margin-bottom: 0.5rem;
        }
        
        #AC_statusModalContent .staff-info {
          padding: 0.75rem;
          background: #f8f9fa;
          border-radius: 8px;
          border: 1px solid #e9ecef;
        }
        
        #AC_statusModalContent .staff-name {
          font-weight: 700;
          color: #2c3e50;
          margin-bottom: 0.25rem;
        }
        
        #AC_statusModalContent .staff-time {
          font-size: 0.8rem;
          color: #6c757d;
          margin-bottom: 0.5rem;
        }
        
        #AC_statusModalContent .status-badge {
          padding: 0.35rem 0.75rem;
          border-radius: 20px;
          font-size: 0.8rem;
          font-weight: 600;
          display: inline-block;
        }
        
        #AC_statusModalContent .status-accepted { background: #d4edda; color: #155724; }
        #AC_statusModalContent .status-rejected { background: #f8d7da; color: #721c24; }
        #AC_statusModalContent .status-pending { background: #fff3cd; color: #856404; }
        #AC_statusModalContent .status-requested { background: #d1ecf1; color: #0c5460; }
        
        #AC_statusModalContent .reason-section {
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }
        
        #AC_statusModalContent .reason-item {
          padding: 1.25rem;
          border-radius: 8px;
          background: #f8f9fa;
          border-left: 4px solid #6f42c1;
        }
        
        #AC_statusModalContent .reason-title {
          font-weight: 700;
          color: #495057;
          margin-bottom: 0.75rem;
          display: flex;
          align-items: center;
        }
        
        #AC_statusModalContent .reason-content {
          color: #6c757d;
          line-height: 1.6;
          background: white;
          padding: 1rem;
          border-radius: 6px;
          border: 1px solid #e9ecef;
        }
        
        #AC_statusModalContent .reason-input {
          margin-top: 0.5rem;
        }
        
        #AC_statusModalContent .rejection-textarea {
          border: 2px solid #e9ecef;
          border-radius: 8px;
          padding: 1rem;
          font-size: 0.9rem;
          resize: vertical;
          min-height: 100px;
        }
        
        #AC_statusModalContent .rejection-textarea:focus {
          border-color: #dc3545;
          box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25);
        }
        
        #AC_statusModalContent .action-buttons {
          padding: 2rem;
          background: #f8f9fa;
          border-radius: 12px;
          border: 1px solid #e9ecef;
        }
        
        #AC_statusModalContent .action-buttons .btn {
          padding: 0.75rem 2rem;
          font-weight: 600;
          border-radius: 8px;
          font-size: 1.1rem;
        }
        
        @media (max-width: 768px) {
          #AC_statusModalContent .approval-step {
            flex-direction: column;
            text-align: center;
          }
          
          #AC_statusModalContent .step-icon {
            align-self: center;
          }
          
          #AC_statusModalContent .action-buttons .btn {
            width: 100%;
            margin-bottom: 1rem;
          }
        }
      </style>
    `;

    // Render the generated HTML into the modal or target container
    document.getElementById('AC_statusModalContent').innerHTML = styles + html;
}

  function ac_status_change_refund(type, data, pay) {
    console.log(data);
    // Determine the status (Accepted/Rejected)
    const status = type === 1 ? 'Accepted' : 'Rejected';
    const statusColor = type === 1 ? 'success' : 'danger';
    const statusIcon = type === 1 ? 'fa-check-circle' : 'fa-times-circle';

    if (type == 1) {
        var bh_status = '<span class="status-badge status-accepted">Accepted</span>';
    } else if (type == 2) {
        var bh_status = '<span class="status-badge status-rejected">Rejected</span>';
    } else {
        var bh_status = '<span class="status-badge status-pending">Waiting for Approval</span>';
    }

    var ac_type = data.ac_status;
    if (ac_type == 1) {
        var ac_status = '<span class="status-badge status-accepted">Accepted</span>';
    } else if (ac_type == 2) {
        var ac_status = '<span class="status-badge status-rejected">Rejected</span>';
    } else {
        var ac_status = '<span class="text-muted">-</span>';
    }

    // Calculate checked and total checklist items
    const parser = new DOMParser();
    const checklistDoc = parser.parseFromString(data.check_list, 'text/html');
    const allCheckboxes = checklistDoc.querySelectorAll('.checklist-checkbox');
    const checkedCount = checklistDoc.querySelectorAll('.checklist-checkbox:checked').length;
    const totalCount = allCheckboxes.length;
    const formattedDateTime = formatDateTime(data.created_at);
    const formattedDate = formatDate(data.created_at);
    const bhformattedDateTime = formatDateTime(data.bh_status_date);
    const acformattedDateTime = formatDateTime(data.ac_status_date);

    // Staff information templates
    var bh = `<div class="staff-info">
                <div class="text-muted fs-7">Not assigned</div>
              </div>`;
    if (data.bh_staff_name) {
        bh = `<div class="staff-info">
                <div class="staff-name">${data.bh_staff_name || '-'}</div>
                <div class="staff-time">${bhformattedDateTime}</div>
                <div class="staff-status">${bh_status}</div>
              </div>`;
    }

    var ac = `<div class="staff-info">
                <div class="text-muted fs-7">Not assigned</div>
              </div>`;
    if (data.ac_staff_name) {
        ac = `<div class="staff-info">
                <div class="staff-name">${data.ac_staff_name || '-'}</div>
                <div class="staff-time">${acformattedDateTime}</div>
                <div class="staff-status">${ac_status}</div>
              </div>`;
    }

    // Disable all checkboxes
    allCheckboxes.forEach(checkbox => (checkbox.disabled = true));

    // Generate dynamic HTML content
    const html = `
      <div class="refund-view-container">
        <!-- Confirmation Header -->
        <div class="confirmation-header text-center mb-4">
          <div class="confirmation-icon bg-success">
            <i class="fas fa-money-bill-wave"></i>
          </div>
          <h3 class="confirmation-title">Confirm Amount Refunded</h3>
          <p class="confirmation-message">Are you sure you want to mark this amount as <strong>Refunded</strong>?</p>
          <input type="hidden" id="sts_change_type" name="sts_change_type" value="${type}"/>
          <input type="hidden" id="sts_change_id" name="sts_change_id" value="${data.sno}"/>
        </div>

        <div class="row g-4">
          <!-- Customer Details Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-user-circle me-2"></i>
                Customer Details
              </div>
              <div class="card-body">
                <div class="customer-main">
                  <div class="customer-avatar">
                    <i class="fas fa-user"></i>
                  </div>
                  <div class="customer-info">
                    <div class="customer-name">${data.cus_name}</div>
                    <div class="customer-id">${data.cus_customer_id}</div>
                  </div>
                </div>
                
                <div class="detail-item">
                  <div class="detail-label">
                    <i class="fas fa-calendar me-1"></i>
                    Created Date
                  </div>
                  <div class="detail-value">${formattedDate}</div>
                </div>
                
                <div class="detail-item">
                  <div class="detail-label">
                    <i class="fas fa-chart-line me-1"></i>
                    Payment Progress
                  </div>
                  <div class="detail-value">
                    <div class="progress-container">
                      <div class="progress-bar-wrapper">
                        <div class="progress-bar" style="width: ${pay}%">
                          <span class="progress-text">${pay}%</span>
                        </div>
                      </div>
                      <div class="progress-stats">${pay}% Completed</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Checklist Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-tasks me-2"></i>
                Checklist
                <span class="checklist-count">${checkedCount}/${totalCount}</span>
              </div>
              <div class="card-body">
                <div class="checklist-container">
                  ${checklistDoc.body.innerHTML}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row g-4 mt-2">
          <!-- Payment Details Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-money-bill-wave me-2"></i>
                Payment Details
              </div>
              <div class="card-body">
                <div class="payment-item">
                  <div class="payment-label">
                    <span>Paid Amount</span>
                    <small class="text-warning">Without GST</small>
                  </div>
                  <div class="payment-amount amount-paid">${data.currency_symbol}${Currecncy_format(data.paid_amount)}</div>
                </div>
                
                <div class="payment-item">
                  <div class="payment-label">Min. Deducted Amount</div>
                  <div class="payment-amount amount-deducted">${data.currency_symbol}${Currecncy_format(data.min_deducted_amount)}</div>
                </div>
                
                <div class="payment-item">
                  <div class="payment-label">Possible Eligible Amount</div>
                  <div class="payment-amount amount-eligible">${data.currency_symbol}${Currecncy_format(data.posible_eligible_amount)}</div>
                </div>
                
                <div class="payment-item highlight">
                  <div class="payment-label">Refund Amount</div>
                  <div class="payment-amount amount-refund">${data.currency_symbol}${Currecncy_format(data.refund_amount)}</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Approval Flow Card -->
          <div class="col-lg-6">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-users me-2"></i>
                Approval Flow
              </div>
              <div class="card-body">
                <div class="approval-flow">
                  <div class="approval-step">
                    <div class="step-icon cre">
                      <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="step-content">
                      <div class="step-title">Requester</div>
                      <div class="step-info">
                        <div class="staff-name">${data.created_staff_name}</div>
                        <div class="staff-time">${formattedDateTime}</div>
                        <span class="status-badge status-requested">Requested</span>
                      </div>
                    </div>
                  </div>
                  
                  <div class="approval-step">
                    <div class="step-icon authority">
                      <i class="fas fa-user-shield"></i>
                    </div>
                    <div class="step-content">
                      <div class="step-title">Authority</div>
                      <div class="step-info">${bh}</div>
                    </div>
                  </div>
                  
                  <div class="approval-step">
                    <div class="step-icon accounts">
                      <i class="fas fa-calculator"></i>
                    </div>
                    <div class="step-content">
                      <div class="step-title">Accounts Head</div>
                      <div class="step-info">${ac}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Reasons Section -->
        <div class="row g-4 mt-2">
          <div class="col-12">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-comment-dots me-2"></i>
                Reasons & Notes
              </div>
              <div class="card-body">
                <div class="reason-section">
                  <div class="reason-item">
                    <div class="reason-title">
                      <i class="fas fa-user-edit me-2"></i>
                      Requester Reason
                    </div>
                    <div class="reason-content">${data.drop_refund_reason}</div>
                  </div>
                  
                  ${type === 2 ? `
                  <div class="reason-item">
                    <div class="reason-title text-danger">
                      <i class="fas fa-times-circle me-2"></i>
                      Authority Reject Reason
                    </div>
                    <div class="reason-content">${data.bh_reject_reason}</div>
                  </div>` : ''}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row g-4 mt-2">
          <div class="col-12">
            <div class="detail-card">
              <div class="card-header">
                <i class="fas fa-comment-dots me-2"></i>
                Refunded &amp; Details
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-lg-4">
                    <label class="text-dark fs-6 fw-semibold">Refunded Date<span class="text-danger">*</span></label>
                    <input type="text" id="refunded_date" name="refunded_date" placeholder="Select Date" class="form-control common_date_class comp_interview_date" value="{{ date('d-M-Y') }}" readonly />
                  </div>
                  <div class="col-lg-4">
                    <label class="text-dark fs-6 fw-semibold">Payment Mode<span class="text-danger">*</span></label>
                    <select id="pay_mode_list" name="pay_mode_list" class="select form-select" data-dropdown-parent="#kt_modal_refund_acc">
                        <option value="">Select</option>
                        @foreach ($pay_mode_list as $p_list)
                          <option value="{{ $p_list->sno }}">{{ $p_list->paymentmode_name }}</option>
                        @endforeach
                    </select>
                    <div class="text-danger" id="pay_mode_list_err"></div>
                  </div>
                  <div class="col-lg-4">
                    <label class="text-dark fs-6 fw-semibold">Description<span class="text-danger">*</span></label>
                    <textarea class="form-control" rows="2" id="refund_description" name="refund_description" placeholder="Enter Description"></textarea>
                    <div class="text-danger" id="refund_description_err"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    `;

    // Add CSS styles
    const styles = `
      <style>
        #AC_refund_statusModalContent .refund-view-container {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        #AC_refund_statusModalContent .confirmation-header {
          
          border-radius: 12px;
          color: white;
          margin-bottom: 2rem;
        }
        
        #AC_refund_statusModalContent .confirmation-icon {
          width: 80px;
          height: 80px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 1rem;
          font-size: 2rem;
          background: rgba(255,255,255,0.2);
        }
        
        #AC_refund_statusModalContent .confirmation-title {
          font-size: 1.75rem;
          font-weight: 700;
          margin-bottom: 0.5rem;
        }
        
        #AC_refund_statusModalContent .confirmation-message {
          font-size: 1.1rem;
          opacity: 0.9;
          margin-bottom: 0;
        }
        
        #AC_refund_statusModalContent .detail-card {
          background: white;
          border-radius: 12px;
          box-shadow: 0 2px 12px rgba(0,0,0,0.08);
          border: 1px solid #e9ecef;
          overflow: hidden;
          height: 100%;
        }
        
        #AC_refund_statusModalContent .card-header {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 1rem 1.5rem;
          font-weight: 600;
          display: flex;
          align-items: center;
          font-size: 1.1rem;
        }
        
        #AC_refund_statusModalContent .card-body {
          padding: 1.5rem;
        }
        
        #AC_refund_statusModalContent .customer-main {
          display: flex;
          align-items: center;
          margin-bottom: 1.5rem;
          padding-bottom: 1rem;
          border-bottom: 1px solid #e9ecef;
        }
        
        #AC_refund_statusModalContent .customer-avatar {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 1.2rem;
          margin-right: 1rem;
        }
        
        #AC_refund_statusModalContent .customer-name {
          font-size: 1.25rem;
          font-weight: 700;
          color: #2c3e50;
          margin-bottom: 0.25rem;
        }
        
        #AC_refund_statusModalContent .customer-id {
          font-size: 0.9rem;
          color: #6c757d;
          font-weight: 500;
        }
        
        #AC_refund_statusModalContent .detail-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
          padding: 0.75rem;
          background: #f8f9fa;
          border-radius: 8px;
        }
        
        #AC_refund_statusModalContent .detail-label {
          flex: 1;
          font-weight: 600;
          color: #495057;
          display: flex;
          align-items: center;
        }
        
        #AC_refund_statusModalContent .detail-value {
          flex: 1;
          text-align: right;
          font-weight: 700;
          color: #2c3e50;
        }
        
        #AC_refund_statusModalContent .progress-container {
          width: 100%;
        }
        
        #AC_refund_statusModalContent .progress-bar-wrapper {
          width: 100%;
          height: 24px;
          background: #e9ecef;
          border-radius: 12px;
          overflow: hidden;
          margin-bottom: 0.5rem;
          border: 1px solid #dee2e6;
        }
        
        #AC_refund_statusModalContent .progress-bar {
          height: 100%;
          background: linear-gradient(90deg, #ffa500, #ffb732);
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          position: relative;
          transition: width 0.3s ease;
        }
        
        #AC_refund_statusModalContent .progress-text {
          color: #000;
          font-weight: 700;
          font-size: 0.8rem;
          text-shadow: 0 1px 1px rgba(255,255,255,0.5);
        }
        
        #AC_refund_statusModalContent .progress-stats {
          font-size: 0.8rem;
          color: #6c757d;
          text-align: center;
          font-weight: 500;
        }
        
        #AC_refund_statusModalContent .checklist-count {
          background: rgba(255,255,255,0.2);
          padding: 0.25rem 0.75rem;
          border-radius: 20px;
          font-size: 0.9rem;
          margin-left: auto;
        }
        
        #AC_refund_statusModalContent .checklist-container {
          max-height: 300px;
          overflow-y: auto;
          padding: 1rem;
          background: #f8f9fa;
          border-radius: 8px;
          border: 1px solid #e9ecef;
        }
        
        #AC_refund_statusModalContent .payment-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem;
          margin-bottom: 0.75rem;
          border-radius: 8px;
          background: #f8f9fa;
          border-left: 4px solid #dee2e6;
        }
        
        #AC_refund_statusModalContent .payment-item.highlight {
          background: #fff3cd;
          border-left-color: #ffc107;
          border: 2px solid #ffc107;
        }
        
        #AC_refund_statusModalContent .payment-label {
          flex: 1;
          font-weight: 600;
          color: #495057;
        }
        
        #AC_refund_statusModalContent .payment-label small {
          display: block;
          font-size: 0.75rem;
          font-weight: 500;
        }
        
        #AC_refund_statusModalContent .payment-amount {
          font-weight: 700;
          font-size: 1.1rem;
        }
        
        #AC_refund_statusModalContent .amount-paid { color: #28a745; }
        #AC_refund_statusModalContent .amount-deducted { color: #dc3545; }
        #AC_refund_statusModalContent .amount-eligible { color: #17a2b8; }
        #AC_refund_statusModalContent .amount-refund { color: #dc3545; font-size: 1.3rem !important; }
        
        #AC_refund_statusModalContent .approval-flow {
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }
        
        #AC_refund_statusModalContent .approval-step {
          display: flex;
          align-items: flex-start;
          gap: 1rem;
        }
        
        #AC_refund_statusModalContent .step-icon {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 1.2rem;
          flex-shrink: 0;
        }
        
        #AC_refund_statusModalContent .step-icon.cre { background: #6f42c1; }
        #AC_refund_statusModalContent .step-icon.authority { background: #e83e8c; }
        #AC_refund_statusModalContent .step-icon.accounts { background: #20c997; }
        
        #AC_refund_statusModalContent .step-content {
          flex: 1;
        }
        
        #AC_refund_statusModalContent .step-title {
          font-weight: 600;
          color: #495057;
          margin-bottom: 0.5rem;
        }
        
        #AC_refund_statusModalContent .staff-info {
          padding: 0.75rem;
          background: #f8f9fa;
          border-radius: 8px;
          border: 1px solid #e9ecef;
        }
        
        #AC_refund_statusModalContent .staff-name {
          font-weight: 700;
          color: #2c3e50;
          margin-bottom: 0.25rem;
        }
        
        #AC_refund_statusModalContent .staff-time {
          font-size: 0.8rem;
          color: #6c757d;
          margin-bottom: 0.5rem;
        }
        
        #AC_refund_statusModalContent .status-badge {
          padding: 0.35rem 0.75rem;
          border-radius: 20px;
          font-size: 0.8rem;
          font-weight: 600;
          display: inline-block;
        }
        
        #AC_refund_statusModalContent .status-accepted { background: #d4edda; color: #155724; }
        #AC_refund_statusModalContent .status-rejected { background: #f8d7da; color: #721c24; }
        #AC_refund_statusModalContent .status-pending { background: #fff3cd; color: #856404; }
        #AC_refund_statusModalContent .status-requested { background: #d1ecf1; color: #0c5460; }
        
        #AC_refund_statusModalContent .reason-section {
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }
        
        #AC_refund_statusModalContent .reason-item {
          padding: 1.25rem;
          border-radius: 8px;
          background: #f8f9fa;
          border-left: 4px solid #6f42c1;
        }
        
        #AC_refund_statusModalContent .reason-title {
          font-weight: 700;
          color: #495057;
          margin-bottom: 0.75rem;
          display: flex;
          align-items: center;
        }
        
        #AC_refund_statusModalContent .reason-content {
          color: #6c757d;
          line-height: 1.6;
          background: white;
          padding: 1rem;
          border-radius: 6px;
          border: 1px solid #e9ecef;
        }
        
        #AC_refund_statusModalContent .action-buttons {
          padding: 2rem;
          background: #f8f9fa;
          border-radius: 12px;
          border: 1px solid #e9ecef;
        }
        
        #AC_refund_statusModalContent .action-buttons .btn {
          padding: 0.75rem 2rem;
          font-weight: 600;
          border-radius: 8px;
          font-size: 1.1rem;
        }
        
        @media (max-width: 768px) {
          #AC_refund_statusModalContent .approval-step {
            flex-direction: column;
            text-align: center;
          }
          
          #AC_refund_statusModalContent .step-icon {
            align-self: center;
          }
          
          #AC_refund_statusModalContent .action-buttons .btn {
            width: 100%;
            margin-bottom: 1rem;
          }
        }
      </style>
    `;

    // Render the generated HTML into the modal or target container
    document.getElementById('AC_refund_statusModalContent').innerHTML = styles + html;
}



  function view_drop_refund(data,pay) {
    // Determine the status (Accepted/Rejected)
    var type = data.bh_status;
    if(type ==1){
      var bh_status='<label class="badge bg-success text-white fs-8 fw-bold">Accepted</label>';
    }else if(type == 2){
      var bh_status='<label class="badge bg-danger text-white fs-8 fw-bold">Rejected</label>';
    }else{
      var bh_status='<label class="badge bg-warning text-black fs-8 fw-bold">Waiting for Approval</label>';
    }
    var ac_type = data.ac_status;
    if(ac_type ==1){
      var ac_status='<label class="badge bg-success text-white fs-8 fw-bold">Accepted</label>';
    }else if(type == 2){
      var ac_status='<label class="badge bg-danger text-white fs-8 fw-bold">Rejected</label>';
    }else{
      var ac_status='-';
    }
    // Calculate checked and total checklist items
    const parser = new DOMParser();
    const checklistDoc = parser.parseFromString(data.check_list, 'text/html');
    const allCheckboxes = checklistDoc.querySelectorAll('.checklist-checkbox');
    const checkedCount = checklistDoc.querySelectorAll('.checklist-checkbox:checked').length;
    const totalCount = allCheckboxes.length;
    const formattedDateTime = formatDateTime(data.created_at);
    const formattedDate = formatDate(data.created_at);
    const bhformattedDateTime = formatDateTime(data.bh_status_date);
    const acformattedDateTime = formatDateTime(data.ac_status_date);
    var bh=`-`;
    if(data.bh_staff_name){
       var bh= `<label class="text-black fs-6 fw-semibold">${data.bh_staff_name||'-'}</label>
              <div class="d-block fs-8">
                 <label class="fw-bold fs-8 text-dark">[ ${bhformattedDateTime} ]</label>
              </div>
              <div class="d-block fs-8">
                  ${bh_status}
                </div>`;
    }
    var ac=`-`;
    if(data.ac_staff_name){
       var ac= `<label class="text-black fs-6 fw-semibold">${data.ac_staff_name||'-'}</label>
              <div class="d-block fs-8">
                 <label class="fw-bold fs-8 text-dark">[ ${acformattedDateTime} ]</label>
              </div>
              <div class="d-block fs-8">
                  ${ac_status}
                </div>`;
    }

    // Disable all checkboxes
    allCheckboxes.forEach(checkbox => (checkbox.disabled = true));

    // Generate dynamic HTML content
    const html = `
      <div class="mb-4 text-center">
        <h3 class="text-center mb-4 text-black">
          <label>Refund View </label>
        </h3>
      </div>

      <div class="row mb-2">
        <div class="col-lg-6">
          <div class="text-black text-center mb-3 fs-4 fw-semibold"><u>Customer Details</u></div>
          <div class="d-flex align-items-center px-1 mb-2">
            <div class="mb-0 align-items-center">
              <label class="text-black fs-6 fw-bold">${data.cus_name}</label>
              <div class="d-block text-dark fw-bold fs-7" title="Customer ID">${data.cus_customer_id}</div>
            </div>
          </div>

          <div class="row mb-2">
            <label class="col-5 text-dark fs-6 fw-semibold">Created Date</label>
            <label class="col-1 text-dark fs-6 fw-semibold">:</label>
            <label class="col-6 text-black fs-6 fw-bold">
              ${formattedDate}
            </label>
          </div>

          <div class="row mb-2">
            <label class="col-5 text-dark fs-6 fw-semibold">Sales Staff</label>
            <label class="col-1 text-dark fs-6 fw-semibold">:</label>
            <label class="col-6 text-black fs-6 fw-bold">
             ${data.sales_satff}
            </label>
          </div>

          <div class="row mb-5">
            <label class="col-5 text-dark fs-6 fw-semibold">Payment (%)</label>
            <label class="col-1 text-dark fs-6 fw-semibold">:</label>
            <div class="col-6">
              <div class="progress rounded h-20px w-100 border border-dark shadow-lg">
                <div class="progress-bar bg-info progress-bar-striped progress-bar-animated"
                     style="width: ${pay}%; background-color: #FFA500 !important;" aria-valuenow="${pay}"
                     aria-valuemin="0" aria-valuemax="100">
                  <span class="text-black fw-bold fs-7">${pay}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="text-black mb-3 fs-4 fw-semibold text-center">
            <label><u>Checklist</u></label> -
            <label class="badge bg-label-warning text-black fw-semibold fs-6">
              ${checkedCount} / ${totalCount}
            </label>
          </div>
          <div class="scroll-y max-h-225px min-h-225px py-2">
            ${checklistDoc.body.innerHTML}
          </div>
        </div>
        <hr class="my-2 text-dark">
      </div>

      <div class="row mb-2">
        <div class="col-lg-6">
            <div class="text-black text-center mb-3 fs-4 fw-semibold"><u>Payment Details</u></div>
            <div class="row mb-2">
              <div class="col-5 text-dark fs-6 fw-semibold">
                <div class="fs-6 fw-semibold">Paid Amount
                  <div class="d-block fs-8">
                    <label class="fw-bold fs-8 text-danger">[Without GST]</label>
                  </div>
                </div>
              </div>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <div class="col-6 text-black fs-6 fw-bold">
                <label class="badge bg-label-success text-dark fs-6 fw-bold">&#8377; ${Currecncy_format(data.paid_amount)}</label>
              </div>
            </div>
            <div class="row mb-2">
              <div class="col-5 text-dark fs-6 fw-semibold">
                <div class="fs-6 fw-semibold">Min.Deducted Amount</div>
              </div>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <div class="col-6 text-black fs-6 fw-bold">
                <label class="badge bg-label-danger fs-6 fw-bold">&#8377; ${Currecncy_format(data.min_deducted_amount)}</label>
              </div>
            </div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Possible Eligible Amount</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <div class="col-6 text-black fs-6 fw-bold">
                <label class="badge bg-info fs-6 fw-bold">&#8377; ${Currecncy_format(data.posible_eligible_amount)}</label>
              </div>
            </div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Refund Amount</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <div class="col-6 text-black fs-6 fw-bold">
                <label class="badge bg-danger fs-6 fw-bold">&#8377; ${Currecncy_format(data.refund_amount)}</label>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="text-black text-center mb-3 fs-4 fw-semibold"><u>Attended By</u></div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Requester</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <div class="col-6 text-black fs-6 fw-bold">
                <label class="text-black fs-6 fw-semibold">${data.created_staff_name}</label>
                <div class="d-block fs-8">
                  <label class="fw-bold fs-8 text-dark">[ ${formattedDateTime} ]</label>
                </div>
                <div class="d-block fs-8">
                  <label class="badge bg-warning text-black fs-8 fw-bold">Requested</label>
                </div>
              </div>
            </div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Authority</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <div class="col-6 text-black fs-6 fw-bold">${bh}</div>
            </div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">A/c (Accounts Head)</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <div class="col-6 text-black fs-6 fw-bold">${ac}</div>
            </div>
          </div>
        <hr class="my-2 text-dark">
      </div>

      <div class="col-lg-12">
        <div class="text-black mt-1 mb-2 fs-5 fw-semibold">Requester - Reason</div>
        <div class="row mb-2">
          <label class="col-12 text-danger fs-6 fw-bold text-justify">
            &emsp;&emsp;${data.drop_refund_reason}
          </label>
        </div>
      </div>

      ${type === 2 ? `
        <div class="col-lg-12">
          <div class="text-black mt-1 mb-2 fs-5 fw-semibold">Authority - Reject Reason</div>
          <label class="col-12 text-danger fs-6 fw-bold text-justify">
          &emsp;&emsp;${data.bh_reject_reason}
          </label>
        </div>` : ''}

      ${data.ac_status ===2  ? `
      <hr class="my-2 text-dark">
      <div class="row">
        <label class="col-lg-12 text-black text-center mb-3 fs-4 fw-semibold"><u>Refunded Details</u></label>
        <div class="col-lg-4">
          <label class="text-dark fs-6 fw-semibold"><u>Refunded Date</u></label>
          <div class="d-block mt-1">
          <label class="text-black fs-6 fw-semibold">${formatDate(data.refunded_date)}</label>
          </div>
        </div>
        <div class="col-lg-4">
          <label class="text-dark fs-6 fw-semibold"><u>Payment Mode</u></label>
          <div class="d-block mt-1">
            <label class="text-black fs-6 fw-semibold">${data.paymentmode_name}</label>
          </div>
        </div>
        <div class="col-lg-4">
          <label class="text-dark fs-6 fw-semibold"><u>Refunded Description</u></label>
          <div class="d-block mt-1">
            <label class="text-danger fs-6 fw-bold text-justify">
            &emsp;&emsp;${data.refunded_reason}
            </label>
          </div>
        </div>
      </div>` : ''}
    `;


    // Render the generated HTML into the modal or target container
    document.getElementById('view_drop_refundContent').innerHTML = html;
  }


  function view_drop_refund(data, pay) {

    
    console.log('DATaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', data);
      // Determine the status (Accepted/Rejected)
      var type = data.bh_status;
      if (type == 1) {
          var bh_status = '<span class="status-badge status-accepted">Accepted</span>';
      } else if (type == 2) {
          var bh_status = '<span class="status-badge status-rejected">Rejected</span>';
      } else {
          var bh_status = '<span class="status-badge status-pending">Waiting for Approval</span>';
      }
      
      var ac_type = data.ac_status;
      if (ac_type == 1) {
          var ac_status = '<span class="status-badge status-accepted">Accepted</span>';
      } else if (ac_type == 2) {
          var ac_status = '<span class="status-badge status-rejected">Rejected</span>';
      } else {
          var ac_status = '<span class="text-muted">-</span>';
      }

      // Calculate checked and total checklist items
      const parser = new DOMParser();
      const checklistDoc = parser.parseFromString(data.check_list, 'text/html');
      const allCheckboxes = checklistDoc.querySelectorAll('.checklist-checkbox');
      const checkedCount = checklistDoc.querySelectorAll('.checklist-checkbox:checked').length;
      const totalCount = allCheckboxes.length;
      const formattedDateTime = formatDateTime(data.created_at);
      const formattedDate = formatDate(data.created_at);
      const bhformattedDateTime = formatDateTime(data.bh_status_date);
      const acformattedDateTime = formatDateTime(data.ac_status_date);
      
      // Disable all checkboxes
      allCheckboxes.forEach(checkbox => (checkbox.disabled = true));

      // Staff information templates
      var bh = `<div class="staff-info">
                  <div class="text-muted fs-7">Not assigned</div>
                </div>`;
      if (data.bh_staff_name) {
          bh = `<div class="staff-info">
                  <div class="staff-name">${data.bh_staff_name || '-'}</div>
                  <div class="staff-time">${bhformattedDateTime}</div>
                  <div class="staff-status">${bh_status}</div>
                </div>`;
      }

      var ac = `<div class="staff-info">
                  <div class="text-muted fs-7">Not assigned</div>
                </div>`;
      if (data.ac_staff_name) {
          ac = `<div class="staff-info">
                  <div class="staff-name">${data.ac_staff_name || '-'}</div>
                  <div class="staff-time">${acformattedDateTime}</div>
                  <div class="staff-status">${ac_status}</div>
                </div>`;
      }

      // Generate dynamic HTML content
      const html = `
        <div class="refund-view-container">
          <!-- Header -->
          <div class="refund-header">
            <div class="refund-title">
              <i class="fas fa-receipt me-2"></i>
              Refund Application Details
            </div>
          </div>

          <div class="row g-4">
            <!-- Customer Details Card -->
            <div class="col-lg-6">
              <div class="detail-card">
                <div class="card-header">
                  <i class="fas fa-user-circle me-2"></i>
                  Customer Details
                </div>
                <div class="card-body">
                  <div class="customer-main">
                    <div class="customer-avatar">
                      <i class="fas fa-user"></i>
                    </div>
                    <div class="customer-info">
                      <div class="customer-name">${data.cus_name}</div>
                      <div class="customer-id">${data.cus_customer_id}</div>
                    </div>
                  </div>
                  
                  <div class="detail-item">
                    <div class="detail-label">
                      <i class="fas fa-calendar me-1"></i>
                      Created Date
                    </div>
                    <div class="detail-value">${formattedDate}</div>
                  </div>
                  
                  <div class="detail-item">
                    <div class="detail-label">
                      <i class="fas fa-user-tie me-1"></i>
                      Sales Staff
                    </div>
                    <div class="detail-value">${data.sales_satff}</div>
                  </div>
                  <div class="detail-item">
                    <div class="detail-label">
                      <i class="fas fa-chart-line me-1"></i>
                      Payment Progress
                    </div>
                    <div class="detail-value">
                      <div class="progress-container">
                        <div class="progress-bar-wrapper">
                          <div class="progress-bar" style="width: ${pay}%">
                            <span class="progress-text">${pay}%</span>
                          </div>
                        </div>
                        <div class="progress-stats">${pay}% Completed</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Checklist Card -->
            <div class="col-lg-6">
              <div class="detail-card">
                <div class="card-header">
                  <i class="fas fa-tasks me-2"></i>
                  Checklist
                  <span class="checklist-count">${checkedCount}/${totalCount}</span>
                </div>
                <div class="card-body">
                  <div class="checklist-container">
                    ${checklistDoc.body.innerHTML}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="row g-4 mt-2">
            <!-- Payment Details Card -->
            <div class="col-lg-6">
              <div class="detail-card">
                <div class="card-header">
                  <i class="fas fa-money-bill-wave me-2"></i>
                  Payment Details
                </div>
                <div class="card-body">
                  <div class="payment-item">
                    <div class="payment-label">
                      <span>Paid Amount</span>
                      <small class="text-warning">Without GST</small>
                    </div>
                    <div class="payment-amount amount-paid">${data.currency_symbol}${Currecncy_format(data.paid_amount)}</div>
                  </div>
                  
                  
                  <div class="payment-item">
                    <div class="payment-label">Min. Deducted Amount</div>
                    <div class="payment-amount amount-deducted">${data.currency_symbol}${Currecncy_format(data.min_deducted_amount)}</div>
                  </div>
                  
                  <div class="payment-item">
                    <div class="payment-label">Possible Eligible Amount</div>
                    <div class="payment-amount amount-eligible">${data.currency_symbol}${Currecncy_format(data.posible_eligible_amount)}</div>
                  </div>
                  
                  <div class="payment-item highlight">
                    <div class="payment-label">Refund Amount</div>
                    <div class="payment-amount amount-refund">${data.currency_symbol}${Currecncy_format(data.refund_amount)}</div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Approval Flow Card -->
            <div class="col-lg-6">
              <div class="detail-card">
                <div class="card-header">
                  <i class="fas fa-users me-2"></i>
                  Approval Flow
                </div>
                <div class="card-body">
                  <div class="approval-flow">
                    <div class="approval-step">
                      <div class="step-icon cre">
                        <i class="fas fa-user-tie"></i>
                      </div>
                      <div class="step-content">
                        <div class="step-title">Requester</div>
                        <div class="step-info">
                          <div class="staff-info">
                            <div class="staff-name">${data.created_staff_name}</div>
                            <div class="staff-time">${formattedDateTime}</div>
                            <span class="status-badge status-requested">Requested</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div class="approval-step">
                      <div class="step-icon authority">
                        <i class="fas fa-user-shield"></i>
                      </div>
                      <div class="step-content">
                        <div class="step-title">Authority</div>
                        <div class="step-info">${bh}</div>
                      </div>
                    </div>
                    
                    <div class="approval-step">
                      <div class="step-icon accounts">
                        <i class="fas fa-calculator"></i>
                      </div>
                      <div class="step-content">
                        <div class="step-title">Accounts Head</div>
                        <div class="step-info">${ac}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Reasons Section -->
          <div class="row g-4 mt-2">
            <div class="col-12">
              <div class="detail-card">
                <div class="card-header">
                  <i class="fas fa-comment-dots me-2"></i>
                  Reasons & Notes
                </div>
                <div class="card-body">
                  <div class="reason-section">
                    <div class="reason-item">
                      <div class="reason-title">
                        <i class="fas fa-user-edit me-2"></i>
                        Requester Reason
                      </div>
                      <div class="reason-content">${data.drop_refund_reason}</div>
                    </div>
                    
                    ${type === 2 ? `
                    <div class="reason-item">
                      <div class="reason-title text-danger">
                        <i class="fas fa-times-circle me-2"></i>
                        Authority Reject Reason
                      </div>
                      <div class="reason-content">${data.bh_reject_reason}</div>
                    </div>` : ''}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Refund Details (if applicable) -->
          ${data.ac_status === 2 ? `
          <div class="row g-4 mt-2">
            <div class="col-12">
              <div class="detail-card refund-details">
                <div class="card-header">
                  <i class="fas fa-check-circle me-2 text-success"></i>
                  Refund Completed
                </div>
                <div class="card-body">
                  <div class="row g-3">
                    <div class="col-md-4">
                      <div class="refund-info">
                        <div class="refund-label">Refunded Date</div>
                        <div class="refund-value">${formatDate(data.refunded_date)}</div>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="refund-info">
                        <div class="refund-label">Payment Mode</div>
                        <div class="refund-value">${data.paymentmode_name}</div>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="refund-info">
                        <div class="refund-label">Refund Description</div>
                        <div class="refund-value">${data.refunded_reason}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>` : ''}
        </div>
      `;

      // Add properly scoped CSS styles
      const styles = `
        <style>
          #view_drop_refundContent .refund-view-container {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          }
          
          #view_drop_refundContent .refund-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #e9ecef;
          }
          
          #view_drop_refundContent .refund-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: #2c3e50;
            display: flex;
            align-items: center;
          }
          
          #view_drop_refundContent .refund-id {
            font-size: 0.9rem;
            color: #6c757d;
            background: #f8f9fa;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            border: 1px solid #dee2e6;
          }
          
          #view_drop_refundContent .detail-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.08);
            border: 1px solid #e9ecef;
            overflow: hidden;
            height: 100%;
          }
          
          #view_drop_refundContent .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 1.5rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            font-size: 1.1rem;
          }
          
          #view_drop_refundContent .card-body {
            padding: 1.5rem;
          }
          
          #view_drop_refundContent .customer-main {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e9ecef;
          }
          
          #view_drop_refundContent .customer-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
            margin-right: 1rem;
          }
          
          #view_drop_refundContent .customer-name {
            font-size: 1.25rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 0.25rem;
          }
          
          #view_drop_refundContent .customer-id {
            font-size: 0.9rem;
            color: #6c757d;
            font-weight: 500;
          }
          
          #view_drop_refundContent .detail-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding: 0.75rem;
            background: #f8f9fa;
            border-radius: 8px;
          }
          
          #view_drop_refundContent .detail-label {
            flex: 1;
            font-weight: 600;
            color: #495057;
            display: flex;
            align-items: center;
          }
          
          #view_drop_refundContent .detail-value {
            flex: 1;
            text-align: right;
            font-weight: 700;
            color: #2c3e50;
          }
          
          #view_drop_refundContent .progress-container {
            width: 100%;
          }
          
          #view_drop_refundContent .progress-bar-wrapper {
            width: 100%;
            height: 24px;
            background: #e9ecef;
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 0.5rem;
            border: 1px solid #dee2e6;
          }
          
          #view_drop_refundContent .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #ffa500, #ffb732);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            transition: width 0.3s ease;
          }
          
          #view_drop_refundContent .progress-text {
            color: #000;
            font-weight: 700;
            font-size: 0.8rem;
            text-shadow: 0 1px 1px rgba(255,255,255,0.5);
          }
          
          #view_drop_refundContent .progress-stats {
            font-size: 0.8rem;
            color: #6c757d;
            text-align: center;
            font-weight: 500;
          }
          
          #view_drop_refundContent .checklist-count {
            background: rgba(255,255,255,0.2);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.9rem;
            margin-left: auto;
          }
          
          #view_drop_refundContent .checklist-container {
            max-height: 300px;
            overflow-y: auto;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e9ecef;
          }
          
          #view_drop_refundContent .payment-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            margin-bottom: 0.75rem;
            border-radius: 8px;
            background: #f8f9fa;
            border-left: 4px solid #dee2e6;
          }
          
          #view_drop_refundContent .payment-item.highlight {
            background: #fff3cd;
            border-left-color: #ffc107;
            border: 2px solid #ffc107;
          }
          
          #view_drop_refundContent .payment-label {
            flex: 1;
            font-weight: 600;
            color: #495057;
          }
          
          #view_drop_refundContent .payment-label small {
            display: block;
            font-size: 0.75rem;
            font-weight: 500;
          }
          
          #view_drop_refundContent .payment-amount {
            font-weight: 700;
            font-size: 1.1rem;
          }
          
          #view_drop_refundContent .amount-paid { color: #28a745; }
          #view_drop_refundContent .amount-costing { color: #007bff; }
          #view_drop_refundContent .amount-deducted { color: #dc3545; }
          #view_drop_refundContent .amount-eligible { color: #17a2b8; }
          #view_drop_refundContent .amount-refund { color: #dc3545; font-size: 1.3rem !important; }
          
          #view_drop_refundContent .approval-flow {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
          }
          
          #view_drop_refundContent .approval-step {
            display: flex;
            align-items: flex-start;
            gap: 1rem;
          }
          
          #view_drop_refundContent .step-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
            flex-shrink: 0;
          }
          
          #view_drop_refundContent .step-icon.cre { background: #6f42c1; }
          #view_drop_refundContent .step-icon.authority { background: #e83e8c; }
          #view_drop_refundContent .step-icon.accounts { background: #20c997; }
          
          #view_drop_refundContent .step-content {
            flex: 1;
          }
          
          #view_drop_refundContent .step-title {
            font-weight: 600;
            color: #495057;
            margin-bottom: 0.5rem;
          }
          
          #view_drop_refundContent .staff-info {
            padding: 0.75rem;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e9ecef;
          }
          
          #view_drop_refundContent .staff-name {
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 0.25rem;
          }
          
          #view_drop_refundContent .staff-time {
            font-size: 0.8rem;
            color: #6c757d;
            margin-bottom: 0.5rem;
          }
          
          #view_drop_refundContent .status-badge {
            padding: 0.35rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            display: inline-block;
          }
          
          #view_drop_refundContent .status-accepted { background: #d4edda; color: #155724; }
          #view_drop_refundContent .status-rejected { background: #f8d7da; color: #721c24; }
          #view_drop_refundContent .status-pending { background: #fff3cd; color: #856404; }
          #view_drop_refundContent .status-requested { background: #d1ecf1; color: #0c5460; }
          
          #view_drop_refundContent .reason-section {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
          }
          
          #view_drop_refundContent .reason-item {
            padding: 1.25rem;
            border-radius: 8px;
            background: #f8f9fa;
            border-left: 4px solid #6f42c1;
          }
          
          #view_drop_refundContent .reason-title {
            font-weight: 700;
            color: #495057;
            margin-bottom: 0.75rem;
            display: flex;
            align-items: center;
          }
          
          #view_drop_refundContent .reason-content {
            color: #6c757d;
            line-height: 1.6;
            background: white;
            padding: 1rem;
            border-radius: 6px;
            border: 1px solid #e9ecef;
          }
          
          #view_drop_refundContent .refund-details {
            border: 2px solid #28a745 !important;
          }
          
          #view_drop_refundContent .refund-details .card-header {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
          }
          
          #view_drop_refundContent .refund-info {
            text-align: center;
            padding: 1rem;
          }
          
          #view_drop_refundContent .refund-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 0.5rem;
          }
          
          #view_drop_refundContent .refund-value {
            font-weight: 700;
            color: #28a745;
            font-size: 1.1rem;
          }
          
          #view_drop_refundContent .scroll-y {
            max-height: 300px;
            overflow-y: auto;
          }
          
          @media (max-width: 768px) {
            #view_drop_refundContent .refund-header {
              flex-direction: column;
              gap: 1rem;
              text-align: center;
            }
            
            #view_drop_refundContent .approval-step {
              flex-direction: column;
              text-align: center;
            }
            
            #view_drop_refundContent .step-icon {
              align-self: center;
            }
          }
        </style>
      `;

      // Render the generated HTML into the modal or target container
      document.getElementById('view_drop_refundContent').innerHTML = styles + html;
  }
  

  function status_change_validation(){
    var err = 0;
    var type = $('#sts_change_type').val();
    if(type==2){
      var bhreject_reason = $('#bhreject_reason').val().trim();
      if(bhreject_reason==''){
        $('#bhreject_reason_err').html('Enter Reject Reason is requered..!');
        err++;
      }else{
        $('#bhreject_reason_err').html('');
      }
    }
    return err===0;
  }

  function refund_status_change_validation(){
    var err = 0;

      var pay_mode_list = $('#pay_mode_list').val();
      if(pay_mode_list==''){
        $('#pay_mode_list_err').html('Select Payment Mode is requered..!');
        err++;
      }else{
        $('#pay_mode_list_err').html('');
      }
      var refund_description = $('#refund_description').val().trim();
      if(refund_description==''){
        $('#refund_description_err').html('Enter Refunded Reason is requered..!');
        err++;
      }else{
        $('#refund_description_err').html('');
      }
    return err===0;
  }
  </script>
<script>
  $(".list_page").DataTable({
    "ordering": false,
    "paging": false,
    // "aaSorting":[],
    "fixedColumns": {
      "left": 1,
      "right": 1,
    },
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<!-- Thumbnail Image Upload Start : ADD -->
<script>
  function date_fill_issue_rpt() {
    var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
    var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
    var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
    var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
    var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
    var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
    var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
    var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
    var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

    if (dt_fill_issue_rpt == "today") {
      today_dt_iss_rpt.style.display = "block";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else if (dt_fill_issue_rpt == "week") {
      today_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "block";
      week_to_dt_iss_rpt.style.display = "block";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";

      var curr = new Date; // get current date
      var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
      var last = first + 6; // last day is the first day + 6

      var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
      firstday = firstday.split("-").reverse().join("-");
      var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
      lastday = lastday.split("-").reverse().join("-");
      $('#week_from_date_fil').val(firstday);
      $('#week_to_date_fil').val(lastday);

    } else if (dt_fill_issue_rpt == "monthly") {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "block";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else if (dt_fill_issue_rpt == "custom_date") {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "block";
      to_dt_iss_rpt.style.display = "block";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    }
  }
</script>
@endsection
