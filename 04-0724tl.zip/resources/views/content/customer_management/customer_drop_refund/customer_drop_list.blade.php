@extends('layouts/layoutMaster')

@section('title', 'Manage Drop Customers')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection
@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection


<style>
  .list_page tbody td {
    padding: 5px !important;
  }
  /* Example CSS for adjusting underline height */
.underline {
  text-decoration: underline;
  text-decoration-thickness: 2px; /* Adjust the thickness of the underline */
  text-underline-offset: 6px; /* Adjust the distance between the text and the underline */
}

</style>

<style>
/* Additional CSS for better table column display */
.carousel.slide {
    width: 100%;
    min-width: 400px;
}


.carousel-item {
    min-height: 120px;
}

.txt_vertical {
    writing-mode: vertical-rl;
    text-orientation: mixed;
    transform: rotate(180deg);
    font-size: 0.7rem;
    font-weight: bold;
    color: #6c757d;
    margin-left: -5px;
}

.rotate-180 {
    transform: rotate(180deg);
}

.rotate-270 {
    transform: rotate(270deg);
    display: block;
    white-space: nowrap;
}

.w-350px {
    width: 350px;
    min-width: 350px;
}

.h-80px {
    height: 80px;
}

.fs-8 {
    font-size: 0.8rem;
}

/* Ensure proper text truncation */
.text-truncate {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}



/* Responsive adjustments */
@media (max-width: 768px) {
    .w-350px {
        width: 280px;
        min-width: 280px;
    }
    
    .carousel.slide {
        min-width: 350px;
    }
}
</style>
@section('content')
<div class="card card-action">
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
  <div class="card-header border-bottom pb-0 flex-wrap">
    <div class="card-action-title text-black fs-5 fw-bold mb-1">
      <h5 class="card-title mb-1">Manage Customer Drop</h5>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-1">
          <li class="breadcrumb-item">
            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
          </li>
          <span class="text-dark opacity-75 me-1 ms-1">
            <i class="mdi mdi-chevron-double-right fs-4"></i>
          </span>
          <li class="breadcrumb-item">
            <a href="javascript:;" class="d-flex align-items-center fw-semibold">Customer Management</a>
          </li>
        </ol>
      </nav>
    </div>
  </div>
  <div class="card-body pt-2">
    <div class="row mb-4">
      @php $perpage_count = $perpage ? $perpage : 10; @endphp
      <div class="col-lg-2">
          <span>Show</span>
          <br>
          <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
              @php
              $options = [10, 25, 100, 500]; // Define available options
              @endphp
              @php foreach ($options as $option): @endphp
              <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                  @php echo $option; @endphp
              </option>
              @php endforeach; @endphp
          </select>
      </div>
      <div class="col-lg-10 d-flex align-items-end justify-content-end">
          <form id="search_form" method="POST" action="/manage_customer_drop">
              @csrf
            <div class="d-flex align-items-center gap-2 mt-2">
              <div>
                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                <input type="hidden" name="filter_on" value="1">
                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                <input
                  type="text"
                  class="form-control"
                  id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                  placeholder="Enter Search"
                />
              </div>
              <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
            </div>
          </form>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12">
        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
          <thead>
            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
              <th class="min-w-100px">Customer</th>
              <th class="min-w-150px">Services / Payment Progress</th>
              <th class="min-w-50px">Authority Status</th>
              <th class="min-w-50px">Actions</th>
            </tr>
          </thead>
          <tbody class="text-black fw-semibold fs-7">
            @if (isset($customers))
              @foreach ($customers as $i => $cus)
                <tr>
                   
                    <td>
                        <div class="d-flex align-items-center px-1">
                            <div class="mb-0 align-items-center">
                                <label>
                                    <span class="fs-7 me-1">{{ $cus->cus_name }}</span>
                                </label>
                                <div class="d-block text-primary fs-8" title="Email ID">{{ $cus->cus_email_id ?? '-' }}</div>
                                <div class="d-block mt-1">
                                    <label class="fw-semibold fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Requested Date">{{ date($common_date_format, strtotime($cus->created_at)) }}</label>
                                </div>
                            </div>
                        </div>
                    </td>

                    <td>
                        @php
                            $proposal_details = $cus->proposal_details ?? [];
                        @endphp

                        @php
                            $Progress = $cus->paid_percentage; // Placeholder value for progress
                            $pay_per = $cus->paid_percentage;  // Placeholder value for payment percentage
                            $payable_amount = $cus->payable_amount; // Placeholder value for paid amount
                            $paid_amount = $cus->paid_amount; // Placeholder value for paid amount
                            $balance_amount = $cus->balance_amount; // Placeholder value for paid amount
                            $present_days = 0; // Placeholder value for present days
                            
                            // Set color based on progress value
                            if ($Progress <= 20) {
                                $color = '#ec0b03'; // Red
                            } elseif ($Progress >= 90) {
                                $color = '#16af08'; // Green
                            } else {
                                $color = '#ffa500'; // Orange
                            }
                        @endphp

                        <div id="carouselExample{{$i}}" class="carousel slide" data-bs-ride="carousel" style="max-height: 200px;">
                            <div class="carousel-inner pb-5 ps-5">
                                @foreach ($proposal_details as $index => $proposal)
                                  <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                                      <div class="text-center text-info mb-1 ">
                                          Proposal ID - {{ $proposal->proposal_ids }}
                                      </div>

                                      <div class="d-flex px-1 align-items-center gap-1">

                                          <!-- Course Details -->
                                          <div class="ms-2">
                                              <div class="row w-350px">

                                                  <div class="col-12">
                                                      <div class="row align-items-center">
                                                          <label class="col-3 text-dark fs-8 fw-semibold mb-0">Type</label>
                                                          <label class="col-1">:</label>
                                                          <label class="col-8 fw-bold">
                                                              {{ $proposal->product_package == 1 ? 'Product' : 'Package' }}
                                                          </label>
                                                      </div>
                                                  </div>

                                                  <div class="col-12">
                                                      <div class="row align-items-center">
                                                          <label class="col-3 text-dark fs-8 fw-semibold mb-0">Product</label>
                                                          <label class="col-1">:</label>
                                                          <label class="col-8" title="{{ $proposal->product_name }}">
                                                              {{ $proposal->product_name }}
                                                          </label>
                                                      </div>
                                                  </div>

                                                  <div class="col-12">
                                                      <div class="row align-items-center">
                                                          <label class="col-3 text-dark fs-8 fw-semibold mb-0">Variant</label>
                                                          <label class="col-1">:</label>
                                                          <label class="col-8" title="{{ $proposal->variant_name }}">
                                                              {{ $proposal->variant_name }}
                                                          </label>
                                                      </div>
                                                  </div>

                                                  <div class="col-12">
                                                      <div class="row align-items-center">
                                                          <label class="col-3 text-dark fs-8 fw-semibold mb-0">Variable</label>
                                                          <label class="col-1">:</label>
                                                          <label class="col-8" title="{{ $proposal->variable_name }}">
                                                              {{ $proposal->variable_name }}
                                                          </label>
                                                      </div>
                                                  </div>

                                              </div>
                                          </div>
                                      </div>
                                  </div>
                                @endforeach

                            </div><!-- End Carousel Inner -->

                            <!-- Carousel Indicators -->
                            <div class="carousel-indicators position-absolute mb-0" style="bottom: 10px;">
                                @foreach ($proposal_details as $index => $proposal)
                                    <button type="button" data-bs-target="#carouselExample{{$i}}" data-bs-slide-to="{{ $index }}" class="{{ $index == 0 ? 'active' : '' }} bg-dark" style="width: 8px; height: 8px; border-radius: 50%;"></button>
                                @endforeach
                            </div><!-- End Carousel Indicators -->
                        </div><!-- End Carousel -->
                    </td>

                    <td>
                        @if ($cus->bh_status == 0)
                            <user href="javascript:;" class="badge bg-warning text-black fw-bold fs-8" @if(auth()->user()->role_id == 1)data-bs-toggle="dropdown" @endif  aria-haspopup="true" aria-expanded="false">Waiting for Approval</a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="javascript:;" class="dropdown-item fs-7 py-2" data-bs-toggle="modal" data-bs-target="#kt_modal_refund_accept" onclick="status_change(1, {{ json_encode($cus ?? []) }}, {{ $Progress }}, {{ $pay_per }}, {{ $paid_amount }}, {{ $payable_amount }}, {{ $balance_amount }}, {{count($cus->proposal_details)}})">Accept</a>
                                <a href="javascript:;" class="dropdown-item fs-7 py-2" data-bs-toggle="modal" data-bs-target="#kt_modal_refund_accept" onclick="status_change(2, {{ json_encode($cus ?? []) }}, {{ $Progress }}, {{ $pay_per }}, {{ $paid_amount }}, {{ $payable_amount }}, {{ $balance_amount }}, {{count($cus->proposal_details)}})">Reject</a>
                            </div>
                        @elseif ($cus->bh_status == 1)
                            <div class="badge bg-info text-white fw-bold fs-8" style="background-color:#f80c33 !important;">Customer Dropped Approved</div>
                            <div class="d-block mt-1">
                                <label class="fw-semibold fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Request Accepted Date">{{ $cus->bh_status_date ? date($common_date_format, strtotime($cus->bh_status_date)) : '-' }}</label>
                            </div>
                        @elseif ($cus->bh_status == 2)
                            <div class="badge bg-success text-white fw-bold fs-8">Customer Dropped Rejected</div>
                            <a href="javascript:;" class="fw-bold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $cus->bh_reject_reason ?? '-' }}"><i class="mdi mdi-information fs-7 text-black fw-bold"></i></a>
                        @endif
                    </td>

                    <td align="center">
                        <span class="text-end">
                            <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_refund_view" onclick="view_drop_refund({{ json_encode($cus ?? []) }}, {{ $Progress }}, {{ $pay_per }}, {{ $paid_amount }}, {{ $payable_amount }}, {{ $balance_amount }} , {{count($cus->proposal_details)}})">
                                <i class="mdi mdi-eye-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"></i>
                            </a>
                        </span>
                    </td>
                </tr>
                @endforeach

            @endif
          </tbody>
        </table>
      </div>
      <div class="mt-4">
        {{ $customers->appends(request()->except(['page', '_token']))->links() }}
      </div>
    </div>
  </div>
</div>

<!--begin::Modal - Customer Drop View-->
<div class="modal fade" id="kt_modal_refund_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div id="view_drop_refundContent"></div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Refund View-->

<!--begin::Modal - Customer Drop Accepted-->
<div class="modal fade" id="kt_modal_refund_accept" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <form id="cus_drp_form" action="{{ route('customer_drop_status_change') }}" method="POST" enctype="multipart/form-data" autocomplete="off" onsubmit="return status_change_validation()">
          @csrf
          <!--begin::Heading-->
          <div id="statusModalContent"></div>
          <div class="d-flex justify-content-end align-items-center mt-6 gap-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary" id="status_submit_btn">Customer Droped</button>
          </div>
        </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Customer Drop Accepted-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>


  /* Customize Toastr notification */
  .toast-success {
      background-color: green;
  }

  /* Customize Toastr notification */
  .toast-error {
      background-color: rgb(196, 3, 3);
  }
  .error_msg {
      border: solid 2px red !important;
      border-color: red !important;
  }
</style>
<script>
// Display Toastr messages
@if(Session::has('toastr'))
var type = "{{ Session::get('toastr')['type'] }}";
var message = "{{ Session::get('toastr')['message'] }}";
toastr[type](message);
@endif
</script>
<script>
  $('#filter').click(function() {
      $('.filter_tbox').slideToggle('slow');
  });
  $(document).ready(function() {
      @if ($filter_on ?? '')
          // $('.customer_tbox').slideToggle('fast');
          $('.filter_tbox').slideToggle('fast');
          // });
      @endif
  });
</script>
<script>
function formatDateTime(dateString) {
    const date = new Date(dateString);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
        return '-'; // Return '-' if the date is invalid
    }

    const options = {
        year: 'numeric',
        month: 'short',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    };

    return date.toLocaleString('en-GB', options).replace(',', '');
}
function formatDate(dateString) {
    const date = new Date(dateString);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
        return '-'; // Return '-' if the date is invalid
    }

    // Get the day, month (abbreviated), and year
    const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
    const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
    const year = date.getFullYear(); // Get full year

    // Construct and return the formatted date string
    return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
}
function Currecncy_format(Number) {
    var Currecncy = (Number || 0).toLocaleString('en-IN', {
                    maximumFractionDigits: 2,
                    currency: 'INR'
                });
    return Currecncy;
  }
function status_change(type, data, course, pay, paid_amount, payable, balance,products) {
  console.log('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', data);
  
  const status = type === 1 ? 'Accepted' : 'Rejected';
  const statusColor = type === 1 ? 'danger' : 'success';
  const actionText = type === 1 ? 'Approve' : 'Reject';
  
  // Calculate checked and total checklist items
  const parser = new DOMParser();
  const checklistDoc = parser.parseFromString(data.check_list, 'text/html');
  const allCheckboxes = checklistDoc.querySelectorAll('.checklist-checkbox');
  const checkedCount = checklistDoc.querySelectorAll('.checklist-checkbox:checked').length;
  const totalCount = allCheckboxes.length;
  const progressPercentage = totalCount > 0 ? Math.round((checkedCount / totalCount) * 100) : 0;
  
  const formattedDateTime = formatDateTime(data.created_at);
  const formattedDate = formatDate(data.created_at);
  const formattedDate_lead = data.registered_date ? formatDate(data.registered_date) : 'N/A';

  // Disable all checkboxes
  allCheckboxes.forEach(checkbox => (checkbox.disabled = true));

  // Generate dynamic HTML content with improved UI/UX
  const html = `
    <!-- Header Section -->
    <div class="text-center mb-8">
      <div class="mb-4">
        
        <h1 class="text-gray-900 fw-bolder mb-2">${actionText} Drop Request</h1>
        <div class="text-muted fs-5 fw-semibold">You are about to ${actionText.toLowerCase()} this request</div>
      </div>
      <div class="badge bg-${statusColor} text-white fs-6 px-4 py-3 rounded-pill fw-bold">
        ${actionText} Confirmation
      </div>
    </div>

    <input type="hidden" id="sts_change_type" name="sts_change_type" value="${type}"/>
    <input type="hidden" id="sts_change_id" name="sts_change_id" value="${data.sno}"/>

    <!-- Customer Information Card -->
    <div class="card card-bordered shadow-sm mb-6">
      <div class="card-header card-header-stretch bg-light-primary py-5">
        <h2 class="card-title text-gray-800 fw-bolder mb-0">Customer Information</h2>
      </div>
      <div class="card-body p-8">
        <div class="row g-6">
          <!-- Left Column -->
          <div class="col-lg-6">
            <!-- Customer Profile -->
            <div class="d-flex align-items-center p-4 mb-5 bg-light-primary rounded">
              <div class="customer-avatar bg-primary rounded-circle d-flex align-items-center justify-content-center me-4" style="width: 70px; height: 70px;">
                <span class="fs-3 fw-bold text-white">${data.cus_name ? data.cus_name.charAt(0).toUpperCase() : 'C'}</span>
              </div>
              <div class="flex-grow-1">
                <div class="fs-2 fw-bolder text-gray-900">${data.cus_name}</div>
                <div class="fs-5 text-muted fw-semibold">Customer ID: ${data.cus_customer_id}</div>
              </div>
            </div>

            <!-- Timeline Information -->
            <div class="bg-light rounded p-5">
              <div class="info-item mb-4">
                <div class="text-muted fs-7 fw-semibold mb-1">Total Products</div>
                <div class="badge badge-lg bg-success fs-6 fw-bold">${products}</div>
              </div>
              <div class="info-item mb-4">
                <div class="text-muted fs-7 fw-semibold mb-1">Request Created</div>
                <div class="fs-5 fw-bold text-gray-800">${formattedDateTime}</div>
              </div>
              
              <div class="info-item mb-4">
                <div class="text-muted fs-7 fw-semibold mb-1">Customer Registered</div>
                <div class="fs-5 fw-bold text-gray-800">${formattedDate_lead}</div>
              </div>
              
              <div class="info-item">
                <div class="text-muted fs-7 fw-semibold mb-1">Sales Staff</div>
                <div class="fs-5 fw-bold text-gray-800">${data.sales_satff}</div>
              </div>
            </div>
          </div>

          <!-- Right Column -->
          <div class="col-lg-6">
            <!-- Payment Progress -->
            <div class="card card-flush bg-light-warning mb-3">
              <div class="card-body p-5">
                <div class="d-flex align-items-center mb-3">
                  <div class="flex-grow-1">
                    <div class="fs-5 fw-bold text-gray-800">Payment Progress</div>
                    <div class="text-muted fs-7">Overall payment completion</div>
                  </div>
                  <span class="fs-3 fw-bolder text-warning">${pay}%</span>
                </div>
                <div class="progress h-10px bg-white rounded">
                  <div class="progress-bar bg-warning rounded" role="progressbar" 
                       style="width: ${pay}%" aria-valuenow="${pay}" 
                       aria-valuemin="0" aria-valuemax="100">
                  </div>
                </div>
              </div>
            </div>

            <!-- Financial Summary -->
            <div class="bg-light rounded p-5">
              <h4 class="text-gray-800 fw-bold  border-bottom">Financial Summary</h4>
              
              <div class="financial-item d-flex align-items-center justify-content-between mb-3 p-3 bg-white rounded">
                <div>
                  <div class="text-muted fs-7 fw-semibold">Total Payable</div>
                  <div class="fs-6 fw-bold text-gray-700">Amount due</div>
                </div>
                <span class="badge badge-lg bg-info fs-6 fw-bold">${Currecncy_format(payable)}</span>
              </div>
              
              <div class="financial-item d-flex align-items-center justify-content-between mb-3 p-3 bg-white rounded">
                <div>
                  <div class="text-muted fs-7 fw-semibold">Total Paid</div>
                  <div class="fs-6 fw-bold text-gray-700">Amount received</div>
                </div>
                <span class="badge badge-lg bg-success fs-6 fw-bold">${Currecncy_format(paid_amount)}</span>
              </div>
              
              <div class="financial-item d-flex align-items-center justify-content-between p-3 bg-white rounded">
                <div>
                  <div class="text-muted fs-7 fw-semibold">Balance Due</div>
                  <div class="fs-6 fw-bold text-gray-700">Remaining amount</div>
                </div>
                <span class="badge badge-lg bg-danger fs-6 fw-bold">${Currecncy_format(balance)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Checklist Section -->
    <div class="card card-bordered shadow-sm mb-6">
      <div class="card-header card-header-stretch bg-light-warning py-5">
        <div class="card-title d-flex align-items-center justify-content-between w-100">
          <h2 class="text-gray-800 fw-bolder mb-0">Staff Checklist</h2>
          <div class="d-flex align-items-center">
            <span class="badge badge-lg bg-warning text-white fs-6 fw-bold">
              ${checkedCount}/${totalCount} (${progressPercentage}%)
            </span>
          </div>
        </div>
      </div>
      <div class="card-body p-6">
        <div class="scroll-y max-h-400px px-4 py-4 bg-light rounded">
          <div class="row g-4">
            ${Array.from(checklistDoc.body.children).map((item, index) => `
              <div class="col-md-6">
                <div class="form-check form-check-custom form-check-solid p-3 bg-white rounded">
                  ${item.innerHTML}
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    </div>

    <!-- Approval Information -->
    <div class="card card-bordered shadow-sm mb-6">
      <div class="card-header card-header-stretch bg-light-info py-5">
        <h2 class="card-title text-gray-800 fw-bolder mb-0">Approval Information</h2>
      </div>
      <div class="card-body p-6">
        <div class="row g-6">
          <!-- Requested By -->
          <div class="col-lg-6">
            <div class="bg-light-primary rounded p-5 h-100">
              <h4 class="text-primary fw-bold mb-4 text-center">Requested By</h4>
              <div class="text-center">
                <div class="requestor-avatar bg-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                  <span class="fs-4 fw-bold text-white">${data.created_staff_name ? data.created_staff_name.charAt(0).toUpperCase() : 'S'}</span>
                </div>
                <div class="fs-4 fw-bold text-gray-800">${data.created_staff_name}</div>
                <div class="fs-6 text-muted fw-semibold">Staff Member</div>
                <div class="mt-3">
                  <span class="badge badge-lg bg-primary fs-7 fw-semibold">
                    ${formattedDateTime}
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <!-- To Be Approved By -->
          <div class="col-lg-6">
            <div class="bg-light-${statusColor} rounded p-5 h-100">
              <h4 class="text-${statusColor} fw-bold mb-4 text-center">${actionText} By</h4>
              <div class="text-center">
                <div class="approver-avatar bg-${statusColor} rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                  <span class="fs-4 fw-bold text-white">A</span>
                </div>
                <div class="fs-4 fw-bold text-gray-800">You</div>
                <div class="fs-6 text-muted fw-semibold">Authority</div>
                <div class="mt-3">
                  <span class="badge badge-lg bg-${statusColor} fs-7 fw-semibold">
                    ${new Date().toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Drop Reason Section -->
    <div class="card card-bordered shadow-sm mb-6">
      <div class="card-header card-header-stretch bg-light-danger py-5">
        <h2 class="card-title text-gray-800 fw-bolder mb-0">Drop Reason</h2>
      </div>
      <div class="card-body p-6">
        <div class="alert alert-danger border-0 bg-light-danger p-5">
          <div class="d-flex flex-column">
            <h4 class="fw-bold text-gray-800 mb-3">Customer Drop Request Reason</h4>
            <div class="reason-content bg-white rounded p-4 border">
              <p class="fw-normal fs-6 text-gray-700 mb-0 lh-lg">${data.drop_refund_reason}</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Reject Reason Input (Only for Rejection) -->
    ${type === 2 ? `
    <div class="card card-bordered shadow-sm mb-0">
      <div class="card-header card-header-stretch bg-light-warning py-5">
        <h2 class="card-title text-gray-800 fw-bolder mb-0">Rejection Reason</h2>
      </div>
      <div class="card-body p-6">
        <div class="alert alert-warning border-0 bg-light-warning p-4 mb-4">
          <div class="d-flex flex-column">
            <h5 class="fw-bold text-gray-800 mb-2">Required Information</h5>
            <p class="fw-normal fs-6 text-gray-700 mb-0">Please provide a clear reason for rejecting this drop request.</p>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label text-danger fs-6 fw-bold required mb-3">
            Authority Rejection Reason
          </label>
          <textarea class="form-control form-control-solid" 
                    rows="4" 
                    id="bhreject_reason" 
                    name="bhreject_reason" 
                    placeholder="Please provide detailed reason for rejecting this customer drop request..."
                    data-kt-autosize="true"
                    style="min-height: 120px;"></textarea>
          <div class="text-danger mt-2 fs-7" id="bhreject_reason_err"></div>
        </div>
      </div>
    </div>` : ''}

    <style>
      .status-indicator, .customer-avatar, .requestor-avatar, .approver-avatar {
        border: 3px solid var(--bs-light);
        font-weight: 700;
      }
      .info-item, .financial-item {
        transition: all 0.3s ease;
      }
      .info-item:hover, .financial-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      }
      .form-control-solid {
        background-color: var(--bs-light-bg-subtle);
        border-color: var(--bs-border-color);
        transition: all 0.3s ease;
      }
      .form-control-solid:focus {
        background-color: var(--bs-white);
        border-color: var(--bs-warning);
        box-shadow: 0 0 0 3px rgba(var(--bs-warning-rgb), 0.1);
      }
    </style>
  `;

  // Render the generated HTML
  document.getElementById('statusModalContent').innerHTML = html;
  
  // Update button styling based on action type
  const submitBtn = document.getElementById('status_submit_btn');
  if (type === 1) {
    submitBtn.innerHTML = `Yes, Approve Drop Request`;
    submitBtn.className = 'btn btn-danger btn-lg fw-bold px-6';
  } else {
    submitBtn.innerHTML = `No, Reject Drop Request`;
    submitBtn.className = 'btn btn-success btn-lg fw-bold px-6';
  }
}

function view_drop_refund(data, course, pay, paid_amount, payable, balance ,products) {
  // Determine the status
  var type = data.bh_status;
  let statusBadge, statusColor, statusText;
  
  if (type == 1) {
    statusBadge = '<span class="badge bg-danger text-white fs-6 px-4 py-3 rounded-pill fw-bold">Approved</span>';
    statusColor = 'danger';
    statusText = 'Approved';
  } else if (type == 2) {
    statusBadge = '<span class="badge bg-success text-white fs-6 px-4 py-3 rounded-pill fw-bold">Rejected</span>';
    statusColor = 'success';
    statusText = 'Rejected';
  } else {
    statusBadge = '<span class="badge bg-warning text-white fs-6 px-4 py-3 rounded-pill fw-bold">Pending Approval</span>';
    statusColor = 'warning';
    statusText = 'Pending';
  }

  // Calculate checked and total checklist items
  const parser = new DOMParser();
  const checklistDoc = parser.parseFromString(data.check_list, 'text/html');
  const allCheckboxes = checklistDoc.querySelectorAll('.checklist-checkbox');
  const checkedCount = checklistDoc.querySelectorAll('.checklist-checkbox:checked').length;
  const totalCount = allCheckboxes.length;
  const progressPercentage = totalCount > 0 ? Math.round((checkedCount / totalCount) * 100) : 0;
  
  const formattedDateTime = formatDateTime(data.created_at);
  const bhformattedDateTime = formatDateTime(data.bh_status_date);
  const formattedDate = formatDate(data.created_at);
  const formattedDate_lead = data.registered_date ? formatDate(data.registered_date) : 'N/A';

  // Disable all checkboxes
  allCheckboxes.forEach(checkbox => (checkbox.disabled = true));

  // Generate dynamic HTML content
  const html = `
    <!-- Header Section -->
    <div class="text-center mb-8">
      <div class="mb-4">
        <h1 class="text-gray-900 fw-bolder mb-2">Drop Request Details</h1>
      </div>
      ${statusBadge}
    </div>

    <!-- Customer Information Card -->
    <div class="card card-bordered shadow-sm mb-6">
      <div class="card-header card-header-stretch bg-light-primary py-5">
        <h2 class="card-title text-gray-800 fw-bolder mb-0">Customer Information</h2>
      </div>
      <div class="card-body p-8">
        <div class="row g-6">
          <!-- Left Column -->
          <div class="col-lg-6">
            <!-- Customer Profile -->
            <div class="d-flex align-items-center mb-6 p-6 bg-light-primary rounded">
              <div class="customer-avatar bg-primary rounded-circle d-flex align-items-center justify-content-center me-4" style="width: 70px; height: 70px;">
                <span class="fs-3 fw-bold text-white">${data.cus_name ? data.cus_name.charAt(0).toUpperCase() : 'C'}</span>
              </div>
              <div class="flex-grow-1">
                <div class="fs-2 fw-bolder text-gray-900">${data.cus_name}</div>
                <div class="fs-5 text-muted fw-semibold">Customer ID: ${data.cus_customer_id}</div>
              </div>
            </div>

            <!-- Timeline Information -->
            <div class="bg-light rounded p-5">
              <div class="info-item mb-4">
                <div class="text-muted fs-7 fw-semibold mb-1">Total Products</div>
                <div class="badge badge-lg bg-success fs-6 fw-bold">${products}</div>
              </div>
              <div class="info-item mb-4">
                <div class="text-muted fs-7 fw-semibold mb-1">Request Created</div>
                <div class="fs-5 fw-bold text-gray-800">${formattedDateTime}</div>
              </div>
              
              <div class="info-item mb-4">
                <div class="text-muted fs-7 fw-semibold mb-1">Customer Registered</div>
                <div class="fs-5 fw-bold text-gray-800">${formattedDate_lead}</div>
              </div>
              
              <div class="info-item">
                <div class="text-muted fs-7 fw-semibold mb-1">Sales Staff</div>
                <div class="fs-5 fw-bold text-gray-800">${data.sales_satff}</div>
              </div>
            </div>
          </div>

          <!-- Right Column -->
          <div class="col-lg-6">
            <!-- Payment Progress -->
            <div class="card card-flush bg-light-warning mb-7">
              <div class="card-body p-5">
                <div class="d-flex align-items-center mb-3">
                  <div class="flex-grow-1">
                    <div class="fs-5 fw-bold text-gray-800">Payment Progress</div>
                    <div class="text-muted fs-7">Overall payment completion</div>
                  </div>
                  <span class="fs-3 fw-bolder text-warning">${pay}%</span>
                </div>
                <div class="progress h-10px bg-white rounded">
                  <div class="progress-bar bg-warning rounded" role="progressbar" 
                       style="width: ${pay}%" aria-valuenow="${pay}" 
                       aria-valuemin="0" aria-valuemax="100">
                  </div>
                </div>
              </div>
            </div>

            <!-- Financial Summary -->
            <div class="bg-light rounded p-5">
              <h4 class="text-gray-800 fw-bold border-bottom">Financial Summary</h4>
              
              <div class="financial-item d-flex align-items-center justify-content-between mb-3 p-3 bg-white rounded">
                <div>
                  <div class="text-muted fs-7 fw-semibold">Total Payable</div>
                  <div class="fs-6 fw-bold text-gray-700">Amount due</div>
                </div>
                <span class="badge badge-lg bg-info fs-6 fw-bold">${Currecncy_format(payable)}</span>
              </div>
              
              <div class="financial-item d-flex align-items-center justify-content-between mb-3 p-3 bg-white rounded">
                <div>
                  <div class="text-muted fs-7 fw-semibold">Total Paid</div>
                  <div class="fs-6 fw-bold text-gray-700">Amount received</div>
                </div>
                <span class="badge badge-lg bg-success fs-6 fw-bold">${Currecncy_format(paid_amount)}</span>
              </div>
              
              <div class="financial-item d-flex align-items-center justify-content-between p-3 bg-white rounded">
                <div>
                  <div class="text-muted fs-7 fw-semibold">Balance Due</div>
                  <div class="fs-6 fw-bold text-gray-700">Remaining amount</div>
                </div>
                <span class="badge badge-lg bg-danger fs-6 fw-bold">${Currecncy_format(balance)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Checklist Section -->
    <div class="card card-bordered shadow-sm mb-6">
      <div class="card-header card-header-stretch bg-light-warning py-5">
        <div class="card-title d-flex align-items-center justify-content-between w-100">
          <h2 class="text-gray-800 fw-bolder mb-0">Staff Checklist</h2>
          <div class="d-flex align-items-center">
            <span class="badge badge-lg bg-warning text-white fs-6 fw-bold">
              ${checkedCount}/${totalCount} (${progressPercentage}%)
            </span>
          </div>
        </div>
      </div>
      <div class="card-body p-6">
        <div class="scroll-y max-h-400px px-4 py-4 bg-light rounded">
          <div class="row g-4">
            ${Array.from(checklistDoc.body.children).map((item, index) => `
              <div class="col-md-6">
                <div class="form-check form-check-custom form-check-solid p-3 bg-white rounded">
                  ${item.innerHTML}
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    </div>

    <!-- Approval Process -->
    <div class="card card-bordered shadow-sm mb-6">
      <div class="card-header card-header-stretch bg-light-info py-5">
        <h2 class="card-title text-gray-800 fw-bolder mb-0">Approval Process</h2>
      </div>
      <div class="card-body p-6">
        <div class="timeline">
          <!-- Step 1 - Request Submitted -->
          <div class="timeline-item ${type >= 0 ? 'completed' : ''}">
            <div class="timeline-indicator bg-success"></div>
            <div class="timeline-content">
              <div class="timeline-header">
                <h4 class="text-success fw-bold">Request Submitted</h4>
                <span class="text-muted fs-7">${formattedDateTime}</span>
              </div>
              <div class="timeline-body">
                <p class="mb-1"><strong>Submitted by:</strong> ${data.created_staff_name}</p>
                <p class="text-muted mb-0">Initial request creation</p>
              </div>
            </div>
          </div>

          <!-- Step 2 - Under Review -->
          <div class="timeline-item ${type > 0 ? 'completed' : (type === 0 ? 'current' : '')}">
            <div class="timeline-indicator ${type > 0 ? 'bg-success' : (type === 0 ? 'bg-warning' : 'bg-secondary')}"></div>
            <div class="timeline-content">
              <div class="timeline-header">
                <h4 class="${type > 0 ? 'text-success' : (type === 0 ? 'text-warning' : 'text-muted')} fw-bold">
                  ${type === 0 ? 'Under Review' : type > 0 ? 'Review Completed' : 'Pending Review'}
                </h4>
                ${type > 0 ? `<span class="text-muted fs-7">${bhformattedDateTime}</span>` : ''}
              </div>
              <div class="timeline-body">
                ${type > 0 ? `
                  <p class="mb-1"><strong>Reviewed by:</strong> ${data.bh_staff_name || 'Authority'}</p>
                  <p class="text-muted mb-0">Authority review completed</p>
                ` : '<p class="text-muted mb-0">Waiting for authority review</p>'}
              </div>
            </div>
          </div>

          <!-- Step 3 - Final Decision -->
          <div class="timeline-item ${type === 1 || type === 2 ? 'completed' : ''}">
            <div class="timeline-indicator ${type === 1 ? 'bg-danger' : (type === 2 ? 'bg-success' : 'bg-secondary')}"></div>
            <div class="timeline-content">
              <div class="timeline-header">
                <h4 class="${type === 1 ? 'text-danger' : (type === 2 ? 'text-success' : 'text-muted')} fw-bold">
                  ${type === 1 ? 'Approved' : type === 2 ? 'Rejected' : 'Decision Pending'}
                </h4>
              </div>
              <div class="timeline-body">
                <p class="text-muted mb-0">
                  ${type !== 0 ? 'Final decision made by authority' : 'Awaiting final decision'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Drop Reason Section -->
    <div class="card card-bordered shadow-sm mb-6">
      <div class="card-header card-header-stretch bg-light-danger py-5">
        <h2 class="card-title text-gray-800 fw-bolder mb-0">Drop Reason</h2>
      </div>
      <div class="card-body p-6">
        <div class="alert alert-danger border-0 bg-light-danger p-5">
          <div class="d-flex flex-column">
            <h4 class="fw-bold text-gray-800 mb-3">Customer Drop Request Reason</h4>
            <div class="reason-content bg-white rounded p-4 border">
              <p class="fw-normal fs-6 text-gray-700 mb-0 lh-lg">${data.drop_refund_reason}</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Reject Reason (Only for rejected requests) -->
    ${type === 2 ? `
    <div class="card card-bordered shadow-sm mb-0">
      <div class="card-header card-header-stretch bg-light-warning py-5">
        <h2 class="card-title text-gray-800 fw-bolder mb-0">Rejection Details</h2>
      </div>
      <div class="card-body p-6">
        <div class="alert alert-warning border-0 bg-light-warning p-5">
          <div class="d-flex flex-column">
            <h4 class="fw-bold text-gray-800 mb-3">Authority Rejection Reason</h4>
            <div class="reason-content bg-white rounded p-4 border">
              <p class="fw-normal fs-6 text-gray-700 mb-0 lh-lg">${data.bh_reject_reason}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    ` : ''}

    <style>
      .status-indicator {
        border: 3px solid var(--bs-light);
      }
      .customer-avatar {
        font-weight: 700;
      }
      .timeline {
        position: relative;
        padding-left: 30px;
      }
      .timeline-item {
        position: relative;
        padding-bottom: 30px;
      }
      .timeline-item:last-child {
        padding-bottom: 0;
      }
      .timeline-indicator {
        position: absolute;
        left: -30px;
        top: 0;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        border: 3px solid white;
      }
      .timeline-item.completed .timeline-content {
        opacity: 1;
      }
      .timeline-item:not(.completed) .timeline-content {
        opacity: 0.7;
      }
      .timeline-header {
        display: flex;
        justify-content: between;
        align-items: center;
        margin-bottom: 10px;
      }
      .timeline-header h4 {
        margin-bottom: 0;
        flex: 1;
      }
      
      
    </style>
  `;

  // Render the generated HTML
  document.getElementById('view_drop_refundContent').innerHTML = html;
}



function status_change_validation(){
  var err = 0;
  var type = $('#sts_change_type').val();
  if(type==2){
    var bhreject_reason = $('#bhreject_reason').val().trim();
    if(bhreject_reason==''){
      $('#bhreject_reason_err').html('Enter Reject Reason is requered..!');
      err++;
    }else{
      $('#bhreject_reason_err').html('');
    }
  }
  return err===0;
}
</script>

<script>
  $(".list_page").DataTable({
    "ordering": false,
    "paging": false,
    // "aaSorting":[],
    "fixedColumns": {
      "left": 1,
      "right": 1,
    },
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<script>
  function sort_filter(val) {
      if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#search_form').submit();
      } else {
      $('.sorting_filter_class').val(10);
      $('#search_form').submit();
      }
  }
</script>
@endsection
