@extends('layouts/layoutMaster')

@section('title', 'Journal Booklet')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/js/dropdown-hover.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/clipboard/clipboard.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
    <style>
        .list_page thead th,
        .list_page tbody td {
            padding: 10px !important;
        }

        .act_bx:hover {
            background-color: #eae1fc;

        }

        .act_bx_selected {
            background-color: #fbecdb !important;
            border: 1px solid #766e6e70 !important;
        }

        .table tbody,
        tr,
        td,
        tfoot,
        th,
        thead,
        tr {
            border: 1px solid rgb(185, 185, 185) !important;
            padding: 10px !important;
        }

        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
        }

        .table thead th,
        .table tbody td {
            position: relative;
            z-index: 1;
            padding: 8px;
        }

        .table thead th {
            position: sticky;
            top: 0;
            color: #fff;
            z-index: 3;
        }

        .table thead th:first-child,
        .table thead th:nth-child(2),
        .table thead th:nth-child(3),
        .table thead th:last-child {
            position: sticky;
            background: #099dd9;
            z-index: 4;
        }



        .table tbody td:first-child,
        .table tbody td:nth-child(2),
        .table tbody td:nth-child(3),
        .table tbody td:last-child {
            position: sticky;
            background: #fff;
            z-index: 4;
        }

        .table thead th:first-child,
        .table tbody td:first-child {
            left: 0;
            min-width: 200px !important;
            max-width: 250px !important;
        }

        .table thead th:nth-child(2),
        .table tbody td:nth-child(2) {
            left: 220px;
            min-width: 200px !important;
            max-width: 200px !important;
        }

        .table thead th:nth-child(3),
        .table tbody td:nth-child(3) {
            left: 440px;
            min-width: 200px !important;
            max-width: 200px !important;
        }

        .table thead th:last-child,
        .table tbody td:last-child {
            right: 0;
        }
    </style>

    @php
        $module_name = 'Journal Management';
        $menu_name = 'Journal Booklet';
    @endphp

    <!-- Journal List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Journal Booklet</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Journal Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center flex-wrap">
                    @if (auth()->user()->hasPermission($module_name, 'Filter', $menu_name))
                        <a href="javascript:;" class="btn btn-sm fw-bold text-white btn-primary me-2 mb-2" id="filter"
                            title="Filter">
                            <i class="mdi mdi-filter-outline text-center"></i>
                        </a>
                    @endif
                    @if (auth()->user()->hasPermission($module_name, 'Add', $menu_name))
                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white mb-2" data-bs-toggle="modal"
                            data-bs-target="#kt_modal_add_journal_booklet">
                            <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Journal Booklet
                        </a>
                    @endif
                </div>
            </div>
        </div>
        <div class="card-body">

            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-6 mb-4 ">
                            <div class="accordion" id="domainAccordion">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingDomain">
                                        <button class="accordion-button collapsed w-100 h-100" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseDomain" aria-expanded="false"
                                            aria-controls="collapseDomain"
                                            style="background:#c8efff; border-radius:8px; font-weight:600;"
                                            id="domainAccordionButton">
                                            <div class="w-100 d-flex justify-content-between align-items-center">
                                                <span class="fw-semibold fs-5">Domain</span>
                                                <span class="badge bg-danger me-1 animation-blink p-2">
                                                    <label class=" fw-semibold fs-5 text-white"
                                                        id="booklet_total_count">0</label>
                                                </span>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="collapseDomain" class="accordion-collapse collapse"
                                        aria-labelledby="headingDomain" data-bs-parent="#domainAccordion">
                                        <div class="accordion-body px-4 py-3">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="row scroll-y" style="max-height:150px; overflow-y:auto;"
                                                        id="booklet_count_container">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <div class="accordion" id="indexAccordion">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingIndex">
                                        <button class="accordion-button collapsed  w-100 h-100" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseIndex" aria-expanded="false"
                                            aria-controls="collapseIndex" style="background:#f8e39c;  font-weight:600;"
                                            id="indexAccordionButton">
                                            <div class="w-100 d-flex justify-content-between align-items-center">
                                                <span class="fw-semibold fs-5">Index</span>
                                                <span class="badge bg-danger me-1 animation-blink p-2">
                                                    <label class=" fw-semibold fs-5 text-white"
                                                        id="index_total_count">0</label>
                                                </span>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="collapseIndex" class="accordion-collapse collapse"
                                        aria-labelledby="headingIndex" data-bs-parent="#indexAccordion">
                                        <div class="accordion-body px-4 py-3">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="row scroll-y" style="max-height:150px; overflow-y:auto;"
                                                        id="index_count_container">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="filter_tbox" style="display: none;">
                    <form id="search_form" method="POST" action="/journal_management/journal_booklet">
                        <div class="row py-1">
                            @csrf
                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                            <input type="hidden" name="filter_on" value="1">
                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                                value="@php echo $perpage ? $perpage : 10; @endphp" />
                            <div class="col-lg-3 mb-2">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <select class="select3 form-select" id="domain_fill" name="domain_fill">
                                    <option value="" selected>All</option>
                                    @foreach ($domains as $domain)
                                        <option value="{{ $domain->sno }}"
                                            {{ $domain_fill == $domain->sno ? 'selected' : '' }}>
                                            {{ $domain->domain_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-lg-3 mb-2">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal Index</label>
                                <select class="select3 form-select" id="index_fill" name="index_fill">
                                    <option value="" selected>All</option>
                                    @foreach ($filter_index as $index)
                                        <option value="{{ $index->sno }}"
                                            {{ $index_fill == $index->sno ? 'selected' : '' }}>
                                            {{ $index->index_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-lg-3 mb-2">
                                <label class="text-black mb-1 fs-6 fw-semibold d-block">Journal Payment Type</label>
                                <div class="mt-2">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="payment_type_fill"
                                            id="payment_free_fill" value="0"
                                            {{ $payment_type_fill == 0 ? 'checked' : '' }}>
                                        <label class="form-check-label fs-6 fw-semibold"
                                            for="payment_free_fill">Free</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="payment_type_fill"
                                            id="payment_paid_fill" value="1"
                                            {{ $payment_type_fill == 1 ? 'checked' : '' }}>
                                        <label class="form-check-label fs-6 fw-semibold"
                                            for="payment_paid_fill">Paid</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="payment_type_fill"
                                            id="payment_hybrid_fill" value="2"
                                            {{ $payment_type_fill == 2 ? 'checked' : '' }}>
                                        <label class="form-check-label fs-6 fw-semibold"
                                            for="payment_hybrid_fill">Hybrid</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                            <a href="{{ url('/journal_management/journal_booklet') }}" type="button"
                                class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
                            <button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Go</button>
                        </div>
                    </form>
                </div>
                <div class="row mb-4 mt-4">
                    @php $perpage_count = $perpage ? $perpage : 10; @endphp
                    <div class="col-lg-2">
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                            onchange="sort_filter(this.value);">
                            @php
                                $options = [10, 25, 100, 500]; // Define available options
                            @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}"
                                    @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                                    @php echo $option; @endphp
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-lg-10 d-flex align-items-end justify-content-end">
                        <form id="search_form" method="POST" action="/journal_management/journal_booklet">
                            @csrf
                            <div class="d-flex align-items-center gap-2 mt-2">
                                <div>
                                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                    <input type="hidden" name="filter_on" value="0">
                                    <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                        id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                    <input type="text" class="form-control" id="search_fill" name="search_fill"
                                        value="{{ $search_fill ?? '' }}" placeholder="Enter Search" />
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                    onclick="search_filter_func()">Search</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-125px max-w-250px">Journal</th>
                                    <th class="min-w-200px">Domain / Payment Type</th>
                                    <th class="min-w-200px">Publisher</th>
                                    @foreach ($indices as $index)
                                        <th class="w-100" style="background-color:rgb(211, 143, 84) !important;">
                                            <div class="" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                style="width:max-content !important" title="{{ $index->index_name }}">
                                                {{ $index->index_name }}</div>
                                        </th>
                                    @endforeach
                                    <!-- <th class="min-w-100px">Status</th> -->
                                    <th class="min-w-100px">Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-gray-600 fw-semibold fs-7">
                                @if (auth()->user()->hasPermission($module_name, 'List', $menu_name))
                                    @foreach ($books as $book)
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="text-black fw-semibold fs-7">{{ $book->journal_name }}
                                                    </div>
                                                    <a href="{{ $book->journal_link }}" class="ms-1"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Journal Link" target="_blank"><i
                                                            class="mdi mdi-link-variant text-danger fs-4"></i></a>
                                                </div>
                                            </td>
                                            @php
                                                $domainNames = [];
                                                $domainIds = json_decode($book->domain_id ?? '[]');
                                                foreach ($domainIds as $id) {
                                                    $domain = $domains->firstWhere('sno', $id);
                                                    if ($domain) {
                                                        $domainNames[] = $domain->domain_name;
                                                    }
                                                }
                                            @endphp
                                            <td>
                                                <div class="fw-semibold text-black fs-7 text-truncate max-w-250px"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="{{ implode(', ', $domainNames) }}">
                                                    {{ implode(', ', $domainNames) }}
                                                </div>
                                                <div>
                                                    @if ($book->free_paid_check == 0)
                                                        <label class="bg-success p-1 fs-8 rounded text-white">Free</label>
                                                    @elseif($book->free_paid_check == 1)
                                                        <label class="bg-primary p-1 fs-8 rounded text-white">Paid -
                                                            {{ $book->currency_symbol }} {{ $book->amount ?? 0 }}</label>
                                                    @elseif($book->free_paid_check == 2)
                                                        <label class="bg-info p-1 fs-8 rounded text-white">Hybrid -
                                                            {{ $book->currency_symbol }} {{ $book->amount ?? 0 }}</label>
                                                    @endif
                                                </div>
                                            </td>
                                            <td>{{ $book->publisher }}</td>
                                            @php
                                                $scoreMap = collect(
                                                    json_decode($book->journal_score ?? '[]', true),
                                                )->keyBy('journal_index_id');
                                            @endphp

                                            @foreach ($indices as $index)
                                                @php
                                                    $score = $scoreMap[$index->sno]['score'] ?? null;
                                                @endphp
                                                <td align="center">
                                                    <label
                                                        class="text-black fw-semibold fs-6">{{ $score !== null && $score !== '' ? $score : '-' }}</label>
                                                    @if ($score !== null && $score !== '')
                                                        <a href="{{ $index->index_url ?? '#' }}" class="ms-1"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Journal Index Link" target="_blank">
                                                            <i class="mdi mdi-link-variant text-danger fs-4"></i>
                                                        </a>
                                                    @endif
                                                </td>
                                            @endforeach
                                            <td>
                                                <span class="text-center">
                                                    @if (auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                                        <a href="#" class="btn btn-icon btn-sm me-2"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_view_journal_booklet"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            onclick="viewModal('{{ $book->sno }}')" title="View">
                                                            <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                                                        </a>
                                                    @endif
                                                    @if (auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                                                        <a href="#" class="btn btn-icon btn-sm"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_edit_journal_booklet"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            onclick="editModal('{{ $book->sno }}')" title="Edit">
                                                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                                        </a>
                                                    @endif
                                                </span>
                                            </td>
                                        </tr>
                                    @endforeach
                                @else
                                    <tr>
                                        <td>Unauthorized Access</td>
                                        <td></td>
                                        @foreach ($indices as $index)
                                            <td>
                                            </td>
                                        @endforeach
                                        <td></td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-4">
                        {{ $books->appends(request()->except(['page', '_token']))->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--begin::Modal - Add Journal Booklet-->
    <div class="modal fade" id="kt_modal_add_journal_booklet" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Create Journal booklet</h3>
                    </div>
                    <form method="POST" action="{{ route('create_journal_booklet') }}" id="add_validation">
                        @csrf
                        <div class="row">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Journal Name"
                                    id="journal_name" name="journal_name" />
                                <p id="journal_name_error" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal Link<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Journal Link"
                                    id="journal_link" name="journal_link" />
                                <p id="journal_link_error" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Country<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" data-placeholder="Select Country" id="country_id"
                                    name="country_id">
                                    {{-- Country Dropdown Goes Here --}}
                                </select>
                                <p id="country_id_err" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Currency Format<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" data-placeholder="Select Currency" id="currency_id"
                                    name="currency_id">
                                    {{-- Currency Dropdown Goes Here --}}
                                </select>
                                <p id="currency_id_err" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <div class="d-flex mt-4 justify-content-center">
                                    <div class="form-check form-check-inline mt-4">
                                        <input class="form-check-input" type="radio" name="payment_type"
                                            id="payment_free" onchange="amountHide(this.value)" value="0" checked>
                                        <label class="form-check-label fs-6 fw-semibold" for="payment_free">Free</label>
                                    </div>

                                    <div class="form-check form-check-inline mt-4">
                                        <input class="form-check-input" type="radio" name="payment_type"
                                            id="payment_paid" onchange="amountHide(this.value)" value="1">
                                        <label class="form-check-label fs-6 fw-semibold" for="payment_paid">Paid</label>
                                    </div>

                                    <div class="form-check form-check-inline mt-4">
                                        <input class="form-check-input" type="radio" name="payment_type"
                                            id="payment_hybrid" onchange="amountHide(this.value)" value="2">
                                        <label class="form-check-label fs-6 fw-semibold"
                                            for="payment_hybrid">Hybrid</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3" id="journal_booklet_amount">
                                <label class="text-black mb-1 fs-6 fw-semibold">Amount</label>
                                <input type="text" class="form-control" placeholder="Enter Amount"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '');" maxlength="6"
                                    id="journal_amount" name="journal_amount" />
                                <p id="journal_name_error" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-4">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" data-placeholder="Select Domain" id="domain_id"
                                    name="domain_id[]" multiple>
                                    @foreach ($domains as $domain)
                                        <option value="{{ $domain->sno }}">{{ $domain->domain_name }}</option>
                                    @endforeach
                                </select>
                                <p id="domain_id_error" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">ISSN<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter ISSN" maxlength="70"
                                    id="journal_issn" name="journal_issn" />
                                <p id="journal_issn_err" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Publisher<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Publisher" maxlength="70"
                                    id="publisher" name="publisher" />
                                <div id="publisher_err" class="text-danger mt-1"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" placeholder="Enter Description" name="journal_desc"></textarea>
                            </div>
                            <label class="text-danger mb-1 fs-5 fw-semibold">Jounal Index</label>
                            <div class="scroll-y max-h-300px  border border-gray-300i px-3 pt-2 mb-4">
                                <div class="row pt-3 pb-3">
                                    @foreach ($indices as $index)
                                        <div class="col-lg-6">
                                            <div class="row mb-1">
                                                <div class="col-lg-8">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input jin_chk" type="checkbox"
                                                            id="jin_chk_{{ $loop->index }}"
                                                            name="journal_indices[{{ $index->sno }}][id]"
                                                            onclick="toggleScoreInput(this);"
                                                            value="{{ $index->sno }}">
                                                        <label class="text-black fs-7 fw-semibold"
                                                            for="jin_chk_{{ $loop->index }}">{{ $index->index_name }}</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="mb-0 chk_1_tbox" style="display: none;">
                                                        <input type="text"
                                                            class="form-control fs-7 text-center pt-1 pb-1 px-0"
                                                            placeholder="Score"
                                                            name="journal_indices[{{ $index->sno }}][score]"
                                                            oninput="
                                                    // Allow only digits and one dot
                                                    this.value = this.value.replace(/[^0-9.]/g, '');
                                                    
                                                    // Allow only one dot
                                                    const parts = this.value.split('.');
                                                    if(parts.length > 2) {
                                                    this.value = parts[0] + '.' + parts.slice(1).join('');
                                                    }
                                                    
                                                    // Limit the value to max 100 if it's a valid number
                                                    if (this.value !== '' && !isNaN(this.value)) {
                                                    const num = parseFloat(this.value);
                                                    if (num > 100) {
                                                    this.value = '100';
                                                    }
                                                    }
                                                    "
                                                            maxlength="10" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                            <p id="check_box_error" class="text-danger mt-1"></p>
                            <div class="form-repeater_jorn_bklt_create">
                                <div data-repeater-list="group-a_jorn_bklt">
                                    <div data-repeater-item>
                                        <div class="row booklet_row">
                                            <div class="col-lg-5 mb-1">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Contact No</label>
                                                <input type="text" class="form-control" placeholder="Enter Contact No"
                                                    name="contact[]"
                                                    oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                                                <p class="text-danger mt-1 num_error"></p>
                                            </div>
                                            <div class="col-lg-5 mb-1">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Email ID</label>
                                                <input type="text" class="form-control" placeholder="Enter Email ID"
                                                    name="email[]" />
                                                <p class="text-danger mt-1 email_error"></p>
                                            </div>
                                            <div class="col-lg-2 mb-1">
                                                <a href="javascript:;"
                                                    class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_create_del"
                                                    id="jorn_bklt_create_del" style="display: none !important;">
                                                    <i class="mdi mdi-delete fs-4"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="bookletContainer"></div>
                            <div class="mb-4 mt-1">
                                <button type="button" class="btn btn-sm btn-primary jorn_bklt_create_add fs-8 px-2 py-1"
                                    data-repeater-create id="jorn_bklt_create_add">
                                    <i class="mdi mdi-plus me-1"></i> Add More
                                </button>
                            </div>
                        </div>

                        <div class="d-flex justify-content-center align-items-center mt-8">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Create Journal Booklet</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Journal Booklet-->


    <!--begin::Modal - Update Journal Booklet-->
    <div class="modal fade" id="kt_modal_edit_journal_booklet" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Update Journal Booklet</h3>
                    </div>
                    <form action="{{ route('update_journal_booklet') }}" method="POST" id="edit_validation">
                        @csrf
                        <div class="row">
                            <div class="col-lg-4 mb-3">
                                <input type="hidden" name="edit_id" id="edit_name">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Journal Name"
                                    id="edit_journal_name" name="edit_journal_name" />
                                <p id='edit_journal_name_error' class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal Link<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Journal Link"
                                    name="edit_journal_link" id="edit_journal_link" />
                                <p id="edit_journal_link_error" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-4">
                                <label class="text-black mb-1 fs-6 fw-semibold">Country<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" data-placeholder="Select Country"
                                    id="edit_country_id" name="edit_country_id">
                                    {{-- Country Dropdown Goes Here --}}
                                </select>
                                <p id="edit_country_id_err" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-4">
                                <label class="text-black mb-1 fs-6 fw-semibold">Currency<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" data-placeholder="Select Currency"
                                    id="edit_currency_id" name="edit_currency_id">
                                    {{-- currency Dropdown Goes Here --}}
                                </select>
                                <p id="edit_currency_id_err" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold d-block">Payment <span
                                        class="text-danger">*</span></label>

                                <div class="d-flex align-items-center gap-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="edit_payment_type"
                                            onchange="editAmountHide(this.value)" id="edit_payment_free" value="0"
                                            checked>
                                        <label class="form-check-label" for="edit_payment_free">Free</label>
                                    </div>

                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="edit_payment_type"
                                            onchange="editAmountHide(this.value)" id="edit_payment_paid" value="1">
                                        <label class="form-check-label" for="edit_payment_paid">Paid</label>
                                    </div>

                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="edit_payment_type"
                                            onchange="editAmountHide(this.value)" id="edit_payment_hybrid"
                                            value="2">
                                        <label class="form-check-label" for="edit_payment_hybrid">Hybrid</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3" id="edit_journal_booklet_amount">
                                <label class="text-black mb-1 fs-6 fw-semibold">Amount</label>
                                <input type="text" class="form-control" placeholder="Enter Amount"
                                    id="edit_journal_amount" oninput="this.value = this.value.replace(/[^0-9]/g, '');"
                                    name="edit_journal_amount" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" data-placeholder="Select Domain" id="edit_domain_id"
                                    name="edit_domain_id[]" multiple>
                                    @foreach ($domains as $domain)
                                        <option value="{{ $domain->sno }}">{{ $domain->domain_name }}</option>
                                    @endforeach
                                </select>
                                <p id="edit_domain_id_error" class="text-danger mt-1"></p>
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">ISSN</label>
                                <input type="text" class="form-control" placeholder="Enter ISSN"
                                    id="edit_journal_issn" name="edit_journal_issn" />
                                <p id="edit_journal_issn_error" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Publisher</label>
                                <input type="text" class="form-control" placeholder="Enter Publisher"
                                    id="edit_publisher" name="edit_publisher" />
                                <p id="edit_publisher_err" class="text-danger mt-1"></p>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" id="edit_desc" name="edit_desc" placeholder="Enter Description"></textarea>
                            </div>
                            <label class="text-danger mb-1 fs-5 fw-semibold">Jounal Index</label>
                            <div class="scroll-y max-h-300px  border border-gray-300i px-3 pt-2 mb-4">
                                <div class="row pt-3 pb-3">
                                    @foreach ($indices as $index)
                                        <div class="col-lg-6">
                                            <div class="row mb-1">
                                                <div class="col-lg-8 mb-1">
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input edit_jin_chk" type="checkbox"
                                                            id=""
                                                            name="edit_journal_indices[{{ $index->sno }}][id]"
                                                            value="{{ $index->sno }}">
                                                        <label
                                                            class="text-black fs-7 fw-semibold">{{ $index->index_name }}</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="mb-0 chk_2_tbox" style="display: none;">
                                                        <input type="text"
                                                            class="form-control fs-7 text-center pt-1 pb-1 px-0"
                                                            placeholder="Score"
                                                            name="edit_journal_indices[{{ $index->sno }}][score]"
                                                            oninput="
                                                    // Allow only digits and one dot
                                                    this.value = this.value.replace(/[^0-9.]/g, '');
                                                    
                                                    // Allow only one dot
                                                    const parts = this.value.split('.');
                                                    if(parts.length > 2) {
                                                    this.value = parts[0] + '.' + parts.slice(1).join('');
                                                    }
                                                    
                                                    // Limit the value to max 100 if it's a valid number
                                                    if (this.value !== '' && !isNaN(this.value)) {
                                                    const num = parseFloat(this.value);
                                                    if (num > 100) {
                                                    this.value = '100';
                                                    }
                                                    }
                                                    "
                                                            maxlength="10" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                            <p id="edit_check_box_error" class="text-danger mt-1"></p>
                            <div class="form-repeater_jorn_bklt_update">
                                <div data-repeater-list="group-a_jorn_bklt">
                                    <div data-repeater-item>
                                    </div>
                                </div>
                            </div>
                            <div id="editContainer"></div>
                            <div class="mb-4 mt-1">
                                <button type="button" class="btn btn-sm btn-primary jorn_bklt_update_add fs-8 px-2 py-1"
                                    id="jorn_bklt_update_add">
                                    <i class="mdi mdi-plus me-1"></i> Add More
                                </button>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-8">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update Journal Booklet</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Update Journal Booklet-->

    <!--begin::Modal - View Journal Booklet-->
    <div class="modal fade" id="kt_modal_view_journal_booklet" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8">
                        <h3 class="text-center text-black">View <span class="text-info fw-semibold"
                                id="view_journal_name">-</span> Details</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-2">
                                <label class="col-lg-5 text-dark fs-6 fw-semibold">Booklet Name</label>
                                <label class="col-lg-1 text-black fs-6 fw-semibold">:</label>
                                <label class="col-lg-6 text-black fs-6 fw-semibold">
                                    <span id="journal_view_name">
                                        -
                                    </span>
                                    <span id="view_journal_link_con" style="display: none;">
                                        <a href="" id="view_journal_link" class="ms-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" data-bs-original-title="Journal Link">
                                            <i class="mdi mdi-link-variant text-danger fs-4"></i>
                                        </a>
                                    </span>
                                </label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-lg-5 text-dark fs-6 fw-semibold">Payment Type</label>
                                <label class="col-lg-1 text-black fs-6 fw-semibold">:</label>
                                <label class="col-lg-6 text-black fs-6 fw-semibold" id="view_payment_type">
                                    -
                                </label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-lg-5 text-dark fs-6 fw-semibold">ISSN</label>
                                <label class="col-lg-1 text-black fs-6 fw-semibold">:</label>
                                <label class="col-lg-6 text-black fs-6 fw-semibold" id="view_journal_issn">
                                    -
                                </label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-lg-5 text-dark fs-6 fw-semibold">Domain</label>
                                <label class="col-lg-1 text-black fs-6 fw-semibold">:</label>
                                <label class="col-lg-6 text-black fs-6 fw-semibold text-truncate" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="" id="view_journal_domains">
                                    Python, Full Stach, Mechanical Engineering
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-2">
                                <label class="col-lg-5 text-dark fs-6 fw-semibold">Country</label>
                                <label class="col-lg-1 text-black fs-6 fw-semibold">:</label>
                                <label class="col-lg-6 text-black fs-6 fw-semibold"
                                    id="view_journal_country">India</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-lg-5 text-dark fs-6 fw-semibold">Currency</label>
                                <label class="col-lg-1 text-black fs-6 fw-semibold">:</label>
                                <label class="col-lg-6 text-black fs-6 fw-semibold" id="view_journal_currency">INR</label>
                            </div>
                            <div class="row mb-2" id="view_journal_amt_con">
                                <label class="col-lg-5 text-dark fs-6 fw-semibold">Amount</label>
                                <label class="col-lg-1 text-black fs-6 fw-semibold">:</label>
                                <label class="col-lg-6 text-black fs-6 fw-semibold" id="view_journal_amt">10,000</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-lg-5 text-dark fs-6 fw-semibold">Description</label>
                                <label class="col-lg-1 text-black fs-6 fw-semibold">:</label>
                                <label class="col-lg-6 text-black fs-6 fw-semibold" id="view_journal_desc"></label>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3 mt-4">
                            <div class="border border-gray-800 rounded pb-2 ">
                                <div class="d-flex align-items-center justify-content-around border-bottom rounded-top bg-label-warning"
                                    style="background-color: #228837 !important;">
                                    <div class="mb-0 ps-3 py-2">
                                        <label class="text-white fw-semibold fs-5">📜 Journal Index</label>
                                    </div>
                                </div>
                                <div class="scroll-y max-h-200px px-3 py-2 journal-index-list">
                                    <!-- Journal list will be inject here -->
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3 mt-4">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2  scroll_table">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Contact Number</th>
                                        <th class="min-w-150px">Email ID</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7" id="journal_details_view">

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Journal Booklet-->

    <!--begin::Modal - Delete Journal Booklet-->
    <div class="modal fade" id="kt_modal_delete_journal_booklet" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want
                    to
                    delete Journal Booklet ?
                    <div class="d-block fw-bold fs-5 mt-3 py-2">
                        <label class="mb-1">IEEE Internet of Things Journal</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Journal Booklet-->

    <!-- Toastr Starts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>

    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
    <!-- Toastr Ends -->

    <!-- Toggle Score Add Hide & Show Script -->
    <script>
        function toggleScoreInput(checkbox) {
            // Find the nearest .row
            const row = checkbox.closest('.row');

            // Find the score input box in that row
            const scoreBox = row.querySelector('.chk_1_tbox');

            // Toggle display based on checkbox status
            if (checkbox.checked) {
                scoreBox.style.display = "block";
            } else {
                scoreBox.style.display = "none";
            }
        }
    </script>

    <!-- Filter Box Script -->
    <script>
        $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.filter_tbox').slideToggle('fast');
                $('#domainAccordionButton').click();
                $('#indexAccordionButton').click();
            @endif
        });
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>

    <!-- Sort Filter Script -->
    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>

    <!-- Data Table Script -->
    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>

    <!-- Booklet Row Add Script -->
    <script>
        document.getElementById('jorn_bklt_create_add').addEventListener('click', function() {
            var newBookleteDetails =
                `<div class="row booklet_row">
                    <div class="col-lg-5 mb-1">
                        <label class="text-black mb-1 fs-6 fw-semibold">Contact No</label>
                        <input type="text" class="form-control" placeholder="Enter Contact No" name="contact[]" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                        <p class="text-danger mt-1 num_error"></p>
                    </div>
                    <div class="col-lg-5 mb-1">
                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID</label>
                        <input type="text" class="form-control" placeholder="Enter Email ID" name="email[]" />
                        <p class="text-danger mt-1 email_error"></p>
                    </div>
                    <div class="col-lg-2 mb-1">
                        <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_create_del"
                            id="jorn_bklt_create_del">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
        </div>`;
            document.getElementById('bookletContainer').insertAdjacentHTML('beforeend', newBookleteDetails);
        })

        $(document).on('click', '.jorn_bklt_create_del', function() {
            $(this).closest('.row').remove();
        })
    </script>

    <!-- Booklet Row Edit Script -->
    <script>
        document.getElementById('jorn_bklt_update_add').addEventListener('click', function() {
            var editBooklet = `
        <div class="row contact-row mb-3">
            <div class="col-lg-5 mb-1">
                <label class="text-black mb-1 fs-6 fw-semibold">Contact No</label>
                <input type="text" class="form-control" name="edit_contact_no[]" oninput="this.value = this.value.replace(/[^0-9]/g, '')" placeholder="Enter Contact No" />
            </div>
            <div class="col-lg-5 mb-1">
                <label class="text-black mb-1 fs-6 fw-semibold">Email ID</label>
                <input type="text" class="form-control" name="edit_email[]" placeholder="Enter Email ID" />
            </div>
            <div class="col-lg-2 mb-1 d-flex align-items-end">
                <a href="javascript:;" class="btn btn-outline-danger px-2 py-1 jorn_bklt_update_del">
                    <i class="mdi mdi-delete fs-4"></i>
                </a>
            </div>
        </div>`;
            document.getElementById('editContainer').insertAdjacentHTML('beforeend', editBooklet);
        })

        $(document).on('click', '.jorn_bklt_update_del', function() {
            $(this).closest('.row').remove();
        })
    </script>

    <!-- Add Validation -->
    <script>
        function validateEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }

        $('#add_validation').on('submit', function(e) {
            let isValid = true;

            // Clear previous error messages
            $('#journal_name_error, #journal_link_error, #domain_id_error, #check_box_error, #country_id_err, #currency_id_err,#publisher_err')
                .text('');
            $('.num_error, .email_error').text('');
            $('.is-invalid').removeClass('is-invalid');

            // Journal Name
            if ($('#journal_name').val().trim() === '') {
                $('#journal_name_error').text('Enter the Journal Name.');
                isValid = false;
            }

            // Journal Link
            if ($('#journal_link').val().trim() === '') {
                $('#journal_link_error').text('Enter the Journal Link.');
                isValid = false;
            }

            // Domain Id
            const selectedDomains = $('#domain_id').val();
            if (!selectedDomains || selectedDomains.length === 0) {
                $('#domain_id_error').text('Select at least one domain.');
                isValid = false;
            }

            // Country Id
            const selectedCountry = $('#country_id').val();
            if (!selectedCountry || selectedCountry.length === 0) {
                $('#country_id_err').text('Select Country.');
                isValid = false;
            }

            // Currency Id
            const selectedCurrency = $('#currency_id').val();
            if (!selectedCurrency || selectedCurrency.length === 0) {
                $('#currency_id_err').text('Select Currency.');
                isValid = false;
            }

            if ($('#journal_issn').val() === '') {
                $('#journal_issn_err').text('ISSN is required.');
                isValid = false;
            }
            // Publisher
            if ($('#publisher').val() === '') {
                $('#publisher_err').text('Enter Publisher.');
                isValid = false;
            }

            // Score Validation
            $('#check_box_error').text('');
            $('.jin_chk').each(function() {
                const checkbox = $(this);
                const row = checkbox.closest('.row');
                const scoreInput = row.find('.chk_1_tbox input');

                if (checkbox.is(':checked')) {
                    if ($.trim(scoreInput.val()) === '') {
                        isValid = false;
                        $('#check_box_error').text('Enter Score.');
                        scoreInput.css('border', '2px solid red');
                    } else {
                        scoreInput.css('border', '');
                    }
                } else {
                    scoreInput.css('border', '');
                }
            });

            // Contact Details Validation
            // $('.booklet_row').each(function () {
            //     const emailInput = $(this).find('input').eq(1);

            //     const emailVal = emailInput.val().trim();

            //     // Clear previous errors
            //     $(this).find('.email_error').text('');
            //     emailInput.removeClass('is-invalid');

            //     if (emailVal === '') {
            //             $(this).find('.email_error').text('Enter Email ID');
            //             isValid = false;
            //         } else if (!validateEmail(emailVal)) {
            //             $(this).find('.email_error').text('Enter valid Email ID');
            //             isValid = false;
            //     }
            // });

            if (!isValid) {
                e.preventDefault(); // prevent form submit if invalid
            }
        });
    </script>

    <!-- View Journal Booklet -->
    <script>
        function viewModal(id) {
            fetch(`/view_journal_booklet/${id}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 200) {
                        const book = data.data.book;
                        const domains = data.data.domains;
                        const indices = data.data.indices;

                        const journalName = book.journal_name || '-';

                        document.getElementById('view_journal_name').textContent = journalName;
                        document.getElementById('journal_view_name').textContent = journalName;

                        if (book.journal_link) {
                            $('#view_journal_link_con').show();
                            $('#view_journal_link').attr('href', book.journal_link);
                        } else {
                            $('#view_journal_link_con').hide();
                        }

                        if (book.free_paid_check === 0) {
                            $('#view_payment_type').html('Free');
                            $('#view_journal_amt_con').hide();
                        } else if (book.free_paid_check === 1) {
                            $('#view_payment_type').html('Paid');
                            $('#view_journal_amt_con').show();
                        } else if (book.free_paid_check === 2) {
                            $('#view_payment_type').html('Hybrid');
                            $('#view_journal_amt_con').show();
                        }

                        $('#view_journal_country').html(book.name ? book.name : 'India');
                        $('#view_journal_currency').html(`(${book.currency_symbol}) ${book.currency_name}`);

                        $('#view_journal_amt').html(book.amount ? book.amount : 0);
                        $('#view_journal_issn').html(book.issn ? book.issn : '-');
                        $('#view_journal_desc').html(book.journal_desc ? book.journal_desc : '-')

                        const domainNames = Object.values(domains).join(', ') || '-';
                        const domainElement = document.getElementById('view_journal_domains');

                        domainElement.textContent = domainNames;
                        domainElement.setAttribute('title', domainNames);

                        let scoreHTML = '';
                        if (book.journal_score && book.journal_score.length > 0) {
                            book.journal_score.forEach(scoreItem => {
                                const index = indices[scoreItem.journal_index_id];
                                if (index) {
                                    scoreHTML += `
                            <div class="d-flex align-items-center px-2 py-1 mb-2 border-bottom" style="max-width: 600px; margin: auto;">
                                <div class="flex-grow-1 text-start text-black fw-semibold fs-6">
                                    ${index.index_name}
                                    <a href="${index.index_url}" class="ms-1" target="_blank" rel="noopener noreferrer">
                                        <i class="mdi mdi-link-variant text-danger fs-5"></i>
                                    </a>
                                </div>
                            
                                <div class="flex-shrink-0 px-3 fw-semibold fs-7" style="min-width: 30px; text-align: center;">
                                    <span class="mdi mdi-arrow-right-thick fs-5 text-primary fw-semibold"></span>
                                </div>
                            
                                <div class="flex-grow-1 text-end fw-semibold fs-6 text-danger">
                                    ${scoreItem.score} Score
                                </div>
                            </div>`;
                                }
                            });
                        } else {
                            scoreHTML = '<div class="text-danger fs-6 fw-semibold">No journal indices available.</div>';
                        }
                        document.querySelector('.journal-index-list').innerHTML = scoreHTML;

                        let contactHTML = '';

                        // Check The Contact No & Email Is Not Null
                        const validContacts = (book.contact_details || []).filter(contact =>
                            contact.contact_no || contact.email
                        );

                        if (validContacts.length > 0) {
                            validContacts.forEach(contact => {
                                contactHTML += `
                            <tr>
                                <td>${contact.contact_no || '-'}</td>
                                <td>${contact.email || '-'}</td>
                            </tr>`;
                            });
                        } else {
                            contactHTML = '<tr><td colspan="2">No contact details available.</td></tr>';
                        }

                        document.getElementById('journal_details_view').innerHTML = contactHTML;
                    }
                })
                .catch(error => {
                    console.log('Error Fetching :', error);
                });
        };
    </script>

    <!-- Edit Journal Booklet -->
    <script>
        function editModal(id) {
            fetch(`/view_journal_booklet/${id}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 200) {
                        const book = data.data.book;
                        const domains = data.data.domains;
                        const indices = data.data.indices;

                        const journalName = book.journal_name;
                        const journalLink = book.journal_link;

                        $('#edit_name').val(book.sno);
                        $('#edit_journal_name').val(book.journal_name);
                        $('#edit_journal_link').val(book.journal_link);
                        $('#edit_domain_id').val(book.domain_id).change();
                        $('#edit_journal_issn').val(book.issn);
                        $('#edit_publisher').val(book.publisher);
                        const selectedIndexIds = book.journal_score.map(item => item.journal_index_id.toString());

                        $('.edit_jin_chk').each(function() {
                            if (selectedIndexIds.includes($(this).val())) {
                                $(this).prop('checked', true);
                            } else {
                                $(this).prop('checked', false);
                            }
                        });

                        $('.edit_jin_chk').trigger('change');

                        book.journal_score.forEach(function(scoreObj) {
                            $(`input[name="edit_journal_indices[${scoreObj.journal_index_id}][score]"]`).val(
                                scoreObj.score);
                        });

                        const container = document.getElementById('editContainer');
                        container.innerHTML = '';

                        // Add each contact as inputs with pre-filled values
                        book.contact_details.forEach(contact => {
                            // Conditionally include the delete button HTML or an empty string
                            const deleteButtonHtml = `
                <div class="col-lg-2 mb-1 d-flex align-items-end" id="booklet_edit_del_icon" style="display: none !important;">
                    <a href="javascript:;" class="btn btn-outline-danger px-2 py-1 jorn_bklt_update_del">
                        <i class="mdi mdi-delete fs-4"></i>
                    </a>
                </div>`;

                            const contactHtml = `
                <div class="row contact-row mb-3">
                    <div class="col-lg-5 mb-1">
                        <label class="text-black mb-1 fs-6 fw-semibold">Contact No</label>
                        <input type="text" class="form-control" placeholder="Enter Contact No" name="edit_contact_no[]"
                            value="${contact.contact_no ?? ''}" />
                    </div>
                    <div class="col-lg-5 mb-1">
                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID</label>
                        <input type="email" class="form-control" placeholder="Enter Email ID" name="edit_email[]"
                            value="${contact.email ?? ''}" />
                    </div>
                    ${deleteButtonHtml}
                </div>
                `;
                            container.insertAdjacentHTML('beforeend', contactHtml);
                        });

                        if (book.contact_details.length <= 1) {
                            $('#booklet_edit_del_icon').hide();
                        } else {
                            $('#booklet_edit_del_icon').show();
                        }

                        $('#edit_desc').val(book.journal_desc);
                        var countryId = book.country_id;
                        var currencyId = book.currency_id;
                        $('#edit_journal_amount').val(book.amount);

                        $('input[name="edit_payment_type"][value="' + book.free_paid_check + '"]').prop('checked',
                            true);
                        editAmountHide(book.free_paid_check);

                        $.ajax({
                            url: "{{ route('country') }}",
                            type: "GET",
                            success: function(response) {
                                if (response.status === 200 && response.data) {
                                    var countryDropdown = $('#edit_country_id');
                                    countryDropdown.empty();
                                    countryDropdown.append('<option value="">Select Country</option>');
                                    response.data.forEach(function(country) {
                                        countryDropdown.append($('<option></option>').attr('value',
                                            country.id).text(country.name));
                                    });
                                    if (countryId) {
                                        countryDropdown.val(countryId).trigger('change');
                                    }
                                    // countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
                                }
                            },
                            error: function(error) {
                                console.error('Error fetching countries:', error);
                            }
                        });
                        // Event listener for country change
                        $('#edit_country_id').on('change', function() {
                            var editCurrency = $('#edit_currency_id');

                            editCurrency.empty().append('<option value="">Select State</option>');

                            // Fetch and populate states based on selected country
                            $.ajax({
                                url: "{{ route('currency_format') }}",
                                type: "GET",
                                success: function(response) {
                                    if (response.status === 200 && response.data) {
                                        response.data.forEach(function(currency) {
                                            editCurrency.append($('<option></option>').attr(
                                                'value', currency.sno).text(currency
                                                .currency_name + '-' + currency
                                                .currency_symbol));
                                        });
                                        if (currencyId) {
                                            editCurrency.val(currencyId).trigger('change');
                                        }
                                        // stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
                                    }
                                },
                                error: function(error) {
                                    console.error('Error fetching Currency:', error);
                                }
                            });
                        });
                    }
                })
                .catch(error => {
                    console.log('Error Fetching :', error);
                });
        }
    </script>

    <!-- Toggle Score Edit Hide & Show Script -->
    <script>
        $(document).ready(function() {
            $('.edit_jin_chk').on('change', function() {
                const $row = $(this).closest('.row');
                const $scoreBox = $row.find('.chk_2_tbox');

                if ($(this).is(':checked')) {
                    $scoreBox.show();
                } else {
                    $scoreBox.hide();
                    $scoreBox.find('input').val('');
                }
            });

            $('.edit_jin_chk').trigger('change');
        });
    </script>

    <!-- Edit Validation -->
    <script>
        function validateEditEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }

        $('#edit_validation').on('submit', function(e) {
            let isValid = true;

            // Clear previous error messages
            $('#edit_journal_name_error, #edit_journal_link_error, #edit_domain_id_error, #edit_journal_issn_error,#edit_publisher_err, #edit_check_box_error')
                .text('');
            $('.num_error, .email_error').text('');
            $('.is-invalid').removeClass('is-invalid');

            // Journal Name
            if ($('#edit_journal_name').val().trim() === '') {
                $('#edit_journal_name_error').text('Enter the Journal Name.');
                isValid = false;
            }

            // Journal Link
            if ($('#edit_journal_link').val().trim() === '') {
                $('#edit_journal_link_error').text('Enter the Journal Link.');
                isValid = false;
            }

            // Domain Id
            const selectedDomains = $('#edit_domain_id').val();
            if (!selectedDomains || selectedDomains.length === 0) {
                $('#edit_domain_id_error').text('Select at least one domain.');
                isValid = false;
            }

            if ($('#edit_journal_issn').val() === '') {
                isValid = false;
                $('#edit_journal_issn_error').text('ISSN is required.');
            }
            // Publisher
            if ($('#edit_publisher').val() === '') {
                $('#edit_publisher_err').text('Enter Publisher.');
                isValid = false;
            }

            // Score Validation
            $('#edit_check_box_error').text('');
            $('.edit_jin_chk').each(function() {
                const checkbox = $(this);
                const row = checkbox.closest('.row');
                const scoreInput = row.find('.chk_2_tbox input');

                if (checkbox.is(':checked')) {
                    if ($.trim(scoreInput.val()) === '') {
                        isValid = false;
                        $('#edit_check_box_error').text('Enter Score.');
                        scoreInput.css('border', '2px solid red');
                    } else {
                        scoreInput.css('border', '');
                    }
                } else {
                    scoreInput.css('border', '');
                }
            });


            if (!isValid) {
                e.preventDefault(); // prevent form submit if invalid
            }
        });
    </script>

    <!-- Country & Currency Data Fetch Script -->
    <script>
        $(document).ready(function() {
            // Fetch and populate countries
            $.ajax({
                url: "{{ route('country') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('#country_id');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Country</option>');
                        response.data.forEach(function(country) {
                            countryDropdown.append($('<option></option>').attr('value', country
                                .id).text(country.name));
                        });
                        // countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });

            $('#country_id').on('change', function() {
                var currencyDropdown = $('#currency_id');

                currencyDropdown.empty().append('<option value="">Select Currency Format</option>');

                $.ajax({
                    url: "{{ route('currency_format') }}",
                    type: "GET",
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(currency) {
                                currencyDropdown.append(
                                    $('<option>', {
                                        value: currency.sno,
                                        text: currency.currency_name + ' - ' +
                                            currency.currency_symbol
                                    })
                                );
                            });
                        } else {
                            console.error('Invalid response data', response);
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Currency:', error);
                    }
                });
            });
        });
    </script>

    <!-- Amount Hide & Show -->
    <script>
        $(document).ready(function() {
            amountHide($('input[name="payment_type"]:checked').val());
            editAmountHide($('input[name="edit_payment_type"]:checked').val());
        });

        function amountHide(sno) {
            if (sno == 0) {
                $('#journal_booklet_amount').hide();
                $('#journal_amount').val('');
                // $('#journal_amount_error').text('');

            } else {
                $('#journal_booklet_amount').show();
            }
        }

        function editAmountHide(sno) {
            if (sno == 0) {
                $('#edit_journal_booklet_amount').hide();
                $('#edit_journal_amount').val('');
                // $('#edit_journal_amount_err').text('');
            } else {
                $('#edit_journal_booklet_amount').show();
            }
        }
    </script>

    <!-- GET BOOKLET COUNT  -->
    <script>
        $(document).ready(function() {
            getBookletCount();
            getIndexCount();
        });

        function getBookletCount() {
            $.ajax({
                url: '/get_domain_name_and_count',
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const data = response.data;
                        const bookletContainer = $('#booklet_count_container');
                        let totalCount = 0;
                        let html = '';

                        data.forEach(count => {

                            totalCount++;

                            let formattedCount = parseInt(count.booklet_count) > 0 ?
                                String(count.booklet_count).padStart(2, '0') :
                                "0";

                            html += `
                            <div class="col-lg-6 mb-2">
                                <div class="p-3 d-flex justify-content-between align-items-center shadow-sm "
                                    style="border-radius:10px; background:#d4f0ff; cursor: pointer;" onclick="domain_fill_change(${count.sno})">
                                    <span class="fw-semibold text-dark fs-7">${count.domain_name}</span>
                                    <span class="badge  " style="background:#0277bd;">${formattedCount}</span>
                                </div>
                            </div>
                        `;
                        });

                        bookletContainer.html(html);
                        $('#booklet_total_count').html(totalCount);
                    } else {
                        console.error('Error Fetching.');
                    }
                },
                error: function(err) {
                    console.error('Error Fetching.');
                }
            })
        }

        function domain_fill_change(val) {
            $('#domain_fill').val(val).change();
            $('#search_form').submit();

        }

        function index_fill_change(val) {
            $('#index_fill').val(val).change();
            $('#search_form').submit();

        }

        function getIndexCount() {
            $.ajax({
                url: '/get_index_name_and_count',
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const data = response.data;
                        const indexContainer = $('#index_count_container');
                        let totalCount = 0;
                        let html = '';

                        data.forEach(index => {

                            totalCount++;

                            let formattedCount = parseInt(index.booklet_count) > 0 ?
                                String(index.booklet_count).padStart(2, '0') :
                                "0";

                            html += `
                            <div class="col-lg-6 mb-2">
                                <div class="p-3 d-flex justify-content-between align-items-center shadow-sm"
                                    style="border-radius:10px; background:#fff8e1; color:#ff6f00;cursor: pointer;" onclick="index_fill_change(${index.sno})">
                                    <span class="fw-semibold text-dark fs-7">${index.index_name}</span>
                                    <span class="badge  " style="background:#ff6f00;">${formattedCount}</span>
                                </div>
                            </div>
                        `;
                        });

                        indexContainer.html(html);
                        $('#index_total_count').html(totalCount);
                    } else {
                        console.error('Error Fetching.');
                    }
                },
                error: function(err) {
                    console.error('Error Fetching.');
                }
            })
        }
    </script>

@endsection
