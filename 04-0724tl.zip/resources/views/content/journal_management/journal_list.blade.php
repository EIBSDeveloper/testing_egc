@extends('layouts/layoutMaster')

@section('title', 'Journal List')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
    .modal-xxl {
        max-width: 85% !important;
    }

    /* From Uiverse.io by doniaskima */
    .btn-23,
    .btn-23 *,
    .btn-23 :after,
    .btn-23 :before,
    .btn-23:after,
    .btn-23:before {
        border: 0 solid;
        box-sizing: border-box;
    }

    .btn-23 {
        -webkit-tap-highlight-color: transparent;
        -webkit-appearance: button;
        background-color: #000;
        background-image: none;
        color: #fff;
        cursor: pointer;
        font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Arial, Noto Sans, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
        font-size: 100%;
        font-weight: 900;
        line-height: 1.5;
        margin: 0;
        -webkit-mask-image: -webkit-radial-gradient(#000, #fff);
        padding: 0;
        text-transform: uppercase;
    }

    .btn-23:disabled {
        cursor: default;
    }

    .btn-23:-moz-focusring {
        outline: auto;
    }

    .btn-23 svg {
        display: block;
        vertical-align: middle;
    }

    .btn-23 [hidden] {
        display: none;
    }

    .btn-23 {
        border-radius: 99rem;
        border-width: 2px;
        overflow: hidden;
        padding: 0.8rem 3rem;
        position: relative;
    }

    .btn-23 span {
        display: grid;
        inset: 0;
        place-items: center;
        position: absolute;
        transition: opacity 0.2s ease;
    }

    .btn-23 .marquee {
        --spacing: 5em;
        --start: 0em;
        --end: 5em;
        -webkit-animation: marquee 3s linear infinite;
        animation: marquee 3s linear infinite;
        -webkit-animation-play-state: paused;
        animation-play-state: paused;
        opacity: 0;
        position: relative;
        color: #fff;
        text-shadow: none;
    }

    .btn-23:hover .marquee {
        -webkit-animation-play-state: running;
        animation-play-state: running;
        opacity: 1;
    }

    .btn-23:hover .text {
        opacity: 0;
    }

    @-webkit-keyframes marquee {
        0% {
            transform: translateX(var(--start));
        }

        to {
            transform: translateX(var(--end));
        }
    }

    @keyframes marquee {
        0% {
            transform: translateX(var(--start));
        }

        to {
            transform: translateX(var(--end));
        }
    }

    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }

    .indv_cust_jour thead th,
    .indv_cust_jour tbody td {
        padding: 8px !important;
        border: 1px solid rgb(180, 180, 180) !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>
<!-- Journal List Table -->

@php
$helper = new \App\Helpers\Helpers();
$module_name = 'Journal Management';
$menu_name = 'Manage Journal';
@endphp
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Journal List</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Journal Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center flex-wrap">
                <a href="javascript:;" class="btn btn-sm fw-bold text-white btn-primary me-2 mb-2" id="filter" title="Filter">
                    <i class="mdi mdi-filter-outline text-center"></i>
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="filter_tbox" style="display: none;">
            <form id="filter_form" method="POST" action="/journal_list">
                @csrf
                <input type="hidden" name="page" value="{{ request('page', 1)}}">
                <input type="hidden" name="filter_on" value="1">
                <input type="hidden" name="fill_chk" value="1">
                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                    value="25" />
                <div class="row py-1">
                    <input type="hidden" name="page" value="">
                    <div class="col-lg-3 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Customer Name</label>
                        <input type="text" class="form-control" placeholder="Enter Customer Name" id="customer_fill"
                            name="customer_fill" value="{{$customer_fill}}" />
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Customer ID</label>
                        <input type="text" class="form-control" placeholder="Enter Customer ID" id="customer_id_fill"
                            name="customer_id_fill" value="{{$customer_id_fill}}" />
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Booklet</label>
                        <select class="select3 form-select" name="booklet_fill">
                            <option value="">All</option>
                            @foreach ($books as $book)
                                <option value="{{ $book->sno }}" @if($book->sno == $booklet_fill) selected @endif >{{ $book->journal_name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-end mb-4 align-items-center">
                    <a href="{{ url('/journal_list') }}" type="button"
                        class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
                    <button type="submit" class="btn btn-sm btn-primary">Go</button>
                </div>
            </form>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="row mb-2">
                    @php $perpage_count = $perpage ? $perpage : 1; @endphp
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                            onchange="sort_filter(this.value);">
                            @php
                            $options = [10, 25, 100, 500]; // Define available options
                            @endphp
                            @php foreach ($options as $option): @endphp
                            <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ;
                                @endphp>
                                @php echo $option; @endphp
                            </option>
                            @php endforeach; @endphp
                        </select>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Services</th>
                                <th class="min-w-150px">Journal Co Ordinator</th>
                                <th class="min-w-150px">Journal Staff</th>
                                <th class="min-w-150px">Customers</th>
                                <th class="min-w-100px text-center">Submitted</th>
                                <th class="min-w-100px text-center">Reviewed</th>
                                <th class="min-w-100px text-center">Resubmitted</th>
                                <th class="min-w-100px text-center">Accepted</th>
                                <th class="min-w-100px text-center">Rejected</th>
                                <th class="min-w-100px text-center">Published</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7">
                            @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                            @foreach($fetch as $i => $f)
                            <tr id="indv_cust_hd_{{$f->sno}}">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;"
                                            class="bg-label-secondary border border-gray-400i rounded px-1 py-1"
                                            onclick="open_func({{$i}});">
                                            <i class="mdi mdi-plus fs-4" id="plus_btn{{$i}}"></i>
                                        </a>
                                        <div class="mb-0 mx-2">
                                            <label class="fw-semibold text-black fs-7 text-wrap min-w-200px max-w-275px"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="{{$f->service_name}}">{{$f->service_name}}</label>
                                            <div class="d-block mb-1">
                                                <label
                                                    class="fw-semibold text-dark fs-8 text-wrap min-w-200px max-w-275px"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Services Category">{{$f->category_name}}</label>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    @if($f->jc_staff)
                                    @if ($f->jc_image != '' && file_exists(public_path('staff_images/' .$f->jc_image)))
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{ asset('staff_images/' . $f->jc_image) }}" alt="user-avatar"
                                                class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    @else
                                    <div class="symbol symbol-35px me-2">
                                        @php
                                        $initial = strtoupper(substr($f->jc_name, 0, 1));
                                        @endphp
                                    </div>
                                    @endif
                                    @else
                                    <label class="fw-semibold text-black fs-7">-</label>
                                    @endif
                                </td>
                                <td>
                                    @if($f->js_name)
                                    @if ($f->js_image != '' && file_exists(public_path('staff_images/' .$f->js_image)))
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{ asset('staff_images/' . $f->js_image) }}" alt="user-avatar"
                                                class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    @else
                                    <div class="symbol symbol-35px me-2">
                                        @php
                                        $initial = strtoupper(substr($f->js_name, 0, 1));
                                        @endphp
                                    </div>
                                    @endif
                                    @else
                                    <label class="fw-semibold text-black fs-7">-</label>
                                    @endif
                                </td>
                                <td>
                                    <label class="text-black fw-semibold fs-7" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="{{$f->cus_name}}">{{$f->cus_name}}</label>
                                    <div class="d-block">
                                        <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Customer ID">{{$f->cus_id}}</div>
                                    </div>
                                </td>
                                <td align="center">
                                    <label class="badge bg-primary fw-semibold text-white fs-5 px-4 py-2"
                                        style="background-color: #007BFF !important;">{{$f->submitted_count ??
                                        0}}</label>
                                </td>
                                <td align="center">
                                    <label class="badge bg-primary fw-semibold text-black fs-5 px-4 py-2"
                                        style="background-color: #FFA500 !important;">{{$f->review_count ?? 0}}</label>
                                </td>
                                <td align="center">
                                    <label class="badge bg-primary fw-semibold text-white fs-5 px-4 py-2"
                                        style="background-color: #800080 !important;">{{$f->resubmitted_count ??
                                        0}}</label>
                                </td>
                                <td align="center">
                                    <label class="badge bg-primary fw-semibold text-white fs-5 px-4 py-2"
                                        style="background-color: #28A745 !important;">{{$f->accepted_count ??
                                        0}}</label>
                                </td>
                                <td align="center">
                                    <label class="badge bg-primary fw-semibold text-white fs-5 px-4 py-2"
                                        style="background-color: #DC3545 !important;">{{$f->rejected_count ??
                                        0}}</label>
                                </td>
                                <td align="center">
                                    <label class="badge bg-primary fw-semibold text-white fs-5 px-4 py-2"
                                        style="background-color: #17A2B8 !important;">{{$f->published_count ??
                                        0}}</label>
                                </td>
                            </tr>
                            @php
                            $monitorData = $helper->get_journal_monitor_list($f->manage_sno);
                            @endphp
                            <tr id="colse_tr_div{{$i}}" style="display:none;background-color: #efffdd52;">
                                <td colspan="9">
                                    <table class="table align-top gy-1 gs-2 indv_cust_jour">
                                        <thead>
                                            <tr class="text-start align-top fs-6 gs-0">
                                                <th class="min-w-50px text-black fw-semibold text-center">S.No</th>
                                                <th class="min-w-150px text-black fw-semibold">Journal Booklet</th>
                                                <th class="min-w-150px text-black fw-semibold">Paper</th>
                                                <th class="min-w-175px text-black fw-semibold">Domain</th>
                                                <th class="min-w-100px text-black text-center fw-semibold">Author /
                                                    Published Date</th>
                                                <th class="min-w-100px text-black text-center fw-semibold">Published URL
                                                </th>
                                                <th class="min-w-100px text-black fw-semibold">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                            @foreach ($monitorData as $mi => $mlist)
                                            @php
                                            $data = $helper->get_journal_monitor_paper($mlist->sno);

                                            $statusColors = [
                                            0 => ['row' => '#CCE5FF', 'badge' => '#007BFF', 'label' => 'Submitted'],
                                            1 => ['row' => '#FFE6B3', 'badge' => '#FFA500', 'label' => 'Reviewed'],
                                            2 => ['row' => '#e5c1e5', 'badge' => '#DC3545', 'label' => 'Rejected'],
                                            3 => ['row' => '#a7d9a7', 'badge' => '#800080', 'label' => 'Resubmitted'],
                                            4 => ['row' => '#F4CCCC', 'badge' => '#28A745', 'label' => 'Accepted'],
                                            5 => ['row' => '#76c3dd', 'badge' => '#17A2B8', 'label' => 'Published'],
                                            ];

                                            $status = $data->status;
                                            $colors = $statusColors[$status] ?? ['row' => '#FFFFFF', 'badge' =>
                                            '#6c757d', 'label' => 'Unknown'];
                                            @endphp

                                            <tr style="background-color: {{ $colors['row'] }} !important;">
                                                <td align="center">{{ $mi + 1 }}</td>
                                                <td>
                                                    <div class="fs-7 fw-semibold text-black text-truncate max-w-225px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="{{ $data->journal_name }}">
                                                        {{ $data->journal_name }}
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="fs-7 fw-semibold text-black text-truncate max-w-225px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="{{ $data->paper_name }}">
                                                        {{ $data->paper_name }}
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="fw-semibold text-black fs-7 text-truncate max-w-225px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Internet of Things, Communications, Computer Science">
                                                        Internet of Things, Communications, Computer Science
                                                    </div>
                                                </td>
                                                <td align="center">{{ $data->author_name ?? '-' }}</td>
                                                <td align="center">
                                                    @if (!empty($data->published_url))
                                                    <a href="{{ $data->published_url }}"
                                                        class="badge bg-body rounded px-2" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Published Link">
                                                        <i class="mdi mdi-link-variant text-danger fs-4"></i>
                                                    </a>
                                                    @else
                                                    -
                                                    @endif
                                                </td>
                                                <td>
                                                    <div class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: {{ $colors['badge'] }} !important;">
                                                        {{ $colors['label'] }}
                                                    </div>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
                <div class="mt-4">
                    {{ $fetch->appends(request()->except(['page', '_token']))->links() }}
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function open_func(id) {
      var colse_tr_div = document.getElementById("colse_tr_div"+id);
  
      if (colse_tr_div.style.display == "none") {
        document.getElementById("colse_tr_div"+id).style.display = "table-row";
        document.getElementById("plus_btn"+id).classList.remove("mdi-plus");
        document.getElementById("plus_btn"+id).classList.add("mdi-minus");
        document.getElementById("main_tr_div"+id).style.backgroundColor = "#f9f3c5db";
      } else {
        document.getElementById("colse_tr_div"+id).style.display = "none";
        document.getElementById("plus_btn"+id).classList.remove("mdi-minus");
        document.getElementById("plus_btn"+id).classList.add("mdi-plus");
        document.getElementById("main_tr_div"+id).removeAttribute("style");
      }
    }
</script>

<script>
    $(document).ready(function() {
        @if($filter_on ?? '')
        $('.filter_tbox').slideToggle('fast');
        // });
        @endif
    });

    // Toggle branch filter section
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });

</script>

<script>
    function sort_filter(val) {
          if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#filter_form').submit();
          } else {
            $('.sorting_filter_class').val(25);
            $('#filter_form').submit();
          }
        }
</script>

@endsection