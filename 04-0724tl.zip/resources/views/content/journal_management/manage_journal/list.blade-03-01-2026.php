@extends('layouts/layoutMaster')

@section('title', 'Manage Journal')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
#correction_chk {
        /* Size */
        width: 24px;
        height: 24px;
       
        /* Positioning */
        margin: 7px 8px 10px 0px;
       
        /* Custom appearance */
        cursor: pointer;
        accent-color: #4CAF50 !important; /* Custom color for modern browsers */
    }
    .profile-avatar {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 1rem;
        transition: all 0.25s ease-in-out;
        cursor: pointer;
    }
    .profile-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .profile-avatar:hover {
        transform: scale(1.1);
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
    }
    .bg-gradient-primary {
        background: linear-gradient(45deg, #007bff, #00c6ff);
    }

    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }

    .indv_cust_jour thead th,
    .indv_cust_jour tbody td {
        padding: 8px !important;
        border: 1px solid rgb(180, 180, 180) !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }

    .service-master-card {
        backdrop-filter: blur(10px);
        background: #f0913d;
    }

    .stat-card {
        backdrop-filter: blur(10px);
        transition: all 0.3s ease;
        background: rgba(255, 255, 255, 0.2) !important;
    }
    .pulse-btn {
        position: relative;
    }
    .pulse-btn::after {
        content: '';
        position: absolute;
        top: -4px;
        left: -4px;
        right: -4px;
        bottom: -4px;
        border: 2px solid #ff6b6b;
        border-radius: 50%;
        animation: pulse 2s infinite;
        opacity: 0;
    }
    @keyframes pulse {
        0% { transform: scale(0.95); opacity: 0.7; }
        70% { transform: scale(1.05); opacity: 0; }
        100% { transform: scale(0.95); opacity: 0; }
    }
</style>
<!-- Journal List Table -->

@php
$helper = new \App\Helpers\Helpers();
$module_name = 'Journal Management';
$menu_name = 'Manage Journal';
@endphp
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Journal</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Journal Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center flex-wrap">
                <!--<button class="btn-23" data-bs-toggle="modal" data-bs-target="#kt_modal_add_journal_booklet_ai">-->
                <!--    <span class="text">AI Suggestion</span>-->
                <!--    <span aria-hidden="" class="marquee">AI Suggestion</span>-->
                <!--</button>-->
            </div>
        </div>
    </div>
    <div class="card-body">
        {{-- <div class="filter_tbox" style="display: none;">
            <form id="filter_form" method="POST" action="/journal_management/manage_journal">
                @csrf
                <input type="hidden" name="page" value="{{ request('page', 1)}}">
                <input type="hidden" name="filter_on" value="1">
                <input type="hidden" name="fill_chk" value="1">
                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                    value="25" />
                <div class="row py-1">
                    <input type="hidden" name="page" value="">
                    <div class="col-lg-3 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Customer Name</label>
                        <input type="text" class="form-control" placeholder="Enter Customer Name" id="customer_fill"
                            name="customer_fill" value="{{$customer_fill}}" />
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Customer ID</label>
                        <input type="text" class="form-control" placeholder="Enter Customer ID" id="customer_id_fill"
                            name="customer_id_fill" value="{{$customer_id_fill}}" />
                    </div>
                </div>
                <div class="d-flex justify-content-end mb-4 align-items-center">
                    <a href="{{ url('/journal_management/manage_journal') }}" type="button"
                        class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
                    <button type="submit" class="btn btn-sm btn-primary">Go</button>
                </div>
            </form>
        </div> --}}
        <div class="row">
               <div class="col-lg-12 d-flex align-items-center justify-content-start gap-2 mb-3">
                <div class="card rounded px-2 py-2"  style="box-shadow: {{ $currentStatus == 0 ? '0 0 0 2px #007BFF' : 'none' }};width: 180px;border: 1px solid #ccc;border-bottom: 3px solid #007BFF;cursor: pointer;"  onclick="filterByStatus(0)">
                    <div class="d-flex align-items-center justify-content-start gap-4">
                        <span class="badge rounded-circle" style="background-color: #d4e9ff;">
                            <i class="mdi mdi-text-box-check-outline fs-4" style="color: #007bff;"></i>
                        </span>
                        <div class="d-flex flex-column align-items-start justify-content-start gap-0">
                            <label>Submitted</label>
                            <label class="fw-bold fs-5 text-black">{{ $submittedCount == 0 ? 0 : str_pad($submittedCount, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                </div>
                <div class="card rounded px-2 py-2"  style="box-shadow: {{ $currentStatus == 1 ? '0 0 0 2px #FFA500' : 'none' }};border: 1px solid #ccc;border-bottom: 3px solid #FFA500;width: 180px;cursor: pointer;"  onclick="filterByStatus(1)">
                    <div class="d-flex align-items-center justify-content-start gap-4">
                        <span class="badge rounded-circle" style="background-color: #ffeece;">
                            <i class="mdi mdi-text-box-search-outline fs-4" style="color: #ffa500;"></i>
                        </span>
                        <div class="d-flex flex-column align-items-start justify-content-start gap-0">
                            <label>Reviewed</label>
                            <label class="fw-bold fs-5 text-black">{{ $reviewedCount == 0 ? 0 : str_pad($reviewedCount, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                </div>
                <div class="card rounded px-2 py-2"  style="box-shadow: {{ $currentStatus == 3 ? '0 0 0 2px #800080' : 'none' }};border: 1px solid #ccc;border-bottom: 3px solid #800080;width: 180px;cursor: pointer;"   onclick="filterByStatus(3)">
                    <div class="d-flex align-items-center justify-content-start gap-4">
                        <span class="badge rounded-circle" style="background-color: #fff0ff;">
                            <i class="mdi mdi-file-restore-outline fs-4" style="color: #800080"></i>
                        </span>
                        <div class="d-flex flex-column align-items-start justify-content-start gap-0">
                            <label>Resubmitted</label>
                            <label class="fw-bold fs-5 text-black">{{ $resubmittedCount == 0 ? 0 : str_pad($resubmittedCount, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                </div>
                <div class="card rounded px-2 py-2"  style="box-shadow: {{ $currentStatus == 4 ? '0 0 0 2px #28A745' : 'none' }};border: 1px solid #ccc;border-bottom: 3px solid #28A745;width: 180px;cursor: pointer;"   onclick="filterByStatus(4)">
                    <div class="d-flex align-items-center justify-content-start gap-4">
                        <span class="badge rounded-circle" style="background-color: #e2ffe9;">
                            <i class="mdi mdi-file-document-check-outline fs-4" style="color: #28A745"></i>
                        </span>
                        <div class="d-flex flex-column align-items-start justify-content-start gap-0">
                            <label>Accepted</label>
                            <label class="fw-bold fs-5 text-black">{{ $acceptedCount == 0 ? 0 : str_pad($acceptedCount, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                </div>
                <div class="card rounded px-2 py-2"  style="box-shadow: {{ $currentStatus == 5 ? '0 0 0 2px #DC3545' : 'none' }};border: 1px solid #ccc;border-bottom: 3px solid #DC3545;width: 180px;cursor: pointer;"  onclick="filterByStatus(5)">
                    <div class="d-flex align-items-center justify-content-start gap-4">
                        <span class="badge rounded-circle" style="background-color: #ffe6e8;">
                            <i class="mdi mdi-file-document-remove-outline fs-4" style="color: #DC3545"></i>
                        </span>
                        <div class="d-flex flex-column align-items-start justify-content-start gap-0">
                            <label>Rejected</label>
                            <label class="fw-bold fs-5 text-black">{{ $rejectedCount == 0 ? 0 : str_pad($rejectedCount, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                </div>
                <div class="card rounded px-2 py-2"  style="box-shadow: {{ $currentStatus == 6 ? '0 0 0 2px #17A2B8' : 'none' }};border: 1px solid #ccc;border-bottom: 3px solid #17A2B8;width: 180px;cursor: pointer;"   onclick="filterByStatus(6)">
                    <div class="d-flex align-items-center justify-content-start gap-4">
                        <span class="badge rounded-circle" style="background-color: #e4fbff;">
                            <i class="mdi mdi-file-link-outline fs-4" style="color: #17A2B8"></i>
                        </span>
                        <div class="d-flex flex-column align-items-start justify-content-start gap-0">
                            <label>Published</label>
                            <label class="fw-bold fs-5 text-black">{{ $publishedCount == 0 ? 0 : str_pad($publishedCount, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                </div>
                 @if($currentStatus !== null)
                    <button class="btn btn-sm btn-primary border rounded-circle p-2 pulse-btn"
                        onclick="clearStatusFilter()"
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Clear Filter">
                    <i class="mdi mdi-filter-remove fs-5 text-white"></i>
                </button>
                @endif
            </div>
            <div class="col-lg-12">
                <div class="row mb-4">
                    @php $perpage_count = $perpage ? $perpage : 10; @endphp
                    <div class="col-lg-2">
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                            onchange="sort_filter(this.value);">
                            @php
                            $options = [10, 25, 100, 500]; // Define available options
                            @endphp
                            @php foreach ($options as $option): @endphp
                            <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                                @php echo $option; @endphp
                            </option>
                            @php endforeach; @endphp
                        </select>
                    </div>
                    <div class="col-lg-10 d-flex align-items-end justify-content-end">
                        <form id="search_form" method="POST" action="/journal_management/manage_journal">
                            @csrf
                            <div class="d-flex align-items-center gap-2 mt-2">
                                <div>
                                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                    <input type="hidden" name="filter_on" value="0">
                                    <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                                        value="@php echo $perpage ? $perpage : 10; @endphp" />
                                    <input type="text" class="form-control" id="search_fill" name="search_fill"
                                        value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                    onclick="search_filter_func()">Search</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-200px">Customers</th>
                                <th class="min-w-100px text-center">Services</th>
                                <th class="min-w-150px text-center">Domain & Index</th>
                                <th class="min-w-100px text-center">Journal Staff</th>
                                <th class="min-w-100px text-center">Submitted</th>
                                <th class="min-w-100px text-center">Reviewed</th>
                                <th class="min-w-100px text-center">Resubmitted</th>
                                <th class="min-w-100px text-center">Accepted</th>
                                <th class="min-w-100px text-center">Rejected</th>
                                <th class="min-w-100px text-center">Published</th>
                                <th class="min-w-80px">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7">
                            @foreach($lists as $i => $list)
                                <tr id="indv_cust_hd_{{$i}}">
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <a href="javascript:;"
                                                class="bg-label-secondary border border-gray-400i rounded px-1 py-1"
                                                onclick="open_func({{$i}});">
                                                <i class="mdi mdi-plus fs-4" id="plus_btn{{$i}}"></i>
                                            </a>
                                            <div class="mb-0 mx-2">
                                                <label class="text-black text-truncate fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="{{$list->cus_name}}">{{$list->cus_name}}</label>
                                                <div class="d-block">
                                                    <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer ID">
                                                        {{$list->customer_id}}</div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="mb-0 mx-2">
                                            <label class="text-black text-truncate fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="{{$list->service_name}}">{{$list->service_name}}</label>
                                            <div class="d-block">
                                                <div class="text-danger fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Service Id">
                                                    {{$list->service_id}}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <label class="d-block badge text-truncate bg-success fs-7 text-black px-2 py-1" style="max-width: 150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->domain_names ? implode(', ', $list->domain_names->toArray()) : 'No Domains' }}">{{ $list->domain_names ? implode(', ', $list->domain_names->toArray()) : 'No Domains' }}</label>
                                        <label class="d-block badge text-truncate bg-secondary fs-7 text-white px-2 py-1 mt-1" style="max-width: 150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->index_names }}">{{ $list->index_names }}</label>
                                    </td>
                                    <td class="ps-4">
                                        <div class="d-flex align-items-center gap-4">
                                            <!-- Journal Coordinator -->
                                            <div class="d-flex flex-column align-items-center position-relative">
                                                @if($list->jouranal_coordinator_image)
                                                    @if ($list->jouranal_coordinator_image != '' && file_exists(public_path('staff_images/' .$list->jouranal_coordinator_image)))
                                                        <div class="profile-avatar shadow-sm border border-2 border-primary" data-bs-toggle="tooltip" title="JTL: {{ $list->jouranal_coordinator_name }}">
                                                            <img src="{{ asset('staff_images/' . $list->jouranal_coordinator_image) }}" alt="{{ $list->jouranal_coordinator_name }}">
                                                        </div>
                                                    @else
                                                        <div class="profile-avatar bg-primary text-white shadow-sm border border-2 border-primary" data-bs-toggle="tooltip" title="JTL: {{ $list->jouranal_coordinator_name }}">
                                                            <span>{{ strtoupper(substr($list->jouranal_coordinator_name, 0, 1)) }}</span>
                                                        </div>
                                                    @endif
                                                @else
                                                    <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Coordinator">
                                                        <i class="mdi mdi-account-off fs-5"></i>
                                                    </div>
                                                @endif
                                                <small class="text-muted mt-1 fw-medium">JTL</small>
                                            </div>

                                            <!-- Journal Staff -->
                                            <div class="d-flex flex-column align-items-center position-relative">
                                                @if($list->journal_staff_image)
                                                    @if ($list->journal_staff_image != '' && file_exists(public_path('staff_images/' .$list->journal_staff_image)))
                                                        <div class="profile-avatar shadow-sm border border-2 border-success" data-bs-toggle="tooltip" title="JE: {{ $list->journal_staff_name }}">
                                                            <img src="{{ asset('staff_images/' . $list->journal_staff_image) }}" alt="{{ $list->journal_staff_name }}">
                                                        </div>
                                                    @else
                                                        <div class="profile-avatar bg-success text-white shadow-sm border border-2 border-success" data-bs-toggle="tooltip" title="JE: {{ $list->journal_staff_name }}">
                                                            <span>{{ strtoupper(substr($list->journal_staff_name, 0, 1)) }}</span>
                                                        </div>
                                                    @endif
                                                @else
                                                    <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                                                        <i class="mdi mdi-account-off fs-5"></i>
                                                    </div>
                                                @endif
                                                <small class="text-muted mt-1 fw-medium">JE</small>
                                            </div>

                                        </div>
                                    </td>
                                    @php
                                        $submittedCount = $helper->get_submitted_count($list->sno, $list->journal_customer_id) ?? 0;
                                        $reviewedCount = $helper->get_reviewed_count($list->sno, $list->journal_customer_id) ?? 0;
                                        $resubmittedCount = $helper->get_resubmitted_count($list->sno, $list->journal_customer_id) ?? 0;
                                        $acceptedCount = $helper->get_accepted_count($list->sno, $list->journal_customer_id) ?? 0;
                                        $rejectedCount = $helper->get_rejected_count($list->sno, $list->journal_customer_id) ?? 0;
                                        $publishedCount = $helper->get_published_count($list->sno, $list->journal_customer_id) ?? 0;
                                    @endphp
                                    <td align="center">
                                        <div class="circular-badge bg-primary" data-bs-toggle="tooltip" title="Submitted Papers">
                                            <span class="text-white fw-bold fs-6">{{ str_pad($submittedCount, 2, '0', STR_PAD_LEFT) }}</span>
                                        </div>
                                    </td>
                                    
                                    <td align="center">
                                        <div class="circular-badge bg-warning" data-bs-toggle="tooltip" title="Reviewed Papers">
                                            <span class="text-dark fw-bold fs-6">{{ str_pad($reviewedCount, 2, '0', STR_PAD_LEFT) }}</span>
                                        </div>
                                    </td>
                                    
                                    <td align="center">
                                        <div class="circular-badge bg-purple" data-bs-toggle="tooltip" title="Resubmitted Papers">
                                            <span class="text-white fw-bold fs-6">{{ str_pad($resubmittedCount, 2, '0', STR_PAD_LEFT) }}</span>
                                        </div>
                                    </td>
                                    
                                    <td align="center">
                                        <div class="circular-badge bg-success" data-bs-toggle="tooltip" title="Accepted Papers">
                                            <span class="text-white fw-bold fs-6">{{ str_pad($acceptedCount, 2, '0', STR_PAD_LEFT) }}</span>
                                        </div>
                                    </td>
                                    
                                    <td align="center">
                                        <div class="circular-badge bg-danger" data-bs-toggle="tooltip" title="Rejected Papers">
                                            <span class="text-white fw-bold fs-6">{{ str_pad($rejectedCount, 2, '0', STR_PAD_LEFT) }}</span>
                                        </div>
                                    </td>
                                    
                                    <td align="center">
                                        <div class="circular-badge bg-info" data-bs-toggle="tooltip" title="Published Papers">
                                            <span class="text-white fw-bold fs-6">{{ str_pad($publishedCount, 2, '0', STR_PAD_LEFT) }}</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="text-center">
                                            <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false">
                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                @php
                                                    $loginStaff = auth()->user()->user_id;
                                                    $journalTL = $list->jc_id;
                                                    $journalStaff = $list->jc_staff;
                                                @endphp
                                                {{-- @if($journalTL === $loginStaff) --}}
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_journal_assign_staff"
                                                        onclick="AssignStaff('{{$list->sno}}')">
                                                        <span> <i class="mdi mdi-account fs-4 text-black me-2"></i>
                                                            Assign Staff
                                                        </span>
                                                    </a>
                                                {{-- @endif --}}
                                                {{-- @if($journalStaff == $loginStaff) --}}
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_submit_journal"
                                                        onclick="fetchData('{{$list->sno}}')">
                                                        <span> <i class="mdi mdi-book-open-variant-outline fs-4 text-black me-2"></i>
                                                            Submit Journal
                                                        </span>
                                                    </a>
                                                {{-- @endif --}}
                                                {{-- @if(auth()->user()->hasPermission($module_name, 'Add Requirement', $menu_name)) --}}
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_assign_requirements" onclick="openRequirement('{{$list->sno}}')">
                                                        <span><i class="mdi mdi-file-document-plus-outline fs-3 text-black me-1"></i></span>
                                                        <span>Requirments</span>
                                                    </a>
                                                {{-- @endif --}}
                                                @php
                                                    $encryptedValue = $helper->encrypt_decrypt($list->sno,'encrypt');
                                                    $url = url('/view_manage_journal/' .$encryptedValue);
                                                @endphp
                                                @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                                <a href="{{$url}}" class="dropdown-item">
                                                    <span> <i
                                                            class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                                                </a>
                                                @endif
                                            </div>
                                        </span>
                                    </td>
                                </tr>
                                <tr id="colse_tr_div{{$i}}" style="display:none;background-color: #efffdd52;">
                                    <td colspan="11">
                                        <table class="table align-top gy-1 gs-2 indv_cust_jour">
                                            <thead>
                                                <tr class="text-start align-top fs-6 gs-0">
                                                    <th class="min-w-50px text-black fw-semibold text-center">S.No</th>
                                                    <th class="min-w-150px text-black fw-semibold">Paper</th>
                                                    <th class="min-w-150px text-black fw-semibold">Submitted Date</th>
                                                    <th class="min-w-150px text-black fw-semibold">Journal Booklet</th>
                                                    <th class="min-w-175px text-black fw-semibold">Domain</th>
                                                    <th class="min-w-100px text-black text-center fw-semibold">Author /
                                                        Published Date</th>
                                                    <th class="min-w-100px text-black text-center fw-semibold">Published URL
                                                    </th>
                                                    <th class="min-w-100px text-black fw-semibold">Status</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                @foreach ($list->journal_data as $mi => $journal)
                                                    @php                                        
                                                        $statusColors = [
                                                        0 => ['row' => '#CCE5FF', 'badge' => '#007BFF', 'label' => 'Submitted'],
                                                        1 => ['row' => '#FFE6B3', 'badge' => '#FFA500', 'label' => 'Reviewed'],
                                                        5 => ['row' => '#e5c1e5', 'badge' => '#DC3545', 'label' => 'Rejected'],
                                                        3 => ['row' => '#cfa7d9', 'badge' => '#800080', 'label' => 'Resubmitted'],
                                                        4 => ['row' => '#ccf4d3', 'badge' => '#28A745', 'label' => 'Accepted'],
                                                        6 => ['row' => '#cde6ef', 'badge' => '#17A2B8', 'label' => 'Published'],
                                                        ];
                                        
                                                        $status = $journal->status;
                                                        $colors = $statusColors[$status] ?? ['row' => '#FFFFFF', 'badge' => '#6c757d', 'label' => 'Unknown'];
                                                        $journalPaper = $journal->published_paper_name ?? $journal->paper_name;
                                                    @endphp
                                    
                                                    <tr style="background-color: {{ $colors['row'] }} !important;">
                                                        <td align="center">{{ $mi + 1 }}</td>
                                                        <td>
                                                            <div class="mb-0 mx-2">
                                                                <label class="text-black text-truncate fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="{{ $journalPaper }}">{{ $journalPaper }}</label>
                                                                <div class="d-block">
                                                                    <div class="text-danger fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                        title="Journal Id">
                                                                        {{$journal->journal_id}}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="fs-7 fw-bold text-primary text-uppercase p-2 rounded text-truncate" style="max-width: 200px;">
                                                                {{ \Carbon\Carbon::parse($journal->submited_date)->format('d-M-Y') }}
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="fs-7 fw-semibold text-black text-truncate max-w-225px" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom" title="{{ $journal->journal_name }}">
                                                                {{ $journal->journal_name }}
                                                            </div>
                                                        </td>
                                                        @php
                                                            if(count($journal->domain_names) > 0) {
                                                                $domains = implode(', ', $journal->domain_names);
                                                            } else {
                                                                $domains = 'Not Available';
                                                            }
                                                        @endphp
                                                        <td>
                                                            <div class="fw-semibold text-black fs-7 text-truncate max-w-225px" data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom" title="{{  $domains  }}">
                                                                {{  $domains  }}
                                                            </div>
                                                        </td>
                                                        <td align="center">
                                                            <div class="mb-0 mx-2">
                                                                <label class="{{ $journal->publish_author ? 'bg-warning' : '' }} text-black px-2 py-1 text-truncate fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="{{ $journal->publish_author ?? '-' }}">{{ $journal->publish_author ?? '-' }}</label>
                                                                <div class="d-block">
                                                                    <div class="{{ $journal->publish_date ? 'bg-info text-white' : 'text-black' }} px-2 py-1 fw-semibold fs-8">
                                                                        {{$journal->publish_date}}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td align="center">
                                                            @if (!empty($journal->publish_url))
                                                                <a href="{{ $journal->publish_url }}" target="_blank" class="badge bg-body rounded px-2" data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom" title="Published Link">
                                                                    <i class="mdi mdi-link-variant text-danger fs-4"></i>
                                                                </a>
                                                            @else
                                                            -
                                                            @endif
                                                        </td>
                                                        <td>
                                                            @if($journal->status == 0)
                                                                <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                                    style="background-color: 	#007BFF !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <span>Submitted</span>
                                                                    <span class="ms-2"><i class="mdi mdi-menu-down text-white"></i></span>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_journal_reviewed" onclick="getJournalReviewData( '{{ $journal->sno }}' )" >Reviewed</a>
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_journal_accepted" onclick="getJournalAcceptData('{{ $journal->sno }}')" >Accepted</a>
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_journal_rejected" onclick="getJournalRejectData('{{ $journal->sno }}')" >Rejected</a>
                                                                </div>
                                                            @elseif ($journal->status == 1)
                                                                <a href="javascript:;" class="badge bg-info text-black mb-1 fs-7 fw-semibold"
                                                                    style="background-color: 	#FFA500 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <span>Reviewed</span>
                                                                    <span class="ms-2"><i class="mdi mdi-menu-down text-black"></i></span>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_journal_reviewed" onclick="getJournalReviewData( '{{ $journal->sno }}' )" >Reviewed</a>
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_journal_resubmitted" onclick="getJournalResubmitData('{{ $journal->sno }}')" >Resubmitted</a>
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_journal_accepted" onclick="getJournalAcceptData('{{ $journal->sno }}')" >Accepted</a>
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_journal_rejected" onclick="getJournalRejectData('{{ $journal->sno }}')" >Rejected</a>
                                                                </div>
                                                            @elseif ($journal->status == 3)
                                                                <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                                    style="background-color: #800080 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <span>Resubmitted</span>
                                                                    <span class="ms-2"><i class="mdi mdi-menu-down text-white"></i></span>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_journal_accepted" onclick="getJournalAcceptData('{{ $journal->sno }}')" >Accepted</a>
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_journal_rejected" onclick="getJournalRejectData('{{ $journal->sno }}')" >Rejected</a>
                                                                </div>
                                                            @elseif ($journal->status == 4)
                                                                <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                                    style="background-color:	#28A745 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <span>Accepted</span>
                                                                    <span class="ms-2"><i class="mdi mdi-menu-down text-white"></i></span>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_journal_published" onclick="getJournalPublishData('{{ $journal->sno }}')" >Published</a>
                                                                </div>
                                                            @elseif ($journal->status == 5)
                                                                <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color:#DC3545 !important;">Rejected</div>
                                                            @elseif ($journal->status == 6)
                                                                <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #17A2B8 !important;">Published
                                                                </div>
                                                            @endif
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="mt-4">
                    {{ $lists->appends(request()->except(['page', '_token']))->links() }}
                </div>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Add Journal Booklet AI-->
<div class="modal fade" id="kt_modal_add_journal_booklet_ai" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xxl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black me-3"><label>AI Assistance</label>
                        <label>
                            <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"
                                id="ai-study">
                                <ellipse cx="32" cy="61" fill="#e3eaff" rx="17" ry="3"></ellipse>
                                <rect width="34.36" height="31.33" x="14.82" y="19.92" fill="#b0c4ff" rx="7"></rect>
                                <rect width="30.32" height="31.33" x="14.82" y="19.92" fill="#fff" rx="7"></rect>
                                <rect width="26.27" height="31.33" x="18.86" y="19.92" fill="#e3eaff" rx="7"></rect>
                                <path fill="#b0c4ff"
                                    d="m32 19.92-11.12-2.9 1.31 3.97L32 24.97l11.83-2.08-.71-5.87L32 19.92z"></path>
                                <path fill="#0040ff"
                                    d="M42.11 52H21.89a7.84 7.84 0 0 1-7.83-7.83V27a7.84 7.84 0 0 1 7.83-7.83h20.22A7.84 7.84 0 0 1 49.94 27v17.17A7.84 7.84 0 0 1 42.11 52ZM21.89 20.67A6.32 6.32 0 0 0 15.58 27v17.17a6.32 6.32 0 0 0 6.31 6.31h20.22a6.32 6.32 0 0 0 6.31-6.31V27a6.32 6.32 0 0 0-6.31-6.32Z">
                                </path>
                                <path fill="#4f7bff" d="M49.18 27.5h2.06a4 4 0 0 1 4 4v8.17a4 4 0 0 1-4 4h-2.06V27.5Z">
                                </path>
                                <path fill="#6b90ff" d="M49.18 43.66V27.5a4 4 0 0 1 4 4v8.08a4 4 0 0 1-4 4.08Z"></path>
                                <path fill="#a3baff" d="M12.76 27.5h2.06v16.16h-2.06a4 4 0 0 1-4-4V31.5a4 4 0 0 1 4-4Z">
                                </path>
                                <path fill="#6b90ff" d="M14.82 43.66a4 4 0 0 1-4-4v-8.12a4 4 0 0 1 4-4Z"></path>
                                <path fill="#0040ff"
                                    d="M51.2 44.42h-2a.76.76 0 0 1-.76-.76V27.5a.76.76 0 0 1 .76-.76h2a4.8 4.8 0 0 1 4.8 4.8v8.08a4.8 4.8 0 0 1-4.8 4.8zm-1.26-1.51h1.26a3.29 3.29 0 0 0 3.28-3.29v-8.08a3.29 3.29 0 0 0-3.28-3.29h-1.26zm-35.12 1.51h-2A4.8 4.8 0 0 1 8 39.62v-8.08a4.8 4.8 0 0 1 4.8-4.8h2a.76.76 0 0 1 .76.76v16.16a.76.76 0 0 1-.74.76zm-2-16.17a3.29 3.29 0 0 0-3.28 3.29v8.08a3.29 3.29 0 0 0 3.28 3.29h1.26V28.25z">
                                </path>
                                <path fill="#c4d3ff" d="M32 16.89 8.76 10.82 32 4.76l23.24 6.06L32 16.89z"></path>
                                <path fill="#9cb4ff" d="m34.21 16.31-15.35-5.49 14.3-3.53 22.08 3.53-21.03 5.49z">
                                </path>
                                <path fill="#0040ff"
                                    d="M32 17.64h-.19L8.57 11.55a.74.74 0 0 1-.57-.73.75.75 0 0 1 .57-.73L31.81 4a.62.62 0 0 1 .38 0l23.24 6.06a.75.75 0 0 1 .57.73.74.74 0 0 1-.57.73l-23.24 6.1Zm-20.24-6.82L32 16.1l20.24-5.28L32 5.54Z">
                                </path>
                                <path fill="#7d9dff" d="m32 16.89-11.12-2.91v6.07L32 22.95l11.12-2.9v-6.07L32 16.89z">
                                </path>
                                <path fill="#9cb4ff" d="m32 18.91-11.12-2.9v4.04L32 22.95l7.07-1.85v-4.04L32 18.91z">
                                </path>
                                <path fill="#0040ff"
                                    d="M32 23.71a.63.63 0 0 1-.19 0l-11.12-2.9a.76.76 0 0 1-.56-.73V14a.73.73 0 0 1 .29-.6.75.75 0 0 1 .66-.14L32 16.1l10.92-2.85a.75.75 0 0 1 .66.14.76.76 0 0 1 .29.6v6.06a.76.76 0 0 1-.56.73l-11.12 2.9a.63.63 0 0 1-.19.03zm-10.36-4.25L32 22.16l10.36-2.7V15l-10.17 2.62a.81.81 0 0 1-.38 0L21.64 15zm33.6 2.22a.76.76 0 0 1-.76-.75V10.82a.76.76 0 1 1 1.52 0v10.11a.76.76 0 0 1-.76.75zM38.57 45.43H25.43a.76.76 0 0 1-.76-.76v-2a.76.76 0 0 1 1.52 0v1.27h11.62v-1.29a.76.76 0 0 1 1.52 0v2a.76.76 0 0 1-.76.78z">
                                </path>
                                <path fill="#7d9dff"
                                    d="M39.07 37.09H24.93a4 4 0 0 1-4.05-4 4 4 0 0 1 4.05-4h14.14a4 4 0 0 1 4 4 4 4 0 0 1-4 4Z">
                                </path>
                                <path fill="#bacbff"
                                    d="M35 37.09H24.93a4 4 0 0 1-4.05-4 4 4 0 0 1 4.05-4H35a4 4 0 0 1 4 4 4 4 0 0 1-4 4Z">
                                </path>
                                <path fill="#adc2ff"
                                    d="M35 37.09h-6a4 4 0 0 1-4-4 4 4 0 0 1 4-4h6a4 4 0 0 1 4 4 4 4 0 0 1-4 4Z"></path>
                                <path fill="#0040ff"
                                    d="M28 33.05a1 1 0 1 1-1-1 1 1 0 0 1 1 1zm10.06 0a1 1 0 1 1-1-1 1 1 0 0 1 1 1z">
                                </path>
                                <path fill="#0040ff"
                                    d="M39.07 37.85H24.93a4.8 4.8 0 0 1 0-9.6h14.14a4.8 4.8 0 1 1 0 9.6Zm-14.14-8.08a3.29 3.29 0 1 0 0 6.57h14.14a3.29 3.29 0 1 0 0-6.57Z">
                                </path>
                            </svg>
                        </label>
                    </h3>
                </div>
                <div class="row">
                    {{-- <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Customer<span
                                class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Customer</option>
                            <option value="1">Priya Dharshini</option>
                            <option value="2">Selvin R</option>
                            <option value="3">Rama Lakshmi</option>
                        </select>
                    </div> --}}
                    <div class="col-lg-8 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Journal Link<span
                                class="text-danger">*</span></label>
                        <input type="text" id="journalInput" class="form-control"
                            placeholder="Type journal paper name here..." />
                    </div>
                    <div class="col-lg-4 mb-2 d-flex align-items-center ">
                        <a href="javascript:;" id="searchBtn" class="btn px-0 py-0 bg-transparent">
                            <img src="{{asset('assets/phdizone_images/search.png')}}" class="w-60px h-60px" />

                        </a>
                    </div>
                </div>

                <div id="loadingSpinner"
                    style="display:none; justify-content:center; align-items:center; margin-top:10px;">
                    <div class="spinner-border text-primary" role="status" aria-hidden="true"></div>
                    <span class="visually-hidden">Loading...</span>
                </div>

                <!-- Error message -->
                <div id="errorMsg" class="text-danger fs-7 mt-2" style="display:none;"></div>

                <div class="row">
                    <div id="results" style="display: none;">
                        <div class="col-lg-4 mt-4">
                            <div class="card h-100 rounded">
                                <div class="card-header pb-0 border border-bottom bg-label-success py-2">
                                    <div class="fs-5 card-title fw-bold">
                                        <label><svg class="w-30px h-30px me-2" xmlns="http://www.w3.org/2000/svg"
                                                xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 16 16"
                                                id="Database">
                                                <defs>
                                                    <linearGradient id="a">
                                                        <stop offset="0" stop-color="#1c1d1f"
                                                            class="stopColor000092 svgShape"></stop>
                                                        <stop offset="1" stop-color="#0055ff"
                                                            class="stopColorff00f3 svgShape"></stop>
                                                    </linearGradient>
                                                    <linearGradient xlink:href="#a" id="b" x1=".957" x2="13" y1="8"
                                                        y2="8" gradientUnits="userSpaceOnUse"></linearGradient>
                                                </defs>
                                                <path fill="url(#b)"
                                                    d="M5.318 1a.819.819 0 0 0-.818.818v5.127C4.5 7.526 4.974 8 5.555 8h4.89c.581 0 1.055-.474 1.055-1.055V1.818A.819.819 0 0 0 10.682 1H5.318zm.237 1 4.945.055V3H5.543l.012-1zM5.53 4H10.5v1H5.521l.01-1zM5.51 6h4.99v.945L10.445 7 5.5 6.945 5.51 6zM7.5 9v3.635c0 .19-.156.345-.346.345H3.908a1.52 1.52 0 0 0-1.43-1.023c-.837 0-1.521.684-1.521 1.522S1.641 15 2.479 15c.663 0 1.221-.428 1.43-1.021h3.247c.325 0 .613-.13.846-.323.233.193.519.323.844.323h3.248A1.513 1.513 0 0 0 13.52 15c.838 0 1.522-.682 1.522-1.521 0-.84-.683-1.522-1.522-1.522-.663 0-1.221.43-1.43 1.022H8.847a.345.345 0 0 1-.346-.344V9h-1zm-5.021 3.957a.522.522 0 1 1-.002 1.044.522.522 0 0 1 .002-1.044zm11.042 0a.523.523 0 0 1 0 1.043.522.522 0 0 1 0-1.043z">
                                                </path>
                                            </svg></label>
                                        <label>Database Journal</label>

                                    </div>
                                </div>

                                <div class="card-body pb-1 pt-0">
                                    <div class="row">
                                        <div class="scroll-y max-h-400px  px-3 pt-2 mb-4" id="databaseContainer">

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 mt-4">
                            <div class="card h-100 rounded">
                                <div class="card-header pb-0 border border-bottom bg-label-info py-2">
                                    <div class="fs-5 card-title fw-bold">
                                        <svg class="w-40px h-40px" xmlns="http://www.w3.org/2000/svg"
                                            viewBox="0 0 32 32" id="OnlineSearch">
                                            <path fill="#3074fb"
                                                d="M25.06,21.57H24v-7.8a1,1,0,1,0-2,0v7.8H6v-12H18.28a1,1,0,0,0,0-2H5a1,1,0,0,0-1,1v13H3.23a1,1,0,0,0-1,1v.36A5.07,5.07,0,0,0,7.29,28H21a5.07,5.07,0,0,0,5.06-5.06v-.36A1,1,0,0,0,25.06,21.57ZM21,26H7.29a3.08,3.08,0,0,1-3-2.42H24A3.06,3.06,0,0,1,21,26Z"
                                                class="color30c1fb svgShape"></path>
                                            <path fill="#1c1d1f"
                                                d="M29.48,14.87,27,12.43a5.44,5.44,0,1,0-1.42,1.41l2.45,2.45a1,1,0,0,0,1.41-1.42ZM20.2,11.79a3.39,3.39,0,1,1,4.79,0A3.39,3.39,0,0,1,20.2,11.79Z"
                                                class="color2446d8 svgShape"></path>
                                        </svg>
                                        <label>Online Search</label>

                                    </div>
                                </div>

                                <div class="card-body pb-1 pt-0">
                                    <div class="row">
                                        <div class="scroll-y max-h-400px  px-3 pt-2 mb-4" id="onlineSearchContainer">

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 mt-4">
                            <div class="card h-100 rounded">
                                <div class="card-header pb-0 border border-bottom bg-label-primary py-2">
                                    <div class="fs-5 card-title fw-bold">
                                        <label>
                                            <svg class="w-40px w-40px" xmlns="http://www.w3.org/2000/svg"
                                                fill-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="1.414"
                                                clip-rule="evenodd" viewBox="0 0 32 32" id="Recommendation">
                                                <path fill="none" d="M0 0h32v32H0z"></path>
                                                <path fill="#1c1d1f" fill-rule="nonzero"
                                                    d="M16.05 3c2.915.028 5.745 1.767 7.073 4.358 1.121 2.188 1.152 4.899.086 7.111-1.509 3.13-5.189 5.066-8.723 4.389-3.251-.624-5.95-3.456-6.41-6.74-.351-2.508.57-5.16 2.404-6.908A8.072 8.072 0 0 1 15.947 3h.103Zm-.09 2c-2.75.026-5.31 2.118-5.847 4.828-.389 1.959.28 4.099 1.721 5.49 1.666 1.608 4.299 2.127 6.465 1.225 1.915-.796 3.354-2.649 3.642-4.703.356-2.544-1.123-5.246-3.475-6.31A6.034 6.034 0 0 0 15.96 5Z"
                                                    class="color546e7a svgShape"></path>
                                                <path fill="#296df6" fill-rule="nonzero"
                                                    d="m16.982 18.919 4.146 7.181 1.573-2.382s.367-.409.774-.447l2.849-.171-2.825-4.894s-.198-.365-.104-.742c.095-.383.437-.693.831-.748.133-.019.166-.009.209-.007.327.034.618.211.796.497l3.635 6.295c.107.202.115.27.128.398.05.486-.305.983-.796 1.082-.061.013-.077.012-.139.018l-3.965.238-2.189 3.315s-.239.343-.62.426c-.365.08-.77-.065-1.002-.36-.038-.05-.045-.064-.078-.117l-5.55-9.613a7.7 7.7 0 0 0 2.327.031Zm-8.375-4.9a8.193 8.193 0 0 0 1.18 1.956L5.673 23.1l2.849.171s.457.074.688.334c.042.047.05.061.087.113L10.87 26.1l2.263-3.92s.841-.835 1.515-.26c.315.269.434.742.28 1.129-.024.061-.033.074-.063.132l-3.072 5.32c-.126.201-.183.243-.292.319a1.03 1.03 0 0 1-1.32-.153c-.043-.048-.051-.062-.089-.115l-2.189-3.315-3.965-.238s-.435-.04-.697-.345a1.02 1.02 0 0 1-.172-1.022c.024-.06.033-.074.063-.131l5.475-9.482Z"
                                                    class="color29b6f6 svgShape"></path>
                                            </svg>
                                        </label>
                                        Recommended Journal
                                    </div>
                                </div>

                                <div class="card-body pb-1 pt-0">
                                    <div class="row">
                                        <div class="scroll-y max-h-400px px-1 pt-2 mb-4" id="recommendedContainer">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {{-- <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">AI Assistance</a>
                </div> --}}
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Journal Booklet AI-->

<!--begin::Modal - Journal Staff Assign-->
<div class="modal fade" id="kt_modal_journal_assign_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Assign Staff</h3>
                </div>
                <form action="{{route('add_journal_staff')}}" method="POST" id="assign_journal_staff">
                    @csrf
                    <div class="row mt-4">
                        <input type="hidden" name="assgn_service_id" id="assgn_service_id">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="assgn_service">
                                -
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="assgn_cus">-</div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Mobile</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="assgn_mobile">-</div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="assgn_mail">-</div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assign Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="assgn_staff_id" name="assgn_staff_id">
                                <!-- AJAX Will Populate Dropdown -->
                            </select>
                            <p id="assgn_staff_err" class="text-danger mt-1 fs-6 fw-semibold"></p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Assign Staff</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Journal Staff Assign-->

<!--begin::Modal - Submit Journal-->
<div class="modal fade" id="kt_modal_submit_journal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Submit Journal</h3>
                </div>
                <form  id="add_journal_form">
                    <div class="row mt-4">
                        <input type="hidden" id="uploaded_files" name="uploaded_files">
                        <input type="hidden" name="customer_id" id="customer_id">
                        <input type="hidden" name="customer_services_id" id="customer_services_id">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="add_services">
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2 text-truncate"
                                id="cus_info">-</div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Journal Booklet<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="journal_booklet_id" name="journal_booklet_id">
                                <option value="">Select Journal Booklet</option>
                            </select>
                            <p id="booklet_error" class="text-danger mt-1 fs-7"></p>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Paper Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Paper Name" id="paper_name"
                                name="paper_name" />
                            <p id="paper_name_error" class="text-danger mt-1 fs-7"></p>
                        </div>
                        <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                        <div id="dropArea" class="drop-area">
                            <div id="dropMessage" class="drop-message">
                                <div class="upload-text">Drag & drop files here or <span class="clickable">click to
                                        upload</span></div>
                            </div>
                            <div class="preview-list" id="previewList"></div>
                            <input type="file" id="fileInput" multiple />
                        </div>
                        <div class="scroll-y max-h-200px  border border-gray-300i px-3 pt-2 mt-4 mb-4">
                            <div class="form-repeater_jorn_bklt_create">
                                <div data-repeater-list="group-a_jorn_bklt">
                                    <div data-repeater-item>
                                        <div class="row booklet_row">
                                            <div class="col-lg-5 mb-1">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Username / Email ID<span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control journal_email"
                                                    placeholder="Enter Username / Email ID" name="email[]" />
                                                <p class="text-danger mt-1 email_error"></p>
                                            </div>
                                            <div class="col-lg-6 mb-1">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control journal_pass"
                                                    placeholder="Enter Password" name="password[]" />
                                                <p class="text-danger mt-1 pass_error"></p>
                                            </div>
                                            <div class="col-lg-1 mb-1">
                                                <a href="javascript:;"
                                                    class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_create_del"
                                                    id="jorn_bklt_create_del" style="display: none !important;">
                                                    <i class="mdi mdi-delete fs-4"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="bookletContainer"></div>
                        </div>
                        <div class="mb-4 mt-1">
                            <button type="button" class="btn btn-sm btn-primary jorn_bklt_create_add fs-8 px-2 py-1"
                                data-repeater-create id="jorn_bklt_create_add">
                                <i class="mdi mdi-plus me-1"></i> Add More
                            </button>
                        </div>
                        <div class="col-lg-6 mb-3 mt-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" placeholder="Enter Description" id="paper_desc"
                                name="paper_desc"></textarea>
                        </div>
                        <div class="col-lg-6 mb-3 mt-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Submitted Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" placeholder="Select Date" class="form-control journal_date"  id="journal_submitted_date" readonly  />
                            </div>
                            <div class="text-danger mt-2 fs-7 fw-semibold" id="submitJournalDateErr"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="addValidation()">Submit Journal</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Submit Journal-->

<!--begin::Modal - View Journal-->
<div class="modal fade" id="kt_modal_view_journal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">View Journal Details</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Services</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Thesis Writing ( Writing Products )</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya <span class="fs-7 text-primary">(
                            2025/MDU01/CUS2334 )</span></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Paper</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">IEEE Internet of Things Journal</label>
                </div>
                <div class="d-flex align-items-center justify-content-between flex-wrap mb-4">
                    <div class="border text-center border-gray-300i flex-column rounded py-2 px-2">
                        <label class="text-dark fs-6 mb-1 fw-semibold">Scaler</label>
                        <div class="d-block">
                            <label class="badge bg-info fs-6 fw-semibold">01</label>
                        </div>
                    </div>
                    <div class="border text-center border-gray-300i flex-column rounded py-2 px-2">
                        <label class="text-dark fs-6 mb-1 fw-semibold">Published</label>
                        <div class="d-block">
                            <label class="badge bg-success fs-6 fw-semibold">0</label>
                        </div>
                    </div>
                    <div class="border text-center border-gray-300i flex-column rounded py-2 px-2">
                        <label class="text-dark fs-6 mb-1 fw-semibold">Reviewed</label>
                        <div class="d-block">
                            <label class="badge bg-warning text-black fs-6 fw-semibold">0</label>
                        </div>
                    </div>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black fs-7 fw-semibold">&emsp;&emsp; You will assist in writing and
                        organizing thesis chapters according to the guidelines.</label>
                </div>
                <div class="row mb-6">
                    <div class="col-lg-12">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Documents</label>
                        <div class="border border-gray-600i border-dashed rounded py-3 px-2">
                            <div class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">
                                <div class="mb-2">
                                    <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                        class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded border border-gray-300i rounded w-80px h-80px"
                                        download>
                                        <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                            class="h-80px w-80px" />
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Journal-->

<!--begin::Modal - Journal Reviewed-->
<div class="modal fade" id="kt_modal_journal_reviewed" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                want to
                <span class="badge bg-info text-black fs-6 fw-semibold"
                    style="background-color: #FFA500 !important;">Reviewed</span> Journal ?
                <div class="px-3 text-start mt-6">
                    <div class="row">
                        <input type="hidden" name="review_journal_id" id="review_journal_id">
                        <input type="hidden" name="reviewed_files" id="reviewed_files">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                id="reviewed_customer"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                id="reviewed_services"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                id="reviewed_journal"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom" id="reviewed_paper"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="reviewed_domain"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                            <div id="reviewDropArea" class="drop-area">
                                <div id="reviewDropMessage" class="drop-message">
                                    <div class="upload-icon">📁</div>
                                    <div class="upload-text">Drag & drop files here or <span class="clickable">click
                                            to upload</span></div>
                                </div>
                                <div class="preview-list" id="reviewPreviewList"></div>
                                <input type="file" id="reviewFileInput" multiple />
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3 mt-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Reviewed Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" placeholder="Select Date" class="form-control journal_date"  id="journal_reviewed_date" readonly  />
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Reviewer Comments<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="5" placeholder="Enter Reviewer Comments"
                                id="reviewer_comment" name="reviewer_comment"></textarea>
                            <p id="reviewer_comment_err" class="text-danger mt-1"></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="button" class="btn btn-primary me-3" onclick="validateReviewForm()" >Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Journal Reviewed-->

<!--begin::Modal - Journal Resubmitted-->
<div class="modal fade" id="kt_modal_journal_resubmitted" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                want to
                <span class="badge bg-info fs-6 fw-semibold"
                    style="background-color: #800080 !important;">Resubmitted</span> Journal ?
                <div class="px-3 text-start mt-6">
                    <div class="row">
                        <input type="hidden" name="resubmit_journal_id" id="resubmit_journal_id">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="resubmitted_customer"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="resubmitted_services"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="resubmitted_journal"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="resubmitted_domain"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="resubmitted_paper"></div>
                        </div>
                        <div class="col-lg-12 mb-3 mt-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Resubmitted Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" placeholder="Select Date" class="form-control journal_date"  id="journal_resubmitted_date" readonly  />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="button" class="btn btn-primary me-3" onclick="submitResubmitForm()" >Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Journal Resubmitted-->

<!--begin::Modal - Journal Accepted-->
<div class="modal fade" id="kt_modal_journal_accepted" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                want to
                <span class="badge bg-info fs-6 fw-semibold"
                    style="background-color: #28A745 !important;">Accepted</span> Journal ?
                <div class="px-3 text-start mt-6">
                    <div class="row">
                        <input type="hidden" name="accepted_journal_id" id="accepted_journal_id">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="accepted_customer"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="accepted_services"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="accepted_journal"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="accepted_domain"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="accepted_paper"></div>
                        </div>
                        <div class="col-lg-12 mb-3 mt-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Accepted Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" placeholder="Select Date" class="form-control journal_date"  id="journal_accepted_date" readonly  />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="submit" class="btn btn-primary me-3" onclick="submitAcceptForm()">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Journal Accepted-->

<!--begin::Modal - Journal Rejected-->
<div class="modal fade" id="kt_modal_journal_rejected" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                want to
                <span class="badge bg-info fs-6 fw-semibold"
                    style="background-color: #DC3545 !important;">Rejected</span> Journal ?
                <div class="px-3 text-start mt-6">
                    <div class="row">
                        <input type="hidden" name="journal_reject_id" id="journal_reject_id">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                id="rejected_customer"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                            <div class="bg-label-info border  text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                id="rejected_service"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                id="rejected_journal_name"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                id="rejected_paper_name"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="rejected_domains"></div>
                        </div>
                        <div class="col-lg-12 mb-3 mt-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Rejected Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" placeholder="Select Date" class="form-control journal_date"  id="journal_rejected_date" readonly  />
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Rejected Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="4" placeholder="Enter Rejected Reason"
                                id="rejected_reason" name="rejected_reason"></textarea>
                            <div id="rejected_reason_error" class="text-danger mt-1 fw-semibold fs-7"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="button" onclick="validateRejectForm()" class="btn btn-primary me-3">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Journal Rejected-->

<!--begin::Modal - Journal Published-->
<div class="modal fade" id="kt_modal_journal_published" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Journal Published</h3>
                </div>
                <div class="row">
                    <input type="hidden" name="published_id" id="published_id">
                    <input type="hidden" name="publish_uploaded_files" id="publish_uploaded_files">
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                        <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            id="published_customer"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                        <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            id="published_services"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                        <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            id="published_journal"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                        <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" id="published_paper"></div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                        <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                            id="published_domain"></div>
                    </div>
                    <div class="col-lg-6 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Date<span
                                class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i
                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" placeholder="Select Date" id="publish_date" name="publish_date"
                                class="form-control published_date" readonly />
                            </div>
                            <div id="publish_date_error" class="text-danger fs-7 fw-semibold mt-1"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Paper Name<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Paper Name" id="publish_paper"
                            name="publish_paper" />
                        <div id="publish_paper_error" class="text-danger fs-7 fw-semibold mt-1"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Author Name<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Author Name" id="publish_author"
                            name="publish_author" />
                        <div id="publish_author_error" class="text-danger fs-7 fw-semibold mt-1"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">URL<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter URL" id="publish_url"
                            name="publish_url" />
                        <div id="publish_url_error" class="text-danger fs-7 fw-semibold mt-1"></div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                        <div id="publish_dropArea" class="drop-area">
                            <div id="publish_dropMessage" class="drop-message">
                                <div class="upload-icon">📁</div>
                                <div class="upload-text">Drag & drop files here or <span class="clickable">click to
                                        upload</span></div>
                            </div>
                            <div class="preview-list" id="publish_previewList"></div>
                            <input type="file" id="publish_fileInput" multiple />
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="2" placeholder="Enter Description" name="publish_desc"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" onclick="validatePublishForm()">Journal Published</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Journal Published-->

<!-- AI SUGGESTION MODAL STARTS -->
{{-- <div class="modal fade" id="kt_modal_journal_ai" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-between border-0 pb-0 px-4">
                <h3 class="modal-title text-black">AI ASSISTANT</h3>
                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal"
                    aria-label="Close">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                </button>
            </div>
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!-- Input Section -->
                <div class="mb-4">
                    <label for="journalInput" class="form-label fw-semibold">Enter Journal Paper Name</label>
                    <div class="input-group">
                        <input type="text" id="journalInput" class="form-control"
                            placeholder="Type journal paper name here..." />
                        <button id="searchBtn" class="btn btn-primary">Search</button>
                    </div>
                </div>

                <!-- Results Section -->
                <div id="results" style="display:none;">
                    <div class="mb-3">
                        <h5>Analyzed Journals</h5>
                        <ul id="analyzedList" class="list-group mb-2"></ul>
                        <div id="noAnalyzed" class="text-muted">No analyzed journals found.</div>
                    </div>

                    <div>
                        <h5>Recommended Journals</h5>
                        <ul id="recommendedList" class="list-group mb-2"></ul>
                        <div id="noRecommended" class="text-muted">No recommended journals found.</div>
                    </div>
                </div>

                <!-- Loading Indicator -->
                <div id="loading" style="display:none;" class="text-center py-3">
                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Searching...
                </div>

                <!-- Error Message -->
                <div id="errorMsg" class="text-danger mt-3" style="display:none;"></div>
            </div>
        </div>
    </div>
</div> --}}

<!--begin::Modal - Assign Requirements-->
<div class="modal fade" id="kt_modal_assign_requirements" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form id="requirementForm" enctype="multipart/form-data" action="{{ route('requirement_manage_add_update_jnlcustomer') }}" method="POST" novalidate autocomplete="off">
             @csrf
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <input type="hidden" name="requirement_lead_id" id="requirement_lead_id">
                <input type="hidden" name="requirement_status" id="requirement_status">
                <input type="hidden" name="requirement_service_id" id="requirement_service_id">
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">New Journal Requirments</h3>
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-lg-4">
                        <div class="card card-flush shadow-sm h-100">
                            <div class="mt-3">
                                <h6 class="text-dark fw-bold text-center">Customer Information</h6>
                            </div>
                            <div class="card-body pt-2 pb-5">
                                
                                <div class="d-flex flex-column mb-6">
                                    <div class=" mb-1">
                                        <div class="fw-bold text-gray-600">Name</div>
                                        <div class="fw-semibold text-primary" id="requirement_lead_name">-</div>
                                    </div>
                                    <div class=" mb-1">
                                        <div class="fw-bold text-gray-600">Mobile</div>
                                        <div class="fw-semibold text-primary" id="requirement_lead_mobile">-</div>
                                    </div>
                                    <div class="">
                                        <div class="fw-bold text-gray-600">Email</div>
                                        <div class="fw-semibold text-primary" id="requirement_lead_mail">-</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="card card-flush shadow-sm h-100">
                            <div class="mt-3">
                                <h6 class="text-dark fw-bold text-center">Services Information</h6>
                            </div>
                            <div id="requirement_service" class="px-2 py-2 scroll-y max-h-175px"></div>
                        </div>
                    </div>
                </div>
                <div class="card card-flush shadow-sm h-100 px-3 py-3">
                    <div class="row g-5">
                        <div class="col-lg-6 mb-4">
                            <label class="text-black mb-1 fs-6 fw-semibold">Project Journal Team Lead <span class="text-danger">*</span></label>
                            <select id="pc_staff" name="pc_staff" class="select3 form-select">
                                <option value="">Select Project Journal Team Lead</option>
                            </select>
                            <div class="pc_staff_err text-danger"></div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <label class="text-black mb-1 fs-6 fw-semibold">RC</label><br>
                            <input class="" type="checkbox" id="correction_chk"  name="rc_chk" value="1"/>
                        </div>
                    </div>
                    <div class="row">              
                        <div class="form-repeater_reqts mt-6">
                            <div data-repeater-list="group-a_led_question" id="">
                                <div data-repeater-item>
                                    <div class="row mt-4" id="default_repeater">
                                        <div class="col-lg-7 mb-3"  id="default_requirement">
                                            <label class="text-black mb-1 fs-6 fw-semibold" id="requirement_label_1">Requirements Point 1<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Requirement Point 1" id="requirement_name_1" name="requirement_name[]" />
                                            <div class="text-danger err_mssg" id="requirement_name_1_err"></div>
                                        </div>
                                        <div class="col-lg-4 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Attachments</label>
                                            <div class="d-flex align-items-sm-center">
                                                <img src="{{asset('assets/phdizone_images/Document.jpg')}}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo_1" />
                                                <div class="ms-1 button-wrapper" id="defalt_filediv">
                                                    <div class="d-flex align-items-start mt-2 mb-2">
                                                        <button type="button" id="default_doc" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Document" onclick="document.getElementById('document_upload_1').click();">
                                                            <i class="mdi mdi-tray-arrow-up"></i>
                                                            <input type="file" id="document_upload_1" name="document_upload[]" class="file-in" hidden accept="image/png, image/jpeg, application/pdf, text/csv"   onchange="fileChange(event)"  />
                                                        </button>
                                                        <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Document"  id="uploaded_reset_1">
                                                            <i class="mdi mdi-reload"></i>
                                                        </button>
                                                    </div>
                                                    <div class="small fs-8">Allowed JPG, PNG, PDF, CSV. Max size 5MB</div>
                                                    <div class="small text-success fs-8" id="upload_file_name_1"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-1">
                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_reqts_del" id="staff_reqts_del_1" style="display: none !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div id="repeater_req"></div>
                                </div>
                            </div>
                        </div>
                        <div class="mb-1 mt-1">
                            <button type="button" class="btn btn-sm btn-primary staff_reqts_add px-2 py-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Add More" data-repeater-create>
                                <i class="mdi mdi-plus me-1"></i>Add More
                            </button>
                        </div>
                    </div>      
                </div>

                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="submit_requirements" class="btn btn-primary me-3" >
                        Create Requirements
                    </button>
                </div>
            </div>
           </form>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Assign Requirements- -->

{{-- Toastr Starts --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>

    .circular-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .circular-badge:hover {
        transform: scale(1.1);
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }

    .bg-purple { background-color: #800080 !important; }

    /* Customize Toastr container */
    .toast {
        background-color: #313f46;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
</style>
<script>
    // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
</script>
{{-- Toastr Ends --}}

<!-- JOURNAL DATE PICKER -->
<script>
    $(document).ready(function() {
        var isRtl = false; // Define this as needed
        if ($('.journal_date').length) {
            $('.journal_date').datepicker({
                todayHighlight: true,
                autoclose: true,
                format: 'd-M-yyyy',
                orientation: isRtl ? 'auto right' : 'auto left'
            });
        }
    });
</script>

{{-- Customer Email and Password Add --}}
<script>
    document.getElementById('jorn_bklt_create_add').addEventListener('click', function () {
        var newBookleteDetails = 
        `<div class="row booklet_row">
                    <div class="col-lg-5 mb-1">
                        <label class="text-black mb-1 fs-6 fw-semibold">Username / Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control journal_email" placeholder="Enter Username / Email ID" name="email[]" />
                        <p class="text-danger mt-1 email_error"></p>
                    </div>
                    <div class="col-lg-6 mb-1">
                        <label class="text-black mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                        <input type="text" class="form-control journal_pass" placeholder="Enter Password" name="password[]" />
                        <p class="text-danger mt-1 pass_error"></p>
                    </div>
                    <div class="col-lg-1 mb-1">
                        <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_create_del"
                            id="jorn_bklt_create_del">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
        </div>`;
        document.getElementById('bookletContainer').insertAdjacentHTML('beforeend', newBookleteDetails);
    });

    $(document).on('click', '.jorn_bklt_create_del', function(){
        $(this).closest('.row').remove();
    });
</script>

<script>
    function open_func(id) {
      var colse_tr_div = document.getElementById("colse_tr_div"+id);
  
      if (colse_tr_div.style.display == "none") {
        document.getElementById("colse_tr_div"+id).style.display = "table-row";
        document.getElementById("plus_btn"+id).classList.remove("mdi-plus");
        document.getElementById("plus_btn"+id).classList.add("mdi-minus");
        document.getElementById("main_tr_div"+id).style.backgroundColor = "#f9f3c5db";
      } else {
        document.getElementById("colse_tr_div"+id).style.display = "none";
        document.getElementById("plus_btn"+id).classList.remove("mdi-minus");
        document.getElementById("plus_btn"+id).classList.add("mdi-plus");
        document.getElementById("main_tr_div"+id).removeAttribute("style");
      }
    }
</script>
<script>
    $(document).ready(function() {
        @if($filter_on ?? '')
        $('.filter_tbox').slideToggle('fast');
        // });
        @endif
    });

    // Toggle branch filter section
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });

</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>

<script>
    function sort_filter(val) {
        if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
        } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
        }
    }
</script>

<!-- SUBMIT JOURNAL VALIDATION -->
<script>
    function addValidation () {
        let isValid = true;

        // Journal Booklet Error
        $('#booklet_error').text('');
        
        if($('#journal_booklet_id').val() === ''){
            isValid = false;
            $('#booklet_error').text('Select Atleast One.');
        }


        // Paper Name Error
        $('#paper_name_error').text('');

        if($('#paper_name').val() === ''){
            isValid = false;
            $('#paper_name_error').text('Enter the Paper Name.');
        }

        // Journal Email and Password Error
        $('.email_error').text('');
        $('.pass_error').text('');

        $('.booklet_row').each(function (index) {
            let emailField = $(this).find('.journal_email');
            let passField = $(this).find('.journal_pass');
            let email = emailField.val().trim();
            let pass = passField.val().trim();

            // Validate Email
            if(email === '') {
                emailField.next('.email_error').text('Username or Email ID is Required.');
                isValid = false;
            } 

            if(pass === '') {
                passField.next('.pass_error').text('Password is Required');
                isValid = false;
            }
        })

        if(!isValid){
            return false;
        } else {
            submitJournal();
        }

        return true;
    }

    function validateEmail(email) {
        var pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return pattern.test(email);
    }
</script>

<!-- DROP ZONE CSS -->
<style>
    .drop-area {
        border: 2px dashed #4a90e2;
        border-radius: 12px;
        padding: 40px;
        text-align: center;
        position: relative;
        background-color: #f9f9f9;
        transition: background-color 0.3s ease;
        cursor: pointer;
    }

    .drop-area:hover {
        background-color: #f0f7ff;
    }

    .drop-message {
        color: #4a90e2;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .upload-text {
        font-size: 16px;
        font-weight: 500;
    }

    .clickable {
        color: #357ABD;
        text-decoration: underline;
    }

    #fileInput {
        display: none;
    }

    #reviewFileInput {
        display: none;
    }

    #publish_fileInput {
        display: none;
    }

    .preview-list {
        margin-top: 20px;
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        justify-content: flex-start;
    }

    .preview-item {
        width: 150px;
        border: 1px solid #ddd;
        border-radius: 10px;
        background: white;
        box-shadow: 0 0 10px rgba(74, 144, 226, 0.2);
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 10px;
        position: relative;
    }

    .preview-thumb {
        width: 100%;
        height: 100px;
        object-fit: cover;
        border-radius: 6px;
        margin-bottom: 8px;
    }

    .no-preview {
        width: 100%;
        height: 100px;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #f5f5f5;
        color: #888;
        font-size: 50px;
        border-radius: 6px;
        margin-bottom: 8px;
    }

    .preview-filename {
        font-weight: 600;
        text-align: center;
        margin-bottom: 6px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        width: 100%;
    }

    .preview-size {
        color: #666;
        font-size: 12px;
        margin-bottom: 8px;
    }

    .progress-bar {
        width: 100%;
        height: 6px;
        background-color: #eee;
        border-radius: 3px;
        overflow: hidden;
        margin-bottom: 6px;
    }

    .progress-bar-inner {
        height: 100%;
        width: 0;
        background-color: #4a90e2;
        transition: width 0.3s ease;
    }

    .remove-btn {
        position: absolute;
        top: 6px;
        right: 6px;
        background: #ff4d4d;
        border: none;
        border-radius: 50%;
        color: white;
        font-weight: bold;
        width: 24px;
        height: 24px;
        cursor: pointer;
        line-height: 22px;
        text-align: center;
        padding: 0;
    }
</style>

{{-- Dropzone.js File Upload Via AJAX --}}
<script>
    const dropArea = document.getElementById("dropArea");
    const fileInput = document.getElementById("fileInput");
    const previewList = document.getElementById("previewList");
    const dropMessage = document.getElementById("dropMessage");
    let uploadedFiles = [];

    // Make whole drop area clickable
    dropArea.addEventListener("click", () => fileInput.click());

    dropArea.addEventListener("dragover", e => {
        e.preventDefault();
        dropArea.classList.add("bg-light");
    });

    dropArea.addEventListener("dragleave", e => {
        e.preventDefault();
        dropArea.classList.remove("bg-light");
    });

    dropArea.addEventListener("drop", e => {
        e.preventDefault();
        dropArea.classList.remove("bg-light");
        if (e.dataTransfer.files.length) {
            handleFiles(e.dataTransfer.files);
        }
    });

    fileInput.addEventListener("change", e => {
        if (e.target.files.length) {
            handleFiles(e.target.files);
        }
    });

    function humanFileSize(size) {
        const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
        return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
    }

    function handleFiles(files) {
        dropMessage.style.display = "none";
        [...files].forEach(file => {
            const previewItem = document.createElement("div");
            previewItem.className = "preview-item";

            const removeBtn = document.createElement("button");
            removeBtn.className = "remove-btn";
            removeBtn.innerHTML = "&times;";
            removeBtn.onclick = () => {
                previewList.removeChild(previewItem);
                uploadedFiles = uploadedFiles.filter(f => f.name !== file.name);
                if (!previewList.hasChildNodes()) {
                    dropMessage.style.display = "block";
                }
            };
            previewItem.appendChild(removeBtn);

            if (file.type.startsWith("image/")) {
                const img = document.createElement("img");
                img.className = "preview-thumb";
                const reader = new FileReader();
                reader.onload = e => img.src = e.target.result;
                reader.readAsDataURL(file);
                previewItem.appendChild(img);
            } else {
                const noPreview = document.createElement("div");
                noPreview.className = "no-preview";
                noPreview.textContent = "📄";
                previewItem.appendChild(noPreview);
            }

            const nameDiv = document.createElement("div");
            nameDiv.className = "preview-filename";
            nameDiv.textContent = file.name;
            previewItem.appendChild(nameDiv);

            const sizeDiv = document.createElement("div");
            sizeDiv.className = "preview-size";
            sizeDiv.textContent = humanFileSize(file.size);
            previewItem.appendChild(sizeDiv);

            const progressBar = document.createElement("div");
            progressBar.className = "progress-bar";
            const progressBarInner = document.createElement("div");
            progressBarInner.className = "progress-bar-inner";
            progressBar.appendChild(progressBarInner);
            previewItem.appendChild(progressBar);

            previewList.appendChild(previewItem);
            uploadFile(file, progressBarInner);
        });
    }

    function uploadFile(file, progressElement) {
        const url = "{{ route('upload_journal') }}";
        const formData = new FormData();
        formData.append("file_upload[]", file);

        const xhr = new XMLHttpRequest();
        xhr.open("POST", url, true);
        xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

        xhr.upload.onprogress = function (e) {
            if (e.lengthComputable) {
                const percent = (e.loaded / e.total) * 100;
                progressElement.style.width = percent + "%";
            }
        };

        xhr.onload = function () {
            if (xhr.status === 200) {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    uploadedFiles = uploadedFiles.concat(res.files);
                    document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);
                    progressElement.style.backgroundColor = "#28a745";
                } else {
                    progressElement.style.backgroundColor = "#dc3545";
                    alert("Upload failed: " + (res.message || "Unknown error"));
                }
            } else {
                progressElement.style.backgroundColor = "#dc3545";
                alert("Upload failed with status " + xhr.status);
            }
        };

        xhr.onerror = function () {
            progressElement.style.backgroundColor = "#dc3545";
            alert("Upload error.");
        };

        xhr.send(formData);
    }
</script>

<script>
    // Create card for database journal (different structure)
  function createDatabaseJournalCard(journal) {
    return `
      <div class="col-lg-12 mb-2">
        <div class="fs-7 fw-bold text-danger">${journal.journal_name || 'N/A'}</div>
    </div>
    <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
            <label class="me-2" title="Domain">
                <i class="mdi mdi-web fs-4 text-black"></i>
            </label>
            <label class="fs-7 align-items-center text-black fw-semibold">
                ${
                Array.isArray(journal.domains) && journal.domains.length
                ? journal.domains.map(d => d.name).join(', ')
                : 'N/A'
                }
            </label>
        </div>
    </div>
    <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
            <label class="me-2" title="Journal Link">
                <i class="mdi mdi-link fs-4 text-black"></i>
            </label>
            <label class="fs-7 align-items-center text-black fw-semibold">
                ${journal.journal_link ? `<a href="${journal.journal_link}" target="_blank"
                    rel="noopener noreferrer">${journal.journal_link}</a>` : 'N/A'}
            </label>
        </div>
    </div>
    <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
            <label class="me-2" title="Journal Scores">
                <i class="mdi mdi-chart-bar fs-4 text-black"></i>
            </label>
            <label class="fs-7 align-items-center text-black fw-semibold">
                <span>
                    ${
                    Array.isArray(journal.journal_score) && journal.journal_score.length
                    ? journal.journal_score.map(score => `${score.index_name}: ${score.score}`).join(', ')
                    : 'N/A'
                    }
                </span>
            </label>
        </div>
    </div>
    <hr class="border border-info" />
    `;
  }

  // Create card for online/recommended journals
  function createJournalCard(journal) {
    return `
      <div class="col-lg-12 mb-2">
        <div class="fs-7 fw-bold text-danger">${journal.journal_name || 'N/A'}</div>
      </div>
      <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
          <label class="me-2" title="Domain">
            <i class="mdi mdi-web fs-4 text-black"></i>
          </label>
          <label class="fs-7 align-items-center text-black fw-semibold">
            <span>${
                journal.domain
                ? journal.domain
                : (Array.isArray(journal.domains) && journal.domains.length
                ? journal.domains.map(d => d.name).join(', ')
                : 'N/A')
                }
            </span>
          </label>
        </div>
      </div>
      <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
          <label class="me-2" title="Journal Link">
            <i class="mdi mdi-link fs-4 text-black"></i>
          </label>
          <label class="fs-7 align-items-center text-black fw-semibold">
            ${journal.journal_link ? `<a href="${journal.journal_link}" target="_blank" rel="noopener noreferrer">${journal.journal_link}</a>` : 'N/A'}
          </label>
        </div>
      </div>
      <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
          <label class="me-2" title="Journal Scores">
            <i class="mdi mdi-chart-bar fs-4 text-black"></i>
          </label>
          <label class="fs-7 align-items-center text-black fw-semibold">
            <span>
              ${
            Array.isArray(journal.journal_score) && journal.journal_score.length
            ? journal.journal_score.map(score => `${score.index_name}: ${score.score}`).join(', ')
            : 'N/A'
            }
            </span>
          </label>
        </div>
      </div>
      <hr class="border border-info" />
    `;
  }

  function populateJournals(data) {
    const databaseContainer = document.getElementById('databaseContainer');
    const onlineSearchContainer = document.getElementById('onlineSearchContainer');
    const recommendedContainer = document.getElementById('recommendedContainer');

    databaseContainer.innerHTML = '';
    onlineSearchContainer.innerHTML = '';
    recommendedContainer.innerHTML = '';

    const database = data.database_journal || [];
    const online = data.online_journal || [];
    const recommended = data.recommended_journal ? [data.recommended_journal] : [];
    const recommendedOnline = data.recommended_online_journal ? [data.recommended_online_journal] : [];

    // Database journals
    if (database.length) {
      database.forEach(journal => {
        const div = document.createElement('div');
        div.innerHTML = createDatabaseJournalCard(journal);
        databaseContainer.appendChild(div);
      });
    } else {
      databaseContainer.innerHTML = `<div class="fs-7 fw-bold text-muted">No database journals found.</div>`;
    }

    // Online search journals
    if (online.length) {
      online.forEach(journal => {
        const div = document.createElement('div');
        div.innerHTML = createJournalCard(journal);
        onlineSearchContainer.appendChild(div);
      });
    } else {
      onlineSearchContainer.innerHTML = `<div class="fs-7 fw-bold text-muted">No online search journals found.</div>`;
    }

    // Recommended journals
    if (recommended.length || recommendedOnline.length) {
      [...recommended, ...recommendedOnline].forEach(journal => {
        const div = document.createElement('div');
        div.innerHTML = createJournalCard(journal);
        recommendedContainer.appendChild(div);
      });
      recommendedContainer.style.display = 'flex';
      recommendedContainer.style.flexWrap = 'wrap';
      recommendedContainer.style.gap = '1rem';
    } else {
      recommendedContainer.innerHTML = `<div class="fs-7 fw-bold text-muted">No recommended journals found.</div>`;
      recommendedContainer.style.display = '';
    }

    // Initialize Bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"], [title]'));
    tooltipTriggerList.map(el => new bootstrap.Tooltip(el));
  }

  // Trigger search
  document.getElementById('searchBtn').addEventListener('click', () => {
    const paperName = document.getElementById('journalInput').value.trim();
    if (!paperName) {
      alert('Please enter a paper name');
      return;
    }

    const searchBtn = document.getElementById('searchBtn');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const resultsContainer = document.getElementById('results');

    searchBtn.disabled = true;
    loadingSpinner.style.display = 'flex';
    resultsContainer.style.display = 'none';

    fetch('/journal_search', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': '{{ csrf_token() }}' // adjust this if not Blade
      },
      body: JSON.stringify({ prompt: paperName })
    })
      .then(res => {
        if (!res.ok) throw new Error('Network response was not ok');
        return res.json();
      })
      .then(data => {
        populateJournals(data);
        resultsContainer.style.display = 'flex';
        resultsContainer.style.gap = '1rem';
      })
      .catch(err => {
        console.error('Fetch error:', err);
        alert('Error fetching journal data');
      })
      .finally(() => {
        searchBtn.disabled = false;
        loadingSpinner.style.display = 'none';
      });
  });
</script>

<!-- Journal Staff Assign Data Fetch -->
<script>
    function AssignStaff(id) {
        $.ajax({
            url: `/journal_staff_assign/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {
                    var journal = response.data;                    

                    // Assigning Values
                    $('#assgn_service_id').val(journal.sno);
                    $('#assgn_service').html(`${journal.service_name} ( ${journal.service_id} )`);
                    $('#assgn_cus').html(`${journal.cus_name} ( ${journal.cus_id} )`);
                    $('#assgn_mobile').html(journal.cus_mobile ?? '-');
                    $('#assgn_mail').html(journal.cus_email_id ?? '-');

                    // Fetch Staff Data
                    const staffList = response.staff;
                    let options = `<option value="">Select Staff</option>`;

                    staffList.forEach(function (staff) {
                        if(staff.dept_id == 14) {                            
                            options += `<option value="${staff.sno}">${staff.staff_name} - ${staff.position_name}</option>`;
                        }
                    });
                    $('#assgn_staff_id').html(options);

                } else {
                    console.error(`Data Fetching Failed`);
                }
            },
            error: function(xhr, status, error) {
                console.error(`Error Assigning Staff: ${error}`);
            }
        });
    }

    // Assign Staff Validation
    $(document).ready(function () {
        
        // Assign Staff Validation
        $('#assign_journal_staff').on('submit', function(e) {

            $('#assgn_staff_err').text('');
            const selectedStaff = $('#assgn_staff_id').val();
            
            if (selectedStaff === '') {
                e.preventDefault();
                $('#assgn_staff_err').text('Assign the staff.');
                $('#assgn_staff_id').focus();
            }
        });
        
        // Remove Existing Error
        $('#assgn_staff_id').on('change', function () {
            if ($(this).val() !== '') {
                $('#assgn_staff_err').text('');
            }
        });
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
    const modals = document.querySelectorAll('.modal');

    modals.forEach(modal => {
        modal.addEventListener('hidden.bs.modal', function () {
        // Reset all forms inside the modal
        modal.querySelectorAll('form').forEach(form => form.reset());
        databaseContainer.innerHTML = '';
        onlineSearchContainer.innerHTML = '';
        recommendedContainer.innerHTML = '';


        // Clear all error messages
        modal.querySelectorAll('.text-danger').forEach(el => {
            if (el.textContent.trim() === '*') return;
            el.textContent = '';
        });

        // Clear hidden inputs (optional)
        modal.querySelectorAll('input[type="hidden"]').forEach(input => {
            input.value = '';
        });

        // Reset all selects
        modal.querySelectorAll('select').forEach(select => {
            select.selectedIndex = 0;

            // If using Select2 or similar, trigger update
            if ($(select).hasClass('select3')) {
            $(select).val('').trigger('change');  // reset to empty or default value
            }
        });
        });
    });
    });
</script>

<!-- FETCH SUBMIT JOURNAL -->
<script>
    function fetchData(id){
        fetch(`fetch_add_data/${id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{csrf_token()}}'
            }
        })
        .then(res => res.json())
        .then(data => {
            if(data.status === 200){
                var journal = data.data;

                $('#add_services').html(`${journal.service_name} ( ${journal.service_id} )`);
                $('#cus_info').html(`${journal.cus_name} ( ${journal.cus_id} )`);
                $('#customer_id').val(journal.cus_sno);
                $('#customer_services_id').val(journal.sno);
                $('#paper_name').val(journal.journal_paper_name);
                $('#paper_desc').val(journal.journal_paper_desc);
                getJournalBookletData();

            } else {
                console.log('Error Fetching Data !');
            }
        })
        .catch(error => {
            console.log(`Error fetching Data : ${error}`);
        });
    }
</script>

<!-- SUBMIT JOURNAL -->
<script>
    function submitJournal() {

        let formData = {};

        const emails = [];
        const passwords = [];

        $('.journal_email').each(function() {
            emails.push($(this).val());
        });
        $('.journal_pass').each(function() {
            passwords.push($(this).val());
        });

        formData = {
            uploaded_files: $('#uploaded_files').val(),
            customer_id: $('#customer_id').val(),
            customer_services_id: $('#customer_services_id').val(),
            journal_booklet_id: $('#journal_booklet_id').val(),
            paper_name: $('#paper_name').val(),
            paper_desc: $('#paper_desc').val(),
            submitted_date: $('#journal_submitted_date').val(),
            email: emails,
            password: passwords,
            _token: $('meta[name="csrf-token"]').attr('content')
        }

        $.ajax({
            url: `/submit_journal`,
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {
                    location.reload();
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message || 'An error occurred');
                }
            },
            error: function(xhr, status, error) {
                // Handle different HTTP status codes
                if (xhr.status === 409) {
                    // Journal name already exists
                    toastr.error(xhr.responseJSON?.message || 'Journal name already exists!');
                } else if (xhr.status === 422) {
                    // Validation errors
                    const errors = xhr.responseJSON?.errors;
                    if (errors) {
                        // Display validation errors for each field
                        Object.keys(errors).forEach(field => {
                            toastr.error(errors[field][0]);
                        });
                    } else {
                        toastr.error(xhr.responseJSON?.message || 'Validation failed!');
                    }
                } else if (xhr.status === 500) {
                    // Server error
                    toastr.error(xhr.responseJSON?.message || 'Server error occurred!');
                } else {
                    // Other errors
                    toastr.error('An unexpected error occurred: ' + error);
                }
                
                console.error('Error submitting journal:', xhr.responseJSON || error);
            }
        });
    }
</script>

<!-- JOURNAL BOOKLET DATA FETCH -->
<script>
    function getJournalBookletData() {
        $.ajax({
            url: `/get_journal_booklet_data`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200){
                    const booklet = response.data;
                    const bookletContainer = $('#journal_booklet_id');
                    bookletContainer.empty();

                    bookletContainer.append(`<option value="">Select Journal Booklet</option>`);

                    booklet.forEach(book => {
                        bookletContainer.append(`<option value="${book.sno}">${book.journal_name}</option>`);
                    });
                } else {
                    console.log('Error Fetching Journal Booklet Data!');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching journal booklet data:', error);
            }
        });
    }
</script>

<!-- JOURNAL REVIEW DATA FETCH -->
<script>
    function getJournalReviewData(id) {
        $.ajax({
            url: `/get_journal_review_data/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {

                $('#reviewer_comment_err').text('');

                if(response.status === 200){
                    $('[data-bs-toggle="tooltip"]').tooltip('dispose');

                    $('#review_journal_id').val(id);
                    $('#reviewed_customer').html(`${response.data.cus_name} (${response.data.customer_id})`).attr('title', `${response.data.cus_name} (${response.data.customer_id})`);
                    $('#reviewed_services').html(`${response.data.service_name} ( ${response.data.category_name || 'Package'} )`).attr('title', `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`);
                    $('#reviewed_journal').html(`${response.data.journal_name}`).attr('title', `${response.data.journal_name}`);
                    $('#reviewed_paper').html(`${response.data.paper_name} ( ${response.data.journal_id} )`).attr('title', `${response.data.paper_name} ( ${response.data.journal_id} )`);
                    $('#reviewed_domain').html(response.data.domain_names.join(', '));

                    $('[data-bs-toggle="tooltip"]').tooltip();
                } else {
                    console.log('Error Fetching Journal Review Data!');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching journal review data:', error);
            }
        });
    }
</script>

<!-- REVIEW DROPZONE -->
<script>
    const reviewDropArea = document.getElementById("reviewDropArea");
    const reviewFileInput = document.getElementById("reviewFileInput");
    const reviewPreviewList = document.getElementById("reviewPreviewList");
    const reviewDropMessage = document.getElementById("reviewDropMessage");
    let reviewUploadedFiles = [];

    // Make whole drop area clickable
    reviewDropArea.addEventListener("click", () => reviewFileInput.click());

    reviewDropArea.addEventListener("dragover", e => {
        e.preventDefault();
        reviewDropArea.classList.add("bg-light");
    });

    reviewDropArea.addEventListener("dragleave", e => {
        e.preventDefault();
        reviewDropArea.classList.remove("bg-light");
    });

    reviewDropArea.addEventListener("drop", e => {
        e.preventDefault();
        reviewDropArea.classList.remove("bg-light");
        if (e.dataTransfer.files.length) {
            reviewHandleFiles(e.dataTransfer.files);
        }
    });

    reviewFileInput.addEventListener("change", e => {
        if (e.target.files.length) {
            reviewHandleFiles(e.target.files);
        }
    });

    function reviewHumanFileSize(size) {
        const reviewI = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
        return (size / Math.pow(1024, reviewI)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][reviewI];
    }

    function reviewHandleFiles(files) {
        reviewDropMessage.style.display = "none";
        [...files].forEach(file => {
            const reviewPreviewItem = document.createElement("div");
            reviewPreviewItem.className = "preview-item";

            const removeBtn = document.createElement("button");
            removeBtn.className = "remove-btn";
            removeBtn.innerHTML = "&times;";
            removeBtn.onclick = () => {
                reviewPreviewList.removeChild(reviewPreviewItem);
                reviewUploadedFiles = reviewUploadedFiles.filter(f => f.name !== file.name);
                if (!reviewPreviewList.hasChildNodes()) {
                    reviewDropMessage.style.display = "block";
                }
            };
            reviewPreviewItem.appendChild(removeBtn);

            if (file.type.startsWith("image/")) {
                const img = document.createElement("img");
                img.className = "preview-thumb";
                const reader = new FileReader();
                reader.onload = e => img.src = e.target.result;
                reader.readAsDataURL(file);
                reviewPreviewItem.appendChild(img);
            } else {
                const noPreview = document.createElement("div");
                noPreview.className = "no-preview";
                noPreview.textContent = "📄";
                reviewPreviewItem.appendChild(noPreview);
            }

            const nameDiv = document.createElement("div");
            nameDiv.className = "preview-filename";
            nameDiv.textContent = file.name;
            reviewPreviewItem.appendChild(nameDiv);

            const sizeDiv = document.createElement("div");
            sizeDiv.className = "preview-size";
            sizeDiv.textContent = reviewHumanFileSize(file.size);
            reviewPreviewItem.appendChild(sizeDiv);

            const progressBar = document.createElement("div");
            progressBar.className = "progress-bar";
            const progressBarInner = document.createElement("div");
            progressBarInner.className = "progress-bar-inner";
            progressBar.appendChild(progressBarInner);
            reviewPreviewItem.appendChild(progressBar);

            reviewPreviewList.appendChild(reviewPreviewItem);
            reviewUploadFile(file, progressBarInner);
        });
    }

    function reviewUploadFile(file, progressElement) {
        const reviewURL = "{{ route('reviewed_files') }}";
        const reviewFormData = new FormData();
        reviewFormData.append("file_upload[]", file);

        const reviewxhr = new XMLHttpRequest();
        reviewxhr.open("POST", reviewURL, true);
        reviewxhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

        reviewxhr.upload.onprogress = function (e) {
            if (e.lengthComputable) {
                const percent = (e.loaded / e.total) * 100;
                progressElement.style.width = percent + "%";
            }
        };

        reviewxhr.onload = function () {
            if (reviewxhr.status === 200) {
                const res = JSON.parse(reviewxhr.responseText);
                if (res.success) {
                    reviewUploadedFiles = reviewUploadedFiles.concat(res.files);
                    document.getElementById("reviewed_files").value = JSON.stringify(reviewUploadedFiles);
                    progressElement.style.backgroundColor = "#28a745";
                } else {
                    progressElement.style.backgroundColor = "#dc3545";
                    alert("Upload failed: " + (res.message || "Unknown error"));
                }
            } else {
                progressElement.style.backgroundColor = "#dc3545";
                alert("Upload failed with status " + reviewxhr.status);
            }
        };

        reviewxhr.onerror = function () {
            progressElement.style.backgroundColor = "#dc3545";
            alert("Upload error.");
        };

        reviewxhr.send(reviewFormData);
    }
</script>

<!-- REVIEW JOURNAL VALIDATION -->
<script>
    function validateReviewForm() {
        const reviewerComment = $('#reviewer_comment').val();
        let reviweErr = false;

        $('#reviewer_comment_err').text('');
        
        if (reviewerComment === "") {
            $('#reviewer_comment_err').text("Reviewer comment is required!");
            reviweErr = true;
        }

        if(reviweErr) {
            return false;
        } else {
            $.ajax({
                url: '/journal_review_status/' + $('#review_journal_id').val(),
                method: 'POST',
                data: {
                    reviewer_comment: reviewerComment,
                    reviewed_files: JSON.stringify(reviewUploadedFiles),
                    reviewed_date: $('#journal_reviewed_date').val(),
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    if(response.status === 200){
                        toastr.success('Review submitted successfully!');
                        location.reload();
                    } else {
                        console.log('Error Submitting Review:', response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error submitting review:', error);
                }
            });
        }

        return true;
    }
</script>

<!-- JOURNAL RESUBMITTED DATA FETCH -->
<script>
    function getJournalResubmitData(id) {
        $.ajax({
            url: `/get_journal_resubmit_data/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200){
                    $('#resubmit_journal_id').val(id);
                    $('#resubmitted_customer').html(`${response.data.cus_name} (${response.data.customer_id})`).attr('title', `${response.data.cus_name} (${response.data.customer_id})`);
                    $('#resubmitted_services').html(`${response.data.service_name} ( ${response.data.category_name || 'Package'} )`).attr('title', `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`);
                    $('#resubmitted_journal').html(`${response.data.journal_name}`).attr('title', `${response.data.journal_name}`);
                    $('#resubmitted_paper').html(`${response.data.paper_name} ( ${response.data.journal_id} )`).attr('title', `${response.data.paper_name} ( ${response.data.journal_id} )`);
                    $('#resubmitted_domain').html(response.data.domain_names.join(', '));
                } else {
                    console.log('Error Fetching Journal Review Data!');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching journal review data:', error);
            }
        });
    }
</script>

<!-- RESUBMIT JOURNAL SUBVMIT -->
<script>
    function submitResubmitForm() {

        const resubmittedDate = $('#journal_resubmitted_date').val();
        
        $.ajax({
            url: '/journal_resubmit_status/' + $('#resubmit_journal_id').val(),
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                resubmitted_date: resubmittedDate
            },
            success: function(response) {
                if(response.status === 200){
                    toastr.success('Journal resubmitted successfully!');
                    location.reload();
                } else {
                    console.log('Error Resubmitting Journal:', response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error resubmitting journal:', error);
            }
        });
    }
</script>

<!-- JOURNAL ACCEPTED DATA FETCH -->
<script>
    function getJournalAcceptData(id) {
        $.ajax({
            url: `/get_journal_accept_data/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200){
                    $('#accepted_journal_id').val(id);
                    $('#accepted_customer').html(`${response.data.cus_name} (${response.data.customer_id})`).attr('title', `${response.data.cus_name} (${response.data.customer_id})`);
                    $('#accepted_services').html(`${response.data.service_name} ( ${response.data.category_name || 'Package'} )`).attr('title', `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`);
                    $('#accepted_journal').html(`${response.data.journal_name}`).attr('title', `${response.data.journal_name}`);
                    $('#accepted_paper').html(`${response.data.paper_name} ( ${response.data.journal_id} )`).attr('title', `${response.data.paper_name} ( ${response.data.journal_id} )`);
                    $('#accepted_domain').html(response.data.domain_names.join(', '));
                } else {
                    console.log('Error Fetching Journal Review Data!');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching journal review data:', error);
            }
        });
    }
</script>

<!-- Filter By Status -->
<script>
    function filterByStatus(status) {
        const url = new URL(window.location.href);
 
        if (status !== undefined && status !== null) {
            url.searchParams.set('status', status);
        } else {
            url.searchParams.delete('status');
        }
 
        url.searchParams.delete('page');
 
        window.location.href = url.toString();
    }
 
    function clearStatusFilter() {
        const url = new URL(window.location.href);
        url.searchParams.delete('status');
        window.location.href = url.toString();
    }
    document.addEventListener('DOMContentLoaded', function() {
        if (window.location.search.includes('status=')) {
            // Replace current URL without status parameter
            const cleanUrl = window.location.pathname + window.location.search.replace(/[?&]status=[^&]*(&|$)/, '$1').replace(/[?&]$/, '');
            history.replaceState({}, document.title, cleanUrl);
        }
    });
</script>

<!-- ACCEPTED JOURNAL SUBVMIT -->
<script>
    function submitAcceptForm() {
        $.ajax({
            url: '/journal_accept_status/' + $('#accepted_journal_id').val(),
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                accepted_date: $('#journal_accepted_date').val()
            },
            success: function(response) {
                if(response.status === 200){
                    toastr.success('Journal Accepted successfully!');
                    location.reload();
                } else {
                    console.log('Error Resubmitting Journal:', response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error resubmitting journal:', error);
            }
        });
    }
</script>

<!-- JOURNAL REJECTED DATA FETCH -->
<script>
    function getJournalRejectData(id) {
        $.ajax({
            url: `/get_journal_reject_data/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {

                $('#rejected_reason_error').text('');

                if(response.status === 200){
                    $('[data-bs-toggle="tooltip"]').tooltip('dispose');

                    $('#journal_reject_id').val(id);
                    $('#rejected_customer').html(`${response.data.cus_name} (${response.data.customer_id})`).attr('title', `${response.data.cus_name} (${response.data.customer_id})`);
                    $('#rejected_service').html(`${response.data.service_name} ( ${response.data.category_name || 'Package'} )`).attr('title', `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`);
                    $('#rejected_journal_name').html(`${response.data.journal_name}`).attr('title', `${response.data.journal_name}`);
                    $('#rejected_paper_name').html(`${response.data.paper_name} ( ${response.data.journal_id} )`).attr('title', `${response.data.paper_name} ( ${response.data.journal_id} )`);
                    $('#rejected_domains').html(response.data.domain_names.join(', '));

                    $('[data-bs-toggle="tooltip"]').tooltip();
                } else {
                    console.log('Error Fetching Journal Review Data!');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching journal review data:', error);
            }
        });
    }
</script>

<!-- REJECT JOURNAL VALIDATION -->
<script>
    function validateRejectForm() {
        const rejectReason = $('#rejected_reason').val();
        let reviweErr = false;

        $('#rejected_reason_error').text('');
        
        if (rejectReason === "") {
            $('#rejected_reason_error').text("Reject reason is required!");
            reviweErr = true;
        }

        if(reviweErr) {
            return false;
        } else {
            $.ajax({
                url: '/journal_reject_status/' + $('#journal_reject_id').val(),
                method: 'POST',
                data: {
                    reject_reason: rejectReason,
                    rejected_date: $('#journal_rejected_date').val(),
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    if(response.status === 200){
                        toastr.success('Journal rejected successfully!');
                        location.reload();
                    } else {
                        console.log('Error Submitting Reject:', response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error submitting reject:', error);
                }
            });
        }

        return true;
    }
</script>

<!-- JOURNAL PUBLISHED DATA FETCH -->
<script>
    function getJournalPublishData(id) {
        $.ajax({
            url: `/get_journal_publish_data/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {

                $('#publish_date_error, #publish_paper_error, #publish_url_error, #publish_author_error').text('');

                if(response.status === 200){
                    $('[data-bs-toggle="tooltip"]').tooltip('dispose');

                    $('#published_id').val(id);
                    $('#published_customer').html(`${response.data.cus_name} (${response.data.customer_id})`).attr('title', `${response.data.cus_name} (${response.data.customer_id})`);
                    $('#published_services').html(`${response.data.service_name} ( ${response.data.category_name || 'Package'} )`).attr('title', `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`);
                    $('#published_journal').html(`${response.data.journal_name}`).attr('title', `${response.data.journal_name}`);
                    $('#published_paper').html(`${response.data.paper_name} ( ${response.data.journal_id} )`).attr('title', `${response.data.paper_name} ( ${response.data.journal_id} )`);
                    $('#published_domain').html(response.data.domain_names.join(', '));

                    $('[data-bs-toggle="tooltip"]').tooltip();
                } else {
                    console.log('Error Fetching Journal Review Data!');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching journal review data:', error);
            }
        });
    }
</script>

<!-- PUBLISHED JOURNAL DROPZONE -->
<script>
    (function (){
        const dropArea = document.getElementById("publish_dropArea");
        const fileInput = document.getElementById("publish_fileInput");
        const previewList = document.getElementById("publish_previewList");
        const dropMessage = document.getElementById("publish_dropMessage");
        let publisheduploadedFiles = [];

        // Make whole drop area clickable
        dropArea.addEventListener("click", () => fileInput.click());

        dropArea.addEventListener("dragover", e => {
            e.preventDefault();
            dropArea.classList.add("bg-light");
        });

        dropArea.addEventListener("dragleave", e => {
            e.preventDefault();
            dropArea.classList.remove("bg-light");
        });

        dropArea.addEventListener("drop", e => {
            e.preventDefault();
            dropArea.classList.remove("bg-light");
            if (e.dataTransfer.files.length) {
                handleFiles(e.dataTransfer.files);
            }
        });

        fileInput.addEventListener("change", e => {
            if (e.target.files.length) {
                handleFiles(e.target.files);
            }
        });

        function humanFileSize(size) {
            const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
            return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
        }

        function handleFiles(files) {
            dropMessage.style.display = "none";
            [...files].forEach(file => {
                const previewItem = document.createElement("div");
                previewItem.className = "preview-item";

                const removeBtn = document.createElement("button");
                removeBtn.className = "remove-btn";
                removeBtn.innerHTML = "&times;";
                removeBtn.onclick = () => {
                    previewList.removeChild(previewItem);
                    publisheduploadedFiles = publisheduploadedFiles.filter(f => f.name !== file.name);
                    if (!previewList.hasChildNodes()) {
                        dropMessage.style.display = "block";
                    }
                };
                previewItem.appendChild(removeBtn);

                if (file.type.startsWith("image/")) {
                    const img = document.createElement("img");
                    img.className = "preview-thumb";
                    const reader = new FileReader();
                    reader.onload = e => img.src = e.target.result;
                    reader.readAsDataURL(file);
                    previewItem.appendChild(img);
                } else {
                    const noPreview = document.createElement("div");
                    noPreview.className = "no-preview";
                    noPreview.textContent = "📄";
                    previewItem.appendChild(noPreview);
                }

                const nameDiv = document.createElement("div");
                nameDiv.className = "preview-filename";
                nameDiv.textContent = file.name;
                previewItem.appendChild(nameDiv);

                const sizeDiv = document.createElement("div");
                sizeDiv.className = "preview-size";
                sizeDiv.textContent = humanFileSize(file.size);
                previewItem.appendChild(sizeDiv);

                const progressBar = document.createElement("div");
                progressBar.className = "progress-bar";
                const progressBarInner = document.createElement("div");
                progressBarInner.className = "progress-bar-inner";
                progressBar.appendChild(progressBarInner);
                previewItem.appendChild(progressBar);

                previewList.appendChild(previewItem);
                uploadFile(file, progressBarInner);
            });
        }

        function uploadFile(file, progressElement) {
            const url = "{{ route('published_files') }}";
            const formData = new FormData();
            formData.append("publish_uploaded_files[]", file);

            const xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

            xhr.upload.onprogress = function (e) {
                if (e.lengthComputable) {
                    const percent = (e.loaded / e.total) * 100;
                    progressElement.style.width = percent + "%";
                }
            };

            xhr.onload = function () {
                if (xhr.status === 200) {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success) {
                        publisheduploadedFiles = publisheduploadedFiles.concat(res.files);
                        document.getElementById("publish_uploaded_files").value = JSON.stringify(publisheduploadedFiles);
                        progressElement.style.backgroundColor = "#28a745";
                    } else {
                        progressElement.style.backgroundColor = "#dc3545";
                        alert("Upload failed: " + (res.message || "Unknown error"));
                    }
                } else {
                    progressElement.style.backgroundColor = "#dc3545";
                    alert("Upload failed with status " + xhr.status);
                }
            };

            xhr.onerror = function () {
                progressElement.style.backgroundColor = "#dc3545";
                alert("Upload error.");
            };

            xhr.send(formData);
        }
    })();
</script>

<!-- PUBLISHED DATE PICKER -->
<script>
    $(document).ready(function() {
        var isRtl = false; // Define this as needed
        if ($('.published_date').length) {
            $('.published_date').datepicker({
                todayHighlight: true,
                autoclose: true,
                format: 'd-M-yyyy',
                orientation: isRtl ? 'auto right' : 'auto left'
            });
        }
    });
</script>

<!-- PUBLISHED JOURNAL VALIDATION -->
<script>
    function validatePublishForm() {
        const publishDate = $('#publish_date').val();
        const publishPaperName = $('#publish_paper').val();
        const publishURL = $('#publish_url').val();
        const publishAuthor = $('#publish_author').val();

        // Safe JSON parse
        let publishedFiles = [];
        const uploadedFilesVal = $('#publish_uploaded_files').val();
        if (uploadedFilesVal) {
            try {
                publishedFiles = JSON.parse(uploadedFilesVal);
            } catch (e) {
                console.error('Invalid JSON in uploaded files:', e);
                publishedFiles = [];
            }
        }

        let publishErr = false;

        $('#publish_date_error, #publish_paper_error, #publish_url_error, #publish_author_error').text('');

        if (publishDate === "") {
            $('#publish_date_error').text("Publish date is required!");
            publishErr = true;
        }

        if (publishPaperName === "") {
            $('#publish_paper_error').text("Paper name is required!");
            publishErr = true;
        }

        if (publishURL === "") {
            $('#publish_url_error').text("URL is required!");
            publishErr = true;
        }

        if (publishAuthor === "") {
            $('#publish_author_error').text("Author name is required!");
            publishErr = true;
        }

        if (publishErr) {
            return false;
        }

        $.ajax({
            url: '/journal_publish_status/' + $('#published_id').val(),
            method: 'POST',
            data: {
                publish_date: publishDate,
                paper_name: publishPaperName,
                publish_url: publishURL,
                publish_author: publishAuthor,
                published_files: JSON.stringify(publishedFiles),
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                if(response.status === 200){
                    toastr.success('Journal published successfully!');
                    location.reload();
                } else {
                    console.log('Error Submitting Review:', response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error submitting review:', error);
            }
        });

        return true;
    }

</script>


{{-- --------------------------------Add Requirement------------------------------------ --}}

<script>

    $(document).ready(function() {
    // Track dynamic fields

        // Initially hide the delete button for the first requirement

        // Add more requirement fields dynamically
        $('.staff_reqts_add').on('click', function() {
            // Increment the counter

            // Create the new requirement row dynamically
            var newRequirementHtml = `
                <div class="row mt-4 form-repeater_reqts" id="requirement_row_${requirementCounter}">
                    <div class="col-lg-7 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold" id="requirement_label_${requirementCounter}">
                            Requirements Point ${requirementCounter} <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" placeholder="Enter Requirement Point ${requirementCounter}" id="requirement_name_${requirementCounter}" name="requirement_name[]" />
                        <div class="text-danger err_mssg" id="requirement_name_${requirementCounter}_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Attachments</label>
                        <div class="d-flex align-items-sm-center">
                            <img src="{{asset('assets/phdizone_images/Document.jpg')}}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo_${requirementCounter}" />
                            <div class="ms-1 button-wrapper">
                                <div class="d-flex align-items-start mt-2 mb-2">
                                    <button type="button" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Document" onclick="document.getElementById('document_upload_${requirementCounter}').click();">
                                        <i class="mdi mdi-tray-arrow-up"></i>
                                        <input type="file"id="document_upload_${requirementCounter}" name="document_upload[]" class="file-in" hidden accept="image/png, image/jpeg, application/pdf, text/csv"   onchange="fileChange(event)"  />
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Document" id="uploaded_reset_${requirementCounter}">
                                        <i class="mdi mdi-reload"></i>
                                    </button>
                                </div>
                                <div class="small fs-8">Allowed JPG, PNG, PDF, CSV. Max size 5MB</div>
                                <div class="small text-success fs-8" id="upload_file_name_${requirementCounter}"></div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1">
                        <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_reqts_del" id="staff_reqts_del_${requirementCounter}">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
                </div>
            `;

            // Append the new requirement row
            $('#repeater_req').first().parent().append(newRequirementHtml);
            requirementCounter++;

            // Show the delete button for the new row
            $('#staff_reqts_del_' + requirementCounter).show();

            // Hide delete button for the first requirement
        
        });

        // Delete a requirement row
        $(document).on('click', '.staff_reqts_del', function(e) {
            var deleteId = $(this).attr('id');  // Get the id of the clicked delete button
            var index = deleteId.split('_')[3];  // Extract the counter from the id (e.g., 'staff_reqts_del_2' -> 2)

            // Remove the row
            $('#requirement_row_' + index).slideUp(400, function() {
                $(this).remove(); // Remove the row
                requirementCounter--; // Decrement counter

                // Hide the delete button for the first row if there is only one remaining row
                if (requirementCounter === 1) {
                    $('#staff_reqts_del_1').hide();
                }
            });
        });

        $('#submit_requirements').on('click', function () {
            var valid = true;

            

            var pc_staff =  $('#pc_staff').val();
            if(pc_staff == ''){
                $('.pc_staff_err').html('Select Project Journal Team Lead is required');
                valid = false;
            }else{
                $('.pc_staff_err').html('');
            }

            $('input[name^="requirement_name"]:visible:enabled').each(function () {
                let requirement_name = $(this).val();
                let errDiv = $(this).siblings('.err_mssg');

                if (!requirement_name || requirement_name.trim() === '') {
                    valid = false;
                    errDiv.text('Requirement Point is required');
                } else {
                    errDiv.text('');
                }
            });

            if (valid) {
                $('#requirementForm').submit();
                $('#submit_requirements').prop('disabled', true);
            } else {
                $('#submit_requirements').prop('disabled', false);
            }
        });
    });
    var requirementCounter = 1; 
    function openRequirement(id) {
    requirementCounter = 1; 
        // Reset the form before filling it
        $('.form-repeater_reqts').not(':first').remove();

        $.ajax({
            url: '/journal_requirement_manage_details/' + id, // Adjust with your route
            type: 'GET',
            success: function(response) {
                $('#requirement_lead_name').text(response.customer.cus_name);
                $('#requirement_lead_mobile').text(response.customer.cus_mobile || '-');
                $('#requirement_lead_mail').text(response.customer.cus_email_id || '-');
                $('#requirement_service').html(response.productBadges || '');
                $('#requirement_service_id').val(id);
                $('#requirement_lead_id').val(response.customer.sno);

                $('#requirement_status').val('add');
                requirementCounter = 2;
            },
            error: function(xhr, status, error) {
                console.log('Error fetching requirements.');
            }
        });

        var selectedType = 'jtl_staff';
        $.ajax({
            url: '{{ route('get.ajax.data') }}',  // Use the Laravel route name
        type: 'POST',
        data: {
            _token: '{{ csrf_token() }}',  // CSRF token for security
            type: selectedType            // Send the type as parameter
        },
        success: function(response) {
            if (response.success) {
                // Populate the select dropdown with fetched
                var pc_staffDropdown = $('#pc_staff');
                pc_staffDropdown.empty();
                pc_staffDropdown.append($('<option value="">Select Project Journal Team Lead</option>'));
                response.data.forEach(function(level) {
                    pc_staffDropdown.append($('<option></option>').attr('value', level.sno).text(level.staff_name + ' - ' + level.nick_name));
                });
            }
        },
        error: function(xhr, status, error) {
            var pc_staffDropdown = $('#pc_staff');
            pc_staffDropdown.empty();
            pc_staffDropdown.append($('<option value="">Select Project Journal Team Lead</option>'));
        }
        });

        var selectedservice = 'customer_services';
        $.ajax({
        url: '{{ route('get.ajax.data') }}',  // Use the Laravel route name
        type: 'POST',
        data: {
            _token: '{{ csrf_token() }}',  // CSRF token for security
            cus_id: id,
            type: selectedservice            // Send the type as parameter
        },
        success: function(response) {
            if (response.success) {
                // Populate the select dropdown with fetched
                var ServiceDropdown = $('#customer_services');
                ServiceDropdown.empty();
                ServiceDropdown.append($('<option value="">Select Service</option>'));
                response.data.forEach(function(serv) {
                    ServiceDropdown.append($('<option></option>').attr('value', serv.sno).text(serv.service_id + ' - ' + serv.name + ' - ' + serv.product_category_name));
                });
            }
        },
        error: function(xhr, status, error) {
            var ServiceDropdown = $('#customer_services');
            ServiceDropdown.empty();
            ServiceDropdown.append($('<option value="">Select Service</option>'));
        }
        });
    }

    function triggerFileUpload(counter) {
        // This dynamically targets the file input using the counter
        const visibleFileInput = document.querySelector(`#document_upload_${counter}:not([style*="display: none"])`);
        if (visibleFileInput) {
            visibleFileInput.click();
        }
    }

    function fileChange(e) {
        const inputId = e.target.id;
        const requirementId = inputId.split('_')[2];
        const file = e.target.files[0];

        if (file) {
            const fileName = file.name;
            const fileType = file.type;
            const allowedImageTypes = ['image/jpeg', 'image/png'];

            const docImg = document.querySelector(`#uploadedlogo_${requirementId}:not([style*="display: none"])`);
            const resetBtn =document.querySelector(`#uploaded_reset_${requirementId}:not([style*="display: none"])`);
            const fileNameDisplay = document.querySelector(`#upload_file_name_${requirementId}:not([style*="display: none"])`);
            const defaultImageSrc = "{{asset('assets/phdizone_images/Document.jpg')}}";
            const defaultFileText = fileNameDisplay.innerText;

            // Update file name text
            if (fileNameDisplay) {
                fileNameDisplay.innerText = fileName;
            }

            // Show image preview only for image files
            if (docImg) {
                if (allowedImageTypes.includes(fileType)) {
                    docImg.src = URL.createObjectURL(file);
                } else {
                    docImg.src = defaultImageSrc;
                }
            }

            // Reset logic
            if (resetBtn) {
                resetBtn.onclick = () => {
                    e.target.value = ''; // Clear input
                    if (docImg) docImg.src = defaultImageSrc;
                    if (fileNameDisplay) fileNameDisplay.innerText = defaultFileText;
                };
            }
        }
    }
</script>


<script>
    let logofile = document.getElementById('uploadedlogo');
    const fileInput = document.querySelector('.file-in'),
        resetFileInput = document.querySelector('.file-reset');

    if (logofile) {
        const resetImage = logofile.src;
        fileInput.onchange = () => {
            if (fileInput.files[0]) {
                logofile.src = window.URL.createObjectURL(fileInput.files[0]);
            }
        };
        resetFileInput.onclick = () => {
            fileInput.value = '';
            logofile.src = resetImage;
        };
    }
</script>

@endsection