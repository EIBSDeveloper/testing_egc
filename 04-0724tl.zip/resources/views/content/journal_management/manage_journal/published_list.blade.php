@extends('layouts/layoutMaster')

@section('title', 'Published Journal')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/js/dropdown-hover.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/clipboard/clipboard.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
    <style>
        .table-scroll-wrapper {
            position: relative;
            width: 100%;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .top-scrollbar,
        .bottom-scrollbar {
            width: 100%;
            overflow-x: auto;
            overflow-y: hidden;
            height: 16px;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            flex-shrink: 0;
        }

        .top-scrollbar {
            border-bottom: none;
            margin-bottom: -1px;
            /* Overlap with table */
        }

        .bottom-scrollbar {
            border-top: none;
            margin-top: -1px;
            /* Overlap with table */
        }

        .scroll-content {
            height: 1px;
            /* Minimal height, width will be set by JS */
        }

        .table-container {
            /* width: 100%; */
            overflow-x: hidden;
            overflow-y: auto;
            max-height: 70vh;
            /* scrollbar-width: thin;
                                            scrollbar-color: #c1c1c1 #f1f1f1; */
            flex: 1;
        }

        /* Hide the actual scrollbar but keep functionality */
        .table-container::-webkit-scrollbar {
            width: 12px;
            height: 12px;
        }

        .table-container::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 6px;
        }

        .table-container::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 6px;
        }

        .table-container::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }

        /* Ensure table cells don't wrap */
        .table-container th,
        .table-container td {
            white-space: nowrap;
            min-width: 80px;
        }

        /* Make the table take full width of its content */
        .table-container table {
            width: max-content;
            min-width: 100%;
        }

        /* Sticky header (all th) */
        .sticky_table thead th {
            position: sticky;
            top: 0;
            background: #099dda !important;
            color: #fff;
            text-align: center;
            vertical-align: middle;
            z-index: 50;
            /* default header z-index */
        }

        .profile-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.25s ease-in-out;
            cursor: pointer;
        }

        .profile-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .profile-avatar:hover {
            transform: scale(1.1);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
        }

        .bg-gradient-primary {
            background: linear-gradient(45deg, #007bff, #00c6ff);
        }

        .list_page thead th,
        .list_page tbody td {
            padding: 10px !important;
        }

        .indv_cust_jour thead th,
        .indv_cust_jour tbody td {
            padding: 8px !important;
            border: 1px solid rgb(180, 180, 180) !important;
        }

        .act_bx:hover {
            background-color: #eae1fc;

        }

        .act_bx_selected {
            background-color: #fbecdb !important;
            border: 1px solid #766e6e70 !important;
        }

        .service-master-card {
            backdrop-filter: blur(10px);
            background: #f0913d;
        }

        .stat-card {
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.2) !important;
        }

        .pulse-btn {
            position: relative;
        }

        .pulse-btn::after {
            content: '';
            position: absolute;
            top: -4px;
            left: -4px;
            right: -4px;
            bottom: -4px;
            border: 2px solid #ff6b6b;
            border-radius: 50%;
            animation: pulse 2s infinite;
            opacity: 0;
        }

        @keyframes pulse {
            0% {
                transform: scale(0.95);
                opacity: 0.7;
            }

            70% {
                transform: scale(1.05);
                opacity: 0;
            }

            100% {
                transform: scale(0.95);
                opacity: 0;
            }
        }

        .stage-1 {
            --card-color: #007BFF;
        }

        .stage-2 {
            --card-color: #17A2B8;
        }

        .stage-3 {
            --card-color: #28A745;
        }

        .stage-4 {
            --card-color: #DC3545;
        }

        .stage-5 {
            --card-color: #DC3545;
        }

        .stage-6 {
            --card-color: #17A2B8;
        }

        .stage-7 {
            --card-color: #FF6B6B;
        }

        .stage-8 {
            --card-color: #17A2B8;
        }

        .status-card {
            width: 220px;
            height: 90px;
            border-radius: 12px;
            transition: all 0.2s ease-in-out;
        }

        .style-5 .stage-card {
            text-align: center;
            padding: 15px;
            border: 2px solid transparent;
            background: white;
        }

        .style-5 .circle-count {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: color-mix(in srgb, var(--card-color) 10%, white);
            border: 3px solid var(--card-color);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            transition: all 0.3s ease;
        }

        .style-5 .stage-count {
            font-size: 20px;
            color: var(--card-color);
            transition: all 0.3s ease;
        }

        .section-title {
            color: #1a1a1a;
            margin-bottom: 30px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e9ecef;
            font-weight: 700;
        }

        /* COMMON STYLES */
        .stage-card {
            border-radius: 12px;
            transition: all 0.3s ease;
            cursor: pointer;
            height: 100%;
        }

        .stage-label {
            font-weight: 600;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }

        .stage-count {
            font-weight: 800;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        /* ACTIVE STATE STYLES */
        .style-5 .stage-card.active {
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            border: 2px solid var(--card-color);
            background: color-mix(in srgb, var(--card-color) 5%, white);
            transform: translateY(-5px);
            margin-top: 10px;
        }

        .style-5 .stage-card.active .circle-count {
            background: color-mix(in srgb, var(--card-color) 20%, white);
            border-width: 4px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .style-5 .stage-card.active .stage-count {
            font-size: 22px;
            color: color-mix(in srgb, var(--card-color) 80%, black);
        }

        .style-5 .stage-card.active .stage-label {
            color: var(--card-color);
            font-weight: 700;
            font-size: 0.95rem;
        }

        /* Hover effects */
        .style-5 .stage-card:hover:not(.active) {
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
            border: 2px solid color-mix(in srgb, var(--card-color) 30%, white);
        }

        .style-5 .stage-card:hover:not(.active) .circle-count {
            background: color-mix(in srgb, var(--card-color) 15%, white);
        }

        .style-5 .stage-card:hover:not(.active) .stage-label {
            color: var(--card-color);
        }
    </style>

    @php
        $helper = new \App\Helpers\Helpers();
        $module_name = 'Journal Management';
        $menu_name = 'Published Journal';
    @endphp
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Published Journal</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Journal Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center flex-wrap">
                </div>
            </div>
        </div>
        <div class="card-body">

            <div class="row">
                <div class="col-lg-12 table-responsive">
                    <div class="d-flex align-items-center style-5 style-section" style="gap: 50px !important;">
                        <a href="javascript:;">
                            <div class="stage-card stage-2"
                                style="background-color: {{ $currentStatus == 1 ? '0 0 0 2px #17A2B8' : 'none' }};cursor: pointer;">
                                <div class="circle-count">
                                    <div class="stage-count">
                                        {{ $total_published == 0 ? 0 : str_pad($total_published, 2, '0', STR_PAD_LEFT) }}
                                    </div>
                                </div>
                                <div class="stage-label">Overall Published</div>
                            </div>
                        </a>
                        <a href="javascript:;">
                            <div class="stage-card stage-3"
                                style="background-color: {{ $currentStatus == 3 ? '0 0 0 2px #800080' : 'none' }};cursor: pointer;">
                                <div class="circle-count">
                                    <div class="stage-count">
                                        {{ $this_month_published == 0 ? 0 : str_pad($this_month_published, 2, '0', STR_PAD_LEFT) }}
                                    </div>
                                </div>
                                <div class="stage-label">This Month Published</div>
                            </div>
                        </a>
                        <a href="javascript:;">
                            <div class="stage-card stage-4"
                                style="background-color: {{ $currentStatus == 6 ? '0 0 0 2px #17A2B8' : 'none' }};cursor: pointer;">
                                <div class="circle-count">
                                    <div class="stage-count">
                                        {{ $last_month_published == 0 ? 0 : str_pad($last_month_published, 2, '0', STR_PAD_LEFT) }}
                                    </div>
                                </div>
                                <div class="stage-label">Last Month Published</div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="row mb-4">
                    @php $perpage_count = $perpage ? $perpage : 10; @endphp
                    <div class="col-lg-2">
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                            onchange="sort_filter(this.value);">
                            @php
                                $options = [10, 25, 100, 500]; // Define available options
                            @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}"
                                    @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                                    @php echo $option; @endphp
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-lg-10 d-flex align-items-end justify-content-end">
                        <form id="search_form" method="POST" action="/journal_management/published_journal">
                            @csrf
                            <div class="d-flex align-items-center gap-2 mt-2">
                                <div>
                                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                    <input type="hidden" name="filter_on" value="0">
                                    <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                        id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                    <input type="text" class="form-control" id="search_fill" name="search_fill"
                                        value="{{ $search_fill ?? '' }}" placeholder="Enter Search" />
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                    onclick="search_filter_func()">Search</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-center table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Customers / ID</th>
                                <th class="min-w-150px">Services & Domain / index</th>
                                <th class="min-w-100px">Paper & Booklet / Domain</th>
                                <th class="min-w-50px">Published Date</th>
                                <th class="min-w-150px">Journal Staff</th>
                                <th class="min-w-80px">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7">
                            @foreach ($lists as $i => $list)
                                <tr>
                                    @php
                                        if (count($list->domain_names) > 0) {
                                            $domains = implode(', ', $list->domain_names);
                                        } else {
                                            $domains = 'No Domains';
                                        }
                                    @endphp
                                    @php
                                        $statusColors = [
                                            0 => [
                                                'row' => '#CCE5FF',
                                                'badge' => '#007BFF',
                                                'label' => 'Submitted',
                                            ],
                                            1 => [
                                                'row' => '#d8d9c1 ',
                                                'badge' => '#a8ab14',
                                                'label' => 'With Editor',
                                            ],
                                            5 => [
                                                'row' => '#abc9e9',
                                                'badge' => '#DC3545',
                                                'label' => 'Accepted',
                                            ],
                                            3 => [
                                                'row' => '#e7d4b2 ',
                                                'badge' => '#800080',
                                                'label' => 'Under Reviewer',
                                            ],
                                            4 => [
                                                'row' => '#9dd7c1',
                                                'badge' => '#28A745',
                                                'label' => 'Revision',
                                            ],
                                            6 => [
                                                'row' => '#dbc1c4 ',
                                                'badge' => '#17A2B8',
                                                'label' => 'Rejected',
                                            ],
                                            7 => [
                                                'row' => '#b893b9 ',
                                                'badge' => '#17A2B8',
                                                'label' => 'E-Proofing',
                                            ],
                                            8 => [
                                                'row' => '#6bd2e3  ',
                                                'badge' => '#17A2B8',
                                                'label' => 'Published ',
                                            ],
                                        ];

                                        $status = $list->j_status;
                                        $colors = $statusColors[$status] ?? [
                                            'row' => '#FFFFFF',
                                            'badge' => '#6c757d',
                                            'label' => 'Unknown',
                                        ];
                                        $journalPaper = $list->published_paper_name ?? $list->paper_name;
                                    @endphp
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="mb-0 mx-2">
                                                <label class="text-black text-truncate fw-semibold fs-7"
                                                    style="max-width: 150px;" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="{{ $list->cus_name }}">{{ $list->cus_name }}</label>
                                                <div class="d-block">
                                                    <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Customer ID">
                                                        {{ $list->customer_id }}</div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="mb-0">
                                                <label class="fw-semibold text-black fs-7 text-wrap min-w-200px max-w-275px"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Services: {{ $list->service_name }}">{{ $list->service_name }}
                                                </label>
                                                <div class="d-block mb-1">
                                                    <label
                                                        class="fw-semibold text-danger fs-8 ">{{ $list->service_id }}</label>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column gap-1">
                                            <div class="fs-7 fw-semibold text-black text-truncate" style="width:700px;"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                data-bs-original-title="{{ $journalPaper }}">
                                                {{ $journalPaper }}</div>
                                            <div class="d-flex align-items-center gap-1 ">
                                                <div class="d-flex align-items-center gap-2 ">
                                                    <label
                                                        class="fw-semibold text-danger fs-8 ">{{ $list->journal_id }}</label>
                                                    <label class="text-muted">|</label>
                                                    <div class="d-flex align-items-center gap-2">
                                                        <span class="mdi mdi-book-open-blank-variant"></span>
                                                        <div class="text-truncate" style="max-width:300px;"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            data-bs-original-title="Journal Booklet:{{ $list->journal_name }}">
                                                            {{ $list->journal_name }}</div>
                                                    </div>
                                                    <label class="text-muted">|</label>
                                                    <div class="d-flex align-items-center gap-2">
                                                        <span class="mdi mdi-alpha-i-box"></span>
                                                        <div class="text-truncate" style="max-width:300px; "
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            data-bs-original-title="Domain: {{ $domains }}">
                                                            {{ $domains }}</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                    <td>
                                        <div class="fs-7 fw-bold text-primary text-uppercase p-2 rounded text-truncate"
                                            style="max-width: 200px;">
                                            {{ \Carbon\Carbon::parse($list->publish_date)->format('d-M-Y') }}
                                        </div>
                                        <div class="d-flex align-items-center gap-1">
                                            <div class="badge text-white mb-1 fs-7 fw-semibold"
                                                style="background-color:#7239EA !important;">
                                                Published
                                            </div>
                                            <a href="javascript:;" class="dropdown-toggle hide-arrow"
                                                data-bs-toggle="dropdown">
                                                <i class="ms-1 mdi mdi-information text-info fs-9 animation-blink"></i>
                                            </a>

                                            <div class="dropdown-menu py-2 px-4 text-black">
                                                <div class="row mb-2">
                                                    <div class="col-lg-4 fw-semibold">
                                                        Author</div>
                                                    <div class="col-lg-1">:</div>
                                                    <div class="col-lg-7 fw-bold">
                                                        {{ $list->publish_author ?? '-' }}
                                                    </div>
                                                </div>

                                                <div class="row mb-2">
                                                    <div class="col-lg-4 fw-semibold">
                                                        Published Date</div>
                                                    <div class="col-lg-1">:</div>
                                                    <div class="col-lg-7 fw-bold">
                                                        {{ $list->publish_date ? date('d-M-Y', strtotime($list->publish_date)) : 'N/A' }}
                                                    </div>
                                                </div>

                                                <div class="row mb-2">
                                                    <div class="col-lg-4 fw-semibold">
                                                        Published Link</div>
                                                    <div class="col-lg-1">:</div>
                                                    <div class="col-lg-7 fw-bold">
                                                        <a href="{{ $list->publish_url }}" target="_blank"
                                                            class="d-flex align-items-center gap-1">
                                                            <i class="mdi mdi-link-variant text-danger fs-4"></i>
                                                            <span class="text-truncate text-danger" style="width:200px;">
                                                                {{ $list->publish_url }}
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                    <td class="ps-4">
                                        <div class="d-flex align-items-center gap-4">
                                            <!-- Journal Coordinator -->
                                            <div class="d-flex flex-column align-items-center position-relative">
                                                @if ($list->jc_id)
                                                    @if (
                                                        $list->jouranal_coordinator_image != '' &&
                                                            file_exists(public_path('staff_images/' . $list->jouranal_coordinator_image)))
                                                        <div class="profile-avatar shadow-sm border border-2 border-primary"
                                                            data-bs-toggle="tooltip"
                                                            title="JTL: {{ $list->jouranal_coordinator_name }}">
                                                            <img src="{{ asset('staff_images/' . $list->jouranal_coordinator_image) }}"
                                                                alt="{{ $list->jouranal_coordinator_name }}">
                                                        </div>
                                                    @else
                                                        <div class="profile-avatar bg-primary text-white shadow-sm border border-2 border-primary"
                                                            data-bs-toggle="tooltip"
                                                            title="JTL: {{ $list->jouranal_coordinator_name }}">
                                                            <span>{{ strtoupper(substr($list->jouranal_coordinator_name, 0, 1)) }}</span>
                                                        </div>
                                                    @endif
                                                @else
                                                    <div class="profile-avatar bg-light text-muted border"
                                                        data-bs-toggle="tooltip" title="No Coordinator">
                                                        <i class="mdi mdi-account-off fs-5"></i>
                                                    </div>
                                                @endif
                                                <small class="text-muted mt-1 fw-medium">JTL</small>
                                            </div>

                                            <!-- Journal Staff -->
                                            <div class="d-flex flex-column align-items-center position-relative">
                                                @if ($list->jc_staff)
                                                    @if ($list->journal_staff_image != '' && file_exists(public_path('staff_images/' . $list->journal_staff_image)))
                                                        <div class="profile-avatar shadow-sm border border-2 border-success"
                                                            data-bs-toggle="tooltip"
                                                            title="JE: {{ $list->journal_staff_name }}">
                                                            <img src="{{ asset('staff_images/' . $list->journal_staff_image) }}"
                                                                alt="{{ $list->journal_staff_name }}">
                                                        </div>
                                                    @else
                                                        <div class="profile-avatar bg-success text-white shadow-sm border border-2 border-success"
                                                            data-bs-toggle="tooltip"
                                                            title="JE: {{ $list->journal_staff_name }}">
                                                            <span>{{ strtoupper(substr($list->journal_staff_name, 0, 1)) }}</span>
                                                        </div>
                                                    @endif
                                                @else
                                                    <div class="profile-avatar bg-light text-muted border"
                                                        data-bs-toggle="tooltip" title="No Staff">
                                                        <i class="mdi mdi-account-off fs-5"></i>
                                                    </div>
                                                @endif
                                                <small class="text-muted mt-1 fw-medium">JE</small>
                                            </div>

                                        </div>
                                    </td>
                                    <td>
                                        <span class="text-center">
                                            <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false">
                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                @php
                                                    $encryptedValue = $helper->encrypt_decrypt(
                                                        $list->ser_sno,
                                                        'encrypt',
                                                    );
                                                    $url = url('/view_manage_journal/' . $encryptedValue);
                                                @endphp
                                                {{-- @if (auth()->user()->hasPermission($module_name, 'View', $menu_name)) --}}
                                                <a href="{{ $url }}" class="dropdown-item">
                                                    <span> <i
                                                            class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                                                </a>
                                                {{-- @endif --}}
                                            </div>
                                        </span>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="mt-4">
                    {{ $lists->appends(request()->except(['page', '_token']))->links() }}
                </div>
            </div>
        </div>
    </div>
    </div>



    {{-- Toastr Starts --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        .circular-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .circular-badge:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .bg-purple {
            background-color: #800080 !important;
        }

        /* Customize Toastr container */
        .toast {
            background-color: #313f46;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
    {{-- Toastr Ends --}}

    <!-- JOURNAL DATE PICKER -->
    <script>
        $(document).ready(function() {
            var isRtl = false; // Define this as needed
            if ($('.journal_date').length) {
                $('.journal_date').datepicker({
                    todayHighlight: true,
                    autoclose: true,
                    format: 'd-M-yyyy',
                    orientation: isRtl ? 'auto right' : 'auto left'
                });
            }
        });
    </script>


    <script>
        function open_func(id) {
            var colse_tr_div = document.getElementById("colse_tr_div" + id);

            if (colse_tr_div.style.display == "none") {
                document.getElementById("colse_tr_div" + id).style.display = "table-row";
                document.getElementById("plus_btn" + id).classList.remove("mdi-plus");
                document.getElementById("plus_btn" + id).classList.add("mdi-minus");
                document.getElementById("main_tr_div" + id).style.backgroundColor = "#f9f3c5db";
            } else {
                document.getElementById("colse_tr_div" + id).style.display = "none";
                document.getElementById("plus_btn" + id).classList.remove("mdi-minus");
                document.getElementById("plus_btn" + id).classList.add("mdi-plus");
                document.getElementById("main_tr_div" + id).removeAttribute("style");
            }
        }
    </script>
    <script>
        $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.filter_tbox').slideToggle('fast');
                // });
            @endif
        });

        // Toggle branch filter section
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>
    <script>
        function date_fill_issue_rpt() {
            var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
            var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
            var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
            var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
            var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
            var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
            var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_issue_rpt == "today") {
                today_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "week") {
                today_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "block";
                week_to_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#week_from_date_fil').val(firstday);
                $('#week_to_date_fil').val(lastday);

            } else if (dt_fill_issue_rpt == "monthly") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "block";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "custom_date") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "block";
                to_dt_iss_rpt.style.display = "block";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            }
        }
    </script>

    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>
@endsection
