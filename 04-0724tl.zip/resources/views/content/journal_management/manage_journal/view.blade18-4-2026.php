@extends('layouts/layoutMaster')

@section('title', 'View Journal')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }

    .indv_cust_jour thead th,
    .indv_cust_jour tbody td {
        padding: 8px !important;
        border: 1px solid rgb(180, 180, 180) !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }

    .dwn_arw:hover {
        box-shadow: 0 0 15px 13px rgba(0, 0, 0, 0.2);
        border-radius: 50%;
        background-color: white;
    }
</style>
<!-- Journal List Table -->
<div class="card card-action">
    <div class="card-header flex-wrap border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">
                View <span class="text-info fw-bold fs-3">{{ $view->cus_name }}</span> Journal Details
            </h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Journal Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Manage Journal</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element text-end">
            <div class="text-black fw-semibold fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer ID">{{ $view->customer_id }}</div>
            <div class="d-block text-primary fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Mobile No">( +{{ $view->country_code }} ) {{ $view->cus_mobile }}</div>
            <div class="d-block text-dark fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Email ID">{{ $view->cus_email_id }}</div>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-10">
            <div class="col-lg-8">
                <div class="row mb-1">
                    <div class="col-lg-6 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                        <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">{{ $view->product_name }} - {{ $view->service_id }}</div>
                    </div>
                    <div class="col-lg-6 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Service Category</label>
                        <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">{{ $view->product_category_name }}</div>
                    </div>
                </div>
                <div class="row mb-1">
                    <div class="col-lg-6 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                        <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">{{ $view->domain_names ?? "No Domain" }}</div>
                    </div>
                    <div class="col-lg-6 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Index</label>
                        <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">{{ $view->index_names }}</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="d-flex align-items-center border-bottom border-gray-400i border-dashed border-start-0 border-end-0 border-top-0 justify-content-between flex-wrap mb-2 pb-2">
                    <div class="text-center mb-2">
                        <label class="text-black mb-1 fs-5 fw-semibold">Submitted</label>
                        <div class="d-block">
                            <label class="badge bg-info text-white fs-4 fw-semibold" style="background-color: #007BFF !important;">{{ str_pad($view->submitted_count, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                    <div class="text-center mb-2">
                        <label class="text-black mb-1 fs-5 fw-semibold">Reviewed</label>
                        <div class="d-block">
                            <label class="badge bg-info text-black fs-4 fw-semibold" style="background-color: #FFA500 !important;">{{ str_pad($view->reviewed_count, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                    <div class="text-center mb-2">
                        <label class="text-black mb-1 fs-5 fw-semibold">Resubmitted</label>
                        <div class="d-block">
                            <label class="badge bg-info text-white fs-4 fw-semibold" style="background-color: #800080 !important;">{{ str_pad($view->resubmitted_count, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-between flex-wrap">
                    <div class="text-center mb-2">
                        <label class="text-black mb-1 fs-5 fw-semibold">Accepted</label>
                        <div class="d-block">
                            <label class="badge bg-info text-white fs-4 fw-semibold" style="background-color: #28A745 !important;">{{ str_pad($view->accepted_count, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                    <div class="text-center mb-2">
                        <label class="text-black mb-1 fs-5 fw-semibold">Rejected</label>
                        <div class="d-block">
                            <label class="badge bg-info text-white fs-4 fw-semibold" style="background-color: #DC3545 !important;">{{ str_pad($view->reject_count, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                    <div class="text-center mb-2">
                        <label class="text-black mb-1 fs-5 fw-semibold">Published</label>
                        <div class="d-block">
                            <label class="badge bg-info text-white fs-4 fw-semibold" style="background-color: #17A2B8 !important;">{{ str_pad($view->published_count, 2, '0', STR_PAD_LEFT) }}</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            @foreach($view->journals as $i => $journal)
                <div class="col-lg-4 mb-6">
                    <div class="card rounded" style="box-shadow: 0 0 14px 4px rgba(0, 0, 0, 0.2);border: 1px solid #d9d9d9;">
                        <div class="card-body rounded bg-white px-4 pt-4 pb-3">
                            <div class="text-black text-center border-bottom pb-2 h-lg-90px fs-7 fw-semibold px-4">
                                <span class="text-black fs-5 fw-semibold me-2 mb-1 paper_txt text-wrap">{{ $journal->paper_name }}</span>
                                <!-- <span class="ms-1 me-1">-</span> -->
                                <span class="badge bg-info text-{{ $journal->text_color }} fw-semibold fs-6  mb-1" style="background-color: #{{ $journal->background_color }} !important;">{{ $journal->statusHTML }}</span>
                            </div>
                            <div class="d-flex align-items-center h-lg-35px mb-2 mt-3">
                                <div class="me-2 cursor-pointer">
                                    <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Journal Booklet">
                                        <i class="mdi mdi-book-open-variant-outline fs-4"></i>
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <div class="text-black fs-7 fw-semibold facility_txt" data-bs-placement="bottom">{{ $journal->journal_name }}</div>
                                </div>
                            </div>
                            <div class="d-flex align-items-center h-lg-35px mb-2">
                                <div class="me-2 cursor-pointer">
                                    <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Domain">
                                        <i class="mdi mdi-check-network-outline fs-4"></i>
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <div class="text-black fs-7 fw-semibold facility_txt" data-bs-placement="bottom">{{ implode(', ', $journal->domain_names) }}</div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 mb-2">
                                    <label class="text-dark mb-1 fs-7 fw-semibold">Submitted Documents</label>
                                    <div class="border border-gray-600i border-dashed rounded py-1 px-0">
                                        <div class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 pt-1">
                                            @if(count($journal->submitted_files) > 0)
                                                @foreach($journal->submitted_files as $file)
                                                    @php
                                                        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                                                        $fileUrl = asset('journals/' . $file);
                                                    @endphp
                                                    <div class="mb-1">
                                                        <a href="{{ $fileUrl }}"
                                                            class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded border border-gray-300i rounded w-50px h-50px"
                                                            download target="_blank">
                                                            @if(in_array($extension, ['jpg','jpeg','png','gif','bmp','webp']))
                                                                <img src="{{ $fileUrl }}" class="h-50px w-50px border border-gray-300i rounded" />
                                                            @elseif($extension === 'pdf')
                                                                <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                                    class="h-50px w-50px border border-gray-300i rounded" />
                                                            @else
                                                                <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                                    class="h-50px w-50px border border-gray-300i rounded" />
                                                            @endif
                                                        </a>
                                                    </div>
                                                @endforeach
                                            @else
                                                <span class="text-muted">No submitted documents found.</span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="scrl_dwn_tbox_{{ $i }}" style="display: none;">
                                <div class="divider divider-primary mb-6">
                                    <div class="divider-text fs-5 text-black fw-semibold">Journal Status</div>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-lg-12 mb-2">
                                        <ul class="timeline ms-2">
                                            @foreach($journal->journalStatus as $status)
                                                @if($status->status == 6)
                                                    <li class="timeline-item timeline-item-transparent ps-4">
                                                        <span class="timeline-point timeline-point-primary" style="background-color: #{{ $status->bg }} !important;"></span>
                                                        <div class="timeline-event">
                                                            <div class="timeline-header mb-3">
                                                                <h6 class="mb-0 text-body">
                                                                    <span class="badge bg-info fw-semibold fs-6  mb-1" style="background-color: #{{ $status->bg }} !important;">{{ $status->statusHTML }}</span>
                                                                </h6>
                                                                <small class="text-body-secondary fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Date">{{ date('Y-M-d', strtotime($status->published_date)) }}</small>
                                                            </div>
                                                            <div class="d-flex align-items-center h-lg-35px mb-4 mt-3">
                                                                <div class="me-2 cursor-pointer">
                                                                    <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Paper">
                                                                        <i class="mdi mdi-newspaper fs-4"></i>
                                                                    </div>
                                                                </div>
                                                                <div class="mb-0">
                                                                    <span class="text-black fs-7 fw-semibold facility_txt" data-bs-placement="bottom">{{ $status->publiched_paper }}</span>
                                                                    <a href="{{ $status->published_url }}" class="ms-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Link"><i class="mdi mdi-link-variant text-danger fs-3"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="d-flex align-items-center h-lg-35px mb-4">
                                                                <div class="me-2 cursor-pointer">
                                                                    <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Author">
                                                                        <i class="mdi mdi-account-star-outline fs-4"></i>
                                                                    </div>
                                                                </div>
                                                                <div class="mb-0">
                                                                    <div class="text-black fs-7 fw-semibold facility_txt" data-bs-placement="bottom">{{ $status->published_author }}</div>
                                                                </div>
                                                            </div>
                                                            <div class="mb-0">
                                                                <label class="text-black mb-1 fs-7 fw-semibold">Published Documents</label>
                                                                <div class="border border-gray-600i border-dashed rounded py-1 px-0">
                                                                    <div class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 pt-1">
                                                                        <div class="mb-1">
                                                                            @if(count($status->published_files) > 0)
                                                                                @foreach($status->published_files as $file)
                                                                                    @php
                                                                                        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                                                                                        $fileUrl = asset('published_journals/' . $file);
                                                                                    @endphp
                                                                                    <div class="mb-1">
                                                                                        <a href="{{ $fileUrl }}"
                                                                                            class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded border border-gray-300i rounded w-50px h-50px"
                                                                                            download target="_blank">
                                                                                            @if(in_array($extension, ['jpg','jpeg','png','gif','bmp','webp']))
                                                                                                <img src="{{ $fileUrl }}" class="h-50px w-50px border border-gray-300i rounded" />
                                                                                            @elseif($extension === 'pdf')
                                                                                                <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                                                                    class="h-50px w-50px border border-gray-300i rounded" />
                                                                                            @else
                                                                                                <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                                                                    class="h-50px w-50px border border-gray-300i rounded" />
                                                                                            @endif
                                                                                        </a>
                                                                                    </div>
                                                                                @endforeach
                                                                            @else
                                                                                <span class="text-muted">No submitted documents found.</span>
                                                                            @endif
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                @elseif ($status->status == 5)
                                                    <li class="timeline-item timeline-item-transparent ps-4">
                                                        <span class="timeline-point timeline-point-info" style="background-color: #{{ $status->bg }} !important;"></span>
                                                        <div class="timeline-event">
                                                            <div class="timeline-header mb-3">
                                                                <h6 class="mb-0">
                                                                    <span class="badge bg-info fw-semibold fs-6  mb-1" style="background-color: #{{ $status->bg }} !important;">Rejected</span>
                                                                </h6>
                                                                <small class="text-body-secondary fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Rejected Date">{{ date('Y-M-d', strtotime($status->rejected_date)) }}</small>
                                                            </div>
                                                            <label class="text-black mb-1 fs-7 fw-semibold">Rejected Reason</label>
                                                            <p class="fs-7 text-justify fw-semibold mb-4">&emsp;&emsp;&emsp; {{ $status->rejected_reason }}
                                                            </p>
                                                        </div>
                                                    </li>
                                                @elseif ($status->status == 4)
                                                    <li class="timeline-item timeline-item-transparent ps-4">
                                                        <span class="timeline-point timeline-point-info" style="background-color: #{{ $status->bg }} !important;"></span>
                                                        <div class="timeline-event">
                                                            <div class="timeline-header mb-3">
                                                                <h6 class="mb-0">
                                                                    <span class="badge bg-info fw-semibold fs-6  mb-1" style="background-color: #{{ $status->bg }} !important;">Accepted</span>
                                                                </h6>
                                                                <small class="text-body-secondary fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Accepted Date">{{ date('Y-M-d', strtotime($status->accepted_date)) }}</small>
                                                            </div>
                                                        </div>
                                                    </li>
                                                @elseif ($status->status == 3)
                                                    <li class="timeline-item timeline-item-transparent ps-4">
                                                        <span class="timeline-point timeline-point-info" style="background-color: #{{ $status->bg }} !important;"></span>
                                                        <div class="timeline-event">
                                                            <div class="timeline-header mb-3">
                                                                <h6 class="mb-0">
                                                                    <span class="badge bg-info fw-semibold fs-6  mb-1" style="background-color: #{{ $status->bg }} !important;">Resubmitted</span>
                                                                </h6>
                                                                <small class="text-body-secondary fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Resubmitted Date">{{ date('Y-M-d', strtotime($status->resubmitted_date)) }}</small>
                                                            </div>
                                                        </div>
                                                    </li>
                                                @elseif ($status->status == 1)
                                                    <li class="timeline-item timeline-item-transparent ps-4">
                                                        <span class="timeline-point timeline-point-success" style="background-color: #{{ $status->bg }} !important;"></span>
                                                        <div class="timeline-event">
                                                            <div class="timeline-header mb-3">
                                                                <h6 class="mb-0">
                                                                    <span class="badge bg-info text-black fw-semibold fs-6  mb-1" style="background-color: #{{ $status->bg }} !important;">Reviewed</span>
                                                                    <small class="text-body-secondary fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reviewed Date">{{ date('Y-M-d', strtotime($status->reviewed_date)) }}</small>
                                                                </h6>
                                                                <!-- <small class="text-body-secondary">45 min ago</small> -->
                                                            </div>
                                                            <label class="text-black mb-1 fs-7 fw-semibold">Reviewer Comments</label>
                                                            <p class="fs-7 text-justify fw-semibold mb-4">&emsp;&emsp;&emsp; {{ $status->reviewer_comment }}
                                                            </p>
                                                            <div class="mb-0">
                                                                <label class="text-black mb-1 fs-7 fw-semibold">Reviewed Documents</label>
                                                                <div class="border border-gray-600i border-dashed rounded py-1 px-0">
                                                                    <div class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 pt-1">
                                                                        <div class="mb-1">
                                                                            @if(count($status->reviewed_files) > 0)
                                                                                @foreach($status->reviewed_files as $file)
                                                                                    @php
                                                                                        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                                                                                        $fileUrl = asset('reviewed_journals/' . $file);
                                                                                    @endphp
                                                                                    <div class="mb-1">
                                                                                        <a href="{{ $fileUrl }}"
                                                                                            class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded border border-gray-300i rounded w-50px h-50px"
                                                                                            download target="_blank">
                                                                                            @if(in_array($extension, ['jpg','jpeg','png','gif','bmp','webp']))
                                                                                                <img src="{{ $fileUrl }}" class="h-50px w-50px border border-gray-300i rounded" />
                                                                                            @elseif($extension === 'pdf')
                                                                                                <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                                                                    class="h-50px w-50px border border-gray-300i rounded" />
                                                                                            @else
                                                                                                <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                                                                    class="h-50px w-50px border border-gray-300i rounded" />
                                                                                            @endif
                                                                                        </a>
                                                                                    </div>
                                                                                @endforeach
                                                                            @else
                                                                                <span class="text-muted">No submitted documents found.</span>
                                                                            @endif
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                @elseif ($status->status == 0)
                                                    <li class="timeline-item timeline-item-transparent ps-4">
                                                        <span class="timeline-point timeline-point-info" style="background-color: #{{ $status->bg }} !important;"></span>
                                                        <div class="timeline-event">
                                                            <div class="timeline-header mb-0">
                                                                <h6 class="mb-0">
                                                                    <span class="badge bg-info fw-semibold fs-6  mb-1" style="background-color: #{{ $status->bg }} !important;">Submitted</span>
                                                                </h6>
                                                                <small class="text-body-secondary fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Submitted Date">{{ date('Y-M-d', strtotime($status->submitted_date)) }}</small>
                                                                <!-- <small class="text-body-secondary">2 Day Ago</small> -->
                                                            </div>
                                                        </div>
                                                    </li>
                                                @endif
                                            @endforeach
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-2 text-center">
                                <a href="javascript:;" class="mb-0" id="scrl_dwn_{{ $i }}">
                                    <img src="{{ asset('assets/phdizone_images/down_arrow.gif') }}" class="h-50px w-50px dwn_arw ms-n3" id="down_arow_6" />
                                    <img src="{{ asset('assets/phdizone_images/up_arrow.gif') }}" class="h-50px w-50px dwn_arw ms-n3" id="up_arow_6" / style="display: none;">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>



<script>
    function toggleSection(id) {
        $('#scrl_dwn_tbox_' + id).slideToggle('slow');

        const $up = $('#up_arow_' + id);
        const $down = $('#down_arow_' + id);

        const isUpVisible = $up.is(':visible');

        $up.css('display', isUpVisible ? 'none' : 'inline');
        $down.css('display', isUpVisible ? 'inline' : 'none');
    }

    $('[id^="scrl_dwn_"]').click(function() {
    const id = $(this).attr('id').split('_')[2]; // get the number after scrl_dwn_
    toggleSection(id);
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const maxChars = 45;
        const elements = document.querySelectorAll('.facility_txt');

        elements.forEach(el => {
            const fullText = el.textContent.trim();

            if (fullText.length > maxChars) {
                el.setAttribute('title', fullText);
                el.setAttribute('data-bs-placement', 'bottom');
                el.textContent = fullText.slice(0, maxChars) + '...';

                bootstrap.Tooltip.getOrCreateInstance(el);
            }
        });
    });
    document.addEventListener('DOMContentLoaded', () => {
        const maxChars = 60;
        const elements = document.querySelectorAll('.paper_txt');

        elements.forEach(el => {
            const fullText = el.textContent.trim();

            if (fullText.length > maxChars) {
                el.setAttribute('title', fullText);
                el.setAttribute('data-bs-placement', 'bottom');
                el.textContent = fullText.slice(0, maxChars) + '...';

                bootstrap.Tooltip.getOrCreateInstance(el);
            }
        });
    });
</script>
<script>
    function indv_cust_func(val) {
        const rows = ["row_1"];

        rows.forEach(row => {
            const tbox = document.getElementById(`indv_cust_${row.split("_")[1]}_tbox`);
            const button = document.getElementById(`indv_cust_${row.split("_")[1]}_plus_btton`);
            const header = document.getElementById(`indv_cust_hd_${row.split("_")[1]}`);

            if (val === row) {
                const isVisible = tbox.style.display === "table-row";

                // Toggle: if visible, hide; else show
                tbox.style.display = isVisible ? "none" : "table-row";
                button.classList.toggle("mdi-minus", !isVisible);
                button.classList.toggle("mdi-plus", isVisible);
                header.style.backgroundColor = isVisible ? "" : "#f9f3c5db";
            } else {
                // Hide all other rows
                tbox.style.display = "none";
                button.classList.remove("mdi-minus");
                button.classList.add("mdi-plus");
                header.removeAttribute("style");
            }
        });
    }
</script>

@endsection