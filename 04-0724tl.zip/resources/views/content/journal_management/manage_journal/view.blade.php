@extends('layouts/layoutMaster')

@section('title', 'View Journal')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/js/dropdown-hover.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/clipboard/clipboard.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
    <style>
        .list_page thead th,
        .list_page tbody td {
            padding: 10px !important;
        }

        .indv_cust_jour thead th,
        .indv_cust_jour tbody td {
            padding: 8px !important;
            border: 1px solid rgb(180, 180, 180) !important;
        }

        .act_bx:hover {
            background-color: #eae1fc;

        }

        .act_bx_selected {
            background-color: #fbecdb !important;
            border: 1px solid #766e6e70 !important;
        }

        .dwn_arw:hover {
            box-shadow: 0 0 15px 13px rgba(0, 0, 0, 0.2);
            border-radius: 50%;
            background-color: white;
        }

        .profile-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.25s ease-in-out;
            cursor: pointer;
        }

        .profile-avatar img {
            width: 50px;
            height: 50px;
            object-fit: cover;
        }

        .profile-avatar:hover {
            transform: scale(1.1);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
        }
    </style>
    @php
        $helper = new \App\Helpers\Helpers();        
    @endphp
    <!-- Journal List Table -->
    <div class="card card-action">
        <div class="card-header flex-wrap border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">
                    View Journal
                </h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Journal Management</a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Manage Journal</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex flex-column align-items-center">
                    <div class="text-black fw-semibold fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Customer Name">{{ $view->cus_name }}</div>
                    <div class="text-dark fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Customer ID">{{ $view->customer_id }}</div>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-lg-12">
                    <div class="row mb-1">
                        <div class="col-lg-3 mb-2 d-flex align-items-center justify-content-start gap-2">
                            <span class="badge bg-label-secondary rounded-circle px-2 py-2">
                                <i class="mdi mdi-locker-multiple fs-2 text-black"></i>
                            </span>
                            <di class="d-flex flex-column align-items-start">
                                <div class="fs-6 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Service Name">{{ $view->service_name }}</div>
                                <div class="fs-7 fw-semibold text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Service Id">{{ $view->service_id }}</div>
                            </di>
                        </div>
                        <div class="col-lg-3 mb-2 d-flex align-items-center justify-content-start gap-2">
                            <span class="badge bg-label-secondary rounded-circle px-2 py-2">
                                <i class="mdi mdi-check-network-outline fs-2 text-black"></i>
                            </span>
                            <di class="d-flex flex-column align-items-start">
                                <div class="fs-6 fw-semibold text-black facility_txt" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Domain">{{ implode(', ', $view->domain_names) }}</div>
                                <div class="fs-7 fw-semibold text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Index">{{ $view->index_names }}</div>
                            </di>
                        </div>
                        <div class="col-lg-3 mb-2 d-flex align-items-center justify-content-start gap-2">
                            @if ($view->jc_id)
                                @if (
                                    $view->jouranal_coordinator_image != '' &&
                                        file_exists(public_path('staff_images/' . $view->jouranal_coordinator_image)))
                                    <img src="{{ asset('staff_images/' . $view->jouranal_coordinator_image) }}"
                                        class="w-45px h-45px border border-dark border-2 rounded-circle" />
                                @else
                                    <div class="profile-avatar bg-success text-white shadow-sm border border-2 border-success"
                                        data-bs-toggle="tooltip" title="JE: {{ $view->jouranal_coordinator_name }}">
                                        <span>{{ strtoupper(substr($view->jouranal_coordinator_name, 0, 1)) }}</span>
                                    </div>
                                @endif
                                <div class="d-flex flex-column align-items-start">
                                    <div class="fs-6 fw-semibold text-black">{{ $view->jouranal_coordinator_name }}</div>
                                    <div class="fs-7 fw-semibold text-dark">Journal Team Lead</div>
                                </div>
                            @else
                                <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip"
                                    title="No Staff">
                                    <i class="mdi mdi-account-off fs-5"></i>
                                </div>
                                <div class="d-flex flex-column align-items-start">
                                    <div class="fs-6 fw-semibold text-black">No Staff Assign</div>
                                    <div class="fs-7 fw-semibold text-dark">Journal Team Lead</div>
                                </div>
                            @endif
                        </div>
                        <div class="col-lg-3 mb-2 d-flex align-items-center justify-content-start gap-2">
                            @if ($view->jc_staff)
                                @if ($view->journal_staff_image != '' && file_exists(public_path('staff_images/' . $view->journal_staff_image)))
                                    <img src="{{ asset('staff_images/' . $view->journal_staff_image) }}"
                                        class="w-45px h-45px border border-dark border-2 rounded-circle" />
                                @else
                                    <div class="profile-avatar bg-success text-white shadow-sm border border-2 border-success"
                                        data-bs-toggle="tooltip" title="JE: {{ $view->journal_staff_name }}">
                                        <span>{{ strtoupper(substr($view->journal_staff_name, 0, 1)) }}</span>
                                    </div>
                                @endif
                                <div class="d-flex flex-column align-items-start">
                                    <div class="fs-6 fw-semibold text-black">{{ $view->journal_staff_name }}</div>
                                    <div class="fs-7 fw-semibold text-dark">Journal Excetive</div>
                                </div>
                            @else
                                <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip"
                                    title="No Staff">
                                    <i class="mdi mdi-account-off fs-5"></i>
                                </div>
                                <div class="d-flex flex-column align-items-start">
                                    <div class="fs-6 fw-semibold text-black">No Staff Assign</div>
                                    <div class="fs-7 fw-semibold text-dark">Journal Excetive</div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
                <hr>
                <div class="col-lg-12">
                    <div class="d-flex align-items-center justify-content-between flex-wrap mb-2 pb-2">
                        <div class="text-center mb-2">
                            <label class="text-black mb-1 fs-5 fw-semibold">Submitted</label>
                            <div class="d-block">
                                <label class="badge rounded-circle text-white fs-4 fw-semibold"
                                    style="background-color: #007BFF !important;">{{ str_pad($view->submittedCount, 2, '0', STR_PAD_LEFT) }}</label>
                            </div>
                        </div>
                        <div class="text-center mb-2">
                            <label class="text-black mb-1 fs-5 fw-semibold">With Editor</label>
                            <div class="d-block">
                                <label class="badge rounded-circle text-black fs-4 fw-semibold"
                                    style="background-color: #FFA747 !important;">{{ str_pad($view->withEditorCount, 2, '0', STR_PAD_LEFT) }}</label>
                            </div>
                        </div>
                        <div class="text-center mb-2">
                            <label class="text-black mb-1 fs-5 fw-semibold">Under Reviewer</label>
                            <div class="d-block">
                                <label class="badge rounded-circle text-white fs-4 fw-semibold"
                                    style="background-color: #800080 !important;">{{ str_pad($view->underReviewerCount, 2, '0', STR_PAD_LEFT) }}</label>
                            </div>
                        </div>
                        <div class="text-center mb-2">
                            <label class="text-black mb-1 fs-5 fw-semibold">Revision</label>
                            <div class="d-block">
                                <label class="badge rounded-circle text-white fs-4 fw-semibold"
                                    style="background-color: #28A745 !important;">{{ str_pad($view->reviewedCount, 2, '0', STR_PAD_LEFT) }}</label>
                            </div>
                        </div>
                        <div class="text-center mb-2">
                            <label class="text-black mb-1 fs-5 fw-semibold">Accepted</label>
                            <div class="d-block">
                                <label class="badge rounded-circle text-white fs-4 fw-semibold"
                                    style="background-color: #DC3545 !important;">{{ str_pad($view->acceptedCount, 2, '0', STR_PAD_LEFT) }}</label>
                            </div>
                        </div>
                        <div class="text-center mb-2">
                            <label class="text-black mb-1 fs-5 fw-semibold">Rejected</label>
                            <div class="d-block">
                                <label class="badge rounded-circle text-white fs-4 fw-semibold"
                                    style="background-color: #17A2B8 !important;">{{ str_pad($view->rejectedCount, 2, '0', STR_PAD_LEFT) }}</label>
                            </div>
                        </div>
                        <div class="text-center mb-2">
                            <label class="text-black mb-1 fs-5 fw-semibold">E-Proofing</label>
                            <div class="d-block">
                                <label class="badge rounded-circle text-white fs-4 fw-semibold"
                                    style="background-color: #FF6B6B !important;">{{ str_pad($view->eproofingCount, 2, '0', STR_PAD_LEFT) }}</label>
                            </div>
                        </div>
                        <div class="text-center mb-2">
                            <label class="text-black mb-1 fs-5 fw-semibold">Published</label>
                            <div class="d-block">
                                <label class="badge rounded-circle text-white fs-4 fw-semibold"
                                    style="background-color: #6F42C1 !important;">{{ str_pad($view->publishedCount, 2, '0', STR_PAD_LEFT) }}</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                @if (isset($view->journals))
                    @foreach ($view->journals as $i => $journal)
                        @php
                            $statusColors = [
                                0 => [
                                    'row' => '#CCE5FF',
                                    'badge' => '#007BFF',
                                    'label' => 'Submitted',
                                ],
                                1 => [
                                    'row' => '#d8d9c1 ',
                                    'badge' => '#a8ab14',
                                    'label' => 'With Editor',
                                ],
                                5 => [
                                    'row' => '#abc9e9',
                                    'badge' => '#DC3545',
                                    'label' => 'Accepted',
                                ],
                                3 => [
                                    'row' => '#e7d4b2 ',
                                    'badge' => '#800080',
                                    'label' => 'Under Reviewer',
                                ],
                                4 => [
                                    'row' => '#9dd7c1',
                                    'badge' => '#28A745',
                                    'label' => 'Revision',
                                ],
                                6 => [
                                    'row' => '#dbc1c4 ',
                                    'badge' => '#17A2B8',
                                    'label' => 'Rejected',
                                ],
                                7 => [
                                    'row' => '#b893b9 ',
                                    'badge' => '#17A2B8',
                                    'label' => 'E-Proofing',
                                ],
                                8 => [
                                    'row' => '#6bd2e3  ',
                                    'badge' => '#17A2B8',
                                    'label' => 'Published ',
                                ],
                            ];

                            $status = $journal->status;
                            $colors = $statusColors[$status] ?? [
                                'row' => '#FFFFFF',
                                'badge' => '#6c757d',
                                'label' => 'Unknown',
                            ];
                            $journalPaper = $journal->published_paper_name ?? $journal->paper_name;
                        @endphp
                        <div class="col-lg-12 mb-6">
                            <div class="accordion" id="journalAccordion{{ $i }}">
                                <div class="accordion-item card rounded"
                                    style="box-shadow: 0 0 10px 2px rgba(0, 0, 0, 0.2); border: 1px solid #d9d9d9;">
                                    <h2 class="accordion-header mb-0 pb-0" id="heading{{ $i }}">
                                        <button class="accordion-button collapsed bg-white px-4 pt-3" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapse{{ $i }}"
                                            aria-expanded="false" aria-controls="collapse{{ $i }}">
                                            <div class="w-100">
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div class="d-flex align-items-start flex-column">
                                                        <span class="text-black fs-5 fw-semibold paper_txt">
                                                            {{ $journalPaper }}
                                                        </span>
                                                        <div class="d-flex align-items-center justify-content-start gap-2">
                                                            <div class="d-flex align-items-center">
                                                                <div class="me-2">
                                                                    <div class="bg-label-secondary rounded px-1 py-1"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom" title="Domain">
                                                                        <i class="mdi mdi-check-network-outline fs-4"></i>
                                                                    </div>
                                                                </div>
                                                                <div class="text-black fs-7 fw-semibold">
                                                                    {{ implode(', ', $journal->domain_names) }}
                                                                </div>
                                                            </div>
                                                            <div class="d-flex align-items-center">
                                                                <div class="me-2">
                                                                    <div class="bg-label-secondary rounded px-1 py-1"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Journal Booklet">
                                                                        <i
                                                                            class="mdi mdi-book-open-variant-outline fs-4"></i>
                                                                    </div>
                                                                </div>
                                                                <div class="text-black fs-7 fw-semibold">
                                                                    {{ $journal->journal_name }}
                                                                </div>
                                                            </div>
                                                            <div class="d-flex align-items-center">
                                                                <div class="me-2">
                                                                    <div class="bg-label-secondary rounded px-1 py-1"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom" title="Submitted Date">
                                                                        <i class="mdi mdi-calendar-outline fs-4"></i>
                                                                    </div>
                                                                </div>
                                                                <div class="text-black fs-7 fw-semibold">
                                                                    {{ \Carbon\Carbon::parse($journal->submited_date)->format('d-M-Y') }}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <span class="badge fw-semibold fs-6 me-2"
                                                        style="background-color: {{ $journal->background_color }} !important;color: {{ $journal->text_color }} !important">
                                                        {{ $journal->statusHTML }}
                                                    </span>
                                                </div>
                                            </div>
                                        </button>
                                    </h2>
                                    <div id="collapse{{ $i }}" class="accordion-collapse collapse show"
                                        aria-labelledby="heading{{ $i }}"
                                        data-bs-parent="#journalAccordion{{ $i }}">
                                        <div class="accordion-body px-4 py-0">
                                            <div class="divider divider-primary mb-4">
                                                <div class="divider-text fs-5 text-black fw-semibold">
                                                    Journal Status
                                                </div>
                                            </div>
                                            <ul class="timeline ms-2">
                                                @foreach ($journal->journalStatus as $status)
                                                    @php
                                                        $statusColors = [
                                                            0 => [
                                                                'row' => '#CCE5FF',
                                                                'badge' => '#007BFF',
                                                                'text_color' => '#FFF',
                                                                'label' => 'Submitted',
                                                            ],
                                                            1 => [
                                                                'row' => '#d8d9c1 ',
                                                                'badge' => '#a8ab14',
                                                                'text_color' => '#000',
                                                                'label' => 'With Editor',
                                                            ],
                                                            2 => [
                                                                'row' => '#e2dddd ',
                                                                'badge' => '#c7c7c7',
                                                                'text_color' => '#000',
                                                                'label' => 'Closed',
                                                            ],
                                                            5 => [
                                                                'row' => '#abc9e9',
                                                                'badge' => '#DC3545',
                                                                'text_color' => '#FFF',
                                                                'label' => 'Accepted',
                                                            ],
                                                            3 => [
                                                                'row' => '#e7d4b2 ',
                                                                'badge' => '#800080',
                                                                'text_color' => '#FFF',
                                                                'label' => 'Under Reviewer',
                                                            ],
                                                            4 => [
                                                                'row' => '#9dd7c1',
                                                                'badge' => '#28A745',
                                                                'text_color' => '#FFF',
                                                                'label' => 'Revision',
                                                            ],
                                                            6 => [
                                                                'row' => '#dbc1c4 ',
                                                                'badge' => '#17A2B8',
                                                                'text_color' => '#FFF',
                                                                'label' => 'Rejected',
                                                            ],
                                                            7 => [
                                                                'row' => '#b893b9 ',
                                                                'badge' => '#17A2B8',
                                                                'text_color' => '#FFF',
                                                                'label' => 'E-Proofing',
                                                            ],
                                                            8 => [
                                                                'row' => '#6bd2e3  ',
                                                                'badge' => '#7239EA',
                                                                'text_color' => '#FFF',
                                                                'label' => 'Published ',
                                                            ],
                                                        ];

                                                        $statusHTML =
                                                            $statusColors[$status->status]['label'] ?? 'Unknown';
                                                        $bg = $statusColors[$status->status]['badge'] ?? '#6c757d';
                                                        $status->text =
                                                            $statusColors[$status->status]['text_color'] ?? '#6c757d';

                                                        $description = '';
                                                        $date = '';
                                                        $documents = [];
                                                        // 0 - Submitted 1 - With Editor 3 - Under Reviewer 4- Revision 5 - Accepted 6 - Rejected 7 - Eproofing 8 - Published
                                                        if ($status->status == 0) {
                                                            $description = '';
                                                            $date = $status->submitted_date;
                                                            $documents = json_decode(
                                                                $status->submitted_documents,
                                                                true,
                                                            );
                                                        } elseif ($status->status == 1) {
                                                            $description = $status->with_editor_comment;
                                                            $date = $status->with_editor_date;
                                                            $documents = json_decode(
                                                                $status->with_editor_documents,
                                                                true,
                                                            );
                                                        } elseif ($status->status == 3) {
                                                            $description = $status->under_reviewer_comment;
                                                            $date = $status->under_reviewer_date;
                                                            $documents = json_decode(
                                                                $status->under_reviewer_documents,
                                                                true,
                                                            );
                                                        } elseif ($status->status == 4) {
                                                            $description = $status->reviewer_comment;
                                                            $date = $status->reviewed_date;
                                                            $documents = json_decode($status->reviewer_document, true);
                                                        } elseif ($status->status == 5) {
                                                            $description = $status->accepted_comment;
                                                            $date = $status->accepted_date;
                                                            $documents = json_decode(
                                                                $status->accepted_document, // Fixed: Use correct field name
                                                                true,
                                                            );
                                                        } elseif ($status->status == 6) {
                                                            $description = $status->rejected_reason;
                                                            $date = $status->rejected_date;
                                                            $documents = []; // Added: Initialize empty array for rejected status
                                                        } elseif ($status->status == 7) {
                                                            $description = $status->e_proofing_comments;
                                                            $date = $status->e_proofing_date;
                                                            $documents = json_decode(
                                                                $status->e_proofing_documents,
                                                                true,
                                                            );
                                                        } elseif ($status->status == 8) {
                                                            $description = $status->under_reviewer_comment;
                                                            $date = $status->published_date;
                                                            $documents = json_decode($status->published_files, true);
                                                        }

                                                        if (isset($date) && $date != '') {
                                                            $date = date('d-M-Y', strtotime($date));
                                                        }

                                                        // Parse documents - removed redundant json_decode
                                                        $visibleDocuments = [];

                                                        if (!empty($documents) && is_array($documents)) {
                                                            $visibleDocuments = array_filter($documents, function (
                                                                $doc,
                                                            ) {
                                                                return !isset($doc['productionStaff']) ||
                                                                    $doc['productionStaff'] != 1;
                                                            });
                                                        }

                                                        $isDocuments = !empty($visibleDocuments);
                                                    @endphp
                                                    <li class="timeline-item timeline-item-transparent ps-4">
                                                        <span class="timeline-point"
                                                            style="background-color:{{ $bg }};"></span>
                                                        <div class="timeline-event">
                                                            <div class="timeline-header mb-2">
                                                                <h6 class="mb-0 d-flex flex-column gap-1">
                                                                    <label>
                                                                        <span>{{ $date }}</span> -
                                                                        <span class="badge bg-info fw-semibold fs-6"
                                                                            style="background-color:{{ $bg }} !important;">
                                                                            {{ $statusHTML }}
                                                                        </span>
                                                                    </label>
                                                                    <span class="text-dark fw-sembold fs-7">
                                                                       {!! nl2br(e($description)) !!} 
                                                                    </span>
                                                                    @if ($status->status == 8)
                                                                        <div
                                                                            class="d-flex align-items-center h-lg-35px mb-4 mt-3">
                                                                            <div class="me-2 cursor-pointer">
                                                                                <div class="bg-label-secondary rounded px-1 py-1"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Published Paper">
                                                                                    <i class="mdi mdi-newspaper fs-4"></i>
                                                                                </div>
                                                                            </div>
                                                                            <div class="mb-0">
                                                                                <span class="text-black fs-7 fw-semibold "
                                                                                    data-bs-placement="bottom">{{ $status->publiched_paper }}</span>
                                                                                <a href="{{ $status->published_url }}"
                                                                                    class="ms-2"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Published Link"><i
                                                                                        class="mdi mdi-link-variant text-danger fs-3"></i></a>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="d-flex align-items-center h-lg-35px mb-4">
                                                                            <div class="me-2 cursor-pointer">
                                                                                <div class="bg-label-secondary rounded px-1 py-1"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Author">
                                                                                    <i
                                                                                        class="mdi mdi-account-star-outline fs-4"></i>
                                                                                </div>
                                                                            </div>
                                                                            <div class="mb-0">
                                                                                <div class="text-black fs-7 fw-semibold facility_txt"
                                                                                    data-bs-placement="bottom">
                                                                                    {{ $status->published_author ?? '-' }}
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    @endif
                                                                </h6>
                                                                <div>
                                                                    @if ($isDocuments && !empty($visibleDocuments))
                                                                        <div class="dropdown position-relative">
                                                                            <button
                                                                                class="btn btn-outline-primary btn-sm dropdown-toggle d-flex align-items-center"
                                                                                type="button" data-bs-toggle="dropdown"
                                                                                aria-expanded="false">
                                                                                <i
                                                                                    class="mdi mdi-tray-arrow-down me-2"></i>
                                                                            </button>
                                                                            @if (count($visibleDocuments) > 1)
                                                                                <span
                                                                                    class="badge bg-danger rounded-circle  position-absolute"
                                                                                    style="top: -9px;right: 0px;">
                                                                                    {{ count($visibleDocuments) }}
                                                                                </span>
                                                                            @endif
                                                                            <ul class="dropdown-menu">
                                                                                @foreach ($visibleDocuments as $index => $document)
                                                                                    @php
                                                                                        $driveLink =
                                                                                            'https://drive.google.com/uc?id=' .
                                                                                            $document['drive_file_id'] .
                                                                                            '&export=download';
                                                                                        $fileName =
                                                                                            $document['name'] ??
                                                                                            'document_' . ($index + 1);
                                                                                        $fileExtension = pathinfo(
                                                                                            $fileName,
                                                                                            PATHINFO_EXTENSION,
                                                                                        );
                                                                                        $iconClass = $helper->getFileIcon(
                                                                                            $fileExtension,
                                                                                        ); // You'll need to implement this method
                                                                                    @endphp
                                                                                    <li>
                                                                                        <a class="dropdown-item"
                                                                                            href="{{ $driveLink }}"
                                                                                            target="_blank">
                                                                                            <i
                                                                                                class="{{ $iconClass }} me-2"></i>
                                                                                            {{ $fileName }}
                                                                                            <small
                                                                                                class="text-muted d-block">Click
                                                                                                to
                                                                                                download</small>
                                                                                        </a>
                                                                                    </li>
                                                                                @endforeach
                                                                            </ul>
                                                                        </div>
                                                                    @else
                                                                        <img src="{{ asset('assets/phdizone_images/newmultiply.png') }}"
                                                                            alt="avatar"
                                                                            class="rounded-circle img-fluid"
                                                                            style="width: 40px; height: 40px; object-fit: cover;"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="No Documents Uploaded">
                                                                    @endif
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @endif
                {{-- <div class="col-lg-12 mb-6">
                    <div class="accordion" id="journalAccordion2">
                        <div class="accordion-item card rounded"
                            style="box-shadow: 0 0 10px 2px rgba(0, 0, 0, 0.2); border: 1px solid #d9d9d9;">
                            <h2 class="accordion-header mb-0 pb-0" id="headingTwo">
                                <button class="accordion-button collapsed bg-white px-4 pt-3" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false"
                                    aria-controls="collapseTwo">
                                    <div class="w-100">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-start flex-column">
                                                <span class="text-black fs-5 fw-semibold paper_txt">
                                                    Robust Encryption Framework for IoT Devices Based on Bit-plane
                                                    Extraction,
                                                    Chaotic Sine Models, and Quantum Operations
                                                </span>
                                                <div class="d-flex align-items-center gap-3 mt-1 flex-wrap">
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Domain">
                                                                <i class="mdi mdi-check-network-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            Computer Science
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Journal Booklet">
                                                                <i class="mdi mdi-book-open-variant-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            IEEE Internet of Things Journal
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Submitted Date">
                                                                <i class="mdi mdi-calendar-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            01-Sep-2025
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="badge fw-semibold fs-6 me-2"
                                                style="background-color:#FFA500;color:#000;">
                                                Reviewed
                                            </span>
                                        </div>
                                    </div>
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                data-bs-parent="#journalAccordion2">
                                <div class="accordion-body px-4 py-0">
                                    <div class="divider divider-primary mb-4">
                                        <div class="divider-text fs-5 text-black fw-semibold">
                                            Journal Status
                                        </div>
                                    </div>
                                    <ul class="timeline ms-2">
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#FFA500;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge fw-semibold fs-6"
                                                                style="background-color:#FFA500;color:#000;">
                                                                Reviewed
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            We have carefully addressed the reviewers’ suggestions by
                                                            enhancing
                                                            the security analysis, optimizing the authentication protocol,
                                                            and
                                                            clarifying implementation details with experimental results.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#007BFF;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #007BFF !important;">
                                                                Submitted
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            You will assist in writing and organizing thesis chapters
                                                            according to the guidelines.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mb-6">
                    <div class="accordion" id="journalAccordion3">
                        <div class="accordion-item card rounded"
                            style="box-shadow:0 0 10px 2px rgba(0,0,0,0.2); border:1px solid #d9d9d9;">
                            <h2 class="accordion-header mb-0 pb-0" id="headingThree">
                                <button class="accordion-button collapsed bg-white px-4 pt-3" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false"
                                    aria-controls="collapseThree">
                                    <div class="w-100">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-start flex-column">
                                                <span class="text-black fs-5 fw-semibold paper_txt">
                                                    Robust Encryption Framework for IoT Devices Based on Bit-plane
                                                    Extraction,
                                                    Chaotic Sine Models, and Quantum Operations
                                                </span>
                                                <div class="d-flex align-items-center gap-3 mt-1 flex-wrap">
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-check-network-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            Computer Science
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-book-open-variant-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            IEEE Internet of Things Journal
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-calendar-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            12-Oct-2025
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="badge fw-semibold fs-6 me-2"
                                                style="background-color:#800080;color:#fff;">
                                                Resubmitted
                                            </span>
                                        </div>
                                    </div>
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
                                data-bs-parent="#journalAccordion3">
                                <div class="accordion-body px-4 py-0">
                                    <div class="divider divider-primary mb-4">
                                        <div class="divider-text fs-5 text-black fw-semibold">
                                            Journal Status
                                        </div>
                                    </div>
                                    <ul class="timeline ms-2">
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#800080;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #800080 !important;">
                                                                Resubmitted
                                                            </span>
                                                        </label>
                                                    </h6>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#FFA500;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #FFA500 !important;">
                                                                Reviewed
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            We have carefully addressed the reviewers’ suggestions by
                                                            enhancing the
                                                            security analysis of the PQCAIE scheme, optimizing the
                                                            authentication
                                                            protocol for better efficiency in IoT environments, and
                                                            clarifying the
                                                            implementation details with additional experimental results.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#007BFF;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-0">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #007BFF !important;">
                                                                Submitted
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            You will assist in writing and organizing thesis chapters
                                                            according to the guidelines.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mb-6">
                    <div class="accordion" id="journalAccordion4">
                        <div class="accordion-item card rounded"
                            style="box-shadow:0 0 10px 2px rgba(0,0,0,0.2); border:1px solid #d9d9d9;">
                            <h2 class="accordion-header mb-0 pb-0" id="headingFour">
                                <button class="accordion-button collapsed bg-white px-4 pt-3" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false"
                                    aria-controls="collapseFour">
                                    <div class="w-100">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-start flex-column">
                                                <span class="text-black fs-5 fw-semibold paper_txt">
                                                    Robust Encryption Framework for IoT Devices Based on Bit-plane
                                                    Extraction,
                                                    Chaotic Sine Models, and Quantum Operations
                                                </span>
                                                <div class="d-flex align-items-center gap-3 mt-1 flex-wrap">
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-check-network-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            Computer Science
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-book-open-variant-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            IEEE Internet of Things Journal
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-calendar-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            26-Oct-2025
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="badge fw-semibold fs-6 me-2"
                                                style="background-color:#28A745;color:#fff;">
                                                Accepted
                                            </span>
                                        </div>
                                    </div>
                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                data-bs-parent="#journalAccordion4">
                                <div class="accordion-body px-4 py-0">
                                    <div class="divider divider-primary mb-4">
                                        <div class="divider-text fs-5 text-black fw-semibold">
                                            Journal Status
                                        </div>
                                    </div>
                                    <ul class="timeline ms-2">
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#28A745;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #28A745 !important;">
                                                                Accepted
                                                            </span>
                                                        </label>
                                                    </h6>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#800080;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #800080 !important;">
                                                                Resubmitted
                                                            </span>
                                                        </label>
                                                    </h6>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#FFA500;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #FFA500 !important;">
                                                                Reviewed
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            We have carefully addressed the reviewers’ suggestions by
                                                            enhancing the
                                                            security analysis of the PQCAIE scheme, optimizing the
                                                            authentication
                                                            protocol for better efficiency in IoT environments, and
                                                            clarifying the
                                                            implementation details with additional experimental results.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#007BFF;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-0">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #007BFF !important;">
                                                                Submitted
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            You will assist in writing and organizing thesis chapters
                                                            according to the guidelines.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mb-6">
                    <div class="accordion" id="journalAccordion5">
                        <div class="accordion-item card rounded"
                            style="box-shadow:0 0 10px 2px rgba(0,0,0,0.2); border:1px solid #d9d9d9;">
                            <h2 class="accordion-header mb-0 pb-0" id="headingFive">
                                <button class="accordion-button collapsed bg-white px-4 pt-3" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false"
                                    aria-controls="collapseFive">
                                    <div class="w-100">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-start flex-column">
                                                <span class="text-black fs-5 fw-semibold paper_txt">
                                                    Robust Encryption Framework for IoT Devices Based on Bit-plane
                                                    Extraction,
                                                    Chaotic Sine Models, and Quantum Operations
                                                </span>
                                                <div class="d-flex align-items-center gap-3 mt-1 flex-wrap">
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-check-network-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            Computer Science
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-book-open-variant-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            IEEE Internet of Things Journal
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-calendar-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            05-Aug-2025
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="badge fw-semibold fs-6 me-2"
                                                style="background-color:#DC3545;color:#fff;">
                                                Rejected
                                            </span>
                                        </div>
                                    </div>
                                </button>
                            </h2>
                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive"
                                data-bs-parent="#journalAccordion5">
                                <div class="accordion-body px-4 py-0">
                                    <div class="divider divider-primary mb-4">
                                        <div class="divider-text fs-5 text-black fw-semibold">
                                            Journal Status
                                        </div>
                                    </div>
                                    <ul class="timeline ms-2">
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#DC3545;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #DC3545 !important;">
                                                                Rejected
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            Thank you for your valuable feedback and the opportunity to
                                                            submit our work. We understand the concerns raised and will use
                                                            the suggestions to significantly improve our research. We hope
                                                            to address these issues thoroughly and consider resubmission in
                                                            the future.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#28A745;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #28A745 !important;">
                                                                Accepted
                                                            </span>
                                                        </label>
                                                    </h6>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#800080;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #800080 !important;">
                                                                Resubmitted
                                                            </span>
                                                        </label>
                                                    </h6>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#FFA500;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #FFA500 !important;">
                                                                Reviewed
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            We have carefully addressed the reviewers’ suggestions by
                                                            enhancing the
                                                            security analysis of the PQCAIE scheme, optimizing the
                                                            authentication
                                                            protocol for better efficiency in IoT environments, and
                                                            clarifying the
                                                            implementation details with additional experimental results.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#007BFF;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-0">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #007BFF !important;">
                                                                Submitted
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            You will assist in writing and organizing thesis chapters
                                                            according to the guidelines.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mb-6">
                    <div class="accordion" id="journalAccordion6">
                        <div class="accordion-item card rounded"
                            style="box-shadow:0 0 10px 2px rgba(0,0,0,0.2); border:1px solid #d9d9d9;">
                            <h2 class="accordion-header mb-0 pb-0" id="headingSix">
                                <button class="accordion-button collapsed bg-white px-4 pt-3" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false"
                                    aria-controls="collapseSix">
                                    <div class="w-100">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-start flex-column">
                                                <span class="text-black fs-5 fw-semibold paper_txt">
                                                    Robust Encryption Framework for IoT Devices Based on Bit-plane
                                                    Extraction,
                                                    Chaotic Sine Models, and Quantum Operations
                                                </span>
                                                <div class="d-flex align-items-center gap-3 mt-1 flex-wrap">
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-check-network-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            Computer Science
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-book-open-variant-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            IEEE Internet of Things Journal
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-2">
                                                            <div class="bg-label-secondary rounded px-1 py-1">
                                                                <i class="mdi mdi-calendar-outline fs-4"></i>
                                                            </div>
                                                        </div>
                                                        <div class="text-black fs-7 fw-semibold">
                                                            05-Aug-2025
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="badge fw-semibold fs-6 me-2"
                                                style="background-color:#17A2B8;color:#fff;">
                                                Pulished
                                            </span>
                                        </div>
                                    </div>
                                </button>
                            </h2>
                            <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix"
                                data-bs-parent="#journalAccordion6">
                                <div class="accordion-body px-4 py-0">
                                    <div class="divider divider-primary mb-4">
                                        <div class="divider-text fs-5 text-black fw-semibold">
                                            Journal Status
                                        </div>
                                    </div>
                                    <ul class="timeline ms-2">
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#17A2B8;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #17A2B8 !important;">
                                                                Published
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            TinyWolf — Efficient On-device TinyML Training for IoT using
                                                            Enhanced Grey Wolf Optimization presents a lightweight, adaptive
                                                            training framework tailored for resource-constrained IoT
                                                            devices. By enhancing Grey Wolf Optimization, we achieve faster
                                                            convergence and improved model accuracy directly on edge
                                                            devices.
                                                        </span>
                                                        <div class="d-flex align-items-center h-lg-35px mb-4 mt-3">
                                                            <div class="me-2 cursor-pointer">
                                                                <div class="bg-label-secondary rounded px-1 py-1"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Published Paper">
                                                                    <i class="mdi mdi-newspaper fs-4"></i>
                                                                </div>
                                                            </div>
                                                            <div class="mb-0">
                                                                <span class="text-black fs-7 fw-semibold facility_txt"
                                                                    data-bs-placement="bottom">TinyWolf — Efficient
                                                                    on-device TinyML training for IoT using enhanced Grey
                                                                    Wolf Optimization</span>
                                                                <a href="https://linkinghub.elsevier.com/retrieve/pii/S2542660524001690"
                                                                    class="ms-2" data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom" title="Published Link"><i
                                                                        class="mdi mdi-link-variant text-danger fs-3"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center h-lg-35px mb-4">
                                                            <div class="me-2 cursor-pointer">
                                                                <div class="bg-label-secondary rounded px-1 py-1"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Author">
                                                                    <i class="mdi mdi-account-star-outline fs-4"></i>
                                                                </div>
                                                            </div>
                                                            <div class="mb-0">
                                                                <div class="text-black fs-7 fw-semibold facility_txt"
                                                                    data-bs-placement="bottom">Khwaja Mansoor, Mehreen
                                                                    Afzal, Waseem Iqbal, Yawar Abbas, Shynar Mussiraliyeva,
                                                                    Abdellah Chehri</div>
                                                            </div>
                                                        </div>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#DC3545;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #DC3545 !important;">
                                                                Rejected
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            Thank you for your valuable feedback and the opportunity to
                                                            submit our work. We understand the concerns raised and will use
                                                            the suggestions to significantly improve our research. We hope
                                                            to address these issues thoroughly and consider resubmission in
                                                            the future.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#28A745;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #28A745 !important;">
                                                                Accepted
                                                            </span>
                                                        </label>
                                                    </h6>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#800080;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #800080 !important;">
                                                                Resubmitted
                                                            </span>
                                                        </label>
                                                    </h6>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#FFA500;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-2">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #FFA500 !important;">
                                                                Reviewed
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            We have carefully addressed the reviewers’ suggestions by
                                                            enhancing the
                                                            security analysis of the PQCAIE scheme, optimizing the
                                                            authentication
                                                            protocol for better efficiency in IoT environments, and
                                                            clarifying the
                                                            implementation details with additional experimental results.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="timeline-item timeline-item-transparent ps-4">
                                            <span class="timeline-point" style="background-color:#007BFF;"></span>
                                            <div class="timeline-event">
                                                <div class="timeline-header mb-0">
                                                    <h6 class="mb-0 d-flex flex-column gap-1">
                                                        <label>
                                                            <span class="badge bg-info fw-semibold fs-6"
                                                                style="background-color: #007BFF !important;">
                                                                Submitted
                                                            </span>
                                                        </label>
                                                        <span class="text-dark fw-sembold fs-7">
                                                            You will assist in writing and organizing thesis chapters
                                                            according to the guidelines.
                                                        </span>
                                                    </h6>
                                                    <div>
                                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                            download>
                                                            <span class="badge bg-white border border-primary rounded">
                                                                <i class="mdi mdi-tray-arrow-down fs-7 text-primary"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> --}}

            </div>
        </div>
    </div>







    <script>
        function toggleSection(id) {
            $('#scrl_dwn_tbox_' + id).slideToggle('slow');

            const $up = $('#up_arow_' + id);
            const $down = $('#down_arow_' + id);

            const isUpVisible = $up.is(':visible');

            $up.css('display', isUpVisible ? 'none' : 'inline');
            $down.css('display', isUpVisible ? 'inline' : 'none');
        }

        $('#scrl_dwn_1').click(() => toggleSection(1));
        $('#scrl_dwn_2').click(() => toggleSection(2));
        $('#scrl_dwn_3').click(() => toggleSection(3));
        $('#scrl_dwn_4').click(() => toggleSection(4));
        $('#scrl_dwn_5').click(() => toggleSection(5));
        $('#scrl_dwn_6').click(() => toggleSection(6));
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const maxChars = 45;
            const elements = document.querySelectorAll('.facility_txt');

            elements.forEach(el => {
                const fullText = el.textContent.trim();

                if (fullText.length > maxChars) {
                    el.setAttribute('title', fullText);
                    el.setAttribute('data-bs-placement', 'bottom');
                    el.textContent = fullText.slice(0, maxChars) + '...';

                    bootstrap.Tooltip.getOrCreateInstance(el);
                }
            });
        });
        document.addEventListener('DOMContentLoaded', () => {
            const maxChars = 80;
            const elements = document.querySelectorAll('.paper_txt');

            elements.forEach(el => {
                const fullText = el.textContent.trim();

                if (fullText.length > maxChars) {
                    el.setAttribute('title', fullText);
                    el.setAttribute('data-bs-placement', 'bottom');
                    el.textContent = fullText.slice(0, maxChars) + '...';

                    bootstrap.Tooltip.getOrCreateInstance(el);
                }
            });
        });
    </script>
    <script>
        function indv_cust_func(val) {
            const rows = ["row_1"];

            rows.forEach(row => {
                const tbox = document.getElementById(`indv_cust_${row.split("_")[1]}_tbox`);
                const button = document.getElementById(`indv_cust_${row.split("_")[1]}_plus_btton`);
                const header = document.getElementById(`indv_cust_hd_${row.split("_")[1]}`);

                if (val === row) {
                    const isVisible = tbox.style.display === "table-row";

                    // Toggle: if visible, hide; else show
                    tbox.style.display = isVisible ? "none" : "table-row";
                    button.classList.toggle("mdi-minus", !isVisible);
                    button.classList.toggle("mdi-plus", isVisible);
                    header.style.backgroundColor = isVisible ? "" : "#f9f3c5db";
                } else {
                    // Hide all other rows
                    tbox.style.display = "none";
                    button.classList.remove("mdi-minus");
                    button.classList.add("mdi-plus");
                    header.removeAttribute("style");
                }
            });
        }
    </script>
    <script>
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>
    <script>
        function date_fill_issue_rpt() {
            var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
            var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
            var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
            var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
            var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
            var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
            var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_issue_rpt == "today") {
                today_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "week") {
                today_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "block";
                week_to_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#week_from_date_fil').val(firstday);
                $('#week_to_date_fil').val(lastday);

            } else if (dt_fill_issue_rpt == "monthly") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "block";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "custom_date") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "block";
                to_dt_iss_rpt.style.display = "block";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            }
        }
    </script>

    <script>
        $(".list_page_3").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
@endsection
