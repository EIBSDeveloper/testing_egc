@extends('layouts/layoutMaster')

@section('title', 'Manage Journal')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/js/dropdown-hover.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/clipboard/clipboard.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
    <style>
        .table-scroll-wrapper {
            position: relative;
            width: 100%;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .top-scrollbar,
        .bottom-scrollbar {
            width: 100%;
            overflow-x: auto;
            overflow-y: hidden;
            height: 16px;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            flex-shrink: 0;
        }

        .top-scrollbar {
            border-bottom: none;
            margin-bottom: -1px;
            /* Overlap with table */
        }

        .bottom-scrollbar {
            border-top: none;
            margin-top: -1px;
            /* Overlap with table */
        }

        .scroll-content {
            height: 1px;
            /* Minimal height, width will be set by JS */
        }

        .table-container {
            /* width: 100%; */
            overflow-x: hidden;
            overflow-y: auto;
            max-height: 70vh;
            /* scrollbar-width: thin;
                                                                                scrollbar-color: #c1c1c1 #f1f1f1; */
            flex: 1;
        }

        /* Hide the actual scrollbar but keep functionality */
        .table-container::-webkit-scrollbar {
            width: 12px;
            height: 12px;
        }

        .table-container::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 6px;
        }

        .table-container::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 6px;
        }

        .table-container::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }

        /* Ensure table cells don't wrap */
        .table-container th,
        .table-container td {
            white-space: nowrap;
            min-width: 80px;
        }

        /* Make the table take full width of its content */
        .table-container table {
            width: max-content;
            min-width: 100%;
        }

        /* Sticky header (all th) */
        .sticky_table thead th {
            position: sticky;
            top: 0;
            background: #099dda !important;
            color: #fff;
            text-align: center;
            vertical-align: middle;
            z-index: 50;
            /* default header z-index */
        }

        .profile-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.25s ease-in-out;
            cursor: pointer;
        }

        .profile-avatar img {
            width: 50px;
            height: 50px;
            object-fit: cover;
        }

        .profile-avatar:hover {
            transform: scale(1.1);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
        }

        .bg-gradient-primary {
            background: linear-gradient(45deg, #007bff, #00c6ff);
        }

        .list_page thead th,
        .list_page tbody td {
            padding: 10px !important;
        }

        .indv_cust_jour thead th,
        .indv_cust_jour tbody td {
            padding: 8px !important;
            border: 1px solid rgb(180, 180, 180) !important;
        }

        .act_bx:hover {
            background-color: #eae1fc;

        }

        .act_bx_selected {
            background-color: #fbecdb !important;
            border: 1px solid #766e6e70 !important;
        }

        .service-master-card {
            backdrop-filter: blur(10px);
            background: #f0913d;
        }

        .stat-card {
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.2) !important;
        }

        .pulse-btn {
            position: relative;
        }

        .pulse-btn::after {
            content: '';
            position: absolute;
            top: -4px;
            left: -4px;
            right: -4px;
            bottom: -4px;
            border: 2px solid #ff6b6b;
            border-radius: 50%;
            animation: pulse 2s infinite;
            opacity: 0;
        }

        @keyframes pulse {
            0% {
                transform: scale(0.95);
                opacity: 0.7;
            }

            70% {
                transform: scale(1.05);
                opacity: 0;
            }

            100% {
                transform: scale(0.95);
                opacity: 0;
            }
        }

        .stage-1 {
            --card-color: #007BFF;
        }

        .stage-2 {
            --card-color: #FFA500;
        }

        .stage-3 {
            --card-color: #800080;
        }

        .stage-4 {
            --card-color: #28A745;
        }

        .stage-5 {
            --card-color: #DC3545;
        }

        .stage-6 {
            --card-color: #17A2B8;
        }

        .stage-7 {
            --card-color: #FF6B6B;
        }

        .stage-8 {
            --card-color: #6F42C1;
        }

        .status-card {
            width: 220px;
            height: 90px;
            border-radius: 12px;
            transition: all 0.2s ease-in-out;
        }

        .style-5 .stage-card {
            text-align: center;
            padding: 15px;
            border: 2px solid transparent;
            background: white;
        }

        .style-5 .circle-count {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: color-mix(in srgb, var(--card-color) 10%, white);
            border: 3px solid var(--card-color);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            transition: all 0.3s ease;
        }

        .style-5 .stage-count {
            font-size: 20px;
            color: var(--card-color);
            transition: all 0.3s ease;
        }

        .section-title {
            color: #1a1a1a;
            margin-bottom: 30px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e9ecef;
            font-weight: 700;
        }

        /* COMMON STYLES */
        .stage-card {
            border-radius: 12px;
            transition: all 0.3s ease;
            cursor: pointer;
            height: 100%;
        }

        .stage-label {
            font-weight: 600;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }

        .stage-count {
            font-weight: 800;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        /* ACTIVE STATE STYLES */
        .style-5 .stage-card.active {
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            border: 2px solid var(--card-color);
            background: color-mix(in srgb, var(--card-color) 5%, white);
            transform: translateY(-5px);
            margin-top: 10px;
        }

        .style-5 .stage-card.active .circle-count {
            background: color-mix(in srgb, var(--card-color) 20%, white);
            border-width: 4px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .style-5 .stage-card.active .stage-count {
            font-size: 22px;
            color: color-mix(in srgb, var(--card-color) 80%, black);
        }

        .style-5 .stage-card.active .stage-label {
            color: var(--card-color);
            font-weight: 700;
            font-size: 0.95rem;
        }

        /* Hover effects */
        .style-5 .stage-card:hover:not(.active) {
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
            border: 2px solid color-mix(in srgb, var(--card-color) 30%, white);
        }

        .style-5 .stage-card:hover:not(.active) .circle-count {
            background: color-mix(in srgb, var(--card-color) 15%, white);
        }

        .style-5 .stage-card:hover:not(.active) .stage-label {
            color: var(--card-color);
        }
    </style>

    @php
        $helper = new \App\Helpers\Helpers();
        $module_name = 'Journal Management';
        $menu_name = 'Manage Journal';
    @endphp
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Journal</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Journal Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center flex-wrap">
                    <!--<button class="btn-23" data-bs-toggle="modal" data-bs-target="#kt_modal_add_journal_booklet_ai">-->
                    <!--    <span class="text">AI Suggestion</span>-->
                    <!--    <span aria-hidden="" class="marquee">AI Suggestion</span>-->
                    <!--</button>-->
                </div>
            </div>
        </div>
        <div class="card-body">
            {{-- <div class="filter_tbox" style="display: none;">
            <form id="filter_form" method="POST" action="/journal_management/manage_journal">
                @csrf
                <input type="hidden" name="page" value="{{ request('page', 1)}}">
                <input type="hidden" name="filter_on" value="1">
                <input type="hidden" name="fill_chk" value="1">
                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                    value="25" />
                <div class="row py-1">
                    <input type="hidden" name="page" value="">
                    <div class="col-lg-3 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Customer Name</label>
                        <input type="text" class="form-control" placeholder="Enter Customer Name" id="customer_fill"
                            name="customer_fill" value="{{$customer_fill}}" />
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Customer ID</label>
                        <input type="text" class="form-control" placeholder="Enter Customer ID" id="customer_id_fill"
                            name="customer_id_fill" value="{{$customer_id_fill}}" />
                    </div>
                </div>
                <div class="d-flex justify-content-end mb-4 align-items-center">
                    <a href="{{ url('/journal_management/manage_journal') }}" type="button"
                        class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
                    <button type="submit" class="btn btn-sm btn-primary">Go</button>
                </div>
            </form>
        </div> --}}
            <div class="row g-3">

                <div class="col-lg-4">
                    <div class="row g-3">
                        <div class="col-lg-6">
                            <div class=" rounded p-2 d-flex align-items-center justify-content-between bg-gray-100 border">
                                <div class="d-flex flex-column">
                                    <label class="fs-7 fw-semibold text-secondary">Total Customers</label>
                                    <label
                                        class="fs-2 fw-semibold text-black">{{ $customer_count == 0 ? 0 : str_pad($customer_count, 2, '0', STR_PAD_LEFT) }}</label>
                                </div>
                                <span class="badge p-2 fw-semibold  d-flex align-items-center justify-content-center"
                                    style="background:#dde0ff; color:#2c43eb; border-radius:50px; width:47px; height:47px;"><span
                                        class="mdi mdi-account-group fs-3"></span>
                                </span>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class=" rounded p-2 d-flex align-items-center justify-content-between bg-gray-100 border">
                                <div class="d-flex flex-column">
                                    <label class="fs-7 fw-semibold text-secondary">Total Papers</label>
                                    <label class="fs-2 fw-semibold text-black">
                                        {{ $totalpapers == 0 ? 0 : str_pad($totalpapers, 2, '0', STR_PAD_LEFT) }}
                                    </label>
                                </div>
                                <span class="badge p-2 fw-semibold  d-flex align-items-center justify-content-center"
                                    style="background:#dcf2f9; color:#30b7c5; border-radius:50px; width:47px; height:47px;"><span
                                        class="mdi mdi-text-box fs-3"></span>
                                </span>
                            </div>
                        </div>
                        @if ($pending_followupcount > 0)
                            <div class="col-lg-12">
                                <div class=" rounded p-2 d-flex align-items-center justify-content-between position-relative"
                                    style="border:1px solid #d12833; background:#FFF1F2;">
                                    <div class="d-flex flex-column">
                                        <label class="fs-7 fw-semibold " style="color:#e11d1d;">Pending Follow Up's</label>
                                        <label class="fs-2 fw-semibold " style="color:#e11d1d;">
                                            {{ $pending_followupcount == 0 ? 0 : str_pad($pending_followupcount, 2, '0', STR_PAD_LEFT) }}</label>
                                    </div>
                                    <a href="javascript:;" class=" py-0 mb-0 me-2  position-absolute"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                        title="Close Pending Follow Up's" style="left:75%;">
                                        <img src="{{ asset('assets/phdizone_images/Angry_Reaction.gif') }}"
                                            alt="Pending Follow Up's Icon" class="w-80px h-70px text-black fw-bold">
                                    </a>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>

                <div class="col-lg-8">
                    <div class="row g-2">
                        <div class="col-lg-3">
                            <a href="/journal_management/manage_journal?status=0">
                                <div class=" rounded p-2 d-flex align-items-center justify-content-between bg-gray-100 border"
                                    style="{{ $currentStatus == 0 ? 'background-color: #007BFF;color: white;' : 'color: black;' }}  cursor: pointer;">
                                    <div class="d-flex flex-column">
                                        <label class="fs-7 fw-semibold">Submitted</label>
                                        <label
                                            class="fs-2 fw-semibold">{{ $submittedCount == 0 ? 0 : str_pad($submittedCount, 2, '0', STR_PAD_LEFT) }}</label>
                                    </div>
                                    <span class="badge p-2 fw-semibold  d-flex align-items-center justify-content-center"
                                        style="background:#DCEAF9; color:#007BFF; border-radius:50px; width:47px; height:47px;"><span
                                            class="mdi mdi-file-document-multiple fs-3"></span>
                                    </span>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-3">
                            <a href="/journal_management/manage_journal?status=1">
                                <div class=" rounded p-2 d-flex align-items-center justify-content-between bg-gray-100 border"
                                    style="{{ $currentStatus == 1 ? 'background-color: #FFA500;color: white;' : 'color: black;' }}  cursor: pointer;">
                                    <div class="d-flex flex-column">
                                        <label class="fs-7 fw-semibold">With Editor</label>
                                        <label
                                            class="fs-2 fw-semibold">{{ $withEditorCount == 0 ? 0 : str_pad($withEditorCount, 2, '0', STR_PAD_LEFT) }}</label>
                                    </div>
                                    <span class="badge p-2 fw-semibold  d-flex align-items-center justify-content-center"
                                        style="background:#EDE9C3; color:#FFA500; border-radius:50px; width:47px; height:47px;"><span
                                            class="mdi mdi-file-document-edit fs-3"></span>
                                    </span>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-3">
                            <a href="/journal_management/manage_journal?status=3">
                                <div class=" rounded p-2 d-flex align-items-center justify-content-between bg-gray-100 border"
                                    style="{{ $currentStatus == 3 ? 'background-color: #800080;color: white;' : 'color: black;' }}  cursor: pointer;">
                                    <div class="d-flex flex-column">
                                        <label class="fs-7 fw-semibold">Under Reviewer</label>
                                        <label
                                            class="fs-2 fw-semibold">{{ $underReviewerCount == 0 ? 0 : str_pad($underReviewerCount, 2, '0', STR_PAD_LEFT) }}</label>
                                    </div>
                                    <span class="badge p-2 fw-semibold  d-flex align-items-center justify-content-center"
                                        style="background:#F5EADC; color:#800080; border-radius:50px; width:47px; height:47px;"><span
                                            class="mdi mdi-file-document-alert fs-3"></span>
                                    </span>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-3">
                            <a href="/journal_management/manage_journal?status=4">
                                <div class=" rounded p-2 d-flex align-items-center justify-content-between bg-gray-100 border"
                                    style="{{ $currentStatus == 4 ? 'background-color: #28A745;color: white;' : 'color: black;' }}  cursor: pointer;">
                                    <div class="d-flex flex-column">
                                        <label class="fs-7 fw-semibold">Revision</label>
                                        <label
                                            class="fs-2 fw-semibold">{{ $reviewedCount == 0 ? 0 : str_pad($reviewedCount, 2, '0', STR_PAD_LEFT) }}</label>
                                    </div>
                                    <span class="badge p-2 fw-semibold  d-flex align-items-center justify-content-center"
                                        style="background:#DFF1EA; color:#00AD6D; border-radius:50px; width:47px; height:47px;"><span
                                            class="mdi mdi-file-document-arrow-right fs-3"></span>
                                    </span>
                                </div>
                        </div>
                        <div class="col-lg-3">
                            <a href="/journal_management/manage_journal?status=5">
                                <div class=" rounded p-2 d-flex align-items-center justify-content-between bg-gray-100 border"
                                    style="{{ $currentStatus == 5 ? 'background-color: #17A2B8;color: white;' : 'color: black;' }}  cursor: pointer;">
                                    <div class="d-flex flex-column">
                                        <label class="fs-7 fw-semibold">Accepted</label>
                                        <label
                                            class="fs-2 fw-semibold">{{ $acceptedCount == 0 ? 0 : str_pad($acceptedCount, 2, '0', STR_PAD_LEFT) }}</label>
                                    </div>
                                    <span class="badge p-2 fw-semibold  d-flex align-items-center justify-content-center"
                                        style="background:#c7e6f7; color:#17A2B8; border-radius:50px; width:47px; height:47px;"><span
                                            class="mdi mdi-file-document-check fs-3"></span>
                                    </span>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-3">
                            <a href="/journal_management/manage_journal?status=6">
                                <div class=" rounded p-2 d-flex align-items-center justify-content-between bg-gray-100 border"
                                    style="{{ $currentStatus == 6 ? 'background-color: #DC3545;color: white;' : 'color: black;' }}  cursor: pointer;">
                                    <div class="d-flex flex-column">
                                        <label class="fs-7 fw-semibold">Rejected</label>
                                        <label class="fs-2 fw-semibold">
                                            {{ $rejectedCount == 0 ? 0 : str_pad($rejectedCount, 2, '0', STR_PAD_LEFT) }}</label>
                                    </div>
                                    <span class="badge p-2 fw-semibold  d-flex align-items-center justify-content-center"
                                        style="background:#F7E6E6; color:#DC3545; border-radius:50px; width:47px; height:47px;"><span
                                            class="mdi mdi-file-document-minus fs-3"></span>
                                    </span>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-3">
                            <a href="/journal_management/manage_journal?status=7">
                                <div class=" rounded p-2 d-flex align-items-center justify-content-between bg-gray-100 border"
                                    style="{{ $currentStatus == 7 ? 'background-color: #FF6B6B;color: white;' : 'color: black;' }}  cursor: pointer;">
                                    <div class="d-flex flex-column">
                                        <label class="fs-7 fw-semibold">E-Proofing</label>
                                        <label
                                            class="fs-2 fw-semibold">{{ $eproofingCount == 0 ? 0 : str_pad($eproofingCount, 2, '0', STR_PAD_LEFT) }}</label>
                                    </div>
                                    <span class="badge p-2 fw-semibold  d-flex align-items-center justify-content-center"
                                        style="background:#FFF2FF; color:#FF6B6B; border-radius:50px; width:47px; height:47px;"><span
                                            class="mdi mdi-file-document-refresh fs-3"></span>
                                    </span>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-3">
                            <a href="/journal_management/manage_journal?status=8">
                                <div class=" rounded p-2 d-flex align-items-center justify-content-between bg-gray-100 border"
                                    style="{{ $currentStatus == 8 ? 'background-color: #6F42C1;color: white;' : 'color: black;' }}  cursor: pointer;">
                                    <div class="d-flex flex-column">
                                        <label class="fs-7 fw-semibold">Published</label>
                                        <label class="fs-2 fw-semibold">
                                            {{ $publishedCount == 0 ? 0 : str_pad($publishedCount, 2, '0', STR_PAD_LEFT) }}</label>
                                    </div>
                                    <span class="badge p-2 fw-semibold  d-flex align-items-center justify-content-center"
                                        style="background:#E6E0F5; color:#7239EA; border-radius:50px; width:47px; height:47px;"><span
                                            class="mdi mdi-file-document-check fs-3"></span>
                                    </span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="row mb-4">
                        @php $perpage_count = $perpage ? $perpage : 10; @endphp
                        <div class="col-lg-2">
                            <span>Show</span>
                            <br>
                            <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                onchange="sort_filter(this.value);">
                                @php
                                    $options = [10, 25, 100, 500]; // Define available options
                                @endphp
                                @foreach ($options as $option)
                                    <option value="{{ $option }}"
                                        @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                                        @php echo $option; @endphp
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-lg-10 d-flex align-items-end justify-content-end">
                            <form id="search_form" method="POST" action="/journal_management/manage_journal">
                                @csrf
                                <div class="d-flex align-items-center gap-2 mt-2">
                                    <div>
                                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                        <input type="hidden" name="filter_on" value="0">
                                        <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                            id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                        <input type="text" class="form-control" id="search_fill" name="search_fill"
                                            value="{{ $search_fill ?? '' }}" placeholder="Enter Search" />
                                    </div>
                                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                        onclick="search_filter_func()">Search</button>
                                    <a href="{{ url('/journal_management/manage_journal') }}" type="button"
                                        class="me-2 btn btn-sm btn-secondary fw-semibold mb-1">
                                        <span class="mdi mdi-refresh fs-6"></span>
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                    {{-- <div class="table-scroll-wrapper">
                        <!-- Top Scrollbar -->
                        <div class="top-scrollbar">
                            <div class="scroll-content"></div>
                        </div> --}}
                    {{-- <div class="table-container"> --}}
                    <div class="table-responsive">
                        <table class="table align-center table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                            <thead>
                                {{-- <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px">Customers</th>
                                        <th class="min-w-80px text-center">Services</th>
                                        <th class="min-w-80px text-center">Domain &amp; Index</th>
                                        <th class="min-w-80px text-center">Journal Staff</th>
                                        <th class="min-w-50px">Follow-up</th>
                                        <th class="min-w-25px text-center">Submitted</th>
                                        <th class="min-w-25px text-center">With Editor</th>
                                        <th class="min-w-25px text-center">Under Reviewer</th>
                                        <th class="min-w-25px text-center">Revision</th>
                                        <th class="min-w-25px text-center">Accepted</th>
                                        <th class="min-w-25px text-center">Rejected</th>
                                        <th class="min-w-25px text-center">E-Proofing</th>
                                        <th class="min-w-25px text-center">Published</th>
                                        <th class="min-w-25px ">Action</th>
                                    </tr> --}}
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-150px">Customers / ID</th>
                                    <th class="min-w-150px">Services & Domain / index</th>
                                    <th class="min-w-150px">Journal Staff</th>
                                    <th class="min-w-125px text-center">Follow-up</th>
                                    <th class="min-w-125px text-center">Status</th>
                                    <th class="min-w-80px">Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-gray-600 fw-semibold fs-7">
                                @foreach ($lists as $i => $list)
                                    <tr id="indv_cust_hd_{{ $i }}">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <a href="javascript:;"
                                                    class="bg-label-secondary border border-gray-400i rounded px-1 py-1"
                                                    onclick="open_func({{ $i }});">
                                                    <i class="mdi mdi-plus fs-4" id="plus_btn{{ $i }}"></i>
                                                </a>
                                                <div class="mb-0 mx-2">
                                                    <label class="text-black text-truncate fw-semibold fs-7"
                                                        style="max-width: 150px;" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="{{ $list->cus_name }}">{{ $list->cus_name }}</label>
                                                    <div class="d-block">
                                                        <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom" title="Customer ID">
                                                            {{ $list->customer_id }}</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="mb-0">
                                                    <label
                                                        class="fw-semibold text-black fs-7 text-wrap min-w-200px max-w-275px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Services: {{ $list->service_name }}">{{ $list->service_name }}
                                                    </label>
                                                    <div class="d-block mb-1">
                                                        <label
                                                            class="fw-semibold text-danger fs-8 ">{{ $list->service_id }}</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="d-flex gap-2 align-items-center mt-1">
                                                <label
                                                    class="d-block badge text-truncate bg-success fs-7 text-black px-2 py-1"
                                                    style="max-width: 150px;" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="Domain: {{ $list->domain_names ? implode(', ', $list->domain_names->toArray()) : 'No Domains' }}">{{ $list->domain_names ? implode(', ', $list->domain_names->toArray()) : 'No Domains' }}</label>
                                                <label
                                                    class="d-block badge text-truncate bg-secondary fs-7 text-white px-2 py-1"
                                                    style="max-width: 150px;" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="Index: {{ $list->index_names }}">{{ $list->index_names }}</label>
                                            </div>
                                        </td>
                                        <td class="ps-4">
                                            <div class="d-flex align-items-center gap-4">
                                                <!-- Journal Coordinator -->
                                                <div class="d-flex flex-column align-items-center position-relative">
                                                    @if ($list->jc_id)
                                                        @if (
                                                            $list->jouranal_coordinator_image != '' &&
                                                                file_exists(public_path('staff_images/' . $list->jouranal_coordinator_image)))
                                                            <div class="profile-avatar shadow-sm border border-2 border-primary"
                                                                data-bs-toggle="tooltip"
                                                                title="JTL: {{ $list->jouranal_coordinator_name }}">
                                                                <img src="{{ asset('staff_images/' . $list->jouranal_coordinator_image) }}"
                                                                    alt="{{ $list->jouranal_coordinator_name }}">
                                                            </div>
                                                        @else
                                                            <div class="profile-avatar bg-primary text-white shadow-sm border border-2 border-primary"
                                                                data-bs-toggle="tooltip"
                                                                title="JTL: {{ $list->jouranal_coordinator_name }}">
                                                                <span>{{ strtoupper(substr($list->jouranal_coordinator_name, 0, 1)) }}</span>
                                                            </div>
                                                        @endif
                                                    @else
                                                        <div class="profile-avatar bg-light text-muted border"
                                                            data-bs-toggle="tooltip" title="No Coordinator">
                                                            <i class="mdi mdi-account-off fs-5"></i>
                                                        </div>
                                                    @endif
                                                    <small class="text-muted mt-1 fw-medium">JTL</small>
                                                </div>

                                                <!-- Journal Staff -->
                                                <div class="d-flex flex-column align-items-center position-relative">
                                                    @if ($list->jc_staff)
                                                        @if ($list->journal_staff_image != '' && file_exists(public_path('staff_images/' . $list->journal_staff_image)))
                                                            <div class="profile-avatar shadow-sm border border-2 border-success"
                                                                data-bs-toggle="tooltip"
                                                                title="JE: {{ $list->journal_staff_name }}">
                                                                <img src="{{ asset('staff_images/' . $list->journal_staff_image) }}"
                                                                    alt="{{ $list->journal_staff_name }}">
                                                            </div>
                                                        @else
                                                            <div class="profile-avatar bg-success text-white shadow-sm border border-2 border-success"
                                                                data-bs-toggle="tooltip"
                                                                title="JE: {{ $list->journal_staff_name }}">
                                                                <span>{{ strtoupper(substr($list->journal_staff_name, 0, 1)) }}</span>
                                                            </div>
                                                        @endif
                                                    @else
                                                        <div class="profile-avatar bg-light text-muted border"
                                                            data-bs-toggle="tooltip" title="No Staff">
                                                            <i class="mdi mdi-account-off fs-5"></i>
                                                        </div>
                                                    @endif
                                                    <small class="text-muted mt-1 fw-medium">JE</small>
                                                </div>

                                            </div>
                                        </td>
                                        <td>

                                            @php
                                                $followupcount =
                                                    $helper->journal_last_followup_count(
                                                        $list->sno,
                                                        $list->journal_customer_id,
                                                    ) ?? 0;
                                            @endphp
                                            <div class="d-flex align-items-center justify-content-center gap-2">

                                                @if ($followupcount == 0)
                                                    <div class="avatar avatar-sm me-2">
                                                        <a href="javascript:;" class="dropdown-item"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_new_jr_follow_up_lead"
                                                            onclick="OpenNewFollowUP('{{ $list->sno }}',{{ $list->journal_customer_id }},'{{ $list->cus_name }}', '{{ $list->customer_id }}', '{{ $list->service_name }}', '{{ $list->service_id }}', '{{ $list->domain_names ? implode(', ', $list->domain_names->toArray()) : 'No Domains' }}', '{{ $list->index_names }}', '{{ strtoupper(substr($list->jouranal_coordinator_name, 0, 1)) }}', '{{ strtoupper(substr($list->journal_staff_name, 0, 1)) }}')">
                                                            <div class="border border-gray-500i rounded"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Not Yet Followed">
                                                                <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                    alt="Premium Potential Icon"
                                                                    class="w-30px h-30px text-black fw-bold">
                                                            </div>
                                                        </a>
                                                    </div>
                                                @else
                                                    @php
                                                        $journallastfollowup = $helper->journal_last_followup_data(
                                                            $list->sno,
                                                            $list->journal_customer_id,
                                                        );
                                                        $journallastfollowupsts = $journallastfollowup->status ?? 0;
                                                    @endphp
                                                    @if ($journallastfollowupsts == 0)
                                                        <div class="avatar avatar-sm me-2">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_jr_follow_up_lead_schedule"
                                                                onclick="openFpResheduleModal('{{ $list->sno }}','{{ $list->journal_customer_id }}')">
                                                                <div class="border border-gray-500i rounded"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Followup">
                                                                    <img src="{{ asset('assets/phdizone_images/lead/on_followup.gif') }}"
                                                                        alt="Premium Potential Icon"
                                                                        class="w-30px h-30px text-black fw-bold">
                                                                </div>
                                                                <span
                                                                    class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Followup Count"
                                                                    style="background-color: #10ff00 !important;">{{ $followupcount ?? 0 }}</span>
                                                                <span
                                                                    class="position-absolute animation-blink top-100 start-100 translate-middle badge badge-center rounded-pill border bg-danger text-white ms-1"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Followup Pending">!</span>
                                                            </a>
                                                        </div>
                                                    @else
                                                        <div class="avatar avatar-sm me-2">
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_again_jr_follow_up_lead_schedule"
                                                                onclick="openResheduleModalAgain('{{ $list->sno }}','{{ $list->journal_customer_id }}')">
                                                                <div class="border border-gray-500i rounded"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Followup">
                                                                    <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                        alt="Premium Potential Icon"
                                                                        class="w-30px h-30px text-black fw-bold">
                                                                </div>
                                                                <span
                                                                    class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Followup Count"
                                                                    style="background-color: #10ff00 !important;">{{ $followupcount }}</span>
                                                            </a>
                                                        </div>
                                                    @endif
                                                @endif
                                            </div>
                                        </td>
                                        @php
                                            $submittedCount =
                                                $helper->get_submitted_count($list->sno, $list->journal_customer_id) ??
                                                0;
                                            $withEditorCount =
                                                $helper->get_with_editor_count(
                                                    $list->sno,
                                                    $list->journal_customer_id,
                                                ) ?? 0;
                                            $underReviewerCount =
                                                $helper->get_under_reviewer_count(
                                                    $list->sno,
                                                    $list->journal_customer_id,
                                                ) ?? 0;
                                            $reviewedCount =
                                                $helper->get_reviewed_count($list->sno, $list->journal_customer_id) ??
                                                0;
                                            $acceptedCount =
                                                $helper->get_accepted_count($list->sno, $list->journal_customer_id) ??
                                                0;
                                            $rejectedCount =
                                                $helper->get_rejected_count($list->sno, $list->journal_customer_id) ??
                                                0;
                                            $eProofingCount =
                                                $helper->get_e_proofing_count($list->sno, $list->journal_customer_id) ??
                                                0;
                                            $publishedCount =
                                                $helper->get_published_count($list->sno, $list->journal_customer_id) ??
                                                0;
                                        @endphp

                                        <td align="center">
                                            <div class="d-flex align-items-center justify-content-center gap-1">
                                                <span
                                                    class="badge p-2 fw-semibold fs-4 d-flex align-items-center justify-content-center pull-up"
                                                    style="background:#2196f3; color:#fff; border-radius:50px; width:40px; height:40px;"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    data-bs-original-title="Submitted">{{ str_pad($submittedCount, 2, '0', STR_PAD_LEFT) }}
                                                </span>
                                                <span
                                                    class="badge p-2 fw-semibold fs-4 d-flex align-items-center justify-content-center pull-up"
                                                    style="background:#A8AB14; color:#fff; border-radius:50px; width:40px; height:40px;"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    data-bs-original-title="With Editor">{{ str_pad($withEditorCount, 2, '0', STR_PAD_LEFT) }}
                                                </span>
                                                <span
                                                    class="badge p-2 fw-semibold fs-4 d-flex align-items-center justify-content-center pull-up"
                                                    style="background:#ED9900; color:#fff; border-radius:50px; width:40px; height:40px;"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    data-bs-original-title="Under Reviewer">{{ str_pad($underReviewerCount, 2, '0', STR_PAD_LEFT) }}
                                                </span>
                                                <span
                                                    class="badge p-2 fw-semibold fs-4 d-flex align-items-center justify-content-center pull-up"
                                                    style="background:#00AD6D; color:#fff; border-radius:50px; width:40px; height:40px;"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    data-bs-original-title="Revision">{{ str_pad($reviewedCount, 2, '0', STR_PAD_LEFT) }}
                                                </span>
                                                <span
                                                    class="badge p-2 fw-semibold fs-4 d-flex align-items-center justify-content-center pull-up"
                                                    style="background:#007BFF; color:#fff; border-radius:50px; width:40px; height:40px;"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    data-bs-original-title="Accepted">{{ str_pad($acceptedCount, 2, '0', STR_PAD_LEFT) }}
                                                </span>
                                                <span
                                                    class="badge p-2 fw-semibold fs-4 d-flex align-items-center justify-content-center pull-up"
                                                    style="background:#FF4D49; color:#fff; border-radius:50px; width:40px; height:40px;"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    data-bs-original-title="Rejected">{{ str_pad($rejectedCount, 2, '0', STR_PAD_LEFT) }}
                                                </span>
                                                <span
                                                    class="badge p-2 fw-semibold fs-4 d-flex align-items-center justify-content-center pull-up"
                                                    style="background:#940097; color:#fff; border-radius:50px; width:40px; height:40px;"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    data-bs-original-title="E-Proofing">{{ str_pad($eProofingCount, 2, '0', STR_PAD_LEFT) }}
                                                </span>
                                                <span
                                                    class="badge p-2 fw-semibold fs-4 d-flex align-items-center justify-content-center pull-up"
                                                    style="background:#7239EA; color:#fff; border-radius:50px; width:40px; height:40px;"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    data-bs-original-title="Published">{{ str_pad($publishedCount, 2, '0', STR_PAD_LEFT) }}
                                                </span>
                                            </div>
                                        </td>

                                        <td>
                                            <span class="text-center">
                                                <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown"
                                                    aria-haspopup="true" aria-expanded="false">
                                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    @php
                                                        $loginStaff = auth()->user()->user_id;
                                                        $journalTL = $list->jc_id;
                                                        $journalStaff = $list->jc_staff;
                                                    @endphp
                                                    @if ($journalTL === $loginStaff)
                                                        <a href="javascript:;" class="dropdown-item"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_journal_assign_staff"
                                                            onclick="AssignStaff('{{ $list->sno }}')">
                                                            <span> <i class="mdi mdi-account fs-4 text-black me-2"></i>
                                                                Assign Staff
                                                            </span>
                                                        </a>
                                                    @endif
                                                    @if ($journalStaff == $loginStaff)
                                                        <a href="javascript:;" class="dropdown-item"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_submit_journal"
                                                            onclick="fetchData('{{ $list->sno }}')">
                                                            <span> <i
                                                                    class="mdi mdi-book-open-variant-outline fs-4 text-black me-2"></i>
                                                                Submit Journal
                                                            </span>
                                                        </a>
                                                    @endif

                                                    @php
                                                        $encryptedValue = $helper->encrypt_decrypt(
                                                            $list->sno,
                                                            'encrypt',
                                                        );
                                                        $url = url('/view_manage_journal/' . $encryptedValue);
                                                    @endphp
                                                    @if (auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                                        <a href="{{ $url }}" class="dropdown-item">
                                                            <span> <i
                                                                    class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                                                        </a>
                                                    @endif
                                                    @if (auth()->user()->hasPermission($module_name, 'Add Requirement', $menu_name))
                                                        <a href="javascript:;" class="dropdown-item"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_assign_requirements"
                                                            onclick="openRequirement('{{ $list->sno }}')">
                                                            <span><i
                                                                    class="mdi mdi-file-document-plus-outline fs-3 text-black me-1"></i></span>
                                                            <span>Requirments</span>
                                                        </a>
                                                    @endif
                                                    <!--@ if ($journalTL === $loginStaff)-->
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_journal_passlocker"
                                                        onclick="passLocker('{{ $list->journal_customer_id }}')">
                                                        <span> <i class="mdi mdi-file-key fs-3 text-black me-1"></i>Pass
                                                            Locker</span>
                                                    </a>
                                                    <!--@ endif-->
                                                </div>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr id="colse_tr_div{{ $i }}"
                                        style="display:none;background-color: #efffdd52;">
                                        <td colspan="9">
                                            <table class="table align-top gy-1 gs-2 indv_cust_jour">
                                                <thead>
                                                    <tr class="text-start align-top fs-6 gs-0">
                                                        <th class="min-w-10px text-black fw-semibold text-center">S.No</th>
                                                        <th class="min-w-100px text-black fw-semibold">Paper & Booklet /
                                                            Domain</th>
                                                        <th class="min-w-50px text-black fw-semibold">Submitted Date</th>
                                                        <th class="min-w-100px text-black fw-semibold">Status</th>
                                                        <th class="min-w-50px text-black fw-semibold">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="text-gray-600 fw-semibold fs-7">
                                                    @foreach ($list->journal_data as $mi => $journal)
                                                        @php
                                                            $statusColors = [
                                                                0 => [
                                                                    'row' => '#CCE5FF',
                                                                    'badge' => '#007BFF',
                                                                    'label' => 'Submitted',
                                                                ],
                                                                1 => [
                                                                    'row' => '#d8d9c1 ',
                                                                    'badge' => '#a8ab14',
                                                                    'label' => 'With Editor',
                                                                ],
                                                                5 => [
                                                                    'row' => '#abc9e9',
                                                                    'badge' => '#DC3545',
                                                                    'label' => 'Accepted',
                                                                ],
                                                                3 => [
                                                                    'row' => '#e7d4b2 ',
                                                                    'badge' => '#800080',
                                                                    'label' => 'Under Reviewer',
                                                                ],
                                                                4 => [
                                                                    'row' => '#9dd7c1',
                                                                    'badge' => '#28A745',
                                                                    'label' => 'Revision',
                                                                ],
                                                                6 => [
                                                                    'row' => '#dbc1c4 ',
                                                                    'badge' => '#17A2B8',
                                                                    'label' => 'Rejected',
                                                                ],
                                                                7 => [
                                                                    'row' => '#b893b9 ',
                                                                    'badge' => '#17A2B8',
                                                                    'label' => 'E-Proofing',
                                                                ],
                                                                8 => [
                                                                    'row' => '#6bd2e3  ',
                                                                    'badge' => '#17A2B8',
                                                                    'label' => 'Published ',
                                                                ],
                                                            ];

                                                            $status = $journal->status;
                                                            $colors = $statusColors[$status] ?? [
                                                                'row' => '#FFFFFF',
                                                                'badge' => '#6c757d',
                                                                'label' => 'Unknown',
                                                            ];
                                                            $journalPaper =
                                                                $journal->published_paper_name ?? $journal->paper_name;
                                                        @endphp

                                                        <tr style="background-color: {{ $colors['row'] }} !important;">
                                                            <td align="center">{{ $mi + 1 }}</td>

                                                            @php
                                                                if (count($journal->domain_names) > 0) {
                                                                    $domains = implode(', ', $journal->domain_names);
                                                                } else {
                                                                    $domains = 'Not Available';
                                                                }
                                                            @endphp
                                                            <td>
                                                                <div class="d-flex flex-column gap-1">
                                                                    <div class="fs-7 fw-semibold text-black text-truncate"
                                                                        style="width:700px;" data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        data-bs-original-title="{{ $journalPaper }}">
                                                                        {{ $journalPaper }}</div>
                                                                    <div class="d-flex align-items-center gap-1 ">
                                                                        <div class="d-flex align-items-center gap-2 ">
                                                                            <label
                                                                                class="fw-semibold text-danger fs-8 ">{{ $journal->journal_id }}</label>
                                                                            <label class="text-muted">|</label>
                                                                            <div class="d-flex align-items-center gap-2">
                                                                                <span
                                                                                    class="mdi mdi-book-open-blank-variant"></span>
                                                                                <div class="text-truncate"
                                                                                    style="max-width:300px;"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    data-bs-original-title="Journal Booklet:{{ $journal->journal_name }}">
                                                                                    {{ $journal->journal_name }}</div>
                                                                            </div>
                                                                            <label class="text-muted">|</label>
                                                                            <div class="d-flex align-items-center gap-2">
                                                                                <span class="mdi mdi-alpha-i-box"></span>
                                                                                <div class="text-truncate"
                                                                                    style="max-width:300px; "
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    data-bs-original-title="Domain: {{ $domains }}">
                                                                                    {{ $domains }}</div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </td>

                                                            <td>
                                                                <div class="fs-7 fw-bold text-primary text-uppercase p-2 rounded text-truncate"
                                                                    style="max-width: 200px;">
                                                                    {{ \Carbon\Carbon::parse($journal->submited_date)->format('d-M-Y') }}
                                                                </div>
                                                                {{-- </td>

                                                                <td align="center">
                                                                    <div class="mb-0 mx-2">
                                                                        <label
                                                                            class="{{ $journal->publish_author ? 'bg-warning' : '' }} text-black px-2 py-1 text-truncate fw-semibold fs-7"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="{{ $journal->publish_author ?? '-' }}">{{ $journal->publish_author ?? '-' }}</label>
                                                                        <div class="d-block">
                                                                            <div
                                                                                class="{{ $journal->publish_date ? 'bg-info text-white' : 'text-black' }} px-2 py-1 fw-semibold fs-8">
                                                                                {{ $journal->publish_date }}</div>
                                                                        </div>
                                                                    </div>
                                                                </td> --}}
                                                                {{-- <td align="center">
                                                                    @if (!empty($journal->publish_url))
                                                                        <a href="{{ $journal->publish_url }}"
                                                                            target="_blank"
                                                                            class="badge bg-body rounded px-2"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Published Link">
                                                                            <i
                                                                                class="mdi mdi-link-variant text-danger fs-4"></i>
                                                                        </a>
                                                                    @else
                                                                        -
                                                                    @endif
                                                                </td> --}}
                                                            <td>
                                                                @if ($publishedCount > 0)
                                                                    @if ($journal->status == 2)
                                                                        <div class="badge bg-secondary text-black mb-1 fs-7 fw-semibold"
                                                                            style="background-color:#c7c7c7 !important;">
                                                                            Closed
                                                                        </div>
                                                                    @elseif ($journal->status == 8)
                                                                        {{-- PUBLISHED BLOCK --}}
                                                                        <div class="d-flex align-items-center gap-1">
                                                                            <div class="badge text-white mb-1 fs-7 fw-semibold"
                                                                                style="background-color:#7239EA !important;">
                                                                                Published
                                                                            </div>
                                                                            <a href="javascript:;"
                                                                                class="dropdown-toggle hide-arrow"
                                                                                data-bs-toggle="dropdown">
                                                                                <i
                                                                                    class="ms-1 mdi mdi-information text-info fs-9 animation-blink"></i>
                                                                            </a>

                                                                            <div
                                                                                class="dropdown-menu py-2 px-4 text-black">
                                                                                <div class="row mb-2">
                                                                                    <div class="col-lg-4 fw-semibold">
                                                                                        Author</div>
                                                                                    <div class="col-lg-1">:</div>
                                                                                    <div class="col-lg-7 fw-bold">
                                                                                        {{ $journal->publish_author ?? '-' }}
                                                                                    </div>
                                                                                </div>

                                                                                <div class="row mb-2">
                                                                                    <div class="col-lg-4 fw-semibold">
                                                                                        Published Date</div>
                                                                                    <div class="col-lg-1">:</div>
                                                                                    <div class="col-lg-7 fw-bold">
                                                                                        {{ $journal->publish_date ? date('d-M-Y', strtotime($journal->publish_date)) : 'N/A' }}
                                                                                    </div>
                                                                                </div>

                                                                                <div class="row mb-2">
                                                                                    <div class="col-lg-4 fw-semibold">
                                                                                        Published Link</div>
                                                                                    <div class="col-lg-1">:</div>
                                                                                    <div class="col-lg-7 fw-bold">
                                                                                        <a href="{{ $journal->publish_url }}"
                                                                                            target="_blank"
                                                                                            class="d-flex align-items-center gap-1">
                                                                                            <i
                                                                                                class="mdi mdi-link-variant text-danger fs-4"></i>
                                                                                            <span
                                                                                                class="text-truncate text-danger"
                                                                                                style="width:200px;">
                                                                                                {{ $journal->publish_url }}
                                                                                            </span>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    @else
                                                                        <div class="badge text-white mb-1 fs-7 fw-semibold"
                                                                            style="background-color:#da2020 !important;">
                                                                            Awaiting Close
                                                                        </div>
                                                                    @endif
                                                                @else
                                                                    @switch($journal->status)
                                                                        @case(0)
                                                                            <a href="javascript:;"
                                                                                class="badge text-white mb-1 fs-7 fw-semibold"
                                                                                style="background-color:#007BFF !important;"
                                                                                data-bs-toggle="dropdown">
                                                                                Submitted <i class="mdi mdi-menu-down"></i>
                                                                            </a>
                                                                            <div class="dropdown-menu">
                                                                                <a class="dropdown-item" data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_journal_with_editor"
                                                                                    onclick="getJournalWithEditorData('{{ $journal->sno }}')">
                                                                                    With Editor
                                                                                </a>
                                                                            </div>
                                                                        @break

                                                                        @case(1)
                                                                            <a href="javascript:;"
                                                                                class="badge text-black mb-1 fs-7 fw-semibold"
                                                                                style="background-color:#a8ab14 !important;"
                                                                                data-bs-toggle="dropdown">
                                                                                With Editor <i class="mdi mdi-menu-down"></i>
                                                                            </a>
                                                                            <div class="dropdown-menu">
                                                                                <a class="dropdown-item" data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_journal_with_editor"
                                                                                    onclick="getJournalWithEditorData('{{ $journal->sno }}')">
                                                                                    With Editor
                                                                                </a>
                                                                                <a class="dropdown-item" data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_journal_under_reviewer"
                                                                                    onclick="getJournalUnderReviewer('{{ $journal->sno }}')">
                                                                                    Under Reviewer
                                                                                </a>
                                                                            </div>
                                                                        @break

                                                                        @case(2)
                                                                            <div class="badge text-black mb-1 fs-7 fw-semibold"
                                                                                style="background-color:#c7c7c7 !important;">
                                                                                Closed
                                                                            </div>
                                                                        @break

                                                                        @case(3)
                                                                            <a href="javascript:;"
                                                                                class="badge text-white mb-1 fs-7 fw-semibold"
                                                                                style="background-color:#ed9900 !important;"
                                                                                data-bs-toggle="dropdown">
                                                                                Under Reviewer <i class="mdi mdi-menu-down"></i>
                                                                            </a>
                                                                            <div class="dropdown-menu">
                                                                                <a class="dropdown-item" data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_journal_under_reviewer"
                                                                                    onclick="getJournalUnderReviewer('{{ $journal->sno }}')">
                                                                                    Under Reviewer
                                                                                </a>
                                                                                <a class="dropdown-item" data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_journal_reviewed"
                                                                                    onclick="getJournalReviewData('{{ $journal->sno }}')">
                                                                                    Revision
                                                                                </a>
                                                                            </div>
                                                                        @break

                                                                        @case(4)
                                                                            <a href="javascript:;"
                                                                                class="badge text-white mb-1 fs-7 fw-semibold"
                                                                                style="background-color:#00ad6d !important;"
                                                                                data-bs-toggle="dropdown">
                                                                                Revision <i class="mdi mdi-menu-down"></i>
                                                                            </a>
                                                                            <div class="dropdown-menu">
                                                                                <a class="dropdown-item" data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_journal_reviewed"
                                                                                    onclick="getJournalReviewData('{{ $journal->sno }}')">
                                                                                    Revision
                                                                                </a>
                                                                                <a class="dropdown-item" data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_journal_accepted"
                                                                                    onclick="getJournalAcceptData('{{ $journal->sno }}')">
                                                                                    Accepted
                                                                                </a>
                                                                                <a class="dropdown-item" data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_journal_rejected"
                                                                                    onclick="getJournalRejectData('{{ $journal->sno }}')">
                                                                                    Rejected
                                                                                </a>
                                                                            </div>
                                                                        @break

                                                                        @case(5)
                                                                            <a href="javascript:;"
                                                                                class="badge text-white mb-1 fs-7 fw-semibold"
                                                                                style="background-color:#007bff !important;"
                                                                                data-bs-toggle="dropdown">
                                                                                Accepted <i class="mdi mdi-menu-down"></i>
                                                                            </a>
                                                                            <div class="dropdown-menu">
                                                                                <a class="dropdown-item" data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_journal_e_proofing"
                                                                                    onclick="getJournalEProofingData('{{ $journal->sno }}')">
                                                                                    E-Proofing
                                                                                </a>
                                                                            </div>
                                                                        @break

                                                                        @case(6)
                                                                            <div class="badge text-white mb-1 fs-7 fw-semibold"
                                                                                style="background-color:#DC3545 !important;">
                                                                                Rejected
                                                                            </div>
                                                                        @break

                                                                        @case(7)
                                                                            <a href="javascript:;"
                                                                                class="badge text-white mb-1 fs-7 fw-semibold"
                                                                                style="background-color:#940097 !important;"
                                                                                data-bs-toggle="dropdown">
                                                                                E-Proofing <i class="mdi mdi-menu-down"></i>
                                                                            </a>
                                                                            <div class="dropdown-menu">
                                                                                <a class="dropdown-item" data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_journal_published"
                                                                                    onclick="getJournalPublishData('{{ $journal->sno }}')">
                                                                                    Publish
                                                                                </a>
                                                                            </div>
                                                                        @break

                                                                        @case(8)
                                                                            {{-- SAME PUBLISHED BLOCK (no duplication removed fully since inline required) --}}
                                                                            <div class="d-flex align-items-center gap-1">
                                                                                <div class="badge text-white mb-1 fs-7 fw-semibold"
                                                                                    style="background-color:#7239EA !important;">
                                                                                    Published
                                                                                </div>
                                                                                <a href="javascript:;"
                                                                                    class="dropdown-toggle hide-arrow"
                                                                                    data-bs-toggle="dropdown">
                                                                                    <i
                                                                                        class="ms-1 mdi mdi-information text-info fs-9 animation-blink"></i>
                                                                                </a>

                                                                                <div class="dropdown-menu py-2 px-4 text-black">
                                                                                    <div class="row mb-2">
                                                                                        <div class="col-lg-4 fw-semibold">Author
                                                                                        </div>
                                                                                        <div class="col-lg-1">:</div>
                                                                                        <div class="col-lg-7 fw-bold">
                                                                                            {{ $journal->publish_author ?? '-' }}
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="row mb-2">
                                                                                        <div class="col-lg-4 fw-semibold">Published
                                                                                            Date</div>
                                                                                        <div class="col-lg-1">:</div>
                                                                                        <div class="col-lg-7 fw-bold">
                                                                                            {{ $journal->publish_date ? date('d-M-Y', strtotime($journal->publish_date)) : 'N/A' }}
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="row mb-2">
                                                                                        <div class="col-lg-4 fw-semibold">Published
                                                                                            Link</div>
                                                                                        <div class="col-lg-1">:</div>
                                                                                        <div class="col-lg-7 fw-bold">
                                                                                            <a href="{{ $journal->publish_url }}"
                                                                                                target="_blank"
                                                                                                class="d-flex align-items-center gap-1">
                                                                                                <i
                                                                                                    class="mdi mdi-link-variant text-danger fs-4"></i>
                                                                                                <span
                                                                                                    class="text-truncate text-danger"
                                                                                                    style="width:200px;">
                                                                                                    {{ $journal->publish_url }}
                                                                                                </span>
                                                                                            </a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        @break
                                                                    @endswitch
                                                                @endif
                                                            </td>

                                                            <td>
                                                                @if ($publishedCount == 0 && $journal->status != 8 && $journal->status != 2)
                                                                    @if (auth()->user()->hasPermission($module_name, 'Task Request', $menu_name))
                                                                        <a class="btn btn-icon btn-sm"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_task_request"
                                                                            onclick="getTaskRequest('{{ $journal->sno }}')">
                                                                            <i
                                                                                class="mdi mdi-pen-plus fs-3 text-black"></i>
                                                                        </a>
                                                                    @endif
                                                                @endif

                                                                @if (($publishedCount > 0) & ($journal->status != 8) && $journal->status != 2)
                                                                    <a class="btn btn-icon btn-sm" data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_journal_closer"
                                                                        onclick="CloseFetch('{{ $journal->sno }}', '{!! $journal->paper_name !!}', '{{ $journal->journal_id }}')">
                                                                        <i class="mdi mdi-file-document-remove fs-4"></i>
                                                                    </a>
                                                                @else
                                                                    @if ($journal->status == 8 && $loginStaff == 0 || $loginStaff == 1 || $loginStaff == 2)
                                                                        <a class="btn btn-info btn-icon btn-sm"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_generate_noc"
                                                                            onclick="Generate_nocData('{{ $journal->sno }}')">
                                                                            <i class="mdi mdi-file-document-arrow-right fs-4 text-white"
                                                                                title="Send NOC"></i>
                                                                        </a>
                                                                        @php
                                                                            $encryptedValue = $helper->encrypt_decrypt(
                                                                                $journal->sno,
                                                                                'encrypt',
                                                                            );
                                                                            $NOCurl = url('/manage_journal_noc/' . $encryptedValue);
                                                                        @endphp
                                                                         <a href="{{$NOCurl}}" class="btn btn-info btn-icon btn-sm" title="Journal NOC Link">
                                                                            <i class="mdi mdi-link-box-outline fs-4 text-white"
                                                                                title="Send NOC"></i>
                                                                        </a>
                                                                    @endif
                                                                @endif
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    {{-- <div class="bottom-scrollbar">
                            <div class="scroll-content"></div>
                        </div>
                    </div> --}}
                    <div class="mt-4">
                        {{ $lists->appends(request()->except(['page', '_token']))->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--begin::Modal - Journal E- Proofing-->
    <div class="modal fade" id="kt_modal_journal_e_proofing" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    <span class="badge bg-info text-white fs-6 fw-semibold"
                        style="background-color: #940097 !important;">E-Proofing</span> Journal ?
                    <div class="px-3 text-start mt-6">
                        <div class="row">
                            <input type="hidden" name="eProofingId" id="eProofingId">
                            <input type="hidden" name="e_proofing_files" id="e_proofing_files">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="e_proofing_customer"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="e_proofing_service"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="e_proofing_journal"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="e_proofing_paper"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="e_proogfing_domain"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                                <div class="e-proofing-upload-container">
                                    <div id="eProofingDropArea" class="e-proofing-drop-area">
                                        <div id="eProofingDropMessage" class="e-proofing-drop-message">
                                            <div class="e-proofing-upload-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                    viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                                                </svg>
                                            </div>
                                            <div class="e-proofing-upload-text">Drag & drop files here or <span
                                                    class="e-proofing-clickable">click to upload</span></div>
                                            <p class="e-proofing-upload-subtext">Supports PDF, DOC, DOCX, JPG, PNG • Max
                                                10MB per file</p>
                                        </div>
                                        <input type="file" id="eProofingFileInput" class="e-proofing-file-input"
                                            multiple />
                                    </div>

                                    <div class="e-proofing-preview-container" id="eProofingPreviewContainer">
                                        <div class="e-proofing-preview-header">
                                            <div class="e-proofing-preview-title">
                                                <span>Uploaded Files</span>
                                                <span class="badge" id="eProofingFileCount">0</span>
                                            </div>
                                            <button type="button" class="e-proofing-clear-all-btn"
                                                id="eProofingClearAllBtn">Clear All</button>
                                        </div>
                                        <div class="e-proofing-preview-list" id="eProofingPreviewList"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3 mt-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">E-Proofing Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" placeholder="Select Date" class="form-control journal_date"
                                        id="e_proofing_date" readonly />
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">E-Proofing Comments<span
                                        class="text-danger">*</span></label>
                                <textarea class="form-control" rows="5" placeholder="Enter E-Proofing Comments" id="e_proofing_comments"
                                    name="e_proofing_comments"></textarea>
                                <p id="e_proofing_comments_err" class="text-danger mt-1"></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="button" class="btn btn-primary me-3" onclick="validateEProofingForm()">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Journal E-Proofing-->

    <!--begin::Modal - Journal With Editor-->
    <div class="modal fade" id="kt_modal_journal_with_editor" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    <span class="badge bg-info text-white fs-6 fw-semibold"
                        style="background-color: #a8ab14 !important;">With Editor</span> Journal ?
                    <div class="px-3 text-start mt-6">
                        <div class="row">
                            <input type="hidden" name="withEditorId" id="withEditorId">
                            <input type="hidden" name="withEditorFiles" id="withEditorFiles">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="withEditorCustomer"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="withEditorService"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="withEditorJournal"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="withEditorPaper"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="withEditorDomain"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                                <div class="with-editor-upload-container">
                                    <div id="withEditorDropArea" class="with-editor-drop-area">
                                        <div id="withEditorDropMessage" class="with-editor-drop-message">
                                            <div class="with-editor-upload-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                    viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                                                </svg>
                                            </div>
                                            <div class="with-editor-upload-text">Drag & drop files here or <span
                                                    class="with-editor-clickable">click to upload</span></div>
                                            <p class="with-editor-upload-subtext">Supports PDF, DOC, DOCX, JPG, PNG • Max
                                                10MB per file</p>
                                        </div>
                                        <input type="file" id="withEditorFileInput" class="with-editor-file-input"
                                            multiple />
                                    </div>

                                    <div class="with-editor-preview-container" id="withEditorPreviewContainer">
                                        <div class="with-editor-preview-header">
                                            <div class="with-editor-preview-title">
                                                <span>Uploaded Files</span>
                                                <span class="badge" id="withEditorFileCount">0</span>
                                            </div>
                                            <button type="button" class="with-editor-clear-all-btn"
                                                id="withEditorClearAllBtn">Clear All</button>
                                        </div>
                                        <div class="with-editor-preview-list" id="withEditorPreviewList"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3 mt-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">With Editor Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" placeholder="Select Date" class="form-control journal_date"
                                        id="with_editor_date" readonly />
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">With Editor Comments<span
                                        class="text-danger">*</span></label>
                                <textarea class="form-control" rows="5" placeholder="Enter With Editor Comments" id="withEditorComments"
                                    name="with_editor_comments"></textarea>
                                <p id="withEditorCommentsErr" class="text-danger mt-1"></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="button" class="btn btn-primary me-3" onclick="validateWithEditor()">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Journal With Editor-->

    <!--begin::Modal - Journal Under Reviwer-->
    <div class="modal fade" id="kt_modal_journal_under_reviewer" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    <span class="badge bg-info text-white fs-6 fw-semibold"
                        style="background-color: #ed9900 !important;">Under Reviewer</span> Journal ?
                    <div class="px-3 text-start mt-6">
                        <div class="row">
                            <input type="hidden" name="underReviewerId" id="underReviewerId">
                            <input type="hidden" name="under_reviewer_files" id="under_reviewer_files">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="under_reviewer_customer">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="under_reviewer_service">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="under_reviewer_journal">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="under_reviewer_paper"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="under_reviewer_domain"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                                <div class="under-reviewer-upload-container">
                                    <div id="underReviewerDropArea" class="under-reviewer-drop-area">
                                        <div id="underReviewerDropMessage" class="under-reviewer-drop-message">
                                            <div class="under-reviewer-upload-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                    viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                                                </svg>
                                            </div>
                                            <div class="under-reviewer-upload-text">Drag & drop files here or <span
                                                    class="under-reviewer-clickable">click to upload</span></div>
                                            <p class="under-reviewer-upload-subtext">Supports PDF, DOC, DOCX, JPG, PNG •
                                                Max 10MB per file</p>
                                        </div>
                                        <input type="file" id="underReviewerFileInput"
                                            class="under-reviewer-file-input" multiple />
                                    </div>

                                    <div class="under-reviewer-preview-container" id="underReviewerPreviewContainer">
                                        <div class="under-reviewer-preview-header">
                                            <div class="under-reviewer-preview-title">
                                                <span>Uploaded Files</span>
                                                <span class="badge" id="underReviewerFileCount">0</span>
                                            </div>
                                            <button type="button" class="under-reviewer-clear-all-btn"
                                                id="underReviewerClearAllBtn">Clear All</button>
                                        </div>
                                        <div class="under-reviewer-preview-list" id="underReviewerPreviewList"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3 mt-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Under Reviewer Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" placeholder="Select Date" class="form-control journal_date"
                                        id="under_reviewer_date" readonly />
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Under Reviewer Comments<span
                                        class="text-danger">*</span></label>
                                <textarea class="form-control" rows="5" placeholder="Enter Under Reviewer Comments" id="underReviewerComments"
                                    name="underReviewerComments"></textarea>
                                <p id="underReviewerCommentsErr" class="text-danger mt-1"></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="button" class="btn btn-primary me-3" onclick="vallidateunderReviewer()">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Journal Under Reviewer-->

    <!--begin::Modal - Add Journal Booklet AI-->
    <div class="modal fade" id="kt_modal_add_journal_booklet_ai" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xxl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black me-3"><label>AI Assistance</label>
                            <label>
                                <svg class="w-50px h-50px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"
                                    id="ai-study">
                                    <ellipse cx="32" cy="61" fill="#e3eaff" rx="17"
                                        ry="3"></ellipse>
                                    <rect width="34.36" height="31.33" x="14.82" y="19.92" fill="#b0c4ff"
                                        rx="7"></rect>
                                    <rect width="30.32" height="31.33" x="14.82" y="19.92" fill="#fff"
                                        rx="7"></rect>
                                    <rect width="26.27" height="31.33" x="18.86" y="19.92" fill="#e3eaff"
                                        rx="7"></rect>
                                    <path fill="#b0c4ff"
                                        d="m32 19.92-11.12-2.9 1.31 3.97L32 24.97l11.83-2.08-.71-5.87L32 19.92z"></path>
                                    <path fill="#0040ff"
                                        d="M42.11 52H21.89a7.84 7.84 0 0 1-7.83-7.83V27a7.84 7.84 0 0 1 7.83-7.83h20.22A7.84 7.84 0 0 1 49.94 27v17.17A7.84 7.84 0 0 1 42.11 52ZM21.89 20.67A6.32 6.32 0 0 0 15.58 27v17.17a6.32 6.32 0 0 0 6.31 6.31h20.22a6.32 6.32 0 0 0 6.31-6.31V27a6.32 6.32 0 0 0-6.31-6.32Z">
                                    </path>
                                    <path fill="#4f7bff" d="M49.18 27.5h2.06a4 4 0 0 1 4 4v8.17a4 4 0 0 1-4 4h-2.06V27.5Z">
                                    </path>
                                    <path fill="#6b90ff" d="M49.18 43.66V27.5a4 4 0 0 1 4 4v8.08a4 4 0 0 1-4 4.08Z">
                                    </path>
                                    <path fill="#a3baff"
                                        d="M12.76 27.5h2.06v16.16h-2.06a4 4 0 0 1-4-4V31.5a4 4 0 0 1 4-4Z">
                                    </path>
                                    <path fill="#6b90ff" d="M14.82 43.66a4 4 0 0 1-4-4v-8.12a4 4 0 0 1 4-4Z"></path>
                                    <path fill="#0040ff"
                                        d="M51.2 44.42h-2a.76.76 0 0 1-.76-.76V27.5a.76.76 0 0 1 .76-.76h2a4.8 4.8 0 0 1 4.8 4.8v8.08a4.8 4.8 0 0 1-4.8 4.8zm-1.26-1.51h1.26a3.29 3.29 0 0 0 3.28-3.29v-8.08a3.29 3.29 0 0 0-3.28-3.29h-1.26zm-35.12 1.51h-2A4.8 4.8 0 0 1 8 39.62v-8.08a4.8 4.8 0 0 1 4.8-4.8h2a.76.76 0 0 1 .76.76v16.16a.76.76 0 0 1-.74.76zm-2-16.17a3.29 3.29 0 0 0-3.28 3.29v8.08a3.29 3.29 0 0 0 3.28 3.29h1.26V28.25z">
                                    </path>
                                    <path fill="#c4d3ff" d="M32 16.89 8.76 10.82 32 4.76l23.24 6.06L32 16.89z"></path>
                                    <path fill="#9cb4ff" d="m34.21 16.31-15.35-5.49 14.3-3.53 22.08 3.53-21.03 5.49z">
                                    </path>
                                    <path fill="#0040ff"
                                        d="M32 17.64h-.19L8.57 11.55a.74.74 0 0 1-.57-.73.75.75 0 0 1 .57-.73L31.81 4a.62.62 0 0 1 .38 0l23.24 6.06a.75.75 0 0 1 .57.73.74.74 0 0 1-.57.73l-23.24 6.1Zm-20.24-6.82L32 16.1l20.24-5.28L32 5.54Z">
                                    </path>
                                    <path fill="#7d9dff" d="m32 16.89-11.12-2.91v6.07L32 22.95l11.12-2.9v-6.07L32 16.89z">
                                    </path>
                                    <path fill="#9cb4ff" d="m32 18.91-11.12-2.9v4.04L32 22.95l7.07-1.85v-4.04L32 18.91z">
                                    </path>
                                    <path fill="#0040ff"
                                        d="M32 23.71a.63.63 0 0 1-.19 0l-11.12-2.9a.76.76 0 0 1-.56-.73V14a.73.73 0 0 1 .29-.6.75.75 0 0 1 .66-.14L32 16.1l10.92-2.85a.75.75 0 0 1 .66.14.76.76 0 0 1 .29.6v6.06a.76.76 0 0 1-.56.73l-11.12 2.9a.63.63 0 0 1-.19.03zm-10.36-4.25L32 22.16l10.36-2.7V15l-10.17 2.62a.81.81 0 0 1-.38 0L21.64 15zm33.6 2.22a.76.76 0 0 1-.76-.75V10.82a.76.76 0 1 1 1.52 0v10.11a.76.76 0 0 1-.76.75zM38.57 45.43H25.43a.76.76 0 0 1-.76-.76v-2a.76.76 0 0 1 1.52 0v1.27h11.62v-1.29a.76.76 0 0 1 1.52 0v2a.76.76 0 0 1-.76.78z">
                                    </path>
                                    <path fill="#7d9dff"
                                        d="M39.07 37.09H24.93a4 4 0 0 1-4.05-4 4 4 0 0 1 4.05-4h14.14a4 4 0 0 1 4 4 4 4 0 0 1-4 4Z">
                                    </path>
                                    <path fill="#bacbff"
                                        d="M35 37.09H24.93a4 4 0 0 1-4.05-4 4 4 0 0 1 4.05-4H35a4 4 0 0 1 4 4 4 4 0 0 1-4 4Z">
                                    </path>
                                    <path fill="#adc2ff"
                                        d="M35 37.09h-6a4 4 0 0 1-4-4 4 4 0 0 1 4-4h6a4 4 0 0 1 4 4 4 4 0 0 1-4 4Z"></path>
                                    <path fill="#0040ff"
                                        d="M28 33.05a1 1 0 1 1-1-1 1 1 0 0 1 1 1zm10.06 0a1 1 0 1 1-1-1 1 1 0 0 1 1 1z">
                                    </path>
                                    <path fill="#0040ff"
                                        d="M39.07 37.85H24.93a4.8 4.8 0 0 1 0-9.6h14.14a4.8 4.8 0 1 1 0 9.6Zm-14.14-8.08a3.29 3.29 0 1 0 0 6.57h14.14a3.29 3.29 0 1 0 0-6.57Z">
                                    </path>
                                </svg>
                            </label>
                        </h3>
                    </div>
                    <div class="row">
                        {{-- <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Customer<span
                                class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Customer</option>
                            <option value="1">Priya Dharshini</option>
                            <option value="2">Selvin R</option>
                            <option value="3">Rama Lakshmi</option>
                        </select>
                    </div> --}}
                        <div class="col-lg-8 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Journal Link<span
                                    class="text-danger">*</span></label>
                            <input type="text" id="journalInput" class="form-control"
                                placeholder="Type journal paper name here..." />
                        </div>
                        <div class="col-lg-4 mb-2 d-flex align-items-center ">
                            <a href="javascript:;" id="searchBtn" class="btn px-0 py-0 bg-transparent">
                                <img src="{{ asset('assets/phdizone_images/search.png') }}" class="w-60px h-60px" />

                            </a>
                        </div>
                    </div>

                    <div id="loadingSpinner"
                        style="display:none; justify-content:center; align-items:center; margin-top:10px;">
                        <div class="spinner-border text-primary" role="status" aria-hidden="true"></div>
                        <span class="visually-hidden">Loading...</span>
                    </div>

                    <!-- Error message -->
                    <div id="errorMsg" class="text-danger fs-7 mt-2" style="display:none;"></div>

                    <div class="row">
                        <div id="results" style="display: none;">
                            <div class="col-lg-4 mt-4">
                                <div class="card h-100 rounded">
                                    <div class="card-header pb-0 border border-bottom bg-label-success py-2">
                                        <div class="fs-5 card-title fw-bold">
                                            <label><svg class="w-30px h-30px me-2" xmlns="http://www.w3.org/2000/svg"
                                                    xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 16 16"
                                                    id="Database">
                                                    <defs>
                                                        <linearGradient id="a">
                                                            <stop offset="0" stop-color="#1c1d1f"
                                                                class="stopColor000092 svgShape"></stop>
                                                            <stop offset="1" stop-color="#0055ff"
                                                                class="stopColorff00f3 svgShape"></stop>
                                                        </linearGradient>
                                                        <linearGradient xlink:href="#a" id="b" x1=".957"
                                                            x2="13" y1="8" y2="8"
                                                            gradientUnits="userSpaceOnUse"></linearGradient>
                                                    </defs>
                                                    <path fill="url(#b)"
                                                        d="M5.318 1a.819.819 0 0 0-.818.818v5.127C4.5 7.526 4.974 8 5.555 8h4.89c.581 0 1.055-.474 1.055-1.055V1.818A.819.819 0 0 0 10.682 1H5.318zm.237 1 4.945.055V3H5.543l.012-1zM5.53 4H10.5v1H5.521l.01-1zM5.51 6h4.99v.945L10.445 7 5.5 6.945 5.51 6zM7.5 9v3.635c0 .19-.156.345-.346.345H3.908a1.52 1.52 0 0 0-1.43-1.023c-.837 0-1.521.684-1.521 1.522S1.641 15 2.479 15c.663 0 1.221-.428 1.43-1.021h3.247c.325 0 .613-.13.846-.323.233.193.519.323.844.323h3.248A1.513 1.513 0 0 0 13.52 15c.838 0 1.522-.682 1.522-1.521 0-.84-.683-1.522-1.522-1.522-.663 0-1.221.43-1.43 1.022H8.847a.345.345 0 0 1-.346-.344V9h-1zm-5.021 3.957a.522.522 0 1 1-.002 1.044.522.522 0 0 1 .002-1.044zm11.042 0a.523.523 0 0 1 0 1.043.522.522 0 0 1 0-1.043z">
                                                    </path>
                                                </svg></label>
                                            <label>Database Journal</label>

                                        </div>
                                    </div>

                                    <div class="card-body pb-1 pt-0">
                                        <div class="row">
                                            <div class="scroll-y max-h-400px  px-3 pt-2 mb-4" id="databaseContainer">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 mt-4">
                                <div class="card h-100 rounded">
                                    <div class="card-header pb-0 border border-bottom bg-label-info py-2">
                                        <div class="fs-5 card-title fw-bold">
                                            <svg class="w-40px h-40px" xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 32 32" id="OnlineSearch">
                                                <path fill="#3074fb"
                                                    d="M25.06,21.57H24v-7.8a1,1,0,1,0-2,0v7.8H6v-12H18.28a1,1,0,0,0,0-2H5a1,1,0,0,0-1,1v13H3.23a1,1,0,0,0-1,1v.36A5.07,5.07,0,0,0,7.29,28H21a5.07,5.07,0,0,0,5.06-5.06v-.36A1,1,0,0,0,25.06,21.57ZM21,26H7.29a3.08,3.08,0,0,1-3-2.42H24A3.06,3.06,0,0,1,21,26Z"
                                                    class="color30c1fb svgShape"></path>
                                                <path fill="#1c1d1f"
                                                    d="M29.48,14.87,27,12.43a5.44,5.44,0,1,0-1.42,1.41l2.45,2.45a1,1,0,0,0,1.41-1.42ZM20.2,11.79a3.39,3.39,0,1,1,4.79,0A3.39,3.39,0,0,1,20.2,11.79Z"
                                                    class="color2446d8 svgShape"></path>
                                            </svg>
                                            <label>Online Search</label>

                                        </div>
                                    </div>

                                    <div class="card-body pb-1 pt-0">
                                        <div class="row">
                                            <div class="scroll-y max-h-400px  px-3 pt-2 mb-4"
                                                id="onlineSearchContainer">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 mt-4">
                                <div class="card h-100 rounded">
                                    <div class="card-header pb-0 border border-bottom bg-label-primary py-2">
                                        <div class="fs-5 card-title fw-bold">
                                            <label>
                                                <svg class="w-40px w-40px" xmlns="http://www.w3.org/2000/svg"
                                                    fill-rule="evenodd" stroke-linejoin="round"
                                                    stroke-miterlimit="1.414" clip-rule="evenodd" viewBox="0 0 32 32"
                                                    id="Recommendation">
                                                    <path fill="none" d="M0 0h32v32H0z"></path>
                                                    <path fill="#1c1d1f" fill-rule="nonzero"
                                                        d="M16.05 3c2.915.028 5.745 1.767 7.073 4.358 1.121 2.188 1.152 4.899.086 7.111-1.509 3.13-5.189 5.066-8.723 4.389-3.251-.624-5.95-3.456-6.41-6.74-.351-2.508.57-5.16 2.404-6.908A8.072 8.072 0 0 1 15.947 3h.103Zm-.09 2c-2.75.026-5.31 2.118-5.847 4.828-.389 1.959.28 4.099 1.721 5.49 1.666 1.608 4.299 2.127 6.465 1.225 1.915-.796 3.354-2.649 3.642-4.703.356-2.544-1.123-5.246-3.475-6.31A6.034 6.034 0 0 0 15.96 5Z"
                                                        class="color546e7a svgShape"></path>
                                                    <path fill="#296df6" fill-rule="nonzero"
                                                        d="m16.982 18.919 4.146 7.181 1.573-2.382s.367-.409.774-.447l2.849-.171-2.825-4.894s-.198-.365-.104-.742c.095-.383.437-.693.831-.748.133-.019.166-.009.209-.007.327.034.618.211.796.497l3.635 6.295c.107.202.115.27.128.398.05.486-.305.983-.796 1.082-.061.013-.077.012-.139.018l-3.965.238-2.189 3.315s-.239.343-.62.426c-.365.08-.77-.065-1.002-.36-.038-.05-.045-.064-.078-.117l-5.55-9.613a7.7 7.7 0 0 0 2.327.031Zm-8.375-4.9a8.193 8.193 0 0 0 1.18 1.956L5.673 23.1l2.849.171s.457.074.688.334c.042.047.05.061.087.113L10.87 26.1l2.263-3.92s.841-.835 1.515-.26c.315.269.434.742.28 1.129-.024.061-.033.074-.063.132l-3.072 5.32c-.126.201-.183.243-.292.319a1.03 1.03 0 0 1-1.32-.153c-.043-.048-.051-.062-.089-.115l-2.189-3.315-3.965-.238s-.435-.04-.697-.345a1.02 1.02 0 0 1-.172-1.022c.024-.06.033-.074.063-.131l5.475-9.482Z"
                                                        class="color29b6f6 svgShape"></path>
                                                </svg>
                                            </label>
                                            Recommended Journal
                                        </div>
                                    </div>

                                    <div class="card-body pb-1 pt-0">
                                        <div class="row">
                                            <div class="scroll-y max-h-400px px-1 pt-2 mb-4" id="recommendedContainer">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">AI Assistance</a>
                </div> --}}
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Journal Booklet AI-->

    <!--begin::Modal - Journal Staff Assign-->
    <div class="modal fade" id="kt_modal_journal_assign_staff" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Assign Staff</h3>
                    </div>
                    <form action="{{ route('add_journal_staff') }}" method="POST" id="assign_journal_staff">
                        @csrf
                        <div class="row mt-4">
                            <input type="hidden" name="assgn_service_id" id="assgn_service_id">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="assgn_service">
                                    -
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="assgn_cus">-</div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Mobile</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="assgn_mobile">-</div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Email ID</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="assgn_mail">-</div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Assign Staff<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="assgn_staff_id" name="assgn_staff_id">
                                    <!-- AJAX Will Populate Dropdown -->
                                </select>
                                <p id="assgn_staff_err" class="text-danger mt-1 fs-6 fw-semibold"></p>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-8">
                            <button type="reset" class="btn btn-secondary me-3"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Assign Staff</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Journal Staff Assign-->

    <!--begin::Modal - Assign Requirements-->
    <div class="modal fade" id="kt_modal_assign_requirements" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <form id="requirementForm" enctype="multipart/form-data"
                    action="{{ route('requirement_manage_add_update_jnlcustomer') }}" method="POST" novalidate
                    autocomplete="off">
                    @csrf
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <input type="hidden" name="requirement_lead_id" id="requirement_lead_id">
                        <input type="hidden" name="requirement_status" id="requirement_status">
                        <input type="hidden" name="requirement_service_id" id="requirement_service_id">
                        <div class="mb-8 text-center">
                            <h3 class="text-center mb-4 text-black">New Journal Requirments</h3>
                        </div>
                        <div class="row g-3 mb-3">
                            <div class="col-lg-4">
                                <div class="card card-flush shadow-sm h-100">
                                    <div class="mt-3">
                                        <h6 class="text-dark fw-bold text-center">Customer Information</h6>
                                    </div>
                                    <div class="card-body pt-2 pb-5">

                                        <div class="d-flex flex-column mb-6">
                                            <div class=" mb-1">
                                                <div class="fw-bold text-gray-600">Name</div>
                                                <div class="fw-semibold text-primary" id="requirement_lead_name">-</div>
                                            </div>
                                            <div class=" mb-1">
                                                <div class="fw-bold text-gray-600">Mobile</div>
                                                <div class="fw-semibold text-primary" id="requirement_lead_mobile">-
                                                </div>
                                            </div>
                                            <div class="">
                                                <div class="fw-bold text-gray-600">Email</div>
                                                <div class="fw-semibold text-primary" id="requirement_lead_mail">-</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="card card-flush shadow-sm h-100">
                                    <div class="mt-3">
                                        <h6 class="text-dark fw-bold text-center">Services Information</h6>
                                    </div>
                                    <div id="requirement_service" class="px-2 py-2 scroll-y max-h-175px"></div>
                                </div>
                            </div>
                        </div>
                        <div class="card card-flush shadow-sm h-100 px-3 py-3">
                            <div class="row g-5">
                                <div class="col-lg-6 mb-4">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Project Journal Team Lead <span
                                            class="text-danger">*</span></label>
                                    <select id="pc_staff" name="pc_staff" class="select3 form-select">
                                        <option value="">Select Project Journal Team Lead</option>
                                    </select>
                                    <div class="pc_staff_err text-danger"></div>
                                </div>
                                <div class="col-lg-6 mb-4">
                                    <label class="text-black mb-1 fs-6 fw-semibold">RC</label><br>
                                    <input class="" type="checkbox" id="correction_chk" name="rc_chk"
                                        value="1" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-repeater_reqts mt-6">
                                    <div data-repeater-list="group-a_led_question" id="">
                                        <div data-repeater-item>
                                            <div class="row mt-4" id="default_repeater">
                                                <div class="col-lg-7 mb-3" id="default_requirement">
                                                    <label class="text-black mb-1 fs-6 fw-semibold"
                                                        id="requirement_label_1">Requirements Point 1<span
                                                            class="text-danger">*</span></label>
                                                    <input type="text" class="form-control"
                                                        placeholder="Enter Requirement Point 1" id="requirement_name_1"
                                                        name="requirement_name[]" />
                                                    <div class="text-danger err_mssg" id="requirement_name_1_err"></div>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-black mb-1 fs-6 fw-semibold">Attachments</label>
                                                    <div class="d-flex align-items-sm-center">
                                                        <img src="{{ asset('assets/phdizone_images/Document.jpg') }}"
                                                            alt="user-avatar"
                                                            class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid"
                                                            id="uploadedlogo_1" />
                                                        <div class="ms-1 button-wrapper" id="defalt_filediv">
                                                            <div class="d-flex align-items-start mt-2 mb-2">
                                                                <button type="button" id="default_doc"
                                                                    class="btn btn-sm btn-primary me-2" tabindex="0"
                                                                    data-bs-toggle="tooltip" data-bs-placement="top"
                                                                    title="Upload Document"
                                                                    onclick="document.getElementById('document_upload_1').click();">
                                                                    <i class="mdi mdi-tray-arrow-up"></i>
                                                                    <input type="file" id="document_upload_1"
                                                                        name="document_upload[]" class="file-in" hidden
                                                                        accept="image/png, image/jpeg, application/pdf, text/csv"
                                                                        onchange="fileChange(event)" />
                                                                </button>
                                                                <button type="button"
                                                                    class="btn btn-sm btn-outline-danger file-reset"
                                                                    data-bs-toggle="tooltip" data-bs-placement="top"
                                                                    title="Reset Document" id="uploaded_reset_1">
                                                                    <i class="mdi mdi-reload"></i>
                                                                </button>
                                                            </div>
                                                            <div class="small fs-8">Allowed JPG, PNG, PDF, CSV. Max size
                                                                5MB</div>
                                                            <div class="small text-success fs-8"
                                                                id="upload_file_name_1"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-1">
                                                    <a href="javascript:;"
                                                        class="btn btn-outline-danger mt-6 px-1 py-2 staff_reqts_del"
                                                        id="staff_reqts_del_1" style="display: none !important;">
                                                        <i class="mdi mdi-delete fs-4"></i>
                                                    </a>
                                                </div>
                                            </div>
                                            <div id="repeater_req"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-1 mt-1">
                                    <button type="button" class="btn btn-sm btn-primary staff_reqts_add px-2 py-1"
                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Add More"
                                        data-repeater-create>
                                        <i class="mdi mdi-plus me-1"></i>Add More
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="submit_requirements" class="btn btn-primary me-3">
                                Create Requirements
                            </button>
                        </div>
                    </div>
                </form>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Assign Requirements- -->

    <!--begin::Modal - Submit Journal-->
    <div class="modal fade" id="kt_modal_submit_journal" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Submit Journal</h3>
                    </div>
                    <form id="add_journal_form">
                        <div class="row mt-4">
                            <input type="hidden" id="uploaded_files" name="uploaded_files">
                            <input type="hidden" name="customer_id" id="customer_id">
                            <input type="hidden" name="customer_services_id" id="customer_services_id">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="add_services">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2 text-truncate"
                                    id="cus_info">-</div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal Booklet<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="journal_booklet_id" name="journal_booklet_id">
                                    <option value="">Select Journal Booklet</option>
                                </select>
                                <p id="booklet_error" class="text-danger mt-1 fs-7"></p>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Paper Name"
                                    id="paper_name" name="paper_name" />
                                <p id="paper_name_error" class="text-danger mt-1 fs-7"></p>
                            </div>
                            <div class="upload-container">
                                <label class="upload-label">Documents <span class="optional">(Optional)</span></label>
                                <div id="dropArea" class="drop-area">
                                    <div id="dropMessage" class="drop-message">
                                        <div class="upload-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                                stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                                            </svg>
                                        </div>
                                        <div class="upload-text">Drag & drop files here or <span
                                                class="clickable">browse</span></div>
                                        <p class="upload-subtext">Supports PDF, DOC, DOCX, JPG, PNG • Max 10MB per file
                                        </p>
                                    </div>
                                    <input type="file" id="fileInput" class="file-input d-none" multiple />
                                </div>

                                <div class="preview-container" id="previewContainer" style="display: none;">
                                    <div class="preview-header">
                                        <div class="preview-title">
                                            <span>Uploaded Files</span>
                                            <span class="badge" id="fileCount">0</span>
                                        </div>
                                        <button type="button" class="clear-all-btn" id="clearAllBtn">Clear
                                            All</button>
                                    </div>
                                    <div class="preview-list" id="previewList"></div>
                                </div>
                            </div>
                            <div class="scroll-y max-h-200px  border border-gray-300i px-3 pt-2 mt-4 mb-4">
                                <div class="form-repeater_jorn_bklt_create">
                                    <div data-repeater-list="group-a_jorn_bklt">
                                        <div data-repeater-item>
                                            <div class="row booklet_row">
                                                <div class="col-lg-5 mb-1">
                                                    <label class="text-black mb-1 fs-6 fw-semibold">Username / Email
                                                        ID<span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control journal_email"
                                                        placeholder="Enter Username / Email ID" name="email[]" />
                                                    <p class="text-danger mt-1 email_error"></p>
                                                </div>
                                                <div class="col-lg-6 mb-1">
                                                    <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                                            class="text-danger">*</span></label>
                                                    <input type="text" class="form-control journal_pass"
                                                        placeholder="Enter Password" name="password[]" />
                                                    <p class="text-danger mt-1 pass_error"></p>
                                                </div>
                                                <div class="col-lg-1 mb-1">
                                                    <a href="javascript:;"
                                                        class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_create_del"
                                                        id="jorn_bklt_create_del" style="display: none !important;">
                                                        <i class="mdi mdi-delete fs-4"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="bookletContainer"></div>
                            </div>
                            <div class="mb-4 mt-1">
                                <button type="button"
                                    class="btn btn-sm btn-primary jorn_bklt_create_add fs-8 px-2 py-1"
                                    data-repeater-create id="jorn_bklt_create_add">
                                    <i class="mdi mdi-plus me-1"></i> Add More
                                </button>
                            </div>
                            <div class="col-lg-6 mb-3 mt-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" placeholder="Enter Description" id="paper_desc"
                                    name="paper_desc"></textarea>
                            </div>
                            <div class="col-lg-6 mb-3 mt-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Submitted Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" placeholder="Select Date" class="form-control journal_date"
                                        id="journal_submitted_date" readonly />
                                </div>
                                <div class="text-danger mt-2 fs-7 fw-semibold" id="submitJournalDateErr"></div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-8">
                            <button type="reset" class="btn btn-secondary me-3"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" onclick="addValidation()">Submit
                                Journal</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Submit Journal-->

    <!--begin::Modal - View Journal-->
    <div class="modal fade" id="kt_modal_view_journal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center text-black">View Journal Details</h3>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Services</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold">Thesis Writing ( Writing Products )</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold">Priya <span class="fs-7 text-primary">(
                                2025/MDU01/CUS2334 )</span></label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Paper</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold">IEEE Internet of Things Journal</label>
                    </div>
                    <div class="d-flex align-items-center justify-content-between flex-wrap mb-4">
                        <div class="border text-center border-gray-300i flex-column rounded py-2 px-2">
                            <label class="text-dark fs-6 mb-1 fw-semibold">Scaler</label>
                            <div class="d-block">
                                <label class="badge bg-info fs-6 fw-semibold">01</label>
                            </div>
                        </div>
                        <div class="border text-center border-gray-300i flex-column rounded py-2 px-2">
                            <label class="text-dark fs-6 mb-1 fw-semibold">Published</label>
                            <div class="d-block">
                                <label class="badge bg-success fs-6 fw-semibold">0</label>
                            </div>
                        </div>
                        <div class="border text-center border-gray-300i flex-column rounded py-2 px-2">
                            <label class="text-dark fs-6 mb-1 fw-semibold">Reviewed</label>
                            <div class="d-block">
                                <label class="badge bg-warning text-black fs-6 fw-semibold">0</label>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                        <label class="col-12 text-black fs-7 fw-semibold">&emsp;&emsp; You will assist in writing and
                            organizing thesis chapters according to the guidelines.</label>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-12">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Documents</label>
                            <div class="border border-gray-600i border-dashed rounded py-3 px-2">
                                <div class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">
                                    <div class="mb-2">
                                        <a href="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                            class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded border border-gray-300i rounded w-80px h-80px"
                                            download>
                                            <img src="{{ asset('assets/phdizone_images/def_pdf.png') }}"
                                                class="h-80px w-80px" />
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Journal-->

    <!--begin::Modal - Journal Reviewed-->
    <div class="modal fade" id="kt_modal_journal_reviewed" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    <span class="badge bg-info text-white fs-6 fw-semibold"
                        style="background-color: #00ad6d !important;">Revision</span> Journal ?
                    <div class="px-3 text-start mt-6">
                        <div class="row">
                            <input type="hidden" name="review_journal_id" id="review_journal_id">
                            <input type="hidden" name="reviewed_files" id="reviewed_files">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="reviewed_customer"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="reviewed_services"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="reviewed_journal"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="reviewed_paper"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="reviewed_domain"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                                <div class="review-upload-container">
                                    <div id="reviewDropArea" class="review-drop-area">
                                        <div id="reviewDropMessage" class="review-drop-message">
                                            <div class="review-upload-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                    viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                                                </svg>
                                            </div>
                                            <div class="review-upload-text">Drag & drop files here or <span
                                                    class="review-clickable">click to upload</span></div>
                                            <p class="review-upload-subtext">Supports PDF, DOC, DOCX, JPG, PNG • Max 10MB
                                                per file</p>
                                        </div>
                                        <input type="file" id="reviewFileInput" class="review-file-input"
                                            multiple />
                                    </div>

                                    <div class="review-preview-container" id="reviewPreviewContainer">
                                        <div class="review-preview-header">
                                            <div class="review-preview-title">
                                                <span>Uploaded Files</span>
                                                <span class="badge" id="reviewFileCount">0</span>
                                            </div>
                                            <button type="button" class="review-clear-all-btn"
                                                id="reviewClearAllBtn">Clear All</button>
                                        </div>
                                        <div class="review-preview-list" id="reviewPreviewList"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3 mt-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Revision Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" placeholder="Select Date" class="form-control journal_date"
                                        id="journal_reviewed_date" readonly />
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Revision Comments<span
                                        class="text-danger">*</span></label>
                                <textarea class="form-control" rows="5" placeholder="Enter Revision Comments" id="reviewer_comment"
                                    name="reviewer_comment"></textarea>
                                <p id="reviewer_comment_err" class="text-danger mt-1"></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="button" class="btn btn-primary me-3" onclick="validateReviewForm()">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Journal Reviewed-->

    <!--begin::Modal - Journal Resubmitted-->
    <div class="modal fade" id="kt_modal_journal_resubmitted" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    <span class="badge bg-info fs-6 fw-semibold"
                        style="background-color: #800080 !important;">Resubmitted</span> Journal ?
                    <div class="px-3 text-start mt-6">
                        <div class="row">
                            <input type="hidden" name="resubmit_journal_id" id="resubmit_journal_id">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="resubmitted_customer"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="resubmitted_services"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="resubmitted_journal"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="resubmitted_domain"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="resubmitted_paper"></div>
                            </div>
                            <div class="col-lg-12 mb-3 mt-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Resubmitted Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" placeholder="Select Date" class="form-control journal_date"
                                        id="journal_resubmitted_date" readonly />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="button" class="btn btn-primary me-3" onclick="submitResubmitForm()">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Journal Resubmitted-->

    <!--begin::Modal - Journal Accepted-->
    <div class="modal fade" id="kt_modal_journal_accepted" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    <span class="badge fs-6 fw-semibold" style="background-color: #007bff !important;">Accepted</span>
                    Journal ?
                    <div class="px-3 text-start mt-6">
                        <div class="row">
                            <input type="hidden" name="accepted_journal_id" id="accepted_journal_id">
                            <input type="hidden" name="accepted_files" id="accepted_files">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="accepted_customer"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="accepted_services"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="accepted_journal"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="accepted_domain"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="accepted_paper"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                                <div class="accepted-upload-container">
                                    <div id="acceptedDropArea" class="accepted-drop-area">
                                        <div id="acceptedDropMessage" class="accepted-drop-message">
                                            <div class="accepted-upload-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                    viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                                                </svg>
                                            </div>
                                            <div class="accepted-upload-text">Drag & drop files here or <span
                                                    class="accepted-clickable">click to upload</span></div>
                                            <p class="accepted-upload-subtext">Supports PDF, DOC, DOCX, JPG, PNG • Max
                                                10MB per file</p>
                                        </div>
                                        <input type="file" id="acceptedFileInput" class="accepted-file-input"
                                            multiple />
                                    </div>

                                    <div class="accepted-preview-container" id="acceptedPreviewContainer">
                                        <div class="accepted-preview-header">
                                            <div class="accepted-preview-title">
                                                <span>Uploaded Files</span>
                                                <span class="badge" id="acceptedFileCount">0</span>
                                            </div>
                                            <button type="button" class="accepted-clear-all-btn"
                                                id="acceptedClearAllBtn">Clear All</button>
                                        </div>
                                        <div class="accepted-preview-list" id="acceptedPreviewList"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3 mt-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Accepted Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" placeholder="Select Date" class="form-control journal_date"
                                        id="journal_accepted_date" readonly />
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Accepted Comments<span
                                        class="text-danger">*</span></label>
                                <textarea class="form-control" rows="5" placeholder="Enter Accepted Comments" id="accepted_comment"
                                    name="accepted_comment"></textarea>
                                <p id="accepted_comment_err" class="text-danger mt-1"></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3" onclick="validateAcceptedForm()">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Journal Accepted-->

    <!--begin::Modal - Journal Rejected-->
    <div class="modal fade" id="kt_modal_journal_rejected" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    <span class="badge bg-info fs-6 fw-semibold"
                        style="background-color: #DC3545 !important;">Rejected</span> Journal ?
                    <div class="px-3 text-start mt-6">
                        <div class="row">
                            <input type="hidden" name="journal_reject_id" id="journal_reject_id">
                            <input type="hidden" name="rejected_files" id="rejected_files">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="rejected_customer"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border  text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="rejected_service"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="rejected_journal_name">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                                <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" id="rejected_paper_name">
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="rejected_domains"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                                <div class="rejected-upload-container">
                                    <div id="rejectedDropArea" class="rejected-drop-area">
                                        <div id="rejectedDropMessage" class="rejected-drop-message">
                                            <div class="rejected-upload-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                    viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                                                </svg>
                                            </div>
                                            <div class="rejected-upload-text">Drag & drop files here or <span
                                                    class="rejected-clickable">click to upload</span></div>
                                            <p class="rejected-upload-subtext">Supports PDF, DOC, DOCX, JPG, PNG • Max
                                                10MB per file</p>
                                        </div>
                                        <input type="file" id="rejectedFileInput" class="rejected-file-input"
                                            multiple />
                                    </div>

                                    <div class="rejected-preview-container" id="rejectedPreviewContainer">
                                        <div class="rejected-preview-header">
                                            <div class="rejected-preview-title">
                                                <span>Uploaded Files</span>
                                                <span class="badge" id="rejectedFileCount">0</span>
                                            </div>
                                            <button type="button" class="rejected-clear-all-btn"
                                                id="rejectedClearAllBtn">Clear All</button>
                                        </div>
                                        <div class="rejected-preview-list" id="rejectedPreviewList"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3 mt-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Rejected Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" placeholder="Select Date" class="form-control journal_date"
                                        id="journal_rejected_date" readonly />
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Rejected Reason<span
                                        class="text-danger">*</span></label>
                                <textarea class="form-control" rows="4" placeholder="Enter Rejected Reason" id="rejected_reason"
                                    name="rejected_reason"></textarea>
                                <div id="rejected_reason_error" class="text-danger mt-1 fw-semibold fs-7"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="button" onclick="validateRejectForm()" class="btn btn-primary me-3">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Journal Rejected-->

    <!--begin::Modal - Journal Published-->
    <div class="modal fade" id="kt_modal_journal_published" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Journal Published</h3>
                    </div>
                    <div class="row">
                        <input type="hidden" name="published_id" id="published_id">
                        <input type="hidden" name="publish_uploaded_files" id="publish_uploaded_files">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" id="published_customer"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" id="published_services"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" id="published_journal"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" id="published_paper"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="published_domain"></div>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Date<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" placeholder="Select Date" id="publish_date"
                                    name="publish_date" class="form-control published_date" readonly />
                            </div>
                            <div id="publish_date_error" class="text-danger fs-7 fw-semibold mt-1"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Paper Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Paper Name"
                                id="publish_paper" name="publish_paper" />
                            <div id="publish_paper_error" class="text-danger fs-7 fw-semibold mt-1"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Author Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Author Name"
                                id="publish_author" name="publish_author" />
                            <div id="publish_author_error" class="text-danger fs-7 fw-semibold mt-1"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter URL" id="publish_url"
                                name="publish_url" />
                            <div id="publish_url_error" class="text-danger fs-7 fw-semibold mt-1"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                            <div class="published-upload-container">
                                <div id="publishedDropArea" class="published-drop-area">
                                    <div id="publishedDropMessage" class="published-drop-message">
                                        <div class="published-upload-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                                stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                                            </svg>
                                        </div>
                                        <div class="published-upload-text">Drag & drop files here or <span
                                                class="published-clickable">click to upload</span></div>
                                        <p class="published-upload-subtext">Supports PDF, DOC, DOCX, JPG, PNG • Max 10MB
                                            per file</p>
                                    </div>
                                    <input type="file" id="publishedFileInput" class="published-file-input"
                                        multiple />
                                </div>

                                <div class="published-preview-container" id="publishedPreviewContainer">
                                    <div class="published-preview-header">
                                        <div class="published-preview-title">
                                            <span>Uploaded Files</span>
                                            <span class="badge" id="publishedFileCount">0</span>
                                        </div>
                                        <button type="button" class="published-clear-all-btn"
                                            id="publishedClearAllBtn">Clear All</button>
                                    </div>
                                    <div class="published-preview-list" id="publishedPreviewList"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="2" placeholder="Enter Description" name="publish_desc"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" onclick="validatePublishForm()">Journal
                            Published</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Journal Published-->

    <!--begin::Modal - Journal Pass Locker-->
    <div class="modal fade" id="kt_modal_journal_passlocker" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Journal Pass Locker</h3>
                    </div>
                    <div class="row">
                        <input type="hidden" name="published_id" id="published_id">
                        <input type="hidden" name="publish_uploaded_files" id="publish_uploaded_files">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" id="passLockerCustomer"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer ID</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" id="passLockerCustomerId"></div>
                        </div>
                        <div class="col-lg-6 mb-3" id="passLockerMobileContainer">
                            <label class="text-black mb-1 fs-6 fw-semibold">Mobile</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" id="passLockerMobile"></div>
                        </div>
                        <div class="col-lg-6 mb-3" id="passLockerEmailContainer">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email</label>
                            <div class="bg-label-info border text-truncate border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" id="passLockerEmail"></div>
                        </div>
                        <div class="col-lg-12 my-4">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px">Sno</th>
                                        <th class="min-w-300px">Journal</th>
                                        <th class="min-w-100px">User Name</th>
                                        <th class="min-w-100px">Password</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7" id="passLockerTable">
                                    <!-- AJAX POPULATED HERE -->
                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-end mt-4">
                            <nav>
                                <ul class="pagination pagination-sm" id="passLockerPagination"></ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Journal Pass Locker-->

    <!--begin::Modal - Task Request-->
    <div class="modal fade" id="kt_modal_task_request" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Task Request</h3>
                    </div>
                    <input type="hidden" id="taskReqJournalId">
                    <div class="row mt-4">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Task Request<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="task_request_id">
                            </select>
                            <div id="task_request_err" class="text-danger mt-2 fs-7 fw-semibold"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <input type="hidden" name="request_files" id="request_files">
                            <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                            <div class="request-upload-container">
                                <div id="requestDropArea" class="request-drop-area">
                                    <div id="requestDropMessage" class="request-drop-message">
                                        <div class="request-upload-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                                stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                                            </svg>
                                        </div>
                                        <div class="request-upload-text">Drag & drop files here or <span
                                                class="request-clickable">click to upload</span></div>
                                        <p class="request-upload-subtext">Supports PDF, DOC, DOCX, JPG, PNG • Max 10MB per
                                            file</p>
                                    </div>
                                    <input type="file" id="requestFileInput" class="request-file-input" multiple />
                                </div>

                                <div class="request-preview-container" id="requestPreviewContainer">
                                    <div class="request-preview-header">
                                        <div class="request-preview-title">
                                            <span>Uploaded Files</span>
                                            <span class="badge" id="requestFileCount">0</span>
                                        </div>
                                        <button type="button" class="request-clear-all-btn"
                                            id="requestClearAllBtn">Clear All</button>
                                    </div>
                                    <div class="request-preview-list" id="requestPreviewList"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="2" placeholder="Enter Description" id="taskRequestDesc"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" id="taskRequestBtn"
                            onclick="taskRequestValidation()">Request Task</a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Task Request-->

    <!-- AI SUGGESTION MODAL STARTS -->
    {{-- <div class="modal fade" id="kt_modal_journal_ai" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-between border-0 pb-0 px-4">
                <h3 class="modal-title text-black">AI ASSISTANT</h3>
                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal"
                    aria-label="Close">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                </button>
            </div>
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!-- Input Section -->
                <div class="mb-4">
                    <label for="journalInput" class="form-label fw-semibold">Enter Journal Paper Name</label>
                    <div class="input-group">
                        <input type="text" id="journalInput" class="form-control"
                            placeholder="Type journal paper name here..." />
                        <button id="searchBtn" class="btn btn-primary">Search</button>
                    </div>
                </div>

                <!-- Results Section -->
                <div id="results" style="display:none;">
                    <div class="mb-3">
                        <h5>Analyzed Journals</h5>
                        <ul id="analyzedList" class="list-group mb-2"></ul>
                        <div id="noAnalyzed" class="text-muted">No analyzed journals found.</div>
                    </div>

                    <div>
                        <h5>Recommended Journals</h5>
                        <ul id="recommendedList" class="list-group mb-2"></ul>
                        <div id="noRecommended" class="text-muted">No recommended journals found.</div>
                    </div>
                </div>

                <!-- Loading Indicator -->
                <div id="loading" style="display:none;" class="text-center py-3">
                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Searching...
                </div>

                <!-- Error Message -->
                <div id="errorMsg" class="text-danger mt-3" style="display:none;"></div>
            </div>
        </div>
    </div>
</div> --}}

    {{-- Toastr Starts --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        .circular-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .circular-badge:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .bg-purple {
            background-color: #800080 !important;
        }

        /* Customize Toastr container */
        .toast {
            background-color: #313f46;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
    {{-- Toastr Ends --}}

    <!-- JOURNAL DATE PICKER -->
    <script>
        $(document).ready(function() {
            var isRtl = false; // Define this as needed
            if ($('.journal_date').length) {
                $('.journal_date').datepicker({
                    todayHighlight: true,
                    autoclose: true,
                    format: 'd-M-yyyy',
                    orientation: isRtl ? 'auto right' : 'auto left'
                });
            }
        });
    </script>

    {{-- Customer Email and Password Add --}}
    <script>
        document.getElementById('jorn_bklt_create_add').addEventListener('click', function() {
            var newBookleteDetails =
                `<div class="row booklet_row">
                    <div class="col-lg-5 mb-1">
                        <label class="text-black mb-1 fs-6 fw-semibold">Username / Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control journal_email" placeholder="Enter Username / Email ID" name="email[]" />
                        <p class="text-danger mt-1 email_error"></p>
                    </div>
                    <div class="col-lg-6 mb-1">
                        <label class="text-black mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                        <input type="text" class="form-control journal_pass" placeholder="Enter Password" name="password[]" />
                        <p class="text-danger mt-1 pass_error"></p>
                    </div>
                    <div class="col-lg-1 mb-1">
                        <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_create_del"
                            id="jorn_bklt_create_del">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
        </div>`;
            document.getElementById('bookletContainer').insertAdjacentHTML('beforeend', newBookleteDetails);
        });

        $(document).on('click', '.jorn_bklt_create_del', function() {
            $(this).closest('.row').remove();
        });
    </script>

    <script>
        function open_func(id) {
            var colse_tr_div = document.getElementById("colse_tr_div" + id);

            if (colse_tr_div.style.display == "none") {
                document.getElementById("colse_tr_div" + id).style.display = "table-row";
                document.getElementById("plus_btn" + id).classList.remove("mdi-plus");
                document.getElementById("plus_btn" + id).classList.add("mdi-minus");
                document.getElementById("main_tr_div" + id).style.backgroundColor = "#f9f3c5db";
            } else {
                document.getElementById("colse_tr_div" + id).style.display = "none";
                document.getElementById("plus_btn" + id).classList.remove("mdi-minus");
                document.getElementById("plus_btn" + id).classList.add("mdi-plus");
                document.getElementById("main_tr_div" + id).removeAttribute("style");
            }
        }
    </script>
    <script>
        $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.filter_tbox').slideToggle('fast');
                // });
            @endif
        });

        // Toggle branch filter section
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>
    <script>
        function date_fill_issue_rpt() {
            var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
            var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
            var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
            var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
            var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
            var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
            var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_issue_rpt == "today") {
                today_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "week") {
                today_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "block";
                week_to_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#week_from_date_fil').val(firstday);
                $('#week_to_date_fil').val(lastday);

            } else if (dt_fill_issue_rpt == "monthly") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "block";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "custom_date") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "block";
                to_dt_iss_rpt.style.display = "block";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            }
        }
    </script>

    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>

    <!-- SUBMIT JOURNAL VALIDATION -->
    <script>
        function addValidation() {
            let isValid = true;

            // Journal Booklet Error
            $('#booklet_error').text('');

            if ($('#journal_booklet_id').val() === '') {
                isValid = false;
                $('#booklet_error').text('Select Atleast One.');
            }


            // Paper Name Error
            $('#paper_name_error').text('');

            if ($('#paper_name').val() === '') {
                isValid = false;
                $('#paper_name_error').text('Enter the Paper Name.');
            }

            // Journal Email and Password Error
            $('.email_error').text('');
            $('.pass_error').text('');

            $('.booklet_row').each(function(index) {
                let emailField = $(this).find('.journal_email');
                let passField = $(this).find('.journal_pass');
                let email = emailField.val().trim();
                let pass = passField.val().trim();

                // Validate Email
                if (email === '') {
                    emailField.next('.email_error').text('Username / Email ID is Required.');
                    isValid = false;
                }

                if (pass === '') {
                    passField.next('.pass_error').text('Password is Required');
                    isValid = false;
                }
            })

            if (!isValid) {
                return false;
            } else {
                submitJournal();
            }

            return true;
        }

        function validateEmail(email) {
            var pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return pattern.test(email);
        }
    </script>

    <style>
        :root {
            --primary-blue: #3b82f6;
            --primary-blue-hover: #2563eb;
            --success-green: #10b981;
            --danger-red: #ef4444;
            --light-gray: #f8fafc;
            --medium-gray: #e2e8f0;
            --dark-gray: #64748b;
            --text-dark: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            --radius-lg: 12px;
            --radius-md: 8px;
            --radius-sm: 6px;
            --transition: all 0.2s ease;
        }

        .upload-container {
            margin-top: 8px;
        }

        .upload-label {
            display: block;
            color: var(--text-dark);
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        .upload-label .optional {
            color: var(--dark-gray);
            font-weight: 400;
            font-size: 13px;
            margin-left: 4px;
        }

        .drop-area {
            border: 2px dashed var(--medium-gray);
            border-radius: var(--radius-lg);
            padding: 48px 32px;
            text-align: center;
            position: relative;
            background-color: var(--light-gray);
            transition: var(--transition);
            cursor: pointer;
            overflow: hidden;
        }

        .drop-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: inherit;
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.05) 0%, rgba(59, 130, 246, 0) 100%);
            opacity: 0;
            transition: var(--transition);
        }

        .drop-area:hover {
            border-color: var(--primary-blue);
            background-color: #f0f9ff;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .drop-area:hover::before {
            opacity: 1;
        }

        .drop-area.drag-over {
            border-color: var(--primary-blue);
            background-color: #e0f2fe;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .drop-area.drag-over::before {
            opacity: 1;
        }

        .drop-message {
            color: var(--dark-gray);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            pointer-events: none;
        }

        .upload-icon {
            margin-bottom: 16px;
            color: var(--dark-gray);
            transition: var(--transition);
        }

        .drop-area:hover .upload-icon {
            color: var(--primary-blue);
            transform: scale(1.05);
        }

        .upload-icon svg {
            width: 48px;
            height: 48px;
            stroke-width: 1.5;
        }

        .upload-text {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .upload-subtext {
            font-size: 14px;
            color: var(--dark-gray);
            margin-bottom: 0;
        }

        .clickable {
            color: var(--primary-blue);
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
        }

        .clickable:hover {
            color: var(--primary-blue-hover);
            text-decoration: underline;
        }

        .file-input {
            display: none;
        }

        .preview-container {
            margin-top: 24px;
        }

        .preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--medium-gray);
        }

        .preview-title {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .preview-title .badge {
            background-color: var(--primary-blue);
            color: white;
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 500;
        }

        .clear-all-btn {
            background: none;
            border: none;
            color: var(--danger-red);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .clear-all-btn:hover {
            background-color: #fee2e2;
        }

        .preview-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 0;
            overflow-y: scroll;
            max-height: 231px;
        }

        .preview-item {
            border: 1px solid var(--medium-gray);
            border-radius: var(--radius-md);
            background: white;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 16px;
            position: relative;
            transition: var(--transition);
            overflow: hidden;
        }

        .preview-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: var(--primary-blue);
        }

        .preview-thumb-container {
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            background-color: #f8fafc;
        }

        .preview-thumb {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .file-icon {
            width: 48px;
            height: 48px;
            color: var(--dark-gray);
        }

        .file-icon svg {
            width: 100%;
            height: 100%;
        }

        .preview-filename {
            font-weight: 500;
            text-align: center;
            margin-bottom: 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            font-size: 14px;
            color: var(--text-dark);
        }

        .preview-size {
            color: var(--dark-gray);
            font-size: 12px;
            margin-bottom: 12px;
        }

        .progress-container {
            width: 100%;
        }

        .progress-bar {
            width: 100%;
            height: 4px;
            background-color: var(--medium-gray);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .progress-bar-inner {
            height: 100%;
            width: 0;
            background: linear-gradient(90deg, var(--primary-blue), #60a5fa);
            transition: width 0.3s ease;
            border-radius: 2px;
        }

        .progress-text {
            font-size: 11px;
            color: var(--dark-gray);
            text-align: center;
            font-weight: 500;
        }

        .remove-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            background: white;
            border: 1px solid var(--medium-gray);
            border-radius: 50%;
            color: var(--dark-gray);
            font-weight: bold;
            width: 28px;
            height: 28px;
            cursor: pointer;
            line-height: 26px;
            text-align: center;
            padding: 0;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.8;
        }

        .remove-btn:hover {
            background-color: var(--danger-red);
            color: white;
            border-color: var(--danger-red);
            opacity: 1;
            transform: scale(1.1);
        }

        .file-status {
            position: absolute;
            top: 8px;
            left: 8px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-uploading {
            background-color: #fef3c7;
            color: #92400e;
        }

        .status-success {
            background-color: #d1fae5;
            color: #065f46;
        }

        .status-error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .file-type-badge {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            font-weight: 500;
        }

        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 48px 32px;
            color: var(--dark-gray);
            background-color: var(--light-gray);
            border-radius: var(--radius-md);
            border: 1px dashed var(--medium-gray);
        }

        .empty-icon {
            font-size: 32px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .empty-text {
            font-size: 14px;
            color: var(--dark-gray);
        }

        @media (max-width: 640px) {
            .drop-area {
                padding: 32px 16px;
            }

            .preview-list {
                grid-template-columns: 1fr;
            }

            .upload-text {
                font-size: 15px;
            }

            .upload-subtext {
                font-size: 13px;
            }
        }

        /* Add to your existing CSS */
        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        @keyframes pulse {
            0% {
                opacity: 0.6;
            }

            50% {
                opacity: 1;
            }

            100% {
                opacity: 0.6;
            }
        }

        .drive-step.active {
            background: #e8f0fe !important;
            border-left-color: #1a73e8 !important;
        }

        .drive-step.active .step-icon {
            background: #1a73e8 !important;
            color: white !important;
        }

        .drive-step.completed {
            background: #e6f4ea !important;
            border-left-color: #34a853 !important;
        }

        .drive-step.completed .step-icon {
            background: #34a853 !important;
            color: white !important;
        }

        .submit-btn.loading {
            position: relative;
            color: transparent !important;
            pointer-events: none;
        }

        .submit-btn.loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20px;
            height: 20px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: button-spin 0.8s linear infinite;
        }

        @keyframes button-spin {
            to {
                transform: translate(-50%, -50%) rotate(360deg);
            }
        }

        /* With Editor DropZone */

        .with-editor-upload-container {
            margin-top: 8px;
        }

        .with-editor-drop-area {
            border: 2px dashed var(--medium-gray);
            border-radius: var(--radius-lg);
            padding: 48px 32px;
            text-align: center;
            position: relative;
            background-color: var(--light-gray);
            transition: var(--transition);
            cursor: pointer;
            overflow: hidden;
        }

        .with-editor-drop-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: inherit;
            background: linear-gradient(135deg, rgba(147, 51, 234, 0.05) 0%, rgba(147, 51, 234, 0) 100%);
            opacity: 0;
            transition: var(--transition);
        }

        .with-editor-drop-area:hover {
            border-color: #8b5cf6;
            background-color: #faf5ff;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .with-editor-drop-area:hover::before {
            opacity: 1;
        }

        .with-editor-drop-area.drag-over {
            border-color: #8b5cf6;
            background-color: #f3e8ff;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .with-editor-drop-area.drag-over::before {
            opacity: 1;
        }

        .with-editor-drop-message {
            color: var(--dark-gray);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            pointer-events: none;
        }

        .with-editor-upload-icon {
            margin-bottom: 16px;
            color: var(--dark-gray);
            transition: var(--transition);
        }

        .with-editor-drop-area:hover .with-editor-upload-icon {
            color: #8b5cf6;
            transform: scale(1.05);
        }

        .with-editor-upload-icon svg {
            width: 48px;
            height: 48px;
            stroke-width: 1.5;
        }

        .with-editor-upload-text {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .with-editor-upload-subtext {
            font-size: 14px;
            color: var(--dark-gray);
            margin-bottom: 0;
        }

        .with-editor-clickable {
            color: #8b5cf6;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
        }

        .with-editor-clickable:hover {
            color: #7c3aed;
            text-decoration: underline;
        }

        .with-editor-file-input {
            display: none;
        }

        .with-editor-preview-container {
            margin-top: 24px;
            display: none;
        }

        .with-editor-preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--medium-gray);
        }

        .with-editor-preview-title {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .with-editor-preview-title .badge {
            background-color: #8b5cf6;
            color: white;
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 500;
        }

        .with-editor-clear-all-btn {
            background: none;
            border: none;
            color: var(--danger-red);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .with-editor-clear-all-btn:hover {
            background-color: #fee2e2;
        }

        .with-editor-preview-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 0;
            overflow-y: scroll;
            max-height: 231px;
        }

        .with-editor-preview-item {
            border: 1px solid var(--medium-gray);
            border-radius: var(--radius-md);
            background: white;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 16px;
            position: relative;
            transition: var(--transition);
            overflow: hidden;
        }

        .with-editor-preview-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: #8b5cf6;
        }

        .with-editor-preview-thumb-container {
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            background-color: #f8fafc;
        }

        .with-editor-preview-thumb {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .with-editor-file-icon {
            width: 48px;
            height: 48px;
            color: var(--dark-gray);
        }

        .with-editor-file-icon svg {
            width: 100%;
            height: 100%;
        }

        .with-editor-preview-filename {
            font-weight: 500;
            text-align: center;
            margin-bottom: 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            font-size: 14px;
            color: var(--text-dark);
        }

        .with-editor-preview-size {
            color: var(--dark-gray);
            font-size: 12px;
            margin-bottom: 12px;
        }

        .with-editor-progress-container {
            width: 100%;
        }

        .with-editor-progress-bar {
            width: 100%;
            height: 4px;
            background-color: var(--medium-gray);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .with-editor-progress-bar-inner {
            height: 100%;
            width: 0;
            background: linear-gradient(90deg, #8b5cf6, #a78bfa);
            transition: width 0.3s ease;
            border-radius: 2px;
        }

        .with-editor-progress-text {
            font-size: 11px;
            color: var(--dark-gray);
            text-align: center;
            font-weight: 500;
        }

        .with-editor-remove-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            background: white;
            border: 1px solid var(--medium-gray);
            border-radius: 50%;
            color: var(--dark-gray);
            font-weight: bold;
            width: 28px;
            height: 28px;
            cursor: pointer;
            line-height: 26px;
            text-align: center;
            padding: 0;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.8;
        }

        .with-editor-remove-btn:hover {
            background-color: var(--danger-red);
            color: white;
            border-color: var(--danger-red);
            opacity: 1;
            transform: scale(1.1);
        }

        .with-editor-file-status {
            position: absolute;
            top: 8px;
            left: 8px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .with-editor-status-uploading {
            background-color: #fef3c7;
            color: #92400e;
        }

        .with-editor-status-success {
            background-color: #d1fae5;
            color: #065f46;
        }

        .with-editor-status-error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .with-editor-file-type-badge {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            font-weight: 500;
        }

        .with-editor-empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 48px 32px;
            color: var(--dark-gray);
            background-color: var(--light-gray);
            border-radius: var(--radius-md);
            border: 1px dashed var(--medium-gray);
        }

        .with-editor-empty-icon {
            font-size: 32px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .with-editor-empty-text {
            font-size: 14px;
            color: var(--dark-gray);
        }

        /* Purple theme for With Editor status */
        .with-editor-theme {
            --primary-color: #8b5cf6;
            --primary-hover: #7c3aed;
            --primary-light: #faf5ff;
            --primary-bg: rgba(139, 92, 246, 0.05);
        }

        @media (max-width: 640px) {
            .with-editor-drop-area {
                padding: 32px 16px;
            }

            .with-editor-preview-list {
                grid-template-columns: 1fr;
            }

            .with-editor-upload-text {
                font-size: 15px;
            }

            .with-editor-upload-subtext {
                font-size: 13px;
            }
        }

        /* Under Reviewer Status */

        .under-reviewer-upload-container {
            margin-top: 8px;
        }

        .under-reviewer-drop-area {
            border: 2px dashed var(--medium-gray);
            border-radius: var(--radius-lg);
            padding: 48px 32px;
            text-align: center;
            position: relative;
            background-color: var(--light-gray);
            transition: var(--transition);
            cursor: pointer;
            overflow: hidden;
        }

        .under-reviewer-drop-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: inherit;
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.05) 0%, rgba(245, 158, 11, 0) 100%);
            opacity: 0;
            transition: var(--transition);
        }

        .under-reviewer-drop-area:hover {
            border-color: #f59e0b;
            background-color: #fffbeb;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .under-reviewer-drop-area:hover::before {
            opacity: 1;
        }

        .under-reviewer-drop-area.drag-over {
            border-color: #f59e0b;
            background-color: #fef3c7;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .under-reviewer-drop-area.drag-over::before {
            opacity: 1;
        }

        .under-reviewer-drop-message {
            color: var(--dark-gray);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            pointer-events: none;
        }

        .under-reviewer-upload-icon {
            margin-bottom: 16px;
            color: var(--dark-gray);
            transition: var(--transition);
        }

        .under-reviewer-drop-area:hover .under-reviewer-upload-icon {
            color: #f59e0b;
            transform: scale(1.05);
        }

        .under-reviewer-upload-icon svg {
            width: 48px;
            height: 48px;
            stroke-width: 1.5;
        }

        .under-reviewer-upload-text {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .under-reviewer-upload-subtext {
            font-size: 14px;
            color: var(--dark-gray);
            margin-bottom: 0;
        }

        .under-reviewer-clickable {
            color: #f59e0b;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
        }

        .under-reviewer-clickable:hover {
            color: #d97706;
            text-decoration: underline;
        }

        .under-reviewer-file-input {
            display: none;
        }

        .under-reviewer-preview-container {
            margin-top: 24px;
            display: none;
        }

        .under-reviewer-preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--medium-gray);
        }

        .under-reviewer-preview-title {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .under-reviewer-preview-title .badge {
            background-color: #f59e0b;
            color: white;
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 500;
        }

        .under-reviewer-clear-all-btn {
            background: none;
            border: none;
            color: var(--danger-red);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .under-reviewer-clear-all-btn:hover {
            background-color: #fee2e2;
        }

        .under-reviewer-preview-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 0;
            overflow-y: scroll;
            max-height: 231px;
        }

        .under-reviewer-preview-item {
            border: 1px solid var(--medium-gray);
            border-radius: var(--radius-md);
            background: white;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 16px;
            position: relative;
            transition: var(--transition);
            overflow: hidden;
        }

        .under-reviewer-preview-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: #f59e0b;
        }

        .under-reviewer-preview-thumb-container {
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            background-color: #f8fafc;
        }

        .under-reviewer-preview-thumb {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .under-reviewer-file-icon {
            width: 48px;
            height: 48px;
            color: var(--dark-gray);
        }

        .under-reviewer-file-icon svg {
            width: 100%;
            height: 100%;
        }

        .under-reviewer-preview-filename {
            font-weight: 500;
            text-align: center;
            margin-bottom: 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            font-size: 14px;
            color: var(--text-dark);
        }

        .under-reviewer-preview-size {
            color: var(--dark-gray);
            font-size: 12px;
            margin-bottom: 12px;
        }

        .under-reviewer-progress-container {
            width: 100%;
        }

        .under-reviewer-progress-bar {
            width: 100%;
            height: 4px;
            background-color: var(--medium-gray);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .under-reviewer-progress-bar-inner {
            height: 100%;
            width: 0;
            background: linear-gradient(90deg, #f59e0b, #fbbf24);
            transition: width 0.3s ease;
            border-radius: 2px;
        }

        .under-reviewer-progress-text {
            font-size: 11px;
            color: var(--dark-gray);
            text-align: center;
            font-weight: 500;
        }

        .under-reviewer-remove-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            background: white;
            border: 1px solid var(--medium-gray);
            border-radius: 50%;
            color: var(--dark-gray);
            font-weight: bold;
            width: 28px;
            height: 28px;
            cursor: pointer;
            line-height: 26px;
            text-align: center;
            padding: 0;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.8;
        }

        .under-reviewer-remove-btn:hover {
            background-color: var(--danger-red);
            color: white;
            border-color: var(--danger-red);
            opacity: 1;
            transform: scale(1.1);
        }

        .under-reviewer-file-status {
            position: absolute;
            top: 8px;
            left: 8px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .under-reviewer-status-uploading {
            background-color: #fef3c7;
            color: #92400e;
        }

        .under-reviewer-status-success {
            background-color: #d1fae5;
            color: #065f46;
        }

        .under-reviewer-status-error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .under-reviewer-file-type-badge {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            font-weight: 500;
        }

        .under-reviewer-empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 48px 32px;
            color: var(--dark-gray);
            background-color: var(--light-gray);
            border-radius: var(--radius-md);
            border: 1px dashed var(--medium-gray);
        }

        .under-reviewer-empty-icon {
            font-size: 32px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .under-reviewer-empty-text {
            font-size: 14px;
            color: var(--dark-gray);
        }

        /* Amber/Orange theme for Under Reviewer status */
        .under-reviewer-theme {
            --primary-color: #f59e0b;
            --primary-hover: #d97706;
            --primary-light: #fffbeb;
            --primary-bg: rgba(245, 158, 11, 0.05);
        }

        @media (max-width: 640px) {
            .under-reviewer-drop-area {
                padding: 32px 16px;
            }

            .under-reviewer-preview-list {
                grid-template-columns: 1fr;
            }

            .under-reviewer-upload-text {
                font-size: 15px;
            }

            .under-reviewer-upload-subtext {
                font-size: 13px;
            }
        }

        /* Revision Dropzone */

        .review-upload-container {
            margin-top: 8px;
        }

        .review-drop-area {
            border: 2px dashed var(--medium-gray);
            border-radius: var(--radius-lg);
            padding: 48px 32px;
            text-align: center;
            position: relative;
            background-color: var(--light-gray);
            transition: var(--transition);
            cursor: pointer;
            overflow: hidden;
        }

        .review-drop-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: inherit;
            background: linear-gradient(135deg, rgba(14, 165, 233, 0.05) 0%, rgba(14, 165, 233, 0) 100%);
            opacity: 0;
            transition: var(--transition);
        }

        .review-drop-area:hover {
            border-color: #0ea5e9;
            background-color: #f0f9ff;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .review-drop-area:hover::before {
            opacity: 1;
        }

        .review-drop-area.drag-over {
            border-color: #0ea5e9;
            background-color: #e0f2fe;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .review-drop-area.drag-over::before {
            opacity: 1;
        }

        .review-drop-message {
            color: var(--dark-gray);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            pointer-events: none;
        }

        .review-upload-icon {
            margin-bottom: 16px;
            color: var(--dark-gray);
            transition: var(--transition);
        }

        .review-drop-area:hover .review-upload-icon {
            color: #0ea5e9;
            transform: scale(1.05);
        }

        .review-upload-icon svg {
            width: 48px;
            height: 48px;
            stroke-width: 1.5;
        }

        .review-upload-text {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .review-upload-subtext {
            font-size: 14px;
            color: var(--dark-gray);
            margin-bottom: 0;
        }

        .review-clickable {
            color: #0ea5e9;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
        }

        .review-clickable:hover {
            color: #0284c7;
            text-decoration: underline;
        }

        .review-file-input {
            display: none;
        }

        .review-preview-container {
            margin-top: 24px;
            display: none;
        }

        .review-preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--medium-gray);
        }

        .review-preview-title {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .review-preview-title .badge {
            background-color: #0ea5e9;
            color: white;
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 500;
        }

        .review-clear-all-btn {
            background: none;
            border: none;
            color: var(--danger-red);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .review-clear-all-btn:hover {
            background-color: #fee2e2;
        }

        .review-preview-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 0;
            overflow-y: scroll;
            max-height: 231px;
        }

        .review-preview-item {
            border: 1px solid var(--medium-gray);
            border-radius: var(--radius-md);
            background: white;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 16px;
            position: relative;
            transition: var(--transition);
            overflow: hidden;
        }

        .review-preview-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: #0ea5e9;
        }

        .review-preview-thumb-container {
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            background-color: #f8fafc;
        }

        .review-preview-thumb {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .review-file-icon {
            width: 48px;
            height: 48px;
            color: var(--dark-gray);
        }

        .review-file-icon svg {
            width: 100%;
            height: 100%;
        }

        .review-preview-filename {
            font-weight: 500;
            text-align: center;
            margin-bottom: 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            font-size: 14px;
            color: var(--text-dark);
        }

        .review-preview-size {
            color: var(--dark-gray);
            font-size: 12px;
            margin-bottom: 12px;
        }

        .review-progress-container {
            width: 100%;
        }

        .review-progress-bar {
            width: 100%;
            height: 4px;
            background-color: var(--medium-gray);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .review-progress-bar-inner {
            height: 100%;
            width: 0;
            background: linear-gradient(90deg, #0ea5e9, #38bdf8);
            transition: width 0.3s ease;
            border-radius: 2px;
        }

        .review-progress-text {
            font-size: 11px;
            color: var(--dark-gray);
            text-align: center;
            font-weight: 500;
        }

        .review-remove-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            background: white;
            border: 1px solid var(--medium-gray);
            border-radius: 50%;
            color: var(--dark-gray);
            font-weight: bold;
            width: 28px;
            height: 28px;
            cursor: pointer;
            line-height: 26px;
            text-align: center;
            padding: 0;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.8;
        }

        .review-remove-btn:hover {
            background-color: var(--danger-red);
            color: white;
            border-color: var(--danger-red);
            opacity: 1;
            transform: scale(1.1);
        }

        .review-file-status {
            position: absolute;
            top: 8px;
            left: 8px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .review-status-uploading {
            background-color: #fef3c7;
            color: #92400e;
        }

        .review-status-success {
            background-color: #d1fae5;
            color: #065f46;
        }

        .review-status-error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .review-file-type-badge {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            font-weight: 500;
        }

        .review-empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 48px 32px;
            color: var(--dark-gray);
            background-color: var(--light-gray);
            border-radius: var(--radius-md);
            border: 1px dashed var(--medium-gray);
        }

        .review-empty-icon {
            font-size: 32px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .review-empty-text {
            font-size: 14px;
            color: var(--dark-gray);
        }

        /* Sky Blue theme for Review status */
        .review-theme {
            --primary-color: #0ea5e9;
            --primary-hover: #0284c7;
            --primary-light: #f0f9ff;
            --primary-bg: rgba(14, 165, 233, 0.05);
        }

        @media (max-width: 640px) {
            .review-drop-area {
                padding: 32px 16px;
            }

            .review-preview-list {
                grid-template-columns: 1fr;
            }

            .review-upload-text {
                font-size: 15px;
            }

            .review-upload-subtext {
                font-size: 13px;
            }
        }

        /* Accepted Status */

        .accepted-upload-container {
            margin-top: 8px;
        }

        .accepted-drop-area {
            border: 2px dashed var(--medium-gray);
            border-radius: var(--radius-lg);
            padding: 48px 32px;
            text-align: center;
            position: relative;
            background-color: var(--light-gray);
            transition: var(--transition);
            cursor: pointer;
            overflow: hidden;
        }

        .accepted-drop-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: inherit;
            background: linear-gradient(135deg, rgba(34, 197, 94, 0.05) 0%, rgba(34, 197, 94, 0) 100%);
            opacity: 0;
            transition: var(--transition);
        }

        .accepted-drop-area:hover {
            border-color: #22c55e;
            background-color: #f0fdf4;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .accepted-drop-area:hover::before {
            opacity: 1;
        }

        .accepted-drop-area.drag-over {
            border-color: #22c55e;
            background-color: #dcfce7;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .accepted-drop-area.drag-over::before {
            opacity: 1;
        }

        .accepted-drop-message {
            color: var(--dark-gray);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            pointer-events: none;
        }

        .accepted-upload-icon {
            margin-bottom: 16px;
            color: var(--dark-gray);
            transition: var(--transition);
        }

        .accepted-drop-area:hover .accepted-upload-icon {
            color: #22c55e;
            transform: scale(1.05);
        }

        .accepted-upload-icon svg {
            width: 48px;
            height: 48px;
            stroke-width: 1.5;
        }

        .accepted-upload-text {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .accepted-upload-subtext {
            font-size: 14px;
            color: var(--dark-gray);
            margin-bottom: 0;
        }

        .accepted-clickable {
            color: #22c55e;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
        }

        .accepted-clickable:hover {
            color: #16a34a;
            text-decoration: underline;
        }

        .accepted-file-input {
            display: none;
        }

        .accepted-preview-container {
            margin-top: 24px;
            display: none;
        }

        .accepted-preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--medium-gray);
        }

        .accepted-preview-title {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .accepted-preview-title .badge {
            background-color: #22c55e;
            color: white;
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 500;
        }

        .accepted-clear-all-btn {
            background: none;
            border: none;
            color: var(--danger-red);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .accepted-clear-all-btn:hover {
            background-color: #fee2e2;
        }

        .accepted-preview-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 0;
            overflow-y: scroll;
            max-height: 231px;
        }

        .accepted-preview-item {
            border: 1px solid var(--medium-gray);
            border-radius: var(--radius-md);
            background: white;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 16px;
            position: relative;
            transition: var(--transition);
            overflow: hidden;
        }

        .accepted-preview-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: #22c55e;
        }

        .accepted-preview-thumb-container {
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            background-color: #f8fafc;
        }

        .accepted-preview-thumb {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .accepted-file-icon {
            width: 48px;
            height: 48px;
            color: var(--dark-gray);
        }

        .accepted-file-icon svg {
            width: 100%;
            height: 100%;
        }

        .accepted-preview-filename {
            font-weight: 500;
            text-align: center;
            margin-bottom: 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            font-size: 14px;
            color: var(--text-dark);
        }

        .accepted-preview-size {
            color: var(--dark-gray);
            font-size: 12px;
            margin-bottom: 12px;
        }

        .accepted-progress-container {
            width: 100%;
        }

        .accepted-progress-bar {
            width: 100%;
            height: 4px;
            background-color: var(--medium-gray);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .accepted-progress-bar-inner {
            height: 100%;
            width: 0;
            background: linear-gradient(90deg, #22c55e, #4ade80);
            transition: width 0.3s ease;
            border-radius: 2px;
        }

        .accepted-progress-text {
            font-size: 11px;
            color: var(--dark-gray);
            text-align: center;
            font-weight: 500;
        }

        .accepted-remove-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            background: white;
            border: 1px solid var(--medium-gray);
            border-radius: 50%;
            color: var(--dark-gray);
            font-weight: bold;
            width: 28px;
            height: 28px;
            cursor: pointer;
            line-height: 26px;
            text-align: center;
            padding: 0;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.8;
        }

        .accepted-remove-btn:hover {
            background-color: var(--danger-red);
            color: white;
            border-color: var(--danger-red);
            opacity: 1;
            transform: scale(1.1);
        }

        .accepted-file-status {
            position: absolute;
            top: 8px;
            left: 8px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .accepted-status-uploading {
            background-color: #fef3c7;
            color: #92400e;
        }

        .accepted-status-success {
            background-color: #d1fae5;
            color: #065f46;
        }

        .accepted-status-error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .accepted-file-type-badge {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            font-weight: 500;
        }

        .accepted-empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 48px 32px;
            color: var(--dark-gray);
            background-color: var(--light-gray);
            border-radius: var(--radius-md);
            border: 1px dashed var(--medium-gray);
        }

        .accepted-empty-icon {
            font-size: 32px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .accepted-empty-text {
            font-size: 14px;
            color: var(--dark-gray);
        }

        /* Green theme for Accepted status */
        .accepted-theme {
            --primary-color: #22c55e;
            --primary-hover: #16a34a;
            --primary-light: #f0fdf4;
            --primary-bg: rgba(34, 197, 94, 0.05);
        }

        @media (max-width: 640px) {
            .accepted-drop-area {
                padding: 32px 16px;
            }

            .accepted-preview-list {
                grid-template-columns: 1fr;
            }

            .accepted-upload-text {
                font-size: 15px;
            }

            .accepted-upload-subtext {
                font-size: 13px;
            }
        }

        /* E-Proofing Status */

        .e-proofing-upload-container {
            margin-top: 8px;
        }

        .e-proofing-drop-area {
            border: 2px dashed var(--medium-gray);
            border-radius: var(--radius-lg);
            padding: 48px 32px;
            text-align: center;
            position: relative;
            background-color: var(--light-gray);
            transition: var(--transition);
            cursor: pointer;
            overflow: hidden;
        }

        .e-proofing-drop-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: inherit;
            background: linear-gradient(135deg, rgba(6, 182, 212, 0.05) 0%, rgba(6, 182, 212, 0) 100%);
            opacity: 0;
            transition: var(--transition);
        }

        .e-proofing-drop-area:hover {
            border-color: #06b6d4;
            background-color: #ecfeff;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .e-proofing-drop-area:hover::before {
            opacity: 1;
        }

        .e-proofing-drop-area.drag-over {
            border-color: #06b6d4;
            background-color: #cffafe;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .e-proofing-drop-area.drag-over::before {
            opacity: 1;
        }

        .e-proofing-drop-message {
            color: var(--dark-gray);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            pointer-events: none;
        }

        .e-proofing-upload-icon {
            margin-bottom: 16px;
            color: var(--dark-gray);
            transition: var(--transition);
        }

        .e-proofing-drop-area:hover .e-proofing-upload-icon {
            color: #06b6d4;
            transform: scale(1.05);
        }

        .e-proofing-upload-icon svg {
            width: 48px;
            height: 48px;
            stroke-width: 1.5;
        }

        .e-proofing-upload-text {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .e-proofing-upload-subtext {
            font-size: 14px;
            color: var(--dark-gray);
            margin-bottom: 0;
        }

        .e-proofing-clickable {
            color: #06b6d4;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
        }

        .e-proofing-clickable:hover {
            color: #0891b2;
            text-decoration: underline;
        }

        .e-proofing-file-input {
            display: none;
        }

        .e-proofing-preview-container {
            margin-top: 24px;
            display: none;
        }

        .e-proofing-preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--medium-gray);
        }

        .e-proofing-preview-title {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .e-proofing-preview-title .badge {
            background-color: #06b6d4;
            color: white;
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 500;
        }

        .e-proofing-clear-all-btn {
            background: none;
            border: none;
            color: var(--danger-red);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .e-proofing-clear-all-btn:hover {
            background-color: #fee2e2;
        }

        .e-proofing-preview-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 0;
            overflow-y: scroll;
            max-height: 231px;
        }

        .e-proofing-preview-item {
            border: 1px solid var(--medium-gray);
            border-radius: var(--radius-md);
            background: white;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 16px;
            position: relative;
            transition: var(--transition);
            overflow: hidden;
        }

        .e-proofing-preview-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: #06b6d4;
        }

        .e-proofing-preview-thumb-container {
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            background-color: #f8fafc;
        }

        .e-proofing-preview-thumb {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .e-proofing-file-icon {
            width: 48px;
            height: 48px;
            color: var(--dark-gray);
        }

        .e-proofing-file-icon svg {
            width: 100%;
            height: 100%;
        }

        .e-proofing-preview-filename {
            font-weight: 500;
            text-align: center;
            margin-bottom: 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            font-size: 14px;
            color: var(--text-dark);
        }

        .e-proofing-preview-size {
            color: var(--dark-gray);
            font-size: 12px;
            margin-bottom: 12px;
        }

        .e-proofing-progress-container {
            width: 100%;
        }

        .e-proofing-progress-bar {
            width: 100%;
            height: 4px;
            background-color: var(--medium-gray);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .e-proofing-progress-bar-inner {
            height: 100%;
            width: 0;
            background: linear-gradient(90deg, #06b6d4, #22d3ee);
            transition: width 0.3s ease;
            border-radius: 2px;
        }

        .e-proofing-progress-text {
            font-size: 11px;
            color: var(--dark-gray);
            text-align: center;
            font-weight: 500;
        }

        .e-proofing-remove-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            background: white;
            border: 1px solid var(--medium-gray);
            border-radius: 50%;
            color: var(--dark-gray);
            font-weight: bold;
            width: 28px;
            height: 28px;
            cursor: pointer;
            line-height: 26px;
            text-align: center;
            padding: 0;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.8;
        }

        .e-proofing-remove-btn:hover {
            background-color: var(--danger-red);
            color: white;
            border-color: var(--danger-red);
            opacity: 1;
            transform: scale(1.1);
        }

        .e-proofing-file-status {
            position: absolute;
            top: 8px;
            left: 8px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .e-proofing-status-uploading {
            background-color: #fef3c7;
            color: #92400e;
        }

        .e-proofing-status-success {
            background-color: #d1fae5;
            color: #065f46;
        }

        .e-proofing-status-error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .e-proofing-file-type-badge {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            font-weight: 500;
        }

        .e-proofing-empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 48px 32px;
            color: var(--dark-gray);
            background-color: var(--light-gray);
            border-radius: var(--radius-md);
            border: 1px dashed var(--medium-gray);
        }

        .e-proofing-empty-icon {
            font-size: 32px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .e-proofing-empty-text {
            font-size: 14px;
            color: var(--dark-gray);
        }

        /* Cyan theme for E-Proofing status */
        .e-proofing-theme {
            --primary-color: #06b6d4;
            --primary-hover: #0891b2;
            --primary-light: #ecfeff;
            --primary-bg: rgba(6, 182, 212, 0.05);
        }

        @media (max-width: 640px) {
            .e-proofing-drop-area {
                padding: 32px 16px;
            }

            .e-proofing-preview-list {
                grid-template-columns: 1fr;
            }

            .e-proofing-upload-text {
                font-size: 15px;
            }

            .e-proofing-upload-subtext {
                font-size: 13px;
            }
        }

        /* Rejected Status */

        .rejected-upload-container {
            margin-top: 8px;
        }

        .rejected-drop-area {
            border: 2px dashed var(--medium-gray);
            border-radius: var(--radius-lg);
            padding: 48px 32px;
            text-align: center;
            position: relative;
            background-color: var(--light-gray);
            transition: var(--transition);
            cursor: pointer;
            overflow: hidden;
        }

        .rejected-drop-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: inherit;
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.05) 0%, rgba(239, 68, 68, 0) 100%);
            opacity: 0;
            transition: var(--transition);
        }

        .rejected-drop-area:hover {
            border-color: #ef4444;
            background-color: #fef2f2;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .rejected-drop-area:hover::before {
            opacity: 1;
        }

        .rejected-drop-area.drag-over {
            border-color: #ef4444;
            background-color: #fee2e2;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .rejected-drop-area.drag-over::before {
            opacity: 1;
        }

        .rejected-drop-message {
            color: var(--dark-gray);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            pointer-events: none;
        }

        .rejected-upload-icon {
            margin-bottom: 16px;
            color: var(--dark-gray);
            transition: var(--transition);
        }

        .rejected-drop-area:hover .rejected-upload-icon {
            color: #ef4444;
            transform: scale(1.05);
        }

        .rejected-upload-icon svg {
            width: 48px;
            height: 48px;
            stroke-width: 1.5;
        }

        .rejected-upload-text {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .rejected-upload-subtext {
            font-size: 14px;
            color: var(--dark-gray);
            margin-bottom: 0;
        }

        .rejected-clickable {
            color: #ef4444;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
        }

        .rejected-clickable:hover {
            color: #dc2626;
            text-decoration: underline;
        }

        .rejected-file-input {
            display: none;
        }

        .rejected-preview-container {
            margin-top: 24px;
            display: none;
        }

        .rejected-preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--medium-gray);
        }

        .rejected-preview-title {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .rejected-preview-title .badge {
            background-color: #ef4444;
            color: white;
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 500;
        }

        .rejected-clear-all-btn {
            background: none;
            border: none;
            color: var(--danger-red);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .rejected-clear-all-btn:hover {
            background-color: #fee2e2;
        }

        .rejected-preview-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 0;
            overflow-y: scroll;
            max-height: 231px;
        }

        .rejected-preview-item {
            border: 1px solid var(--medium-gray);
            border-radius: var(--radius-md);
            background: white;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 16px;
            position: relative;
            transition: var(--transition);
            overflow: hidden;
        }

        .rejected-preview-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: #ef4444;
        }

        .rejected-preview-thumb-container {
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            background-color: #f8fafc;
        }

        .rejected-preview-thumb {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .rejected-file-icon {
            width: 48px;
            height: 48px;
            color: var(--dark-gray);
        }

        .rejected-file-icon svg {
            width: 100%;
            height: 100%;
        }

        .rejected-preview-filename {
            font-weight: 500;
            text-align: center;
            margin-bottom: 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            font-size: 14px;
            color: var(--text-dark);
        }

        .rejected-preview-size {
            color: var(--dark-gray);
            font-size: 12px;
            margin-bottom: 12px;
        }

        .rejected-progress-container {
            width: 100%;
        }

        .rejected-progress-bar {
            width: 100%;
            height: 4px;
            background-color: var(--medium-gray);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .rejected-progress-bar-inner {
            height: 100%;
            width: 0;
            background: linear-gradient(90deg, #ef4444, #f87171);
            transition: width 0.3s ease;
            border-radius: 2px;
        }

        .rejected-progress-text {
            font-size: 11px;
            color: var(--dark-gray);
            text-align: center;
            font-weight: 500;
        }

        .rejected-remove-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            background: white;
            border: 1px solid var(--medium-gray);
            border-radius: 50%;
            color: var(--dark-gray);
            font-weight: bold;
            width: 28px;
            height: 28px;
            cursor: pointer;
            line-height: 26px;
            text-align: center;
            padding: 0;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.8;
        }

        .rejected-remove-btn:hover {
            background-color: var(--danger-red);
            color: white;
            border-color: var(--danger-red);
            opacity: 1;
            transform: scale(1.1);
        }

        .rejected-file-status {
            position: absolute;
            top: 8px;
            left: 8px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .rejected-status-uploading {
            background-color: #fef3c7;
            color: #92400e;
        }

        .rejected-status-success {
            background-color: #d1fae5;
            color: #065f46;
        }

        .rejected-status-error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .rejected-file-type-badge {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            font-weight: 500;
        }

        .rejected-empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 48px 32px;
            color: var(--dark-gray);
            background-color: var(--light-gray);
            border-radius: var(--radius-md);
            border: 1px dashed var(--medium-gray);
        }

        .rejected-empty-icon {
            font-size: 32px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .rejected-empty-text {
            font-size: 14px;
            color: var(--dark-gray);
        }

        /* Red theme for Rejected status */
        .rejected-theme {
            --primary-color: #ef4444;
            --primary-hover: #dc2626;
            --primary-light: #fef2f2;
            --primary-bg: rgba(239, 68, 68, 0.05);
        }

        @media (max-width: 640px) {
            .rejected-drop-area {
                padding: 32px 16px;
            }

            .rejected-preview-list {
                grid-template-columns: 1fr;
            }

            .rejected-upload-text {
                font-size: 15px;
            }

            .rejected-upload-subtext {
                font-size: 13px;
            }

        }

        /* request Status */

        .request-upload-container {
            margin-top: 8px;
        }

        .request-drop-area {
            border: 2px dashed var(--medium-gray);
            border-radius: var(--radius-lg);
            padding: 48px 32px;
            text-align: center;
            position: relative;
            background-color: var(--light-gray);
            transition: var(--transition);
            cursor: pointer;
            overflow: hidden;
        }

        .request-drop-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: inherit;
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.05) 0%, rgba(239, 68, 68, 0) 100%);
            opacity: 0;
            transition: var(--transition);
        }

        .request-drop-area:hover {
            border-color: #ef4444;
            background-color: #fef2f2;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .request-drop-area:hover::before {
            opacity: 1;
        }

        .request-drop-area.drag-over {
            border-color: #ef4444;
            background-color: #fee2e2;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .request-drop-area.drag-over::before {
            opacity: 1;
        }

        .request-drop-message {
            color: var(--dark-gray);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            pointer-events: none;
        }

        .request-upload-icon {
            margin-bottom: 16px;
            color: var(--dark-gray);
            transition: var(--transition);
        }

        .request-drop-area:hover .request-upload-icon {
            color: #ef4444;
            transform: scale(1.05);
        }

        .request-upload-icon svg {
            width: 48px;
            height: 48px;
            stroke-width: 1.5;
        }

        .request-upload-text {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .request-upload-subtext {
            font-size: 14px;
            color: var(--dark-gray);
            margin-bottom: 0;
        }

        .request-clickable {
            color: #ef4444;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
        }

        .request-clickable:hover {
            color: #dc2626;
            text-decoration: underline;
        }

        .request-file-input {
            display: none;
        }

        .request-preview-container {
            margin-top: 24px;
            display: none;
        }

        .request-preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--medium-gray);
        }

        .request-preview-title {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .request-preview-title .badge {
            background-color: #ef4444;
            color: white;
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 500;
        }

        .request-clear-all-btn {
            background: none;
            border: none;
            color: var(--danger-red);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .request-clear-all-btn:hover {
            background-color: #fee2e2;
        }

        .request-preview-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 0;
            overflow-y: scroll;
            max-height: 231px;
        }

        .request-preview-item {
            border: 1px solid var(--medium-gray);
            border-radius: var(--radius-md);
            background: white;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 16px;
            position: relative;
            transition: var(--transition);
            overflow: hidden;
        }

        .request-preview-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: #ef4444;
        }

        .request-preview-thumb-container {
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            background-color: #f8fafc;
        }

        .request-preview-thumb {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .request-file-icon {
            width: 48px;
            height: 48px;
            color: var(--dark-gray);
        }

        .request-file-icon svg {
            width: 100%;
            height: 100%;
        }

        .request-preview-filename {
            font-weight: 500;
            text-align: center;
            margin-bottom: 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            font-size: 14px;
            color: var(--text-dark);
        }

        .request-preview-size {
            color: var(--dark-gray);
            font-size: 12px;
            margin-bottom: 12px;
        }

        .request-progress-container {
            width: 100%;
        }

        .request-progress-bar {
            width: 100%;
            height: 4px;
            background-color: var(--medium-gray);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .request-progress-bar-inner {
            height: 100%;
            width: 0;
            background: linear-gradient(90deg, #ef4444, #f87171);
            transition: width 0.3s ease;
            border-radius: 2px;
        }

        .request-progress-text {
            font-size: 11px;
            color: var(--dark-gray);
            text-align: center;
            font-weight: 500;
        }

        .request-remove-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            background: white;
            border: 1px solid var(--medium-gray);
            border-radius: 50%;
            color: var(--dark-gray);
            font-weight: bold;
            width: 28px;
            height: 28px;
            cursor: pointer;
            line-height: 26px;
            text-align: center;
            padding: 0;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.8;
        }

        .request-remove-btn:hover {
            background-color: var(--danger-red);
            color: white;
            border-color: var(--danger-red);
            opacity: 1;
            transform: scale(1.1);
        }

        .request-file-status {
            position: absolute;
            top: 8px;
            left: 8px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .request-status-uploading {
            background-color: #fef3c7;
            color: #92400e;
        }

        .request-status-success {
            background-color: #d1fae5;
            color: #065f46;
        }

        .request-status-error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .request-file-type-badge {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            font-weight: 500;
        }

        .request-empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 48px 32px;
            color: var(--dark-gray);
            background-color: var(--light-gray);
            border-radius: var(--radius-md);
            border: 1px dashed var(--medium-gray);
        }

        .request-empty-icon {
            font-size: 32px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .request-empty-text {
            font-size: 14px;
            color: var(--dark-gray);
        }

        /* Red theme for request status */
        .request-theme {
            --primary-color: #ef4444;
            --primary-hover: #dc2626;
            --primary-light: #fef2f2;
            --primary-bg: rgba(239, 68, 68, 0.05);
        }

        @media (max-width: 640px) {
            .request-drop-area {
                padding: 32px 16px;
            }

            .request-preview-list {
                grid-template-columns: 1fr;
            }

            .request-upload-text {
                font-size: 15px;
            }

            .request-upload-subtext {
                font-size: 13px;
            }
        }

        /* Published Status */

        .published-upload-container {
            margin-top: 8px;
        }

        .published-drop-area {
            border: 2px dashed var(--medium-gray);
            border-radius: var(--radius-lg);
            padding: 48px 32px;
            text-align: center;
            position: relative;
            background-color: var(--light-gray);
            transition: var(--transition);
            cursor: pointer;
            overflow: hidden;
        }

        .published-drop-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: inherit;
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.05) 0%, rgba(16, 185, 129, 0) 100%);
            opacity: 0;
            transition: var(--transition);
        }

        .published-drop-area:hover {
            border-color: #10b981;
            background-color: #ecfdf5;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .published-drop-area:hover::before {
            opacity: 1;
        }

        .published-drop-area.drag-over {
            border-color: #10b981;
            background-color: #d1fae5;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .published-drop-area.drag-over::before {
            opacity: 1;
        }

        .published-drop-message {
            color: var(--dark-gray);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            pointer-events: none;
        }

        .published-upload-icon {
            margin-bottom: 16px;
            color: var(--dark-gray);
            transition: var(--transition);
        }

        .published-drop-area:hover .published-upload-icon {
            color: #10b981;
            transform: scale(1.05);
        }

        .published-upload-icon svg {
            width: 48px;
            height: 48px;
            stroke-width: 1.5;
        }

        .published-upload-text {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .published-upload-subtext {
            font-size: 14px;
            color: var(--dark-gray);
            margin-bottom: 0;
        }

        .published-clickable {
            color: #10b981;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
        }

        .published-clickable:hover {
            color: #059669;
            text-decoration: underline;
        }

        .published-file-input {
            display: none;
        }

        .published-preview-container {
            margin-top: 24px;
            display: none;
        }

        .published-preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--medium-gray);
        }

        .published-preview-title {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .published-preview-title .badge {
            background-color: #10b981;
            color: white;
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 500;
        }

        .published-clear-all-btn {
            background: none;
            border: none;
            color: var(--danger-red);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .published-clear-all-btn:hover {
            background-color: #fee2e2;
        }

        .published-preview-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 0;
            overflow-y: scroll;
            max-height: 231px;
        }

        .published-preview-item {
            border: 1px solid var(--medium-gray);
            border-radius: var(--radius-md);
            background: white;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 16px;
            position: relative;
            transition: var(--transition);
            overflow: hidden;
        }

        .published-preview-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: #10b981;
        }

        .published-preview-thumb-container {
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            background-color: #f8fafc;
        }

        .published-preview-thumb {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .published-file-icon {
            width: 48px;
            height: 48px;
            color: var(--dark-gray);
        }

        .published-file-icon svg {
            width: 100%;
            height: 100%;
        }

        .published-preview-filename {
            font-weight: 500;
            text-align: center;
            margin-bottom: 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            font-size: 14px;
            color: var(--text-dark);
        }

        .published-preview-size {
            color: var(--dark-gray);
            font-size: 12px;
            margin-bottom: 12px;
        }

        .published-progress-container {
            width: 100%;
        }

        .published-progress-bar {
            width: 100%;
            height: 4px;
            background-color: var(--medium-gray);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .published-progress-bar-inner {
            height: 100%;
            width: 0;
            background: linear-gradient(90deg, #10b981, #34d399);
            transition: width 0.3s ease;
            border-radius: 2px;
        }

        .published-progress-text {
            font-size: 11px;
            color: var(--dark-gray);
            text-align: center;
            font-weight: 500;
        }

        .published-remove-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            background: white;
            border: 1px solid var(--medium-gray);
            border-radius: 50%;
            color: var(--dark-gray);
            font-weight: bold;
            width: 28px;
            height: 28px;
            cursor: pointer;
            line-height: 26px;
            text-align: center;
            padding: 0;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.8;
        }

        .published-remove-btn:hover {
            background-color: var(--danger-red);
            color: white;
            border-color: var(--danger-red);
            opacity: 1;
            transform: scale(1.1);
        }

        .published-file-status {
            position: absolute;
            top: 8px;
            left: 8px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .published-status-uploading {
            background-color: #fef3c7;
            color: #92400e;
        }

        .published-status-success {
            background-color: #d1fae5;
            color: #065f46;
        }

        .published-status-error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .published-file-type-badge {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            font-weight: 500;
        }

        .published-empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 48px 32px;
            color: var(--dark-gray);
            background-color: var(--light-gray);
            border-radius: var(--radius-md);
            border: 1px dashed var(--medium-gray);
        }

        .published-empty-icon {
            font-size: 32px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .published-empty-text {
            font-size: 14px;
            color: var(--dark-gray);
        }

        /* Emerald theme for Published status */
        .published-theme {
            --primary-color: #10b981;
            --primary-hover: #059669;
            --primary-light: #ecfdf5;
            --primary-bg: rgba(16, 185, 129, 0.05);
        }

        @media (max-width: 640px) {
            .published-drop-area {
                padding: 32px 16px;
            }

            .published-preview-list {
                grid-template-columns: 1fr;
            }

            .published-upload-text {
                font-size: 15px;
            }

            .published-upload-subtext {
                font-size: 13px;
            }
        }
    </style>


    {{-- Dropzone.js File Upload Via AJAX --}}
    <script>
        const dropArea = document.getElementById("dropArea");
        const fileInput = document.getElementById("fileInput");
        const previewList = document.getElementById("previewList");
        const previewContainer = document.getElementById("previewContainer");
        const dropMessage = document.getElementById("dropMessage");
        const fileCount = document.getElementById("fileCount");
        const clearAllBtn = document.getElementById("clearAllBtn");
        let uploadedFiles = [];

        // File type icons mapping
        const fileIcons = {
            pdf: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 13.5H9m6 3H9m3-6h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>`,
            doc: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
              </svg>`,
            image: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
               </svg>`,
            default: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>`
        };

        // Get file icon based on type
        function getFileIcon(file) {
            if (file.type.startsWith('image/')) return fileIcons.image;
            if (file.type === 'application/pdf') return fileIcons.pdf;
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return fileIcons.doc;
            return fileIcons.default;
        }

        // Get file type for badge
        function getFileType(file) {
            if (file.type.startsWith('image/')) return 'IMG';
            if (file.type === 'application/pdf') return 'PDF';
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return 'DOC';
            return file.name.split('.').pop().toUpperCase();
        }

        // Make whole drop area clickable
        dropArea.addEventListener("click", () => fileInput.click());

        dropArea.addEventListener("dragover", e => {
            e.preventDefault();
            dropArea.classList.add("drag-over");
        });

        dropArea.addEventListener("dragleave", e => {
            e.preventDefault();
            dropArea.classList.remove("drag-over");
        });

        dropArea.addEventListener("drop", e => {
            e.preventDefault();
            dropArea.classList.remove("drag-over");
            if (e.dataTransfer.files.length) {
                handleFiles(e.dataTransfer.files);
            }
        });

        fileInput.addEventListener("change", e => {
            if (e.target.files.length) {
                handleFiles(e.target.files);
            }
        });

        // Clear all files
        clearAllBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            e.stopPropagation();

            // Disable button to prevent double clicks
            clearAllBtn.disabled = true;

            for (const file of uploadedFiles) {
                if (file.stored_name) {
                    await removeFileFromServer(file.stored_name);
                }
            }

            // Clear UI
            previewList.innerHTML = '';
            uploadedFiles = [];
            updateFileCount();
            previewContainer.style.display = 'none';
            dropMessage.style.display = 'block';
            document.getElementById("uploaded_files").value = JSON.stringify([]);

            clearAllBtn.disabled = false;
        });

        function humanFileSize(size) {
            const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
            return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
        }

        function updateFileCount() {
            fileCount.textContent = uploadedFiles.length;
        }

        function handleFiles(files) {
            dropMessage.style.display = "none";
            previewContainer.style.display = "block";

            [...files].forEach(file => {
                if (file.size > 10 * 1024 * 1024) {
                    alert(`File "${file.name}" exceeds 10MB limit`);
                    return;
                }

                const previewItem = document.createElement("div");
                previewItem.className = "preview-item";

                // File status badge
                const statusBadge = document.createElement("div");
                statusBadge.className = "file-status status-uploading";
                statusBadge.textContent = "Uploading";
                previewItem.appendChild(statusBadge);

                // File type badge
                const typeBadge = document.createElement("div");
                typeBadge.className = "file-type-badge";
                typeBadge.textContent = getFileType(file);
                previewItem.appendChild(typeBadge);

                // Remove button
                const removeBtn = document.createElement("button");
                removeBtn.type = "button";
                removeBtn.className = "remove-btn";
                removeBtn.innerHTML = "×";
                removeBtn.onclick = async (e) => {

                    e.preventDefault(); // extra protection
                    e.stopPropagation();

                    if (confirm('Remove this file?')) {
                        const storedName = previewItem.dataset.storedName;
                        if (storedName) {
                            const success = await removeFileFromServer(storedName);
                            if (success) {
                                previewList.removeChild(previewItem);
                                uploadedFiles = uploadedFiles.filter(f => f.stored_name !== storedName);
                                updateFileCount();
                                if (uploadedFiles.length === 0) {
                                    previewContainer.style.display = "none";
                                    dropMessage.style.display = "block";
                                }
                                document.getElementById("uploaded_files").value = JSON.stringify(
                                    uploadedFiles);
                            }
                        } else {
                            // If upload was in progress, just remove from UI
                            previewList.removeChild(previewItem);
                            uploadedFiles = uploadedFiles.filter(f => f.original_name !== file.name);
                            updateFileCount();
                            if (uploadedFiles.length === 0) {
                                previewContainer.style.display = "none";
                                dropMessage.style.display = "block";
                            }
                            document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);
                        }
                    }
                };
                previewItem.appendChild(removeBtn);

                // Thumbnail container
                const thumbContainer = document.createElement("div");
                thumbContainer.className = "preview-thumb-container";

                if (file.type.startsWith("image/")) {
                    const img = document.createElement("img");
                    img.className = "preview-thumb";
                    const reader = new FileReader();
                    reader.onload = e => img.src = e.target.result;
                    reader.readAsDataURL(file);
                    thumbContainer.appendChild(img);
                } else {
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "file-icon";
                    fileIcon.innerHTML = getFileIcon(file);
                    thumbContainer.appendChild(fileIcon);
                }
                previewItem.appendChild(thumbContainer);

                // File name
                const nameDiv = document.createElement("div");
                nameDiv.className = "preview-filename";
                nameDiv.title = file.name;
                nameDiv.textContent = file.name.length > 20 ? file.name.substring(0, 20) + '...' : file.name;
                previewItem.appendChild(nameDiv);

                // File size
                const sizeDiv = document.createElement("div");
                sizeDiv.className = "preview-size";
                sizeDiv.textContent = humanFileSize(file.size);
                previewItem.appendChild(sizeDiv);

                // Progress container
                const progressContainer = document.createElement("div");
                progressContainer.className = "progress-container";

                const progressBar = document.createElement("div");
                progressBar.className = "progress-bar";
                const progressBarInner = document.createElement("div");
                progressBarInner.className = "progress-bar-inner";
                progressBar.appendChild(progressBarInner);
                progressContainer.appendChild(progressBar);

                const progressText = document.createElement("div");
                progressText.className = "progress-text";
                progressText.textContent = "0%";
                progressContainer.appendChild(progressText);

                previewItem.appendChild(progressContainer);

                // Add temporary file to array (will be updated after upload)
                uploadedFiles.push({
                    original_name: file.name,
                    stored_name: null, // Will be set after upload
                    path: null
                });

                // Add to preview list
                previewList.appendChild(previewItem);

                // Upload file
                uploadFile(file, progressBarInner, progressText, statusBadge, previewItem);
            });

            updateFileCount();
        }

        function uploadFile(file, progressElement, progressText, statusBadge, previewItem) {
            const url = "{{ route('upload_journal') }}";
            const formData = new FormData();
            formData.append("file_upload[]", file);

            const xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressElement.style.width = percent + "%";
                    progressText.textContent = percent + "%";
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success && res.files.length > 0) {
                        const uploadedFile = res.files[0];

                        // Store file info on the preview item
                        previewItem.dataset.storedName = uploadedFile.stored_name;

                        // Update the file in uploadedFiles array
                        const fileIndex = uploadedFiles.findIndex(f => f.original_name === uploadedFile.original_name);
                        if (fileIndex !== -1) {
                            uploadedFiles[fileIndex] = uploadedFile;
                        }

                        document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);
                        progressElement.style.background = "var(--success-green)";
                        statusBadge.className = "file-status status-success";
                        statusBadge.textContent = "Uploaded";
                        progressText.textContent = "Complete";

                        // Update the filename display to show original name
                        const nameDiv = previewItem.querySelector('.preview-filename');
                        nameDiv.textContent = uploadedFile.original_name.length > 20 ?
                            uploadedFile.original_name.substring(0, 20) + '...' : uploadedFile.original_name;
                        nameDiv.title = uploadedFile.original_name;

                        previewItem.style.borderColor = "var(--success-green)";
                        previewItem.style.boxShadow = "0 0 0 1px var(--success-green)";
                    } else {
                        handleUploadError(progressElement, statusBadge, progressText, res.message || 'Upload failed');
                    }
                } else {
                    handleUploadError(progressElement, statusBadge, progressText, 'Upload failed with status ' + xhr
                        .status);
                }
            };

            xhr.onerror = function() {
                handleUploadError(progressElement, statusBadge, progressText, 'Network error');
            };

            xhr.send(formData);
        }

        async function removeFileFromServer(fileName) {
            try {
                const response = await fetch("{{ url('/upload/temp/remove') }}", {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: JSON.stringify({
                        file_name: fileName
                    }) // Note: matches your backend parameter name
                });

                const result = await response.json();

                if (result.success) {
                    return true;
                } else {
                    toastr.error(result.message || 'Failed to remove file');
                    return false;
                }
            } catch (error) {
                toastr.error(error.message || 'Error removing file');
                return false;
            }
        }

        function handleUploadError(progressElement, statusBadge, progressText, message) {
            progressElement.style.background = "var(--danger-red)";
            statusBadge.className = "file-status status-error";
            statusBadge.textContent = "Error";
            progressText.textContent = "Failed";
            toastr.error(message || 'Upload failed');
        }

        // Initialize with any existing files from hidden input
        document.addEventListener('DOMContentLoaded', () => {
            const existingFiles = JSON.parse(document.getElementById("uploaded_files").value || '[]');
            if (existingFiles.length > 0) {
                // Display already uploaded files
                previewContainer.style.display = "block";
                dropMessage.style.display = "none";

                existingFiles.forEach(file => {
                    createPreviewForExistingFile(file);
                });

                uploadedFiles = existingFiles;
                updateFileCount();
            }
        });

        function createPreviewForExistingFile(fileData) {
            const previewItem = document.createElement("div");
            previewItem.className = "preview-item";
            previewItem.dataset.storedName = fileData.stored_name;

            // File status badge
            const statusBadge = document.createElement("div");
            statusBadge.className = "file-status status-success";
            statusBadge.textContent = "Uploaded";
            previewItem.appendChild(statusBadge);

            // File type badge
            const typeBadge = document.createElement("div");
            typeBadge.className = "file-type-badge";
            const fileExt = fileData.original_name.split('.').pop().toUpperCase();
            typeBadge.textContent = ['PDF', 'DOC', 'DOCX', 'JPG', 'JPEG', 'PNG', 'GIF'].includes(fileExt) ?
                fileExt : fileExt;
            previewItem.appendChild(typeBadge);

            // Remove button
            const removeBtn = document.createElement("button");
            removeBtn.className = "remove-btn";
            removeBtn.innerHTML = "×";
            removeBtn.onclick = async () => {
                if (confirm('Remove this file?')) {
                    const storedName = fileData.stored_name;
                    const success = await removeFileFromServer(storedName);
                    if (success) {
                        previewList.removeChild(previewItem);
                        uploadedFiles = uploadedFiles.filter(f => f.stored_name !== storedName);
                        updateFileCount();
                        if (uploadedFiles.length === 0) {
                            previewContainer.style.display = "none";
                            dropMessage.style.display = "block";
                        }
                        document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);
                    }
                }
            };
            previewItem.appendChild(removeBtn);

            // Thumbnail container
            const thumbContainer = document.createElement("div");
            thumbContainer.className = "preview-thumb-container";

            // Check if it's an image
            const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileData.original_name.split('.').pop()
                .toLowerCase());

            if (isImage && fileData.path) {
                // Try to load image from path
                const img = document.createElement("img");
                img.className = "preview-thumb";
                img.src = "{{ asset('') }}" + fileData.path;
                img.onerror = function() {
                    // If image fails to load, show file icon
                    thumbContainer.innerHTML = '';
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "file-icon";
                    fileIcon.innerHTML = fileIcons.image;
                    thumbContainer.appendChild(fileIcon);
                };
                thumbContainer.appendChild(img);
            } else {
                const fileIcon = document.createElement("div");
                fileIcon.className = "file-icon";
                const fileExt = fileData.original_name.split('.').pop().toLowerCase();
                if (fileExt === 'pdf') {
                    fileIcon.innerHTML = fileIcons.pdf;
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon.innerHTML = fileIcons.doc;
                } else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileExt)) {
                    fileIcon.innerHTML = fileIcons.image;
                } else {
                    fileIcon.innerHTML = fileIcons.default;
                }
                thumbContainer.appendChild(fileIcon);
            }
            previewItem.appendChild(thumbContainer);

            // File name
            const nameDiv = document.createElement("div");
            nameDiv.className = "preview-filename";
            nameDiv.title = fileData.original_name;
            nameDiv.textContent = fileData.original_name.length > 20 ?
                fileData.original_name.substring(0, 20) + '...' : fileData.original_name;
            previewItem.appendChild(nameDiv);

            // File size (if available)
            const sizeDiv = document.createElement("div");
            sizeDiv.className = "preview-size";
            sizeDiv.textContent = fileData.size ? humanFileSize(fileData.size) : 'Size unknown';
            previewItem.appendChild(sizeDiv);

            previewList.appendChild(previewItem);
        }
    </script>

    <script>
        // Create card for database journal (different structure)
        function createDatabaseJournalCard(journal) {
            return `
      <div class="col-lg-12 mb-2">
        <div class="fs-7 fw-bold text-danger">${journal.journal_name || 'N/A'}</div>
    </div>
    <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
            <label class="me-2" title="Domain">
                <i class="mdi mdi-web fs-4 text-black"></i>
            </label>
            <label class="fs-7 align-items-center text-black fw-semibold">
                ${
                Array.isArray(journal.domains) && journal.domains.length
                ? journal.domains.map(d => d.name).join(', ')
                : 'N/A'
                }
            </label>
        </div>
    </div>
    <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
            <label class="me-2" title="Journal Link">
                <i class="mdi mdi-link fs-4 text-black"></i>
            </label>
            <label class="fs-7 align-items-center text-black fw-semibold">
                ${journal.journal_link ? `<a href="${journal.journal_link}" target="_blank"
                                                                                                    rel="noopener noreferrer">${journal.journal_link}</a>` : 'N/A'}
            </label>
        </div>
    </div>
    <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
            <label class="me-2" title="Journal Scores">
                <i class="mdi mdi-chart-bar fs-4 text-black"></i>
            </label>
            <label class="fs-7 align-items-center text-black fw-semibold">
                <span>
                    ${
                    Array.isArray(journal.journal_score) && journal.journal_score.length
                    ? journal.journal_score.map(score => `${score.index_name}: ${score.score}`).join(', ')
                    : 'N/A'
                    }
                </span>
            </label>
        </div>
    </div>
    <hr class="border border-info" />
    `;
        }

        // Create card for online/recommended journals
        function createJournalCard(journal) {
            return `
      <div class="col-lg-12 mb-2">
        <div class="fs-7 fw-bold text-danger">${journal.journal_name || 'N/A'}</div>
      </div>
      <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
          <label class="me-2" title="Domain">
            <i class="mdi mdi-web fs-4 text-black"></i>
          </label>
          <label class="fs-7 align-items-center text-black fw-semibold">
            <span>${
                journal.domain
                ? journal.domain
                : (Array.isArray(journal.domains) && journal.domains.length
                ? journal.domains.map(d => d.name).join(', ')
                : 'N/A')
                }
            </span>
          </label>
        </div>
      </div>
      <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
          <label class="me-2" title="Journal Link">
            <i class="mdi mdi-link fs-4 text-black"></i>
          </label>
          <label class="fs-7 align-items-center text-black fw-semibold">
            ${journal.journal_link ? `<a href="${journal.journal_link}" target="_blank" rel="noopener noreferrer">${journal.journal_link}</a>` : 'N/A'}
          </label>
        </div>
      </div>
      <div class="col-lg-12 mb-1">
        <div class="d-flex justify-content-start">
          <label class="me-2" title="Journal Scores">
            <i class="mdi mdi-chart-bar fs-4 text-black"></i>
          </label>
          <label class="fs-7 align-items-center text-black fw-semibold">
            <span>
              ${
            Array.isArray(journal.journal_score) && journal.journal_score.length
            ? journal.journal_score.map(score => `${score.index_name}: ${score.score}`).join(', ')
            : 'N/A'
            }
            </span>
          </label>
        </div>
      </div>
      <hr class="border border-info" />
    `;
        }

        function populateJournals(data) {
            const databaseContainer = document.getElementById('databaseContainer');
            const onlineSearchContainer = document.getElementById('onlineSearchContainer');
            const recommendedContainer = document.getElementById('recommendedContainer');

            databaseContainer.innerHTML = '';
            onlineSearchContainer.innerHTML = '';
            recommendedContainer.innerHTML = '';

            const database = data.database_journal || [];
            const online = data.online_journal || [];
            const recommended = data.recommended_journal ? [data.recommended_journal] : [];
            const recommendedOnline = data.recommended_online_journal ? [data.recommended_online_journal] : [];

            // Database journals
            if (database.length) {
                database.forEach(journal => {
                    const div = document.createElement('div');
                    div.innerHTML = createDatabaseJournalCard(journal);
                    databaseContainer.appendChild(div);
                });
            } else {
                databaseContainer.innerHTML = `<div class="fs-7 fw-bold text-muted">No database journals found.</div>`;
            }

            // Online search journals
            if (online.length) {
                online.forEach(journal => {
                    const div = document.createElement('div');
                    div.innerHTML = createJournalCard(journal);
                    onlineSearchContainer.appendChild(div);
                });
            } else {
                onlineSearchContainer.innerHTML =
                    `<div class="fs-7 fw-bold text-muted">No online search journals found.</div>`;
            }

            // Recommended journals
            if (recommended.length || recommendedOnline.length) {
                [...recommended, ...recommendedOnline].forEach(journal => {
                    const div = document.createElement('div');
                    div.innerHTML = createJournalCard(journal);
                    recommendedContainer.appendChild(div);
                });
                recommendedContainer.style.display = 'flex';
                recommendedContainer.style.flexWrap = 'wrap';
                recommendedContainer.style.gap = '1rem';
            } else {
                recommendedContainer.innerHTML =
                    `<div class="fs-7 fw-bold text-muted">No recommended journals found.</div>`;
                recommendedContainer.style.display = '';
            }

            // Initialize Bootstrap tooltips
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"], [title]'));
            tooltipTriggerList.map(el => new bootstrap.Tooltip(el));
        }

        // Trigger search
        document.getElementById('searchBtn').addEventListener('click', () => {
            const paperName = document.getElementById('journalInput').value.trim();
            if (!paperName) {
                alert('Please enter a paper name');
                return;
            }

            const searchBtn = document.getElementById('searchBtn');
            const loadingSpinner = document.getElementById('loadingSpinner');
            const resultsContainer = document.getElementById('results');

            searchBtn.disabled = true;
            loadingSpinner.style.display = 'flex';
            resultsContainer.style.display = 'none';

            fetch('/journal_search', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // adjust this if not Blade
                    },
                    body: JSON.stringify({
                        prompt: paperName
                    })
                })
                .then(res => {
                    if (!res.ok) throw new Error('Network response was not ok');
                    return res.json();
                })
                .then(data => {
                    populateJournals(data);
                    resultsContainer.style.display = 'flex';
                    resultsContainer.style.gap = '1rem';
                })
                .catch(err => {
                    console.error('Fetch error:', err);
                    alert('Error fetching journal data');
                })
                .finally(() => {
                    searchBtn.disabled = false;
                    loadingSpinner.style.display = 'none';
                });
        });
    </script>

    <!-- Journal Staff Assign Data Fetch -->
    <script>
        function AssignStaff(id) {
            $.ajax({
                url: `/journal_staff_assign/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === 200) {
                        var journal = response.data;

                        // Assigning Values
                        $('#assgn_service_id').val(journal.sno);
                        $('#assgn_service').html(`${journal.service_name} ( ${journal.service_id} )`);
                        $('#assgn_cus').html(`${journal.cus_name} ( ${journal.cus_id} )`);
                        $('#assgn_mobile').html(journal.cus_mobile ?? '-');
                        $('#assgn_mail').html(journal.cus_email_id ?? '-');

                        // Fetch Staff Data
                        const staffList = response.staff;
                        let options = `<option value="">Select Staff</option>`;

                        staffList.forEach(function(staff) {
                            if (staff.dept_id == 14) {
                                options +=
                                    `<option value="${staff.sno}">${staff.staff_name} - ${staff.position_name}</option>`;
                            }
                        });
                        $('#assgn_staff_id').html(options);

                    } else {
                        console.error(`Data Fetching Failed`);
                    }
                },
                error: function(xhr, status, error) {
                    console.error(`Error Assigning Staff: ${error}`);
                }
            });
        }

        // Assign Staff Validation
        $(document).ready(function() {

            // Assign Staff Validation
            $('#assign_journal_staff').on('submit', function(e) {

                $('#assgn_staff_err').text('');
                const selectedStaff = $('#assgn_staff_id').val();

                if (selectedStaff === '') {
                    e.preventDefault();
                    $('#assgn_staff_err').text('Assign the staff.');
                    $('#assgn_staff_id').focus();
                }
            });

            // Remove Existing Error
            $('#assgn_staff_id').on('change', function() {
                if ($(this).val() !== '') {
                    $('#assgn_staff_err').text('');
                }
            });
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const modals = document.querySelectorAll('.modal');

            modals.forEach(modal => {
                modal.addEventListener('hidden.bs.modal', function() {
                    // Reset all forms inside the modal
                    modal.querySelectorAll('form').forEach(form => form.reset());
                    databaseContainer.innerHTML = '';
                    onlineSearchContainer.innerHTML = '';
                    recommendedContainer.innerHTML = '';


                    // Clear all error messages
                    modal.querySelectorAll('.text-danger').forEach(el => {
                        if (el.textContent.trim() === '*') return;
                        el.textContent = '';
                    });

                    // Clear hidden inputs (optional)
                    modal.querySelectorAll('input[type="hidden"]').forEach(input => {
                        input.value = '';
                    });

                    // Reset all selects
                    modal.querySelectorAll('select').forEach(select => {
                        select.selectedIndex = 0;

                        // If using Select2 or similar, trigger update
                        if ($(select).hasClass('select3')) {
                            $(select).val('').trigger(
                                'change'); // reset to empty or default value
                        }
                    });
                });
            });
        });
    </script>

    <!-- FETCH SUBMIT JOURNAL -->
    <script>
        function fetchData(id) {
            fetch(`fetch_add_data/${id}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 200) {
                        var journal = data.data;

                        $('#add_services').html(`${journal.service_name} ( ${journal.service_id} )`);
                        $('#cus_info').html(`${journal.cus_name} ( ${journal.cus_id} )`);
                        $('#customer_id').val(journal.cus_sno);
                        $('#customer_services_id').val(journal.sno);
                        $('#paper_name').val(journal.journal_paper_name);
                        $('#paper_desc').val(journal.journal_paper_desc);
                        getJournalBookletData();

                    } else {
                        console.log('Error Fetching Data !');
                    }
                })
                .catch(error => {
                    console.log(`Error fetching Data : ${error}`);
                });
        }
    </script>

    <!-- SUBMIT JOURNAL -->
    <script>
        function submitJournal() {
            // Show the loader overlay
            showGoogleDriveLoader();

            let formData = {};

            const emails = [];
            const passwords = [];

            $('.journal_email').each(function() {
                emails.push($(this).val());
            });
            $('.journal_pass').each(function() {
                passwords.push($(this).val());
            });

            formData = {
                uploaded_files: $('#uploaded_files').val(),
                customer_id: $('#customer_id').val(),
                customer_services_id: $('#customer_services_id').val(),
                journal_booklet_id: $('#journal_booklet_id').val(),
                paper_name: $('#paper_name').val(),
                paper_desc: $('#paper_desc').val(),
                submitted_date: $('#journal_submitted_date').val(),
                email: emails,
                password: passwords,
                _token: $('meta[name="csrf-token"]').attr('content')
            }

            $.ajax({
                url: `/submit_journal`,
                method: 'POST',
                data: formData,
                dataType: 'json',
                beforeSend: function() {
                    // Disable submit button to prevent multiple submissions
                    $('.submit-btn').prop('disabled', true).addClass('loading');
                },
                success: function(response) {
                    hideGoogleDriveLoader();
                    if (response.status === 200) {
                        // Show success message before reloading
                        showSuccessMessage(response.message);
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        hideGoogleDriveLoader();
                        toastr.error(response.message || 'An error occurred');
                        $('.submit-btn').prop('disabled', false).removeClass('loading');
                    }
                },
                error: function(xhr, status, error) {
                    hideGoogleDriveLoader();
                    $('.submit-btn').prop('disabled', false).removeClass('loading');

                    // Handle different HTTP status codes
                    if (xhr.status === 409) {
                        // Journal name already exists
                        toastr.error(xhr.responseJSON?.message || 'Journal name already exists!');
                    } else if (xhr.status === 422) {
                        // Validation errors
                        const errors = xhr.responseJSON?.errors;
                        if (errors) {
                            // Display validation errors for each field
                            Object.keys(errors).forEach(field => {
                                toastr.error(errors[field][0]);
                            });
                        } else {
                            toastr.error(xhr.responseJSON?.message || 'Validation failed!');
                        }
                    } else if (xhr.status === 500) {
                        // Server error
                        toastr.error(xhr.responseJSON?.message || 'Server error occurred!');
                    } else {
                        // Other errors
                        toastr.error('An unexpected error occurred: ' + error);
                    }

                    console.error('Error submitting journal:', xhr.responseJSON || error);
                }
            });
        }

        // Google Drive style loader functions
        function showGoogleDriveLoader() {
            // Create overlay if it doesn't exist
            if (!$('#drive-loader-overlay').length) {
                $('body').append(`
                <div id="drive-loader-overlay" style="
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(255, 255, 255, 0.9);
                    z-index: 9999;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    backdrop-filter: blur(2px);
                    transition: opacity 0.3s ease;
                ">
                    <div class="drive-loader" style="
                        width: 80px;
                        height: 80px;
                        position: relative;
                        margin-bottom: 20px;
                    ">
                        <div class="drive-logo" style="
                            width: 40px;
                            height: 40px;
                            position: absolute;
                            top: 50%;
                            left: 50%;
                            transform: translate(-50%, -50%);
                            background: linear-gradient(135deg, #4285F4, #34A853, #FBBC05, #EA4335);
                            border-radius: 8px;
                            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                        ">
                            <div style="
                                position: absolute;
                                top: 8px;
                                left: 8px;
                                width: 24px;
                                height: 24px;
                                background: white;
                                border-radius: 4px;
                                display: flex;
                                align-items: center;
                                justify-content: center;
                                font-weight: bold;
                                color: #4285F4;
                                font-size: 12px;
                            ">GD</div>
                        </div>
                        <div class="drive-loader-ring" style="
                            width: 100%;
                            height: 100%;
                            border: 4px solid #f3f3f3;
                            border-top: 4px solid #4285F4;
                            border-right: 4px solid #34A853;
                            border-bottom: 4px solid #FBBC05;
                            border-radius: 50%;
                            animation: spin 2s linear infinite;
                        "></div>
                    </div>

                    <div class="drive-loader-text" style="
                        font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                        color: #3c4043;
                        font-size: 16px;
                        font-weight: 500;
                        margin-bottom: 8px;
                    ">Uploading to Google Drive</div>

                    <div class="drive-loader-subtext" style="
                        font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                        color: #5f6368;
                        font-size: 14px;
                        text-align: center;
                        max-width: 300px;
                        line-height: 1.4;
                    ">Creating folders and uploading files. This may take a moment...</div>

                    <div class="drive-progress-container" style="
                        width: 300px;
                        margin-top: 20px;
                        background: #f1f3f4;
                        border-radius: 10px;
                        height: 6px;
                        overflow: hidden;
                    ">
                        <div class="drive-progress-bar" style="
                            width: 0%;
                            height: 100%;
                            background: linear-gradient(90deg, #4285F4, #34A853);
                            border-radius: 10px;
                            transition: width 0.3s ease;
                        "></div>
                    </div>

                    <div class="drive-progress-text" style="
                        font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                        color: #5f6368;
                        font-size: 13px;
                        margin-top: 8px;
                    ">Preparing upload...</div>

                    <div class="drive-steps" style="
                        margin-top: 20px;
                        display: flex;
                        flex-direction: column;
                        gap: 10px;
                        width: 300px;
                    ">
                        <div class="drive-step" data-step="1" style="
                            display: flex;
                            align-items: center;
                            gap: 10px;
                            padding: 8px 12px;
                            background: #f8f9fa;
                            border-radius: 8px;
                            border-left: 4px solid #e8eaed;
                        ">
                            <div class="step-icon" style="
                                width: 20px;
                                height: 20px;
                                border-radius: 50%;
                                background: #e8eaed;
                                display: flex;
                                align-items: center;
                                justify-content: center;
                                font-size: 12px;
                                color: #5f6368;
                            ">1</div>
                            <div class="step-text" style="
                                font-size: 14px;
                                color: #5f6368;
                            ">Creating folder structure</div>
                        </div>
                        <div class="drive-step" data-step="2" style="
                            display: flex;
                            align-items: center;
                            gap: 10px;
                            padding: 8px 12px;
                            background: #f8f9fa;
                            border-radius: 8px;
                            border-left: 4px solid #e8eaed;
                        ">
                            <div class="step-icon" style="
                                width: 20px;
                                height: 20px;
                                border-radius: 50%;
                                background: #e8eaed;
                                display: flex;
                                align-items: center;
                                justify-content: center;
                                font-size: 12px;
                                color: #5f6368;
                            ">2</div>
                            <div class="step-text" style="
                                font-size: 14px;
                                color: #5f6368;
                            ">Uploading files</div>
                        </div>
                        <div class="drive-step" data-step="3" style="
                            display: flex;
                            align-items: center;
                            gap: 10px;
                            padding: 8px 12px;
                            background: #f8f9fa;
                            border-radius: 8px;
                            border-left: 4px solid #e8eaed;
                        ">
                            <div class="step-icon" style="
                                width: 20px;
                                height: 20px;
                                border-radius: 50%;
                                background: #e8eaed;
                                display: flex;
                                align-items: center;
                                justify-content: center;
                                font-size: 12px;
                                color: #5f6368;
                            ">3</div>
                            <div class="step-text" style="
                                font-size: 14px;
                                color: #5f6368;
                            ">Saving journal information</div>
                        </div>
                    </div>
                </div>
            `);

                // Add CSS animation
                const style = document.createElement('style');
                style.innerHTML = `
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }

                @keyframes pulse {
                    0% { opacity: 0.6; }
                    50% { opacity: 1; }
                    100% { opacity: 0.6; }
                }

                .drive-step.active {
                    background: #e8f0fe !important;
                    border-left-color: #1a73e8 !important;
                }

                .drive-step.active .step-icon {
                    background: #1a73e8 !important;
                    color: white !important;
                }

                .drive-step.completed {
                    background: #e6f4ea !important;
                    border-left-color: #34a853 !important;
                }

                .drive-step.completed .step-icon {
                    background: #34a853 !important;
                    color: white !important;
                }
            `;
                document.head.appendChild(style);
            }

            $('#drive-loader-overlay').fadeIn(300);

            // Simulate progress updates
            simulateDriveUploadProgress();
        }

        function hideGoogleDriveLoader() {
            $('#drive-loader-overlay').fadeOut(300, function() {
                $(this).remove();
            });
        }

        function showSuccessMessage(message) {
            if (!$('#success-message-overlay').length) {
                $('body').append(`
                <div id="success-message-overlay" style="
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(255, 255, 255, 0.95);
                    z-index: 10000;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    backdrop-filter: blur(2px);
                ">
                    <div style="
                        width: 80px;
                        height: 80px;
                        background: #34a853;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        margin-bottom: 20px;
                        animation: scaleIn 0.5s ease;
                    ">
                        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                    </div>

                    <div style="
                        font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                        color: #202124;
                        font-size: 24px;
                        font-weight: 500;
                        margin-bottom: 10px;
                    ">Success!</div>

                    <div style="
                        font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                        color: #5f6368;
                        font-size: 16px;
                        text-align: center;
                        max-width: 400px;
                        line-height: 1.5;
                        margin-bottom: 30px;
                    ">${message}</div>

                    <div style="
                        font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                        color: #5f6368;
                        font-size: 14px;
                        text-align: center;
                        max-width: 400px;
                        line-height: 1.4;
                    ">
                        <div style="display: flex; align-items: center; gap: 8px; justify-content: center;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="#34a853">
                                <path d="M19 4H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 16H5V8h14v12z"/>
                            </svg>
                            <span>Files uploaded to Google Drive successfully</span>
                        </div>
                    </div>
                </div>
            `);

                // Add CSS animation
                const style = document.createElement('style');
                style.innerHTML = `
                @keyframes scaleIn {
                    0% { transform: scale(0); opacity: 0; }
                    70% { transform: scale(1.1); }
                    100% { transform: scale(1); opacity: 1; }
                }
            `;
                document.head.appendChild(style);
            }

            $('#success-message-overlay').fadeIn(300);
        }

        function simulateDriveUploadProgress() {
            let progress = 0;
            let currentStep = 1;

            const progressBar = $('#drive-loader-overlay .drive-progress-bar');
            const progressText = $('#drive-loader-overlay .drive-progress-text');
            const steps = $('#drive-loader-overlay .drive-step');

            // Step 1: Creating folder structure (0-30%)
            setTimeout(() => {
                updateStep(1, 'active');
                simulateProgressIncrement(30, 1500, 'Creating customer folder...');

                setTimeout(() => {
                    updateStep(1, 'completed');
                    updateStep(2, 'active');

                    // Step 2: Uploading files (30-80%)
                    setTimeout(() => {
                        simulateProgressIncrement(50, 3000, 'Uploading files to Google Drive...');

                        setTimeout(() => {
                            updateStep(2, 'completed');
                            updateStep(3, 'active');

                            // Step 3: Saving information (80-95%)
                            setTimeout(() => {
                                simulateProgressIncrement(15, 2000,
                                    'Saving journal information...');

                                setTimeout(() => {
                                    updateStep(3, 'completed');

                                    // Final step (95-100%)
                                    setTimeout(() => {
                                        simulateProgressIncrement(5,
                                            1000,
                                            'Finalizing...');
                                    }, 500);
                                }, 500);
                            }, 500);
                        }, 500);
                    }, 500);
                }, 500);
            }, 500);

            function simulateProgressIncrement(increment, duration, message) {
                const startProgress = progress;
                const endProgress = progress + increment;
                const startTime = Date.now();

                progressText.text(message);

                function update() {
                    const elapsed = Date.now() - startTime;
                    const percent = Math.min(elapsed / duration, 1);

                    progress = startProgress + (increment * percent);
                    progressBar.css('width', progress + '%');

                    if (percent < 1) {
                        requestAnimationFrame(update);
                    } else {
                        progress = endProgress;
                    }
                }

                update();
            }

            function updateStep(stepNumber, status) {
                const step = steps.filter(`[data-step="${stepNumber}"]`);
                step.removeClass('active completed').addClass(status);

                const icon = step.find('.step-icon');
                if (status === 'completed') {
                    icon.html(
                        '<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>'
                    );
                } else if (status === 'active') {
                    icon.html(stepNumber);
                }
            }
        }

        // Also update your submit button to call this function
        $(document).ready(function() {
            // Add loading class to submit button
            $('.submit-btn').on('click', function(e) {
                e.preventDefault();
                submitJournal();
            });

            // Add CSS for loading button
            const buttonStyle = document.createElement('style');
            buttonStyle.innerHTML = `
            .submit-btn.loading {
                position: relative;
                color: transparent !important;
            }

            .submit-btn.loading::after {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 20px;
                height: 20px;
                border: 2px solid rgba(255, 255, 255, 0.3);
                border-top-color: white;
                border-radius: 50%;
                animation: button-spin 0.8s linear infinite;
            }

            @keyframes button-spin {
                to { transform: translate(-50%, -50%) rotate(360deg); }
            }
        `;
            document.head.appendChild(buttonStyle);
        });
    </script>

    <!-- JOURNAL BOOKLET DATA FETCH -->
    <script>
        function getJournalBookletData() {
            $.ajax({
                url: `/get_journal_booklet_data`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === 200) {
                        const booklet = response.data;
                        const bookletContainer = $('#journal_booklet_id');
                        bookletContainer.empty();

                        bookletContainer.append(`<option value="">Select Journal Booklet</option>`);

                        booklet.forEach(book => {
                            bookletContainer.append(
                                `<option value="${book.sno}">${book.journal_name}</option>`);
                        });
                    } else {
                        console.log('Error Fetching Journal Booklet Data!');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching journal booklet data:', error);
                }
            });
        }
    </script>

    <!-- JOURNAL REVIEW DATA FETCH -->
    <script>
        function getJournalReviewData(id) {
            $.ajax({
                url: `/get_journal_review_data/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {

                    $('#reviewer_comment_err').text('');

                    if (response.status === 200) {
                        $('[data-bs-toggle="tooltip"]').tooltip('dispose');

                        $('#review_journal_id').val(id);
                        $('#reviewed_customer').html(`${response.data.cus_name} (${response.data.customer_id})`)
                            .attr('title', `${response.data.cus_name} (${response.data.customer_id})`);
                        $('#reviewed_services').html(
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`)
                            .attr('title',
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`
                            );
                        $('#reviewed_journal').html(`${response.data.journal_name}`).attr('title',
                            `${response.data.journal_name}`);
                        $('#reviewed_paper').html(`${response.data.paper_name} ( ${response.data.journal_id} )`)
                            .attr('title', `${response.data.paper_name} ( ${response.data.journal_id} )`);
                        $('#reviewed_domain').html(response.data.domain_names.join(', '));

                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.log('Error Fetching Journal Review Data!');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching journal review data:', error);
                }
            });
        }
    </script>

    <!-- REVIEW DROPZONE -->
    <script>
        // File type icons mapping for Review
        const reviewFileIcons = {
            pdf: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 13.5H9m6 3H9m3-6h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>`,
            doc: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
              </svg>`,
            image: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
               </svg>`,
            default: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>`
        };

        const reviewDropArea = document.getElementById("reviewDropArea");
        const reviewFileInput = document.getElementById("reviewFileInput");
        const reviewPreviewList = document.getElementById("reviewPreviewList");
        const reviewPreviewContainer = document.getElementById("reviewPreviewContainer");
        const reviewDropMessage = document.getElementById("reviewDropMessage");
        const reviewFileCount = document.getElementById("reviewFileCount");
        const reviewClearAllBtn = document.getElementById("reviewClearAllBtn");
        let reviewUploadedFiles = [];

        // Get file icon based on type
        function reviewGetFileIcon(file) {
            if (file.type.startsWith('image/')) return reviewFileIcons.image;
            if (file.type === 'application/pdf') return reviewFileIcons.pdf;
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return reviewFileIcons.doc;
            return reviewFileIcons.default;
        }

        // Get file type for badge
        function reviewGetFileType(file) {
            if (file.type.startsWith('image/')) return 'IMG';
            if (file.type === 'application/pdf') return 'PDF';
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return 'DOC';
            return file.name.split('.').pop().toUpperCase();
        }

        // Make whole drop area clickable
        reviewDropArea.addEventListener("click", () => reviewFileInput.click());

        reviewDropArea.addEventListener("dragover", e => {
            e.preventDefault();
            reviewDropArea.classList.add("drag-over");
        });

        reviewDropArea.addEventListener("dragleave", e => {
            e.preventDefault();
            reviewDropArea.classList.remove("drag-over");
        });

        reviewDropArea.addEventListener("drop", e => {
            e.preventDefault();
            reviewDropArea.classList.remove("drag-over");
            if (e.dataTransfer.files.length) {
                reviewHandleFiles(e.dataTransfer.files);
            }
        });

        reviewFileInput.addEventListener("change", e => {
            if (e.target.files.length) {
                reviewHandleFiles(e.target.files);
            }
        });

        // Clear all files
        reviewClearAllBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            e.stopPropagation();

            reviewClearAllBtn.disabled = true;

            // Remove all files from server if stored_name exists
            for (const file of reviewUploadedFiles) {
                if (file.stored_name) {
                    await reviewRemoveFileFromServer(file.stored_name, null); // null because UI will be cleared
                }
            }

            // Clear UI
            reviewPreviewList.innerHTML = '';
            reviewUploadedFiles = [];
            reviewUpdateFileCount();
            reviewPreviewContainer.style.display = 'none';
            reviewDropMessage.style.display = 'block';
            document.getElementById("reviewed_files").value = JSON.stringify([]);

            reviewClearAllBtn.disabled = false;
        });

        function reviewHumanFileSize(size) {
            const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
            return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
        }

        function reviewUpdateFileCount() {
            reviewFileCount.textContent = reviewUploadedFiles.length;
        }

        function reviewHandleFiles(files) {
            reviewDropMessage.style.display = "none";
            reviewPreviewContainer.style.display = "block";

            [...files].forEach(file => {
                if (file.size > 10 * 1024 * 1024) {
                    alert(`File "${file.name}" exceeds 10MB limit`);
                    return;
                }

                const previewItem = document.createElement("div");
                previewItem.className = "review-preview-item";

                // File status badge
                const statusBadge = document.createElement("div");
                statusBadge.className = "review-file-status review-status-uploading";
                statusBadge.textContent = "Uploading";
                previewItem.appendChild(statusBadge);

                // File type badge
                const typeBadge = document.createElement("div");
                typeBadge.className = "review-file-type-badge";
                typeBadge.textContent = reviewGetFileType(file);
                previewItem.appendChild(typeBadge);

                // Remove button
                const removeBtn = document.createElement("button");
                removeBtn.type = "button";
                removeBtn.className = "review-remove-btn";
                removeBtn.innerHTML = "×";
                removeBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    const storedName = previewItem.dataset.storedName;
                    if (storedName) {
                        reviewRemoveFileFromServer(storedName, previewItem);
                    } else {
                        reviewPreviewList.removeChild(previewItem);
                        reviewUploadedFiles = reviewUploadedFiles.filter(f => f.original_name !== file.name);
                        reviewUpdateFileCount();
                        if (reviewUploadedFiles.length === 0) {
                            reviewPreviewContainer.style.display = 'none';
                            reviewDropMessage.style.display = 'block';
                        }
                        document.getElementById("reviewed_files").value = JSON.stringify(reviewUploadedFiles);
                    }
                };
                previewItem.appendChild(removeBtn);

                // Thumbnail container
                const thumbContainer = document.createElement("div");
                thumbContainer.className = "review-preview-thumb-container";

                if (file.type.startsWith("image/")) {
                    const img = document.createElement("img");
                    img.className = "review-preview-thumb";
                    const reader = new FileReader();
                    reader.onload = e => img.src = e.target.result;
                    reader.readAsDataURL(file);
                    thumbContainer.appendChild(img);
                } else {
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "review-file-icon";
                    fileIcon.innerHTML = reviewGetFileIcon(file);
                    thumbContainer.appendChild(fileIcon);
                }
                previewItem.appendChild(thumbContainer);

                // File name
                const nameDiv = document.createElement("div");
                nameDiv.className = "review-preview-filename";
                nameDiv.title = file.name;
                nameDiv.textContent = file.name.length > 20 ? file.name.substring(0, 20) + '...' : file.name;
                previewItem.appendChild(nameDiv);

                // File size
                const sizeDiv = document.createElement("div");
                sizeDiv.className = "review-preview-size";
                sizeDiv.textContent = reviewHumanFileSize(file.size);
                previewItem.appendChild(sizeDiv);

                // Progress container
                const progressContainer = document.createElement("div");
                progressContainer.className = "review-progress-container";

                const progressBar = document.createElement("div");
                progressBar.className = "review-progress-bar";
                const progressBarInner = document.createElement("div");
                progressBarInner.className = "review-progress-bar-inner";
                progressBar.appendChild(progressBarInner);
                progressContainer.appendChild(progressBar);

                const progressText = document.createElement("div");
                progressText.className = "review-progress-text";
                progressText.textContent = "0%";
                progressContainer.appendChild(progressText);

                previewItem.appendChild(progressContainer);

                // Add temporary file to array (will be updated after upload)
                reviewUploadedFiles.push({
                    original_name: file.name,
                    stored_name: null,
                    path: null
                });

                // Add to preview list
                reviewPreviewList.appendChild(previewItem);

                // Upload file
                reviewUploadFile(file, progressBarInner, progressText, statusBadge, previewItem);
            });

            reviewUpdateFileCount();
        }

        function reviewUploadFile(file, progressElement, progressText, statusBadge, previewItem) {
            const url = "{{ route('upload_journal') }}";
            const formData = new FormData();
            formData.append("file_upload[]", file);

            const xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressElement.style.width = percent + "%";
                    progressText.textContent = percent + "%";
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success && res.files.length > 0) {
                        const uploadedFile = res.files[0];

                        // Store file info on the preview item
                        previewItem.dataset.storedName = uploadedFile.stored_name;

                        // Update the file in uploadedFiles array
                        const fileIndex = reviewUploadedFiles.findIndex(f => f.original_name === uploadedFile
                            .original_name);
                        if (fileIndex !== -1) {
                            reviewUploadedFiles[fileIndex] = uploadedFile;
                        }

                        document.getElementById("reviewed_files").value = JSON.stringify(reviewUploadedFiles);
                        progressElement.style.background = "#10b981";
                        statusBadge.className = "review-file-status review-status-success";
                        statusBadge.textContent = "Uploaded";
                        progressText.textContent = "Complete";

                        // Update the filename display to show original name
                        const nameDiv = previewItem.querySelector('.review-preview-filename');
                        nameDiv.textContent = uploadedFile.original_name.length > 20 ?
                            uploadedFile.original_name.substring(0, 20) + '...' : uploadedFile.original_name;
                        nameDiv.title = uploadedFile.original_name;

                        previewItem.style.borderColor = "#10b981";
                        previewItem.style.boxShadow = "0 0 0 1px #10b981";
                    } else {
                        reviewHandleUploadError(progressElement, statusBadge, progressText, res.message ||
                            'Upload failed');
                    }
                } else {
                    reviewHandleUploadError(progressElement, statusBadge, progressText, 'Upload failed with status ' +
                        xhr.status);
                }
            };

            xhr.onerror = function() {
                reviewHandleUploadError(progressElement, statusBadge, progressText, 'Network error');
            };

            xhr.send(formData);
        }

        async function reviewRemoveFileFromServer(fileName, previewItem) {
            try {
                const response = await fetch("{{ url('/upload/temp/remove') }}", {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: JSON.stringify({
                        file_name: fileName
                    })
                });

                const result = await response.json();

                if (result.success) {
                    if (previewItem) {
                        reviewPreviewList.removeChild(previewItem);
                        reviewUploadedFiles = reviewUploadedFiles.filter(f => f.stored_name !== fileName);
                        reviewUpdateFileCount();
                        if (reviewUploadedFiles.length === 0) {
                            reviewPreviewContainer.style.display = "none";
                            reviewDropMessage.style.display = "block";
                        }
                        document.getElementById("reviewed_files").value = JSON.stringify(reviewUploadedFiles);
                    }
                    return true;
                } else {
                    toastr.error(result.message || 'Failed to remove file');
                    return false;
                }
            } catch (error) {
                toastr.error(error.message || 'Error removing file');
                return false;
            }
        }

        function reviewHandleUploadError(progressElement, statusBadge, progressText, message) {
            progressElement.style.background = "var(--danger-red)";
            statusBadge.className = "review-file-status review-status-error";
            statusBadge.textContent = "Error";
            progressText.textContent = "Failed";
            toastr.error(message || 'Upload failed');
        }

        // Initialize with any existing files from hidden input
        document.addEventListener('DOMContentLoaded', () => {
            const existingFiles = JSON.parse(document.getElementById("reviewed_files").value || '[]');
            if (existingFiles.length > 0) {
                // Display already uploaded files
                reviewPreviewContainer.style.display = "block";
                reviewDropMessage.style.display = "none";

                existingFiles.forEach(file => {
                    reviewCreatePreviewForExistingFile(file);
                });

                reviewUploadedFiles = existingFiles;
                reviewUpdateFileCount();
            }
        });

        function reviewCreatePreviewForExistingFile(fileData) {
            const previewItem = document.createElement("div");
            previewItem.className = "review-preview-item";
            previewItem.dataset.storedName = fileData.stored_name;

            // File status badge
            const statusBadge = document.createElement("div");
            statusBadge.className = "review-file-status review-status-success";
            statusBadge.textContent = "Uploaded";
            previewItem.appendChild(statusBadge);

            // File type badge
            const typeBadge = document.createElement("div");
            typeBadge.className = "review-file-type-badge";
            const fileExt = fileData.original_name.split('.').pop().toUpperCase();
            typeBadge.textContent = ['PDF', 'DOC', 'DOCX', 'JPG', 'JPEG', 'PNG', 'GIF'].includes(fileExt) ?
                fileExt : fileExt;
            previewItem.appendChild(typeBadge);

            // Remove button
            const removeBtn = document.createElement("button");
            removeBtn.className = "review-remove-btn";
            removeBtn.innerHTML = "×";
            removeBtn.onclick = async (e) => {
                e.preventDefault();
                e.stopPropagation();

                const storedName = fileData.stored_name;
                await reviewRemoveFileFromServer(storedName, previewItem);
            };
            previewItem.appendChild(removeBtn);

            // Thumbnail container
            const thumbContainer = document.createElement("div");
            thumbContainer.className = "review-preview-thumb-container";

            // Check if it's an image
            const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileData.original_name.split('.').pop()
                .toLowerCase());

            if (isImage && fileData.path) {
                // Try to load image from path
                const img = document.createElement("img");
                img.className = "review-preview-thumb";
                img.src = "{{ asset('') }}" + fileData.path;
                img.onerror = function() {
                    // If image fails to load, show file icon
                    thumbContainer.innerHTML = '';
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "review-file-icon";
                    fileIcon.innerHTML = reviewFileIcons.image;
                    thumbContainer.appendChild(fileIcon);
                };
                thumbContainer.appendChild(img);
            } else {
                const fileIcon = document.createElement("div");
                fileIcon.className = "review-file-icon";
                const fileExt = fileData.original_name.split('.').pop().toLowerCase();
                if (fileExt === 'pdf') {
                    fileIcon.innerHTML = reviewFileIcons.pdf;
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon.innerHTML = reviewFileIcons.doc;
                } else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileExt)) {
                    fileIcon.innerHTML = reviewFileIcons.image;
                } else {
                    fileIcon.innerHTML = reviewFileIcons.default;
                }
                thumbContainer.appendChild(fileIcon);
            }
            previewItem.appendChild(thumbContainer);

            // File name
            const nameDiv = document.createElement("div");
            nameDiv.className = "review-preview-filename";
            nameDiv.title = fileData.original_name;
            nameDiv.textContent = fileData.original_name.length > 20 ?
                fileData.original_name.substring(0, 20) + '...' : fileData.original_name;
            previewItem.appendChild(nameDiv);

            // File size (if available)
            const sizeDiv = document.createElement("div");
            sizeDiv.className = "review-preview-size";
            sizeDiv.textContent = fileData.size ? reviewHumanFileSize(fileData.size) : 'Size unknown';
            previewItem.appendChild(sizeDiv);

            reviewPreviewList.appendChild(previewItem);
        }

        function validateReviewForm() {
            const reviewerComment = $('#reviewer_comment').val();
            let reviewErr = false;

            $('#reviewer_comment_err').text('');

            if (reviewerComment === "") {
                $('#reviewer_comment_err').text("Revision comment is required!");
                reviewErr = true;
            }

            if (reviewErr) {
                return false;
            } else {
                // Show Google Drive loader
                showGoogleDriveLoader();

                $.ajax({
                    url: '/journal_review_status/' + $('#review_journal_id').val(),
                    method: 'POST',
                    data: {
                        reviewer_comment: reviewerComment,
                        reviewed_files: JSON.stringify(reviewUploadedFiles),
                        reviewed_date: $('#journal_reviewed_date').val(),
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        hideGoogleDriveLoader();
                        if (response.status === 200) {
                            toastr.success('Revision submitted successfully!');
                            setTimeout(() => {
                                location.reload();
                            }, 1500);
                        } else {
                            console.log('Error Submitting Review:', response.message);
                            toastr.error('Error submitting review');
                        }
                    },
                    error: function(xhr, status, error) {
                        hideGoogleDriveLoader();
                        console.error('Error submitting review:', error);
                        toastr.error('Error submitting review');
                    }
                });
            }

            return true;
        }
    </script>

    <!-- JOURNAL RESUBMITTED DATA FETCH -->
    <script>
        function getJournalResubmitData(id) {
            $.ajax({
                url: `/get_journal_resubmit_data/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === 200) {
                        $('#resubmit_journal_id').val(id);
                        $('#resubmitted_customer').html(
                            `${response.data.cus_name} (${response.data.customer_id})`).attr('title',
                            `${response.data.cus_name} (${response.data.customer_id})`);
                        $('#resubmitted_services').html(
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`)
                            .attr('title',
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`
                            );
                        $('#resubmitted_journal').html(`${response.data.journal_name}`).attr('title',
                            `${response.data.journal_name}`);
                        $('#resubmitted_paper').html(
                            `${response.data.paper_name} ( ${response.data.journal_id} )`).attr('title',
                            `${response.data.paper_name} ( ${response.data.journal_id} )`);
                        $('#resubmitted_domain').html(response.data.domain_names.join(', '));
                    } else {
                        console.log('Error Fetching Journal Review Data!');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching journal review data:', error);
                }
            });
        }
    </script>

    <!-- RESUBMIT JOURNAL SUBVMIT -->
    <script>
        function submitResubmitForm() {

            const resubmittedDate = $('#journal_resubmitted_date').val();

            $.ajax({
                url: '/journal_resubmit_status/' + $('#resubmit_journal_id').val(),
                method: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    resubmitted_date: resubmittedDate
                },
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success('Journal resubmitted successfully!');
                        location.reload();
                    } else {
                        console.log('Error Resubmitting Journal:', response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error resubmitting journal:', error);
                }
            });
        }
    </script>

    <!-- JOURNAL ACCEPTED DATA FETCH -->
    <script>
        function getJournalAcceptData(id) {
            $.ajax({
                url: `/get_journal_accept_data/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === 200) {
                        $('#accepted_journal_id').val(id);
                        $('#accepted_customer').html(`${response.data.cus_name} (${response.data.customer_id})`)
                            .attr('title', `${response.data.cus_name} (${response.data.customer_id})`);
                        $('#accepted_services').html(
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`)
                            .attr('title',
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`
                            );
                        $('#accepted_journal').html(`${response.data.journal_name}`).attr('title',
                            `${response.data.journal_name}`);
                        $('#accepted_paper').html(`${response.data.paper_name} ( ${response.data.journal_id} )`)
                            .attr('title', `${response.data.paper_name} ( ${response.data.journal_id} )`);
                        $('#accepted_domain').html(response.data.domain_names.join(', '));
                    } else {
                        console.log('Error Fetching Journal Review Data!');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching journal review data:', error);
                }
            });
        }
    </script>

    <script>
        // File type icons mapping for Accepted
        const acceptedFileIcons = {
            pdf: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 13.5H9m6 3H9m3-6h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>`,
            doc: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
              </svg>`,
            image: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
               </svg>`,
            default: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>`
        };

        const acceptedDropArea = document.getElementById("acceptedDropArea");
        const acceptedFileInput = document.getElementById("acceptedFileInput");
        const acceptedPreviewList = document.getElementById("acceptedPreviewList");
        const acceptedPreviewContainer = document.getElementById("acceptedPreviewContainer");
        const acceptedDropMessage = document.getElementById("acceptedDropMessage");
        const acceptedFileCount = document.getElementById("acceptedFileCount");
        const acceptedClearAllBtn = document.getElementById("acceptedClearAllBtn");
        let acceptedUploadedFiles = [];

        // Get file icon based on type
        function acceptedGetFileIcon(file) {
            if (file.type.startsWith('image/')) return acceptedFileIcons.image;
            if (file.type === 'application/pdf') return acceptedFileIcons.pdf;
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return acceptedFileIcons.doc;
            return acceptedFileIcons.default;
        }

        // Get file type for badge
        function acceptedGetFileType(file) {
            if (file.type.startsWith('image/')) return 'IMG';
            if (file.type === 'application/pdf') return 'PDF';
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return 'DOC';
            return file.name.split('.').pop().toUpperCase();
        }

        // Make whole drop area clickable
        acceptedDropArea.addEventListener("click", () => acceptedFileInput.click());

        acceptedDropArea.addEventListener("dragover", e => {
            e.preventDefault();
            acceptedDropArea.classList.add("drag-over");
        });

        acceptedDropArea.addEventListener("dragleave", e => {
            e.preventDefault();
            acceptedDropArea.classList.remove("drag-over");
        });

        acceptedDropArea.addEventListener("drop", e => {
            e.preventDefault();
            acceptedDropArea.classList.remove("drag-over");
            if (e.dataTransfer.files.length) {
                acceptedHandleFiles(e.dataTransfer.files);
            }
        });

        acceptedFileInput.addEventListener("change", e => {
            if (e.target.files.length) {
                acceptedHandleFiles(e.target.files);
            }
        });

        // Clear all files
        acceptedClearAllBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            e.stopPropagation();

            acceptedClearAllBtn.disabled = true;

            for (const file of acceptedUploadedFiles) {
                if (file.stored_name) {
                    await acceptedRemoveFileFromServer(file.stored_name, null);
                }
            }

            acceptedPreviewList.innerHTML = '';
            acceptedUploadedFiles = [];
            acceptedUpdateFileCount();
            acceptedPreviewContainer.style.display = 'none';
            acceptedDropMessage.style.display = 'block';
            document.getElementById("accepted_files").value = JSON.stringify([]);

            acceptedClearAllBtn.disabled = false;
        });

        function acceptedHumanFileSize(size) {
            const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
            return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
        }

        function acceptedUpdateFileCount() {
            acceptedFileCount.textContent = acceptedUploadedFiles.length;
        }

        function acceptedHandleFiles(files) {
            acceptedDropMessage.style.display = "none";
            acceptedPreviewContainer.style.display = "block";

            [...files].forEach(file => {
                if (file.size > 10 * 1024 * 1024) {
                    toastr.error(`File "${file.name}" exceeds 10MB limit`);
                    return;
                }

                const previewItem = document.createElement("div");
                previewItem.className = "accepted-preview-item";

                // File status badge
                const statusBadge = document.createElement("div");
                statusBadge.className = "accepted-file-status accepted-status-uploading";
                statusBadge.textContent = "Uploading";
                previewItem.appendChild(statusBadge);

                // File type badge
                const typeBadge = document.createElement("div");
                typeBadge.className = "accepted-file-type-badge";
                typeBadge.textContent = acceptedGetFileType(file);
                previewItem.appendChild(typeBadge);

                // Remove button
                const removeBtn = document.createElement("button");
                removeBtn.type = "button";
                removeBtn.className = "accepted-remove-btn";
                removeBtn.innerHTML = "×";
                removeBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    const storedName = previewItem.dataset.storedName;
                    if (storedName) {
                        acceptedRemoveFileFromServer(storedName, previewItem);
                    } else {
                        acceptedPreviewList.removeChild(previewItem);
                        acceptedUploadedFiles = acceptedUploadedFiles.filter(f => f.original_name !== file
                            .name);
                        acceptedUpdateFileCount();

                        if (acceptedUploadedFiles.length === 0) {
                            acceptedPreviewContainer.style.display = "none";
                            acceptedDropMessage.style.display = "block";
                        }

                        document.getElementById("accepted_files").value =
                            JSON.stringify(acceptedUploadedFiles);
                    }
                };
                previewItem.appendChild(removeBtn);

                // Thumbnail container
                const thumbContainer = document.createElement("div");
                thumbContainer.className = "accepted-preview-thumb-container";

                if (file.type.startsWith("image/")) {
                    const img = document.createElement("img");
                    img.className = "accepted-preview-thumb";
                    const reader = new FileReader();
                    reader.onload = e => img.src = e.target.result;
                    reader.readAsDataURL(file);
                    thumbContainer.appendChild(img);
                } else {
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "accepted-file-icon";
                    fileIcon.innerHTML = acceptedGetFileIcon(file);
                    thumbContainer.appendChild(fileIcon);
                }
                previewItem.appendChild(thumbContainer);

                // File name
                const nameDiv = document.createElement("div");
                nameDiv.className = "accepted-preview-filename";
                nameDiv.title = file.name;
                nameDiv.textContent = file.name.length > 20 ? file.name.substring(0, 20) + '...' : file.name;
                previewItem.appendChild(nameDiv);

                // File size
                const sizeDiv = document.createElement("div");
                sizeDiv.className = "accepted-preview-size";
                sizeDiv.textContent = acceptedHumanFileSize(file.size);
                previewItem.appendChild(sizeDiv);

                // Progress container
                const progressContainer = document.createElement("div");
                progressContainer.className = "accepted-progress-container";

                const progressBar = document.createElement("div");
                progressBar.className = "accepted-progress-bar";
                const progressBarInner = document.createElement("div");
                progressBarInner.className = "accepted-progress-bar-inner";
                progressBar.appendChild(progressBarInner);
                progressContainer.appendChild(progressBar);

                const progressText = document.createElement("div");
                progressText.className = "accepted-progress-text";
                progressText.textContent = "0%";
                progressContainer.appendChild(progressText);

                previewItem.appendChild(progressContainer);

                // Add temporary file to array (will be updated after upload)
                acceptedUploadedFiles.push({
                    original_name: file.name,
                    stored_name: null,
                    path: null
                });

                // Add to preview list
                acceptedPreviewList.appendChild(previewItem);

                // Upload file
                acceptedUploadFile(file, progressBarInner, progressText, statusBadge, previewItem);
            });

            acceptedUpdateFileCount();
        }

        function acceptedUploadFile(file, progressElement, progressText, statusBadge, previewItem) {
            // FIXED: Corrected the route name - removed extra 's' from 'accepted_journalsss'
            const url = "{{ route('upload_journal') }}"; // Changed from 'accepted_journalsss' to 'upload_journal'
            const formData = new FormData();
            formData.append("file_upload[]", file);

            const xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressElement.style.width = percent + "%";
                    progressText.textContent = percent + "%";
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success && res.files.length > 0) {
                        const uploadedFile = res.files[0];

                        // Store file info on the preview item
                        previewItem.dataset.storedName = uploadedFile.stored_name;

                        // Update the file in uploadedFiles array
                        const fileIndex = acceptedUploadedFiles.findIndex(f => f.original_name === uploadedFile
                            .original_name);
                        if (fileIndex !== -1) {
                            acceptedUploadedFiles[fileIndex] = uploadedFile;
                        }

                        document.getElementById("accepted_files").value = JSON.stringify(acceptedUploadedFiles);
                        progressElement.style.background = "#10b981";
                        statusBadge.className = "accepted-file-status accepted-status-success";
                        statusBadge.textContent = "Uploaded";
                        progressText.textContent = "Complete";

                        // Update the filename display to show original name
                        const nameDiv = previewItem.querySelector('.accepted-preview-filename');
                        nameDiv.textContent = uploadedFile.original_name.length > 20 ?
                            uploadedFile.original_name.substring(0, 20) + '...' : uploadedFile.original_name;
                        nameDiv.title = uploadedFile.original_name;

                        previewItem.style.borderColor = "#10b981";
                        previewItem.style.boxShadow = "0 0 0 1px #10b981";
                    } else {
                        acceptedHandleUploadError(progressElement, statusBadge, progressText, res.message ||
                            'Upload failed');
                    }
                } else {
                    acceptedHandleUploadError(progressElement, statusBadge, progressText, 'Upload failed with status ' +
                        xhr.status);
                }
            };

            xhr.onerror = function() {
                acceptedHandleUploadError(progressElement, statusBadge, progressText, 'Network error');
            };

            xhr.send(formData);
        }

        async function acceptedRemoveFileFromServer(fileName, previewItem) {
            try {
                // FIXED: Changed from 'route' to 'url' and updated endpoint
                const response = await fetch("{{ url('/upload/temp/remove') }}", {
                    method: 'DELETE', // Changed from POST to DELETE
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: JSON.stringify({
                        file_name: fileName
                    })
                });

                const result = await response.json();

                if (result.success) {
                    if (previewItem) {
                        // Remove from UI
                        acceptedPreviewList.removeChild(previewItem);
                        acceptedUploadedFiles = acceptedUploadedFiles.filter(f => f.stored_name !== fileName);
                        acceptedUpdateFileCount();
                        if (acceptedUploadedFiles.length === 0) {
                            acceptedPreviewContainer.style.display = "none";
                            acceptedDropMessage.style.display = "block";
                        }
                        document.getElementById("accepted_files").value = JSON.stringify(acceptedUploadedFiles);
                    }
                    toastr.success('File removed successfully');
                    return true;
                } else {
                    toastr.error('Failed to remove file: ' + (result.message || 'Unknown error'));
                    return false;
                }
            } catch (error) {
                toastr.error('Error removing file: ' + error.message);
                return false;
            }
        }

        function acceptedHandleUploadError(progressElement, statusBadge, progressText, message) {
            progressElement.style.background = "var(--danger-red)";
            statusBadge.className = "accepted-file-status accepted-status-error";
            statusBadge.textContent = "Error";
            progressText.textContent = "Failed";
            toastr.error("Upload failed: " + message);
        }

        // Initialize with any existing files from hidden input
        document.addEventListener('DOMContentLoaded', () => {
            const existingFiles = JSON.parse(document.getElementById("accepted_files").value || '[]');
            if (existingFiles.length > 0) {
                // Display already uploaded files
                acceptedPreviewContainer.style.display = "block";
                acceptedDropMessage.style.display = "none";

                existingFiles.forEach(file => {
                    acceptedCreatePreviewForExistingFile(file);
                });

                acceptedUploadedFiles = existingFiles;
                acceptedUpdateFileCount();
            }
        });

        function acceptedCreatePreviewForExistingFile(fileData) {
            const previewItem = document.createElement("div");
            previewItem.className = "accepted-preview-item";
            previewItem.dataset.storedName = fileData.stored_name;

            // File status badge
            const statusBadge = document.createElement("div");
            statusBadge.className = "accepted-file-status accepted-status-success";
            statusBadge.textContent = "Uploaded";
            previewItem.appendChild(statusBadge);

            // File type badge
            const typeBadge = document.createElement("div");
            typeBadge.className = "accepted-file-type-badge";
            const fileExt = fileData.original_name.split('.').pop().toUpperCase();
            typeBadge.textContent = ['PDF', 'DOC', 'DOCX', 'JPG', 'JPEG', 'PNG', 'GIF'].includes(fileExt) ?
                fileExt : fileExt;
            previewItem.appendChild(typeBadge);

            // Remove button
            const removeBtn = document.createElement("button");
            removeBtn.className = "accepted-remove-btn";
            removeBtn.innerHTML = "×";
            removeBtn.onclick = async (e) => {
                e.preventDefault();
                e.stopPropagation();

                const storedName = fileData.stored_name;
                await acceptedRemoveFileFromServer(storedName, previewItem);
            };

            previewItem.appendChild(removeBtn);

            // Thumbnail container
            const thumbContainer = document.createElement("div");
            thumbContainer.className = "accepted-preview-thumb-container";

            // Check if it's an image
            const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileData.original_name.split('.').pop()
                .toLowerCase());

            if (isImage && fileData.path) {
                // Try to load image from path
                const img = document.createElement("img");
                img.className = "accepted-preview-thumb";
                img.src = "{{ asset('') }}" + fileData.path;
                img.onerror = function() {
                    // If image fails to load, show file icon
                    thumbContainer.innerHTML = '';
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "accepted-file-icon";
                    fileIcon.innerHTML = acceptedFileIcons.image;
                    thumbContainer.appendChild(fileIcon);
                };
                thumbContainer.appendChild(img);
            } else {
                const fileIcon = document.createElement("div");
                fileIcon.className = "accepted-file-icon";
                const fileExt = fileData.original_name.split('.').pop().toLowerCase();
                if (fileExt === 'pdf') {
                    fileIcon.innerHTML = acceptedFileIcons.pdf;
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon.innerHTML = acceptedFileIcons.doc;
                } else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileExt)) {
                    fileIcon.innerHTML = acceptedFileIcons.image;
                } else {
                    fileIcon.innerHTML = acceptedFileIcons.default;
                }
                thumbContainer.appendChild(fileIcon);
            }
            previewItem.appendChild(thumbContainer);

            // File name
            const nameDiv = document.createElement("div");
            nameDiv.className = "accepted-preview-filename";
            nameDiv.title = fileData.original_name;
            nameDiv.textContent = fileData.original_name.length > 20 ?
                fileData.original_name.substring(0, 20) + '...' : fileData.original_name;
            previewItem.appendChild(nameDiv);

            // File size (if available)
            const sizeDiv = document.createElement("div");
            sizeDiv.className = "accepted-preview-size";
            sizeDiv.textContent = fileData.size ? acceptedHumanFileSize(fileData.size) : 'Size unknown';
            previewItem.appendChild(sizeDiv);

            acceptedPreviewList.appendChild(previewItem);
        }

        function validateAcceptedForm() {
            const acceptedComment = $('#accepted_comment').val();
            let acceptedErr = false;

            $('#accepted_comment_err').text('');

            if (acceptedComment === "") {
                $('#accepted_comment_err').text("Accepted comment is required!");
                acceptedErr = true;
            }

            if (acceptedErr) {
                return false;
            } else {
                // Show Google Drive loader
                showGoogleDriveLoader();

                $.ajax({
                    url: '/journal_accept_status/' + $('#accepted_journal_id').val(),
                    method: 'POST',
                    data: {
                        accepted_comment: acceptedComment,
                        accepted_files: JSON.stringify(acceptedUploadedFiles),
                        accepted_date: $('#journal_accepted_date').val(),
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        hideGoogleDriveLoader();
                        if (response.status === 200) {
                            toastr.success('Accepted Status Submitted Successfully!');
                            setTimeout(() => {
                                location.reload();
                            }, 1500);
                        } else {
                            console.log('Error Submitting Accepted:', response.message);
                            toastr.error('Error submitting accepted status');
                        }
                    },
                    error: function(xhr, status, error) {
                        hideGoogleDriveLoader();
                        console.error('Error submitting accepted status:', error);
                        toastr.error('Error submitting accepted status');
                    }
                });
            }

            return true;
        }
    </script>

    <!-- Filter By Status -->
    {{-- <script>
   function filterByStatus(element, status) {
        const url = new URL(window.location.href);

        if (status !== undefined && status !== null) {
            url.searchParams.set('status', status);
        } else {
            url.searchParams.delete('status');
        }

        url.searchParams.delete('page');

        // Store the active status before navigation
        sessionStorage.setItem('activeStageStatus', status);
        sessionStorage.setItem('activeStageLabel', element.querySelector('.stage-label').textContent);
        if (element.classList.contains('active')) {
            element.classList.remove('active');
            // redirect to default page
            window.location.href = "{{ url('/journal_management/manage_journal') }}";
        }
        window.location.href = url.toString();
    }

    // Set active card based on URL parameter on page load
    document.addEventListener('DOMContentLoaded', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const statusParam = urlParams.get('status');

        if (statusParam !== null) {
            // Find the card with matching status
            const cards = document.querySelectorAll('.stage-card');
            cards.forEach(card => {
                // Check onclick attribute for the status
                const onclickAttr = card.getAttribute('onclick');
                if (onclickAttr) {
                    const match = onclickAttr.match(/filterByStatus\(this,\s*(\d+)\)/);
                    if (match && match[1] === statusParam) {
                        card.classList.add('active');
                    } else {
                        card.classList.remove('active');
                    }
                }
            });
        } else {
            // If no status param, check sessionStorage
            const storedStatus = sessionStorage.getItem('activeStageStatus');
            if (storedStatus !== null) {
                const cards = document.querySelectorAll('.stage-card');
                cards.forEach(card => {
                    const onclickAttr = card.getAttribute('onclick');
                    if (onclickAttr) {
                        const match = onclickAttr.match(/filterByStatus\(this,\s*(\d+)\)/);
                        if (match && match[1] === storedStatus) {
                            card.classList.add('active');
                        } else {
                            card.classList.remove('active');
                        }
                    }
                });
            } else {
                // Default: first card is active
                const firstCard = document.querySelector('.stage-card');
                if (firstCard) {
                    firstCard.classList.add('active');
                }
            }
        }

        // Clean URL but keep visual state
        if (window.location.search.includes('status=')) {
            const cleanUrl = window.location.pathname + window.location.search.replace(/[?&]status=[^&]*(&|$)/, '$1').replace(/[?&]$/, '');
            history.replaceState({}, document.title, cleanUrl);
        }
    });
</script> --}}



    <!-- JOURNAL REJECTED DATA FETCH -->
    <script>
        function getJournalRejectData(id) {
            $.ajax({
                url: `/get_journal_reject_data/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {

                    $('#rejected_reason_error').text('');

                    if (response.status === 200) {
                        $('[data-bs-toggle="tooltip"]').tooltip('dispose');

                        $('#journal_reject_id').val(id);
                        $('#rejected_customer').html(`${response.data.cus_name} (${response.data.customer_id})`)
                            .attr('title', `${response.data.cus_name} (${response.data.customer_id})`);
                        $('#rejected_service').html(
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`)
                            .attr('title',
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`
                            );
                        $('#rejected_journal_name').html(`${response.data.journal_name}`).attr('title',
                            `${response.data.journal_name}`);
                        $('#rejected_paper_name').html(
                            `${response.data.paper_name} ( ${response.data.journal_id} )`).attr('title',
                            `${response.data.paper_name} ( ${response.data.journal_id} )`);
                        $('#rejected_domains').html(response.data.domain_names.join(', '));

                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.log('Error Fetching Journal Review Data!');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching journal review data:', error);
                }
            });
        }
    </script>

    <script>
        // File type icons mapping for Rejected
        const rejectedFileIcons = {
            pdf: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 13.5H9m6 3H9m3-6h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>`,
            doc: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
              </svg>`,
            image: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
               </svg>`,
            default: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>`
        };

        const rejectedDropArea = document.getElementById("rejectedDropArea");
        const rejectedFileInput = document.getElementById("rejectedFileInput");
        const rejectedPreviewList = document.getElementById("rejectedPreviewList");
        const rejectedPreviewContainer = document.getElementById("rejectedPreviewContainer");
        const rejectedDropMessage = document.getElementById("rejectedDropMessage");
        const rejectedFileCount = document.getElementById("rejectedFileCount");
        const rejectedClearAllBtn = document.getElementById("rejectedClearAllBtn");
        let rejectedUploadedFiles = []; // FIXED: Changed from rejectedUploadFiles to rejectedUploadedFiles for consistency

        // Get file icon based on type
        function rejectedGetFileIcon(file) {
            if (file.type.startsWith('image/')) return rejectedFileIcons.image;
            if (file.type === 'application/pdf') return rejectedFileIcons.pdf;
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return rejectedFileIcons.doc;
            return rejectedFileIcons.default;
        }

        // Get file type for badge
        function rejectedGetFileType(file) {
            if (file.type.startsWith('image/')) return 'IMG';
            if (file.type === 'application/pdf') return 'PDF';
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return 'DOC';
            return file.name.split('.').pop().toUpperCase();
        }

        // Make whole drop area clickable
        rejectedDropArea.addEventListener("click", () => rejectedFileInput.click());

        rejectedDropArea.addEventListener("dragover", e => {
            e.preventDefault();
            rejectedDropArea.classList.add("drag-over");
        });

        rejectedDropArea.addEventListener("dragleave", e => {
            e.preventDefault();
            rejectedDropArea.classList.remove("drag-over");
        });

        rejectedDropArea.addEventListener("drop", e => {
            e.preventDefault();
            rejectedDropArea.classList.remove("drag-over");
            if (e.dataTransfer.files.length) {
                rejectedHandleFiles(e.dataTransfer.files);
            }
        });

        rejectedFileInput.addEventListener("change", e => {
            if (e.target.files.length) {
                rejectedHandleFiles(e.target.files);
            }
        });

        // Clear all files
        rejectedClearAllBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            e.stopPropagation();

            rejectedClearAllBtn.disabled = true;

            for (const file of rejectedUploadedFiles) {
                if (file.stored_name) {
                    await rejectedRemoveFileFromServer(file.stored_name, null);
                }
            }

            rejectedPreviewList.innerHTML = '';
            rejectedUploadedFiles = [];
            rejectedUpdateFileCount();
            rejectedPreviewContainer.style.display = 'none';
            rejectedDropMessage.style.display = 'block';
            document.getElementById("rejected_files").value = JSON.stringify([]);

            rejectedClearAllBtn.disabled = false;
        });


        function rejectedHumanFileSize(size) {
            const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
            return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
        }

        function rejectedUpdateFileCount() {
            rejectedFileCount.textContent = rejectedUploadedFiles.length;
        }

        function rejectedHandleFiles(files) {
            rejectedDropMessage.style.display = "none";
            rejectedPreviewContainer.style.display = "block";

            [...files].forEach(file => {
                if (file.size > 10 * 1024 * 1024) {
                    toastr.error(`File "${file.name}" exceeds 10MB limit`);
                    return;
                }

                const previewItem = document.createElement("div");
                previewItem.className = "rejected-preview-item";

                // File status badge
                const statusBadge = document.createElement("div");
                statusBadge.className = "rejected-file-status rejected-status-uploading";
                statusBadge.textContent = "Uploading";
                previewItem.appendChild(statusBadge);

                // File type badge
                const typeBadge = document.createElement("div");
                typeBadge.className = "rejected-file-type-badge";
                typeBadge.textContent = rejectedGetFileType(file);
                previewItem.appendChild(typeBadge);

                // Remove button
                const removeBtn = document.createElement("button");
                removeBtn.type = "button";
                removeBtn.className = "rejected-remove-btn";
                removeBtn.innerHTML = "×";
                removeBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    const storedName = previewItem.dataset.storedName;
                    if (storedName) {
                        rejectedRemoveFileFromServer(storedName, previewItem);
                    } else {
                        rejectedPreviewList.removeChild(previewItem);
                        rejectedUploadedFiles =
                            rejectedUploadedFiles.filter(f => f.original_name !== file.name);

                        rejectedUpdateFileCount();

                        if (rejectedUploadedFiles.length === 0) {
                            rejectedPreviewContainer.style.display = "none";
                            rejectedDropMessage.style.display = "block";
                        }

                        document.getElementById("rejected_files").value =
                            JSON.stringify(rejectedUploadedFiles);
                    }

                };
                previewItem.appendChild(removeBtn);

                // Thumbnail container
                const thumbContainer = document.createElement("div");
                thumbContainer.className = "rejected-preview-thumb-container";

                if (file.type.startsWith("image/")) {
                    const img = document.createElement("img");
                    img.className = "rejected-preview-thumb";
                    const reader = new FileReader();
                    reader.onload = e => img.src = e.target.result;
                    reader.readAsDataURL(file);
                    thumbContainer.appendChild(img);
                } else {
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "rejected-file-icon";
                    fileIcon.innerHTML = rejectedGetFileIcon(file);
                    thumbContainer.appendChild(fileIcon);
                }
                previewItem.appendChild(thumbContainer);

                // File name
                const nameDiv = document.createElement("div");
                nameDiv.className = "rejected-preview-filename";
                nameDiv.title = file.name;
                nameDiv.textContent = file.name.length > 20 ? file.name.substring(0, 20) + '...' : file.name;
                previewItem.appendChild(nameDiv);

                // File size
                const sizeDiv = document.createElement("div");
                sizeDiv.className = "rejected-preview-size";
                sizeDiv.textContent = rejectedHumanFileSize(file.size);
                previewItem.appendChild(sizeDiv);

                // Progress container
                const progressContainer = document.createElement("div");
                progressContainer.className = "rejected-progress-container";

                const progressBar = document.createElement("div");
                progressBar.className = "rejected-progress-bar";
                const progressBarInner = document.createElement("div");
                progressBarInner.className = "rejected-progress-bar-inner";
                progressBar.appendChild(progressBarInner);
                progressContainer.appendChild(progressBar);

                const progressText = document.createElement("div");
                progressText.className = "rejected-progress-text";
                progressText.textContent = "0%";
                progressContainer.appendChild(progressText);

                previewItem.appendChild(progressContainer);

                // Add temporary file to array (will be updated after upload)
                rejectedUploadedFiles.push({
                    original_name: file.name,
                    stored_name: null,
                    path: null
                });

                // Add to preview list
                rejectedPreviewList.appendChild(previewItem);

                // Upload file
                rejectedUploadFile(file, progressBarInner, progressText, statusBadge, previewItem);
            });

            rejectedUpdateFileCount();
        }

        function rejectedUploadFile(file, progressElement, progressText, statusBadge, previewItem) {
            // FIXED: Changed to consistent upload route
            const url = "{{ route('upload_journal') }}"; // Changed from 'rejected_journals' for consistency
            const formData = new FormData();
            formData.append("file_upload[]", file);

            const xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressElement.style.width = percent + "%";
                    progressText.textContent = percent + "%";
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success && res.files.length > 0) {
                        const uploadedFile = res.files[0];

                        // Store file info on the preview item
                        previewItem.dataset.storedName = uploadedFile.stored_name;

                        // Update the file in uploadedFiles array
                        const fileIndex = rejectedUploadedFiles.findIndex(f => f.original_name === uploadedFile
                            .original_name);
                        if (fileIndex !== -1) {
                            rejectedUploadedFiles[fileIndex] = uploadedFile;
                        }

                        document.getElementById("rejected_files").value = JSON.stringify(rejectedUploadedFiles);
                        progressElement.style.background = "#10b981";
                        statusBadge.className = "rejected-file-status rejected-status-success";
                        statusBadge.textContent = "Uploaded";
                        progressText.textContent = "Complete";

                        // Update the filename display to show original name
                        const nameDiv = previewItem.querySelector('.rejected-preview-filename');
                        nameDiv.textContent = uploadedFile.original_name.length > 20 ?
                            uploadedFile.original_name.substring(0, 20) + '...' : uploadedFile.original_name;
                        nameDiv.title = uploadedFile.original_name;

                        previewItem.style.borderColor = "#10b981";
                        previewItem.style.boxShadow = "0 0 0 1px #10b981";
                    } else {
                        rejectedHandleUploadError(progressElement, statusBadge, progressText, res.message ||
                            'Upload failed');
                    }
                } else {
                    rejectedHandleUploadError(progressElement, statusBadge, progressText, 'Upload failed with status ' +
                        xhr.status);
                }
            };

            xhr.onerror = function() {
                rejectedHandleUploadError(progressElement, statusBadge, progressText, 'Network error');
            };

            xhr.send(formData);
        }

        async function rejectedRemoveFileFromServer(fileName, previewItem) {
            try {
                // FIXED: Changed to consistent remove endpoint
                const response = await fetch("{{ url('/upload/temp/remove') }}", {
                    method: 'DELETE', // Changed from POST to DELETE
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: JSON.stringify({
                        file_name: fileName
                    })
                });

                const result = await response.json();

                if (result.success) {
                    if (previewItem) {
                        // Remove from UI
                        rejectedPreviewList.removeChild(previewItem);
                        rejectedUploadedFiles = rejectedUploadedFiles.filter(f => f.stored_name !== fileName);
                        rejectedUpdateFileCount();
                        if (rejectedUploadedFiles.length === 0) {
                            rejectedPreviewContainer.style.display = "none";
                            rejectedDropMessage.style.display = "block";
                        }
                        document.getElementById("rejected_files").value = JSON.stringify(rejectedUploadedFiles);
                    }
                    toastr.success('File removed successfully');
                    return true;
                } else {
                    toastr.error('Failed to remove file: ' + (result.message || 'Unknown error'));
                    return false;
                }
            } catch (error) {
                toastr.error('Error removing file: ' + error.message);
                return false;
            }
        }

        function rejectedHandleUploadError(progressElement, statusBadge, progressText, message) {
            progressElement.style.background = "var(--danger-red)";
            statusBadge.className = "rejected-file-status rejected-status-error";
            statusBadge.textContent = "Error";
            progressText.textContent = "Failed";
            toastr.error("Upload failed: " + message);
        }

        // Initialize with any existing files from hidden input
        document.addEventListener('DOMContentLoaded', () => {
            const existingFiles = JSON.parse(document.getElementById("rejected_files").value || '[]');
            if (existingFiles.length > 0) {
                // Display already uploaded files
                rejectedPreviewContainer.style.display = "block";
                rejectedDropMessage.style.display = "none";

                existingFiles.forEach(file => {
                    rejectedCreatePreviewForExistingFile(file);
                });

                rejectedUploadedFiles = existingFiles;
                rejectedUpdateFileCount();
            }
        });

        function rejectedCreatePreviewForExistingFile(fileData) {
            const previewItem = document.createElement("div");
            previewItem.className = "rejected-preview-item";
            previewItem.dataset.storedName = fileData.stored_name;

            // File status badge
            const statusBadge = document.createElement("div");
            statusBadge.className = "rejected-file-status rejected-status-success";
            statusBadge.textContent = "Uploaded";
            previewItem.appendChild(statusBadge);

            // File type badge
            const typeBadge = document.createElement("div");
            typeBadge.className = "rejected-file-type-badge";
            const fileExt = fileData.original_name.split('.').pop().toUpperCase();
            typeBadge.textContent = ['PDF', 'DOC', 'DOCX', 'JPG', 'JPEG', 'PNG', 'GIF'].includes(fileExt) ?
                fileExt : fileExt;
            previewItem.appendChild(typeBadge);

            // Remove button
            const removeBtn = document.createElement("button");
            removeBtn.className = "rejected-remove-btn";
            removeBtn.innerHTML = "×";
            removeBtn.onclick = async (e) => {
                e.preventDefault();
                e.stopPropagation();

                const storedName = fileData.stored_name;
                await rejectedRemoveFileFromServer(storedName, previewItem);

            };
            previewItem.appendChild(removeBtn);

            // Thumbnail container
            const thumbContainer = document.createElement("div");
            thumbContainer.className = "rejected-preview-thumb-container";

            // Check if it's an image
            const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileData.original_name.split('.').pop()
                .toLowerCase());

            if (isImage && fileData.path) {
                // Try to load image from path
                const img = document.createElement("img");
                img.className = "rejected-preview-thumb";
                img.src = "{{ asset('') }}" + fileData.path;
                img.onerror = function() {
                    // If image fails to load, show file icon
                    thumbContainer.innerHTML = '';
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "rejected-file-icon";
                    fileIcon.innerHTML = rejectedFileIcons.image;
                    thumbContainer.appendChild(fileIcon);
                };
                thumbContainer.appendChild(img);
            } else {
                const fileIcon = document.createElement("div");
                fileIcon.className = "rejected-file-icon";
                const fileExt = fileData.original_name.split('.').pop().toLowerCase();
                if (fileExt === 'pdf') {
                    fileIcon.innerHTML = rejectedFileIcons.pdf;
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon.innerHTML = rejectedFileIcons.doc;
                } else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileExt)) {
                    fileIcon.innerHTML = rejectedFileIcons.image;
                } else {
                    fileIcon.innerHTML = rejectedFileIcons.default;
                }
                thumbContainer.appendChild(fileIcon);
            }
            previewItem.appendChild(thumbContainer);

            // File name
            const nameDiv = document.createElement("div");
            nameDiv.className = "rejected-preview-filename";
            nameDiv.title = fileData.original_name;
            nameDiv.textContent = fileData.original_name.length > 20 ?
                fileData.original_name.substring(0, 20) + '...' : fileData.original_name;
            previewItem.appendChild(nameDiv);

            // File size (if available)
            const sizeDiv = document.createElement("div");
            sizeDiv.className = "rejected-preview-size";
            sizeDiv.textContent = fileData.size ? rejectedHumanFileSize(fileData.size) : 'Size unknown';
            previewItem.appendChild(sizeDiv);

            rejectedPreviewList.appendChild(previewItem);
        }

        function validateRejectForm() {
            const rejectReason = $('#rejected_reason').val();
            let rejectErr = false;

            $('#rejected_reason_error').text('');

            if (rejectReason === "") {
                $('#rejected_reason_error').text("Reject reason is required!");
                rejectErr = true;
            }

            if (rejectErr) {
                return false;
            } else {
                // Show Google Drive loader
                showGoogleDriveLoader();

                $.ajax({
                    url: '/journal_reject_status/' + $('#journal_reject_id').val(),
                    method: 'POST',
                    data: {
                        reject_reason: rejectReason,
                        rejected_files: JSON.stringify(rejectedUploadedFiles), // FIXED: Changed variable name
                        rejected_date: $('#journal_rejected_date').val(),
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        hideGoogleDriveLoader();
                        if (response.status === 200) {
                            toastr.success('Journal rejected successfully!');
                            setTimeout(() => {
                                location.reload();
                            }, 1500);
                        } else {
                            console.log('Error Submitting Reject:', response.message);
                            toastr.error('Error submitting reject status');
                        }
                    },
                    error: function(xhr, status, error) {
                        hideGoogleDriveLoader();
                        console.error('Error submitting reject:', error);
                        toastr.error('Error submitting reject status');
                    }
                });
            }

            return true;
        }
    </script>

    <!-- JOURNAL PUBLISHED DATA FETCH -->
    <script>
        function getJournalPublishData(id) {
            $.ajax({
                url: `/get_journal_publish_data/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {

                    $('#publish_date_error, #publish_paper_error, #publish_url_error, #publish_author_error')
                        .text('');

                    if (response.status === 200) {
                        $('[data-bs-toggle="tooltip"]').tooltip('dispose');

                        $('#published_id').val(id);
                        $('#published_customer').html(
                            `${response.data.cus_name} (${response.data.customer_id})`).attr('title',
                            `${response.data.cus_name} (${response.data.customer_id})`);
                        $('#published_services').html(
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`)
                            .attr('title',
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`
                            );
                        $('#published_journal').html(`${response.data.journal_name}`).attr('title',
                            `${response.data.journal_name}`);
                        $('#published_paper').html(
                            `${response.data.paper_name} ( ${response.data.journal_id} )`).attr('title',
                            `${response.data.paper_name} ( ${response.data.journal_id} )`);
                        $('#published_domain').html(response.data.domain_names.join(', '));

                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.log('Error Fetching Journal Review Data!');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching journal review data:', error);
                }
            });
        }
    </script>

    <!-- PUBLISHED DATE PICKER -->
    <script>
        $(document).ready(function() {
            var isRtl = false; // Define this as needed
            if ($('.published_date').length) {
                $('.published_date').datepicker({
                    todayHighlight: true,
                    autoclose: true,
                    format: 'd-M-yyyy',
                    orientation: isRtl ? 'auto right' : 'auto left'
                });
            }
        });
    </script>

    <script>
        // File type icons mapping for Published
        const publishedFileIcons = {
            pdf: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 13.5H9m6 3H9m3-6h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>`,
            doc: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
              </svg>`,
            image: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
               </svg>`,
            default: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>`
        };

        const publishedDropArea = document.getElementById("publishedDropArea");
        const publishedFileInput = document.getElementById("publishedFileInput");
        const publishedPreviewList = document.getElementById("publishedPreviewList");
        const publishedPreviewContainer = document.getElementById("publishedPreviewContainer");
        const publishedDropMessage = document.getElementById("publishedDropMessage");
        const publishedFileCount = document.getElementById("publishedFileCount");
        const publishedClearAllBtn = document.getElementById("publishedClearAllBtn");
        let publishedUploadedFiles = [];

        // Get file icon based on type
        function publishedGetFileIcon(file) {
            if (file.type.startsWith('image/')) return publishedFileIcons.image;
            if (file.type === 'application/pdf') return publishedFileIcons.pdf;
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return publishedFileIcons.doc;
            return publishedFileIcons.default;
        }

        // Get file type for badge
        function publishedGetFileType(file) {
            if (file.type.startsWith('image/')) return 'IMG';
            if (file.type === 'application/pdf') return 'PDF';
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return 'DOC';
            return file.name.split('.').pop().toUpperCase();
        }

        // Make whole drop area clickable
        publishedDropArea.addEventListener("click", () => publishedFileInput.click());

        publishedDropArea.addEventListener("dragover", e => {
            e.preventDefault();
            publishedDropArea.classList.add("drag-over");
        });

        publishedDropArea.addEventListener("dragleave", e => {
            e.preventDefault();
            publishedDropArea.classList.remove("drag-over");
        });

        publishedDropArea.addEventListener("drop", e => {
            e.preventDefault();
            publishedDropArea.classList.remove("drag-over");
            if (e.dataTransfer.files.length) {
                publishedHandleFiles(e.dataTransfer.files);
            }
        });

        publishedFileInput.addEventListener("change", e => {
            if (e.target.files.length) {
                publishedHandleFiles(e.target.files);
            }
        });

        // Clear all files
        publishedClearAllBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            e.stopPropagation();

            publishedClearAllBtn.disabled = true;

            for (const file of publishedUploadedFiles) {
                if (file.stored_name) {
                    await publishedRemoveFileFromServer(file.stored_name, null);
                }
            }

            publishedPreviewList.innerHTML = '';
            publishedUploadedFiles = [];
            publishedUpdateFileCount();
            publishedPreviewContainer.style.display = 'none';
            publishedDropMessage.style.display = 'block';
            document.getElementById("publish_uploaded_files").value = JSON.stringify([]);

            publishedClearAllBtn.disabled = false;
        });


        function publishedHumanFileSize(size) {
            const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
            return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
        }

        function publishedUpdateFileCount() {
            publishedFileCount.textContent = publishedUploadedFiles.length;
        }

        function publishedHandleFiles(files) {
            publishedDropMessage.style.display = "none";
            publishedPreviewContainer.style.display = "block";

            [...files].forEach(file => {
                if (file.size > 10 * 1024 * 1024) {
                    toastr.error(`File "${file.name}" exceeds 10MB limit`);
                    return;
                }

                const previewItem = document.createElement("div");
                previewItem.className = "published-preview-item";

                // File status badge
                const statusBadge = document.createElement("div");
                statusBadge.className = "published-file-status published-status-uploading";
                statusBadge.textContent = "Uploading";
                previewItem.appendChild(statusBadge);

                // File type badge
                const typeBadge = document.createElement("div");
                typeBadge.className = "published-file-type-badge";
                typeBadge.textContent = publishedGetFileType(file);
                previewItem.appendChild(typeBadge);

                // Remove button
                const removeBtn = document.createElement("button");
                removeBtn.type = "button";
                removeBtn.className = "published-remove-btn";
                removeBtn.innerHTML = "×";
                removeBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    const storedName = previewItem.dataset.storedName;
                    if (storedName) {
                        publishedRemoveFileFromServer(storedName, previewItem);
                    } else {
                        publishedPreviewList.removeChild(previewItem);
                        publishedUploadedFiles =
                            publishedUploadedFiles.filter(f => f.original_name !== file.name);

                        publishedUpdateFileCount();

                        if (publishedUploadedFiles.length === 0) {
                            publishedPreviewContainer.style.display = "none";
                            publishedDropMessage.style.display = "block";
                        }

                        document.getElementById("publish_uploaded_files").value =
                            JSON.stringify(publishedUploadedFiles);
                    }

                };
                previewItem.appendChild(removeBtn);

                // Thumbnail container
                const thumbContainer = document.createElement("div");
                thumbContainer.className = "published-preview-thumb-container";

                if (file.type.startsWith("image/")) {
                    const img = document.createElement("img");
                    img.className = "published-preview-thumb";
                    const reader = new FileReader();
                    reader.onload = e => img.src = e.target.result;
                    reader.readAsDataURL(file);
                    thumbContainer.appendChild(img);
                } else {
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "published-file-icon";
                    fileIcon.innerHTML = publishedGetFileIcon(file);
                    thumbContainer.appendChild(fileIcon);
                }
                previewItem.appendChild(thumbContainer);

                // File name
                const nameDiv = document.createElement("div");
                nameDiv.className = "published-preview-filename";
                nameDiv.title = file.name;
                nameDiv.textContent = file.name.length > 20 ? file.name.substring(0, 20) + '...' : file.name;
                previewItem.appendChild(nameDiv);

                // File size
                const sizeDiv = document.createElement("div");
                sizeDiv.className = "published-preview-size";
                sizeDiv.textContent = publishedHumanFileSize(file.size);
                previewItem.appendChild(sizeDiv);

                // Progress container
                const progressContainer = document.createElement("div");
                progressContainer.className = "published-progress-container";

                const progressBar = document.createElement("div");
                progressBar.className = "published-progress-bar";
                const progressBarInner = document.createElement("div");
                progressBarInner.className = "published-progress-bar-inner";
                progressBar.appendChild(progressBarInner);
                progressContainer.appendChild(progressBar);

                const progressText = document.createElement("div");
                progressText.className = "published-progress-text";
                progressText.textContent = "0%";
                progressContainer.appendChild(progressText);

                previewItem.appendChild(progressContainer);

                // Add temporary file to array (will be updated after upload)
                publishedUploadedFiles.push({
                    original_name: file.name,
                    stored_name: null,
                    path: null
                });

                // Add to preview list
                publishedPreviewList.appendChild(previewItem);

                // Upload file
                publishedUploadFile(file, progressBarInner, progressText, statusBadge, previewItem);
            });

            publishedUpdateFileCount();
        }

        function publishedUploadFile(file, progressElement, progressText, statusBadge, previewItem) {
            // FIXED: Changed to consistent upload route
            const url = "{{ route('upload_journal') }}"; // Changed from 'published_files' for consistency
            const formData = new FormData();
            formData.append("file_upload[]",
                file); // Changed from "publish_uploaded_files[]" to "file_upload[]" for consistency

            const xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressElement.style.width = percent + "%";
                    progressText.textContent = percent + "%";
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success && res.files.length > 0) {
                        const uploadedFile = res.files[0];

                        // Store file info on the preview item
                        previewItem.dataset.storedName = uploadedFile.stored_name;

                        // Update the file in uploadedFiles array
                        const fileIndex = publishedUploadedFiles.findIndex(f => f.original_name === uploadedFile
                            .original_name);
                        if (fileIndex !== -1) {
                            publishedUploadedFiles[fileIndex] = uploadedFile;
                        }

                        document.getElementById("publish_uploaded_files").value = JSON.stringify(
                            publishedUploadedFiles);
                        progressElement.style.background = "#10b981";
                        statusBadge.className = "published-file-status published-status-success";
                        statusBadge.textContent = "Uploaded";
                        progressText.textContent = "Complete";

                        // Update the filename display to show original name
                        const nameDiv = previewItem.querySelector('.published-preview-filename');
                        nameDiv.textContent = uploadedFile.original_name.length > 20 ?
                            uploadedFile.original_name.substring(0, 20) + '...' : uploadedFile.original_name;
                        nameDiv.title = uploadedFile.original_name;

                        previewItem.style.borderColor = "#10b981";
                        previewItem.style.boxShadow = "0 0 0 1px #10b981";
                    } else {
                        publishedHandleUploadError(progressElement, statusBadge, progressText, res.message ||
                            'Upload failed');
                    }
                } else {
                    publishedHandleUploadError(progressElement, statusBadge, progressText,
                        'Upload failed with status ' + xhr.status);
                }
            };

            xhr.onerror = function() {
                publishedHandleUploadError(progressElement, statusBadge, progressText, 'Network error');
            };

            xhr.send(formData);
        }

        async function publishedRemoveFileFromServer(fileName, previewItem) {
            try {
                // FIXED: Changed to consistent remove endpoint
                const response = await fetch("{{ url('/upload/temp/remove') }}", {
                    method: 'DELETE', // Changed from POST to DELETE
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: JSON.stringify({
                        file_name: fileName
                    })
                });

                const result = await response.json();

                if (result.success) {
                    if (previewItem) {
                        // Remove from UI
                        publishedPreviewList.removeChild(previewItem);
                        publishedUploadedFiles = publishedUploadedFiles.filter(f => f.stored_name !== fileName);
                        publishedUpdateFileCount();
                        if (publishedUploadedFiles.length === 0) {
                            publishedPreviewContainer.style.display = "none";
                            publishedDropMessage.style.display = "block";
                        }
                        document.getElementById("publish_uploaded_files").value = JSON.stringify(
                            publishedUploadedFiles);
                    }
                    toastr.success('File removed successfully');
                    return true;
                } else {
                    toastr.error('Failed to remove file: ' + (result.message || 'Unknown error'));
                    return false;
                }
            } catch (error) {
                toastr.error('Error removing file: ' + error.message);
                return false;
            }
        }

        function publishedHandleUploadError(progressElement, statusBadge, progressText, message) {
            progressElement.style.background = "var(--danger-red)";
            statusBadge.className = "published-file-status published-status-error";
            statusBadge.textContent = "Error";
            progressText.textContent = "Failed";
            toastr.error("Upload failed: " + message);
        }

        // Initialize with any existing files from hidden input
        document.addEventListener('DOMContentLoaded', () => {
            const existingFiles = JSON.parse(document.getElementById("publish_uploaded_files").value || '[]');
            if (existingFiles.length > 0) {
                // Display already uploaded files
                publishedPreviewContainer.style.display = "block";
                publishedDropMessage.style.display = "none";

                existingFiles.forEach(file => {
                    publishedCreatePreviewForExistingFile(file);
                });

                publishedUploadedFiles = existingFiles;
                publishedUpdateFileCount();
            }
        });

        function publishedCreatePreviewForExistingFile(fileData) {
            const previewItem = document.createElement("div");
            previewItem.className = "published-preview-item";
            previewItem.dataset.storedName = fileData.stored_name;

            // File status badge
            const statusBadge = document.createElement("div");
            statusBadge.className = "published-file-status published-status-success";
            statusBadge.textContent = "Uploaded";
            previewItem.appendChild(statusBadge);

            // File type badge
            const typeBadge = document.createElement("div");
            typeBadge.className = "published-file-type-badge";
            const fileExt = fileData.original_name.split('.').pop().toUpperCase();
            typeBadge.textContent = ['PDF', 'DOC', 'DOCX', 'JPG', 'JPEG', 'PNG', 'GIF'].includes(fileExt) ?
                fileExt : fileExt;
            previewItem.appendChild(typeBadge);

            // Remove button
            const removeBtn = document.createElement("button");
            removeBtn.className = "published-remove-btn";
            removeBtn.innerHTML = "×";
            removeBtn.onclick = async (e) => {
                e.preventDefault();
                e.stopPropagation();

                const storedName = fileData.stored_name;
                await publishedRemoveFileFromServer(storedName, previewItem);

            };
            previewItem.appendChild(removeBtn);

            // Thumbnail container
            const thumbContainer = document.createElement("div");
            thumbContainer.className = "published-preview-thumb-container";

            // Check if it's an image
            const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileData.original_name.split('.').pop()
                .toLowerCase());

            if (isImage && fileData.path) {
                // Try to load image from path
                const img = document.createElement("img");
                img.className = "published-preview-thumb";
                img.src = "{{ asset('') }}" + fileData.path;
                img.onerror = function() {
                    // If image fails to load, show file icon
                    thumbContainer.innerHTML = '';
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "published-file-icon";
                    fileIcon.innerHTML = publishedFileIcons.image;
                    thumbContainer.appendChild(fileIcon);
                };
                thumbContainer.appendChild(img);
            } else {
                const fileIcon = document.createElement("div");
                fileIcon.className = "published-file-icon";
                const fileExt = fileData.original_name.split('.').pop().toLowerCase();
                if (fileExt === 'pdf') {
                    fileIcon.innerHTML = publishedFileIcons.pdf;
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon.innerHTML = publishedFileIcons.doc;
                } else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileExt)) {
                    fileIcon.innerHTML = publishedFileIcons.image;
                } else {
                    fileIcon.innerHTML = publishedFileIcons.default;
                }
                thumbContainer.appendChild(fileIcon);
            }
            previewItem.appendChild(thumbContainer);

            // File name
            const nameDiv = document.createElement("div");
            nameDiv.className = "published-preview-filename";
            nameDiv.title = fileData.original_name;
            nameDiv.textContent = fileData.original_name.length > 20 ?
                fileData.original_name.substring(0, 20) + '...' : fileData.original_name;
            previewItem.appendChild(nameDiv);

            // File size (if available)
            const sizeDiv = document.createElement("div");
            sizeDiv.className = "published-preview-size";
            sizeDiv.textContent = fileData.size ? publishedHumanFileSize(fileData.size) : 'Size unknown';
            previewItem.appendChild(sizeDiv);

            publishedPreviewList.appendChild(previewItem);
        }

        function validatePublishForm() {
            const publishDate = $('#publish_date').val();
            const publishPaperName = $('#publish_paper').val();
            const publishURL = $('#publish_url').val();
            const publishAuthor = $('#publish_author').val();

            // Use the global publishedUploadedFiles variable directly
            const publishedFiles = publishedUploadedFiles;

            let publishErr = false;

            $('#publish_date_error, #publish_paper_error, #publish_url_error, #publish_author_error').text('');

            if (publishDate === "") {
                $('#publish_date_error').text("Publish date is required!");
                publishErr = true;
            }

            if (publishPaperName === "") {
                $('#publish_paper_error').text("Paper name is required!");
                publishErr = true;
            }

            if (publishURL === "") {
                $('#publish_url_error').text("URL is required!");
                publishErr = true;
            }

            if (publishAuthor === "") {
                $('#publish_author_error').text("Author name is required!");
                publishErr = true;
            }

            if (publishErr) {
                return false;
            }

            // Show Google Drive loader
            showGoogleDriveLoader();

            $.ajax({
                url: '/journal_publish_status/' + $('#published_id').val(),
                method: 'POST',
                data: {
                    publish_date: publishDate,
                    paper_name: publishPaperName,
                    publish_url: publishURL,
                    publish_author: publishAuthor,
                    published_files: JSON.stringify(publishedFiles),
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    hideGoogleDriveLoader();
                    if (response.status === 200) {
                        toastr.success('Journal published successfully!');
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        console.log('Error Publishing:', response.message);
                        toastr.error('Error submitting publish status');
                    }
                },
                error: function(xhr, status, error) {
                    hideGoogleDriveLoader();
                    console.error('Error submitting publish:', error);
                    toastr.error('Error submitting publish status');
                }
            });

            return true;
        }
    </script>

    <!-- With Editor Status -->
    <script>
        function getJournalWithEditorData(id) {
            $.ajax({
                url: `/get_journal_review_data/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {

                    if (response.status === 200) {
                        $('[data-bs-toggle="tooltip"]').tooltip('dispose');

                        $('#withEditorId').val(id);
                        $('#withEditorCustomer').html(
                            `${response.data.cus_name} (${response.data.customer_id})`).attr('title',
                            `${response.data.cus_name} (${response.data.customer_id})`);
                        $('#withEditorService').html(
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`)
                            .attr('title',
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`
                            );
                        $('#withEditorJournal').html(`${response.data.journal_name}`).attr('title',
                            `${response.data.journal_name}`);
                        $('#withEditorPaper').html(
                            `${response.data.paper_name} ( ${response.data.journal_id} )`).attr('title',
                            `${response.data.paper_name} ( ${response.data.journal_id} )`);
                        $('#withEditorDomain').html(response.data.domain_names.join(', '));

                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.log('Error Fetching Journal Review Data!');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching journal review data:', error);
                }
            });
        }
    </script>

    <script>
        // File type icons mapping for With Editor
        const withEditorFileIcons = {
            pdf: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 13.5H9m6 3H9m3-6h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>`,
            doc: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
              </svg>`,
            image: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
               </svg>`,
            default: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>`
        };

        const withEditorDropArea = document.getElementById("withEditorDropArea");
        const withEditorFileInput = document.getElementById("withEditorFileInput");
        const withEditorPreviewList = document.getElementById("withEditorPreviewList");
        const withEditorPreviewContainer = document.getElementById("withEditorPreviewContainer");
        const withEditorDropMessage = document.getElementById("withEditorDropMessage");
        const withEditorFileCount = document.getElementById("withEditorFileCount");
        const withEditorClearAllBtn = document.getElementById("withEditorClearAllBtn");
        let withEditorUploadedFiles = [];

        // Get file icon based on type
        function withEditorGetFileIcon(file) {
            if (file.type.startsWith('image/')) return withEditorFileIcons.image;
            if (file.type === 'application/pdf') return withEditorFileIcons.pdf;
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return withEditorFileIcons.doc;
            return withEditorFileIcons.default;
        }

        // Get file type for badge
        function withEditorGetFileType(file) {
            if (file.type.startsWith('image/')) return 'IMG';
            if (file.type === 'application/pdf') return 'PDF';
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return 'DOC';
            return file.name.split('.').pop().toUpperCase();
        }

        // Make whole drop area clickable
        withEditorDropArea.addEventListener("click", () => withEditorFileInput.click());

        withEditorDropArea.addEventListener("dragover", e => {
            e.preventDefault();
            withEditorDropArea.classList.add("drag-over");
        });

        withEditorDropArea.addEventListener("dragleave", e => {
            e.preventDefault();
            withEditorDropArea.classList.remove("drag-over");
        });

        withEditorDropArea.addEventListener("drop", e => {
            e.preventDefault();
            withEditorDropArea.classList.remove("drag-over");
            if (e.dataTransfer.files.length) {
                withEditorHandleFiles(e.dataTransfer.files);
            }
        });

        withEditorFileInput.addEventListener("change", e => {
            if (e.target.files.length) {
                withEditorHandleFiles(e.target.files);
            }
        });

        // Clear all files
        withEditorClearAllBtn.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();

            withEditorPreviewList.innerHTML = '';
            withEditorUploadedFiles = [];
            withEditorUpdateFileCount();
            withEditorPreviewContainer.style.display = 'none';
            withEditorDropMessage.style.display = 'block';
            document.getElementById("withEditorFiles").value = JSON.stringify([]);
        });

        function withEditorHumanFileSize(size) {
            const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
            return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
        }

        function withEditorUpdateFileCount() {
            withEditorFileCount.textContent = withEditorUploadedFiles.length;
        }

        function withEditorHandleFiles(files) {
            withEditorDropMessage.style.display = "none";
            withEditorPreviewContainer.style.display = "block";

            [...files].forEach(file => {
                if (file.size > 10 * 1024 * 1024) {
                    toastr.error(`File "${file.name}" exceeds 10MB limit`);
                    return;
                }

                const previewItem = document.createElement("div");
                previewItem.className = "with-editor-preview-item";

                // File status badge
                const statusBadge = document.createElement("div");
                statusBadge.className = "with-editor-file-status with-editor-status-uploading";
                statusBadge.textContent = "Uploading";
                previewItem.appendChild(statusBadge);

                // File type badge
                const typeBadge = document.createElement("div");
                typeBadge.className = "with-editor-file-type-badge";
                typeBadge.textContent = withEditorGetFileType(file);
                previewItem.appendChild(typeBadge);

                // Remove button
                const removeBtn = document.createElement("button");
                removeBtn.type = "button";
                removeBtn.className = "with-editor-remove-btn";
                removeBtn.innerHTML = "×";
                removeBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    const storedName = previewItem.dataset.storedName;

                    if (storedName) {
                        withEditorRemoveFileFromServer(storedName, previewItem);
                    } else {
                        withEditorPreviewList.removeChild(previewItem);
                        withEditorUploadedFiles =
                            withEditorUploadedFiles.filter(f => f.original_name !== file.name);

                        withEditorUpdateFileCount();

                        if (withEditorUploadedFiles.length === 0) {
                            withEditorPreviewContainer.style.display = "none";
                            withEditorDropMessage.style.display = "block";
                        }

                        document.getElementById("withEditorFiles").value =
                            JSON.stringify(withEditorUploadedFiles);
                    }

                };
                previewItem.appendChild(removeBtn);

                // Thumbnail container
                const thumbContainer = document.createElement("div");
                thumbContainer.className = "with-editor-preview-thumb-container";

                if (file.type.startsWith("image/")) {
                    const img = document.createElement("img");
                    img.className = "with-editor-preview-thumb";
                    const reader = new FileReader();
                    reader.onload = e => img.src = e.target.result;
                    reader.readAsDataURL(file);
                    thumbContainer.appendChild(img);
                } else {
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "with-editor-file-icon";
                    fileIcon.innerHTML = withEditorGetFileIcon(file);
                    thumbContainer.appendChild(fileIcon);
                }
                previewItem.appendChild(thumbContainer);

                // File name
                const nameDiv = document.createElement("div");
                nameDiv.className = "with-editor-preview-filename";
                nameDiv.title = file.name;
                nameDiv.textContent = file.name.length > 20 ? file.name.substring(0, 20) + '...' : file.name;
                previewItem.appendChild(nameDiv);

                // File size
                const sizeDiv = document.createElement("div");
                sizeDiv.className = "with-editor-preview-size";
                sizeDiv.textContent = withEditorHumanFileSize(file.size);
                previewItem.appendChild(sizeDiv);

                // Progress container
                const progressContainer = document.createElement("div");
                progressContainer.className = "with-editor-progress-container";

                const progressBar = document.createElement("div");
                progressBar.className = "with-editor-progress-bar";
                const progressBarInner = document.createElement("div");
                progressBarInner.className = "with-editor-progress-bar-inner";
                progressBar.appendChild(progressBarInner);
                progressContainer.appendChild(progressBar);

                const progressText = document.createElement("div");
                progressText.className = "with-editor-progress-text";
                progressText.textContent = "0%";
                progressContainer.appendChild(progressText);

                previewItem.appendChild(progressContainer);

                // Add temporary file to array (will be updated after upload)
                withEditorUploadedFiles.push({
                    original_name: file.name,
                    stored_name: null,
                    path: null
                });

                // Add to preview list
                withEditorPreviewList.appendChild(previewItem);

                // Upload file
                withEditorUploadFile(file, progressBarInner, progressText, statusBadge, previewItem);
            });

            withEditorUpdateFileCount();
        }

        function withEditorUploadFile(file, progressElement, progressText, statusBadge, previewItem) {
            const url = "{{ route('upload_journal') }}";
            const formData = new FormData();
            formData.append("file_upload[]", file);

            const xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressElement.style.width = percent + "%";
                    progressText.textContent = percent + "%";
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success && res.files.length > 0) {
                        const uploadedFile = res.files[0];

                        // Store file info on the preview item
                        previewItem.dataset.storedName = uploadedFile.stored_name;

                        // Update the file in uploadedFiles array
                        const fileIndex = withEditorUploadedFiles.findIndex(f => f.original_name === uploadedFile
                            .original_name);
                        if (fileIndex !== -1) {
                            withEditorUploadedFiles[fileIndex] = uploadedFile;
                        }

                        document.getElementById("withEditorFiles").value = JSON.stringify(withEditorUploadedFiles);
                        progressElement.style.background = "#10b981";
                        statusBadge.className = "with-editor-file-status with-editor-status-success";
                        statusBadge.textContent = "Uploaded";
                        progressText.textContent = "Complete";

                        // Update the filename display to show original name
                        const nameDiv = previewItem.querySelector('.with-editor-preview-filename');
                        nameDiv.textContent = uploadedFile.original_name.length > 20 ?
                            uploadedFile.original_name.substring(0, 20) + '...' : uploadedFile.original_name;
                        nameDiv.title = uploadedFile.original_name;

                        previewItem.style.borderColor = "#10b981";
                        previewItem.style.boxShadow = "0 0 0 1px #10b981";
                    } else {
                        withEditorHandleUploadError(progressElement, statusBadge, progressText, res.message ||
                            'Upload failed');
                    }
                } else {
                    withEditorHandleUploadError(progressElement, statusBadge, progressText,
                        'Upload failed with status ' + xhr.status);
                }
            };

            xhr.onerror = function() {
                withEditorHandleUploadError(progressElement, statusBadge, progressText, 'Network error');
            };

            xhr.send(formData);
        }

        async function withEditorRemoveFileFromServer(fileName, previewItem) {
            try {
                const response = await fetch("{{ url('/upload/temp/remove') }}", {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: JSON.stringify({
                        file_name: fileName
                    })
                });

                const result = await response.json();

                if (result.success) {
                    withEditorPreviewList.removeChild(previewItem);
                    withEditorUploadedFiles = withEditorUploadedFiles.filter(f => f.stored_name !== fileName);
                    withEditorUpdateFileCount();
                    if (withEditorUploadedFiles.length === 0) {
                        withEditorPreviewContainer.style.display = "none";
                        withEditorDropMessage.style.display = "block";
                    }
                    document.getElementById("withEditorFiles").value = JSON.stringify(withEditorUploadedFiles);
                    return true;
                } else {
                    toastr.error(result.message || 'Failed to remove file');
                    return false;
                }
            } catch (error) {
                toastr.error(error.message || 'Error removing file');
                return false;
            }
        }

        function withEditorHandleUploadError(progressElement, statusBadge, progressText, message) {
            progressElement.style.background = "var(--danger-red)";
            statusBadge.className = "with-editor-file-status with-editor-status-error";
            statusBadge.textContent = "Error";
            progressText.textContent = "Failed";
            toastr.error(message || 'Upload failed');
        }

        // Initialize with any existing files from hidden input
        document.addEventListener('DOMContentLoaded', () => {
            const existingFiles = JSON.parse(document.getElementById("withEditorFiles").value || '[]');
            if (existingFiles.length > 0) {
                // Display already uploaded files
                withEditorPreviewContainer.style.display = "block";
                withEditorDropMessage.style.display = "none";

                existingFiles.forEach(file => {
                    withEditorCreatePreviewForExistingFile(file);
                });

                withEditorUploadedFiles = existingFiles;
                withEditorUpdateFileCount();
            }
        });

        function withEditorCreatePreviewForExistingFile(fileData) {
            const previewItem = document.createElement("div");
            previewItem.className = "with-editor-preview-item";
            previewItem.dataset.storedName = fileData.stored_name;

            // File status badge
            const statusBadge = document.createElement("div");
            statusBadge.className = "with-editor-file-status with-editor-status-success";
            statusBadge.textContent = "Uploaded";
            previewItem.appendChild(statusBadge);

            // File type badge
            const typeBadge = document.createElement("div");
            typeBadge.className = "with-editor-file-type-badge";
            const fileExt = fileData.original_name.split('.').pop().toUpperCase();
            typeBadge.textContent = ['PDF', 'DOC', 'DOCX', 'JPG', 'JPEG', 'PNG', 'GIF'].includes(fileExt) ?
                fileExt : fileExt;
            previewItem.appendChild(typeBadge);

            // Remove button
            const removeBtn = document.createElement("button");
            removeBtn.className = "with-editor-remove-btn";
            removeBtn.innerHTML = "×";
            removeBtn.onclick = async () => {
                if (confirm('Remove this file?')) {
                    const storedName = fileData.stored_name;
                    await withEditorRemoveFileFromServer(storedName, previewItem);
                }
            };
            previewItem.appendChild(removeBtn);

            // Thumbnail container
            const thumbContainer = document.createElement("div");
            thumbContainer.className = "with-editor-preview-thumb-container";

            // Check if it's an image
            const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileData.original_name.split('.').pop()
                .toLowerCase());

            if (isImage && fileData.path) {
                // Try to load image from path
                const img = document.createElement("img");
                img.className = "with-editor-preview-thumb";
                img.src = "{{ asset('') }}" + fileData.path;
                img.onerror = function() {
                    // If image fails to load, show file icon
                    thumbContainer.innerHTML = '';
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "with-editor-file-icon";
                    fileIcon.innerHTML = withEditorFileIcons.image;
                    thumbContainer.appendChild(fileIcon);
                };
                thumbContainer.appendChild(img);
            } else {
                const fileIcon = document.createElement("div");
                fileIcon.className = "with-editor-file-icon";
                const fileExt = fileData.original_name.split('.').pop().toLowerCase();
                if (fileExt === 'pdf') {
                    fileIcon.innerHTML = withEditorFileIcons.pdf;
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon.innerHTML = withEditorFileIcons.doc;
                } else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileExt)) {
                    fileIcon.innerHTML = withEditorFileIcons.image;
                } else {
                    fileIcon.innerHTML = withEditorFileIcons.default;
                }
                thumbContainer.appendChild(fileIcon);
            }
            previewItem.appendChild(thumbContainer);

            // File name
            const nameDiv = document.createElement("div");
            nameDiv.className = "with-editor-preview-filename";
            nameDiv.title = fileData.original_name;
            nameDiv.textContent = fileData.original_name.length > 20 ?
                fileData.original_name.substring(0, 20) + '...' : fileData.original_name;
            previewItem.appendChild(nameDiv);

            // File size (if available)
            const sizeDiv = document.createElement("div");
            sizeDiv.className = "with-editor-preview-size";
            sizeDiv.textContent = fileData.size ? withEditorHumanFileSize(fileData.size) : 'Size unknown';
            previewItem.appendChild(sizeDiv);

            withEditorPreviewList.appendChild(previewItem);
        }

        function validateWithEditor() {
            const withEditorComment = $('#withEditorComments').val();
            let withEditorErr = false;

            $('#withEditorCommentsErr').text('');

            if (withEditorComment === "") {
                $('#withEditorCommentsErr').text("Reviewer comment is required!");
                withEditorErr = true;
            }

            if (withEditorErr) {
                return false;
            } else {
                // Show Google Drive loader
                showGoogleDriveLoader();

                $.ajax({
                    url: '/journal_with_editor_status/' + $('#withEditorId').val(),
                    method: 'POST',
                    data: {
                        with_editor_comment: withEditorComment,
                        with_editor_files: JSON.stringify(withEditorUploadedFiles),
                        with_editor_date: $('#with_editor_date').val(),
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        hideGoogleDriveLoader();
                        if (response.status === 200) {
                            toastr.success('With Editor Status Submitted Successfully!');
                            setTimeout(() => {
                                location.reload();
                            }, 1500);
                        } else {
                            console.log('Error Submitting with editor status:', response.message);
                            toastr.error('Error submitting with editor status');
                        }
                    },
                    error: function(xhr, status, error) {
                        hideGoogleDriveLoader();
                        console.error('Error submitting with editor status:', error);
                        toastr.error('Error submitting with editor status');
                    }
                });
            }

            return true;
        }
    </script>


    <script>
        function getJournalUnderReviewer(id) {
            $.ajax({
                url: `/get_journal_review_data/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {

                    if (response.status === 200) {
                        $('[data-bs-toggle="tooltip"]').tooltip('dispose');

                        $('#underReviewerId').val(id);
                        $('#under_reviewer_customer').html(
                            `${response.data.cus_name} (${response.data.customer_id})`).attr('title',
                            `${response.data.cus_name} (${response.data.customer_id})`);
                        $('#under_reviewer_service').html(
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`)
                            .attr('title',
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`
                            );
                        $('#under_reviewer_journal').html(`${response.data.journal_name}`).attr('title',
                            `${response.data.journal_name}`);
                        $('#under_reviewer_paper').html(
                            `${response.data.paper_name} ( ${response.data.journal_id} )`).attr('title',
                            `${response.data.paper_name} ( ${response.data.journal_id} )`);
                        $('#under_reviewer_domain').html(response.data.domain_names.join(', '));

                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.log('Error Fetching Journal Under Reviewer Data!');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching journal Under Reviewer data:', error);
                }
            });
        }
    </script>

    <script>
        // File type icons mapping for Under Reviewer
        const underReviewerFileIcons = {
            pdf: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 13.5H9m6 3H9m3-6h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>`,
            doc: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
              </svg>`,
            image: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
               </svg>`,
            default: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>`
        };

        const underReviewerDropArea = document.getElementById("underReviewerDropArea");
        const underReviewerFileInput = document.getElementById("underReviewerFileInput");
        const underReviewerPreviewList = document.getElementById("underReviewerPreviewList");
        const underReviewerPreviewContainer = document.getElementById("underReviewerPreviewContainer");
        const underReviewerDropMessage = document.getElementById("underReviewerDropMessage");
        const underReviewerFileCount = document.getElementById("underReviewerFileCount");
        const underReviewerClearAllBtn = document.getElementById("underReviewerClearAllBtn");
        let underReviewerUploadedFiles = [];

        // Get file icon based on type
        function underReviewerGetFileIcon(file) {
            if (file.type.startsWith('image/')) return underReviewerFileIcons.image;
            if (file.type === 'application/pdf') return underReviewerFileIcons.pdf;
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return underReviewerFileIcons.doc;
            return underReviewerFileIcons.default;
        }

        // Get file type for badge
        function underReviewerGetFileType(file) {
            if (file.type.startsWith('image/')) return 'IMG';
            if (file.type === 'application/pdf') return 'PDF';
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return 'DOC';
            return file.name.split('.').pop().toUpperCase();
        }

        // Make whole drop area clickable
        underReviewerDropArea.addEventListener("click", () => underReviewerFileInput.click());

        underReviewerDropArea.addEventListener("dragover", e => {
            e.preventDefault();
            underReviewerDropArea.classList.add("drag-over");
        });

        underReviewerDropArea.addEventListener("dragleave", e => {
            e.preventDefault();
            underReviewerDropArea.classList.remove("drag-over");
        });

        underReviewerDropArea.addEventListener("drop", e => {
            e.preventDefault();
            underReviewerDropArea.classList.remove("drag-over");
            if (e.dataTransfer.files.length) {
                underReviewerHandleFiles(e.dataTransfer.files);
            }
        });

        underReviewerFileInput.addEventListener("change", e => {
            if (e.target.files.length) {
                underReviewerHandleFiles(e.target.files);
            }
        });

        // Clear all files
        underReviewerClearAllBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            e.stopPropagation();

            underReviewerClearAllBtn.disabled = true;

            // If you want to remove uploaded files from server
            for (const file of underReviewerUploadedFiles) {
                if (file.stored_name) {
                    await underReviewerRemoveFileFromServer(file.stored_name, null);
                }
            }

            underReviewerPreviewList.innerHTML = '';
            underReviewerUploadedFiles = [];
            underReviewerUpdateFileCount();
            underReviewerPreviewContainer.style.display = 'none';
            underReviewerDropMessage.style.display = 'block';
            document.getElementById("underReviewerFiles").value = JSON.stringify([]);

            underReviewerClearAllBtn.disabled = false;
        });


        function underReviewerHumanFileSize(size) {
            const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
            return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
        }

        function underReviewerUpdateFileCount() {
            underReviewerFileCount.textContent = underReviewerUploadedFiles.length;
        }

        function underReviewerHandleFiles(files) {
            underReviewerDropMessage.style.display = "none";
            underReviewerPreviewContainer.style.display = "block";

            [...files].forEach(file => {
                if (file.size > 10 * 1024 * 1024) {
                    alert(`File "${file.name}" exceeds 10MB limit`);
                    return;
                }

                const previewItem = document.createElement("div");
                previewItem.className = "under-reviewer-preview-item";

                // File status badge
                const statusBadge = document.createElement("div");
                statusBadge.className = "under-reviewer-file-status under-reviewer-status-uploading";
                statusBadge.textContent = "Uploading";
                previewItem.appendChild(statusBadge);

                // File type badge
                const typeBadge = document.createElement("div");
                typeBadge.className = "under-reviewer-file-type-badge";
                typeBadge.textContent = underReviewerGetFileType(file);
                previewItem.appendChild(typeBadge);

                // Remove button
                const removeBtn = document.createElement("button");
                removeBtn.type = "button";
                removeBtn.className = "under-reviewer-remove-btn";
                removeBtn.innerHTML = "×";
                removeBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    const storedName = previewItem.dataset.storedName;
                    if (storedName) {
                        underReviewerRemoveFileFromServer(storedName, previewItem);
                    } else {
                        underReviewerPreviewList.removeChild(previewItem);
                        underReviewerUploadedFiles = underReviewerUploadedFiles.filter(f => f.original_name !==
                            file.name);
                        underReviewerUpdateFileCount();
                        if (underReviewerUploadedFiles.length === 0) {
                            underReviewerPreviewContainer.style.display = 'none';
                            underReviewerDropMessage.style.display = 'block';
                        }
                        document.getElementById("underReviewerFiles").value = JSON.stringify(
                            underReviewerUploadedFiles);
                    }
                };
                previewItem.appendChild(removeBtn);

                // Thumbnail container
                const thumbContainer = document.createElement("div");
                thumbContainer.className = "under-reviewer-preview-thumb-container";

                if (file.type.startsWith("image/")) {
                    const img = document.createElement("img");
                    img.className = "under-reviewer-preview-thumb";
                    const reader = new FileReader();
                    reader.onload = e => img.src = e.target.result;
                    reader.readAsDataURL(file);
                    thumbContainer.appendChild(img);
                } else {
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "under-reviewer-file-icon";
                    fileIcon.innerHTML = underReviewerGetFileIcon(file);
                    thumbContainer.appendChild(fileIcon);
                }
                previewItem.appendChild(thumbContainer);

                // File name
                const nameDiv = document.createElement("div");
                nameDiv.className = "under-reviewer-preview-filename";
                nameDiv.title = file.name;
                nameDiv.textContent = file.name.length > 20 ? file.name.substring(0, 20) + '...' : file.name;
                previewItem.appendChild(nameDiv);

                // File size
                const sizeDiv = document.createElement("div");
                sizeDiv.className = "under-reviewer-preview-size";
                sizeDiv.textContent = underReviewerHumanFileSize(file.size);
                previewItem.appendChild(sizeDiv);

                // Progress container
                const progressContainer = document.createElement("div");
                progressContainer.className = "under-reviewer-progress-container";

                const progressBar = document.createElement("div");
                progressBar.className = "under-reviewer-progress-bar";
                const progressBarInner = document.createElement("div");
                progressBarInner.className = "under-reviewer-progress-bar-inner";
                progressBar.appendChild(progressBarInner);
                progressContainer.appendChild(progressBar);

                const progressText = document.createElement("div");
                progressText.className = "under-reviewer-progress-text";
                progressText.textContent = "0%";
                progressContainer.appendChild(progressText);

                previewItem.appendChild(progressContainer);

                // Add temporary file to array (will be updated after upload)
                underReviewerUploadedFiles.push({
                    original_name: file.name,
                    stored_name: null,
                    path: null
                });

                // Add to preview list
                underReviewerPreviewList.appendChild(previewItem);

                // Upload file
                underReviewerUploadFile(file, progressBarInner, progressText, statusBadge, previewItem);
            });

            underReviewerUpdateFileCount();
        }

        function underReviewerUploadFile(file, progressElement, progressText, statusBadge, previewItem) {
            const url = "{{ route('upload_journal') }}";
            const formData = new FormData();
            formData.append("file_upload[]", file);

            const xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressElement.style.width = percent + "%";
                    progressText.textContent = percent + "%";
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success && res.files.length > 0) {
                        const uploadedFile = res.files[0];

                        // Store file info on the preview item
                        previewItem.dataset.storedName = uploadedFile.stored_name;

                        // Update the file in uploadedFiles array
                        const fileIndex = underReviewerUploadedFiles.findIndex(f => f.original_name === uploadedFile
                            .original_name);
                        if (fileIndex !== -1) {
                            underReviewerUploadedFiles[fileIndex] = uploadedFile;
                        }

                        document.getElementById("underReviewerFiles").value = JSON.stringify(
                            underReviewerUploadedFiles);
                        progressElement.style.background = "#10b981";
                        statusBadge.className = "under-reviewer-file-status under-reviewer-status-success";
                        statusBadge.textContent = "Uploaded";
                        progressText.textContent = "Complete";

                        // Update the filename display to show original name
                        const nameDiv = previewItem.querySelector('.under-reviewer-preview-filename');
                        nameDiv.textContent = uploadedFile.original_name.length > 20 ?
                            uploadedFile.original_name.substring(0, 20) + '...' : uploadedFile.original_name;
                        nameDiv.title = uploadedFile.original_name;

                        previewItem.style.borderColor = "#10b981";
                        previewItem.style.boxShadow = "0 0 0 1px #10b981";
                    } else {
                        underReviewerHandleUploadError(progressElement, statusBadge, progressText, res.message ||
                            'Upload failed');
                    }
                } else {
                    underReviewerHandleUploadError(progressElement, statusBadge, progressText,
                        'Upload failed with status ' + xhr.status);
                }
            };

            xhr.onerror = function() {
                underReviewerHandleUploadError(progressElement, statusBadge, progressText, 'Network error');
            };

            xhr.send(formData);
        }

        async function underReviewerRemoveFileFromServer(fileName, previewItem) {
            try {
                const response = await fetch("{{ url('/upload/temp/remove') }}", {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: JSON.stringify({
                        file_name: fileName
                    })
                });

                const result = await response.json();

                if (result.success) {
                    underReviewerPreviewList.removeChild(previewItem);
                    underReviewerUploadedFiles = underReviewerUploadedFiles.filter(f => f.stored_name !== fileName);
                    underReviewerUpdateFileCount();
                    if (underReviewerUploadedFiles.length === 0) {
                        underReviewerPreviewContainer.style.display = "none";
                        underReviewerDropMessage.style.display = "block";
                    }
                    document.getElementById("underReviewerFiles").value = JSON.stringify(underReviewerUploadedFiles);
                    return true;
                } else {
                    // toastr.error(result.message || 'Failed to remove file');
                    return false;
                }
            } catch (error) {
                // toastr.error(error.message || 'Error removing file');
                return false;
            }
        }

        function underReviewerHandleUploadError(progressElement, statusBadge, progressText, message) {
            progressElement.style.background = "var(--danger-red)";
            statusBadge.className = "under-reviewer-file-status under-reviewer-status-error";
            statusBadge.textContent = "Error";
            progressText.textContent = "Failed";
            toastr.error(message || 'Upload failed');
        }

        // Initialize with any existing files from hidden input
        document.addEventListener('DOMContentLoaded', () => {
            const existingFiles = JSON.parse(document.getElementById("underReviewerFiles").value || '[]');
            if (existingFiles.length > 0) {
                // Display already uploaded files
                underReviewerPreviewContainer.style.display = "block";
                underReviewerDropMessage.style.display = "none";

                existingFiles.forEach(file => {
                    underReviewerCreatePreviewForExistingFile(file);
                });

                underReviewerUploadedFiles = existingFiles;
                underReviewerUpdateFileCount();
            }
        });

        function underReviewerCreatePreviewForExistingFile(fileData) {
            const previewItem = document.createElement("div");
            previewItem.className = "under-reviewer-preview-item";
            previewItem.dataset.storedName = fileData.stored_name;

            // File status badge
            const statusBadge = document.createElement("div");
            statusBadge.className = "under-reviewer-file-status under-reviewer-status-success";
            statusBadge.textContent = "Uploaded";
            previewItem.appendChild(statusBadge);

            // File type badge
            const typeBadge = document.createElement("div");
            typeBadge.className = "under-reviewer-file-type-badge";
            const fileExt = fileData.original_name.split('.').pop().toUpperCase();
            typeBadge.textContent = ['PDF', 'DOC', 'DOCX', 'JPG', 'JPEG', 'PNG', 'GIF'].includes(fileExt) ?
                fileExt : fileExt;
            previewItem.appendChild(typeBadge);

            // Remove button
            const removeBtn = document.createElement("button");
            removeBtn.className = "under-reviewer-remove-btn";
            removeBtn.innerHTML = "×";
            removeBtn.onclick = async (e) => {
                e.preventDefault();
                e.stopPropagation();

                const storedName = fileData.stored_name;
                await underReviewerRemoveFileFromServer(storedName, previewItem);
            };
            previewItem.appendChild(removeBtn);

            // Thumbnail container
            const thumbContainer = document.createElement("div");
            thumbContainer.className = "under-reviewer-preview-thumb-container";

            // Check if it's an image
            const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileData.original_name.split('.').pop()
                .toLowerCase());

            if (isImage && fileData.path) {
                // Try to load image from path
                const img = document.createElement("img");
                img.className = "under-reviewer-preview-thumb";
                img.src = "{{ asset('') }}" + fileData.path;
                img.onerror = function() {
                    // If image fails to load, show file icon
                    thumbContainer.innerHTML = '';
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "under-reviewer-file-icon";
                    fileIcon.innerHTML = underReviewerFileIcons.image;
                    thumbContainer.appendChild(fileIcon);
                };
                thumbContainer.appendChild(img);
            } else {
                const fileIcon = document.createElement("div");
                fileIcon.className = "under-reviewer-file-icon";
                const fileExt = fileData.original_name.split('.').pop().toLowerCase();
                if (fileExt === 'pdf') {
                    fileIcon.innerHTML = underReviewerFileIcons.pdf;
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon.innerHTML = underReviewerFileIcons.doc;
                } else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileExt)) {
                    fileIcon.innerHTML = underReviewerFileIcons.image;
                } else {
                    fileIcon.innerHTML = underReviewerFileIcons.default;
                }
                thumbContainer.appendChild(fileIcon);
            }
            previewItem.appendChild(thumbContainer);

            // File name
            const nameDiv = document.createElement("div");
            nameDiv.className = "under-reviewer-preview-filename";
            nameDiv.title = fileData.original_name;
            nameDiv.textContent = fileData.original_name.length > 20 ?
                fileData.original_name.substring(0, 20) + '...' : fileData.original_name;
            previewItem.appendChild(nameDiv);

            // File size (if available)
            const sizeDiv = document.createElement("div");
            sizeDiv.className = "under-reviewer-preview-size";
            sizeDiv.textContent = fileData.size ? underReviewerHumanFileSize(fileData.size) : 'Size unknown';
            previewItem.appendChild(sizeDiv);

            underReviewerPreviewList.appendChild(previewItem);
        }

        function vallidateunderReviewer() {
            const underReviewerComment = $('#underReviewerComments').val();
            let underReviewerErr = false;

            $('#underReviewerCommentsErr').text('');

            if (underReviewerComment === "") {
                $('#underReviewerCommentsErr').text("Under Reviewer comment is required!");
                underReviewerErr = true;
            }

            if (underReviewerErr) {
                return false;
            } else {
                // Show Google Drive loader
                showGoogleDriveLoader();

                $.ajax({
                    url: '/journal_under_reviewer_status/' + $('#underReviewerId').val(),
                    method: 'POST',
                    data: {
                        under_reviewer_comment: underReviewerComment,
                        under_reviewer_files: JSON.stringify(underReviewerUploadedFiles),
                        under_reviewer_date: $('#under_reviewer_date').val(),
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        hideGoogleDriveLoader();
                        if (response.status === 200) {
                            toastr.success('Under Reviewer Status Submitted Successfully!');
                            setTimeout(() => {
                                location.reload();
                            }, 1500);
                        } else {
                            console.log('Error Submitting Under Reviewer status:', response.message);
                            toastr.error('Error submitting Under Reviewer status');
                        }
                    },
                    error: function(xhr, status, error) {
                        hideGoogleDriveLoader();
                        console.error('Error submitting Under Reviewer status:', error);
                        toastr.error('Error submitting Under Reviewer status');
                    }
                });
            }

            return true;
        }
    </script>

    <!-- E Proofing Journal -->
    <script>
        function getJournalEProofingData(id) {
            $.ajax({
                url: `/get_journal_review_data/${id}`,
                method: 'GET',
                dataType: 'json',
                success: function(response) {

                    if (response.status === 200) {
                        $('[data-bs-toggle="tooltip"]').tooltip('dispose');

                        $('#eProofingId').val(id);
                        $('#e_proofing_customer').html(
                            `${response.data.cus_name} (${response.data.customer_id})`).attr('title',
                            `${response.data.cus_name} (${response.data.customer_id})`);
                        $('#e_proofing_service').html(
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`)
                            .attr('title',
                                `${response.data.service_name} ( ${response.data.category_name || 'Package'} )`
                            );
                        $('#e_proofing_journal').html(`${response.data.journal_name}`).attr('title',
                            `${response.data.journal_name}`);
                        $('#e_proofing_paper').html(
                            `${response.data.paper_name} ( ${response.data.journal_id} )`).attr('title',
                            `${response.data.paper_name} ( ${response.data.journal_id} )`);
                        $('#e_proogfing_domain').html(response.data.domain_names.join(', '));

                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.log('Error Fetching Journal Under Reviewer Data!');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching journal Under Reviewer data:', error);
                }
            });
        }
    </script>

    <script>
        // File type icons mapping for E-Proofing
        const eProofingFileIcons = {
            pdf: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 13.5H9m6 3H9m3-6h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>`,
            doc: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
              </svg>`,
            image: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
               </svg>`,
            default: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>`
        };

        const eProofingDropArea = document.getElementById("eProofingDropArea");
        const eProofingFileInput = document.getElementById("eProofingFileInput");
        const eProofingPreviewList = document.getElementById("eProofingPreviewList");
        const eProofingPreviewContainer = document.getElementById("eProofingPreviewContainer");
        const eProofingDropMessage = document.getElementById("eProofingDropMessage");
        const eProofingFileCount = document.getElementById("eProofingFileCount");
        const eProofingClearAllBtn = document.getElementById("eProofingClearAllBtn");
        let eProofingUploadedFiles = [];

        // Get file icon based on type
        function eProofingGetFileIcon(file) {
            if (file.type.startsWith('image/')) return eProofingFileIcons.image;
            if (file.type === 'application/pdf') return eProofingFileIcons.pdf;
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return eProofingFileIcons.doc;
            return eProofingFileIcons.default;
        }

        // Get file type for badge
        function eProofingGetFileType(file) {
            if (file.type.startsWith('image/')) return 'IMG';
            if (file.type === 'application/pdf') return 'PDF';
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return 'DOC';
            return file.name.split('.').pop().toUpperCase();
        }

        // Make whole drop area clickable
        eProofingDropArea.addEventListener("click", () => eProofingFileInput.click());

        eProofingDropArea.addEventListener("dragover", e => {
            e.preventDefault();
            eProofingDropArea.classList.add("drag-over");
        });

        eProofingDropArea.addEventListener("dragleave", e => {
            e.preventDefault();
            eProofingDropArea.classList.remove("drag-over");
        });

        eProofingDropArea.addEventListener("drop", e => {
            e.preventDefault();
            eProofingDropArea.classList.remove("drag-over");
            if (e.dataTransfer.files.length) {
                eProofingHandleFiles(e.dataTransfer.files);
            }
        });

        eProofingFileInput.addEventListener("change", e => {
            if (e.target.files.length) {
                eProofingHandleFiles(e.target.files);
            }
        });

        // Clear all files
        eProofingClearAllBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            e.stopPropagation();

            eProofingClearAllBtn.disabled = true;

            for (const file of eProofingUploadedFiles) {
                if (file.stored_name) {
                    await eProofingRemoveFileFromServer(file.stored_name, null);
                }
            }

            eProofingPreviewList.innerHTML = '';
            eProofingUploadedFiles = [];
            eProofingUpdateFileCount();
            eProofingPreviewContainer.style.display = 'none';
            eProofingDropMessage.style.display = 'block';
            document.getElementById("e_proofing_files").value = JSON.stringify([]);

            eProofingClearAllBtn.disabled = false;
        });

        function eProofingHumanFileSize(size) {
            const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
            return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
        }

        function eProofingUpdateFileCount() {
            eProofingFileCount.textContent = eProofingUploadedFiles.length;
        }

        function eProofingHandleFiles(files) {
            eProofingDropMessage.style.display = "none";
            eProofingPreviewContainer.style.display = "block";

            [...files].forEach(file => {
                if (file.size > 10 * 1024 * 1024) {
                    toastr.error(`File "${file.name}" exceeds 10MB limit`);
                    return;
                }

                const previewItem = document.createElement("div");
                previewItem.className = "e-proofing-preview-item";

                // File status badge
                const statusBadge = document.createElement("div");
                statusBadge.className = "e-proofing-file-status e-proofing-status-uploading";
                statusBadge.textContent = "Uploading";
                previewItem.appendChild(statusBadge);

                // File type badge
                const typeBadge = document.createElement("div");
                typeBadge.className = "e-proofing-file-type-badge";
                typeBadge.textContent = eProofingGetFileType(file);
                previewItem.appendChild(typeBadge);

                // Remove button
                const removeBtn = document.createElement("button");
                removeBtn.type = "button";
                removeBtn.className = "e-proofing-remove-btn";
                removeBtn.innerHTML = "×";
                removeBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    const storedName = previewItem.dataset.storedName;
                    if (storedName) {
                        eProofingRemoveFileFromServer(storedName, previewItem);
                    } else {
                        eProofingPreviewList.removeChild(previewItem);
                        eProofingUploadedFiles =
                            eProofingUploadedFiles.filter(f => f.original_name !== file.name);

                        eProofingUpdateFileCount();

                        if (eProofingUploadedFiles.length === 0) {
                            eProofingPreviewContainer.style.display = "none";
                            eProofingDropMessage.style.display = "block";
                        }

                        document.getElementById("e_proofing_files").value =
                            JSON.stringify(eProofingUploadedFiles);
                    }

                };
                previewItem.appendChild(removeBtn);

                // Thumbnail container
                const thumbContainer = document.createElement("div");
                thumbContainer.className = "e-proofing-preview-thumb-container";

                if (file.type.startsWith("image/")) {
                    const img = document.createElement("img");
                    img.className = "e-proofing-preview-thumb";
                    const reader = new FileReader();
                    reader.onload = e => img.src = e.target.result;
                    reader.readAsDataURL(file);
                    thumbContainer.appendChild(img);
                } else {
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "e-proofing-file-icon";
                    fileIcon.innerHTML = eProofingGetFileIcon(file);
                    thumbContainer.appendChild(fileIcon);
                }
                previewItem.appendChild(thumbContainer);

                // File name
                const nameDiv = document.createElement("div");
                nameDiv.className = "e-proofing-preview-filename";
                nameDiv.title = file.name;
                nameDiv.textContent = file.name.length > 20 ? file.name.substring(0, 20) + '...' : file.name;
                previewItem.appendChild(nameDiv);

                // File size
                const sizeDiv = document.createElement("div");
                sizeDiv.className = "e-proofing-preview-size";
                sizeDiv.textContent = eProofingHumanFileSize(file.size);
                previewItem.appendChild(sizeDiv);

                // Progress container
                const progressContainer = document.createElement("div");
                progressContainer.className = "e-proofing-progress-container";

                const progressBar = document.createElement("div");
                progressBar.className = "e-proofing-progress-bar";
                const progressBarInner = document.createElement("div");
                progressBarInner.className = "e-proofing-progress-bar-inner";
                progressBar.appendChild(progressBarInner);
                progressContainer.appendChild(progressBar);

                const progressText = document.createElement("div");
                progressText.className = "e-proofing-progress-text";
                progressText.textContent = "0%";
                progressContainer.appendChild(progressText);

                previewItem.appendChild(progressContainer);

                // Add temporary file to array (will be updated after upload)
                eProofingUploadedFiles.push({
                    original_name: file.name,
                    stored_name: null,
                    path: null
                });

                // Add to preview list
                eProofingPreviewList.appendChild(previewItem);

                // Upload file
                eProofingUploadFile(file, progressBarInner, progressText, statusBadge, previewItem);
            });

            eProofingUpdateFileCount();
        }

        function eProofingUploadFile(file, progressElement, progressText, statusBadge, previewItem) {
            // FIXED: Changed from incorrect route to consistent upload route
            const url = "{{ route('upload_journal') }}"; // Changed from '/e_proofing_journalsss'
            const formData = new FormData();
            formData.append("file_upload[]", file);

            const xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressElement.style.width = percent + "%";
                    progressText.textContent = percent + "%";
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success && res.files.length > 0) {
                        const uploadedFile = res.files[0];

                        // Store file info on the preview item
                        previewItem.dataset.storedName = uploadedFile.stored_name;

                        // Update the file in uploadedFiles array
                        const fileIndex = eProofingUploadedFiles.findIndex(f => f.original_name === uploadedFile
                            .original_name);
                        if (fileIndex !== -1) {
                            eProofingUploadedFiles[fileIndex] = uploadedFile;
                        }

                        document.getElementById("e_proofing_files").value = JSON.stringify(eProofingUploadedFiles);
                        progressElement.style.background = "#10b981";
                        statusBadge.className = "e-proofing-file-status e-proofing-status-success";
                        statusBadge.textContent = "Uploaded";
                        progressText.textContent = "Complete";

                        // Update the filename display to show original name
                        const nameDiv = previewItem.querySelector('.e-proofing-preview-filename');
                        nameDiv.textContent = uploadedFile.original_name.length > 20 ?
                            uploadedFile.original_name.substring(0, 20) + '...' : uploadedFile.original_name;
                        nameDiv.title = uploadedFile.original_name;

                        previewItem.style.borderColor = "#10b981";
                        previewItem.style.boxShadow = "0 0 0 1px #10b981";
                    } else {
                        eProofingHandleUploadError(progressElement, statusBadge, progressText, res.message ||
                            'Upload failed');
                    }
                } else {
                    eProofingHandleUploadError(progressElement, statusBadge, progressText,
                        'Upload failed with status ' + xhr.status);
                }
            };

            xhr.onerror = function() {
                eProofingHandleUploadError(progressElement, statusBadge, progressText, 'Network error');
            };

            xhr.send(formData);
        }

        async function eProofingRemoveFileFromServer(fileName, previewItem) {
            try {
                // FIXED: Changed to consistent remove endpoint
                const response = await fetch("{{ url('/upload/temp/remove') }}", {
                    method: 'DELETE', // Changed from POST to DELETE
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: JSON.stringify({
                        file_name: fileName
                    })
                });

                const result = await response.json();

                if (result.success) {
                    if (previewItem) {
                        // Remove from UI
                        eProofingPreviewList.removeChild(previewItem);
                        eProofingUploadedFiles = eProofingUploadedFiles.filter(f => f.stored_name !== fileName);
                        eProofingUpdateFileCount();
                        if (eProofingUploadedFiles.length === 0) {
                            eProofingPreviewContainer.style.display = "none";
                            eProofingDropMessage.style.display = "block";
                        }
                        document.getElementById("e_proofing_files").value = JSON.stringify(eProofingUploadedFiles);
                    }
                    toastr.success('File removed successfully');
                    return true;
                } else {
                    toastr.error('Failed to remove file: ' + (result.message || 'Unknown error'));
                    return false;
                }
            } catch (error) {
                toastr.error('Error removing file: ' + error.message);
                return false;
            }
        }

        function eProofingHandleUploadError(progressElement, statusBadge, progressText, message) {
            progressElement.style.background = "var(--danger-red)";
            statusBadge.className = "e-proofing-file-status e-proofing-status-error";
            statusBadge.textContent = "Error";
            progressText.textContent = "Failed";
            toastr.error("Upload failed: " + message);
        }

        // Initialize with any existing files from hidden input
        document.addEventListener('DOMContentLoaded', () => {
            const existingFiles = JSON.parse(document.getElementById("e_proofing_files").value || '[]');
            if (existingFiles.length > 0) {
                // Display already uploaded files
                eProofingPreviewContainer.style.display = "block";
                eProofingDropMessage.style.display = "none";

                existingFiles.forEach(file => {
                    eProofingCreatePreviewForExistingFile(file);
                });

                eProofingUploadedFiles = existingFiles;
                eProofingUpdateFileCount();
            }
        });

        function eProofingCreatePreviewForExistingFile(fileData) {
            const previewItem = document.createElement("div");
            previewItem.className = "e-proofing-preview-item";
            previewItem.dataset.storedName = fileData.stored_name;

            // File status badge
            const statusBadge = document.createElement("div");
            statusBadge.className = "e-proofing-file-status e-proofing-status-success";
            statusBadge.textContent = "Uploaded";
            previewItem.appendChild(statusBadge);

            // File type badge
            const typeBadge = document.createElement("div");
            typeBadge.className = "e-proofing-file-type-badge";
            const fileExt = fileData.original_name.split('.').pop().toUpperCase();
            typeBadge.textContent = ['PDF', 'DOC', 'DOCX', 'JPG', 'JPEG', 'PNG', 'GIF'].includes(fileExt) ?
                fileExt : fileExt;
            previewItem.appendChild(typeBadge);

            // Remove button
            const removeBtn = document.createElement("button");
            removeBtn.className = "e-proofing-remove-btn";
            removeBtn.innerHTML = "×";
            removeBtn.onclick = async (e) => {
                e.preventDefault();
                e.stopPropagation();

                const storedName = fileData.stored_name;
                await eProofingRemoveFileFromServer(storedName, previewItem);
            };
            previewItem.appendChild(removeBtn);

            // Thumbnail container
            const thumbContainer = document.createElement("div");
            thumbContainer.className = "e-proofing-preview-thumb-container";

            // Check if it's an image
            const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileData.original_name.split('.').pop()
                .toLowerCase());

            if (isImage && fileData.path) {
                // Try to load image from path
                const img = document.createElement("img");
                img.className = "e-proofing-preview-thumb";
                img.src = "{{ asset('') }}" + fileData.path;
                img.onerror = function() {
                    // If image fails to load, show file icon
                    thumbContainer.innerHTML = '';
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "e-proofing-file-icon";
                    fileIcon.innerHTML = eProofingFileIcons.image;
                    thumbContainer.appendChild(fileIcon);
                };
                thumbContainer.appendChild(img);
            } else {
                const fileIcon = document.createElement("div");
                fileIcon.className = "e-proofing-file-icon";
                const fileExt = fileData.original_name.split('.').pop().toLowerCase();
                if (fileExt === 'pdf') {
                    fileIcon.innerHTML = eProofingFileIcons.pdf;
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon.innerHTML = eProofingFileIcons.doc;
                } else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileExt)) {
                    fileIcon.innerHTML = eProofingFileIcons.image;
                } else {
                    fileIcon.innerHTML = eProofingFileIcons.default;
                }
                thumbContainer.appendChild(fileIcon);
            }
            previewItem.appendChild(thumbContainer);

            // File name
            const nameDiv = document.createElement("div");
            nameDiv.className = "e-proofing-preview-filename";
            nameDiv.title = fileData.original_name;
            nameDiv.textContent = fileData.original_name.length > 20 ?
                fileData.original_name.substring(0, 20) + '...' : fileData.original_name;
            previewItem.appendChild(nameDiv);

            // File size (if available)
            const sizeDiv = document.createElement("div");
            sizeDiv.className = "e-proofing-preview-size";
            sizeDiv.textContent = fileData.size ? eProofingHumanFileSize(fileData.size) : 'Size unknown';
            previewItem.appendChild(sizeDiv);

            eProofingPreviewList.appendChild(previewItem);
        }

        function validateEProofingForm() {
            const eProofingComment = $('#e_proofing_comments').val();
            let eProofingErr = false;

            $('#e_proofing_comments_err').text('');

            if (eProofingComment === "") {
                $('#e_proofing_comments_err').text("E-Proofing comment is required!");
                eProofingErr = true;
            }

            if (eProofingErr) {
                return false;
            } else {
                // Show Google Drive loader
                showGoogleDriveLoader();

                $.ajax({
                    url: '/journal_e_proofing/' + $('#eProofingId').val(),
                    method: 'POST',
                    data: {
                        e_proofing_comment: eProofingComment,
                        e_proofing_files: JSON.stringify(eProofingUploadedFiles),
                        e_proofing_date: $('#e_proofing_date').val(),
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        hideGoogleDriveLoader();
                        if (response.status === 200) {
                            toastr.success('E-Proofing Status Submitted Successfully!');
                            setTimeout(() => {
                                location.reload();
                            }, 1500);
                        } else {
                            console.log('Error Submitting E-Proofing status:', response.message);
                            toastr.error('Error submitting E-Proofing status');
                        }
                    },
                    error: function(xhr, status, error) {
                        hideGoogleDriveLoader();
                        console.error('Error submitting E-Proofing status:', error);
                        toastr.error('Error submitting E-Proofing status');
                    }
                });
            }

            return true;
        }
    </script>

    <!---------------- Pass Locker ------------------>
    <script>
        function passLocker(customerId) {
            if (!customerId) return;

            $.ajax({
                url: `/journal_passlocker/${customerId}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const customer = response.data.customer;
                        const passLocker = response.data.passLocker;

                        $('#passLockerCustomer').html(customer.cus_name);
                        $('#passLockerCustomerId').html(customer.customer_id);

                        const cusMobile = customer.cus_mobile;
                        const cusMail = customer.cus_email_id;

                        if (!cusMobile || cusMobile === null) {
                            $('#passLockerMobileContainer').addClass('d-none');
                        } else {
                            $('#passLockerMobile').html(cusMobile);
                            $('#passLockerMobileContainer').removeClass('d-none');
                        }

                        if (!cusMail || cusMail === null) {
                            $('#passLockerEmailContainer').addClass('d-none');
                        } else {
                            $('#passLockerEmail').html(cusMail);
                            $('#passLockerEmailContainer').removeClass('d-none');
                        }

                        const rowsPerPage = 5;
                        let currentPage = 1;
                        const table = $('#passLockerTable');

                        function renderTable(page) {
                            const start = (page - 1) * rowsPerPage;
                            const end = start + rowsPerPage;
                            const sliceData = passLocker.slice(start, end);

                            let html = '';

                            sliceData.forEach((pass, index) => {
                                html += `
                                <tr>
                                    <td>${start + index + 1}</td>
                                    <td class="">
                                        <label class="fs-7 text-truncate max-w-300px" data-bs-toggle="tooltip" data-bs-placement="top" title="${pass.paper_name}">${pass.paper_name}</label>
                                    </td>
                                    <td>${pass.user_name}</td>
                                    <td>${pass.password}</td>
                                </tr>
                            `;
                            });

                            table.html(html);
                            $('[data-bs-toggle="tooltip"]').tooltip();

                        }

                        function renderPagination() {
                            const totalPages = Math.ceil(passLocker.length / rowsPerPage);
                            let paginationHTML = '';

                            for (let i = 1; i <= totalPages; i++) {
                                paginationHTML += `
                                <li class="page-item ${i === currentPage ? 'active' : ''}">
                                    <a class="page-link" href="javascript:;" data-page="${i}">${i}</a>
                                </li>
                            `;
                            }

                            $('#passLockerPagination').html(paginationHTML);
                        }

                        $(document).off('click', '#passLockerPagination .page-link')
                            .on('click', '#passLockerPagination .page-link', function(e) {
                                e.preventDefault();
                                currentPage = parseInt($(this).data('page'));
                                renderTable(currentPage);
                                renderPagination();
                            });

                        renderTable(currentPage);
                        renderPagination();

                    } else {
                        console.error('Something Went Wrong.');
                    }
                },
                error: function(error) {
                    console.error('Servor Error.');
                }
            });
        }
    </script>

    <script>
        // File type icons mapping for request
        const requestFileIcons = {
            pdf: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 13.5H9m6 3H9m3-6h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>`,
            doc: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
              </svg>`,
            image: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
               </svg>`,
            default: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>`
        };

        const requestDropArea = document.getElementById("requestDropArea");
        const requestFileInput = document.getElementById("requestFileInput");
        const requestPreviewList = document.getElementById("requestPreviewList");
        const requestPreviewContainer = document.getElementById("requestPreviewContainer");
        const requestDropMessage = document.getElementById("requestDropMessage");
        const requestFileCount = document.getElementById("requestFileCount");
        const requestClearAllBtn = document.getElementById("requestClearAllBtn");
        let requestUploadedFiles = []; // FIXED: Changed from requestUploadFiles to requestUploadedFiles for consistency

        // Get file icon based on type
        function requestGetFileIcon(file) {
            if (file.type.startsWith('image/')) return requestFileIcons.image;
            if (file.type === 'application/pdf') return requestFileIcons.pdf;
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return requestFileIcons.doc;
            return requestFileIcons.default;
        }

        // Get file type for badge
        function requestGetFileType(file) {
            if (file.type.startsWith('image/')) return 'IMG';
            if (file.type === 'application/pdf') return 'PDF';
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return 'DOC';
            return file.name.split('.').pop().toUpperCase();
        }

        // Make whole drop area clickable
        requestDropArea.addEventListener("click", () => requestFileInput.click());

        requestDropArea.addEventListener("dragover", e => {
            e.preventDefault();
            requestDropArea.classList.add("drag-over");
        });

        requestDropArea.addEventListener("dragleave", e => {
            e.preventDefault();
            requestDropArea.classList.remove("drag-over");
        });

        requestDropArea.addEventListener("drop", e => {
            e.preventDefault();
            requestDropArea.classList.remove("drag-over");
            if (e.dataTransfer.files.length) {
                requestHandleFiles(e.dataTransfer.files);
            }
        });

        requestFileInput.addEventListener("change", e => {
            if (e.target.files.length) {
                requestHandleFiles(e.target.files);
            }
        });

        // Clear all files
        requestClearAllBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            e.stopPropagation();

            requestClearAllBtn.disabled = true;

            for (const file of requestUploadedFiles) {
                if (file.stored_name) {
                    await requestRemoveFileFromServer(file.stored_name, null);
                }
            }

            requestPreviewList.innerHTML = '';
            requestUploadedFiles = [];
            requestUpdateFileCount();
            requestPreviewContainer.style.display = 'none';
            requestDropMessage.style.display = 'block';
            document.getElementById("request_files").value = JSON.stringify([]);

            requestClearAllBtn.disabled = false;
        });


        function requestHumanFileSize(size) {
            const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
            return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
        }

        function requestUpdateFileCount() {
            requestFileCount.textContent = requestUploadedFiles.length;
        }

        function requestHandleFiles(files) {
            requestDropMessage.style.display = "none";
            requestPreviewContainer.style.display = "block";

            [...files].forEach(file => {
                if (file.size > 10 * 1024 * 1024) {
                    toastr.error(`File "${file.name}" exceeds 10MB limit`);
                    return;
                }

                const previewItem = document.createElement("div");
                previewItem.className = "request-preview-item";

                // File status badge
                const statusBadge = document.createElement("div");
                statusBadge.className = "request-file-status request-status-uploading";
                statusBadge.textContent = "Uploading";
                previewItem.appendChild(statusBadge);

                // File type badge
                const typeBadge = document.createElement("div");
                typeBadge.className = "request-file-type-badge";
                typeBadge.textContent = requestGetFileType(file);
                previewItem.appendChild(typeBadge);

                // Remove button
                const removeBtn = document.createElement("button");
                removeBtn.type = "button";
                removeBtn.className = "request-remove-btn";
                removeBtn.innerHTML = "×";
                removeBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    const storedName = previewItem.dataset.storedName;
                    if (storedName) {
                        requestRemoveFileFromServer(storedName, previewItem);
                    } else {
                        requestPreviewList.removeChild(previewItem);
                        requestUploadedFiles =
                            requestUploadedFiles.filter(f => f.original_name !== file.name);

                        requestUpdateFileCount();

                        if (requestUploadedFiles.length === 0) {
                            requestPreviewContainer.style.display = "none";
                            requestDropMessage.style.display = "block";
                        }

                        document.getElementById("request_files").value =
                            JSON.stringify(requestUploadedFiles);
                    }

                };
                previewItem.appendChild(removeBtn);

                // Thumbnail container
                const thumbContainer = document.createElement("div");
                thumbContainer.className = "request-preview-thumb-container";

                if (file.type.startsWith("image/")) {
                    const img = document.createElement("img");
                    plus_btn
                    img.className = "request-preview-thumb";
                    const reader = new FileReader();
                    reader.onload = e => img.src = e.target.result;
                    reader.readAsDataURL(file);
                    thumbContainer.appendChild(img);
                } else {
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "request-file-icon";
                    fileIcon.innerHTML = requestGetFileIcon(file);
                    thumbContainer.appendChild(fileIcon);
                }
                previewItem.appendChild(thumbContainer);

                // File name
                const nameDiv = document.createElement("div");
                nameDiv.className = "request-preview-filename";
                nameDiv.title = file.name;
                nameDiv.textContent = file.name.length > 20 ? file.name.substring(0, 20) + '...' : file.name;
                previewItem.appendChild(nameDiv);

                // File size
                const sizeDiv = document.createElement("div");
                sizeDiv.className = "request-preview-size";
                sizeDiv.textContent = requestHumanFileSize(file.size);
                previewItem.appendChild(sizeDiv);

                // Progress container
                const progressContainer = document.createElement("div");
                progressContainer.className = "request-progress-container";

                const progressBar = document.createElement("div");
                progressBar.className = "request-progress-bar";
                const progressBarInner = document.createElement("div");
                progressBarInner.className = "request-progress-bar-inner";
                progressBar.appendChild(progressBarInner);
                progressContainer.appendChild(progressBar);

                const progressText = document.createElement("div");
                progressText.className = "request-progress-text";
                progressText.textContent = "0%";
                progressContainer.appendChild(progressText);

                previewItem.appendChild(progressContainer);

                // Add temporary file to array (will be updated after upload)
                requestUploadedFiles.push({
                    original_name: file.name,
                    stored_name: null,
                    path: null
                });

                // Add to preview list
                requestPreviewList.appendChild(previewItem);

                // Upload file
                requestUploadFile(file, progressBarInner, progressText, statusBadge, previewItem);
            });

            requestUpdateFileCount();
        }

        function requestUploadFile(file, progressElement, progressText, statusBadge, previewItem) {
            // FIXED: Changed to consistent upload route
            const url = "{{ route('upload_journal') }}"; // Changed from 'request_journals' for consistency
            const formData = new FormData();
            formData.append("file_upload[]", file);

            const xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressElement.style.width = percent + "%";
                    progressText.textContent = percent + "%";
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success && res.files.length > 0) {
                        const uploadedFile = res.files[0];

                        // Store file info on the preview item
                        previewItem.dataset.storedName = uploadedFile.stored_name;

                        // Update the file in uploadedFiles array
                        const fileIndex = requestUploadedFiles.findIndex(f => f.original_name === uploadedFile
                            .original_name);
                        if (fileIndex !== -1) {
                            requestUploadedFiles[fileIndex] = uploadedFile;
                        }

                        document.getElementById("request_files").value = JSON.stringify(requestUploadedFiles);
                        progressElement.style.background = "#10b981";
                        statusBadge.className = "request-file-status request-status-success";
                        statusBadge.textContent = "Uploaded";
                        progressText.textContent = "Complete";

                        // Update the filename display to show original name
                        const nameDiv = previewItem.querySelector('.request-preview-filename');
                        nameDiv.textContent = uploadedFile.original_name.length > 20 ?
                            uploadedFile.original_name.substring(0, 20) + '...' : uploadedFile.original_name;
                        nameDiv.title = uploadedFile.original_name;

                        previewItem.style.borderColor = "#10b981";
                        previewItem.style.boxShadow = "0 0 0 1px #10b981";
                    } else {
                        requestHandleUploadError(progressElement, statusBadge, progressText, res.message ||
                            'Upload failed');
                    }
                } else {
                    requestHandleUploadError(progressElement, statusBadge, progressText, 'Upload failed with status ' +
                        xhr.status);
                }
            };

            xhr.onerror = function() {
                requestHandleUploadError(progressElement, statusBadge, progressText, 'Network error');
            };

            xhr.send(formData);
        }

        async function requestRemoveFileFromServer(fileName, previewItem) {
            try {
                // FIXED: Changed to consistent remove endpoint
                const response = await fetch("{{ url('/upload/temp/remove') }}", {
                    method: 'DELETE', // Changed from POST to DELETE
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: JSON.stringify({
                        file_name: fileName
                    })
                });

                const result = await response.json();

                if (result.success) {
                    if (previewItem) {
                        // Remove from UI
                        requestPreviewList.removeChild(previewItem);
                        requestUploadedFiles = requestUploadedFiles.filter(f => f.stored_name !== fileName);
                        requestUpdateFileCount();
                        if (requestUploadedFiles.length === 0) {
                            requestPreviewContainer.style.display = "none";
                            requestDropMessage.style.display = "block";
                        }
                        document.getElementById("request_files").value = JSON.stringify(requestUploadedFiles);
                    }
                    toastr.success('File removed successfully');
                    return true;
                } else {
                    toastr.error('Failed to remove file: ' + (result.message || 'Unknown error'));
                    return false;
                }
            } catch (error) {
                toastr.error('Error removing file: ' + error.message);
                return false;
            }
        }

        function requestHandleUploadError(progressElement, statusBadge, progressText, message) {
            progressElement.style.background = "var(--danger-red)";
            statusBadge.className = "request-file-status request-status-error";
            statusBadge.textContent = "Error";
            progressText.textContent = "Failed";
            toastr.error("Upload failed: " + message);
        }

        // Initialize with any existing files from hidden input
        document.addEventListener('DOMContentLoaded', () => {
            const existingFiles = JSON.parse(document.getElementById("request_files").value || '[]');
            if (existingFiles.length > 0) {
                // Display already uploaded files
                requestPreviewContainer.style.display = "block";
                requestDropMessage.style.display = "none";

                existingFiles.forEach(file => {
                    requestCreatePreviewForExistingFile(file);
                });

                requestUploadedFiles = existingFiles;
                requestUpdateFileCount();
            }
        });

        function requestCreatePreviewForExistingFile(fileData) {
            const previewItem = document.createElement("div");
            previewItem.className = "request-preview-item";
            previewItem.dataset.storedName = fileData.stored_name;

            // File status badge
            const statusBadge = document.createElement("div");
            statusBadge.className = "request-file-status request-status-success";
            statusBadge.textContent = "Uploaded";
            previewItem.appendChild(statusBadge);

            // File type badge
            const typeBadge = document.createElement("div");
            typeBadge.className = "request-file-type-badge";
            const fileExt = fileData.original_name.split('.').pop().toUpperCase();
            typeBadge.textContent = ['PDF', 'DOC', 'DOCX', 'JPG', 'JPEG', 'PNG', 'GIF'].includes(fileExt) ?
                fileExt : fileExt;
            previewItem.appendChild(typeBadge);

            // Remove button
            const removeBtn = document.createElement("button");
            removeBtn.className = "request-remove-btn";
            removeBtn.innerHTML = "×";
            removeBtn.onclick = async (e) => {
                e.preventDefault();
                e.stopPropagation();

                const storedName = fileData.stored_name;
                await requestRemoveFileFromServer(storedName, previewItem);

            };
            previewItem.appendChild(removeBtn);

            // Thumbnail container
            const thumbContainer = document.createElement("div");
            thumbContainer.className = "request-preview-thumb-container";

            // Check if it's an image
            const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileData.original_name.split('.').pop()
                .toLowerCase());

            if (isImage && fileData.path) {
                // Try to load image from path
                const img = document.createElement("img");
                img.className = "request-preview-thumb";
                img.src = "{{ asset('') }}" + fileData.path;
                img.onerror = function() {
                    // If image fails to load, show file icon
                    thumbContainer.innerHTML = '';
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "request-file-icon";
                    fileIcon.innerHTML = requestFileIcons.image;
                    thumbContainer.appendChild(fileIcon);
                };
                thumbContainer.appendChild(img);
            } else {
                const fileIcon = document.createElement("div");
                fileIcon.className = "request-file-icon";
                const fileExt = fileData.original_name.split('.').pop().toLowerCase();
                if (fileExt === 'pdf') {
                    fileIcon.innerHTML = requestFileIcons.pdf;
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon.innerHTML = requestFileIcons.doc;
                } else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileExt)) {
                    fileIcon.innerHTML = requestFileIcons.image;
                } else {
                    fileIcon.innerHTML = requestFileIcons.default;
                }
                thumbContainer.appendChild(fileIcon);
            }
            previewItem.appendChild(thumbContainer);

            // File name
            const nameDiv = document.createElement("div");
            nameDiv.className = "request-preview-filename";
            nameDiv.title = fileData.original_name;
            nameDiv.textContent = fileData.original_name.length > 20 ?
                fileData.original_name.substring(0, 20) + '...' : fileData.original_name;
            previewItem.appendChild(nameDiv);

            // File size (if available)
            const sizeDiv = document.createElement("div");
            sizeDiv.className = "request-preview-size";
            sizeDiv.textContent = fileData.size ? requestHumanFileSize(fileData.size) : 'Size unknown';
            previewItem.appendChild(sizeDiv);

            requestPreviewList.appendChild(previewItem);
        }

        function getTaskRequest(id) {

            if (!id) return;

            $('#taskReqJournalId').val(id);

            $.ajax({
                url: `/task_request_list`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const container = $('#task_request_id');
                        container.empty().append('<option value="">Select Task Request</option>');

                        response.data.forEach(task => {
                            container.append(
                                `<option value="${task.sno}">${task.request_name}</option>`);
                        });
                    }
                },
                error: function(err) {
                    console.error('Servor Error !');
                }
            })
        }

        function taskRequestValidation() {
            const button = $('#taskRequestBtn');
            const taskRequest = $('#task_request_id').val();
            const id = $('#taskReqJournalId').val();
            const desc = $('#taskRequestDesc').val();

            $('#task_request_err').text('');

            if (!taskRequest) {
                $('#task_request_err').text('Task request is required.');
                return false;
            }

            button.text('Requesting...').prop('disabled', true);

            let formData = new FormData();
            formData.append('id', id);
            formData.append('request_id', taskRequest);
            formData.append('task_desc', desc);
            formData.append('uploaded_files', JSON.stringify(requestUploadedFiles));

            $.ajax({
                url: '/create_task_request',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: formData,
                processData: false, // ✅ IMPORTANT
                contentType: false, // ✅ IMPORTANT
                success: function(res) {
                    if (res.status === 200) {
                        toastr.success('Task Requested Successfully!');
                        location.reload();
                    } else {
                        toastr.error(res.message || 'Something went wrong');
                    }

                    button.text('Request Task').prop('disabled', false);
                },
                error: function(xhr) {
                    console.error(xhr.responseText);
                    toastr.error('Server Error!');
                    button.text('Request Task').prop('disabled', false);
                }
            });
        }
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const tableContainer = document.querySelector('.table-container');
            const topScrollbar = document.querySelector('.top-scrollbar');
            const bottomScrollbar = document.querySelector('.bottom-scrollbar');
            const topScrollContent = document.querySelector('.top-scrollbar .scroll-content');
            const bottomScrollContent = document.querySelector('.bottom-scrollbar .scroll-content');

            if (tableContainer && topScrollbar && bottomScrollbar) {
                // Set scroll content width to match table width
                function setScrollbarWidth() {
                    const tableWidth = tableContainer.scrollWidth;
                    topScrollContent.style.width = tableWidth + 'px';
                    bottomScrollContent.style.width = tableWidth + 'px';
                }

                // Initialize scrollbar width
                setScrollbarWidth();

                // Update on resize
                window.addEventListener('resize', setScrollbarWidth);

                // Update after any table content changes
                const observer = new MutationObserver(setScrollbarWidth);
                observer.observe(tableContainer, {
                    childList: true,
                    subtree: true
                });

                // Synchronize horizontal scrolling
                function syncHorizontalScroll(source, target1, target2) {
                    target1.scrollLeft = source.scrollLeft;
                    if (target2) {
                        target2.scrollLeft = source.scrollLeft;
                    }
                }

                // Table to scrollbars
                tableContainer.addEventListener('scroll', function() {
                    syncHorizontalScroll(this, topScrollbar, bottomScrollbar);
                });

                // Top scrollbar to table and bottom scrollbar
                topScrollbar.addEventListener('scroll', function() {
                    syncHorizontalScroll(this, tableContainer, bottomScrollbar);
                });

                // Bottom scrollbar to table and top scrollbar
                bottomScrollbar.addEventListener('scroll', function() {
                    syncHorizontalScroll(this, tableContainer, topScrollbar);
                });

                // Also update on window resize
                window.addEventListener('resize', function() {
                    setTimeout(setScrollbarWidth, 100);
                });

                // === FIX: Add Shift + Scroll support for horizontal scrolling ===
                function handleShiftScroll(e, scrollElement) {
                    if (e.shiftKey) {
                        e.preventDefault();
                        const delta = e.deltaY || e.deltaX;
                        scrollElement.scrollLeft += delta;
                    }
                }

                // Apply to table container
                tableContainer.addEventListener('wheel', function(e) {
                    if (e.shiftKey) {
                        e.preventDefault();
                        this.scrollLeft += e.deltaY;
                    }
                }, {
                    passive: false
                });

                // Apply to top scrollbar (if it has wheel events)
                topScrollbar.addEventListener('wheel', function(e) {
                    if (e.shiftKey) {
                        e.preventDefault();
                        this.scrollLeft += e.deltaY;
                    }
                }, {
                    passive: false
                });

                // Apply to bottom scrollbar
                bottomScrollbar.addEventListener('wheel', function(e) {
                    if (e.shiftKey) {
                        e.preventDefault();
                        this.scrollLeft += e.deltaY;
                    }
                }, {
                    passive: false
                });
            }
        });
    </script>
    {{-- --------------------------------Add Requirement------------------------------------ --}}

    <script>
        $(document).ready(function() {
            // Track dynamic fields

            // Initially hide the delete button for the first requirement

            // Add more requirement fields dynamically
            $('.staff_reqts_add').on('click', function() {
                // Increment the counter

                // Create the new requirement row dynamically
                var newRequirementHtml = `
                <div class="row mt-4 form-repeater_reqts" id="requirement_row_${requirementCounter}">
                    <div class="col-lg-7 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold" id="requirement_label_${requirementCounter}">
                            Requirements Point ${requirementCounter} <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" placeholder="Enter Requirement Point ${requirementCounter}" id="requirement_name_${requirementCounter}" name="requirement_name[]" />
                        <div class="text-danger err_mssg" id="requirement_name_${requirementCounter}_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Attachments</label>
                        <div class="d-flex align-items-sm-center">
                            <img src="{{ asset('assets/phdizone_images/Document.jpg') }}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo_${requirementCounter}" />
                            <div class="ms-1 button-wrapper">
                                <div class="d-flex align-items-start mt-2 mb-2">
                                    <button type="button" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Document" onclick="document.getElementById('document_upload_${requirementCounter}').click();">
                                        <i class="mdi mdi-tray-arrow-up"></i>
                                        <input type="file"id="document_upload_${requirementCounter}" name="document_upload[]" class="file-in" hidden accept="image/png, image/jpeg, application/pdf, text/csv"   onchange="fileChange(event)"  />
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Document" id="uploaded_reset_${requirementCounter}">
                                        <i class="mdi mdi-reload"></i>
                                    </button>
                                </div>
                                <div class="small fs-8">Allowed JPG, PNG, PDF, CSV. Max size 5MB</div>
                                <div class="small text-success fs-8" id="upload_file_name_${requirementCounter}"></div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1">
                        <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_reqts_del" id="staff_reqts_del_${requirementCounter}">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
                </div>
            `;

                // Append the new requirement row
                $('#repeater_req').first().parent().append(newRequirementHtml);
                requirementCounter++;

                // Show the delete button for the new row
                $('#staff_reqts_del_' + requirementCounter).show();

                // Hide delete button for the first requirement

            });

            // Delete a requirement row
            $(document).on('click', '.staff_reqts_del', function(e) {
                var deleteId = $(this).attr('id'); // Get the id of the clicked delete button
                var index = deleteId.split('_')[
                    3]; // Extract the counter from the id (e.g., 'staff_reqts_del_2' -> 2)

                // Remove the row
                $('#requirement_row_' + index).slideUp(400, function() {
                    $(this).remove(); // Remove the row
                    requirementCounter--; // Decrement counter

                    // Hide the delete button for the first row if there is only one remaining row
                    if (requirementCounter === 1) {
                        $('#staff_reqts_del_1').hide();
                    }
                });
            });

            $('#submit_requirements').on('click', function() {
                var valid = true;



                var pc_staff = $('#pc_staff').val();
                if (pc_staff == '') {
                    $('.pc_staff_err').html('Select Project Journal Team Lead is required');
                    valid = false;
                } else {
                    $('.pc_staff_err').html('');
                }

                $('input[name^="requirement_name"]:visible:enabled').each(function() {
                    let requirement_name = $(this).val();
                    let errDiv = $(this).siblings('.err_mssg');

                    if (!requirement_name || requirement_name.trim() === '') {
                        valid = false;
                        errDiv.text('Requirement Point is required');
                    } else {
                        errDiv.text('');
                    }
                });

                if (valid) {
                    $('#requirementForm').submit();
                    $('#submit_requirements').prop('disabled', true);
                } else {
                    $('#submit_requirements').prop('disabled', false);
                }
            });
        });
        var requirementCounter = 1;

        function openRequirement(id) {
            requirementCounter = 1;
            // Reset the form before filling it
            $('.form-repeater_reqts').not(':first').remove();

            $.ajax({
                url: '/journal_requirement_manage_details/' + id, // Adjust with your route
                type: 'GET',
                success: function(response) {
                    $('#requirement_lead_name').text(response.customer.cus_name);
                    $('#requirement_lead_mobile').text(response.customer.cus_mobile || '-');
                    $('#requirement_lead_mail').text(response.customer.cus_email_id || '-');
                    $('#requirement_service').html(response.productBadges || '');
                    $('#requirement_service_id').val(id);
                    $('#requirement_lead_id').val(response.customer.sno);

                    $('#requirement_status').val('add');
                    requirementCounter = 2;
                },
                error: function(xhr, status, error) {
                    console.log('Error fetching requirements.');
                }
            });

            var selectedType = 'jtl_staff';
            $.ajax({
                url: '{{ route('get.ajax.data') }}', // Use the Laravel route name
                type: 'POST',
                data: {
                    _token: '{{ csrf_token() }}', // CSRF token for security
                    type: selectedType // Send the type as parameter
                },
                success: function(response) {
                    if (response.success) {
                        // Populate the select dropdown with fetched
                        var pc_staffDropdown = $('#pc_staff');
                        pc_staffDropdown.empty();
                        pc_staffDropdown.append($(
                            '<option value="">Select Project Journal Team Lead</option>'));
                        response.data.forEach(function(level) {
                            pc_staffDropdown.append($('<option></option>').attr('value', level.sno)
                                .text(level.staff_name + ' - ' + level.nick_name));
                        });
                    }
                },
                error: function(xhr, status, error) {
                    var pc_staffDropdown = $('#pc_staff');
                    pc_staffDropdown.empty();
                    pc_staffDropdown.append($('<option value="">Select Project Journal Team Lead</option>'));
                }
            });

            var selectedservice = 'customer_services';
            $.ajax({
                url: '{{ route('get.ajax.data') }}', // Use the Laravel route name
                type: 'POST',
                data: {
                    _token: '{{ csrf_token() }}', // CSRF token for security
                    cus_id: id,
                    type: selectedservice // Send the type as parameter
                },
                success: function(response) {
                    if (response.success) {
                        // Populate the select dropdown with fetched
                        var ServiceDropdown = $('#customer_services');
                        ServiceDropdown.empty();
                        ServiceDropdown.append($('<option value="">Select Service</option>'));
                        response.data.forEach(function(serv) {
                            ServiceDropdown.append($('<option></option>').attr('value', serv.sno).text(
                                serv.service_id + ' - ' + serv.name + ' - ' + serv
                                .product_category_name));
                        });
                    }
                },
                error: function(xhr, status, error) {
                    var ServiceDropdown = $('#customer_services');
                    ServiceDropdown.empty();
                    ServiceDropdown.append($('<option value="">Select Service</option>'));
                }
            });
        }

        function triggerFileUpload(counter) {
            // This dynamically targets the file input using the counter
            const visibleFileInput = document.querySelector(`#document_upload_${counter}:not([style*="display: none"])`);
            if (visibleFileInput) {
                visibleFileInput.click();
            }
        }

        function fileChange(e) {
            const inputId = e.target.id;
            const requirementId = inputId.split('_')[2];
            const file = e.target.files[0];

            if (file) {
                const fileName = file.name;
                const fileType = file.type;
                const allowedImageTypes = ['image/jpeg', 'image/png'];

                const docImg = document.querySelector(`#uploadedlogo_${requirementId}:not([style*="display: none"])`);
                const resetBtn = document.querySelector(`#uploaded_reset_${requirementId}:not([style*="display: none"])`);
                const fileNameDisplay = document.querySelector(
                    `#upload_file_name_${requirementId}:not([style*="display: none"])`);
                const defaultImageSrc = "{{ asset('assets/phdizone_images/Document.jpg') }}";
                const defaultFileText = fileNameDisplay.innerText;

                // Update file name text
                if (fileNameDisplay) {
                    fileNameDisplay.innerText = fileName;
                }

                // Show image preview only for image files
                if (docImg) {
                    if (allowedImageTypes.includes(fileType)) {
                        docImg.src = URL.createObjectURL(file);
                    } else {
                        docImg.src = defaultImageSrc;
                    }
                }

                // Reset logic
                if (resetBtn) {
                    resetBtn.onclick = () => {
                        e.target.value = ''; // Clear input
                        if (docImg) docImg.src = defaultImageSrc;
                        if (fileNameDisplay) fileNameDisplay.innerText = defaultFileText;
                    };
                }
            }
        }
    </script>


    <script>
        let logofile = document.getElementById('uploadedlogo');
        const fileInput = document.querySelector('.file-in');
        const resetFileInput = document.querySelector('.file-reset');

        if (logofile) {
            const resetImage = logofile.src;
            fileInput.onchange = () => {
                if (fileInput.files[0]) {
                    logofile.src = window.URL.createObjectURL(fileInput.files[0]);
                }
            };
            resetFileInput.onclick = () => {
                fileInput.value = '';
                logofile.src = resetImage;
            };
        }
    </script>

    <!--begin::Modal - Appointment Schedule-->
    <div class="modal fade" id="kt_modal_new_jr_follow_up_lead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <form id="followupForm" action="{{ route('add_journal_followup') }}" method="POST" novalidate
                    autocomplete="off">
                    @csrf
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-8 text-center">
                            <h3 class="text-center mb-4 text-black">Followup Schedule</h3>
                        </div>
                        <div class="row mt-4 p-2 bg-gray-200 rounded mb-2">
                            <div class="col-lg-12 mb-3 d-flex align-items-center gap-2">
                                <span class="badge bg-gray-100 rounded-circle"><i
                                        class="mdi mdi-briefcase-account-outline text-black"></i></span>
                                <label class="text-black fs-6 fw-semibold">Customer Details</label>
                                <input type="hidden" name="new_customer_id" id="new_customer_id">

                                <input type="hidden" name="new_service_id" id="new_service_id">

                            </div>
                            <div class="col-lg-6 mb-3">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Customer</label>
                                    <label class="text-black fs-6 fw-medium" id="new_fu_customer">Priya</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Customer Id</label>
                                    <label class="text-black fs-6 fw-medium"
                                        id="new_fu_customer_id">CUS-00004/06/2025</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Service</label>
                                    <label class="text-black fs-6 fw-medium" id="new_fu_customer_service">Research Paper
                                        Writing</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Service Id</label>
                                    <label class="text-black fs-6 fw-medium"
                                        id="new_fu_customer_service_id">SR-00004/2025</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Domain</label>
                                    <label class="text-black fs-6 fw-medium" id="new_fu_domain">Computer Science
                                        Engineering</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Index</label>
                                    <label class="text-black fs-6 fw-medium" id="new_fu_index">Scopus-Q1</label>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-lg-12 mb-3 d-flex align-items-center gap-2">
                                <span class="badge bg-gray-100 rounded-circle"><i
                                        class="mdi mdi-notebook-outline text-black"></i></span>
                                <label class="text-black fs-6 fw-semibold">Journal Team Details</label>
                            </div>
                            <div class="col-lg-6 mb-3 d-flex align-items-center justify-content-start gap-2">
                                <div class="d-flex flex-column">
                                    <label class="text-black fs-6 fw-medium">Bhagiyarathi</label>
                                    <label class="badge bg-label-warning text-dark fs-7 fw-medium">Journal Team
                                        Lead</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3 d-flex align-items-center justify-content-start gap-2">
                                <div class="d-flex flex-column">
                                    <label class="text-black fs-6 fw-medium">Prema</label>
                                    <label class="badge bg-label-warning text-dark fs-7 fw-medium">Journal
                                        Executive</label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Date<span
                                        class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="lead_apt_sch" name="appointment_date"
                                        placeholder="Select Date" class="form-control" value="" />
                                </div>
                                <div class="text-danger" id="apt_date_err"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Time<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control common_time_class" placeholder="HH:MM"
                                    id="apt_time_followp" name="appointment_time" />
                                <div class="text-danger" id="apt_time_err"></div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id="followupBtn" class="btn btn-primary"
                                    onclick="FollowupvalidateForm()">Schedule</button>
                            </div>
                        </div>

                    </div>
                </form>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Appointment Schedule-->
    <script>
        function OpenNewFollowUP(service, cus_sno, cus_name, cus_id, ser_name, ser_id, domain, index, jtl, je) {
            $('#new_service_id').val(service);
            $('#new_customer_id').val(cus_sno);

        }


        function FollowupvalidateForm() {
            var err = 0;
            $('#followupBtn').prop('disabled', true);
            // Validate knowledge Name
            var lead_apt_sch = document.getElementById("lead_apt_sch").value.trim();
            if (lead_apt_sch === "") {
                document.getElementById('apt_date_err').innerHTML = 'Appointment Date is required...!';
                document.getElementById('lead_apt_sch').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('lead_apt_sch').classList.remove('error_msg');
                document.getElementById('apt_date_err').innerHTML = '';
            }
            // Validate knowledge Name
            var apt_time_followp = document.getElementById("apt_time_followp").value.trim();
            if (apt_time_followp === "") {
                document.getElementById('apt_time_err').innerHTML = 'Appointment Time is required...!';
                document.getElementById('apt_time_followp').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('apt_time_followp').classList.remove('error_msg');
                document.getElementById('apt_time_err').innerHTML = '';
            }
            if (err === 0) {
                $('#followupBtn').prop('disabled', true);
                $('#followupForm').submit();

            } else {
                $('#followupBtn').prop('disabled', false);
            }
        }
    </script>

    <!--begin::Modal - Pending Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_jr_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Report</h3>
                    </div>
                    <form id="updateResheduleForm" autocomplete="off">
                        <div class="row mt-4 p-2 bg-gray-200 rounded mb-2">
                            <div class="col-lg-12 mb-2 d-flex align-items-center gap-2">
                                <span class="badge bg-gray-100 rounded-circle"><i
                                        class="mdi mdi-briefcase-account-outline text-black"></i></span>
                                <label class="text-black fs-6 fw-semibold">Customer Details</label>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Customer</label>
                                    <label class="text-black fs-6 fw-medium cus_name">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Customer Id</label>
                                    <label class="text-black fs-6 fw-medium cus_id">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Service</label>
                                    <label class="text-black fs-6 fw-medium cus_service">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Service Id</label>
                                    <label class="text-black fs-6 fw-medium cus_service_id">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Domain</label>
                                    <label class="text-black fs-6 fw-medium cus_domain">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Index</label>
                                    <label class="text-black fs-6 fw-medium cus_index">-</label>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-lg-12 mb-2 d-flex align-items-center gap-2">
                                <span class="badge bg-gray-100 rounded-circle"><i
                                        class="mdi mdi-clock-outline text-black"></i></span>
                                <label class="text-black fs-6 fw-semibold">Follow-up Details</label>
                            </div>
                            <div class="col-lg-4 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Follow-up Date</label>
                                    <label class="text-black fs-6 fw-medium" id="app_date">-</label>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Follow-up Time</label>
                                    <label class="text-black fs-6 fw-medium" id="app_time">-</label>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-1 d-flex align-items-center justify-content-end">
                                <div class="text-black fs-5 fw-semibold">
                                    <span>Reschedule Count</span>
                                    <span class="badge bg-danger fs-6 text-white rounded"
                                        id="followup_reschedule_count">0</span>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-lg-12 mb-2 d-flex align-items-center gap-2">
                                <span class="badge bg-gray-100 rounded-circle"><i
                                        class="mdi mdi-notebook-outline text-black"></i></span>
                                <label class="text-black fs-6 fw-semibold">Journal Team Details</label>
                            </div>
                            <div class="col-lg-6 mb-2 d-flex align-items-center justify-content-start gap-2">
                                {{-- <div class="avatar">
                                    <img src="{{ asset('assets/phdizone_images/staff_1.png') }}" alt="staff image"
                                        class="w-42px h-42px rounded-circle border border-dark">
                                </div> --}}
                                <div class="d-flex flex-column">
                                    <label class="text-black fs-6 fw-medium jtl_fp">-</label>
                                    <label class="badge bg-label-warning text-dark fs-7 fw-medium">Journal Team
                                        Lead</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2 d-flex align-items-center justify-content-start gap-2">
                                {{-- <div class="avatar">
                                    <img src="{{ asset('assets/phdizone_images/staff_1.png') }}" alt="staff image"
                                        class="w-42px h-42px rounded-circle border border-dark">
                                </div> --}}
                                <div class="d-flex flex-column">
                                    <label class="text-black fs-6 fw-medium je_fp">-</label>
                                    <label class="badge bg-label-warning text-dark fs-7 fw-medium">Journal
                                        Executive</label>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-lg-12 mb-4">
                                <label class="text-black mb-1 fs-6 fw-semibold mt-4 me-2  d-block">Progressed<span
                                        class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="progressed" id="progressed"
                                        value="1" name="progressed" onclick="progress_func('yes');" checked />
                                    <label class="form-check-label">Yes</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="progressed" id="progressed"
                                        value="2" name="progressed" onclick="progress_func('no');" />
                                    <label class="form-check-label">No</label>
                                </div>
                            </div>
                        </div>
                        <div id="message" name="message">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold d-block">
                                        Follow Through <span class="text-danger">*</span>
                                    </label>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="direct_call" value="1" checked />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="direct_call">Direct Call</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="whatsapp_chat" value="2" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="whatsapp_chat">Whatsapp Chat</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="whatsapp_call" value="3" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="whatsapp_call">Whatsapp Call</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="email" value="4" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="email">E-Mail</label>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold d-block">Conversation Message<span
                                            class="text-danger">*</span></label>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="1" checked />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Positive</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="-1" />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Negative</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="0" />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Neutral</label>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <textarea class="form-control" rows="3" id="convo_message"
                                        oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"
                                        placeholder="Enter Conversation Message"></textarea>
                                    <div class="text-danger" id="convo_message_err"></div>
                                </div>
                            </div>
                            <div class="border-bottom mb-3 mt-2"></div>
                        </div>
                        <div id="reason" name="reason" style="display: none !important;">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select" id="app_reason" name="app_reason"
                                        onchange="toggleInputField_followup(this.value)">
                                        <option value="">Select Reason</option>
                                        @if (isset($followupReasonList))
                                            @foreach ($followupReasonList as $s_reason)
                                                <option value="{{ $s_reason->reason_name }}"
                                                    data-comments-check-followup="{{ $s_reason->comments_check }}">
                                                    {{ $s_reason->reason_name }}
                                                </option>
                                            @endforeach
                                        @endif
                                        <option value="1">Others</option>
                                    </select>
                                    <div class="text-danger" id="app_reason_select_err"></div>
                                    <div class="mt-4" id="followup_reason_div" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="followup_reason_text"
                                            id="followup_reason_text" value="" placeholder="Enter Reason">
                                        <div class="text-danger" id="followup_comments_text_err"></div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Date<span
                                                class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="re_app_date" placeholder="Select Date"
                                                class="form-control" value="" name="appointment_date" />

                                        </div>
                                        <div class="text-danger" id="re_app_date_err"></div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Time<span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control common_time_class_new"
                                            placeholder="HH:MM" id="re_app_time" name="appointment_time"
                                            value="" />
                                        <div class="text-danger" id="re_app_time_err"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="border-bottom mb-3 mt-2"></div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="accordion">
                                    <div class="accordion-item mb-2 active">
                                        <h2 class="accordion-header" id="headingPopoutOne">
                                            <button type="button" class="accordion-button" data-bs-toggle="collapse"
                                                data-bs-target="#accordionPopoutOne" aria-expanded="true"
                                                aria-controls="accordionPopoutOne">
                                                <span class="text-black fw-semibold fs-6">Followup History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="app_count">00</span>
                                            </button>
                                        </h2>
                                        <div id="accordionPopoutOne" class="accordion-collapse collapse show"
                                            aria-labelledby="headingPopoutOne" data-bs-parent="#accordionPopout">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-125px">Last Followup<br>Date / Time
                                                                    </th>
                                                                    <th class="min-w-125px">Followed By</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="historicalLeadIdsTableBody">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id='rescheduleBtn' class="btn btn-primary"
                                    onclick="updateReshedule()">Submit
                                    Report</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Pending Followup Lead Schedule-->
    <script>
        let reshedule_id;
        let customer_id;

        // ✅ Initialize Flatpickr (Time Picker)
        document.addEventListener("DOMContentLoaded", function() {
            flatpickr("#re_app_time", {
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                time_24hr: true,
                minuteIncrement: 5
            });
        });

        // ✅ Open Modal + Load Data
        function openFpResheduleModal(categoryId, CustomerID) {

            reshedule_id = categoryId;
            customer_id = CustomerID;

            function formatDate(dateString) {
                const date = new Date(dateString);
                const day = date.getDate().toString().padStart(2, '0');
                const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                const month = monthNames[date.getMonth()];
                const year = date.getFullYear();
                return `${day}-${month}-${year}`;
            }

            function formatTime(timeString) {
                const date = new Date(`1970-01-01T${timeString}`);
                let hours = date.getHours();
                const minutes = date.getMinutes().toString().padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12 || 12;
                return `${hours}:${minutes} ${ampm}`;
            }

            fetch(`/EditjournalFollowup/${categoryId}`)
                .then(response => response.json())
                .then(data => {

                    if (data.status === 200) {

                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;

                        // ✅ Set current appointment
                        document.getElementById('app_date').innerText = formatDate(lead.appointment_date);
                        document.getElementById('app_time').innerText = formatTime(lead.appointment_time);

                        $('#followup_reschedule_count_again').text(data.data.reschedule_count);
                        $('#followup_reschedule_count').text(data.data.reschedule_count);
                        $('#followup_reschedule_rep_count').text(data.data.reschedule_count);

                        $('#app_count').html(historicalLeadIds.length);
                        $('.jtl_fp').html(lead.jouranal_coordinator_name);
                        $('.je_fp').html(lead.journal_staff_name);
                        $('.cus_name').html(lead.cus_name);
                        $('.cus_id').html(lead.customer_id);
                        $('.cus_service').html(lead.service_id);
                        $('.cus_service_id').html(lead.service_id);
                        $('.cus_index').html(lead.index_names);
                        $('.cus_domain').html(lead.domain_names || 'N/A');

                        // ✅ Table rendering
                        const tbody = document.getElementById('historicalLeadIdsTableBody');
                        tbody.innerHTML = '';

                        if (historicalLeadIds.length > 0) {

                            const FollowThough = [
                                'Unknown',
                                'Direct Call',
                                'Whatsapp Chat',
                                'Whatsapp Call',
                                'E-Mail'
                            ];

                            historicalLeadIds.forEach((category, index) => {
                                var FollowThoughsts = category.is_reschedule == 0 ? FollowThough[category
                                    .follow_through ?? 0] : 'Re-schedule';
                                const row = `
                        <tr class="${category.is_reschedule == 1 ? 'bg-danger' : ''}">
                            <td>${index + 1}</td>
                            <td>
                                ${formatDate(category.appointment_date)}<br>
                                ${formatTime(category.appointment_time)}
                            </td>
                            <td>
                                ${category.staff_name}<br>
                                <span class="badge bg-info">
                                    ${FollowThoughsts}
                                </span>
                            </td>
                            <td title="${category.convo_message ?? '-'}">
                                ${category.convo_message ?? '-'}
                            </td>
                            <td title="${category.reason ?? '-'}">
                                ${category.reason ?? '-'}
                            </td>
                        </tr>`;

                                tbody.innerHTML += row;
                            });

                            $('[data-bs-toggle="tooltip"]').tooltip();

                        } else {
                            tbody.innerHTML = `<tr><td colspan="5">No Records</td></tr>`;
                        }

                    } else {
                        console.error('Error:', data.message);
                    }
                })
                .catch(error => console.error('Fetch Error:', error));
        }

        // ✅ Update Reschedule
        function updateReshedule() {

            const resheduleid = reshedule_id;
            const customerid = customer_id;
            const progressed = document.querySelector('input[name="progressed"]:checked')?.value;

            let app_score = null;
            let convo_message = null;
            let follow_through = null;
            let reason = null;
            let appointment_date = null;
            let appointment_time = null;

            let err = 0;

            if (progressed == 1) {

                app_score = document.querySelector('input[name="app_score"]:checked')?.value;
                follow_through = document.querySelector('input[name="follow_through"]:checked')?.value;
                convo_message = document.getElementById('convo_message').value;

                if (!convo_message) {
                    $('#convo_message_err').text('Conversation Message is Required');
                    err++;
                } else {
                    $('#convo_message_err').text('');
                }

            } else {

                reason = document.getElementById('app_reason').value;
                const other_reason = document.getElementById('followup_reason_text').value;

                appointment_date = document.getElementById('re_app_date').value;
                appointment_time = document.getElementById('re_app_time').value;

                if (!reason) {
                    $('#app_reason_select_err').text('Reason is Required');
                    err++;
                } else {
                    $('#app_reason_select_err').text('');
                }

                if (reason == 1 && !other_reason) {
                    $('#followup_comments_text_err').text('Other Reason is Required');
                    err++;
                } else if (reason == 1) {
                    reason = other_reason;
                }

                if (!appointment_date) {
                    $('#re_app_date_err').text('Followup Date is Required');
                    err++;
                } else {
                    $('#re_app_date_err').text('');
                }

                if (!appointment_time) {
                    $('#re_app_time_err').text('Followup Time is Required');
                    err++;
                } else {
                    $('#re_app_time_err').text('');
                }
            }

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            if (err === 0) {

                $('#rescheduleBtn').prop('disabled', true);

                fetch(`/journal_followup_update/${resheduleid}/${customerid}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        },
                        body: JSON.stringify({
                            progressed,
                            app_score,
                            follow_through,
                            convo_message,
                            reason,
                            appointment_date,
                            appointment_time
                        })
                    })
                    .then(response => response.json()) // ✅ FIXED
                    .then(data => {

                        if (data.status === 200) {
                            toastr.success('Follow-up Updated successfully!');
                            location.reload();
                        } else {
                            toastr.error('Follow-up Failed to update!');
                            $('#rescheduleBtn').prop('disabled', false);
                        }
                    })
                    .catch(error => {
                        console.error('Update Error:', error);
                        $('#rescheduleBtn').prop('disabled', false);
                    });

            } else {
                $('#rescheduleBtn').prop('disabled', false);
            }
        }
    </script>
    <script>
        function progress_func(prog_val) {
            if (prog_val == 'no') {
                document.getElementById("message").style.display = "none";
                document.getElementById("reason").style.display = "block";
            } else {
                document.getElementById("message").style.display = "block";
                document.getElementById("reason").style.display = "none";
            }
        }
    </script>

    <!--begin::Modal - Again Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_again_jr_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">New Followup</h3>
                    </div>
                    <form action="{{ route('add_journal_followup') }}" method="POST" id="newfollowupForm"
                        autocomplete="off">
                        @csrf
                        <div class="row mt-4 p-2 bg-gray-200 rounded mb-2">
                            <input type="hidden" name="new_customer_id" class="new_customer_id">
                            <input type="hidden" name="new_service_id" class="new_service_id">
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Customer</label>
                                    <label class="text-black fs-6 fw-medium cus_name">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Customer Id</label>
                                    <label class="text-black fs-6 fw-medium cus_id">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Service</label>
                                    <label class="text-black fs-6 fw-medium cus_service">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Service Id</label>
                                    <label class="text-black fs-6 fw-medium cus_service_id">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Domain</label>
                                    <label class="text-black fs-6 fw-medium cus_domain">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Index</label>
                                    <label class="text-black fs-6 fw-medium cus_index">-</label>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-lg-12 mb-3 d-flex align-items-center gap-2">
                                <span class="badge bg-gray-100 rounded-circle"><i
                                        class="mdi mdi-notebook-outline text-black"></i></span>
                                <label class="text-black fs-6 fw-semibold">Journal Team Details</label>
                            </div>
                            <div class="col-lg-6 mb-2 d-flex align-items-center justify-content-start gap-2">
                                {{-- <div class="avatar">
                                    <img src="{{ asset('assets/phdizone_images/staff_1.png') }}" alt="staff image"
                                        class="w-42px h-42px rounded-circle border border-dark">
                                </div> --}}
                                <div class="d-flex flex-column">
                                    <label class="text-black fs-6 fw-medium jtl_fp">-</label>
                                    <label class="badge bg-label-warning text-dark fs-7 fw-medium">Journal Team
                                        Lead</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2 d-flex align-items-center justify-content-start gap-2">
                                {{-- <div class="avatar">
                                    <img src="{{ asset('assets/phdizone_images/staff_1.png') }}" alt="staff image"
                                        class="w-42px h-42px rounded-circle border border-dark">
                                </div> --}}
                                <div class="d-flex flex-column">
                                    <label class="text-black fs-6 fw-medium je_fp">-</label>
                                    <label class="badge bg-label-warning text-dark fs-7 fw-medium">Journal
                                        Executive</label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="app_date_again" name="appointment_date"
                                        placeholder="Select Date" class="form-control cus_date_doj"
                                        value="{{ date('d-M-Y') }}" />
                                </div>
                                <div class="text-danger" id="app_date_again_err"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Time</label>
                                <input type="text" class="form-control app_new_time_class" placeholder="HH:MM"
                                    id="app_time_again" name="appointment_time" />
                                <div class="text-danger" id="app_time_again_err"></div>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-end">
                                <div class="text-black fs-5 fw-semibold">
                                    <span>Reschedule Count</span>
                                    <span class="badge bg-danger fs-6 text-white rounded"
                                        id="followup_reschedule_count_again">0</span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="accordion">
                                    <div class="accordion-item mb-2">
                                        <h2 class="accordion-header" id="again_flw_headingPopoutOne">
                                            <button type="button" class="accordion-button collapsed"
                                                data-bs-toggle="collapse" data-bs-target="#again_flw_accordionPopoutOne"
                                                aria-expanded="false" aria-controls="again_flw_accordionPopoutOne">
                                                <span class="text-black fw-semibold fs-6">Followup History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="app_count_again">00</span>
                                            </button>
                                        </h2>
                                        <div id="again_flw_accordionPopoutOne" class="accordion-collapse collapse"
                                            aria-labelledby="again_flw_headingPopoutOne">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-125px">Last Followup<br>Date / Time
                                                                    </th>
                                                                    <th class="min-w-125px">Followed By</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="historicalLeadIdsTableBodyAgain">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id="newfollowupBtn" class="btn btn-primary"
                                    onclick="NewFollowupvalidateForm()">Schedule</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Again Followup Lead Schedule-->

    <script>
        function formatDate(dateString) {
            const date = new Date(dateString);
            const day = date.getDate().toString().padStart(2, '0');
            const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            const month = monthNames[date.getMonth()];
            const year = date.getFullYear();
            return `${day}-${month}-${year}`;
        }
        // new appointment
        let resheduleagain_id;
        let customeragain_id;

        function openResheduleModalAgain(categoryId, CustomerID) {

            resheduleagain_id = categoryId;
            customeragain_id = CustomerID;
            // Function to format date to '10-Jun-2024'
            

            function formatTime(timeString) {
                const date = new Date(`1970-01-01T${timeString}Z`);
                let hours = date.getUTCHours();
                const minutes = date.getUTCMinutes().toString().padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                return `${hours}:${minutes} ${ampm}`;
            }
            fetch(`/EditjournalFollowup/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;
                        $('#followup_reschedule_count_again').text(data.data.reschedule_count);
                        $('#followup_reschedule_count').text(data.data.reschedule_count);
                        $('#followup_reschedule_rep_count').text(data.data.reschedule_count);
                        $('.new_service_id').val(categoryId);
                        $('.new_customer_id').val(CustomerID);
                        $('#app_count').html(data.data.appointmentCount);
                        $('.jtl_fp').html(lead.jouranal_coordinator_name);
                        $('.je_fp').html(lead.journal_staff_name);
                        $('.cus_name').html(lead.cus_name);
                        $('.cus_id').html(lead.customer_id);
                        $('.cus_service').html(lead.service_id);
                        $('.cus_service_id').html(lead.service_id);
                        $('.cus_index').html(lead.index_names);
                        $('.cus_domain').html(lead.domain_names || 'N/A');

                        const historicalTableBody = document.getElementById('historicalLeadIdsTableBodyAgain');
                        historicalTableBody.innerHTML = '';
                        $('#app_count_again').html(historicalLeadIds.length);
                        if (historicalLeadIds.length > 0) {
                            for (let index = 0; index < historicalLeadIds.length; index++) {
                                const category = historicalLeadIds[index];
                                if (category.app_score === 1) {
                                    var score =
                                        `<span class="text-success fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                } else if (category.app_score === -1) {
                                    var score =
                                        `<span class="text-danger fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                } else if (category.app_score === 0) {
                                    var score =
                                        `<span class="text-info fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                } else {
                                    var score = `<span class="text-info fw-bold fs-5 text-center">-</span>`;
                                }
                                const FollowThough = [
                                    'Unknown', // 0
                                    'Direct Call', // 1
                                    'Whatsapp Chat', // 2
                                    'Whatsapp Call', // 3
                                    'E-Mail', // 4
                                ];
                                var FollowThoughsts = category.is_reschedule == 0 ? FollowThough[category
                                    .follow_through ?? 0] : 'Re-schedule';
                                const row = `
                        <tr class="${category.is_reschedule == 1 ? 'bg-danger' : ''}">
                                <td>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-2">${index + 1}</span>
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="fs-8 text-black fw-semibold">${formatDate(category.appointment_date)}</label>
                                    <div class="d-block text-dark fs-8"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="Last Followup Date">${formatTime(category.appointment_time)}</div>
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <div class="text-black fw-semibold fs-7 mb-1">${category.staff_name}</div>
                                        <div> <span class="bg-info text-white text-center p-1 rounded" title="Follow though">${FollowThoughsts}</span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.convo_message ? category.convo_message : '-'}">${category.convo_message ? category.convo_message : '-'}
                                        </div>
                                </td>
                                <td>
                                    <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.reason ? category.reason : '-'}">${category.reason ? category.reason : '-'}
                                        </div>
                                </td>
                            </tr>`;
                                historicalTableBody.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }
                        } else {
                            const row = `<tr>
                                        
                                    </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }

                        $('[data-bs-toggle="tooltip"]').tooltip();


                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                    $('[data-bs-toggle="tooltip"]').tooltip();
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });


        }

        function NewFollowupvalidateForm() {
            var err = 0;
            $('#newfollowupBtn').prop('disabled', true);
            // Validate knowledge Name
            var app_date_again = document.getElementById("app_date_again").value.trim();
            if (app_date_again === "") {
                document.getElementById('app_date_again_err').innerHTML = 'Appointment Date is required...!';
                document.getElementById('app_date_again').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('app_date_again').classList.remove('error_msg');
                document.getElementById('app_date_again_err').innerHTML = '';
            }
            // Validate knowledge Name
            var app_time_again = document.getElementById("app_time_again").value.trim();
            if (app_time_again === "") {
                document.getElementById('app_time_again_err').innerHTML = 'Appointment Time is required...!';
                document.getElementById('app_time_again').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('app_time_again').classList.remove('error_msg');
                document.getElementById('app_time_again_err').innerHTML = '';
            }
            if (err === 0) {
                $('#newfollowupBtn').prop('disabled', true);
                $('#newfollowupForm').submit();
            } else {
                $('#newfollowupBtn').prop('disabled', false);
            }
        }


        function toggleInputField_followup(value) {
            var followupReasonDiv = document.getElementById('followup_reason_div');
            var followupReasonText = document.getElementById('followup_reason_text');
            // var followupCommentsDiv = document.getElementById('followup_comments_div');
            var selectedOption = document.querySelector('#app_reason option:nth-child(' + (document.getElementById(
                'app_reason').selectedIndex + 1) + ')');
            // var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check-followup') : null;

            if (value == '1') {
                followupReasonDiv.style.display = 'block';
                followupReasonText.setAttribute('required', 'required');
            } else {
                followupReasonDiv.style.display = 'none';
                followupReasonText.removeAttribute('required');
            }
        }
    </script>

    <!--begin::Modal - Generate NOC-->
    <div class="modal fade" id="kt_modal_generate_noc" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Generate NOC</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 my-4">
                            <div class="row">
                                <div class="col-lg-12 mb-4">
                                    <div class="row">
                                        <div class="col-4 text-dark fs-6 fw-semibold">Customer</div>
                                        <div class="col-1 text-black fs-6 fw-bold">:</div>
                                        <div class="col-7 text-black fs-6 fw-semibold ">
                                            <label id="noc_customer_name">-</label>
                                            <span class="text-danger text-nowrap">( <span id="noc_customer_code"></span>
                                                )</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-4">
                                    <div class="row">
                                        <div class="col-4 text-dark fs-6 fw-semibold">Services </div>
                                        <div class="col-1 text-black fs-6 fw-bold">:</div>
                                        <div class="col-7 text-black fs-6 fw-semibold ">
                                            <label id="noc_service_name"></label>
                                            <span class="text-danger text-nowrap" id="noc_service_code"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-4">
                                    <div class="row">
                                        <div class="col-4 text-dark fs-6 fw-semibold">Journal</div>
                                        <div class="col-1 text-black fs-6 fw-bold">:</div>
                                        <div class="col-7 text-black fs-6 fw-semibold ">
                                            <label id="noc_journal_title"></label>
                                            <span class="text-danger text-nowrap" id="noc_journal_code"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-4">
                                    <div class="row">
                                        <div class="col-4 text-dark fs-6 fw-semibold">Booklet</div>
                                        <div class="col-1 text-black fs-6 fw-bold">:</div>
                                        <div class="col-7 text-black fs-6 fw-semibold">
                                            <div id="noc_booklet"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-4">
                                    <div class="row">
                                        <div class="col-4 text-dark fs-6 fw-semibold">Domain</div>
                                        <div class="col-1 text-black fs-6 fw-bold">:</div>
                                        <div class="col-7 text-black fs-6 fw-semibold">
                                            <div id="noc_domain"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-4">
                                    <div class="row">
                                        <div class="col-4 text-dark fs-6 fw-semibold">Status</div>
                                        <div class="col-1 text-black fs-6 fw-bold">:</div>
                                        <div class="col-7 ">
                                            <span class="badge bg-label-info text-black fs-6 fw-semibold px-2"
                                                style="border-radius:3px;">
                                                <div id="noc_status"></div>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-4">
                                    <div class="row">
                                        <div class="col-4 text-dark fs-6 fw-semibold">Submitted Date</div>
                                        <div class="col-1 text-black fs-6 fw-bold">:</div>
                                        <div class="col-7 ">
                                            <span class="badge bg-label-success text-black fs-6 fw-semibold px-2"
                                                style="border-radius:3px;">
                                                <div id="noc_submitted_date"></div>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="d-flex align-items-center flex-wrap gap-2">
                                    <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_whats_app"
                                        onclick="send_proposal_whatsapp_func();">
                                        <div
                                            class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                            <img src="{{ asset('assets/phdizone_images/social_media/whatsapp.png') }}"
                                                alt="whatsapp" class="w-45px h-45px" />
                                            <div class="d-block">
                                                <div class="text-dark fw-semibold fs-8 social_md_txt">Whats App</div>
                                            </div>
                                        </div>
                                    </a>
                                    <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_email"
                                        onclick="send_proposal_email_func();">
                                        <div
                                            class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                            <img src="{{ asset('assets/phdizone_images/social_media/email.png') }}"
                                                alt="email" class="w-45px h-45px" />
                                            <div class="d-block">
                                                <div class="text-dark fw-semibold fs-8 social_md_txt">Email</div>
                                            </div>
                                        </div>
                                    </a>
                                    <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_message"
                                        onclick="send_proposal_message_func();">
                                        <div
                                            class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                            <img src="{{ asset('assets/phdizone_images/social_media/message.png') }}"
                                                alt="message" class="w-45px h-45px" />
                                            <div class="d-block">
                                                <div class="text-dark fw-semibold fs-8 social_md_txt">Message</div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="3" placeholder="Enter Description"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        {{-- <a href="{{ url('/manage_journal_noc') }}"> --}}
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Generate
                            NOC</button>
                        {{-- </a> --}}

                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal -  Generate NOC-->
    <script>
        function Generate_nocData(ID) {
            fetch(`/journal_noc_generate/${ID}`)
                .then(response => response.json())
                .then(data => {

                    if (data.status === 200) {

                        let journal = data.data.journal_details;
                        let customer = data.data.customer_details;

                        // Customer
                        document.getElementById('noc_customer_name').innerText = customer.cus_name ?? '-';
                        document.getElementById('noc_customer_code').innerText = `(${customer.customer_id ?? '-'})`;

                        // Service
                        document.getElementById('noc_service_name').innerText = customer.service_name ?? '-';
                        document.getElementById('noc_service_code').innerText = `(${customer.service_id ?? '-'})`;
                        
                        // Journal
                        document.getElementById('noc_journal_title').innerText = journal.paper_name ?? '-';
                        document.getElementById('noc_journal_code').innerText = `(${journal.journal_id ?? '-'})`;

                        // Booklet (you don’t have name, only ID)
                        document.getElementById('noc_booklet').innerText = customer.journal_data.journal_name ?? '-';

                        // Domain (not available → fallback)
                        document.getElementById('noc_domain').innerText = customer.journal_data.domain_names ?? '-';

                        // Status Mapping (important)
                        let statusText = 'Unknown';
                        switch (journal.status) {
                            case 1:
                                statusText = 'Submitted';
                                break;
                            case 2:
                                statusText = 'Under Review';
                                break;
                            case 3:
                                statusText = 'Reviewed';
                                break;
                            case 4:
                                statusText = 'Accepted';
                                break;
                            case 8:
                                statusText = 'Published';
                                break;
                        }
                        statusText = 'Published';

                        document.getElementById('noc_status').innerHTML =
                            `<span class="badge bg-label-info text-black">${statusText}</span>`;

                        // Submitted Date
                        let date = formatDate(journal.submited_date ? journal.submited_date.split(' ')[0] : '-');
                        document.getElementById('noc_submitted_date').innerHTML =
                            `<span class="badge bg-label-success text-black">${date}</span>`;

                        // Open modal
                        // let modal = new bootstrap.Modal(document.getElementById('kt_modal_generate_noc'));
                        // modal.show();

                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    </script>

    <!--begin::Modal - Close Journal -->
    <div class="modal fade" id="kt_modal_journal_closer" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to close Journal ?
                    <div class="d-block fw-semibold text-danger mt-4 fs-5 py-2" id="Journal_data">

                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="submit" class="btn btn-danger me-3" onclick="ConfrimClose()">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Close Journal -->
    <script>
        function CloseFetch(id, name, IDS) {
            const dangerBtn = document.querySelector('#kt_modal_journal_closer .btn-danger');
            if (dangerBtn) {
                dangerBtn.setAttribute('data-id', id);
            }
            $('#Journal_data').html(`<label class="text-info">${IDS}</label><br>
                        <label>${name}</label>`);
        }

        function ConfrimClose() {
            const dangerBtn = document.querySelector('#kt_modal_journal_closer .btn-danger');
            if (!dangerBtn) {
                toastr.error('Modal element not found');
                return;
            }

            const ID = dangerBtn.getAttribute('data-id');
            if (!ID) {
                toastr.error('No journal selected');
                return;
            }

            fetch('/close_journal/' + ID, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        return response.json().then(err => Promise.reject(err));
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.status === 200) {
                        toastr.success(data.message);
                        setTimeout(() => location.reload(), 1000); // Slight delay for better UX
                    } else {
                        toastr.error(data.error_msg || data.message || 'Failed to close journal');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    toastr.error(error.error_msg || 'An unexpected error occurred. Please try again.');
                });
        }
    </script>

@endsection
