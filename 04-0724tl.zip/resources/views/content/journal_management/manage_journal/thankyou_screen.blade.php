@extends('layouts/blankLayout')

@section('title', 'NOC Submitted - Thank You')

@section('content')

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            /* font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; */
            background: linear-gradient(135deg, #f8fafc 0%, #fcfeff 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .thank-you-container {
            background: white;
            max-width: 460px;
            width: 100%;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            margin: 0 auto;
        }

        /* Success Header */
        .success-header {
            background: linear-gradient(135deg, #10b981, #34d399);
            padding: 40px 20px 30px;
            text-align: center;
            color: white;
        }

        .success-icon {
            width: 90px;
            height: 90px;
            /* background: rgba(255, 255, 255, 0.95); */
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
        }

        .success-icon i {
            font-size: 48px;
            color: #10b981;
        }

        .success-header h1 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
            letter-spacing: 0.5px;
        }

        .success-header p {
            font-size: 16px;
            opacity: 0.95;
            font-weight: 500;
        }

        /* Content Area */
        .content-area {
            padding: 35px 30px 40px;
            text-align: center;
        }

        .thank-you-text {
            font-size: 20px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 12px;
        }

        .message {
            font-size: 15.5px;
            line-height: 1.65;
            color: #4b5563;
            margin-bottom: 35px;
        }

        /* Buttons */
        .btn-group {
            display: flex;
            flex-direction: column;
            gap: 14px;
        }

        .btn {
            padding: 16px 24px;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background: #10b981;
            color: white;
        }

        .btn-primary:hover {
            background: #059669;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: white;
            color: #374151;
            border: 2px solid #e5e7eb;
        }

        .btn-secondary:hover {
            border-color: #10b981;
            color: #10b981;
        }

        .btn i {
            margin-right: 8px;
        }

        /* Responsive */
        @media (max-width: 480px) {
            .thank-you-container {
                border-radius: 16px;
                margin: 10px;
            }

            .success-header {
                padding: 35px 20px 25px;
            }

            .success-icon {
                width: 80px;
                height: 80px;
            }

            .success-icon i {
                font-size: 42px;
            }

            .success-header h1 {
                font-size: 24px;
            }

            .content-area {
                padding: 30px 25px 35px;
            }

            .btn {
                padding: 15px 20px;
                font-size: 15.5px;
            }
        }

        @media (max-width: 360px) {
            .content-area {
                padding: 25px 20px;
            }
        }
    </style>

    <div class="thank-you-container">
        <div class="success-header">
            <div class="success-icon">
                <img src="{{ asset('assets/phdizone_images/Correct.gif') }}" alt="Tick Mark" class="responsive-img"
                    width="150px" height="150px">
            </div>
            <h1 class="text-white">NOC Submitted!</h1>
            <p>Successfully acknowledged & processed</p>
        </div>
        <div class="content-area">
            <h2 class="thank-you-text">Thank you for your support</h2>
            <p class="message">
                Thank you for providing the NOC and trusting our expertise
                We appreciate the opportunity to assist with your thesis and research work.
            </p>
            {{-- <p class="message m-0 text-danger">
            Redirecting in <span id="count">5</span> seconds...
        </p> --}}
            <!-- <label class="text-danger loction_msg d-none" id="count"></label> -->
        </div>

    </div>
    <script>
        // let seconds = 5;
        // const countdown = setInterval(function () {
        //     document.getElementById("count").innerText = seconds;
        //     seconds--;
        //     if (seconds < 0) {
        //         clearInterval(countdown);
        //         window.location.href = "google.com";
        //     }
        // }, 1000);
    </script>


@endsection
