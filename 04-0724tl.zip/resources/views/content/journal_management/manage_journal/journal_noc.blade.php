@extends('layouts/blankLayout')

@section('title', 'No Objection Certificate [NOC]')

@section('content')

    <style>
        .content-wrapper {
            width: 100%;
            max-width: 210mm;
            margin: 0 auto;
            padding: 20px;
            display: block;
            background-color: #ffffff;
        }

        img {
            max-width: 100%;
            height: auto;
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            flex-wrap: wrap;
        }

        .eibs_title {
            font-weight: bold;
            color: black;
            text-align: center;
            margin: 20px 0 25px 0;
            font-size: 28px;
            width: 100%;
        }

        .main-content {
            font-size: 15.5px;
            line-height: 1.65;
            color: #333;
        }

        .greeting {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .credentials-box {
            background: #fffce8;
            border: 1px solid #e5ca25;
            padding: 18px;
            margin: 20px 0;
            border-radius: 6px;
            font-size: 15px;
        }

        .review-links a {
            color: #0066cc;
            text-decoration: underline;
        }

        .trustpilot-link {
            display: inline-block;
            max-width: 100%;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;

        }

        .acknowledgement {
            margin-top: 40px;
            padding: 20px;
            border: 2px solid #0066cc;
            border-radius: 8px;
            background: #f8f9ff;

        }

        .checkbox-container {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin-top: 10px;
        }

        .checkbox-container input[type="checkbox"] {
            margin-top: 4px;
            width: 18px;
            height: 18px;
            accent-color: #0066cc;
        }

        .ack-btn {
            font-size: 18px;
            font-weight: 600;
            padding: 14px 32px;
            letter-spacing: 0.5px;
            text-transform: none;
            width: auto;
            min-width: 280px;
        }

        @media (max-width: 768px) {
            .main-content {
                font-size: 14.5px;
                line-height: 1.6;
            }

            .eibs_title {
                font-size: 24px;
                margin: 15px 0 20px 0;
            }

            .credentials-box {
                font-size: 14px;
                padding: 15px;
            }

            .ack-btn {
                font-size: 17px;
                padding: 13px 28px;
                min-width: 260px;
            }
        }

        @media (max-width: 480px) {
            .main-content {
                font-size: 14px;
                line-height: 1.55;
            }

            .eibs_title {
                font-size: 22px;
            }

            .header {
                flex-direction: column;
                text-align: center;
                gap: 8px;
            }

            .ack-btn {
                font-size: 16px;
                padding: 12px 24px;
                width: 100%;
                min-width: 100%;
            }
        }

        @media (max-width: 360px) {
            .eibs_title {
                font-size: 20px;
            }

            .main-content {
                font-size: 13.5px;
            }
        }

        /* Print Styles */
        @media print {
            body {
                background: white !important;
                color: black !important;
            }

            .noprint {
                display: none !important;
            }

            .content-wrapper {
                border: none;
                padding: 10px;
            }

            .acknowledgement {
                border: 1px solid #0066cc;
            }

            .ack-btn {
                display: none !important;
            }
        }
    </style>

    <div class="content-wrapper">
        <div style="margin-left: 20px; margin-right: 20px;">

            <div class="header">
                <img src="{{ asset('assets/phdizone_images/phdizone_logo.png') }}" width="180px" height="80px"
                    alt="PhdiZone Logo">
                <div
                    style="display: flex; align-items:start; justify-content: start; flex-direction: column; gap: 2px; font-size:14px; font-weight:bold; color:black;">
                    <label>
                        <span><i class="mdi mdi-email-outline fs-5"></i></span>
                        <span>customercare@phdizone.com</span>
                    </label>
                    <label>
                        <span><i class="mdi mdi-phone-outline fs-5"></i></span>
                        <span>+91 7845736970</span>
                    </label>
                </div>
            </div>

            <div style="border-top: solid 4px #0066cc; margin-top: 15px;"></div>

            <label class="eibs_title">No Objection Certificate [NOC]</label>

            <div class="main-content">

                <p class="greeting">Dear Sir / Madam,</p>

                <p><strong>Congratulations on this significant achievement!</strong></p>

                <p>We are delighted to inform you that your paper titled
                    <strong>"{{ $journal_details->paper_name ?? '' }}"</strong> has been accepted for publication in the
                    journal <strong>{{ $customer_details->journal_data->journal_name ?? '' }}</strong>, published by
                    <strong>{{ $customer_details->cus_name ?? '' }}</strong>.
                </p>

                <p>This achievement marks a significant milestone in your academic journey, and we are proud to have
                    supported you throughout this process.</p>

                <p>We would also like to express our gratitude for your continued relationship with
                    <strong>PhdiZone</strong>. After this communication, this project will be closed and your credentials
                    will be handed over.
                </p>

                <p>Please find below your login credentials for both email and journal access:</p>

                <div class="credentials-box">
                    <strong>Journal Login Credentials:</strong><br><br>
                    <strong>Username:</strong> {{ $journal_credentials->user_name ?? '' }}<br>
                    <strong>Password:</strong> {{ $journal_credentials->password ?? '' }}
                </div>

                <p>We would be immensely grateful if you could take a moment to leave a review reflecting your experience
                    with our team.</p>

                <p class="review-links">
                    <strong>Google Review Link:</strong>
                    <a href="https://go.climbo.com/phdizone" target="_blank">https://go.climbo.com/phdizone</a><br>
                    <strong>Trust Pilot Link:</strong>
                    <a href="https://g.page/r/CXzqW8PGnPpyEB0/review" class="mt-2" target="_blank"
                        class="trustpilot-link">
                        https://g.page/r/CXzqW8PGnPpyEB0/review
                    </a>
                </p>

                <p>Hence, if you have any further clarification regarding this, please reach out within <strong>3 business
                        days</strong> from the date of this email, failing which it will be automatically considered as
                    acknowledged and the project will be closed in our CRM system.</p>

                <p>Thank you once again for your trust and support.</p>

                <div class="acknowledgement">
                    <strong>Acknowledgement & Consent</strong>
                    <div class="checkbox-container">
                        <input type="checkbox" id="acknowledge">
                        <label for="acknowledge" style="cursor: pointer;">
                            I/We accept the terms of the No Objection Certificate and authorize PhdiZone to proceed with the
                            closure of the project
                            and handover of credentials as mentioned above.
                        </label>
                    </div>
                </div>


                <div class="d-flex align-items-center justify-content-center mt-4 mb-4">
                    <button type="button" class="btn btn-primary btn-lg ack-btn" id="submitBtn" disabled>
                        <span class="text-white">Acknowledgement & Submit</span>
                    </button>
                </div>

            </div>
        </div>
    </div>

    <script>
        document.getElementById('acknowledge').addEventListener('change', function() {
            const btn = document.getElementById('submitBtn');
            btn.disabled = !this.checked;
        });

        // New functionality for submit button
        let submitClicked = false;

        document.getElementById('submitBtn').addEventListener('click', function() {
            if (!this.disabled) {
                submitClicked = true;
                const url = "{{ url('/manage_journal_noc_thank_you/' . $encryptIDs) }}";

                // Open new tab
                window.open(url, '_blank');

                // Try to close
                window.close();
            }
        });

        // If close fails, show message when user tries to leave
        window.addEventListener('beforeunload', function(e) {
            if (submitClicked) {
                // This shows a confirmation dialog
                e.preventDefault();
                e.returnValue = '';
            }
        });
    </script>

@endsection
