@extends('layouts/layoutMaster')

@section('title', 'Journal Followup')


@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/js/dropdown-hover.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/clipboard/clipboard.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')

    <!-- <style>
                            .list_page thead th,
                            .list_page tbody td {
                                padding: 7px !important;
                            }
                        </style> -->

    <!-- Lead List Table -->
    <div class="card">
        <div class="card-header border-bottom pb-1">
            <h5 class="card-title mb-1">Journal Followup</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Journal Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Un Followup</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-body px-4 py-0">
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                        <div class="scroll-container" id="scrollContainer">
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{ url('/journal_followup') }}" type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2"
                                        style="background-color: #FCFF66 !important;">
                                        <span style="color:#000 !important;">Today Followup</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">
                                            {{ $todayFollowupCount == 0 ? 0 : str_pad($todayFollowupCount, 2, '0', STR_PAD_LEFT) }}
                                        </span>
                                    </a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{ url('/journal_closed_followup') }}" type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2"
                                        style="background-color: #d0dfd7 !important;">
                                        <span class="ms-2" id="cld_flwup_txt">Closed Followup</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">
                                            {{ $closedFollowupCount == 0 ? 0 : str_pad($closedFollowupCount, 2, '0', STR_PAD_LEFT) }}
                                        </span>
                                    </a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{ url('/journal_reschedule_followup') }}" type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2"
                                        style="background-color: #FFB6C1 !important;">
                                        <span class="ms-2" id="rescd_flwup_txt">Reschedule Followup</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">
                                            {{ $rescheduleFollowupCount == 0 ? 0 : str_pad($rescheduleFollowupCount, 2, '0', STR_PAD_LEFT) }}
                                        </span>
                                    </a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{ url('/journal_unfollowup') }}" type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2"
                                        style="background-color: #ff7a7a !important; box-shadow: 0px 0rem 1rem 6px rgba(0, 0, 0, 0.22) !important;">
                                        <span class="ms-2" id="un_flwup_txt">Un Followup</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">
                                            {{ $unFollowupCount == 0 ? 0 : str_pad($unFollowupCount, 2, '0', STR_PAD_LEFT) }}
                                        </span>
                                    </a>
                                </li>
                            </div>
                        </div>
                        <button class="scroll-btn right" id="scrollRightBtn"><i
                                class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>
            </div>
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="row mb-4">
                            @php $perpage_count = $perpage ? $perpage : 10; @endphp
                            <div class="col-lg-2">
                                <span>Show</span>
                                <br>
                                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                    onchange="sort_filter(this.value);">
                                    @php
                                        $options = [10, 25, 100, 500]; // Define available options
                                    @endphp
                                    @foreach ($options as $option)
                                        <option value="{{ $option }}"
                                            @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                                            @php echo $option; @endphp
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-lg-10 d-flex align-items-end justify-content-end">
                                <form id="search_form" method="POST" action="/journal_unfollowup">
                                    @csrf
                                    <div class="d-flex align-items-center gap-2 mt-2">
                                        <div>
                                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                            <input type="hidden" name="filter_on" value="0">
                                            <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                                id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                            <input type="text" class="form-control" id="search_fill" name="search_fill"
                                                value="{{ $search_fill ?? '' }}" placeholder="Enter Search" />
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                            onclick="search_filter_func()">Search</button>
                                        <a href="{{ url('/journal_unfollowup') }}" type="button"
                                            class="me-2 btn btn-sm btn-secondary fw-semibold mb-1">
                                            <span class="mdi mdi-refresh fs-6"></span>
                                        </a>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 table-responsive">
                                <table class="table align-middle table-row-dashed table-striped table-hover gy-2 gs-2">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-150px">Customer</th>
                                            <th class="min-w-150px">Service</th>
                                            <th class="min-w-150px">Domain & Index</th>
                                            <th class="min-w-100px">Date</th>
                                            <th class="min-w-50px">Time</th>
                                            <th class="min-w-100px">Followed By</th>
                                            <th class="min-w-150px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                        @foreach ($List as $i => $list)
                                            <tr>
                                                <td>
                                                    <div class="d-flex flex-column">
                                                        <label class="text-black text-truncate fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="{{ $list->cus_name }}">{{ $list->cus_name }}</label>
                                                        <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom" title="Customer ID">
                                                            {{ $list->customer_id }}</div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="mb-0 mx-2">
                                                        <label class="text-black text-truncate fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="{{ $list->service_name }}">{{ $list->service_name }}</label>
                                                        <div class="d-block">
                                                            <div class="text-danger fw-semibold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Service Id">
                                                                {{ $list->service_id }}</div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <label
                                                        class="d-block badge text-truncate bg-success fs-7 text-black px-2 py-1"
                                                        style="max-width: 150px;" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="{{ $list->domain_names ? implode(', ', $list->domain_names->toArray()) : 'No Domains' }}">{{ $list->domain_names ? implode(', ', $list->domain_names->toArray()) : 'No Domains' }}</label>
                                                    <label
                                                        class="d-block badge text-truncate bg-secondary fs-7 text-white px-2 py-1"
                                                        style="max-width: 150px;" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="{{ $list->index_names }}">{{ $list->index_names }}</label>
                                                </td>
                                                <td>
                                                    <div class="badge bg-success fw-semibold text-black fs-7">
                                                        {{ $list->formatted_date }}
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="badge bg-danger fw-semibold text-white fs-7">
                                                        {{ $list->formatted_time }}
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="fw-semibold text-black fs-7">
                                                        {{ $list->created_staff_name }}</div>
                                                </td>
                                                <td>
                                                    <div class="badge bg-danger rounded text-white cursor-pointer"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_jr_follow_up_lead_schedule"
                                                        onclick="openFpResheduleModal('{{ $list->services_sno }}','{{ $list->journal_customer_id }}')">
                                                        Closed
                                                        Follow-up</div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <div class="mt-4">
                                {{ $List->appends(request()->except(['page', '_token']))->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--begin::Modal - Pending Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_jr_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Report</h3>
                    </div>
                    <form id="updateResheduleForm" autocomplete="off">
                        <div class="row mt-4 p-2 bg-gray-200 rounded mb-2">
                            <div class="col-lg-12 mb-2 d-flex align-items-center gap-2">
                                <span class="badge bg-gray-100 rounded-circle"><i
                                        class="mdi mdi-briefcase-account-outline text-black"></i></span>
                                <label class="text-black fs-6 fw-semibold">Customer Details</label>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Customer</label>
                                    <label class="text-black fs-6 fw-medium cus_name">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Customer Id</label>
                                    <label class="text-black fs-6 fw-medium cus_id">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Service</label>
                                    <label class="text-black fs-6 fw-medium cus_service">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Service Id</label>
                                    <label class="text-black fs-6 fw-medium cus_service_id">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Domain</label>
                                    <label class="text-black fs-6 fw-medium cus_domain">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Index</label>
                                    <label class="text-black fs-6 fw-medium cus_index">-</label>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-lg-12 mb-2 d-flex align-items-center gap-2">
                                <span class="badge bg-gray-100 rounded-circle"><i
                                        class="mdi mdi-clock-outline text-black"></i></span>
                                <label class="text-black fs-6 fw-semibold">Follow-up Details</label>
                            </div>
                            <div class="col-lg-4 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Follow-up Date</label>
                                    <label class="text-black fs-6 fw-medium" id="app_date">-</label>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-2">
                                <div class="d-flex flex-column">
                                    <label class="text-dark fs-7 fw-medium">Follow-up Time</label>
                                    <label class="text-black fs-6 fw-medium" id="app_time">-</label>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-1 d-flex align-items-center justify-content-end">
                                <div class="text-black fs-5 fw-semibold">
                                    <span>Reschedule Count</span>
                                    <span class="badge bg-danger fs-6 text-white rounded"
                                        id="followup_reschedule_count">0</span>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-lg-12 mb-2 d-flex align-items-center gap-2">
                                <span class="badge bg-gray-100 rounded-circle"><i
                                        class="mdi mdi-notebook-outline text-black"></i></span>
                                <label class="text-black fs-6 fw-semibold">Journal Team Details</label>
                            </div>
                            <div class="col-lg-6 mb-2 d-flex align-items-center justify-content-start gap-2">
                                {{-- <div class="avatar">
                                    <img src="{{ asset('assets/phdizone_images/staff_1.png') }}" alt="staff image"
                                        class="w-42px h-42px rounded-circle border border-dark">
                                </div> --}}
                                <div class="d-flex flex-column">
                                    <label class="text-black fs-6 fw-medium jtl_fp">-</label>
                                    <label class="badge bg-label-warning text-dark fs-7 fw-medium">Journal Team
                                        Lead</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-2 d-flex align-items-center justify-content-start gap-2">
                                {{-- <div class="avatar">
                                    <img src="{{ asset('assets/phdizone_images/staff_1.png') }}" alt="staff image"
                                        class="w-42px h-42px rounded-circle border border-dark">
                                </div> --}}
                                <div class="d-flex flex-column">
                                    <label class="text-black fs-6 fw-medium je_fp">-</label>
                                    <label class="badge bg-label-warning text-dark fs-7 fw-medium">Journal
                                        Executive</label>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-lg-12 mb-4">
                                <label class="text-black mb-1 fs-6 fw-semibold mt-4 me-2  d-block">Progressed<span
                                        class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="progressed" id="progressed"
                                        value="1" name="progressed" onclick="progress_func('yes');" checked />
                                    <label class="form-check-label">Yes</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="progressed" id="progressed"
                                        value="2" name="progressed" onclick="progress_func('no');" />
                                    <label class="form-check-label">No</label>
                                </div>
                            </div>
                        </div>
                        <div id="message" name="message">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold d-block">
                                        Follow Through <span class="text-danger">*</span>
                                    </label>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="direct_call" value="1" checked />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="direct_call">Direct Call</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="whatsapp_chat" value="2" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="whatsapp_chat">Whatsapp Chat</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="whatsapp_call" value="3" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="whatsapp_call">Whatsapp Call</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="email" value="4" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="email">E-Mail</label>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold d-block">Conversation Message<span
                                            class="text-danger">*</span></label>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="1" checked />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Positive</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="-1" />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Negative</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="0" />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Neutral</label>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <textarea class="form-control" rows="3" id="convo_message"
                                        oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"
                                        placeholder="Enter Conversation Message"></textarea>
                                    <div class="text-danger" id="convo_message_err"></div>
                                </div>
                            </div>
                            <div class="border-bottom mb-3 mt-2"></div>
                        </div>
                        <div id="reason" name="reason" style="display: none !important;">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select" id="app_reason" name="app_reason"
                                        onchange="toggleInputField_followup(this.value)">
                                        <option value="">Select Reason</option>
                                        @if (isset($followupReasonList))
                                            @foreach ($followupReasonList as $s_reason)
                                                <option value="{{ $s_reason->reason_name }}"
                                                    data-comments-check-followup="{{ $s_reason->comments_check }}">
                                                    {{ $s_reason->reason_name }}
                                                </option>
                                            @endforeach
                                        @endif
                                        <option value="1">Others</option>
                                    </select>
                                    <div class="text-danger" id="app_reason_select_err"></div>
                                    <div class="mt-4" id="followup_reason_div" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="followup_reason_text"
                                            id="followup_reason_text" value="" placeholder="Enter Reason">
                                        <div class="text-danger" id="followup_comments_text_err"></div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Date<span
                                                class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="re_app_date" placeholder="Select Date"
                                                class="form-control" value="" name="appointment_date" />

                                        </div>
                                        <div class="text-danger" id="re_app_date_err"></div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Time<span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control common_time_class_new"
                                            placeholder="HH:MM" id="re_app_time" name="appointment_time"
                                            value="" />
                                        <div class="text-danger" id="re_app_time_err"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="border-bottom mb-3 mt-2"></div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="accordion">
                                    <div class="accordion-item mb-2 active">
                                        <h2 class="accordion-header" id="headingPopoutOne">
                                            <button type="button" class="accordion-button" data-bs-toggle="collapse"
                                                data-bs-target="#accordionPopoutOne" aria-expanded="true"
                                                aria-controls="accordionPopoutOne">
                                                <span class="text-black fw-semibold fs-6">Followup History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="app_count">00</span>
                                            </button>
                                        </h2>
                                        <div id="accordionPopoutOne" class="accordion-collapse collapse show"
                                            aria-labelledby="headingPopoutOne" data-bs-parent="#accordionPopout">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-125px">Last Followup<br>Date / Time
                                                                    </th>
                                                                    <th class="min-w-125px">Followed By</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="historicalLeadIdsTableBody">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id='rescheduleBtn' class="btn btn-primary"
                                    onclick="updateReshedule()">Submit
                                    Report</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Pending Followup Lead Schedule-->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>

    <script>
        let reshedule_id;
        let customer_id;

        // ✅ Initialize Flatpickr (Time Picker)
        document.addEventListener("DOMContentLoaded", function() {
            flatpickr("#re_app_time", {
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                time_24hr: true,
                minuteIncrement: 5
            });
        });

        // ✅ Open Modal + Load Data
        function openFpResheduleModal(categoryId, CustomerID) {

            reshedule_id = categoryId;
            customer_id = CustomerID;

            function formatDate(dateString) {
                const date = new Date(dateString);
                const day = date.getDate().toString().padStart(2, '0');
                const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                const month = monthNames[date.getMonth()];
                const year = date.getFullYear();
                return `${day}-${month}-${year}`;
            }

            function formatTime(timeString) {
                const date = new Date(`1970-01-01T${timeString}`);
                let hours = date.getHours();
                const minutes = date.getMinutes().toString().padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12 || 12;
                return `${hours}:${minutes} ${ampm}`;
            }

            fetch(`/EditjournalFollowup/${categoryId}`)
                .then(response => response.json())
                .then(data => {

                    if (data.status === 200) {

                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;

                        // ✅ Set current appointment
                        document.getElementById('app_date').innerText = formatDate(lead.appointment_date);
                        document.getElementById('app_time').innerText = formatTime(lead.appointment_time);

                        $('#followup_reschedule_count_again').text(data.data.reschedule_count);
                        $('#followup_reschedule_count').text(data.data.reschedule_count);
                        $('#followup_reschedule_rep_count').text(data.data.reschedule_count);

                        $('#app_count').html(historicalLeadIds.length);
                        $('.jtl_fp').html(lead.jouranal_coordinator_name);
                        $('.je_fp').html(lead.journal_staff_name);
                        $('.cus_name').html(lead.cus_name);
                        $('.cus_id').html(lead.customer_id);
                        $('.cus_service').html(lead.service_id);
                        $('.cus_service_id').html(lead.service_id);
                        $('.cus_index').html(lead.index_names);
                        $('.cus_domain').html(lead.domain_names || 'N/A');

                        // ✅ Table rendering
                        const tbody = document.getElementById('historicalLeadIdsTableBody');
                        tbody.innerHTML = '';

                        if (historicalLeadIds.length > 0) {

                            const FollowThough = [
                                'Unknown',
                                'Direct Call',
                                'Whatsapp Chat',
                                'Whatsapp Call',
                                'E-Mail'
                            ];

                            historicalLeadIds.forEach((category, index) => {
                                var FollowThoughsts = category.is_reschedule == 0 ? FollowThough[category
                                    .follow_through ?? 0] : 'Re-schedule';
                                const row = `
                        <tr class="${category.is_reschedule == 1 ? 'bg-danger' : ''}">
                            <td>${index + 1}</td>
                            <td>
                                ${formatDate(category.appointment_date)}<br>
                                ${formatTime(category.appointment_time)}
                            </td>
                            <td>
                                ${category.staff_name}<br>
                                <span class="badge bg-info">
                                    ${FollowThoughsts}
                                </span>
                            </td>
                            <td title="${category.convo_message ?? '-'}">
                                ${category.convo_message ?? '-'}
                            </td>
                            <td title="${category.reason ?? '-'}">
                                ${category.reason ?? '-'}
                            </td>
                        </tr>`;

                                tbody.innerHTML += row;
                            });

                            $('[data-bs-toggle="tooltip"]').tooltip();

                        } else {
                            tbody.innerHTML = `<tr><td colspan="5">No Records</td></tr>`;
                        }

                    } else {
                        console.error('Error:', data.message);
                    }
                })
                .catch(error => console.error('Fetch Error:', error));
        }

        // ✅ Update Reschedule
        function updateReshedule() {

            const resheduleid = reshedule_id;
            const customerid = customer_id;
            const progressed = document.querySelector('input[name="progressed"]:checked')?.value;

            let app_score = null;
            let convo_message = null;
            let follow_through = null;
            let reason = null;
            let appointment_date = null;
            let appointment_time = null;

            let err = 0;

            if (progressed == 1) {

                app_score = document.querySelector('input[name="app_score"]:checked')?.value;
                follow_through = document.querySelector('input[name="follow_through"]:checked')?.value;
                convo_message = document.getElementById('convo_message').value;

                if (!convo_message) {
                    $('#convo_message_err').text('Conversation Message is Required');
                    err++;
                } else {
                    $('#convo_message_err').text('');
                }

            } else {

                reason = document.getElementById('app_reason').value;
                const other_reason = document.getElementById('followup_reason_text').value;

                appointment_date = document.getElementById('re_app_date').value;
                appointment_time = document.getElementById('re_app_time').value;

                if (!reason) {
                    $('#app_reason_select_err').text('Reason is Required');
                    err++;
                } else {
                    $('#app_reason_select_err').text('');
                }

                if (reason == 1 && !other_reason) {
                    $('#followup_comments_text_err').text('Other Reason is Required');
                    err++;
                } else if (reason == 1) {
                    reason = other_reason;
                }

                if (!appointment_date) {
                    $('#re_app_date_err').text('Followup Date is Required');
                    err++;
                } else {
                    $('#re_app_date_err').text('');
                }

                if (!appointment_time) {
                    $('#re_app_time_err').text('Followup Time is Required');
                    err++;
                } else {
                    $('#re_app_time_err').text('');
                }
            }

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            if (err === 0) {

                $('#rescheduleBtn').prop('disabled', true);

                fetch(`/journal_followup_update/${resheduleid}/${customerid}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        },
                        body: JSON.stringify({
                            progressed,
                            app_score,
                            follow_through,
                            convo_message,
                            reason,
                            appointment_date,
                            appointment_time
                        })
                    })
                    .then(response => response.json()) // ✅ FIXED
                    .then(data => {

                        if (data.status === 200) {
                            toastr.success('Follow-up Updated successfully!');
                            location.reload();
                        } else {
                            toastr.error('Follow-up Failed to update!');
                            $('#rescheduleBtn').prop('disabled', false);
                        }
                    })
                    .catch(error => {
                        console.error('Update Error:', error);
                        $('#rescheduleBtn').prop('disabled', false);
                    });

            } else {
                $('#rescheduleBtn').prop('disabled', false);
            }
        }

        function toggleInputField_followup(value) {
            var followupReasonDiv = document.getElementById('followup_reason_div');
            var followupReasonText = document.getElementById('followup_reason_text');
            // var followupCommentsDiv = document.getElementById('followup_comments_div');
            var selectedOption = document.querySelector('#app_reason option:nth-child(' + (document.getElementById(
                'app_reason').selectedIndex + 1) + ')');
            // var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check-followup') : null;

            if (value == '1') {
                followupReasonDiv.style.display = 'block';
                followupReasonText.setAttribute('required', 'required');
            } else {
                followupReasonDiv.style.display = 'none';
                followupReasonText.removeAttribute('required');
            }
        }
    </script>
    <script>
        function progress_func(prog_val) {
            if (prog_val == 'no') {
                document.getElementById("message").style.display = "none";
                document.getElementById("reason").style.display = "block";
            } else {
                document.getElementById("message").style.display = "block";
                document.getElementById("reason").style.display = "none";
            }
        }
    </script>

    <script>
        $(".list_page").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>
@endsection
