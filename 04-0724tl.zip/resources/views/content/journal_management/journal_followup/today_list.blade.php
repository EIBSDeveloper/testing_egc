@extends('layouts/layoutMaster')

@section('title', 'Journal Followup')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('page-script')
@endsection
@section('content')
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id;
        $user_data = $helper->get_staff_data($user_id);
    @endphp

    <!-- Lead List Table -->
    <div class="card">
        <div class="card-header border-bottom pb-1">
            <h5 class="card-title mb-1">Journal Followup</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Journal Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Today Followup </a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <span class="fs-5 fw-bold text-info d-flex align-items-center">{{ date('d-M-Y') }}</span>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-body px-4 py-0">
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                        <div class="scroll-container" id="scrollContainer">
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{ url('/journal_followup') }}" type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2"
                                        style="background-color: #FCFF66 !important; box-shadow: 0px 0rem 1rem 6px rgba(0, 0, 0, 0.22) !important;">
                                        <span style="color:#000 !important;">Today Followup</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">
                                            {{ $todayFollowupCount == 0 ? 0 : str_pad($todayFollowupCount, 2, '0', STR_PAD_LEFT) }}
                                        </span>
                                    </a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{ url('/journal_closed_followup') }}" type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2"
                                        style="background-color: #d0dfd7 !important;">
                                        <span class="ms-2" id="cld_flwup_txt">Closed Followup</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">
                                            {{ $closedFollowupCount == 0 ? 0 : str_pad($closedFollowupCount, 2, '0', STR_PAD_LEFT) }}
                                        </span>
                                    </a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{ url('/journal_reschedule_followup') }}" type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2"
                                        style="background-color: #FFB6C1 !important;">
                                        <span class="ms-2" id="rescd_flwup_txt">Reschedule Followup</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">
                                            {{ $rescheduleFollowupCount == 0 ? 0 : str_pad($rescheduleFollowupCount, 2, '0', STR_PAD_LEFT) }}
                                        </span>
                                    </a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{ url('/journal_unfollowup') }}" type="button"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2"
                                        style="background-color: #ff7a7a !important;">
                                        <span class="ms-2" id="un_flwup_txt">Un Followup</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">
                                            {{ $unFollowupCount == 0 ? 0 : str_pad($unFollowupCount, 2, '0', STR_PAD_LEFT) }}
                                        </span>
                                    </a>
                                </li>
                            </div>
                        </div>
                        <button class="scroll-btn right" id="scrollRightBtn"><i
                                class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>
            </div>
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="row mb-4">
                            @php $perpage_count = $perpage ? $perpage : 10; @endphp
                            <div class="col-lg-2">
                                <span>Show</span>
                                <br>
                                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                    onchange="sort_filter(this.value);">
                                    @php
                                        $options = [10, 25, 100, 500]; // Define available options
                                    @endphp
                                    @foreach ($options as $option)
                                        <option value="{{ $option }}"
                                            @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                                            @php echo $option; @endphp
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-lg-10 d-flex align-items-end justify-content-end">
                                <form id="search_form" method="POST" action="/journal_followup">
                                    @csrf
                                    <div class="d-flex align-items-center gap-2 mt-2">
                                        <div>
                                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                            <input type="hidden" name="filter_on" value="0">
                                            <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                                id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                            <input type="text" class="form-control" id="search_fill"
                                                name="search_fill" value="{{ $search_fill ?? '' }}"
                                                placeholder="Enter Search" />
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                            onclick="search_filter_func()">Search</button>
                                        <a href="{{ url('/journal_followup') }}" type="button"
                                            class="me-2 btn btn-sm btn-secondary fw-semibold mb-1">
                                            <span class="mdi mdi-refresh fs-6"></span>
                                        </a>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 table-responsive">
                                <table class="table align-middle table-row-dashed table-striped table-hover gy-2 gs-2">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-150px">Customer</th>
                                            <th class="min-w-150px">Service</th>
                                            <th class="min-w-150px">Domain & Index</th>
                                            <th class="min-w-100px">Date</th>
                                            <th class="min-w-50px">Time</th>
                                            <th class="min-w-100px">Followed By</th>
                                            <th class="min-w-150px">Followup Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                        @foreach ($List as $i => $list)
                                            <tr
                                                @if ($list->is_reschedule == 1) style="background-color: #ECA8B3 !important;" @endif>
                                                <td>
                                                    <div class="d-flex flex-column">
                                                        <label class="text-black text-truncate fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="{{ $list->cus_name }}">{{ $list->cus_name }}</label>
                                                        <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom" title="Customer ID">
                                                            {{ $list->customer_id }}</div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="mb-0 mx-2">
                                                        <label class="text-black text-truncate fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="{{ $list->service_name }}">{{ $list->service_name }}</label>
                                                        <div class="d-block">
                                                            <div class="text-danger fw-semibold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Service Id">
                                                                {{ $list->service_id }}</div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <label
                                                        class="d-block badge text-truncate bg-success fs-7 text-black px-2 py-1"
                                                        style="max-width: 150px;" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="{{ $list->domain_names ? implode(', ', $list->domain_names->toArray()) : 'No Domains' }}">{{ $list->domain_names ? implode(', ', $list->domain_names->toArray()) : 'No Domains' }}</label>
                                                    <label
                                                        class="d-block badge text-truncate bg-secondary fs-7 text-white px-2 py-1"
                                                        style="max-width: 150px;" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="{{ $list->index_names }}">{{ $list->index_names }}</label>
                                                </td>
                                                <td>
                                                    <div class="badge bg-success fw-semibold text-black fs-7">
                                                        {{ $list->formatted_date }}
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="badge bg-danger fw-semibold text-white fs-7">
                                                        {{ $list->formatted_time }}
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="fw-semibold text-black fs-7">
                                                        {{ $list->created_staff_name }}</div>
                                                </td>
                                                <td>
                                                    @if ($list->is_reschedule == 1)
                                                        <div class="badge bg-danger text-black rounded fw-bold fs-8">
                                                            Re-schedule
                                                        </div>
                                                    @elseif($list->status == 0)
                                                        <div class="badge bg-warning text-black rounded fw-bold fs-8">
                                                            New Followup
                                                        </div>
                                                    @elseif($list->status == 1)
                                                        <div class="badge bg-success text-white rounded fw-bold fs-8">
                                                            Closed
                                                        </div>
                                                    @else
                                                        -
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach

                                    </tbody>
                                </table>
                            </div>
                            <div class="mt-4">
                                {{ $List->appends(request()->except(['page', '_token']))->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <script>
        $(".list_page").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>
@endsection
