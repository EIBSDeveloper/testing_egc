@extends('layouts/layoutMaster')

@section('title', 'Journal Monitor')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>

@php
    $module_name = 'Journal Management';
    $menu_name = 'Journal Monitor';
@endphp
<!-- Journal List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Journal Monitor</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Journal Management</a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-175px">Customer</th>
                            <th class="min-w-150px">Journal / Domain</th>
                            <th class="min-w-150px">Paper</th>
                            <th class="min-w-100px text-center">Author / Published</th>
                            <th class="min-w-100px text-center">Published URL</th>
                            <th class="min-w-100px">Status</th>
                            <th class="min-w-50px text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                            @foreach($lists as $list)
                                <tr>
                                    <td>
                                        <label class="text-black fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$list->cus_name}}">{{$list->cus_name}}</label>
                                        <div class="d-block">
                                            <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer ID">{{$list->customer_id}}</div>
                                        </div>
                                    </td>
                                    @php
                                        if(count($list->domain_names) > 0) {
                                            $domains = implode(', ', $list->domain_names);
                                        } else {
                                            $domains = 'Not Available';
                                        }
                                    @endphp
                                    <td>
                                        <label class="fs-7 fw-semibold text-black text-truncate max-w-225px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$list->journal_name}}">{{$list->journal_name}}</label>
                                        <div class="d-block mt-n2">
                                            <label class="fs-8 fw-semibold text-dark text-truncate max-w-175px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $domains }}">{{ $domains }}</label>
                                        </div>
                                    </td>
                                    <td>
                                        <label class="text-black fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="{{$list->paper_name}}">{{$list->paper_name}}</label>
                                        <div class="d-block">
                                            <div class="text-danger fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Journal ID">
                                                {{$list->journal_id}}</div>
                                        </div>
                                    </td>
                                    <td align="center">
                                        {{$list->publish_author ?? '-'}} 
                                        <br>
                                        {{ $list->publish_date ? \Carbon\Carbon::parse($list->publish_date)->format('F Y') : '' }}
                                    </td>
                                    <td align="center">
                                        @if (!empty($list->publish_url))
                                            <a href="{{ $list->publish_url }}" class="badge bg-body rounded px-2" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Published Link">
                                                <i class="mdi mdi-link-variant text-danger fs-4"></i>
                                            </a>
                                        @else
                                        -
                                        @endif                           
                                    </td>
                                    <td>
                                        @if($list->status == 0) 
                                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: 	#007BFF !important;" >
                                                <span>Submitted</span>
                                            </a>
                                        @elseif ($list->status == 1)
                                            <a href="javascript:;" class="badge bg-info text-black mb-1 fs-7 fw-semibold" style="background-color: 	#FFA500 !important;">
                                                <span>Reviewed</span>
                                                <span class="ms-2">
                                            </a>
                                        @elseif ($list->status == 3)
                                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                style="background-color: #800080 !important;">
                                                <span>Resubmitted</span>
                                            </a>
                                        @elseif ($list->status == 4)
                                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                style="background-color:	#28A745 !important;">
                                                <span>Accepted</span>
                                            </a>
                                        @elseif ($list->status == 5)
                                            <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color:#DC3545 !important;">Rejected</div>
                                        @elseif ($list->status == 6)
                                            <div class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #17A2B8 !important;">Published</div>
                                        @endif                                    
                                    </td>
                                    <td>
                                        <div class="text-center">
                                            @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                                <a href="javascript:;" class="text-black fw-bold me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_view_journal_monitor" onclick="viewDataFetch('{{$list->sno}}')">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3"></i></span>
                                                </a>   
                                            @endif 
                                            <!-- <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_journal">
                                                    <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                                                </a>
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_journal">
                                                    <span> <i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Update</span>
                                                </a>
                                            </div> -->
                                        </div> 
                                    </td>
                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <td>Unauthorised Access</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<!--begin::Modal - Journal Reviewed-->
<div class="modal fade" id="kt_modal_journal_reviewed" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <form action="{{route('add_review_form')}}" method="POST" id="reviewed_form">
                @csrf
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                    <span class="badge bg-info text-black fs-6 fw-semibold" style="background-color: #FFA500 !important;">Reviewed</span> Journal ?
                    <div class="px-3 text-start mt-6">
                            <div class="row">
                            <input type="hidden" name="review_id" id="review_id">
                            <input type="hidden" name="review_customer_id" id="review_customer_id">
                            <input type="hidden" name="uploaded_files" id="uploaded_files">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="reviewed_customer"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="reviewed_services"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="reviewed_journal"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="reviewed_domain"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="reviewed_paper"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                                <div id="dropArea" class="drop-area">
                                    <div id="dropMessage" class="drop-message">
                                        <div class="upload-icon">📁</div>
                                        <div class="upload-text">Drag & drop files here or <span class="clickable">click to upload</span></div>
                                    </div>
                                    <div class="preview-list" id="previewList"></div>
                                    <input type="file" id="fileInput" multiple />
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Reviewer Comments<span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="7" placeholder="Enter Reviewer Comments" id="reviewer_comment" name="reviewer_comment"></textarea>
                                <p id="reviewer_comment_error" class="text-danger mt-1"></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Journal Reviewed-->

<!--begin::Modal - Journal Resubmitted-->
<div class="modal fade" id="kt_modal_journal_resubmitted" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <form action="{{route('store_resubmitted_form')}}" method="POST">
                @csrf
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                    <span class="badge bg-info fs-6 fw-semibold" style="background-color: #800080 !important;">Resubmitted</span> Journal ?
                    <div class="px-3 text-start mt-6">
                        <div class="row">
                            <input type="hidden" name="resubmitted_id" id="resubmitted_id">
                            <input type="hidden" name="resubmitted_journal_id" id="resubmitted_journal_id">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="resubmitted_customer"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="resubmitted_services"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="resubmitted_journal"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="resubmitted_domain"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="resubmitted_paper"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Journal Resubmitted-->

<!--begin::Modal - Journal Accepted-->
<div class="modal fade" id="kt_modal_journal_accepted" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <form action="{{route('store_accepted_form')}}" method="POST">
                @csrf
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                    <span class="badge bg-info fs-6 fw-semibold" style="background-color: #28A745 !important;">Accepted</span> Journal ?
                    <div class="px-3 text-start mt-6">
                        <div class="row">
                            <input type="hidden" name="accepted_id" id="accepted_id">
                            <input type="hidden" name="accepted_journal_id" id="accepted_journal_id">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="accepted_customer"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="accepted_services"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="accepted_journal"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="accepted_domain"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="accepted_paper"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Journal Accepted-->

<!--begin::Modal - Journal Rejected-->
<div class="modal fade" id="kt_modal_journal_rejected" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <form action="{{route('store_rejection_form')}}" method="POST" id="rejected_form">
                @csrf
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                    <span class="badge bg-info fs-6 fw-semibold" style="background-color: #DC3545 !important;">Rejected</span> Journal ?
                    <div class="px-3 text-start mt-6">
                        <div class="row">
                            <input type="hidden" name="cancel_id" id="cancel_id">
                            <input type="hidden" name="reject_manage_journal" id="reject_manage_journal">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="rejected_customer"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="rejected_service"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="rejected_journal_name"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="rejected_domains"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="rejected_paper_name"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Rejected Reason<span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="6" placeholder="Enter Rejected Reason" id="rejected_reason" name="rejected_reason"></textarea>
                                <p id="rejected_reason_error" class="text-danger mt-1 fs-7"></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Journal Rejected-->

<!--begin::Modal - Journal Published-->
<div class="modal fade" id="kt_modal_journal_published" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Journal Published</h3>
                </div>
                <form action="{{route('add_published_form')}}" method="POST" id="published_form">
                    @csrf
                    <div class="row">
                        <input type="hidden" name="published_id" id="published_id">
                        <input type="hidden" name="published_journal_id" id="published_journal_id">
                        <input type="hidden" name="publish_uploaded_files" id="publish_uploaded_files">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="published_customer"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="published_services"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Journal</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="published_journal"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Domain</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="published_domain"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Paper</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="published_paper"></div>
                        </div>
                        <div class="col-lg-12 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" placeholder="Select Date" id="publish_date" name="publish_date" class="form-control common_date_time_class"/>
                                <p id="publish_date_error" class="text-danger mt-1"></p>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Paper Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Paper Name" id="publish_paper" name="publish_paper" />
                            <p id="publish_paper_error" class="text-danger mt-1"></p>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Author Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Author Name" id="publish_author" name="publish_author" />
                            <p id="publish_author_error" class="text-danger mt-1"></p>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">URL<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter URL" id="publish_url" name="publish_url" />
                            <p id="publish_url_error" class="text-danger mt-1"></p>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Documents</label>
                            <div id="publish_dropArea" class="drop-area">
                                <div id="publish_dropMessage" class="drop-message">
                                    <div class="upload-icon">📁</div>
                                    <div class="upload-text">Drag & drop files here or <span class="clickable">click to upload</span></div>
                                </div>
                                <div class="preview-list" id="publish_previewList"></div>
                                <input type="file" id="publish_fileInput" multiple />
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="4" placeholder="Enter Description" name="publish_desc"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Journal Published</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Journal Published-->


<!--begin::Modal - View Journal Monitor-->
<div class="modal fade" id="kt_modal_view_journal_monitor" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">
                        <span>View Journal Details</span>
                        <span class="ms-1 me-1">-</span>
                        <span class="badge bg-info fw-semibold fs-5" style="background-color: #007BFF !important;" id="view_title">Submitted</span>
                    </h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold"><span id="view_customer"></span> <span class="fs-7 text-primary" id="view_customer_id"></span></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Services</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold"><span id="view_services"></span> <span id="view_services_category"></span></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Journal</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="view_journal"></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Domain</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="view_domain_names"></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Paper</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="view_paper"></label>
                </div>
                <div class="row mb-6">
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black fs-7 fw-semibold" id="view_desc"></label>
                </div>
                <div class="row mb-6" id="view_submitted_row">
                    <div class="col-lg-12">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Submitted Documents</label>
                        <div class="border border-gray-600i border-dashed rounded py-3 px-2">
                            <div id="submitted_document_container" class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div id="view_reviewed_row">
                    <div class="divider divider-primary mb-6">
                        <div class="divider-text fs-5 text-black fw-semibold">Reviewed</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-12">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Reviewed Documents</label>
                            <div class="border border-gray-600i border-dashed rounded py-3 px-2">
                                <div id="reviewed_document_container" class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Reviewer Comments</label>
                        <label class="col-12 text-black text-justify fs-7 fw-semibold" id="view_reviewed_comments"></label>
                    </div>
                </div>
                <div id="view_rejected_row">
                    <div class="divider divider-primary mb-6">
                        <div class="divider-text fs-5 text-black fw-semibold">Rejected</div>
                    </div>
                    <div class="row mb-6">
                        <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Rejected Reason</label>
                        <label class="col-12 text-black text-justify fs-7 fw-semibold" id="view_rejected_reason"></label>
                    </div>
                </div>
                <div id="view_published_row">
                    <div class="divider divider-primary mb-6">
                        <div class="divider-text fs-5 text-black fw-semibold">Published</div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Date</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold"><?php echo date("d-M-Y"); ?></label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Paper</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="view_published_paper"></label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Author</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="view_published_author"></label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">URL</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <div class="col-8 text-black fs-6 fw-semibold">
                            <a href="" class="badge bg-body rounded px-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Link" id="view_published_url"><i class="mdi mdi-link-variant text-danger fs-4"></i></a>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-12">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Published Documents</label>
                            <div class="border border-gray-600i border-dashed rounded py-3 px-2">
                                <div id="published_documents_container" class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                        <label class="col-12 text-black text-justify fs-7 fw-semibold" id="view_published_desc"></label>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Journal Monitor-->


{{-- Toastr Starts --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr container */
    .toast {
        background-color: #313f46;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
</style>
<script>
    // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
</script>
{{-- Toastr Ends --}}

<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

{{-- Date Picker For Publish Journal --}}
<script>
    $(document).ready(function() {
        $(".common_date_time_class").flatpickr({
            enableTime: false, // Disable time picker
            dateFormat: 'Y-m-d', // Only date format
            defaultDate: new Date() // Optional: sets default date to today
        });
    });
</script>

{{-- Fetch Data For Status Via AJAX --}}
<script>
    function dataFetch(id){
        fetch(`/dataFetchForm/${id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{csrf_token()}}'
            }
        })
        .then(res => res.json())
        .then(data => {
            if(data.status === 200){
                var journal = data.data;

                // Rejected Journal
                $('#rejected_customer').html(`${journal.cus_name} (${journal.customer_id})`);
                $('#rejected_service').html(`${journal.service_name} ( ${journal.category_name} )`);
                $('#rejected_journal_name').html(`${journal.journal_name}`);
                $('#rejected_domains').html(`${journal.domain_names}`);
                $('#rejected_paper_name').html(`${journal.paper_name}`);
                $('#reject_manage_journal').val(`${journal.manage_journal_id}`);
                $('#cancel_id').val(`${journal.sno}`);

                // Reviewed Journal
                $('#reviewed_customer').html(`${journal.cus_name} (${journal.customer_id})`);
                $('#reviewed_services').html(`${journal.service_name} ( ${journal.category_name} )`);
                $('#reviewed_journal').html(`${journal.journal_name}`);
                $('#reviewed_domain').html(`${journal.domain_names}`);
                $('#reviewed_paper').html(`${journal.paper_name}`);
                $('#review_customer_id').val(`${journal.manage_journal_id}`);
                $('#review_id').val(`${journal.sno}`);

                // Resubmitted Journal
                $('#resubmitted_customer').html(`${journal.cus_name} (${journal.customer_id})`);
                $('#resubmitted_journal').html(`${journal.journal_name}`);
                $('#resubmitted_paper').html(`${journal.paper_name}`);
                $('#resubmitted_domain').html(`${journal.domain_names}`);
                $('#resubmitted_services').html(`${journal.service_name} ( ${journal.category_name} )`);
                $('#resubmitted_journal_id').val(`${journal.manage_journal_id}`);
                $('#resubmitted_id').val(`${journal.sno}`);

                // Accepted Journal
                $('#accepted_customer').html(`${journal.cus_name} (${journal.customer_id})`);
                $('#accepted_journal').html(`${journal.journal_name}`);
                $('#accepted_paper').html(`${journal.paper_name}`);
                $('#accepted_domain').html(`${journal.domain_names}`);
                $('#accepted_services').html(`${journal.service_name} ( ${journal.category_name} )`);
                $('#accepted_journal_id').val(`${journal.manage_journal_id}`);  
                $('#accepted_id').val(`${journal.sno}`);  
                
                // Published Journal
                $('#published_customer').html(`${journal.cus_name} (${journal.customer_id})`);
                $('#published_journal').html(`${journal.journal_name}`);
                $('#published_paper').html(`${journal.paper_name}`);
                $('#published_domain').html(`${journal.domain_names}`);
                $('#published_services').html(`${journal.service_name} ( ${journal.category_name} )`);
                $('#published_journal_id').val(`${journal.manage_journal_id}`);
                $('#published_id').val(`${journal.sno}`);

            } else {
                console.log('Error Fetching Data !');
            }
        })
        .catch(error => {
            console.log(`Error fetching Data : ${error}`);
        });
    }
</script>

{{-- Rejected Form Validation --}}
<script>
    $('#rejected_form').on('submit', (e) => {
        let isValid = true;

        $('#rejected_reason_error').text('');

        if($('#rejected_reason').val() === ''){
            isValid = false;
            $('#rejected_reason_error').text('Enter a Valid Rejected Reason.');
        }

        if(!isValid){
            e.preventDefault();
        }
    })
</script>

{{-- Review Form Validation --}}
<script>
    $('#reviewed_form').on('submit', (e) => {
        let isValid = true;

        $('#reviewer_comment_error').text('');

        if($('#reviewer_comment').val() === ''){
            isValid = false;
            $('#reviewer_comment_error').text('Enter Your Comment.');
        }

        if(!isValid){
            e.preventDefault();
        }
    })
</script>

{{-- Published Form Validation --}}
<script>
    $('#published_form').on('submit', (e) => {
        let isValid = true;

        $('#publish_paper_error').text('');

        if($('#publish_paper').val() === ''){
            isValid = false;
            $('#publish_paper_error').text('Enter a Paper Name.');
        }

        $('#publish_author_error').text('');

        if($('#publish_author').val() === ''){
            isValid = false;
            $('#publish_author_error').text('Enter an Author Name.');
        }

        $('#publish_url_error').text('');

        if($('#publish_url').val() === ''){
            isValid = false;
            $('#publish_url_error').text('Enter an URL.');
        }

        // $('#publish_date_error').text('');

        // if($('publish_date').val() === ''){
        //     isValid = false;
        //     $('#publish_date_error').text('Select the Date to Publish.');
        //     $('#publish_date').focus();
        // }

        if(!isValid){
            e.preventDefault();
        }
    })
</script>

{{-- Dropzone.js CSS For Reviewed Form --}}
<style>
    .drop-area {
        border: 2px dashed #4a90e2;
        border-radius: 12px;
        padding: 40px;
        text-align: center;
        position: relative;
        background-color: #f9f9f9;
        transition: background-color 0.3s ease;
        cursor: pointer;
    }

    .drop-area:hover {
        background-color: #f0f7ff;
    }

    .drop-message {
        color: #4a90e2;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .upload-icon {
        font-size: 48px;
        margin-bottom: 10px;
    }

    .upload-text {
        font-size: 16px;
        font-weight: 500;
    }

    .clickable {
        color: #357ABD;
        text-decoration: underline;
    }

    #fileInput {
        display: none;
    }

    .preview-list {
        margin-top: 20px;
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        justify-content: flex-start;
    }

    .preview-item {
        width: 150px;
        border: 1px solid #ddd;
        border-radius: 10px;
        background: white;
        box-shadow: 0 0 10px rgba(74, 144, 226, 0.2);
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 10px;
        position: relative;
    }

    .preview-thumb {
        width: 100%;
        height: 100px;
        object-fit: cover;
        border-radius: 6px;
        margin-bottom: 8px;
    }

    .no-preview {
        width: 100%;
        height: 100px;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #f5f5f5;
        color: #888;
        font-size: 50px;
        border-radius: 6px;
        margin-bottom: 8px;
    }

    .preview-filename {
        font-weight: 600;
        text-align: center;
        margin-bottom: 6px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        width: 100%;
    }

    .preview-size {
        color: #666;
        font-size: 12px;
        margin-bottom: 8px;
    }

    .progress-bar {
        width: 100%;
        height: 6px;
        background-color: #eee;
        border-radius: 3px;
        overflow: hidden;
        margin-bottom: 6px;
    }

    .progress-bar-inner {
        height: 100%;
        width: 0;
        background-color: #4a90e2;
        transition: width 0.3s ease;
    }

    .remove-btn {
        position: absolute;
        top: 6px;
        right: 6px;
        background: #ff4d4d;
        border: none;
        border-radius: 50%;
        color: white;
        font-weight: bold;
        width: 24px;
        height: 24px;
        cursor: pointer;
        line-height: 22px;
        text-align: center;
        padding: 0;
    }
</style>

{{-- Dropzone.js File Upload Via AJAX For Reviewed Form--}}
<script>
    const dropArea = document.getElementById("dropArea");
    const fileInput = document.getElementById("fileInput");
    const previewList = document.getElementById("previewList");
    const dropMessage = document.getElementById("dropMessage");
    let uploadedFiles = [];

    // Make whole drop area clickable
    dropArea.addEventListener("click", () => fileInput.click());

    dropArea.addEventListener("dragover", e => {
        e.preventDefault();
        dropArea.classList.add("bg-light");
    });

    dropArea.addEventListener("dragleave", e => {
        e.preventDefault();
        dropArea.classList.remove("bg-light");
    });

    dropArea.addEventListener("drop", e => {
        e.preventDefault();
        dropArea.classList.remove("bg-light");
        if (e.dataTransfer.files.length) {
            handleFiles(e.dataTransfer.files);
        }
    });

    fileInput.addEventListener("change", e => {
        if (e.target.files.length) {
            handleFiles(e.target.files);
        }
    });

    function humanFileSize(size) {
        const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
        return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
    }

    function handleFiles(files) {
        dropMessage.style.display = "none";
        [...files].forEach(file => {
            const previewItem = document.createElement("div");
            previewItem.className = "preview-item";

            const removeBtn = document.createElement("button");
            removeBtn.className = "remove-btn";
            removeBtn.innerHTML = "&times;";
            removeBtn.onclick = () => {
                previewList.removeChild(previewItem);
                uploadedFiles = uploadedFiles.filter(f => f.name !== file.name);
                if (!previewList.hasChildNodes()) {
                    dropMessage.style.display = "block";
                }
            };
            previewItem.appendChild(removeBtn);

            if (file.type.startsWith("image/")) {
                const img = document.createElement("img");
                img.className = "preview-thumb";
                const reader = new FileReader();
                reader.onload = e => img.src = e.target.result;
                reader.readAsDataURL(file);
                previewItem.appendChild(img);
            } else {
                const noPreview = document.createElement("div");
                noPreview.className = "no-preview";
                noPreview.textContent = "📄";
                previewItem.appendChild(noPreview);
            }

            const nameDiv = document.createElement("div");
            nameDiv.className = "preview-filename";
            nameDiv.textContent = file.name;
            previewItem.appendChild(nameDiv);

            const sizeDiv = document.createElement("div");
            sizeDiv.className = "preview-size";
            sizeDiv.textContent = humanFileSize(file.size);
            previewItem.appendChild(sizeDiv);

            const progressBar = document.createElement("div");
            progressBar.className = "progress-bar";
            const progressBarInner = document.createElement("div");
            progressBarInner.className = "progress-bar-inner";
            progressBar.appendChild(progressBarInner);
            previewItem.appendChild(progressBar);

            previewList.appendChild(previewItem);
            uploadFile(file, progressBarInner);
        });
    }

    function uploadFile(file, progressElement) {
        const url = "{{ route('reviewed_files') }}";
        const formData = new FormData();
        formData.append("file_upload[]", file);

        const xhr = new XMLHttpRequest();
        xhr.open("POST", url, true);
        xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

        xhr.upload.onprogress = function (e) {
            if (e.lengthComputable) {
                const percent = (e.loaded / e.total) * 100;
                progressElement.style.width = percent + "%";
            }
        };

        xhr.onload = function () {
            if (xhr.status === 200) {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    uploadedFiles = uploadedFiles.concat(res.files);
                    document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);
                    progressElement.style.backgroundColor = "#28a745";
                } else {
                    progressElement.style.backgroundColor = "#dc3545";
                    alert("Upload failed: " + (res.message || "Unknown error"));
                }
            } else {
                progressElement.style.backgroundColor = "#dc3545";
                alert("Upload failed with status " + xhr.status);
            }
        };

        xhr.onerror = function () {
            progressElement.style.backgroundColor = "#dc3545";
            alert("Upload error.");
        };

        xhr.send(formData);
    }
</script>

{{-- Dropzone.js CSS For Published Form --}}
<style>
    .drop-area {
        border: 2px dashed #4a90e2;
        border-radius: 12px;
        padding: 40px;
        text-align: center;
        position: relative;
        background-color: #f9f9f9;
        transition: background-color 0.3s ease;
        cursor: pointer;
    }

    .drop-area:hover {
        background-color: #f0f7ff;
    }

    .drop-message {
        color: #4a90e2;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .upload-icon {
        font-size: 48px;
        margin-bottom: 10px;
    }

    .upload-text {
        font-size: 16px;
        font-weight: 500;
    }

    .clickable {
        color: #357ABD;
        text-decoration: underline;
    }

    #publish_fileInput {
        display: none;
    }

    .preview-list {
        margin-top: 20px;
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        justify-content: flex-start;
    }

    .preview-item {
        width: 150px;
        border: 1px solid #ddd;
        border-radius: 10px;
        background: white;
        box-shadow: 0 0 10px rgba(74, 144, 226, 0.2);
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 10px;
        position: relative;
    }

    .preview-thumb {
        width: 100%;
        height: 100px;
        object-fit: cover;
        border-radius: 6px;
        margin-bottom: 8px;
    }

    .no-preview {
        width: 100%;
        height: 100px;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #f5f5f5;
        color: #888;
        font-size: 50px;
        border-radius: 6px;
        margin-bottom: 8px;
    }

    .preview-filename {
        font-weight: 600;
        text-align: center;
        margin-bottom: 6px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        width: 100%;
    }

    .preview-size {
        color: #666;
        font-size: 12px;
        margin-bottom: 8px;
    }

    .progress-bar {
        width: 100%;
        height: 6px;
        background-color: #eee;
        border-radius: 3px;
        overflow: hidden;
        margin-bottom: 6px;
    }

    .progress-bar-inner {
        height: 100%;
        width: 0;
        background-color: #4a90e2;
        transition: width 0.3s ease;
    }

    .remove-btn {
        position: absolute;
        top: 6px;
        right: 6px;
        background: #ff4d4d;
        border: none;
        border-radius: 50%;
        color: white;
        font-weight: bold;
        width: 24px;
        height: 24px;
        cursor: pointer;
        line-height: 22px;
        text-align: center;
        padding: 0;
    }
</style>

{{-- Dropzone.js File Upload Via AJAX For Published Form--}}
<script>

    (function (){
    const dropArea = document.getElementById("publish_dropArea");
    const fileInput = document.getElementById("publish_fileInput");
    const previewList = document.getElementById("publish_previewList");
    const dropMessage = document.getElementById("publish_dropMessage");
    let publisheduploadedFiles = [];

    // Make whole drop area clickable
    dropArea.addEventListener("click", () => fileInput.click());

    dropArea.addEventListener("dragover", e => {
        e.preventDefault();
        dropArea.classList.add("bg-light");
    });

    dropArea.addEventListener("dragleave", e => {
        e.preventDefault();
        dropArea.classList.remove("bg-light");
    });

    dropArea.addEventListener("drop", e => {
        e.preventDefault();
        dropArea.classList.remove("bg-light");
        if (e.dataTransfer.files.length) {
            handleFiles(e.dataTransfer.files);
        }
    });

    fileInput.addEventListener("change", e => {
        if (e.target.files.length) {
            handleFiles(e.target.files);
        }
    });

    function humanFileSize(size) {
        const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
        return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
    }

    function handleFiles(files) {
        dropMessage.style.display = "none";
        [...files].forEach(file => {
            const previewItem = document.createElement("div");
            previewItem.className = "preview-item";

            const removeBtn = document.createElement("button");
            removeBtn.className = "remove-btn";
            removeBtn.innerHTML = "&times;";
            removeBtn.onclick = () => {
                previewList.removeChild(previewItem);
                publisheduploadedFiles = publisheduploadedFiles.filter(f => f.name !== file.name);
                if (!previewList.hasChildNodes()) {
                    dropMessage.style.display = "block";
                }
            };
            previewItem.appendChild(removeBtn);

            if (file.type.startsWith("image/")) {
                const img = document.createElement("img");
                img.className = "preview-thumb";
                const reader = new FileReader();
                reader.onload = e => img.src = e.target.result;
                reader.readAsDataURL(file);
                previewItem.appendChild(img);
            } else {
                const noPreview = document.createElement("div");
                noPreview.className = "no-preview";
                noPreview.textContent = "📄";
                previewItem.appendChild(noPreview);
            }

            const nameDiv = document.createElement("div");
            nameDiv.className = "preview-filename";
            nameDiv.textContent = file.name;
            previewItem.appendChild(nameDiv);

            const sizeDiv = document.createElement("div");
            sizeDiv.className = "preview-size";
            sizeDiv.textContent = humanFileSize(file.size);
            previewItem.appendChild(sizeDiv);

            const progressBar = document.createElement("div");
            progressBar.className = "progress-bar";
            const progressBarInner = document.createElement("div");
            progressBarInner.className = "progress-bar-inner";
            progressBar.appendChild(progressBarInner);
            previewItem.appendChild(progressBar);

            previewList.appendChild(previewItem);
            uploadFile(file, progressBarInner);
        });
    }

    function uploadFile(file, progressElement) {
        const url = "{{ route('published_files') }}";
        const formData = new FormData();
        formData.append("publish_uploaded_files[]", file);

        const xhr = new XMLHttpRequest();
        xhr.open("POST", url, true);
        xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

        xhr.upload.onprogress = function (e) {
            if (e.lengthComputable) {
                const percent = (e.loaded / e.total) * 100;
                progressElement.style.width = percent + "%";
            }
        };

        xhr.onload = function () {
            if (xhr.status === 200) {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    publisheduploadedFiles = publisheduploadedFiles.concat(res.files);
                    document.getElementById("publish_uploaded_files").value = JSON.stringify(publisheduploadedFiles);
                    progressElement.style.backgroundColor = "#28a745";
                } else {
                    progressElement.style.backgroundColor = "#dc3545";
                    alert("Upload failed: " + (res.message || "Unknown error"));
                }
            } else {
                progressElement.style.backgroundColor = "#dc3545";
                alert("Upload failed with status " + xhr.status);
            }
        };

        xhr.onerror = function () {
            progressElement.style.backgroundColor = "#dc3545";
            alert("Upload error.");
        };

        xhr.send(formData);
    }
    })();
</script>

{{-- View Journal Data Fetch Via AJAX --}}
<script>
    function viewDataFetch(id) {
        fetch(`/view_journal/${id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{csrf_token()}}'
            }
        })
        .then(res => res.json())
        .then(data => {
            if(data.status == 200){
                var monitor = data.data;
                
                $('#view_customer').html(monitor.cus_name);
                $('#view_customer_id').html(`( ${monitor.customer_id} )`);
                $('#view_services').html(monitor.service_name);
                $('#view_services_category').html(`( ${monitor.category_name} )`);
                $('#view_journal').html(monitor.journal_name);
                $('#view_domain_names').html(monitor.domain_names.join(', '));
                $('#view_paper').html(monitor.paper_name);
                $('#view_desc').html(monitor.manage_journal_desc ?? '-');

                // Hide all rows initially
                $('#view_submitted_row').hide();
                $('#view_published_row').hide();
                $('#view_rejected_row').hide();
                $('#view_reviewed_row').hide();

                const title = document.getElementById('view_title');

                // Submitted Row (status 0)
                if(monitor.journal_monitor_status === 0){

                    title.textContent = 'Submitted';
                    title.style.setProperty('background-color', '#007BFF', 'important');

                    const submittedContainer = document.getElementById('submitted_document_container');
                    submittedContainer.innerHTML = '';

                    if(monitor.submitted_files && monitor.submitted_files.length > 0){
                        monitor.submitted_files.forEach(file => {
                            let extension = file.split('.').pop().toLowerCase();
                            let fileUrl = `/journals/${file}`; // adjust folder path
                            
                            let attachmentHTML = '';
                            
                            if(['jpg','jpeg','png','gif','bmp','webp'].includes(extension)){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="${fileUrl}" alt="Attachment" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else if(extension === 'pdf'){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_pdf.png" alt="PDF" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else {
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_file.png" alt="File" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            }
                            
                            submittedContainer.insertAdjacentHTML('beforeend', attachmentHTML);
                        });
                    } else {
                        submittedContainer.innerHTML = '<span class="text-muted">No submitted documents found.</span>';
                    }
                    
                    $('#view_submitted_row').show();
                }

                // Reviewed Row (status 1)
                else if(monitor.journal_monitor_status === 1){

                    title.textContent = 'Reviewed';
                    title.style.setProperty('background-color', '#FFA500', 'important');

                    const reviewedContainer = document.getElementById('reviewed_document_container');
                    reviewedContainer.innerHTML = '';
                    
                    if(monitor.reviewed_files && monitor.reviewed_files.length > 0){
                        monitor.reviewed_files.forEach(file => {
                            let extension = file.split('.').pop().toLowerCase();
                            let fileUrl = `/reviewed_journals/${file}`; // adjust folder path
                            
                            let attachmentHTML = '';
                            
                            if(['jpg','jpeg','png','gif','bmp','webp'].includes(extension)){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="${fileUrl}" alt="Attachment" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else if(extension === 'pdf'){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_pdf.png" alt="PDF" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else {
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_file.png" alt="File" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            }
                            
                            reviewedContainer.insertAdjacentHTML('beforeend', attachmentHTML);
                        });
                    } else {
                        reviewedContainer.innerHTML = '<span class="text-muted">No reviewed documents found.</span>';
                    }

                    $('#view_reviewed_comments').html(monitor.reviewer_comment ?? '-');

                    $('#view_reviewed_row').show();
                }

                // Rejected Row (status 2)
                else if(monitor.journal_monitor_status === 2){

                    title.textContent = 'Rejected';
                    title.style.setProperty('background-color', '#DC3545', 'important');

                    $('#view_rejected_reason').html(monitor.rejected_reason ?? '-');
                    $('#view_rejected_row').show();
                }

                // Published Row (status 5)
                else if(monitor.journal_monitor_status === 5){

                    title.textContent = 'Published';
                    title.style.setProperty('background-color', '#17A2B8', 'important');

                    $('#view_published_paper').html(monitor.journal_monitor_paper);
                    $('#view_published_author').html(monitor.author_name ?? '-');
                    $('#view_published_url').attr('href', monitor.published_url ?? '#');
                    $('#view_published_desc').html(monitor.published_desc ?? '-');

                    const publishedContainer = document.getElementById('published_documents_container');
                    publishedContainer.innerHTML = '';

                    if(monitor.uploaded_files && monitor.uploaded_files.length > 0){
                        monitor.uploaded_files.forEach(file => {
                            let extension = file.split('.').pop().toLowerCase();
                            let fileUrl = `/published_journals/${file}`;

                            let attachmentHTML = '';

                            if(['jpg','jpeg','png','gif','bmp','webp'].includes(extension)){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="${fileUrl}" alt="Attachment" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else if(extension === 'pdf'){
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_pdf.png" alt="PDF" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            } else {
                                attachmentHTML = `
                                <div class="d-block overlay text-center me-1 px-2 py-2">
                                    <a href="${fileUrl}" target="_blank" download
                                        class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                        <img src="/assets/phdizone_images/def_file.png" alt="File" class="h-75px w-75px" />
                                    </a>
                                </div>`;
                            }

                            publishedContainer.insertAdjacentHTML('beforeend', attachmentHTML);
                        });
                    } else {
                        publishedContainer.innerHTML = '<span class="text-muted">No attachments found.</span>';
                    }

                    // Date formatting function
                    function formatDate(dateString) {
                        if (!dateString) return '-';
                        const options = { day: '2-digit', month: 'short', year: 'numeric' };
                        const date = new Date(dateString);
                        // format: 19-Jun-2025
                        return date.toLocaleDateString('en-GB', options).replace(/ /g, '-');
                    }

                    const formattedDate = formatDate(monitor.published_date);
                    $('#view_published_date').html(formattedDate);

                    $('#view_published_row').show();
                }

                
                else if(monitor.journal_monitor_status === 3){
                    title.textContent = 'Resubmitted';
                    title.style.setProperty('background-color', '#800080', 'important');
                }
                
                else if(monitor.journal_monitor_status === 4){
                    title.textContent = 'Accepted';
                    title.style.setProperty('background-color', '#28A745', 'important');
                }

            } else {
                console.log('Data Not Fetched !');
            }
        })
        .catch(error => {
            console.log('Error Fetching Data :', error);
        });
    }
</script>



@endsection