@extends('layouts/layoutMaster')

@section('title', 'Call Log')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    @endphp
    @php
        $module_name = 'Lead Management';
        $menu_name = 'Manage Calls';
    @endphp

    <style>
        .list_page thead th,
        .list_page tbody td {
            padding: 7px !important;
        }
    </style>


    <style>
        /* Profile image styling */
        .symbol-45px {
            width: 45px;
            height: 45px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .symbol-45px:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .object-fit-cover {
            object-fit: cover;
            border-radius: 8px;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .d-flex.align-items-start.gap-3 {
                flex-direction: column;
                align-items: flex-start !important;
            }

            .symbol-45px {
                margin-bottom: 8px;
            }
        }
    </style>


    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-0 flex-wrap">
            <div class="card-action-title text-black fs-5 fw-bold mb-1">
                <h5 class="card-title mb-1">Call Log Search</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Monitor Tool</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="mb-0 d-flex align-items-center">
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-2 mb-2" id="filter">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Filter"><i
                            class="mdi mdi-filter-outline text-center"></i></span>
                </a>
            </div>
        </div>



        <div class="card-body px-4 py-0 pt-2">

            <div class="d-flex flex-wrap align-items-stretch gap-3 mb-4">
                <!-- Incoming Calls Card -->
                <a href="javascript:;" class="text-center border rounded-3 p-3 text-decoration-none hover-shadow"
                    style="width: 180px; background: #fff;">
                    <div class="text-dark fw-semibold fs-6 mb-2">Incoming Calls</div>
                    <div class="mb-3">
                        <img src="{{ asset('assets/phdizone_images/incoming_call.gif') }}" alt="Incoming Call Icon"
                            class="rounded" style="width: 70px; height: 70px; object-fit: cover;">
                    </div>
                    <div>
                        <span class="badge rounded-pill fw-bold fs-6 px-3 py-2"
                            style="background-color: #ebb5a9; color: #000;">
                            {{ sprintf('%02d', $incoming_call_count) }}
                        </span>
                    </div>
                </a>

                <!-- Outgoing Calls Card -->
                <a href="javascript:;" class="text-center border rounded-3 p-3 text-decoration-none hover-shadow"
                    style="width: 180px; background: #fff;">
                    <div class="text-dark fw-semibold fs-6 mb-2">Outgoing Calls</div>
                    <div class="mb-3">
                        <img src="{{ asset('assets/phdizone_images/outgoing_call.gif') }}" alt="Outgoing Call Icon"
                            class="rounded" style="width: 70px; height: 70px; object-fit: cover;">
                    </div>
                    <div class="d-flex align-items-center justify-content-center gap-1">
                        <span class="badge rounded-pill fw-bold fs-6 px-3 py-2"
                            style="background-color: #ffbc67; color: #000;" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" title="Total Outgoing Calls">
                            {{ sprintf('%02d', $outgoingcall_count) }}
                        </span>
                        <span class="fw-bold text-black fs-5">/</span>
                        <span class="badge rounded-pill fw-bold fs-6 px-3 py-2"
                            style="background-color: #ffbc67; color: #000;" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" title="Average Outgoing Call Ratio">
                            {{ number_format($outgoing_call_ratio, 1) }}%
                        </span>
                    </div>
                </a>

                <!-- Missed Calls Card -->
                <a href="javascript:;" class="text-center border rounded-3 p-3 text-decoration-none hover-shadow"
                    style="width: 180px; background: #fff;">
                    <div class="text-dark fw-semibold fs-6 mb-2">Missed Calls</div>
                    <div class="mb-3">
                        <img src="{{ asset('assets/phdizone_images/missed_call.gif') }}" alt="Missed Call Icon"
                            style="width: 70px; height: 70px; object-fit: cover;">
                    </div>
                    <div class="d-flex align-items-center justify-content-center gap-1">
                        <span class="badge rounded-pill fw-bold fs-6 px-3 py-2"
                            style="background-color: #4c84e1; color: #fff;" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" title="Total Missed Calls">
                            {{ sprintf('%02d', $missedcall_count) }}
                        </span>
                        <span class="fw-bold text-black fs-5">/</span>
                        <span class="badge rounded-pill fw-bold fs-6 px-3 py-2"
                            style="background-color: #4c84e1; color: #fff;" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" title="Average Missed Call Ratio">
                            {{ number_format($missed_call_ratio, 1) }}%
                        </span>
                    </div>
                </a>

                <!-- Rejected Calls Card -->
                <a href="javascript:;" class="text-center border rounded-3 p-3 text-decoration-none hover-shadow"
                    style="width: 180px; background: #fff;" data-bs-toggle="tooltip" data-bs-placement="bottom"
                    title="Total Number of Rejected Calls">
                    <div class="text-dark fw-semibold fs-6 mb-2">Rejected Calls</div>
                    <div class="mb-3">
                        <img src="{{ asset('assets/phdizone_images/declined_Call.gif') }}" alt="Rejected Call Icon"
                            class="rounded" style="width: 70px; height: 70px; object-fit: cover;">
                    </div>
                    <div>
                        <span class="badge rounded-pill fw-bold fs-6 px-3 py-2"
                            style="background-color: #ff0028; color: #fff;">
                            {{ sprintf('%02d', $rejected_call_count) }}
                        </span>
                    </div>
                </a>

                <!-- Dialed Calls Card -->
                <a href="javascript:;" class="text-center border rounded-3 p-3 text-decoration-none hover-shadow"
                    style="width: 180px; background: #fff;" data-bs-toggle="tooltip" data-bs-placement="bottom"
                    title="Total Number of Dialed Calls">
                    <div class="text-dark fw-semibold fs-6 mb-2">Dialed Calls</div>
                    <div class="mb-3">
                        <img src="{{ asset('assets/phdizone_images/Dialed_call.gif') }}" alt="Dialed Call Icon"
                            class="rounded" style="width: 70px; height: 70px; object-fit: cover;">
                    </div>
                    <div>
                        <span class="badge rounded-pill fw-bold fs-6 px-3 py-2"
                            style="background: linear-gradient(135deg, #6ac7e8 0%, #4aa3c9 100%); color: #fff;">
                            {{ sprintf('%02d', $dialedcall_count) }}
                        </span>
                    </div>
                </a>

                <!-- Search Form Card -->
                <div class="border rounded-3 p-3 flex-grow-1" style="background: #fff; min-width: 300px;">
                    <form id="search_form" method="POST" action="/call_log_search"
                        class="h-100 d-flex align-items-center">
                        @csrf
                        <div class="d-flex align-items-center gap-2 w-100">
                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                            <input type="hidden" name="filter_on" value="1">
                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="{{ $perpage ?? 10 }}" />
                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="{{ $perpage ?? 10 }}" />
                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="{{ $perpage ?? 10 }}" />

                            <div class="flex-grow-1">
                                <input type="text" class="form-control form-control-lg" id="lead_fill"
                                    name="call_fill" value="{{ $call_fill ?? '' }}"
                                    placeholder="Search by Name or Mobile No." />
                            </div>

                            <button type="submit" class="btn btn-primary px-4 py-2" onclick="search_filter_func()">
                                <i class="mdi mdi-magnify me-1"></i>Search
                            </button>

                            <a href="{{ url('/call_log_search') }}" type="button" class="btn btn-secondary px-3 py-2"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reset Filters">
                                <i class="mdi mdi-refresh fs-5"></i>
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <style>
                .hover-shadow {
                    transition: all 0.3s ease;
                }

                .hover-shadow:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                    cursor: pointer;
                }
            </style>
            <div class="filter_tbox" style="display: none;">
                <form id="filter_form" method="POST" action="/call_log_search" autocomplete="off">
                    @csrf
                    <div class="row py-1">
                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                        <input type="hidden" name="filter_on" value="1">
                        <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                            value="@php echo $perpage ? $perpage : 10; @endphp" />
                        <div class="col-lg-3 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Status</label>
                            <select id="status_fill" name="status_fill" class="select3 form-select">
                                <option value="" selected>All</option>
                                <option value="0" {{ $status_fill == '0' ? 'selected' : '' }}>Outgoing Call</option>
                                <option value="4" {{ $status_fill == '4' ? 'selected' : '' }}>Dialed Call</option>
                                <option value="1" {{ $status_fill == '1' ? 'selected' : '' }}>Incoming Call</option>
                                <option value="2" {{ $status_fill == '2' ? 'selected' : '' }}>Missed Call</option>
                                <option value="3" {{ $status_fill == '3' ? 'selected' : '' }}>Rejected Call</option>
                            </select>
                        </div>

                        <div class="col-lg-3 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Callers</label>
                            <select id="staff_fill" name="staff_fill" class="select3 form-select">
                                <option value="" selected>All</option>
                                @foreach ($staff_list as $stf_list)
                                    <option value="{{ $stf_list->staff_id }}"
                                        @if ($stf_list->staff_id == $staff_fill) selected @endif>{{ $stf_list->staff_name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end mb-2">
                        <a href="{{ url('/call_log_search') }}" type="button"
                            class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset
                        </a>
                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6">Go</button>
                    </div>
                </form>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between align-items-center ">
                        <div class="">
                            @php $perpage_count = $perpage ? $perpage : 10; @endphp
                            <div>
                                <span>Show</span>
                                <br>
                                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                    onchange="sort_filter(this.value);">
                                    @php
                                        $options = [10, 25, 100, 500]; // Define available options
                                    @endphp
                                    @foreach ($options as $option)
                                        <option value="{{ $option }}"
                                            @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                            @php echo $option; @endphp
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px px-2">Staff</th>
                                <th class="min-w-100px px-2">Communicator</th>
                                <th class="min-w-100px px-1">Call Date</th>
                                <th class="min-w-100px px-1">Start Time</th>
                                <th class="min-w-100px px-1">End Time</th>
                                <th class="min-w-100px px-1">Duration</th>
                                <th class="min-w-100px px-1">Status</th>
                                @if (auth()->user()->hasPermission($module_name, 'Location', $menu_name))
                                    <th class="min-w-50px px-1">Location</th>
                                @endif
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7">
                            @php
                                $startTime = microtime(true);
                            @endphp
                            @if (isset($calls))
                                @foreach ($calls as $call)
                                    @php
                                        if ($call->call_status == 0) {
                                            $bgColor = '';
                                            $img = 'outgoing_call.ico';
                                            $imgClr = '#FFA500';
                                        } elseif ($call->call_status == 1) {
                                            $bgColor = '';
                                            $img = 'incoming_call.ico';
                                            $imgClr = '#50CD89';
                                        } elseif ($call->call_status == 2) {
                                            $bgColor = '#ffcf9f !important;';
                                            $img = 'missed_call.ico';
                                            $imgClr = '#4CD2FC';
                                        } elseif ($call->call_status == 3) {
                                            $bgColor = '#FF7979 !important;';
                                            $img = 'rejected_call.ico';
                                            $imgClr = '#9F0A22';
                                        } elseif ($call->call_status == 4) {
                                            $bgColor = '';
                                            $img = 'dialed_call.ico';
                                            $imgClr = '#1855FD';
                                        }

                                        $last_login_data = $lastLoginDataMap[$call->staff_phone_no] ?? null;

                                        $last_login_date = $last_login_data ? $last_login_data->last_sync_date : '';
                                        $last_login_time = $last_login_data ? $last_login_data->last_sync_time : '';
                                        if ($last_login_date && $last_login_time) {
                                            // Combine the date and time to form a DateTime object
                                            $last_login_datetime = new DateTime(
                                                $last_login_date . ' ' . $last_login_time,
                                            );

                                            // Get the current date and time
                                            $current_datetime = new DateTime();

                                            // Calculate the difference between current time and last login time
                                            $interval = $current_datetime->diff($last_login_datetime);

                                            // Initialize an array to hold the duration breakdown
                                            $duration = [];

                                            // Check for years
                                            if ($interval->y > 0) {
                                                $duration[] = $interval->y . ' year' . ($interval->y > 1 ? 's' : '');
                                            }

                                            // Check for months
                                            if ($interval->m > 0) {
                                                $duration[] = $interval->m . ' month' . ($interval->m > 1 ? 's' : '');
                                            }

                                            // Check for days
                                            if ($interval->d > 0) {
                                                $duration[] = $interval->d . ' day' . ($interval->d > 1 ? 's' : '');
                                            }

                                            // Check for hours
                                            if ($interval->h > 0) {
                                                $duration[] = $interval->h . ' hour' . ($interval->h > 1 ? 's' : '');
                                            }

                                            // Check for minutes
                                            if ($interval->i > 0) {
                                                $duration[] = $interval->i . ' minute' . ($interval->i > 1 ? 's' : '');
                                            }

                                            // If no significant time difference (seconds)
                                            if ($interval->s > 0 && empty($duration)) {
                                                $duration[] = $interval->s . ' second' . ($interval->s > 1 ? 's' : '');
                                            }

                                            // If no significant time difference at all
                                            if (empty($duration)) {
                                                $duration[] = 'Just now';
                                            }

                                            // Combine all the parts with spaces
                                            $duration = implode(' ', $duration);
                                        } else {
                                            $duration = '-';
                                        }
                                    @endphp
                                    <tr style="background: {{ $bgColor }}">
                                        <td class="px-2 py-3">
                                            <div class="d-flex align-items-start gap-3">
                                                {{-- Profile Image --}}
                                                <div class="symbol symbol-45px rounded-3 overflow-hidden border border-2"
                                                    style="background: {{ $imgClr }}; min-width: 45px; height: 45px; margin-top: 2rem !important;">
                                                    <div class="image-input image-input-circle w-100 h-100">
                                                        <img src="{{ asset('assets/phdizone_images/calls/' . $img) }}"
                                                            alt="{{ $call->staff_name }}"
                                                            class="w-100 h-100 object-fit-cover" />
                                                    </div>
                                                </div>

                                                {{-- Staff Info --}}
                                                <div class="flex-grow-1">
                                                    {{-- Name and Phone --}}
                                                    <div class="d-flex flex-column mb-1">
                                                        <span
                                                            class="fw-semibold text-dark fs-6">{{ $call->staff_name }}</span>
                                                        <a href="tel:{{ $call->staff_phone_no }}"
                                                            class="text-primary text-decoration-none fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Call {{ $call->staff_name }}">
                                                            <i
                                                                class="mdi mdi-phone me-1 fs-8"></i>{{ $call->staff_phone_no }}
                                                        </a>
                                                    </div>

                                                    {{-- Department and Job Position --}}
                                                    <div class="d-flex flex-wrap gap-1 mb-2">
                                                        @if (!empty($call->department_name))
                                                            <span
                                                                class="badge bg-light-success text-success fw-semibold fs-8 px-2 py-1 rounded-pill"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Department">
                                                                <i class="mdi mdi-office-building me-1 fs-8"></i>
                                                                {{ $call->department_name }}
                                                            </span>
                                                        @endif

                                                        @if (!empty($call->job_position_name))
                                                            <span
                                                                class="badge bg-light-warning text-warning fw-semibold fs-8 px-2 py-1 rounded-pill"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Job Position">
                                                                <i class="mdi mdi-badge-account-horizontal me-1 fs-8"></i>
                                                                {{ $call->job_position_name }}
                                                            </span>
                                                        @endif
                                                    </div>

                                                    {{-- Last Login Info --}}
                                                    @if (isset($last_login_date) || isset($last_login_time))
                                                        <div
                                                            class="d-flex align-items-center gap-2 bg-light p-2 rounded-3">
                                                            <div class="d-flex align-items-center text-muted">
                                                                <i class="mdi mdi-clock-outline me-1 fs-7"></i>
                                                                <span class="fw-semibold fs-7" data-bs-toggle="tooltip"
                                                                    data-bs-placement="right" title="Last Login">
                                                                    @if ($last_login_date)
                                                                        {{ date($common_date_format, strtotime($last_login_date)) }}
                                                                    @endif
                                                                    @if ($last_login_time)
                                                                        {{ date('h:i A', strtotime($last_login_time)) }}
                                                                    @endif
                                                                </span>
                                                            </div>
                                                            @if (isset($duration))
                                                                <span
                                                                    class="badge bg-light-danger text-danger fw-bold fs-8 px-2 py-1 rounded-pill">
                                                                    <i class="mdi mdi-clock-alert me-1 fs-8"></i>
                                                                    {{ $duration }} ago
                                                                </span>
                                                            @endif
                                                        </div>
                                                    @endif
                                                </div>
                                            </div>
                                        </td>


                                        <td class="px-2 py-2">
                                            @php
                                                $displayName =
                                                    $call->lead_name ??
                                                    ($call->customer_name ?? ($call->internal_user_name ?? 'Unknown'));
                                                $phoneNumber = $call->customer_phone_no ?? 'N/A';
                                                $sourceType = $call->lead_name
                                                    ? 'Lead'
                                                    : ($call->internal_user_name
                                                        ? 'Internal'
                                                        : 'Customer');
                                                $badgeClass = $call->lead_name
                                                    ? 'bg-light-primary text-primary'
                                                    : ($call->internal_user_name
                                                        ? 'bg-light-warning text-warning'
                                                        : 'bg-light-success text-success');
                                                $staffName = $call->lead_staff ?? 'Old Staff';
                                            @endphp

                                            <div class="d-flex flex-column">
                                                {{-- Main Contact Info --}}
                                                <div class="d-flex align-items-center gap-2 mb-1">
                                                    {{-- Status Indicator --}}
                                                    <span class="badge rounded-circle p-1"
                                                        style="width: 8px; height: 8px; background-color: {{ $call->lead_name ? '#0d6efd' : ($call->internal_user_name ? '#ffc107' : '#198754') }};"
                                                        data-bs-toggle="tooltip" data-bs-placement="left"
                                                        title="{{ $sourceType }} Type">
                                                    </span>

                                                    {{-- Name with Icon --}}
                                                    <div class="d-flex align-items-center gap-1 flex-wrap">
                                                        <i class="mdi mdi-account-circle fs-6 text-gray-600"></i>
                                                        <span
                                                            class="fw-semibold text-dark fs-7">{{ $displayName }}</span>

                                                        {{-- Source Badge --}}
                                                        <span
                                                            class="badge {{ $badgeClass }} fw-semibold fs-8 px-2 py-1 rounded-pill">
                                                            {{ $sourceType }}
                                                        </span>
                                                    </div>
                                                </div>

                                                {{-- Phone Number --}}
                                                @if ($phoneNumber !== 'N/A')
                                                    <div class="d-flex align-items-center gap-2 mb-1 ms-3">
                                                        <i class="mdi mdi-phone fs-8 text-dark"></i>
                                                        <a href="javascript:;" class="fs-8 text-primary">
                                                            {{ $phoneNumber }}
                                                        </a>
                                                    </div>
                                                @else
                                                    <div class="d-flex align-items-center gap-2 mb-1 ms-3">
                                                        <i class="mdi mdi-phone-off fs-8 text-muted"></i>
                                                        <span class="text-muted fs-7 fst-italic">No phone number</span>
                                                    </div>
                                                @endif

                                                {{-- Staff Information --}}
                                                @if ($call->lead_name || $call->internal_user_name)
                                                    <div class="d-flex align-items-center gap-2 ms-3">
                                                        <i class="mdi mdi-account-tie fs-8 text-info"></i>
                                                        <span class="text-info fs-7" data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom" title="Created by">
                                                            {{ $staffName }}
                                                        </span>

                                                        @if ($call->internal_user_name)
                                                            <span
                                                                class="badge bg-light-info text-info fs-8 px-2 rounded-pill">
                                                                <i class="mdi mdi-lock me-1 fs-8"></i>Internal
                                                            </span>
                                                        @endif
                                                    </div>
                                                @endif

                                                {{-- Additional Metadata if available --}}
                                                @if (isset($call->created_at) || isset($call->call_duration))
                                                    <div
                                                        class="d-flex align-items-center gap-3 mt-2 ms-3 pt-1 border-top border-light">
                                                        @if (isset($call->created_at))
                                                            <div class="d-flex align-items-center gap-1">
                                                                <i class="mdi mdi-calendar-clock fs-8 text-muted"></i>
                                                                <span
                                                                    class="text-muted fs-8">{{ date('d M Y, h:i A', strtotime($call->created_at)) }}</span>
                                                            </div>
                                                        @endif

                                                        @if (isset($call->call_duration))
                                                            <div class="d-flex align-items-center gap-1">
                                                                <i class="mdi mdi-timer-sand fs-8 text-muted"></i>
                                                                <span
                                                                    class="text-muted fs-8">{{ $call->call_duration }}</span>
                                                            </div>
                                                        @endif
                                                    </div>
                                                @endif
                                            </div>
                                        </td>
                                        <td class="px-1">
                                            <label
                                                class="text-black fs-7 fw-semibold">{{ date($common_date_format, strtotime($call->call_start_date)) }}</label>
                                        </td>
                                        <td class="px-1">
                                            <label
                                                class="text-info fs-7 fw-semibold">{{ date('h:i A', strtotime($call->call_start_time)) }}</label>
                                        </td>
                                        <td class="px-1">
                                            <label
                                                class="text-danger fs-7 fw-semibold">{{ $call->call_end_time ? date('h:i A', strtotime($call->call_end_time)) : '-' }}</label>
                                        </td>
                                        <td class="px-1">
                                            <label
                                                class="badge bg-warning text-black fs-7 fw-bold">{{ $call->call_duration ? $call->call_duration : '-' }}</label>
                                        </td>
                                        <td class="px-1">
                                            @if ($call->call_status == 0)
                                                <label class="badge bg-warning rounded text-black fs-7 fw-semibold"
                                                    style="background-color: #FFA500 !important;">Outgoing Call</label>
                                            @elseif ($call->call_status == 1)
                                                <label class="badge bg-warning rounded text-black fs-7 fw-semibold"
                                                    style="background-color: #50CD89 !important;">Incoming Call</label>
                                            @elseif ($call->call_status == 2)
                                                <label class="badge bg-warning rounded text-black fs-7 fw-semibold"
                                                    style="background-color: #4CD2FC !important;">Missed Call</label>
                                            @elseif ($call->call_status == 3)
                                                <label class="badge bg-danger rounded text-white fs-7 fw-semibold"
                                                    style="background-color: #9F0A22 !important;">Rejected Call</label>
                                            @elseif($call->call_status == 4)
                                                <label class="badge bg-warning rounded text-white fs-7 fw-semibold"
                                                    style="background-color: #1855FD !important;">Dialed Call</label>
                                            @endif
                                        </td>
                                        @if (auth()->user()->hasPermission($module_name, 'Location', $menu_name))
                                            <td>
                                                <a href="javascript:;" data-bs-toggle="modal"
                                                    data-bs-target="#kt_modal_call_location"
                                                    class="border border-gray-400 rounded px-1 py-2"
                                                    onclick="call_location_func({{ $call->latitude ? $call->latitude : '0' }},{{ $call->longitude ? $call->longitude : '0' }})">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        data-bs-original-title="Location"> <i
                                                            class="mdi mdi-map-marker-radius text-gray fs-4"></i></span>
                                                </a>
                                            </td>
                                        @endif
                                    </tr>
                                @endforeach
                            @endif

                        </tbody>
                    </table>
                </div>
                @php
                    $endTime = microtime(true);
                    $executionTime = $endTime - $startTime;
                    // Convert to milliseconds (optional)
                    $executionTimeMs = number_format($executionTime * 1000, 2);
                @endphp

                <!--<p class="text-danger fw-bold">Render Time: {{ $executionTimeMs }} ms</p>-->
                <div class="mt-4">
                    {{ $calls->appends(request()->except(['page', '_token']))->links() }}
                </div>
            </div>
        </div>



        <!--begin::Modal - Staff Call Location-->
        <div class="modal fade" id="kt_modal_call_location" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
            data-bs-backdrop="static">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-xl">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                        transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                        transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-4 text-center">
                            <h3 class="text-center mb-4 text-black" id="call_location_name">Call Location</h3>
                        </div>
                        <div class="row mb-4">
                            <div id="call-location-data"></div>
                        </div>
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Staff Call Location-->

        <script>
            $('#filter').click(function() {
                $('.filter_tbox').slideToggle('slow');
            });
        </script>
        <script>
            function sort_filter(val) {
                if (val != "") {
                    $('.sorting_filter_class').val(val);
                    $('#filter_form').submit();
                } else {
                    $('.sorting_filter_class').val(10);
                    $('#filter_form').submit();
                }
            }
        </script>

        <script>
            $(".list_page").DataTable({
                "ordering": false,
                "paging": false,
                // "aaSorting":[],
                "language": {
                    "lengthMenu": "Show _MENU_",
                },
                "dom": "<'row mb-3'" +
                    // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                    // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                    ">" +

                    "<'table-responsive'tr>" +

                    "<'row'" +
                    // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                    // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                    ">"
            });
        </script>
        <script>
            function call_location_func(latitude, longitude) {
                console.log(longitude)
                var location =
                    `<iframe width="100%" height="500" src="https://maps.google.com/maps?q=${latitude},${longitude}&hl=es;z=14&output=embed"></iframe>`
                $('#call-location-data').html(location);
            }
        </script>




    @endsection
