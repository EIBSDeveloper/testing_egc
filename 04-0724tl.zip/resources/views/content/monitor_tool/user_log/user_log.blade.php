@extends('layouts/layoutMaster')

@section('title', 'User Log')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
    <div class="card">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title text-black fs-5 fw-bold mb-1">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <!-- Left: Title + Breadcrumb -->
                    <div class="d-flex flex-column">
                        <h5 class="card-title mb-1">User Log</h5>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0">
                                <li class="breadcrumb-item">
                                    <a href="https://erp.elysiumtechnologies.com/dashboards"
                                        class="d-flex align-items-center">
                                        <i class="mdi mdi-home text-body fs-4"></i>
                                    </a>
                                </li>
                                <span class="text-dark opacity-75 mx-1">
                                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                                </span>
                                <li class="breadcrumb-item">
                                    <a href="javascript:;" class="d-flex align-items-center fw-semibold">Monitoring
                                        Tools</a>
                                </li>
                            </ol>
                        </nav>
                    </div>

                    <!-- Right: Count + Button in same row -->
                    <div class="d-flex align-items-center gap-2">
                        <div>
                            <button id="clearLog" class="btn btn-danger">Clear</button>
                        </div>
                        <div>
                            <button id="homeips" class="btn btn-primary" onclick="homeipsopen()" data-bs-toggle="modal"
                                data-bs-target="#HomeipsModal">Home Ips</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        @php
            $helper = new \App\Helpers\Helpers();
            $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id;
        @endphp

        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-3">
                    @if (isset($role_permission->manage_branch))
                        @if ($role_permission->manage_branch == 2)
                            @php
                                $user_id = auth()->user()->user_id;
                                $branch_data = $helper->get_branch_control_list_user($user_id);
                                $branches = $branch_data['branches'];
                                $franchises = $branch_data['franchises'];
                            @endphp
                            <select name="branch_id" class="select2 form-select" id="branchSelectsgoal">
                                <option value="0" selected>All Branches</option>
                                @if ($branches->isNotEmpty())
                                    <optgroup label="Branches">
                                        @foreach ($branches as $branch)
                                            <option value="{{ $branch->sno }}"
                                                {{ $selectedBranch == $branch->sno ? 'selected' : '' }}>
                                                {{ $branch->branch_name }}
                                            </option>
                                        @endforeach
                                    </optgroup>
                                @endif
                                @if ($franchises->isNotEmpty())
                                    <optgroup label="Franchises">
                                        @foreach ($franchises as $franchise)
                                            <option value="{{ $franchise->sno }}"
                                                {{ $selectedBranch == $franchise->sno ? 'selected' : '' }}>
                                                {{ $franchise->franchise_name }}
                                            </option>
                                        @endforeach
                                    </optgroup>
                                @endif
                            </select>
                        @elseif($role_permission->manage_branch == 1)
                            @if ($branch_common)
                                <div class="d-flex align-items-center mt-2">
                                    <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                                    <div>
                                        <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                                        <small class="text-muted">{{ $branch_common->branch_name }}</small>
                                    </div>
                                </div>
                            @endif
                        @endif
                    @endif
                </div>

                <div class="col-lg-2 mb-2">
                    <select id="department_fill" name="department_fill" class="select2 form-select">
                        <option value="">Select Department</option>
                    </select>
                </div>

                <div class="col-md-2">
                    <select id="typeFilter" class="select2 form-select">
                        <option value="">All</option>
                        <option value="0">Success</option>
                        <option value="1">Failed</option>
                    </select>
                </div>

                <div class="col-md-2">
                    <input type="text" id="searchInput" class="form-control" placeholder="Search IP/User Name">
                </div>

                <div class="col-md-2">
                    <button id="filterBtn" class="btn btn-primary">Search</button>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1"
                            id="loginLogTable">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary text-white">
                                    <th>IP Address</th>
                                    <th>Date/Time</th>
                                    <th>User Name</th>
                                    <th>Password</th>
                                    <th>Login</th>
                                </tr>
                            </thead>
                            <tbody id="logTableBody">
                                <tr>
                                    <td colspan="5" class="text-center text-muted">Loading...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <nav>
                        <ul class="pagination justify-content-end mt-3" id="pagination"></ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <!-- Clear Log Modal -->
    <div class="modal fade" id="clearLogModal" tabindex="-1" aria-labelledby="clearLogModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="clearLogModalLabel">Clear Old Logs</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <label for="monthSelect" class="text-dark mb-1 fs-6 fw-semibold">Select Log Duration to Clear:</label>
                    <select id="monthSelect" class="select2 form-select">
                        <option value="">-- Choose --</option>
                        <option value="1">1 Month</option>
                        <option value="2">2 Months</option>
                        <option value="3">3 Months</option>
                        <option value="6">6 Months</option>
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="confirmClear" class="btn btn-danger">Clear Logs</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Home Ips Modal -->
    <div class="modal fade" id="HomeipsModal" tabindex="-1" aria-labelledby="HomeipsModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="HomeipsModalLabel">Home Ips</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="ipAddContainer">
                        <!-- Existing IPs will be displayed here -->
                    </div>
                    <button type="button" class="btn btn-info" id="addIpBtn">Add More IP</button>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" onclick="confirmClear()" class="btn btn-primary">Update Ip</button>
                </div>
            </div>
        </div>
    </div>

    <input type="hidden" id="ipadress" value="{{ $home_ips->ip_ids ?? '[]' }}">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        .toast-success {
            background-color: green !important;
        }

        .toast-error {
            background-color: red !important;
        }

        .error_msg {
            border: solid 2px red !important;
        }

        .bg-label-danger {
            background-color: rgba(234, 84, 85, 0.16) !important;
        }
    </style>

    <script>
        // Define global functions first
        window.homeipsopen = function() {
            try {
                var ipsElement = $('#ipadress');
                if (!ipsElement.length) return;

                var ips = ipsElement.val();
                ips = ips ? JSON.parse(ips) : [];

                $('#ipAddContainer').empty();

                if (ips.length === 0) {
                    $('#ipAddContainer').append(`
                        <div class="input-group mb-3">
                            <input type="text" class="form-control ip-input" placeholder="Enter IP address">
                            <button class="btn btn-danger remove-ip" type="button">Remove</button>
                        </div>
                    `);
                } else {
                    ips.forEach(function(ip) {
                        $('#ipAddContainer').append(`
                            <div class="input-group mb-3">
                                <input type="text" class="form-control ip-input" value="${ip}">
                                <button class="btn btn-danger remove-ip" type="button">Remove</button>
                            </div>
                        `);
                    });
                }
            } catch (e) {
                console.error('Error parsing IPs:', e);
                toastr.error('Error loading IP addresses');
            }
        };

        window.confirmClear = function() {
            var updatedIps = [];
            var isValid = true;

            $('.ip-input').each(function() {
                var ipValue = $(this).val().trim();
                if (ipValue === '') {
                    $(this).addClass('error_msg');
                    isValid = false;
                } else {
                    $(this).removeClass('error_msg');
                    updatedIps.push(ipValue);
                }
            });

            if (!isValid) {
                toastr.error('Please fill in all IP addresses');
                return;
            }

            if (updatedIps.length > 0) {
                $.ajax({
                    url: '{{ route('homeips.update') }}',
                    method: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        ips: updatedIps
                    },
                    success: function(response) {
                        if (response.success) {
                            toastr.success('IP addresses updated successfully');
                            $('#ipadress').val(JSON.stringify(updatedIps));
                            $('#HomeipsModal').modal('hide');
                            if (typeof loadLogs === 'function') {
                                loadLogs();
                            }
                        } else {
                            toastr.error(response.message || 'Failed to update IP addresses');
                        }
                    },
                    error: function(xhr) {
                        toastr.error(xhr.responseJSON?.message || 'Error occurred while updating IPs');
                    }
                });
            }else{
                toastr.error('Please fill atleast one IP addresses');
                return;
            }
        };

        $(document).ready(function() {
            // Initialize Select2
            // $('.select2').select2({
            //     dropdownParent: $('body')
            // });

            let currentPage = 1;
            let isLoading = false;

            // Main function to load logs
            window.loadLogs = function(page = 1) {
                if (isLoading) return;
                isLoading = true;

                const search = $('#searchInput').val();
                const type = $('#typeFilter').val();
                const branch_id = $('#branchSelectsgoal').val();
                const department_id = $('#department_fill').val();

                $('#logTableBody').html(
                    '<tr><td colspan="5" class="text-center text-muted">Loading...</td></tr>');

                $.ajax({
                    url: `/user_login_logs/list?page=${page}`,
                    type: 'GET',
                    data: {
                        search,
                        type,
                        branch_id,
                        department_id
                    },
                    success: function(res) {
                        if (res.status === 200) {
                            const data = res.data.data;
                            let rows = '';

                            if (data.length === 0) {
                                rows =
                                    '<tr><td colspan="5" class="text-center text-muted">No Records Found</td></tr>';
                            } else {
                                let ips = [];
                                try {
                                    ips = JSON.parse($('#ipadress').val() || '[]');
                                } catch (e) {
                                    ips = [];
                                }

                                data.forEach(log => {
                                    const badgeClass = log.login_type === 'Success' ?
                                        'bg-success' : 'bg-danger';
                                    const passwordDisplay = log.login_type === 'Success' ?
                                        '*********' : (log.password ?? '-');
                                    const branchBadgeClass = (!log.branch_name || log
                                            .branch_name === 'Unknown') ?
                                        'bg-danger text-white' : 'bg-info';
                                    const rowClass = ips.includes(log.ip_address) ? '' :
                                        'bg-label-danger';

                                    rows += `
                                        <tr class="${rowClass}">
                                            <td>
                                                ${log.ip_address ?? '-'}<br/>
                                                <span class="badge ${branchBadgeClass}">${log.branch_name ?? '-'}</span>
                                            </td>
                                            <td>${log.date_time ?? '-'}</td>
                                            <td>${log.user_name ?? '-'}</td>
                                            <td>${passwordDisplay}</td>
                                            <td><span class="badge ${badgeClass}">${log.login_type}</span></td>
                                        </tr>
                                    `;
                                });
                            }

                            $('#logTableBody').html(rows);
                            renderPagination(res.data);
                        }
                    },
                    error: function() {
                        $('#logTableBody').html(
                            '<tr><td colspan="5" class="text-center text-danger">Error loading data</td></tr>'
                            );
                    },
                    complete: function() {
                        isLoading = false;
                    }
                });
            };

            // Pagination render function
            function renderPagination(pagination) {
                if (!pagination || pagination.last_page <= 1) {
                    $('#pagination').html('');
                    return;
                }

                let pagHtml = '';
                const total = pagination.last_page;
                const current = pagination.current_page;
                let start = Math.max(1, current - 2);
                let end = Math.min(total, current + 2);

                // Previous button
                pagHtml += `<li class="page-item ${current === 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${current - 1}">Previous</a>
                    </li>`;

                // First page
                if (start > 1) {
                    pagHtml += `<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>`;
                    if (start > 2) pagHtml +=
                        `<li class="page-item disabled"><span class="page-link">...</span></li>`;
                }

                // Page numbers
                for (let i = start; i <= end; i++) {
                    pagHtml += `<li class="page-item ${i === current ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${i}">${i}</a>
                        </li>`;
                }

                // Last page
                if (end < total) {
                    if (end < total - 1) pagHtml +=
                        `<li class="page-item disabled"><span class="page-link">...</span></li>`;
                    pagHtml +=
                        `<li class="page-item"><a class="page-link" href="#" data-page="${total}">${total}</a></li>`;
                }

                // Next button
                pagHtml += `<li class="page-item ${current === total ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${current + 1}">Next</a>
                    </li>`;

                $('#pagination').html(pagHtml);
            }

            // Event bindings
            $('#filterBtn').click(function() {
                currentPage = 1;
                loadLogs();
            });

            $('#searchInput, #typeFilter, #branchSelectsgoal, #department_fill').on('change', function() {
                currentPage = 1;
                loadLogs();
            });

            $('#pagination').on('click', '.page-link', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (!page || $(this).parent().hasClass('disabled') || $(this).parent().hasClass('active'))
                    return;
                currentPage = page;
                loadLogs(page);
            });

            // Load departments
            $.ajax({
                url: "{{ route('department') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('#department_fill');
                        selectDropdown.empty();
                        selectDropdown.append('<option value="">Select Department</option>');

                        response.data.forEach(function(dpt_list) {
                            selectDropdown.append(
                                $('<option></option>').attr('value', dpt_list.sno)
                                .text(dpt_list.department_name)
                            );
                        });

                        // Refresh Select2
                        selectDropdown.trigger('change');
                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                    toastr.error('Failed to load departments');
                }
            });

            // Clear Log modal
            $('#clearLog').on('click', function() {
                $('#monthSelect').val('').trigger('change');
                $('#clearLogModal').modal('show');
            });

            // Confirm Clear
            $('#confirmClear').on('click', function() {
                const months = $('#monthSelect').val();

                if (!months) {
                    toastr.error('Please select how many months to clear.');
                    return;
                }

                if (!confirm(`Are you sure you want to delete logs older than ${months} month(s)?`)) {
                    return;
                }

                $.ajax({
                    url: '/logs/clear',
                    type: 'POST',
                    data: {
                        months: months,
                        _token: '{{ csrf_token() }}'
                    },
                    beforeSend: function() {
                        $('#confirmClear').prop('disabled', true).html(
                            '<span class="spinner-border spinner-border-sm me-1"></span> Clearing...'
                            );
                    },
                    success: function(response) {
                        $('#clearLogModal').modal('hide');
                        toastr.success(response.message || 'Logs cleared successfully');
                        loadLogs();
                    },
                    error: function(xhr) {
                        toastr.error(xhr.responseJSON?.message || 'Error clearing logs');
                    },
                    complete: function() {
                        $('#confirmClear').prop('disabled', false).text('Clear Logs');
                    }
                });
            });

            // Add More IP functionality
            $('#addIpBtn').on('click', function() {
                $('#ipAddContainer').append(`
                    <div class="input-group mb-3">
                        <input type="text" class="form-control ip-input" placeholder="Enter new IP">
                        <button class="btn btn-danger remove-ip" type="button">Remove</button>
                    </div>
                `);
            });

            // Remove IP functionality
            $(document).on('click', '.remove-ip', function() {
                $(this).closest('.input-group').remove();
            });

            // Clear error class on input
            $(document).on('input', '.ip-input', function() {
                $(this).removeClass('error_msg');
            });

            // Initial load
            loadLogs();
        });
    </script>
@endsection
