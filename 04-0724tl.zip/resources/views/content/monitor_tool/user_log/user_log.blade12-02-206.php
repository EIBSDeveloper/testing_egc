@extends('layouts/layoutMaster')

@section('title', 'User Log')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('content')

    <div class="card">
        <div class="card-header border-bottom pb-1 ">
            <div class="card-action-title text-black fs-5 fw-bold mb-1">
              <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            
                <!-- Left: Title + Breadcrumb -->
                <div class="d-flex flex-column">
                  <h5 class="card-title mb-1">User Log</h5>
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                      <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center">
                          <i class="mdi mdi-home text-body fs-4"></i>
                        </a>
                      </li>
                      <span class="text-dark opacity-75 mx-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                      </span>
                      <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center fw-semibold">Monitoring Tools</a>
                      </li>
                    </ol>
                  </nav>
                </div>
            
                <!-- Right: Count + Button in same row -->
                <div class="d-flex align-items-center gap-3">
                    <div class="col-md-12">
                      <button id="clearLog" class="btn btn-danger w-100">Clear</button>
                    </div>
                </div>
                
              </div>
            </div>

        </div>
        @php
            $helper = new \App\Helpers\Helpers();
            $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id;
        @endphp
        <div class="card-body">
          <div class="row mb-3">
            <div class="col-md-3">
                @if(isset($role_permission->manage_branch))
                    @if($role_permission->manage_branch == 2)
                        @php
                            $user_id = auth()->user()->user_id;
                            $branch_data = $helper->get_branch_control_list_user($user_id);
                            $branches = $branch_data['branches'];
                            $franchises = $branch_data['franchises'];
                        @endphp
                        <select name="branch_id" class="select3 form-select" id="branchSelectsgoal">
                            <option value="0" selected>All Branches</option>
                            @if ($branches->isNotEmpty())
                                <optgroup label="Branches">
                                    @foreach ($branches as $branch)
                                        <option value="{{ $branch->sno }}" {{ $selectedBranch == $branch->sno ? 'selected' : '' }}>
                                            {{ $branch->branch_name }}
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                            @if ($franchises->isNotEmpty())
                                <optgroup label="Franchises">
                                    @foreach ($franchises as $franchise)
                                        <option value="{{ $franchise->sno }}" {{ $selectedBranch == $franchise->sno ? 'selected' : '' }}>
                                            {{ $franchise->franchise_name }}
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                        </select>
                    @elseif($role_permission->manage_branch == 1)
                        @if($branch_common)
                            <div class="d-flex align-items-center mt-2">
                                <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                                <div>
                                    <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                                    <small class="text-muted">{{ $branch_common->branch_name }}</small>
                                </div>
                            </div>
                        @endif
                    @endif
                @endif
            </div>
            <div class="col-lg-2 mb-2">
                <select id="department_fill" name="department_fill" class="select3 form-select">
                    <option value="">Select Department</option>
                </select>
            </div>
            <div class="col-md-2">
              <select id="typeFilter" class="select3 form-select">
                <option value="">All</option>
                <option value="0">Success</option>
                <option value="1">Failed</option>
              </select>
            </div>
            <div class="col-md-2">
              <input type="text" id="searchInput" class="form-control" placeholder="Search IP/User Name">
            </div>
            <div class="col-md-2">
              <button id="filterBtn" class="btn btn-primary w-50">Search</button>
            </div>
            
          </div>
        
          <div class="row">
            <div class="col-lg-12">
              <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page" id="loginLogTable">
                <thead>
                  <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary text-white">
                    <th>IP Address</th>
                    <th>Date/Time</th>
                    <th>User Name</th>
                    <th>Password</th>
                    <th>Login</th>
                  </tr>
                </thead>
                <tbody id="logTableBody">
                  <tr>
                      <td></td>
                      <td></td>
                      <td class="text-center text-muted">Loading...</td>
                      <td></td>
                      <td></td>
                  </tr>
                </tbody>
              </table>
        
              <nav>
                <ul class="pagination justify-content-end mt-3" id="pagination"></ul>
              </nav>
            </div>
          </div>
        </div>
    </div>
    <!-- Modal -->
<div class="modal fade" id="clearLogModal" tabindex="-1" aria-labelledby="clearLogModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title" id="clearLogModalLabel">Clear Old Logs</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      
      <div class="modal-body">
        <label for="monthSelect" class="text-dark mb-1 fs-6 fw-semibold">Select Log Duration to Clear:</label>
        <select id="monthSelect" class="select3 form-select">
          <option value="">-- Choose --</option>
          <option value="1">1 Month</option>
          <option value="2">2 Months</option>
          <option value="3">3 Months</option>
          <option value="6">6 Months</option>
        </select>
      </div>
      
      <div class="text-center mt-2 mb-2">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" id="confirmClear" class="btn btn-danger">Clear Logs</button>
      </div>
      
    </div>
  </div>
</div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }

</style>



<script>

$(document).ready(function() {
    let currentPage = 1;

    function loadLogs(page = 1) {
        const search = $('#searchInput').val();
        const type = $('#typeFilter').val();
        const branch_id = $('#branchSelectsgoal').val();
        const department_id = $('#department_fill').val();
        $('#logTableBody').html(`<tr><td colspan="5" class="text-center text-muted">Loading...</td></tr>`);

        $.ajax({
            url: `/user_login_logs/list?page=${page}`,
            type: 'GET',
            data: { search, type, branch_id, department_id },
            success: function(res) {
                if (res.status === 200) {
                    const data = res.data.data;
                    let rows = '';

                    if (data.length === 0) {
                        rows = `<tr><td colspan="5" class="text-center text-muted">No Records Found</td></tr>`;
                    } else {
                        data.forEach(log => {
                            const badgeClass = log.login_type === 'Success' ? 'bg-success' : 'bg-danger';
                            // ðŸ‘‡ Hide password if Success, show if Failed
                            const passwordDisplay = log.login_type === 'Success' ? '*********' : (log.password ?? '-');
                            const branchBadgeClass = (log.branch_name === 'Unknown' || !log.branch_name)
                                ? 'bg-danger text-white'
                                : 'bg-info';

                            rows += `
                                <tr>
                                    <td>
                                    ${log.ip_address ?? '-'}<br/>
                                    <span class="badge ${branchBadgeClass}">${log.branch_name ?? '-'}</span>
                                    </td>
                                    <td>${log.date_time ?? '-'}</td>
                                    <td>
                                      ${log.user_name ?? '-'} 
                                      
                                    </td>
                                    <td>${passwordDisplay}</td>
                                    <td><span class="badge ${badgeClass}">${log.login_type}</span></td>
                                </tr>
                            `;
                        });
                    }

                    $('#logTableBody').html(rows);
                    renderPagination(res.data);
                }
            },
            error: function() {
                $('#logTableBody').html(`<tr><td colspan="5" class="text-center text-danger">Error loading data</td></tr>`);
            }
        });
    }

    // ðŸ‘‡ Smart Pagination Function
    function renderPagination(pagination) {
        let pagHtml = '';
        const total = pagination.last_page;
        const current = pagination.current_page;

        if (total <= 1) {
            $('#pagination').html('');
            return;
        }

        let start = Math.max(1, current - 2);
        let end = Math.min(total, current + 2);

        // Always show first and last pages when far away
        if (start > 1) {
            pagHtml += `<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>`;
            if (start > 2) pagHtml += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        }

        for (let i = start; i <= end; i++) {
            pagHtml += `<li class="page-item ${i === current ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${i}">${i}</a>
                        </li>`;
        }

        if (end < total) {
            if (end < total - 1) pagHtml += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
            pagHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${total}">${total}</a></li>`;
        }

        // Previous / Next
        let prevDisabled = current === 1 ? 'disabled' : '';
        let nextDisabled = current === total ? 'disabled' : '';
        pagHtml = `<li class="page-item ${prevDisabled}">
                        <a class="page-link" href="#" data-page="${current - 1}">Previous</a>
                    </li>` + pagHtml +
                   `<li class="page-item ${nextDisabled}">
                        <a class="page-link" href="#" data-page="${current + 1}">Next</a>
                    </li>`;

        $('#pagination').html(pagHtml);
    }

    // Event bindings
    $('#filterBtn').click(function() {
        currentPage = 1;
        loadLogs();
    });

    $('#pagination').on('click', '.page-link', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        if (!page || $(this).parent().hasClass('disabled') || $(this).parent().hasClass('active')) return;
        currentPage = page;
        loadLogs(page);
    });
    $('#branchSelectsgoal').change(function() {
        currentPage = 1;
        loadLogs();
    });
    // Initial load
    loadLogs();
    
     $.ajax({
        // route from hr_directory web.php
        url: "{{ route('department') }}"
        , type: "GET"
        , success: function(response) {
            console.warn(response);
            if (response.status === 200 && response.data) {
                // Populate the select dropdown with fetched hr directory
                var selectDropdown = $('select[name="department_fill"]');
                selectDropdown.empty();
                selectDropdown.append($('<option value="">Select Department</option>'));
                response.data.forEach(function(dpt_list) {
                    var option = $('<option></option>').attr('value', dpt_list.sno)
                        .text(dpt_list.department_name);
                    selectDropdown.append(option);
                });
            }
        }
        , error: function(error) {
            console.error('Error fetching Department:', error);
        }
    });
});
</script>

<script>
$(document).ready(function () {

    // 🧩 Open Modal
    $('#clearLog').on('click', function () {
        $('#monthSelect').val('');
        $('#clearLogModal').modal('show');
    });

    // 🗑 Confirm Clear
    $('#confirmClear').on('click', function () {
        const months = $('#monthSelect').val();

        if (!months) {
            alert('Please select how many months to clear.');
            return;
        }

        if (!confirm(`Are you sure you want to delete logs older than ${months} month(s)?`)) {
            return;
        }

        $.ajax({
            url: '/logs/clear',
            type: 'POST',
            data: {
                months: months,
                _token: '{{ csrf_token() }}'
            },
            beforeSend: function () {
                $('#confirmClear').prop('disabled', true).text('Clearing...');
            },
            success: function (response) {
                $('#clearLogModal').modal('hide');
                toastr.success(response.message);

                // ✅ Refresh the table after deletion
                if (typeof loadLogs === 'function') {
                    loadLogs();
                } else {
                    console.warn('⚠️ loadLogs() function not found.');
                }
            },
            error: function (xhr) {
                alert('Error clearing logs: ' + (xhr.responseJSON?.message || 'Unknown error'));
            },
            complete: function () {
                $('#confirmClear').prop('disabled', false).text('Clear Logs');
            }
        });
    });
});
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
         "pageLength":25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });

</script>
@endsection
