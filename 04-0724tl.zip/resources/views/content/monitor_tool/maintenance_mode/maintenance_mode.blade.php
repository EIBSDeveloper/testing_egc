@extends('layouts/layoutMaster')

@section('title', 'Maintenance Mode')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('content')
<div class="card">
    <div class="card-header border-bottom pb-1 ">
            <div class="card-action-title text-black fs-5 fw-bold mb-1">
              <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            
                <!-- Left: Title + Breadcrumb -->
                <div class="d-flex flex-column">
                  <h5 class="card-title mb-1">Maintenance Mode</h5>
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                      <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center">
                          <i class="mdi mdi-home text-body fs-4"></i>
                        </a>
                      </li>
                      <span class="text-dark opacity-75 mx-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                      </span>
                      <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center fw-semibold">Monitoring Tools</a>
                      </li>
                    </ol>
                  </nav>
                </div>
            
                <!-- Right: Count + Button in same row -->
                <div class="d-flex align-items-center gap-3">
                    
                </div>
                
              </div>
            </div>

        </div>
   
    <div class="card-body">
        @php
            // Recursive function to render menu and submenus
            function renderMenu($items, $level = 0) {
                $bgColors = ['#e0f2ff','rgba(9,157,218,0.2)','#b3dbff']; // Submenu shades
                foreach($items as $item):
                    $hasSub = isset($item['submenu']) && count($item['submenu']) > 0;
                    $currentBg = $level === 0 ? '#099dda' : ($bgColors[$level % count($bgColors)] ?? '#e0f2ff');
                    $textColor = $level === 0 ? 'white' : '#1e3a8a';
                    $collapseId = "menu-{$item['slug']}";
        @endphp
        <li class="mb-2">
            <div class="d-flex justify-content-between align-items-center p-3 rounded mb-1 menu-item-header {{ $level === 0 ? 'main-menu' : 'submenu-level' }}"
                 data-bs-toggle="collapse"
                 data-bs-target="#{{ $collapseId }}"
                 style="cursor:pointer; background-color: {{ $currentBg }}; color: {{ $textColor }};">
                 
                <div class="d-flex align-items-center flex-grow-1 me-3">
                    <i class="{{ $item['icon'] ?? 'mdi mdi-folder-outline' }} me-3"></i>
                    <div class="d-flex flex-column w-100">
                        <div class="fw-semibold">{{ $item['name'] }}</div>
                        <div class="maintenance-date">
                            @if(!empty($item['maintenance_date']))
                                @if($item['status'] == 0)
                                    <small class="d-flex align-items-center mt-1">
                                        <i class="mdi mdi-check-circle-outline me-1 text-success"></i>
                                        <span class="text-success fw-semibold">Live : {{ \Carbon\Carbon::parse($item['maintenance_date'])->format('M d, Y H:i') }}</span>
                                    </small>
                                @else
                                    <small class="d-flex align-items-center mt-1">
                                        <i class="mdi mdi-clock-alert-outline me-1"></i>
                                        <span class="fw-bold" style="color:#ef4444;">
                                            Since: {{ \Carbon\Carbon::parse($item['maintenance_date'])->format('M d, Y H:i') }}
                                        </span>
                                    </small>
                                @endif
                            @else
                                <small class="d-flex align-items-center mt-1">
                                    <i class="mdi mdi-check-circle-outline me-1 text-success"></i>
                                    <span class="text-success fw-semibold">Live</span>
                                </small>
                            @endif
                        </div>
                    </div>
                </div>
    
                <div class="d-flex align-items-center toggle-container">
                    <!-- Toggle -->
                    <div class="toggle-wrapper me-2">
                        <label style="width:100%; height:100%; cursor:pointer; margin:0;">
                            <input type="checkbox" class="maintenance-toggle" data-slug="{{ $item['slug'] }}" {{ ($item['status'] ?? 0) ? '' : 'checked' }}>
                            <span class="slider">
                                <span class="label-on">Live</span>
                                <span class="label-off">Maintenance</span>
                            </span>
                        </label>
                    </div>
                    @if($hasSub)
                        <i class="mdi mdi-chevron-down ms-2 menu-chevron" data-target="#{{ $collapseId }}"></i>
                        @else
                        <span class="ms-4"></span>
                    @endif
                </div>
            </div>
    
            @if($hasSub)
                <ul class="ps-3 collapse" id="{{ $collapseId }}">
                    {!! renderMenu($item['submenu'], $level + 1) !!}
                </ul>
            @endif
        </li>
        @php
                endforeach;
            }
        @endphp
    
        <ul class="menu-list list-unstyled">
            {!! renderMenu($menu['menu']) !!}
        </ul>
    </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
    /* Toastr */
    .toast { background-color: #39484f; }
    .toast-success { background-color: green; }
    .toast-error { background-color: red; }
    .main-menu { transition: background 0.3s; }
    .main-menu:hover { opacity: 0.9; }
    .submenu-level { transition: background 0.3s; }
    .submenu-level:hover { opacity: 0.9; }
    
    /* Toggle Container - Fixed width for consistent alignment */
    .toggle-container {
        min-width: 190px;
        justify-content: flex-end;
    }
    
    /* Toggle */
    .toggle-wrapper { 
        position: relative; 
        width: 170px; 
        height: 35px; 
        display:inline-block; 
        flex-shrink: 0;
    }
    .maintenance-toggle { 
        opacity:0; 
        width:100%; 
        height:100%; 
        position:absolute; 
        top:0; 
        left:0; 
        z-index:11; 
        cursor:pointer; 
    }
    .slider { 
        position:absolute; 
        cursor:pointer; 
        top:0; 
        left:0; 
        right:0; 
        bottom:0; 
        background-color:#ef4444; 
        border-radius:35px; 
        display:flex; 
        align-items:center; 
        justify-content:space-between; 
        padding:0 12px; 
        color:white; 
        font-weight:bold; 
        font-size:13px; 
        user-select:none; 
        transition:0.4s; 
        z-index:9; 
    }
    .slider .label-on { 
        opacity:0; 
        width:58%; 
        text-align:center; 
        transition:opacity 0.4s; 
    }
    .slider .label-off { 
        opacity:1; 
        width:58%; 
        text-align:center; 
        transition:opacity 0.4s; 
    }
    .slider::before { 
        content:''; 
        position:absolute; 
        width:27px; 
        height:27px; 
        border-radius:50%; 
        background:white; 
        top:4px; 
        left:4px; 
        transition:0.4s; 
        z-index:2; 
        box-shadow:0 2px 4px rgba(0,0,0,0.2); 
    }
    .maintenance-toggle:checked + .slider { 
        background-color:#4ade80; 
    }
    .maintenance-toggle:checked + .slider .label-on { 
        opacity:1; 
    }
    .maintenance-toggle:checked + .slider .label-off { 
        opacity:0; 
    }
    .maintenance-toggle:checked + .slider::before { 
        transform: translateX(135px); 
    }

    /* Chevron rotation */
    .menu-chevron { 
        transition: transform 0.3s ease; 
        flex-shrink: 0;
    }
    .menu-chevron.rotated { 
        transform: rotate(180deg); 
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .menu-item-header {
            flex-direction: column;
            align-items: flex-start !important;
        }
        .menu-item-header > div:first-child {
            margin-bottom: 10px;
            width: 100%;
        }
        .toggle-container {
            min-width: 100%;
            justify-content: flex-start;
        }
        .toggle-wrapper {
            width: 150px;
        }
        .maintenance-toggle:checked + .slider::before {
            transform: translateX(115px);
        }
    }
    
    @media (max-width: 576px) {
        .card-header .d-flex {
            flex-direction: column;
            align-items: flex-start !important;
        }
        .card-title {
            font-size: 1.25rem;
        }
        .toggle-wrapper {
            width: 140px;
        }
        .maintenance-toggle:checked + .slider::before {
            transform: translateX(105px);
        }
    }
</style>

<script>
$(document).ready(function() {
    // Handle chevron rotation on collapse
    $('.menu-chevron').on('click', function(e) {
        e.stopPropagation();
        $(this).toggleClass('rotated');
    });
    
    // Handle toggle change
    $(document).on('change', '.maintenance-toggle', function(e) {
        e.stopPropagation(); // Prevent collapse toggle

        let slug = $(this).data('slug');
        let status = $(this).is(':checked') ? 0 : 1; // Maintenance = 1
        let $toggle = $(this);
        let $menuItem = $toggle.closest('.menu-item-header');
        let $date = $menuItem.find('.maintenance-date');

        $.ajax({
            url: "{{ route('maintenance.toggle') }}",
            method: "POST",
            data: { _token: "{{ csrf_token() }}", slug, status },
            success: function(res) {
                if(res.success) {
                    toastr.success(res.message);

                    // Update status display
                    if(status === 1 && res.maintenance_date){
                        let dt = new Date(res.maintenance_date);
                        let options = { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false };
                        let formatted = dt.toLocaleString('en-US', options).replace(',', '');
                        $date.html(`
                            <small class="d-flex align-items-center mt-1">
                                <i class="mdi mdi-clock-alert-outline me-1"></i>
                                <span class="fw-bold" style="color:#ef4444;">
                                    Since: ${formatted}
                                </span>
                            </small>
                        `);
                    } else {
                        if(res.maintenance_date){
                            let dt = new Date(res.maintenance_date);
                            let options = { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false };
                            let formatted = dt.toLocaleString('en-US', options).replace(',', '');
                            $date.html(`
                                <small class="d-flex align-items-center mt-1">
                                    <i class="mdi mdi-check-circle-outline me-1 text-success"></i>
                                    <span class="text-success fw-semibold">Live: ${formatted}</span>
                                </small>
                            `);
                        }else{
                            $date.html(`
                                <small class="d-flex align-items-center mt-1">
                                    <i class="mdi mdi-check-circle-outline me-1 text-success"></i>
                                    <span class="text-success fw-semibold">Live</span>
                                </small>
                            `);
                        }
                    }
                    
                    // Update status summary if available
                    if(res.live_count !== undefined && res.maintenance_count !== undefined) {
                        $('.status-summary').html(`
                            <span class="text-success fw-bold">${res.live_count} Live</span> | 
                            <span class="text-danger fw-bold">${res.maintenance_count} Maintenance</span>
                        `);
                    }
                } else {
                    toastr.error(res.message);
                    $toggle.prop('checked', !status);
                }
            },
            error: function() {
                toastr.error('Something went wrong!');
                $toggle.prop('checked', !status);
            }
        });
    });
});
</script>
@endsection