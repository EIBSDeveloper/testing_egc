@extends('layouts/layoutMaster')

@section('title', 'Maintenance Mode')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('content')
<style>
   

    /* Optional floating shapes */
    .background-shapes {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0; left: 0;
        pointer-events: none;
        overflow: hidden;
        z-index: 1;
    }

    .shape {
        position: absolute;
        border-radius: 50%;
        opacity: 0.2;
        animation: floatShapes 10s linear infinite;
    }

    .shape.shape1 { width: 120px; height: 120px; background-color: #ff6b6b; top: 20%; left: 10%; animation-duration: 12s; }
    .shape.shape2 { width: 80px; height: 80px; background-color: #f77f00; top: 60%; left: 80%; animation-duration: 15s; }
    .shape.shape3 { width: 100px; height: 100px; background-color: #4ade80; top: 40%; left: 50%; animation-duration: 18s; }
    .shape.shape4 { width: 60px; height: 60px; background-color: #1e90ff; top: 70%; left: 30%; animation-duration: 25s; }
    .shape.shape5 { width: 90px; height: 90px; background-color: #ff69b4; top: 20%; left: 70%; animation-duration: 22s; }
    .shape.shape6 { width: 50px; height: 50px; background-color: #4ade80; top: 30%; left: 60%; animation-duration: 22s; }
    .shape.shape7 { width: 76px; height: 76px; background-color: #ff69b4; top: 50%; left: 70%; animation-duration: 22s; }

    @keyframes floatShapes {
        0% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(-30px) rotate(180deg); }
        100% { transform: translateY(0px) rotate(360deg); }
    }

    /* Center container */
    .maintenance-container {
        display: flex;
        justify-content: center;
        align-items: center;
        /*height: 100vh;*/
        position: relative;
        z-index: 2;
    }

    /* Card style */
    .maintenance-card {
        background-color: rgba(255,255,255,0.95);
        border-radius: 25px;
        box-shadow: 0 16px 40px rgba(0,0,0,0.25);
        padding: 60px 50px;
        max-width: 520px;
        width: 100%;
        text-align: center;
        position: relative;
        overflow: hidden;
        animation: fadeIn 0.8s ease-in-out;
        z-index: 3;
    }

    /* Icon container */
    .icon-container {
        position: relative;
        margin-bottom: 25px;
    }

    .icon-big {
        font-size: 80px;
        color: #e63946;
        animation: spin 2s linear infinite;
        display: inline-block;
        z-index: 3;
        position: relative;
    }

    .icon-small-left, .icon-small-right {
        font-size: 40px;
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        animation: float 3s ease-in-out infinite;
    }

    .icon-small-left {
        left: -50px;
        color: #f77f00;
    }

    .icon-small-right {
        right: -50px;
        color: #1e90ff;
        animation-delay: 1.5s;
    }

    @keyframes float {
        0% { transform: translateY(-10px); }
        50% { transform: translateY(10px); }
        100% { transform: translateY(-10px); }
    }

    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }

    /* Heading and text */
    .maintenance-card h1 { color: #e63946; font-size: 2.7rem; margin-bottom: 15px; font-weight: 700; }
    .maintenance-card p { color: #333333; font-size: 1.2rem; margin-bottom: 20px; }
    .maintenance-card .maintenance-date { color: #f77f00; font-weight: 600; display: block; margin-top: 10px; font-size: 1rem; }

    /* GIF image */
    .maintenance_image { width: 50%; max-width: 300px; height: auto; margin-bottom: 20px; }

    /* Fade-in animation */
    @keyframes fadeIn { from { opacity: 0; transform: translateY(-30px); } to { opacity: 1; transform: translateY(0); } }

    /* Responsive */
    @media (max-width: 576px) {
        .maintenance-card { padding: 40px 30px; }
        .maintenance-card h1 { font-size: 2.2rem; }
        .icon-big { font-size: 60px; }
        .icon-small-left, .icon-small-right { font-size: 28px; }
    }
</style>

<div class="background-shapes">
    <div class="shape shape1"><i class="mdi mdi-cog-outline icon-big"></i></div>
    <div class="shape shape2"><i class="mdi mdi-cog-outline icon-big"></i></div>
    <div class="shape shape3"><i class="mdi mdi-cog-outline icon-small-left"></i></div>
    <div class="shape shape4"><i class="mdi mdi-cog-outline icon-big"></i></div>
    <div class="shape shape5"><i class="mdi mdi-cog-outline icon-big"></i></div>
     <div class="shape shape6"><i class="mdi mdi-cog-outline icon-big"></i></div>
      <div class="shape shape7"><i class="mdi mdi-cog-outline icon-big"></i></div>
</div>

<div class="maintenance-container">
    <div class="maintenance-card">
        <div class="icon-container">
            <i class="mdi mdi-cog-outline icon-big"></i>
            <i class="mdi mdi-cog-outline icon-small-left"></i>
            <i class="mdi mdi-cog-outline icon-small-right"></i>
        </div>

        <img
            class="maintenance_image"
            src="https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExZHBvM3p1eG1zZGthNGs5bHkwa3l4Mjc4ZGVzN2RveTNwamw5eHZ1dyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/qIMZVXWJHQI0Qu3Pe9/giphy.gif"
            alt="Working On It"
        />

        <h1>Maintenance Mode</h1>
        <p>This page is currently under maintenance.</p>

        @if(session('maintenance_since'))
            <span class="maintenance-date">
                Since: {{ \Carbon\Carbon::parse(session('maintenance_since'))->format('M d, Y H:i') }}
            </span>
        @endif
    </div>
</div>

<!-- Material Design Icons -->
<link href="https://cdn.materialdesignicons.com/6.5.95/css/materialdesignicons.min.css" rel="stylesheet">




@endsection