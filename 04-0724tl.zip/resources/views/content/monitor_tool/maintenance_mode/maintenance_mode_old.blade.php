@extends('layouts/layoutMaster')

@section('title', 'Maintenance Mode')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('content')

    <div class="card">
        <div class="card-header border-bottom pb-1 ">
            <div class="card-action-title text-black fs-5 fw-bold mb-1">
              <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            
                <!-- Left: Title + Breadcrumb -->
                <div class="d-flex flex-column">
                  <h5 class="card-title mb-1">Maintenance Mode</h5>
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                      <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center">
                          <i class="mdi mdi-home text-body fs-4"></i>
                        </a>
                      </li>
                      <span class="text-dark opacity-75 mx-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                      </span>
                      <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center fw-semibold">Monitoring Tools</a>
                      </li>
                    </ol>
                  </nav>
                </div>
            
                <!-- Right: Count + Button in same row -->
                <div class="d-flex align-items-center gap-3">
                    
                </div>
                
              </div>
            </div>

        </div>
       
        <div class="card-body">
            @php
                // Recursive function to render menu and submenus
                function renderMenu($items, $level = 0) {
                    $bgColors = ['#e0f2ff','rgba(9,157,218,0.2)','#b3dbff']; // Submenu shades
                    foreach($items as $item):
                        $hasSub = isset($item['submenu']) && count($item['submenu']) > 0;
                        $currentBg = $level === 0 ? '#099dda' : ($bgColors[$level % count($bgColors)] ?? '#e0f2ff');
                        $textColor = $level === 0 ? 'white' : '#1e3a8a';
                        $collapseId = "menu-{$item['slug']}";
            @endphp
            <li class="mb-2">
                <div class="d-flex justify-content-between align-items-center p-2 rounded mb-1 menu-item-header {{ $level === 0 ? 'main-menu' : 'submenu-level' }}"
                     data-bs-toggle="collapse"
                     data-bs-target="#{{ $collapseId }}"
                     style="cursor:pointer; background-color: {{ $currentBg }}; color: {{ $textColor }};">
                     
                    <div class="d-flex align-items-center">
                        <i class="{{ $item['icon'] ?? 'mdi mdi-folder' }} me-2"></i>
                        <div>
                            <div>{{ $item['name'] }}</div>
                            <small class="maintenance-date text-warning fw-bold ">
                                @if(!empty($item['maintenance_date']))
                                  <span class="fw-bold" style="color:#ef4444;">Since: {{ \Carbon\Carbon::parse($item['maintenance_date'])->format('M d, Y H:i') }}</span>
                                @else
                                   <span class="align-middle" style="display:inline-flex; align-items:center;">
                                    <span style="font-size:1.2rem; font-weight:bold; margin-right:4px; line-height:1;">&middot;</span>
                                    Live
                                  </span>
                                @endif
                            </small>
                        </div>
                    </div>
        
                    <div class="d-flex align-items-center">
                        <!-- Toggle -->
                        <div class="toggle-wrapper me-2">
                            <label style="width:100%; height:100%; cursor:pointer; margin:0;">
                                <input type="checkbox" class="maintenance-toggle" data-slug="{{ $item['slug'] }}" {{ ($item['status'] ?? 0) ? '' : 'checked' }}>
                                <span class="slider">
                                    <span class="label-on">Live</span>
                                    <span class="label-off">Maintenance</span>
                                </span>
                            </label>
                        </div>
                        @if($hasSub)
                            <i class="mdi mdi-chevron-down ms-2 menu-chevron" data-target="#{{ $collapseId }}"></i>
                        @endif
                    </div>
                </div>
        
                @if($hasSub)
                    <ul class="ps-3 collapse" id="{{ $collapseId }}">
                        {!! renderMenu($item['submenu'], $level + 1) !!}
                    </ul>
                @endif
            </li>
            @php
                    endforeach;
                }
            @endphp
        
            <ul class="menu-list list-unstyled">
                {!! renderMenu($menu['menu']) !!}
            </ul>
        </div>

</div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
    /* Toastr */
    .toast { background-color: #39484f; }
    .toast-success { background-color: green; }
    .toast-error { background-color: red; }
    .main-menu { transition: background 0.3s; }
    .main-menu:hover { opacity: 0.9; }
    .submenu-level { transition: background 0.3s; }
    .submenu-level:hover { opacity: 0.9; }
    
    /* Toggle */
    .toggle-wrapper { position: relative; width: 170px; height: 35px; display:inline-block; }
    .maintenance-toggle { opacity:0; width:100%; height:100%; position:absolute; top:0; left:0; z-index:11; cursor:pointer; }
    .slider { position:absolute; cursor:pointer; top:0; left:0; right:0; bottom:0; background-color:#ef4444; border-radius:35px; display:flex; align-items:center; justify-content:space-between; padding:0 12px; color:white; font-weight:bold; font-size:13px; user-select:none; transition:0.4s; z-index:9; }
    .slider .label-on { opacity:0; width:58%; text-align:center; transition:opacity 0.4s; }
    .slider .label-off { opacity:1; width:58%; text-align:center; transition:opacity 0.4s; }
    .slider::before { content:''; position:absolute; width:27px; height:27px; border-radius:50%; background:white; top:4px; left:4px; transition:0.4s; z-index:2; box-shadow:0 2px 4px rgba(0,0,0,0.2); }
    .maintenance-toggle:checked + .slider { background-color:#4ade80; }
    .maintenance-toggle:checked + .slider .label-on { opacity:1; }
    .maintenance-toggle:checked + .slider .label-off { opacity:0; }
    .maintenance-toggle:checked + .slider::before { transform: translateX(135px); }

/* Chevron rotation */
.menu-chevron { transition: transform 0.3s ease; }
.menu-chevron.rotated { transform: rotate(180deg); }

</style>

<script>
$(document).on('change', '.maintenance-toggle', function(e) {
    e.stopPropagation(); // Prevent collapse toggle

    let slug = $(this).data('slug');
    let status = $(this).is(':checked') ? 0 : 1; // Maintenance = 1
    let $toggle = $(this);
    let $menuItem = $toggle.closest('.menu-item-header');
    let $date = $menuItem.find('.maintenance-date');

    $.ajax({
        url: "{{ route('maintenance.toggle') }}",
        method: "POST",
        data: { _token: "{{ csrf_token() }}", slug, status },
        success: function(res) {
            if(res.success) {
                toastr.success(res.message);

                // Always update text
                 if(status === 1 && res.maintenance_date){
                    let dt = new Date(res.maintenance_date);
                    let options = { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false };
                    let formatted = dt.toLocaleString('en-US', options).replace(',', '');
                   $date.html(`<span style="color:#ef4444;">Since: ${formatted}</span>`);
                } else {
                   $date.html(` <span class="align-middle" style="display:inline-flex; align-items:center;">
                                        <span style="font-size:1.2rem; font-weight:bold; margin-right:4px; line-height:1;">&middot;</span>
                                        Live
                                      </span>`);
                }
            } else {
                toastr.error(res.message);
                $toggle.prop('checked', !status);
            }
        },
        error: function() {
            toastr.error('Something went wrong!');
            $toggle.prop('checked', !status);
        }
    });
});

</script>






       

 
 



<script>
    $(".list_page").DataTable({
        "ordering": false,
         "pageLength":25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });

</script>
@endsection
