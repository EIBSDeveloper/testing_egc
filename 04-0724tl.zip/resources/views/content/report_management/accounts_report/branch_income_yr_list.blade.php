@extends('layouts/layoutMaster')

@section('title', 'Branch Income '.$report_heading.' - Yearly')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('content')

<style>
    .table-scroll-wrapper {
        position: relative;
        width: 100%;
    }

    .top-scrollbar {
        overflow-x: auto;
        overflow-y: hidden;
        height: 16px; /* top scrollbar height */
    }

    .top-scrollbar div {
        height: 1px;
    }

    .table-container {
        overflow-x: auto;
        overflow-y: auto;
        max-height: calc(99vh - 100px);
        /* width: 100%; */
    }

 /* Base table */
    .sticky_table { 
        border-collapse: collapse; 
        border: 1px solid #222222ff;  
        width: 100%; /* ensures horizontal scroll works */
    }

    /* Sticky header (all th) */
    .sticky_table thead th {
        position: sticky;
        top: 0;
        background: #00246b !important;
        color: #fff;
        text-align: center;
        vertical-align: middle;
        z-index: 50; /* default header z-index */
        border-right: 1px solid #ffffff;
    }
    
    /* Table cells */
    .sticky_table th, 
    .sticky_table td { 
        padding: 0;                
        text-align: center;
        vertical-align: middle;
        width: 100px;               
        height: 100px;             
        min-width: 80px;           
        max-width: 80px;
        min-height: 80px;           
        max-height: 80px;
        overflow: hidden;
        white-space: nowrap;
        border: 1px solid #222222ff;  
    }


    .sticky_table th.sticky-col-left {
        position: sticky;
        left: 0;
        color: #fff;
        background: #00246b !important;
        z-index: 60;
        border-right: 1px solid #ffff;
    }

    .sticky_table td.sticky-col-left {
        position: sticky;
        left: 0;
        color: #000;
        background-color: #fff;
        z-index: 15;
        border-right: 1px solid #222222ff;
    }


    .sticky_table td.sticky-col-second {
        position: sticky;
        left: 150px;     
        background: #fff; 
        color: #000;
        z-index: 10;      
        border-right: 1px solid #222222ff;
    }


    .sticky_table th.sticky-col-second {
        position: sticky;
        left: 150px;
        background: #00246b !important;
        color: #fff;
        z-index: 60;      
        border-right: 1px solid #ffff;
    }

    .sticky_table .current-month-row {
        background: #f3f9b8 !important;
        color: #000;
    }

    .current-month-row label {
        color: black !important;
    }

    .year-vertical {
        writing-mode: vertical-rl;   /* rotates text vertically */
        transform: rotate(180deg);   /* makes it read top-to-bottom */
        white-space: nowrap;         /* avoid breaking year digits */
        vertical-align: middle;      /* keep it centered */
        text-align: center;
    }

    .chart-nav-item button {
        border: 2px solid #099dda !important;
    }

    .incre_value {
        background-color: #28a745 !important;
    }
    .decre_value {
        background-color: #dc3545 !important;
    }
    .main_value {
        background-color: #3dc5e1 !important;
    }
    .nutral_value {
        background-color: #fff !important;
    }
    .current_day_value {
        background-color: #c395ff !important;
    }

    .search {
      position: relative;
      background: #ffffff;
      border-radius: 40px;
      padding: 5px 10px;
      display: flex;
      align-items: center;
      width: 350px;
    }

    /* Buttons */
    .search-btn, .reset-btn {
      color: #ffffff;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: #099dda;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-left: 10px;
      cursor: pointer;
      transition: background 0.3s;
      flex-shrink: 0;
    }

    .search span.select2-selection.select2-selection--multiple {
        border: none !important;
        border-radius: 8px 0px 0px 12px;
        width: 232px;
    }

    .search-btn:hover, .reset-btn:hover{
        color : #fff;
    }
</style>

<style id="my-style-id"></style>

<style>
    /* Sticky header (all th) */
    .sticky_table tfoot tr {
        position: sticky;
        bottom: 0;
        background: #00246b !important;
        color: #000;
        text-align: center;
        vertical-align: middle;
        z-index: 50; /* default header z-index */
    }

    .sticky_table tfoot td.sticky-col-left {
        position: sticky;
        left: 0;
        bottom:0;
        color: #000;
        background: #00246b !important;
        z-index: 15;
        border-right: 1px solid #ffff;
    }

    .sticky_table tfoot td.sticky-col-second {
        position: sticky;
        left: 150px;
        bottom: 0;
        background: #00246b !important;
        color: #000;
        z-index: 10;      
        border-right: 1px solid #ffff;
    }

    td.sticky-col-left_2 {
        position: sticky;
        color: #000;
        z-index: 15;
        border-right: 0px solid #222222ff;
        left: 50%;
        max-width: -webkit-fill-available;
    }
</style>

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1 d-flex align-items-center justify-content-between gap-2">
        <div>
            <h5 class="card-title mb-1">Branch Income {{ $report_heading }} - Yearly</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Business {{ $report_heading }}</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="{{ url('/manage_reports/branch_income_yearly') }}" class="d-flex align-items-center">Accounts {{ $report_heading }}</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="{{ url('/manage_reports/branch_income_yearly') }}" class="d-flex align-items-center">Branch Income</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/branch_income_yearly') }}"type="button" class="nav-link text-capitalize active">Yearly</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/branch_income_monthly') }}" type="button" class="nav-link text-capitalize">Monthly</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="card-body">
        @php
            use Carbon\Carbon;
            $monthNumber = date('m'); // August
            $year = date('Y');
            $CurrentMonth = str_pad($monthNumber,2,'0',STR_PAD_LEFT); // "08" or use: date('M', strtotime("2025-$monthNumber-01")) for "Aug"
            $CurrentMonthName = date('M');
            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $monthNumber, $year);
        @endphp
        <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-6" style="flex-wrap: wrap;">
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/branch_income_yearly') }}" type="button" class="nav-link text-capitalize active">Branch Income</a>
                    </li>
                    <!-- <li class="nav-item">
                        <a href="{{ url('/manage_reports/franchise_income_yearly') }}" type="button" class="nav-link text-capitalize">Franchise Income</a>
                    </li> -->
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/incomevsexp_yr_list') }}" type="button" class="nav-link text-capitalize">Income Vs Expenditure</a>
                    </li>
                </ul>
            </div>

            <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-2" style="margin-left: auto;">
                <div class="border border-primary search">
                    <input type="hidden" class="form-control" placeholder="Enter Branch Position Name" id="lead_src_name_year">
                    <!-- <input type="hidden" class="form-control" placeholder="Enter Branch Position Name" id="lead_src_name_month"> -->
                    <!-- <input type="hidden" id="is_existing_val" value="2"> -->
                    <div style="width:100%">
                        <select class="select3 form-select" id="lead_src_name" data-placeholder="Select Branch" multiple >
                        </select>
                    </div>
                    <a class="search-btn" onclick="get_lead_details_table()" href="javascript:;" title="Reset selection">
                        <span class="mdi mdi-magnify fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Search"></span>
                    </a>
                    <a class="reset-btn" onclick="reset_options()" href="javascript:;" itle="Search">
                        <span class="mdi mdi-refresh fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reset"></span>
                    </a>
                </div>
            </div>

            <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-2 flex-option">
                <ul class="nav nav-pills justify-content-end" role="tablist">
                    <li class="nav-item me-1">
                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary py-2" data-bs-toggle="modal" data-bs-target="#kt_modal_month_lead" id="graph_div" style="display:none !important;">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Graph"><i class="mdi mdi-finance fs-3"></i></span>
                        </a>
                    </li>
                    <!-- Previous Month Button -->
                    <li class="nav-item me-1">
                        <a class="nav-link px-3"
                            href="javascript:;" id="prevMonthBtn">
                            <div class="text-center">
                            <span class="mdi mdi-arrow-left-circle-outline  fs-2"></span>
                            </div>
                        </a>
                    </li>

                    <!-- Current Month Button (Active) -->
                    <li class="nav-item me-1">
                        <a class="nav-link active px-3 border border-dashed border-primary waves-effect waves-light"
                            href="javascript:;">
                            <div class="text-center">
                                <span class="fs-4 fw-semibold text-capitalize" id="selectedYear">{{$year}}</span>
                            </div>
                        </a>
                    </li>
                    <!-- Next Month Button -->
                    <li class="nav-item me-1">
                        <a class="nav-link px-3"
                            href="javascript:;" id="nextMonthBtn">
                            <div class="text-center">
                            <span class="mdi mdi-arrow-right-circle-outline  fs-2"></span>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row mb-2">

            <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-6" style="flex-wrap: wrap;">
                <div class="col-lg-10 mx-3 mb-2 d-flex align-items-center justify-content-start gap-2 p-3 mb-6 border rounded border-primary py-3" style="flex-flow: wrap;max-width: fit-content;">
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #f3f9b8"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Current Month</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #c395ff"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Current Month Value</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #28a745"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Increased Value</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #dc3545"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Decreased Value</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #3dc5e1"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Maintained Value</label>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="table-scroll-wrapper">
                    <!-- Top Scrollbar -->
                    <div class="top-scrollbar mb-1">
                        <div></div>
                    </div>
                    <div class="table-container">
                        <table class="table align-middle table-row-dashed table-striped table-hover sticky_table" id="Monthly_lead_table">
                            <thead>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7">
                            </tbody>
                            <tfoot class="text-black fw-semibold fs-3" id="Yearly_lead_footer"></tfoot>
                        </table>
                    </div>
                    <div class="bottom-scrollbar mt-3">
                        <div></div>
                    </div>
                </div>
                <!-- <div class="d-flex justify-content-between align-items-center mt-6">
                    <div id="paginationInfo"></div>
                    <div id="paginationControls"></div>
                </div> -->
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Total Leads Vs Month-->
<div class="modal fade" id="kt_modal_month_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="modal-body px-2 py-2 position-relative">
                <button type="button"
                        class="btn btn-sm btn-icon rounded-pill btn-white position-absolute modal_close"
                        style="top: 2px; right: 2px; z-index: 10;"
                        data-bs-dismiss="modal" aria-label="Close" onclick="close_function()">
                    <span class="svg-icon svg-icon-1">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                            transform="rotate(-45 6 17.3137)" fill="currentColor" />
                        <rect x="7.41422" y="6" width="16" height="2" rx="1"
                            transform="rotate(45 7.41422 6)" fill="currentColor" />
                    </svg>
                    </span>
                </button>
                <div class="rounded-4 border-1 px-5 pt-5">
                    <!--begin::Heading-->
                    <div class="mb-4">
                        <h3 class=" mb-4 text-black text-center">Branch Income - Yearly (<span id="modal_lead_pie_name">{{ date('Y') }}</span>)</h3>
                    </div>

                    <div class="row">
                        <div id="lead_source_pie_chart_div" style="display:block;">
                            <div class="col-lg-12 mb-2">
                                <!-- Leads Pie Chart -->
                                <!-- <div id="lead_source_pie_chart" style="max-width:500px;margin:auto;"></div> -->
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-pie"></i> Branch Income Distribution on <span id="modal_lead_source_pie_name">{{ date('Y') }}</span></h1>
                                    <div id="lead_source_pie_chart-wrapper"></div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-2">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Monthly Branch Income Distribution <span id="modal_lead_source_area_name"></span></h1>
                                    <div id="lead_source_area_chart-wrapper"><div id="lead_source_area_chart"></div></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-end mt-6 mb-4">
                        <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal" onclick="close_function()">Close</a>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Total Leads Vs Month-->

<script>

    var months = @json($months);

    var short_months = @json($short_months);
    var cond_months = [];

    var full_months = {
        1: 'January',
        2: 'February',
        3: 'March',
        4: 'April',
        5: 'May',
        6: 'June',
        7: 'July',
        8: 'August',
        9: 'September',
        10: 'October',
        11: 'November',
        12: 'December'
    };

    var days = null;
    var Month = null;
    var dayLabels = null;
    var leadTypes = null;
    var leadTypesPie = [];
    var leadTypes_keys = [];
    var leadsData = null;
    var preleadsData = null;
    var percentages = null;
    var sourceTotals = null;
    var dayTotals = null;
    var grandTotalAll = null;
    var dayNames = null;
    var sourceTrends = null;
    var year = null;
    var yearShort = null;
    var line_MonthColors = null;
    var pie_MonthColors = null;

    let comparison_area_lead = [];

    var monthlyCustomerTotals = null;
    
    const now = new Date();
    let currentYear = now.getFullYear();
    let currentMonth = now.getMonth() + 1; // getMonth() returns 0–11
    let currentDate = now.getDate();

    // Initial selection defaults to current date
    let selectedYear = currentYear;
    let selectedMonth = currentMonth;

    // Empty Line Chart for trend
    var chartMonthCustomers = new ApexCharts(document.querySelector("#lead_source_area_chart"), {
        chart: { type:'area', height:350 },
        series: [],
        dataLabels: { 
            enabled: true,
            formatter: function (val) {
                return new Intl.NumberFormat('en-IN', {
                    style: 'currency',
                    currency: 'INR',
                    minimumFractionDigits: 0,  // change to 2 if you want decimals
                    maximumFractionDigits: 0
                }).format(val);
            }
        },
        xaxis: {
            categories: [],
            title: {
                text: '', // 🔹 X-axis heading
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333'
                }
            }
        },
        yaxis: {
            title: {
                text: 'Total Branch Income', // 🔹 Y-axis heading
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333'
                }
            },
            labels: {
                formatter: function (val) {
                    return new Intl.NumberFormat('en-IN', {
                        style: 'currency',
                        currency: 'INR',
                        minimumFractionDigits: 0,  // change to 2 if you want decimals
                        maximumFractionDigits: 0
                    }).format(val);
                }
            }
        },
        title: { text:'' },
        stroke: { curve:'smooth' },
        tooltip: {
            shared: true,
            intersect: false,
            x: {
                formatter: function (value) {
                    return full_months[value] || 'Unknown Month'; // fallback if not found
                }
            },
            y: {
                formatter: function (val) {
                    return new Intl.NumberFormat('en-IN', {
                        style: 'currency',
                        currency: 'INR',
                        minimumFractionDigits: 0,  // change to 2 if you want decimals
                        maximumFractionDigits: 0
                    }).format(val);
                }
            }
        },
        legend: {
            position: 'bottom', // Must match the class you're targeting
            horizontalAlign: 'center',
            verticalAlign: 'center' // optionally, to help vertical placement
        }
    });
    chartMonthCustomers.render();

    $(document).ready(function () {

        document.getElementById("prevMonthBtn").addEventListener("click", function (e) {
            e.preventDefault();
            currentYear--;
            selectedYear = currentYear;
            // selectedMonth = currentMonth;

            updateMonthDisplay(selectedYear);
            hide_year_arrow(selectedYear);
        });

        document.getElementById("nextMonthBtn").addEventListener("click", function (e) {
            e.preventDefault();
            currentYear++;
            selectedYear = currentYear;
            // selectedMonth = currentMonth;

            updateMonthDisplay(selectedYear);
            hide_year_arrow(selectedYear);
        });

        updateMonthDisplay(selectedYear);
        hide_year_arrow(selectedYear);
    });

    function formatCurrency(number, decimals = 2) {
        const formattedNumber = new Intl.NumberFormat('en-IN', {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        }).format(number);
        return formattedNumber;
    }

    function reset_options() {
        const reset_src_select = document.getElementById('lead_src_name');
        const reset_src_selectedValues = Array.from([]).map(option => option.value);
        var selectCatDropdown = $(`#lead_src_name`);
        selectCatDropdown.val(reset_src_selectedValues).trigger('change');
        get_lead_details_table()
    }

    function updateMonthDisplay(selectedYear) {

        document.getElementById("lead_src_name_year").value = selectedYear;
        // document.getElementById("lead_src_name_month").value = selectMonth;
        const src_select = document.getElementById('lead_src_name');
        const src_selectedValues = Array.from(src_select.selectedOptions).map(option => option.value);
        // Fix month index for months array (0-based)
        // short_month_name = Shortmonths[selectMonth] ?? '<?= date('M') ?>';
        // month_name = months[selectMonth] ?? '<?= date('F') ?>';
        document.getElementById("selectedYear").textContent = `${selectedYear}`;
        document.getElementById("modal_lead_pie_name").textContent = `${selectedYear}`;
        document.getElementById("modal_lead_source_pie_name").textContent = `${selectedYear}`;
        // document.getElementById("modal_lead_source_area_name").textContent = month_name;

        // var checked_cond = $('#is_existing_val').val();
        // var checked_val_cond = (parseInt(checked_cond) === 1) ? true : false;
        get_lead_src_list();
    }

    function get_lead_src_list() {

        const src_select = document.getElementById('lead_src_name');
        const src_selectedValues = Array.from(src_select.selectedOptions).map(option => option.value);
        var selectCatDropdown = $(`#lead_src_name`);

        // var checked_val = checked ? 1 : 2;
        // $('#is_existing_val').val(checked_val);

        $.ajax({

            url: "{{ route('get_branch_list_data') }}",
            type: "POST",
            data: {
                branch_type : 1,
                _token: '{{ csrf_token() }}',
            },
            success: function(response) {
                if (response.status === 200 && response.data) {
                    selectCatDropdown.empty();
                    response.data.forEach(function(role) {
                        selectCatDropdown.append(
                            $('<option></option>').attr('value', role.sno).text(role.branch_name)
                        );
                    });

                    // Now that options are added, set the selected values and trigger change
                    selectCatDropdown.val(src_selectedValues).trigger('change');
                } else {
                    console.error('Unexpected response format or status:', response);
                }
            },
            error: function(error) {
                console.error('Error fetching Branch Income list:', error);
            }
        });

        get_lead_details_table();
    }

    function hide_year_arrow(selectedYear) {
        const systemMonth = now.getMonth() + 1;
        const systemYear = now.getFullYear();

        if (parseInt(selectedYear) === systemYear) {
            document.getElementById("nextMonthBtn").style.display = "none";
        } else {
            document.getElementById("nextMonthBtn").style.display = "inline-block";
        }
    }

    function get_lead_details_table() {

        selectedYear = $('#lead_src_name_year').val().trim();
        // selectMonth = $('#lead_src_name_month').val().trim();
        lead_src_name = $('#lead_src_name').val();
        // const is_existing_val = $('#is_existing_val').val();

        $.ajax({
            url: '{{ route("branch_income_yearly_data") }}',
            method: 'POST',
            dataType: 'json',
            data: {
                year: selectedYear,
                // month: selectMonth,
                search_lead_src_fill: lead_src_name ?? '',
                // is_existing_val: parseInt(is_existing_val) ?? 2,
                _token: '{{ csrf_token() }}'
            },
            beforeSend: function () {
                Swal.fire({
                    title: 'Processing...',
                    text: 'Please wait while we load the data.',
                    showConfirmButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    customClass: {
                        confirmButton: 'd-none btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false,
                    didOpen: () => {
                        Swal.showLoading();
                        document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
                    }
                });
                $('#Monthly_lead_table thead').html('');
                $('#Yearly_lead_footer').empty();
                $('#Monthly_lead_table tbody').html(`
                    <tr><td colspan="100%" class="text-center">Loading...</td></tr>
                `);
            },
            success: function (data) {
                try {

                    if (!data || typeof data !== 'object') {
                        throw new Error('Invalid response format');
                    }

                    days = Array.isArray(data.days) ? data.days : Object.values(data.days || {});
                    dayLabels = data.dayLabels && typeof data.dayLabels === 'object' ? data.dayLabels : null;
                    months = data.months && typeof data.months === 'object' ? data.months : null;
                    short_months = data.short_months && typeof data.short_months === 'object' ? data.short_months : null;
                    cond_months = Array.isArray(short_months) ? short_months : Object.values(short_months || {});
                    leadTypes = data.leadTypes && typeof data.leadTypes === 'object' ? data.leadTypes : null;
                    leadsData = data.leadData && typeof data.leadData === 'object' ? data.leadData : null;
                    preleadsData = data.preleadData && typeof data.preleadData === 'object' ? data.preleadData : null;
                    percentages = data.percentages && typeof data.percentages === 'object' ? data.percentages : null;
                    sourceTotals = data.sourceTotals && typeof data.sourceTotals === 'object' ? data.sourceTotals : null;
                    dayTotals = data.dayTotals && typeof data.dayTotals === 'object' ? data.dayTotals : null;
                    grandTotalAll = data.grandTotalAll ? data.grandTotalAll : 0;
                    Month = data.Month ? parseInt(data.Month) : currentMonth;
                    dayNames = data.dayNames && typeof data.dayNames === 'object' ? data.dayNames : null;
                    sourceTrends = data.sourceTrends && typeof data.sourceTrends === 'object' ? data.sourceTrends : null;
                    year = data.year ? parseInt(data.year) : currentYear;
                    yearShort = data.yearShort ? parseInt(data.yearShort) : parseInt(<?= date('y') ?>);
                    line_MonthColors = Array.isArray(data.line_MonthColors) ? data.line_MonthColors : Object.values(data.line_MonthColors || {});
                    leadTypes_keys = Array.isArray(data.leadTypes_keys) ? data.leadTypes_keys : Object.values(data.leadTypes_keys || {});
                    pie_MonthColors = Array.isArray(data.pie_MonthColors) ? data.pie_MonthColors : Object.values(data.pie_MonthColors || {});

                    leadTypesPie = Array.isArray(leadTypes) ? leadTypes : Object.values(leadTypes || {});

                    monthlyCustomerTotals = leadTypes_keys.map(src => sourceTotals[src] || 0)

                    if (!months || !year || !leadTypes || !leadsData) {
                        throw new Error('Required data missing');
                    }

                    buildTableHeader(months, Month, year);
                    buildLeadsTable(leadTypes, leadsData, months, Month, year, preleadsData);
                    create_pie_chart_lead();
                    updateTrendChart();
                    comparison_area_lead = [];
                } catch (ex) {
                    console.error('Data validation error:', ex);
                    showNoDataRow(selectedYear);
                } finally {
                    Swal.close();
                }
            },
            error: function (xhr, status, error) {

                Swal.close();
                let message = 'Failed to load data. Please try again later.';
                if(xhr.status === 0){
                    message = 'Network error: Please check your internet connection.';
                } else if(xhr.status >= 500){
                    message = 'Server error occurred. Please try again later.';
                } else if(xhr.status === 422){
                    message = 'Validation error: Please check your input.';
                } else if(xhr.responseJSON && xhr.responseJSON.message){
                    message = xhr.responseJSON.message;
                }

                console.error('Error loading data:', xhr.responseText);

                showNoDataRow(selectedYear);

                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: message,
                    showConfirmButton: true,
                    confirmButtonText: 'Close',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light btn-md'
                    },
                    buttonsStyling: false
                });
            }
        });
    }

    function buildTableHeader(th_days, th_currentMonth, th_year) {

        var $thead = $('#Monthly_lead_table thead');
        $thead.empty();

        var th_daysInMonth = new Date(th_year, th_currentMonth, 0).getDate();

        let headerRow = `
        <tr class="bg-primary text-center fw-bold fs-6">
            <th class="min-w-200px sticky-col-left fs-5 text-wrap">Branch</th>`;
        
             $.each(th_days, function (monthNumber, monthName) {
                // if (th_d <= th_daysInMonth) {
                    var row_class = (parseInt(th_year) === now.getFullYear() && parseInt(monthNumber) === now.getMonth() + 1) ? 'current-month-row' : '';
                    // var dayFormatted = String(th_d).padStart(2, '0');
                    // var dateObj = new Date(`${th_year}-${String(th_currentMonth).padStart(2, '0')}-${dayFormatted}`);
                    // var dayName = dateObj.toLocaleDateString('en-US', { weekday: 'short' });

                    headerRow += `
                        <th class="min-w-150px fs-5 text-center ${row_class}">
                            <label class="text-white fw-bold">${short_months[monthNumber]}</label>
                        </th>`;
                // }
            });

        headerRow += `</tr>`;
        $thead.append(headerRow);
    }

    function buildLeadsTable(td_leadTypes, td_leadsData, td_days, td_currentMonth, td_year,td_preleadsData) {

        var $tbody = $('#Monthly_lead_table tbody');
        $tbody.empty();

        let td_hasNonZeroData = false;
        // var td_daysInMonth = new Date(td_year, td_currentMonth, 0).getDate();
        
        // var td_index = 1;

        // var $table_footer = $('#Yearly_lead_footer');
        // $table_footer.empty();
        
        // let leadsFooterRow = `<tr>`;
        // leadsFooterRow += `<td class="sticky-col-left fs-5">
        //     <div class="fs-5 fw-semibold text-white">Total</div>
        //     <div class="d-block mb-2 mt-2">
        //         <span class="bg-info text-white fs-4 py-2 px-2 rounded" id="day_wise_grand_count_lead">00</span>
        //     </div>
        // </td>`;
        
        var grand_day_wise_count_lead = 0;

        td_leadTypes.forEach((td_leadType,td_index) => {
            
            var td_leadType_id = leadTypes_keys[td_index];

            let td_leadsRow = `<tr>`;
            
            td_leadsRow += `<td class="sticky-col-left fs-5 hover_tr_class_${td_index}">
                <label class="fw-semibold fs-5 text-wrap mt-2">${td_leadType}</label>
                <div class="d-block mt-2 mb-4">
                    <span class="bg-info text-white fs-4 py-2 px-2 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Income">₹${ formatCurrency(sourceTotals?.[td_leadType_id] ?? 0,0) }</span>
                </div>
            </td>`;
            
            let td_prevLeads = null;
            
            var td_prevYear = parseInt(td_year) - 1;
            // var td_predaysInMonth = new Date(td_year, td_currentMonth, 0).getDate();
            
            var day_wise_count_lead = 0;
            
            $.each(td_days, function (monthNumber, monthName) {
                
                var td_prevMonth = parseInt(monthNumber) - 1;

                // if (td_d <= td_daysInMonth) {

                    const td_dayData = td_leadsData?.[monthNumber]?.[td_leadType_id] || 0;
                    var td_dropPercentData = parseInt(percentages?.[monthNumber]?.[td_leadType_id]) ?? 0;

                    // Check for non-zero data
                    if (td_dayData > 0) {
                        td_hasNonZeroData = true;
                    }

                    const r_systemMonth = now.getMonth() + 1;
                    const r_systemYear = now.getFullYear();
                    var isCurrentYear = (parseInt(monthNumber) === r_systemMonth && parseInt(td_year) === r_systemYear);

                    if (parseInt(monthNumber) === 1) {
                        if (td_preleadsData) {
                            // td_prevYear = parseInt(td_year) - 1;
                            td_prevMonth = 12;
                            // td_predaysInMonth = new Date(td_prevYear, td_prevMonth, 0).getDate();
                            td_prevLeads = td_preleadsData?.[td_prevMonth]?.[td_leadType_id] || 0;
                        }
                    }else if(parseInt(monthNumber) !== 1){
                        if (td_preleadsData) {
                            // td_prevYear = parseInt(td_year);
                            td_prevMonth = parseInt(monthNumber) - 1;
                            // td_predaysInMonth = new Date(td_prevYear, td_prevMonth, 0).getDate();
                            td_prevLeads = td_preleadsData?.[td_prevMonth]?.[td_leadType_id] || 0;
                        }
                    }

                    // --- Leads color logic ---
                    let leadsBadgeColor = 'nutral_value'; // green default
                    // const td_day = parseInt(td_d, 10);
                    var lead_enable_data = true;
                    if (isCurrentYear) {
                        if (parseInt(r_systemMonth) === parseInt(monthNumber)) {
                            leadsBadgeColor = 'current_day_value'; // currentDate
                            lead_enable_data = true;
                        } else if (parseInt(r_systemMonth) < parseInt(monthNumber)) {
                            leadsBadgeColor = 'nutral_value'; // future
                            lead_enable_data = false;
                        } else if (td_prevLeads !== null) {
                            if (td_dayData > td_prevLeads) leadsBadgeColor = 'incre_value'; // up
                            else if (td_dayData < td_prevLeads) leadsBadgeColor = 'decre_value'; // down
                            else leadsBadgeColor = 'main_value'; // same
                            lead_enable_data = true;
                        }
                    } else if (td_prevLeads !== null) {
                        if (td_dayData > td_prevLeads) leadsBadgeColor = 'incre_value';
                        else if (td_dayData < td_prevLeads) leadsBadgeColor = 'decre_value';
                        else leadsBadgeColor = 'main_value';
                        lead_enable_data = true;
                    }

                    td_leadsRow += `<td class="${ lead_enable_data ? 'hover_day_class_'+td_index+'_'+monthNumber+' ' : ''}text-center ${leadsBadgeColor}">
                        <label class="fw-semibold fs-3 text-black">${lead_enable_data ? '₹'+formatCurrency(td_dayData, 0) : ''}</label>
                    </td>`;

                    td_prevLeads = td_dayData;
                    day_wise_count_lead += parseInt(td_dayData ?? 0);

                // } else {
                //     td_leadsRow += `<td class="text-center">-</td>`;
                // }

            });
            
            td_leadsRow += `</tr>`;

            $tbody.append(td_leadsRow);
            // get_pagination(pagination_data,true);

            grand_day_wise_count_lead += sourceTotals?.[td_leadType_id] ?? 0;
            scroll_option();

            document.getElementById('graph_div').style.setProperty('display', 'block', 'important');
            // td_index++;
        });

        // $.each(td_days, function (monthNumber, monthName) {

        //     var foot_row_class = (parseInt(td_year) === now.getFullYear() && parseInt(monthNumber) === now.getMonth() + 1) ? ' current-month-row' : '';

        //     leadsFooterRow += `<td class="text-center${foot_row_class}">
        //         <label class="fw-semibold fs-3 text-white">₹${ formatCurrency(dayTotals?.[monthNumber] ?? 0,0) } </label>
        //     </td>`;
        // });

        // leadsFooterRow += `</tr>`;
        
        // $table_footer.append(leadsFooterRow);
        
        // $(`#day_wise_grand_count_lead`).text('₹'+formatCurrency(grand_day_wise_count_lead ?? 0,0));

        
        hover_classes(td_leadTypes,td_days);
        
        $('[data-bs-toggle="tooltip"]').tooltip({ 'animation' : false });

        if (!td_hasNonZeroData) {
            showNoDataRow(td_year)
            document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
        }
    }

    function showNoDataRow(year) {
        $('#Monthly_lead_table tbody').html(`
            <tr>
                <td colspan="100%" class="text-left text-muted fw-semibold py-4 fs-4 px-6" style="text-align: left;">
                    No Branch Income data found for ${year}.
                </td>
            </tr>
        `);
        $('#Yearly_lead_footer').empty();
        // get_pagination(null,false);
        document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
    }

    function create_pie_chart_lead(){
    
        const dataSeries = monthlyCustomerTotals ? monthlyCustomerTotals?.map(val => val ?? 0) ?? [] : [];
        const $wrapper = $('#lead_source_pie_chart-wrapper');
        
        // If no data or all 0s, show message
        const allZeros = dataSeries.every(val => val === 0);
            
        if (!dataSeries || dataSeries.length === 0 || allZeros) {
            $wrapper.html(`
            <div class="no-data-message fs-6" style="min-height: auto;align-content: space-evenly;">
            No data found
                </div>
                `);
            return;
        }
        
        // Clear wrapper and add chart container
        $wrapper.html('<div id="lead_source_pie_chart"></div>');
        
        var clickedIndex = null;

        var chartLeads = new ApexCharts(document.querySelector("#lead_source_pie_chart"), {
            series: dataSeries,
            chart: { type:'pie', height:350,
                events: {
                    dataPointSelection: function(event, chartContext, config){
                        var clickedIndex = config.dataPointIndex;
                        var source_id = leadTypes_keys[clickedIndex] ?? 'None';
                        var source_name = leadTypes[clickedIndex] ?? 'None';
                        if (comparison_area_lead[clickedIndex]) {
                            delete comparison_area_lead[clickedIndex];
                        } else {
                            var trendData = sourceTrends[source_id] ?? [];
                            var line_color = line_MonthColors[clickedIndex] ?? '#1e90ff';
                            comparison_area_lead[clickedIndex] = {
                                name: source_name,
                                data: trendData,
                                color: line_color
                            };
                        }
                        var seriesArray = Object.values(comparison_area_lead);
                        updateTrendChart(seriesArray);
                    }
                }
            },
            labels: leadTypesPie ?? [],
            colors: pie_MonthColors,
            title: { text: '' },
            legend: {
                position: 'bottom',
                fontSize: '14px',
                labels: {
                    colors: 'black'
                },
                markers: {
                    width: 14,
                    height: 14,
                    radius: 3
                }
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return new Intl.NumberFormat('en-IN', {
                            style: 'currency',
                            currency: 'INR',
                            minimumFractionDigits: 0,  // change to 2 if you want decimals
                            maximumFractionDigits: 0
                        }).format(val);
                    },
                    title: {
                        formatter: function (seriesName) {
                            return seriesName + " :";
                        }
                    }
                }
            },
            dataLabels: { enabled:true, formatter: function(val, opts){ return Math.round(opts.w.globals.seriesPercent[opts.seriesIndex]) + ' %'; } }
        });
        chartLeads.render();
    }

    function updateTrendChart(seriesData = null) {
        if(seriesData !== null){
            chartMonthCustomers.updateSeries(seriesData);
            chartMonthCustomers.updateOptions({
                xaxis: { categories: cond_months }
            });
        }else{
            chartMonthCustomers.updateSeries([]);
            chartMonthCustomers.updateOptions({
                xaxis: { categories: [] }
            });
        }
    }

    function close_function(){
        updateTrendChart();
        comparison_area_lead = [];
    }

    function scroll_option() {
        
        const topScrollbar = document.querySelector(".top-scrollbar");
        const bottomScrollbar = document.querySelector(".bottom-scrollbar");
        const topScroller = topScrollbar.querySelector("div");
        const bottomScroller = bottomScrollbar.querySelector("div");

        const tableContainer = document.querySelector(".table-container");

        // Match widths
        topScroller.style.width = tableContainer.scrollWidth + "px";

        // Sync scrolls
        topScrollbar.addEventListener("scroll", function () {
            tableContainer.scrollLeft = topScrollbar.scrollLeft;
        });
        tableContainer.addEventListener("scroll", function () {
            topScrollbar.scrollLeft = tableContainer.scrollLeft;
        });

        bottomScroller.style.width = tableContainer.scrollWidth + "px";

        // Sync scrolls
        bottomScrollbar.addEventListener("scroll", function () {
            tableContainer.scrollLeft = bottomScrollbar.scrollLeft;
        });
        tableContainer.addEventListener("scroll", function () {
            bottomScrollbar.scrollLeft = tableContainer.scrollLeft;
        });
    }

    function hover_classes(e_months = null, e_days = null) {

        if (e_months !== null) {

            e_months.forEach((e_leadType,monthNumber) => {

                // Remove old listeners
                document.querySelectorAll(`.hover_tr_class_${monthNumber}`).forEach(el => {
                    el.replaceWith(el.cloneNode(true));
                });

                // ============================
                // 🔹 Month-wise Hover
                // ============================

                // // Hover on sub-row cell
                // document.querySelectorAll(`.hover_td_class_${monthNumber}`).forEach(td => {
                //     td.addEventListener("mouseenter", () => {
                //         highlight(td);

                //         // highlight month header
                //         let row = td.parentNode;
                //         while (row) {
                //             const rowspanCell = row.querySelector(`.hover_tr_class_${monthNumber}`);
                //             if (rowspanCell) {
                //                 highlight(rowspanCell);
                //                 break;
                //             }
                //             row = row.previousElementSibling;
                //         }

                //         // 🔸 NEW: expand related day cells (height animation)
                //         document.querySelectorAll(`[class^="hover_day_class_${monthNumber}_"]`).forEach(dayCell => {
                //             highlight(dayCell,2);
                //         });
                //     });

                //     td.addEventListener("mouseleave", () => {
                //         resetMonth(monthNumber);
                //     });
                // });

                // Hover on month header
                document.querySelectorAll(`.hover_tr_class_${monthNumber}`).forEach(td => {
                    td.addEventListener("mouseenter", () => {
                        highlight(td);

                        // highlight ALL sub-row cells
                        // let row = td.parentNode;
                        // while (row) {
                        //     const hoverCell = row.querySelector(`.hover_td_class_${monthNumber}`);
                        //     if (hoverCell) highlight(hoverCell);
                        //     row = row.nextElementSibling;
                        // }

                        // highlight all day cells
                        document.querySelectorAll(`[class^="hover_day_class_${monthNumber}_"]`).forEach(dayCell => {
                            highlight(dayCell,2);
                        });
                    });

                    td.addEventListener("mouseleave", () => {
                        resetMonth(monthNumber);
                    });
                });

                // ============================
                // 🔹 Day-wise Hover
                // ============================
                if (e_days !== null) {
                    $.each(e_days, function (day, day_name) {
                        document.querySelectorAll(`.hover_day_class_${monthNumber}_${day}`).forEach(td => {
                            td.addEventListener("mouseenter", () => {
                                // highlight the parent row's sub-cell
                                const row = td.closest("tr");
                                if (row) {
                                    // const rowCell = row.querySelector(`.hover_td_class_${monthNumber}`);
                                    // if (rowCell) highlight(rowCell);
                                }

                                // highlight the month header cell
                                let prevRow = td.parentNode;
                                while (prevRow) {
                                    const monthHeader = prevRow.querySelector(`.hover_tr_class_${monthNumber}`);
                                    if (monthHeader) {
                                        highlight(monthHeader);
                                        break;
                                    }
                                    prevRow = prevRow.previousElementSibling;
                                }
                            });

                            td.addEventListener("mouseleave", () => {
                                resetDay(monthNumber, day);
                            });
                        });
                    });
                }
            });
        }

        // Highlight style
        function highlight(cell, type = 1) {
            cell.style.backgroundColor = "#f0913d";
            cell.style.color = "#000";
            cell.style.transition = "background-color 0.3s ease-out, color 0.3s ease-out, transform 0.3s ease-out, box-shadow 0.3s ease-out, height 0.3s ease-out";
            cell.style.transform = "translateZ(5px) scale(1.02)";
            if(type === 2){
                cell.style.borderTop = "4px solid #000";
                cell.style.borderBottom = "4px solid #000";
                cell.style.boxShadow = "0 0 12px 3px #f0913d";
            }else{
                cell.style.border = "2px solid #ffffff";
            }
        }

        // Reset month highlights
        function resetMonth(monthNumber) {
            document.querySelectorAll(`.hover_tr_class_${monthNumber}, [class^="hover_day_class_${monthNumber}_"]`).forEach(cell => {
                resetCell(cell);
            });
        }

        // Reset day highlights
        function resetDay(monthNumber, day) {
            document.querySelectorAll(
                `.hover_day_class_${monthNumber}_${day}, .hover_tr_class_${monthNumber}`
            ).forEach(cell => {
                resetCell(cell);
            });
        }

        // Reset helper
        function resetCell(cell) {
            cell.style.backgroundColor = "";
            cell.style.color = "";
            cell.style.transform = "";
            cell.style.border = "";
            cell.style.borderTop = "";
            cell.style.borderBottom = "";
            cell.style.boxShadow = "";
            cell.style.height = ""; // reset to default
        }
    }

</script>

@endsection