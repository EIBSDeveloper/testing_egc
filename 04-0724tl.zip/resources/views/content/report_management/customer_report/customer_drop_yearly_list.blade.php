@extends('layouts/layoutMaster')

@section('title', 'Customer '.$report_heading.' - Yearly')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('content')

<style>
    .table-scroll-wrapper {
        position: relative;
        width: 100%;
    }

    .top-scrollbar {
        overflow-x: auto;
        overflow-y: hidden;
        height: 16px; /* top scrollbar height */
    }

    .top-scrollbar div {
        height: 1px;
    }

    .table-container {
        overflow-x: auto;
        overflow-y: auto;
        max-height: calc(99vh - 100px);
        /* width: 100%; */
    }

 /* Base table */
    .sticky_table { 
        border-collapse: collapse; 
        border: 1px solid #222222ff;  
        width: 100%; /* ensures horizontal scroll works */
    }

    /* Sticky header (all th) */
    .sticky_table thead th {
        position: sticky;
        top: 0;
        background: #00246b !important;
        color: #fff;
        text-align: center;
        vertical-align: middle;
        z-index: 50; /* default header z-index */
        border-right: 1px solid #ffffff;
    }
    
    /* Table cells */
    .sticky_table th, 
    .sticky_table td { 
        padding: 0;                
        text-align: center;
        vertical-align: middle;
        width: 100px;               
        height: 100px;             
        min-width: 80px;           
        max-width: 80px;
        min-height: 80px;           
        max-height: 80px;
        overflow: hidden;
        white-space: nowrap;
        border: 1px solid #222222ff;
    }


    .sticky_table th.sticky-col-left {
        position: sticky;
        left: 0;
        color: #fff;
        background: #00246b !important;
        z-index: 60;
        border-right: 1px solid #ffffff;
    }

    .sticky_table td.sticky-col-left {
        position: sticky;
        left: 0;
        color: #000;
        background-color: #fff;
        z-index: 15;
        border-right: 1px solid #222222ff;
    }


    .sticky_table td.sticky-col-second {
        position: sticky;
        left: 150px;     
        background: #fff; 
        color: #000;
        z-index: 10;      
        border-right: 1px solid #222222ff;
    }


    .sticky_table th.sticky-col-second {
        position: sticky;
        left: 150px;
        background: #00246b !important;
        color: #fff;
        z-index: 60;      
        border-right: 1px solid #ffffff;
    }

    /* .current-month-row td{
        background-color: #f3f9b8 !important;
        color: #000;
    }

    .current-month-row td.sticky-col-second {
        background-color: #f3f9b8 !important;
    }

    .sticky_table tr.current-month-row td.sticky-col-second {
        background-color: #f3f9b8 !important;
    } */

    .current-month-row td.sticky-col-left{
        background-color: #f3f9b8 !important;
        color: #000;
    }

    .year-vertical {
        writing-mode: vertical-rl;   /* rotates text vertically */
        transform: rotate(180deg);   /* makes it read top-to-bottom */
        white-space: nowrap;         /* avoid breaking year digits */
        vertical-align: middle;      /* keep it centered */
        text-align: center;
    }

    .chart-nav-item button {
        border: 2px solid #099dda !important;
    }

    .incre_value {
        background-color: #28a745 !important;
    }
    .decre_value {
        background-color: #dc3545 !important;
    }
    .main_value {
        background-color: #3dc5e1 !important;
    }
    .nutral_value {
        background-color: #fff !important;
    }
    .current_day_value {
        background-color: #c395ff !important;
    }
</style>

<style id="my-style-id"></style>

<style>
    /* Sticky header (all th) */
    .sticky_table tfoot tr {
        position: sticky;
        bottom: 0;
        background: #39484f !important;
        color: #000;
        text-align: center;
        vertical-align: middle;
        z-index: 50; /* default header z-index */
    }

    .sticky_table tfoot td.sticky-col-left {
        position: sticky;
        left: 0;
        bottom:0;
        color: #000;
        background: #39484f !important;
        z-index: 15;
        border-right: 1px solid #000;
    }

    .sticky_table tfoot td.sticky-col-second {
        position: sticky;
        left: 150px;
        bottom: 0;
        background: #39484f !important;
        color: #000;
        z-index: 10;      
        border-right: 1px solid #000;
    }

    .counter-container {
        text-align: center;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;
        height: 100px;
        border: 1px solid #e8e0e0;
        align-content: center;
        padding: 10px;
    }

    .counter-container h1 {
        margin-bottom: 20px;
        color: #333333;
    }

    .counter-container .total_counts_txt {
        color: #7239ea;
        font-size: 28px;
    }

    .scroll-container-wrapper {
        position: relative;
        display: flex;
        align-items: center;
        max-width: 100%;
        overflow: hidden;
    }

    .scroll-container {
        display: flex;
        overflow-x: auto;
        scroll-behavior: smooth;
        padding: 10px 40px;
        gap: 10px;
        scrollbar-width: none;
    }

    .scroll-container::-webkit-scrollbar {
        display: none;
    }

    .item {
        flex: 0 0 auto;
        text-align: center;
        font-weight: bold;
        border-radius: 8px;
    }

    .scroll-btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: #099DDA;
        border: none;
        padding: 10px 10px;
        cursor: pointer;
        z-index: 10;
        border-radius: 4px;
        display: none;
    }

    .scroll-btn.left {
        left: 0;
    }

    .scroll-btn.right {
        right: 0;
    }
</style>
<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1 d-flex align-items-center justify-content-between gap-2">
        <div>
            <h5 class="card-title mb-1">Customer {{ $report_heading }} - Yearly</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Business {{ $report_heading }}</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="{{ url('/manage_reports/customer_source_report_yearly') }}" class="d-flex align-items-center">Customer {{ $report_heading }}</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Drop Customer</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                        <a href="javascript:;"type="button" class="nav-link text-capitalize active">Yearly</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/customer_drop_report') }}" type="button" class="nav-link text-capitalize" >Monthly</a>
                    </li>
                </ul>
            </div>
            
        </div>
    </div>    
    <div class="card-body">
        @php
            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];
            $days = range(1,31); // always show 1-31
            $yearShort = date('y'); // e.g., 25 for 2025
            $year = date('Y');
        @endphp
        <div class="d-flex flex-row justify-items-betwen gap-2 mb-6" style="flex-wrap: wrap;justify-content: space-between;">
            <div class="w-80 nav-align-top mb-2">
                <ul class="nav nav-pills flex-nowrap" role="tablist">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                        <div class="scroll-container" id="scrollContainer">
                            <div class="item">
                                <li class="nav-item">
                                    <a href="{{'/manage_reports/customer_source_report_yearly'}}" type="button" class="nav-link text-capitalize">Customer Source</a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item">
                                    <a href="javascript:;" type="button" class="nav-link text-capitalize active">Drop Customer</a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item">
                                    <a href="{{ url('/manage_reports/customer_age_report_yearly') }}" type="button" class="nav-link text-capitalize">Gender</a>
                                </li>
                            </div>
                            <div class="item">
                                <li class="nav-item">
                                    <a href="{{ url('/manage_reports/customer_employee_type_yearly') }}" type="button" class="nav-link text-capitalize">Employee Type</a>
                                </li>
                            </div>
                        </div>
                        <button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>
            </div>
            <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-2" style="margin-left: auto;">
                <ul class="nav nav-pills justify-content-end" role="tablist">
                    <li class="nav-item me-1">
                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary py-2"  data-bs-toggle="modal" data-bs-target="#kt_modal_course_package_vs_month" id="graph_div" style="display:none !important;">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Graph"><i class="mdi mdi-finance fs-3"></i></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="row mb-2">
            <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-6" style="flex-wrap: wrap;">
                <div class="col-lg-10 mx-3 mb-2 d-flex align-items-center justify-content-start gap-2 p-3 mb-6 border rounded border-primary py-3" style="flex-flow: wrap;max-width: fit-content;">
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #f3f9b8"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Current Year</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #C395FF"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Current Month Value</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #28a745"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Increased Value</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #dc3545"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Decreased Value</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #3dc5e1"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Maintained Value</label>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="table-scroll-wrapper">
                    <!-- Top Scrollbar -->
                    <div class="top-scrollbar">
                        <div></div>
                    </div>
                    <div class="table-container">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 sticky_table">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-150px sticky-col-left fs-5 text-center">
                                        Years 
                                    </th>
                                    <th class="min-w-150px sticky-col-left sticky-col-second fs-5 text-center text-wrap">
                                        Customers
                                        <div class="d-block">
                                            <label>Drops</label>
                                        </div>
                                    </th>
                                    @foreach($months as $month_name)
                                        <th class="min-w-150px fs-5 text-center">{{ $month_name }}</th>
                                    @endforeach
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-3" id="Monthly_lead_table">
                            </tbody>
                            <tfoot class="text-black fw-semibold bg-light fs-3" id="Yearly_lead_footer"></tfoot>
                        </table>
                    </div>
                    <div class="bottom-scrollbar">
                        <div></div>
                    </div>
                </div>
            </div>
            <div id="total_container" style="display:none !important;">
                <!-- <div class="d-flex col-lg-12 mt-6 gap-2 justify-content-center">
                    <div class="counter-container">
                        <div class="counter fw-bold mb-2">
                            <span class="total_counts_txt" id="day_wise_grand_count_placed">00</span>
                        </div>
                        <h4 class="fs-5 fw-bold mb-0">Total Placed Students</h4>
                    </div>
                    <div class="counter-container">
                        <div class="counter fw-bold mb-2">
                            <span class="total_counts_txt" id="day_wise_grand_count_unplaced">00</span>
                        </div>
                        <h4 class="fs-5 fw-bold mb-0">Total Unplaced Students</h4>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Total Leads Vs Month-->
<div class="modal fade" id="kt_modal_course_package_vs_month" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" id="modal_Close" onclick="close_function()">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class="mb-4 text-black text-center" style="line-height: inherit;">Customers Vs Drops - <span id="chart_modal_head">Yearly</span></h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-6 mt-6" style="flex-wrap: wrap;place-self:center;">
                            <ul class="nav nav-pills gap-2" role="tablist">
                                <li class="nav-item chart-nav-item">
                                    <button type="button" class="nav-link text-capitalize active" role="tab" data-bs-toggle="tab" data-bs-target="#tab_overall_yearly" aria-controls="tab_overall_yearly" aria-selected="true">Overall</button>
                                </li>
                                <li class="nav-item chart-nav-item">
                                    <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_active_yearly" aria-controls="tab_active_yearly" aria-selected="true">Customers</button>
                                </li>
                                <li class="nav-item chart-nav-item">
                                    <button type="button" class="nav-link text-capitalize" role="tab" data-bs-toggle="tab" data-bs-target="#tab_finished_yearly" aria-controls="tab_finished_yearly" aria-selected="false">Drops</button>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tab-content p-0">

                        <div class="tab-pane fade show active" id="tab_overall_yearly" role="tabpanel">
                            <div class="row">
                                <div class="col-lg-12 mb-4">
                                    <div class="container text-center border border-gray-200 rounded p-3" style="min-height: auto">
                                        <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Overall Yearly Customers Vs Drops <span id="YearOverallChart_name"></span></h1>
                                        <div id="YearOverallChart-wrapper"><div id="YearOverallChart"></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="tab_active_yearly" role="tabpanel">
                            <div class="row">
                                <div class="col-lg-12 mb-4">
                                    <div class="container text-center border border-gray-200 rounded p-3" style="min-height: auto">
                                        <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-pie"></i> Yearly Customers Distribution <span id="ActivePieChart_name"></span></h1>
                                        <div id="ActivePieChart-wrapper"><div id="ActivePieChart"></div></div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-4">
                                    <div class="container text-center border border-gray-200 rounded p-3" style="min-height: auto">
                                        <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Monthly Customers Distribution <span id="ActiveAreaChart_name"></span></h1>
                                        <div id="ActiveAreaChart-wrapper"><div id="ActiveAreaChart"></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="tab_finished_yearly" role="tabpanel">
                            <div class="row">
                                <div class="col-lg-12 mb-4">
                                    <div class="container text-center border border-gray-200 rounded p-3" style="min-height: auto">
                                        <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-pie"></i> Yearly Drops Distribution <span id="FinishedPieChart_name"></span></h1>
                                        <div id="FinishedPieChart-wrapper"><div id="FinishedPieChart"></div></div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-4">
                                    <div class="container text-center border border-gray-200 rounded p-3" style="min-height: auto">
                                        <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Monthly Drops Distribution <span id="FinishedAreaChart_name"></span></h1>
                                        <div id="FinishedAreaChart-wrapper"><div id="FinishedAreaChart"></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Total Leads Vs Month-->

<script>

const now = new Date();
let currentYear = now.getFullYear();
let currentMonth = now.getMonth() + 1; // getMonth() returns 1–12
var trendcurrentMonth = new Date().getMonth(); // getMonth() returns 0–11
let currentDate = now.getDate();
var trendcurrentYear = now.getFullYear();

var selectedYear = currentYear;

var months = @json($months);

var short_months = null;
var days = @json($days);
var types = null;
var years = null;
var year_colors = null;
var pie_year_colors = null;
var types_list = null;
var type_keys = null;
var intern_data = null;
var pre_intern_data = null;
var totals = null;
var grandTotals = null;
var typeDayTotals = null;
var percentages = null;
var grandTypeTotals = null;
var typeMonthTotals = null;
var year = currentYear;
var type_count = 0;
var MonthTotalActiveTotals = null;
var MonthTotalExtendTotals = null;
var condi_months = null;
var inern_trend_data = null;
var month_percentages = null;
var comparison_area_active = [];
var comparison_area_extend = [];

var full_months = {
    1: 'January',
    2: 'February',
    3: 'March',
    4: 'April',
    5: 'May',
    6: 'June',
    7: 'July',
    8: 'August',
    9: 'September',
    10: 'October',
    11: 'November',
    12: 'December'
};

var type_colors = {
    'customer_count' : '#1E90FF',
    'drop_customer_count' : '#FF4500'
};

const line_MonthColors = [
    null,
    '#2ECC71',
    '#27AE60',
    '#1ABC9C',
    '#16A085',
    '#3498DB',
    '#2980B9',
    '#9B59B6',
    '#8E44AD',
    '#F39C12',
    '#E67E22',
    '#E74C3C',
    '#C0392B'
];

const pie_MonthColors = [
    '#2ECC71',
    '#27AE60',
    '#1ABC9C',
    '#16A085',
    '#3498DB',
    '#2980B9',
    '#9B59B6',
    '#8E44AD',
    '#F39C12',
    '#E67E22',
    '#E74C3C',
    '#C0392B'
];

var chartOverAllMonths = new ApexCharts(document.querySelector("#YearOverallChart"), {
    series: [],
    chart: {
        height: 350,
        type: 'area',
        toolbar: { show: true }
    },
    dataLabels: { 
        enabled: true
    },
    stroke: { curve: 'smooth'},
    markers: { size: 5 },
    xaxis: {
        categories: [],
        title: { text: `Years` } // Use Blade variable
    },
    yaxis: {
        title: { text: 'Total Customers Vs Drops' }
    },
    tooltip: {
        shared: true,
        intersect: false,
        // x: {
        //     formatter: function (value) {
        //         return full_months[value] || 'Unknown Month'; // fallback if not found
        //     }
        // },
        y: {
            formatter: function (value) {
                return value + ' Customers'; // Customize label
            },
            title: {
                formatter: function (seriesName) {
                    return seriesName + ":";
                }
            }
        }
    },
    fill: {
        type: 'gradient', 
        gradient: { 
            shadeIntensity: 0.6, opacityFrom: 0.5, opacityTo: 0.2 
        }
    },
    legend: {
        position: 'top', // Must match the class you're targeting
        horizontalAlign: 'center',
        verticalAlign: 'center' // optionally, to help vertical placement
    }
});
chartOverAllMonths.render();

var chartActiveDaily = new ApexCharts(document.querySelector("#ActiveAreaChart"), {
    series: [],
    chart: {
        height: 350,
        type: 'area',
        toolbar: { show: true }
    },
    dataLabels: { 
        enabled: true
    },
    stroke: { curve: 'smooth'},
    markers: { size: 5 },
    xaxis: {
        categories: Object.values(months ?? {}),
        title: { text: '' } // Use Blade variable
    },
    yaxis: {
        title: { text: 'No of Customers' },
        labels: {
            formatter: function (val) {
                return val;
            }
        }
    },
    tooltip: {
        shared: true,
        intersect: false,
        x: {
            formatter: function (value) {
                return full_months[value] || 'Unknown Month'; // fallback if not found
            }
        },
        y: {
            formatter: function (value) {
                return value + " Customers"; // Customize label
            },
            title: {
                formatter: function (seriesName) {
                    return seriesName + ":";
                }
            }
        }
    },
    fill: {
        type: 'gradient', 
        gradient: { 
            shadeIntensity: 0.6, opacityFrom: 0.5, opacityTo: 0.2 
        }
    },
    legend: {
        position: 'bottom', // Must match the class you're targeting
        horizontalAlign: 'center',
        verticalAlign: 'center' // optionally, to help vertical placement
    }
});
chartActiveDaily.render();

var chartExtendDaily = new ApexCharts(document.querySelector("#FinishedAreaChart"), {
    series: [],
    chart: {
        height: 350,
        type: 'area',
        toolbar: { show: true }
    },
    dataLabels: { 
        enabled: true
    },
    stroke: { curve: 'smooth'},
    markers: { size: 5 },
    xaxis: {
        categories: Object.values(months ?? {}),
        title: { text: '' } // Use Blade variable
    },
    yaxis: {
        title: { text: 'No of Drops' },
        labels: {
            formatter: function (val) {
                return val;
            }
        }
    },
    tooltip: {
        shared: true,
        intersect: false,
        x: {
            formatter: function (value) {
                return full_months[value] || 'Unknown Month'; // fallback if not found
            }
        },
        y: {
            formatter: function (value) {
                return value + " Customers"; // Customize label
            },
            title: {
                formatter: function (seriesName) {
                    return seriesName + ":";
                }
            }
        }
    },
    fill: {
        type: 'gradient', 
        gradient: { 
            shadeIntensity: 0.6, opacityFrom: 0.5, opacityTo: 0.2 
        }
    },
    legend: {
        position: 'bottom', // Must match the class you're targeting
        horizontalAlign: 'center',
        verticalAlign: 'center' // optionally, to help vertical placement
    }
});
chartExtendDaily.render();

$(document).ready(function () {
    getLeadDetailsTable();
});

function getLeadDetailsTable() {

    $.ajax({
        url: '{{ route("customer_drop_report_yearly_data") }}',
        method: 'POST',
        dataType: 'json',
        data: {
            _token: '{{ csrf_token() }}'
        },
        beforeSend: function () {
            Swal.fire({
                title: 'Processing...',
                text: 'Please wait while we load the data.',
                showConfirmButton: false,
                showCancelButton: false,
                allowOutsideClick: false,
                allowEscapeKey: false,
                customClass: {
                    confirmButton: 'd-none btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false,
                didOpen: () => {
                    Swal.showLoading();
                    document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
                    document.getElementById('total_container').style.setProperty('display', 'none', 'important');
                }
            });

            $('#Yearly_lead_footer').empty();
            $('#Monthly_lead_table').html('<tr><td colspan="100%" class="text-center">Loading...</td></tr>');
        },
        success: function (data) {
            try {

                if (!data || typeof data !== 'object') {
                    throw new Error('Invalid response format');
                }

                months = data.months && typeof data.months === 'object' ? data.months : null;
                year_colors = data.year_colors && typeof data.year_colors === 'object' ? data.year_colors : null;
                pie_year_colors = Array.isArray(year_colors) ? year_colors : Object.values(year_colors || {});
                condi_months = Array.isArray(months) ? months : Object.values(months || {});
                short_months = Array.isArray(data.short_months) ? data.short_months : Object.values(data.short_months || {});
                years = Array.isArray(data.years) ? data.years : Object.values(data.years || {});
                days = Array.isArray(data.days) ? data.days : Object.values(data.days || {});
                types = Array.isArray(data.types) ? data.types : Object.values(data.types || {});
                types_list = data.types_list && typeof data.types_list === 'object' ? data.types_list : null;
                type_keys = Array.isArray(data.type_keys) ? data.type_keys : Object.values(data.type_keys || {});
                intern_data = data.inern_cal_data && typeof data.inern_cal_data === 'object' ? data.inern_cal_data : null;
                pre_intern_data = data.pre_inern_cal_data && typeof data.pre_inern_cal_data === 'object' ? data.pre_inern_cal_data : null;
                totals = data.totals && typeof data.totals === 'object' ? data.totals : null;
                grandTotals = data.grandTotals && typeof data.grandTotals === 'object' ? data.grandTotals : null;
                grandTypeTotals = data.grandTypeTotals && typeof data.grandTypeTotals === 'object' ? data.grandTypeTotals : null;
                typeDayTotals = data.typeDayTotals && typeof data.typeDayTotals === 'object' ? data.typeDayTotals : null;
                percentages = data.percentages && typeof data.percentages === 'object' ? data.percentages : null;
                typeMonthTotals = data.typeMonthTotals && typeof data.typeMonthTotals === 'object' ? data.typeMonthTotals : null;
                inern_trend_data = data.inern_trend_data && typeof data.inern_trend_data === 'object' ? data.inern_trend_data : null;
                month_percentages = data.month_percentages && typeof data.month_percentages === 'object' ? data.month_percentages : null;
                type_count = parseInt(data.type_count) ?? 0;

                MonthTotalActiveTotals = typeMonthTotals && Array.isArray(typeMonthTotals.customer_count) ? typeMonthTotals.customer_count : Object.values(typeMonthTotals.customer_count || {});
                MonthTotalExtendTotals = typeMonthTotals && Array.isArray(typeMonthTotals.drop_customer_count) ? typeMonthTotals.drop_customer_count : Object.values(typeMonthTotals.drop_customer_count || {});

                if (!years || !months || !types_list || !intern_data) {
                    throw new Error('Required data missing');
                }
                
                buildLeadsTable();
                overall_months_chart();
                create_pie_active_chart();
                create_pie_extend_chart();

            } catch (ex) {
                console.error('Data validation error:', ex);
                showNoDataRow();
            } finally {
                Swal.close();
            }
        },
        error: function (xhr, status, error) {
            Swal.close();

            let message = 'Failed to load data. Please try again later.';
            if(xhr.status === 0){
                message = 'Network error: Please check your internet connection.';
            } else if(xhr.status >= 500){
                message = 'Server error occurred. Please try again later.';
            } else if(xhr.status === 422){
                message = 'Validation error: Please check your input.';
            } else if(xhr.responseJSON && xhr.responseJSON.message){
                message = xhr.responseJSON.message;
            }

            console.error('Error loading data:', xhr.responseText);

            showNoDataRow();

            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: message,
                showConfirmButton: true,
                confirmButtonText: 'Close',
                allowOutsideClick: false,
                allowEscapeKey: false,
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light btn-md'
                },
                buttonsStyling: false
            });
        }
    });
}

function fr_round(value, decimals) {
    return Number(Math.round(value + 'e' + decimals) + 'e-' + decimals);
}

function buildLeadsTable() {

    try {
        
        const $table = $('#Monthly_lead_table');
        $table.empty();

        let hasAnyData = false;

        const today = new Date().getDate();

        // const $table_footer = $('#Yearly_lead_footer');
        // $table_footer.empty();

        // let bottom_val = 0;
        // var first_tr_key = (type_keys.length > 0) ? type_keys[0] : 'none';
        // let leadsFooterRow = `<tr class="tfoot-${first_tr_key}">`;
        //     leadsFooterRow += `<td rowspan="${type_count ?? 0}" class="text-center sticky-col-left text-white">Total</td>`;

        years.forEach(year => {
            
            const isCurrentYear = parseInt(year) === new Date().getFullYear();

            var isPreMonth = (parseInt(year) < new Date().getFullYear());

            const rowClass = isCurrentYear ? 'current-month-row' : '';
            var tdClass = isCurrentYear ? 'text-black' : '';
                        
            let leadsRow = `<tr class="${rowClass}">`;
            
            leadsRow += `<td rowspan="${type_count ?? 0}" class="sticky-col-left fs-5 text-center align-middle ${tdClass} hover_tr_class_${year}">
                ${year}
            </td>`;

            let prevYear = parseInt(year) - 1;

            var tr_index = 1;

            $.each(types_list, function (type_key, type_name) {
                
                if(tr_index !== 1){
                    leadsRow += `<tr class="${rowClass}">`;
                }

                leadsRow += `<td class="hover_td_class_${year} sticky-col-left sticky-col-second fs-5 ${tdClass}">
                    ${type_name}
                    <div class="d-flex flex-row align-items-center justify-content-center gap-2 mt-2 mb-3">
                        <div class="d-block mb-2 mt-2">
                            <span class="badge bg-warning text-black fs-5 fw-semibold rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total ${type_name}">${ String(typeMonthTotals[type_key]?.[year] ?? 0).padStart(2, '0') }</span>
                        </div>
                    </div>
                </td>`;

                var day_wise_count_lead = 0;

                let prevLeads = 0;
                
                $.each(months, function (monthNumber, monthName) {

                    var prevMonth = parseInt(monthNumber) - 1;

                    var dayDataCustomer = parseInt(intern_data[year]?.[monthNumber]?.[type_key]) ?? 0;

                    var dayDataCustomerPercentData = intern_data[year]?.[monthNumber]?.[type_key] ?? 0;

                    if (dayDataCustomer > 0) {
                        hasAnyData = true;
                    }

                    if (parseInt(monthNumber) === 1) {
                        prevMonth = 12;
                        prevLeads = intern_data[prevYear]?.[prevMonth]?.[type_key] ?? 0;
                    }else if (parseInt(monthNumber) !== 1) {
                        prevMonth = parseInt(monthNumber) - 1;
                        prevLeads = intern_data[year]?.[prevMonth]?.[type_key] ?? 0;
                    }

                    // ----- Leads Row -----
                    let badgeColor = 'nutral_value';
                    var lead_enable_data = true;
                    if (isCurrentYear) {
                        if (parseInt(currentMonth) === parseInt(monthNumber)) {
                            badgeColor = 'current_day_value'; // today
                            lead_enable_data = true;
                        } else if (parseInt(currentMonth) < parseInt(monthNumber)) {
                            badgeColor = 'nutral_value'; // future
                            lead_enable_data = false;
                        } else if (prevLeads !== null) {
                            if (dayDataCustomer > prevLeads) badgeColor = 'incre_value'; // up
                            else if (dayDataCustomer < prevLeads) badgeColor = 'decre_value'; // down
                            else badgeColor = 'main_value'; // same
                            lead_enable_data = true;
                        }
                    } else if (prevLeads !== null) {
                        if (dayDataCustomer > prevLeads) badgeColor = 'incre_value';
                        else if (dayDataCustomer < prevLeads) badgeColor = 'decre_value';
                        else badgeColor = 'main_value';
                        lead_enable_data = true;
                    }

                    prevLeads = dayDataCustomer ?? 0;

                    leadsRow += `<td class="${ lead_enable_data ? 'hover_day_class_'+year+'_'+monthNumber+' ' : ''}text-center ${badgeColor}">
                        <label class="fw-semibold fs-3 text-black">
                            ${ lead_enable_data ? String(dayDataCustomer ?? 0).padStart(2, '0') : '' }
                        </label>
                        ${lead_enable_data && (type_key == 'drop_customer_count') ? '<div class="d-block"><span class="bg-white text-info fs-5 py-1 px-2 rounded">'+(month_percentages[year]?.[monthNumber])+'%</span></div>' : '' }
                    </td>`;
                });

                leadsRow += `</tr>`;
                tr_index++;
            });
            
            $table.append(leadsRow);

            scroll_option();

            document.getElementById('graph_div').style.setProperty('display', 'block', 'important');
            document.getElementById('total_container').style.setProperty('display', 'block', 'important');
        });

        // $('#day_wise_grand_count_placed').text(String(grandTypeTotals['placed_cust_count'] ?? 0).padStart(2, '0'));
        // $('#day_wise_grand_count_unplaced').text(String(grandTypeTotals['unplaced_cust_count'] ?? 0).padStart(2, '0'));
        
        // var tfoot_tr_index = 1;

        // $.each(types_list, function (type_key, type_name) {

        //     if(tfoot_tr_index !== 1){
        //         var tr_key = (type_keys.length > 0) ? type_keys[parseInt(tfoot_tr_index)- 1] : 'none';
        //         bottom_val = bottom_val + 100;
        //         leadsFooterRow += `<tr class="tfoot-${tr_key}">`;
        //     }

        //     leadsFooterRow += `<td class="sticky-col-left sticky-col-second text-white">
        //         ${type_name}
        //         <div class="d-block">
        //             <span class="badge bg-warning text-black fs-5 fw-semibold rounded" data-bs-toggle="tooltip" data-bs-placement="bottom">${ String(grandTypeTotals?.[type_key] ?? 0).padStart(2, '0') }</span>
        //         </div>
        //     </td>`;

        //     $.each(days, function (_, d) {

        //         leadsFooterRow += `<td class="text-center">
        //             <label class="fw-semibold fs-3 text-white">
        //                 ${ String(typeDayTotals[type_key]?.[d] ?? 0).padStart(2, '0') }
        //             </label>
        //         </td>`;

        //     });

        //     tfoot_tr_index++;
        // });
        
        // leadsFooterRow += `</tr>`;
        
        // $table_footer.append(leadsFooterRow);
        
        hover_classes(years,months);

        $('[data-bs-toggle="tooltip"]').tooltip({ 'animation' : false });
        
        if (!hasAnyData) {
            showNoDataRow();
        }

        // if(types_list){

        //     let tfoot_tr_bottom_val = 0;
        //     let style_textContent = '';
    
        //     // Step 1: Convert to array and reverse
        //     const reversed_entries = Object.entries(types_list).reverse();
    
        //     // Step 2: Collect row data
        //     const rows = [];
        //     let current_bottom = 0;
    
        //     reversed_entries.forEach(([type_key, type_name]) => {
        //         rows.push({
        //             type_key,
        //             bottom: current_bottom
        //         });
        //         current_bottom += 100; // Step up for each row
        //     });
    
        //     // Step 3: Find max bottom to skip z-index on that row
        //     const max_bottom = Math.max(...rows.map(r => r.bottom));
    
        //     // Step 4: Build CSS
        //     rows.forEach(row => {
        //         style_textContent += `.sticky_table tfoot tr.tfoot-${row.type_key} { `;
        //         style_textContent += `bottom: ${row.bottom}px; `;
    
        //         if (row.bottom !== max_bottom) {
        //             style_textContent += `z-index: 40; `;
        //         }
    
        //         style_textContent += `}\n`;
        //     });
    
        //     // Step 5: Inject styles
        //     document.getElementById('my-style-id').textContent = style_textContent;
        // }

    } catch (ex) {
        console.error('Error building leads table:', ex);
        showNoDataRow();
    }
}

function showNoDataRow() {
    $('#Monthly_lead_table').html(`
        <tr>
            <td colspan="100%" class="text-left text-muted fw-semibold py-4 fs-4 px-6" style="text-align: left;">
                No Customers Vs Drops data found.
            </td>
        </tr>
    `);
    $('#Yearly_lead_footer').empty();
    // get_pagination(null,false);
    document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
    document.getElementById('total_container').style.setProperty('display', 'none', 'important');
}

function overall_months_chart() {

    chartOverAllMonths.updateSeries([
        {
            name: 'Customers',
            data: MonthTotalActiveTotals,
            color: type_colors?.customer_count ?? '#1E90FF'
        },
        {
            name: 'Drops',
            data: MonthTotalExtendTotals,
            color: type_colors?.drop_customer_count ?? '#FF4500'
        }
    ]);

    chartOverAllMonths.updateOptions({
        xaxis: {
            categories: years ?? []
        }
    });
}

function create_pie_active_chart(){

    var dataSeries = MonthTotalActiveTotals ? MonthTotalActiveTotals?.map(val => val ?? 0) ?? [] : [];
    var $wrapper = $('#ActivePieChart-wrapper');
    
    // If no data or all 0s, show message
    var allZeros = dataSeries.every(val => val === 0);
        
    if (!dataSeries || dataSeries.length === 0 || allZeros) {
        $wrapper.html(`
        <div class="no-data-message fs-6" style="min-height: auto;align-content: space-evenly;">
            No data found
        </div>`);
        return;
    }
    
    // Clear wrapper and add chart container
    $wrapper.html('<div id="ActivePieChart"></div>');
    
    var clickedIndex = null;
    var month_name = 'None';
    var trendData = [];
    var SourceColor = '#1E90FF';

    var chartPieActive = new ApexCharts(document.querySelector("#ActivePieChart"), {
        series: dataSeries,
        chart: { type:'pie', height:350,
            events: {
                dataPointSelection: function(event, chartContext, config){
                    var clickedIndex = config.dataPointIndex;
                    month_name = years[clickedIndex] ?? 'None';
                    if (comparison_area_active[month_name]) {
                        delete comparison_area_active[month_name];
                    } else {
                        clickedIndex = config.dataPointIndex;
                        month_name = years[clickedIndex] ?? 'None';
                        trendData = inern_trend_data[month_name] ?? [];
                        SourceColor = year_colors[month_name] ?? '#1E90FF';
                        comparison_area_active[month_name] = {
                            name: month_name,
                            data: trendData.map(trendD => (trendD.customer_count ?? 0)),
                            color: SourceColor
                        };
                    }
                    var seriesArray = Object.values(comparison_area_active);
                    updateActiveTrendChart(seriesArray);
                }
            }
        },
        labels: years ?? [],
        colors: pie_year_colors,
        title: { text: '' },
        legend: {
            position: 'bottom',
            fontSize: '14px',
            labels: {
                colors: 'black'
            },
            markers: {
                width: 14,
                height: 14,
                radius: 3
            }
        },
        tooltip: {
            y: {
                formatter: function (value) {
                    return value + " Customers"; // Customize label
                },
                title: {
                    formatter: function (seriesName) {
                        return seriesName + ":";
                    }
                }
            }
        },
        dataLabels: { enabled:true, formatter: function(val, opts){ return Math.round(opts.w.globals.seriesPercent[opts.seriesIndex]) + ' %'; } }
    });
    chartPieActive.render().then(() => {
        var month_name = trendcurrentYear ?? 'None';
        var trendData = inern_trend_data[month_name] ?? null;
        var SourceColor = year_colors[month_name] ?? '#1E90FF';
        if(trendData){
            comparison_area_active[month_name] = {
                name: month_name,
                data: trendData.map(trendD => (trendD.customer_count ?? 0)),
                color: SourceColor
            };
            updateActiveTrendChart(Object.values(comparison_area_active)); // Clear or reset the chart
        }else{
            updateActiveTrendChart([]);
            comparison_area_active = [];
        }
    });
}

function updateActiveTrendChart(seriesData = []) {
    chartActiveDaily.updateSeries(seriesData);
}

function create_pie_extend_chart(){

    var dataSeries = MonthTotalExtendTotals ? MonthTotalExtendTotals?.map(val => val ?? 0) ?? [] : [];
    var $wrapper = $('#FinishedPieChart-wrapper');
    
    // If no data or all 0s, show message
    var allZeros = dataSeries.every(val => val === 0);
        
    if (!dataSeries || dataSeries.length === 0 || allZeros) {
        $wrapper.html(`
        <div class="no-data-message fs-6" style="min-height: auto;align-content: space-evenly;">
            No data found
        </div>`);
        return;
    }
    
    // Clear wrapper and add chart container
    $wrapper.html('<div id="FinishedPieChart"></div>');
    
    var clickedIndex = null;
    var month_name = 'None';
    var trendData = [];
    var SourceColor = '#FF4500';

    var chartPieStudent = new ApexCharts(document.querySelector("#FinishedPieChart"), {
        series: dataSeries,
        chart: { type:'pie', height:350,
            events: {
                dataPointSelection: function(event, chartContext, config){
                    var clickedIndex = config.dataPointIndex;
                    month_name = years[clickedIndex] ?? 'None';
                    if (comparison_area_extend[month_name]) {
                        delete comparison_area_extend[month_name];
                    } else {
                        clickedIndex = config.dataPointIndex;
                        month_name = years[clickedIndex] ?? 'None';
                        trendData = inern_trend_data[month_name] ?? [];
                        SourceColor = year_colors[month_name] ?? '#FF4500';
                        comparison_area_extend[month_name] = {
                            name: month_name,
                            data: trendData.map(trendD => (trendD.drop_customer_count ?? 0)),
                            color: SourceColor
                        };
                    }
                    var seriesArray = Object.values(comparison_area_extend);
                    updateExtendTrendChart(seriesArray);
                }
            }
        },
        labels: years ?? [],
        colors: pie_year_colors,
        title: { text: '' },
        legend: {
            position: 'bottom',
            fontSize: '14px',
            labels: {
                colors: 'black'
            },
            markers: {
                width: 14,
                height: 14,
                radius: 3
            }
        },
        tooltip: {
            y: {
                formatter: function (value) {
                    return value + " Drop Customers"; // Customize label
                },
                title: {
                    formatter: function (seriesName) {
                        return seriesName + ":";
                    }
                }
            }
        },
        dataLabels: { enabled:true, formatter: function(val, opts){ return Math.round(opts.w.globals.seriesPercent[opts.seriesIndex]) + ' %'; } }
    });
    chartPieStudent.render().then(() => {
        var month_name = trendcurrentYear ?? 'None';
        var trendData = inern_trend_data[month_name] ?? null;
        var SourceColor = year_colors[month_name] ?? '#FF4500';
        if(trendData){
            comparison_area_extend[month_name] = {
                name: month_name,
                data: trendData.map(trendD => (trendD.drop_customer_count ?? 0)),
                color: SourceColor
            };
            updateExtendTrendChart(Object.values(comparison_area_extend)); // Clear or reset the chart
        }else{
            updateExtendTrendChart([]);
            comparison_area_extend = [];
        }
    });
}

function updateExtendTrendChart(seriesData = []) {
    chartExtendDaily.updateSeries(seriesData);
}

function scroll_option() {
    const topScrollbar = document.querySelector(".top-scrollbar");
    const bottomScrollbar = document.querySelector(".bottom-scrollbar");
    const topScroller = topScrollbar.querySelector("div");
    const bottomScroller = bottomScrollbar.querySelector("div");

    const tableContainer = document.querySelector(".table-container");

    // Match widths
    topScroller.style.width = tableContainer.scrollWidth + "px";

    // Sync scrolls
    topScrollbar.addEventListener("scroll", function () {
        tableContainer.scrollLeft = topScrollbar.scrollLeft;
    });
    tableContainer.addEventListener("scroll", function () {
        topScrollbar.scrollLeft = tableContainer.scrollLeft;
    });

    bottomScroller.style.width = tableContainer.scrollWidth + "px";

    // Sync scrolls
    bottomScrollbar.addEventListener("scroll", function () {
        tableContainer.scrollLeft = bottomScrollbar.scrollLeft;
    });
    tableContainer.addEventListener("scroll", function () {
        bottomScrollbar.scrollLeft = tableContainer.scrollLeft;
    });
}

function hover_classes(e_months = null, e_days = null) {

    if (e_months !== null) {

        e_months.forEach(monthNumber => {

            // Remove old listeners
            document.querySelectorAll(`.hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}`).forEach(el => {
                el.replaceWith(el.cloneNode(true));
            });

            // ============================
            // 🔹 Month-wise Hover
            // ============================

            // Hover on sub-row cell
            document.querySelectorAll(`.hover_td_class_${monthNumber}`).forEach(td => {
                td.addEventListener("mouseenter", () => {
                    highlight(td);

                    // highlight month header
                    let row = td.parentNode;
                    while (row) {
                        const rowspanCell = row.querySelector(`.hover_tr_class_${monthNumber}`);
                        if (rowspanCell) {
                            highlight(rowspanCell);
                            break;
                        }
                        row = row.previousElementSibling;
                    }

                    // 🔸 NEW: expand related day cells (height animation)
                    document.querySelectorAll(`[class^="hover_day_class_${monthNumber}_"]`).forEach(dayCell => {
                        highlight(dayCell,2);
                    });
                });

                td.addEventListener("mouseleave", () => {
                    resetMonth(monthNumber);
                });
            });

            // Hover on month header
            document.querySelectorAll(`.hover_tr_class_${monthNumber}`).forEach(td => {
                td.addEventListener("mouseenter", () => {
                    highlight(td);

                    // highlight ALL sub-row cells
                    let row = td.parentNode;
                    while (row) {
                        const hoverCell = row.querySelector(`.hover_td_class_${monthNumber}`);
                        if (hoverCell) highlight(hoverCell);
                        row = row.nextElementSibling;
                    }

                    // highlight all day cells
                    document.querySelectorAll(`[class^="hover_day_class_${monthNumber}_"]`).forEach(dayCell => {
                        highlight(dayCell,2);
                    });
                });

                td.addEventListener("mouseleave", () => {
                    resetMonth(monthNumber);
                });
            });

            // ============================
            // 🔹 Day-wise Hover
            // ============================
            if (e_days !== null) {
                $.each(e_days, function (day, day_name) {
                    document.querySelectorAll(`.hover_day_class_${monthNumber}_${day}`).forEach(td => {
                        td.addEventListener("mouseenter", () => {
                            // highlight the parent row's sub-cell
                            const row = td.closest("tr");
                            if (row) {
                                const rowCell = row.querySelector(`.hover_td_class_${monthNumber}`);
                                if (rowCell) highlight(rowCell);
                            }

                            // highlight the month header cell
                            let prevRow = td.parentNode;
                            while (prevRow) {
                                const monthHeader = prevRow.querySelector(`.hover_tr_class_${monthNumber}`);
                                if (monthHeader) {
                                    highlight(monthHeader);
                                    break;
                                }
                                prevRow = prevRow.previousElementSibling;
                            }
                        });

                        td.addEventListener("mouseleave", () => {
                            resetDay(monthNumber, day);
                        });
                    });
                });
            }
        });
    }

    // Highlight style
    function highlight(cell, type = 1) {
        cell.style.backgroundColor = "#f0913d";
        cell.style.color = "#000";
        cell.style.transition = "background-color 0.3s ease-out, color 0.3s ease-out, transform 0.3s ease-out, box-shadow 0.3s ease-out, height 0.3s ease-out";
        cell.style.transform = "translateZ(5px) scale(1.02)";
        if(type === 2){
            cell.style.borderTop = "4px solid #000";
            cell.style.borderBottom = "4px solid #000";
            cell.style.boxShadow = "0 0 12px 3px #f0913d";
        }else{
            cell.style.border = "2px solid #ffffff";
        }
    }

    // Reset month highlights
    function resetMonth(monthNumber) {
        document.querySelectorAll(`.hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}, [class^="hover_day_class_${monthNumber}_"]`).forEach(cell => {
            resetCell(cell);
        });
    }

    // Reset day highlights
    function resetDay(monthNumber, day) {
        document.querySelectorAll(
            `.hover_day_class_${monthNumber}_${day}, .hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}`
        ).forEach(cell => {
            resetCell(cell);
        });
    }

    // Reset helper
    function resetCell(cell) {
        cell.style.backgroundColor = "";
        cell.style.color = "";
        cell.style.transform = "";
        cell.style.border = "";
        cell.style.borderTop = "";
        cell.style.borderBottom = "";
        cell.style.boxShadow = "";
        cell.style.height = ""; // reset to default
    }
}

function close_function(){
    overall_months_chart();
    create_pie_active_chart();
    create_pie_extend_chart();
    comparison_area_active = [];
    comparison_area_extend = [];
}

</script>

@endsection