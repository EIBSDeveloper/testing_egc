@extends('layouts/layoutMaster')

@section('title', 'Customer '.$report_heading.' - Monthly')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('content')

<style>
    .table-scroll-wrapper {
        position: relative;
        width: 100%;
    }

    .top-scrollbar {
        overflow-x: auto;
        overflow-y: hidden;
        height: 16px; /* top scrollbar height */
    }

    .top-scrollbar div {
        height: 1px;
    }

    .table-container {
        overflow-x: auto;
        overflow-y: auto;
        max-height: calc(99vh - 100px);
        /* width: 100%; */
    }

 /* Base table */
    .sticky_table { 
        border-collapse: collapse; 
        border: 1px solid #222222ff;  
        width: 100%; /* ensures horizontal scroll works */
    }

    /* Sticky header (all th) */
    .sticky_table thead th {
        position: sticky;
        top: 0;
        background: #00246b !important;
        color: #fff;
        text-align: center;
        vertical-align: middle;
        z-index: 50; /* default header z-index */
        border-right: 1px solid #ffffff;
    }
    
    /* Table cells */
    .sticky_table th, 
    .sticky_table td { 
        padding: 0;                
        text-align: center;
        vertical-align: middle;
        width: 100px;               
        height: 100px;             
        min-width: 80px;           
        max-width: 80px;
        min-height: 80px;           
        max-height: 80px;
        overflow: hidden;
        white-space: nowrap;
        border: 1px solid #222222ff;  
    }


    .sticky_table th.sticky-col-left {
        position: sticky;
        left: 0;
        color: #fff;
        background: #00246b !important;
        z-index: 60;
        border-right: 1px solid #ffffff;
    }

    .sticky_table td.sticky-col-left {
        position: sticky;
        left: 0;
        color: #000;
        background-color: #fff;
        z-index: 15;
        border-right: 1px solid #222222ff;
    }


    .sticky_table td.sticky-col-second {
        position: sticky;
        left: 150px;     
        background: #fff; 
        color: #000;
        z-index: 10;      
        border-right: 1px solid #222222ff;
    }


    .sticky_table th.sticky-col-second {
        position: sticky;
        left: 150px;
        background: #00246b !important;
        color: #fff;
        z-index: 60;      
        border-right: 1px solid #ffffff;
    }

    .sticky_table .current-month-row {
        background: #f3f9b8 !important;
        color: #000;
    }

    .current-month-row label {
        color: black !important;
    }

    .year-vertical {
        writing-mode: vertical-rl;   /* rotates text vertically */
        transform: rotate(180deg);   /* makes it read top-to-bottom */
        white-space: nowrap;         /* avoid breaking year digits */
        vertical-align: middle;      /* keep it centered */
        text-align: center;
    }

    .chart-nav-item button {
        border: 2px solid #099dda !important;
    }

    .incre_value {
        background-color: #28a745 !important;
    }
    .decre_value {
        background-color: #dc3545 !important;
    }
    .main_value {
        background-color: #3dc5e1 !important;
    }
    .nutral_value {
        background-color: #fff !important;
    }
    .current_day_value {
        background-color: #c395ff !important;
    }

    .search {
      position: relative;
      background: #ffffff;
      border-radius: 40px;
      padding: 5px 10px;
      display: flex;
      align-items: center;
      width: 350px;
    }

    /* Buttons */
    .search-btn, .reset-btn {
      color: #ffffff;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: #099dda;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-left: 10px;
      cursor: pointer;
      transition: background 0.3s;
      flex-shrink: 0;
    }

    .search span.select2-selection.select2-selection--multiple {
        border: none !important;
        border-radius: 8px 0px 0px 12px;
        width: 232px;
    }

    .search-btn:hover, .reset-btn:hover{
        color : #fff;
    }
</style>

<style id="my-style-id"></style>

<style>
    /* Sticky header (all th) */
    .sticky_table tfoot tr {
        position: sticky;
        bottom: 0;
        background: #00246b !important;
        color: #000;
        text-align: center;
        vertical-align: middle;
        z-index: 50; /* default header z-index */
    }

    .sticky_table tfoot td.sticky-col-left {
        position: sticky;
        left: 0;
        bottom:0;
        color: #000;
        background: #00246b !important;
        z-index: 15;
        border-right: 1px solid #ffffff;
    }

    .sticky_table tfoot td.sticky-col-second {
        position: sticky;
        left: 150px;
        bottom: 0;
        background: #00246b !important;
        color: #000;
        z-index: 10;      
        border-right: 1px solid #ffffff;
    }

    td.sticky-col-left_2 {
        position: sticky;
        color: #000;
        z-index: 15;
        border-right: 0px solid #ffffff;
        left: 50%;
        max-width: -webkit-fill-available;
    }

    .sticky_table tfoot td {
        border-right: 1px solid white;
    }

    .scroll-container-wrapper {
        position: relative;
        display: flex;
        align-items: center;
        max-width: 100%;
        overflow: hidden;
    }

    .scroll-container {
        display: flex;
        overflow-x: auto;
        scroll-behavior: smooth;
        padding: 10px 40px;
        gap: 10px;
        scrollbar-width: none;
    }

    .scroll-container::-webkit-scrollbar {
        display: none;
    }

    .item {
        flex: 0 0 auto;
        text-align: center;
        font-weight: bold;
        border-radius: 8px;
    }

    .scroll-btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: #099DDA;
        border: none;
        padding: 10px 10px;
        cursor: pointer;
        z-index: 10;
        border-radius: 4px;
        display: none;
    }

    .scroll-btn.left {
        left: 0;
    }

    .scroll-btn.right {
        right: 0;
    }
</style>
<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1 d-flex align-items-center justify-content-between gap-2">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Customer {{$report_heading}} - Monthly</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Business {{$report_heading}}</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="{{ url('/manage_reports/customer_drop_report_yearly') }}" class="d-flex align-items-center">Customer {{$report_heading}}</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="{{ url('/manage_reports/customer_employee_type_yearly') }}" class="d-flex align-items-center">Customer Type</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/customer_employee_type_yearly') }}"type="button" class="nav-link text-capitalize">Yearly</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/customer_employee_type_report') }}" type="button" class="nav-link text-capitalize active">Monthly</a>
                    </li>
                </ul>
            </div>
            
        </div>
    </div>    
    <div class="card-body">
        @php
            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];
            $days = range(1,31); // always show 1-31
            $yearShort = date('y'); // e.g., 25 for 2025
            $year = date('Y');

            use Carbon\Carbon;
            $monthNumber = date('m'); // August
            $CurrentMonth = str_pad($monthNumber,2,'0',STR_PAD_LEFT); // "08" or use: date('M', strtotime("2025-$monthNumber-01")) for "Aug"
            $CurrentMonthName = date('M');
            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $monthNumber, $year);
        @endphp
        <div class="d-flex flex-row justify-items-betwen gap-2 mb-6" style="flex-wrap: wrap;justify-content: space-between;">
            <div class="w-50 nav-align-top mb-2">
                <ul class="nav nav-pills flex-nowrap" role="tablist">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                        <div class="item">
                            <li class="nav-item">
                                <a href="{{'/manage_reports/customer_source_report_yearly'}}" type="button" class="nav-link text-capitalize">Customer Source</a>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item">
                                <a href="{{'/manage_reports/customer_drop_report_yearly'}}" type="button" class="nav-link text-capitalize">Drop Customer</a>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item">
                                <a href="{{ url('/manage_reports/customer_age_report_yearly') }}" type="button" class="nav-link text-capitalize">Gender</a>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item">
                                <a href="{{ url('/manage_reports/customer_employee_type_yearly') }}" type="button" class="nav-link text-capitalize active">Employee Type</a>
                            </li>
                        </div>
                        <button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>
            </div>

            <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-2" style="margin-inline: auto;">
                <div class="border border-primary search">
                    <input type="hidden" class="form-control" placeholder="" id="lead_src_name_year" value="{{ date('Y') }}">
                    <input type="hidden" class="form-control" placeholder="" id="lead_src_name_month" value="{{ date('m') }}">
                    <div style="width:100%">
                        <select class="select3 form-select" id="lead_src_name" data-placeholder="Select Employee Type" multiple>
                        </select>
                    </div>
                    <a class="search-btn" onclick="getLeadDetailsTable()" href="javascript:;" title="Reset selection">
                        <span class="mdi mdi-magnify fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Search"></span>
                    </a>
                    <a class="reset-btn" onclick="reset_options()" href="javascript:;" itle="Search">
                        <span class="mdi mdi-refresh fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reset"></span>
                    </a>
                </div>
            </div>

            <div class="d-flex gap-2 mb-2" style="margin-left: auto;">
                <ul class="nav nav-pills justify-content-end" role="tablist">
                    <li class="nav-item me-1">
                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary py-2"  data-bs-toggle="modal" data-bs-target="#kt_modal_course_package_vs_month" id="graph_div" style="display:none !important;">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Graph"><i class="mdi mdi-finance fs-3"></i></span>
                        </a>
                    </li>

                    <!-- Previous Month Button -->
                    <li class="nav-item me-1">
                        <a class="nav-link px-3"
                            href="javascript:;" id="prevMonthBtn">
                            <div class="text-center">
                            <span class="mdi mdi-arrow-left-circle-outline  fs-2" id=""></span>
                            </div>
                        </a>
                    </li>

                    <!-- Current Month Button (Active) -->
                    <li class="nav-item me-1">
                        <a class="nav-link active px-3 border border-dashed border-primary waves-effect waves-light"
                            href="javascript:;">
                            <div class="text-center">
                                <span class="fs-4 fw-semibold text-capitalize" id="selectedYear">{{$CurrentMonthName}} - {{$year}}</span>
                            </div>
                        </a>
                    </li>
                    <li class="nav-item me-1">
                        <a class="nav-link px-3"
                            href="javascript:;" id="nextMonthBtn">
                            <div class="text-center">
                            <span class="mdi mdi-arrow-right-circle-outline  fs-2" id=""></span>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="row mb-2">
            <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-6" style="flex-wrap: wrap;">
                <div class="col-lg-10 mx-3 mb-2 d-flex align-items-center justify-content-start gap-2 p-3 mb-6 border rounded border-primary py-3" style="flex-flow: wrap;max-width: fit-content;">
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #f3f9b8"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Current Day</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #c395ff"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Current Day Value</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #28a745"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Increased Value</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #dc3545"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Decreased Value</label>
                    </div>
                    <span>|</span>
                    <div class="d-flex align-items-center justify-content-start gap-2">
                        <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #3dc5e1"></span>
                        <span>-</span>
                        <label class="fs-6 fw-semibold text-black">Maintained Value</label>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="table-scroll-wrapper">
                    <!-- Top Scrollbar -->
                    <div class="top-scrollbar">
                        <div></div>
                    </div>
                    <div class="table-container">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 sticky_table" id="Monthly_lead_table">
                            <thead></thead>
                            <tbody class="text-black fw-semibold fs-3">
                            </tbody>
                            <tfoot class="text-black fw-semibold bg-light fs-3" id="Yearly_lead_footer"></tfoot>
                        </table>
                    </div>
                    <div class="bottom-scrollbar">
                        <div></div>
                    </div>
                </div>
            </div>
            <div id="total_container" style="display:none !important;">
                <!-- <div class="d-flex col-lg-12 mt-6 gap-2 justify-content-center">
                    <div class="counter-container">
                        <div class="counter fw-bold mb-2">
                            <span class="total_counts_txt" id="day_wise_grand_count_placed">00</span>
                        </div>
                        <h4 class="fs-5 fw-bold mb-0">Total Placed Students</h4>
                    </div>
                    <div class="counter-container">
                        <div class="counter fw-bold mb-2">
                            <span class="total_counts_txt" id="day_wise_grand_count_unplaced">00</span>
                        </div>
                        <h4 class="fs-5 fw-bold mb-0">Total Unplaced Students</h4>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Total Leads Vs Month-->
<div class="modal fade" id="kt_modal_course_package_vs_month" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" id="modal_Close" onclick="close_function()">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class="mb-4 text-black text-center" style="line-height: inherit;">Employee Type Wise Customer - <span id="chart_modal_head">Monthly</span></h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-4">
                        <div class="container text-center border border-gray-200 rounded p-3" style="min-height: auto">
                            <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-pie"></i> Employee Type Wise Customer Distribution <span id="FinishedPieChart_name"></span></h1>
                            <div id="FinishedPieChart-wrapper"><div id="FinishedPieChart"></div></div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-4">
                        <div class="container text-center border border-gray-200 rounded p-3" style="min-height: auto">
                            <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Daily Employee Type Wise Customer Distribution <span id="FinishedAreaChart_name"></span></h1>
                            <div id="FinishedAreaChart-wrapper"><div id="FinishedAreaChart"></div></div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Total Leads Vs Month-->

<script>

const now = new Date();
let currentYear = now.getFullYear();
let currentMonth = now.getMonth() + 1; // getMonth() returns 1–12
var trendcurrentMonth = new Date().getMonth(); // getMonth() returns 0–11
let currentDate = now.getDate();
var trendcurrentYear = now.getFullYear();

var selectedYear = currentYear;
let selectedMonth = currentMonth;

var months = @json($months);

var short_months = {
    1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr',
    5: 'May', 6: 'Jun', 7: 'Jul', 8: 'Aug',
    9: 'Sep', 10: 'Oct', 11: 'Nov', 12: 'Dec'
};
var days = @json($days);
var types = null;
var years = null;
var year_colors = null;
var leadTypes = null;
var pie_year_colors = null;
var types_list = null;
var Lead_types_list = null;
var type_keys = null;
var intern_data = null;
var pre_intern_data = null;
var totals = null;
var grandTotals = null;
var typeDayTotals = null;
var percentages = null;
var grandTypeTotals = null;
var typeMonthTotals = null;
var year = currentYear;
var type_count = 0;
var MonthTotalActiveTotals = null;
var MonthTotalExtendTotals = null;
var condi_months = null;
var inern_trend_data = null;
var comparison_area_active = [];
var comparison_area_extend = [];

var full_months = {
    1: 'January',
    2: 'February',
    3: 'March',
    4: 'April',
    5: 'May',
    6: 'June',
    7: 'July',
    8: 'August',
    9: 'September',
    10: 'October',
    11: 'November',
    12: 'December'
};

var type_colors = {
    'lead_count' : '#7239ea',
    'conversion_count' : '#ffc700'
};

let line_MonthColors = [
    null,
    '#2ECC71',
    '#27AE60',
    '#1ABC9C',
    '#16A085',
    '#3498DB',
    '#2980B9',
    '#9B59B6',
    '#8E44AD',
    '#F39C12',
    '#E67E22',
    '#E74C3C',
    '#C0392B'
];

let pie_MonthColors = [
    '#2ECC71',
    '#27AE60',
    '#1ABC9C',
    '#16A085',
    '#3498DB',
    '#2980B9',
    '#9B59B6',
    '#8E44AD',
    '#F39C12',
    '#E67E22',
    '#E74C3C',
    '#C0392B'
];

var chartExtendDaily = new ApexCharts(document.querySelector("#FinishedAreaChart"), {
    series: [],
    chart: {
        height: 350,
        type: 'area',
        toolbar: { show: true }
    },
    dataLabels: { 
        enabled: true
    },
    stroke: { curve: 'smooth'},
    markers: { size: 5 },
    xaxis: {
        categories: days,
        title: { text: '' } // Use Blade variable
    },
    yaxis: {
        title: { text: 'No of Customers' },
        labels: {
            formatter: function (val) {
                return val;
            }
        }
    },
    tooltip: {
        shared: true,
        intersect: false,
        x: {
            formatter: function (value) {
                return 'Day '+String(value ?? 0).padStart(2, '0') || 'Unknown Day'; // fallback if not found
            }
        },
        y: {
            formatter: function (value) {
                return value + " Customers"; // Customize label
            },
            title: {
                formatter: function (seriesName) {
                    return seriesName + ":";
                }
            }
        }
    },
    fill: {
        type: 'gradient', 
        gradient: { 
            shadeIntensity: 0.6, opacityFrom: 0.5, opacityTo: 0.2 
        }
    },
    legend: {
        position: 'bottom', // Must match the class you're targeting
        horizontalAlign: 'center',
        verticalAlign: 'center' // optionally, to help vertical placement
    }
});
chartExtendDaily.render();

$(document).ready(function () {

    document.getElementById("prevMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();

        if (currentMonth === 1) {
            currentMonth = 12;
            currentYear--;
        } else {
            currentMonth--;
        }

        selectedYear = currentYear;
        selectedMonth = currentMonth;

        updateMonthDisplay(selectedMonth, selectedYear);
        hide_year_arrow(selectedMonth, selectedYear);
    });

    document.getElementById("nextMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();

        if (currentMonth === 12) {
            currentMonth = 1;
            currentYear++;
        } else {
            currentMonth++;
        }

        selectedYear = currentYear;
        selectedMonth = currentMonth;

        updateMonthDisplay(selectedMonth, selectedYear);
        hide_year_arrow(selectedMonth, selectedYear);
    });

    updateMonthDisplay(selectedMonth, selectedYear);
    hide_year_arrow(selectedMonth, selectedYear);
});

function hide_year_arrow(selectedMonth, selectedYear) {
    const systemMonth = now.getMonth() + 1;
    const systemYear = now.getFullYear();

    if (parseInt(selectedMonth) === systemMonth && parseInt(selectedYear) === systemYear) {
        document.getElementById("nextMonthBtn").style.display = "none";
    } else {
        document.getElementById("nextMonthBtn").style.display = "inline-block";
    }
}

function updateMonthDisplay(selectMonth, selectedYear) {

    
    document.getElementById("lead_src_name_year").value = selectedYear;
    document.getElementById("lead_src_name_month").value = selectMonth;
    
    const src_select = document.getElementById('lead_src_name');
    const src_selectedValues = Array.from(src_select.selectedOptions).map(option => option.value);
    
    short_month_name = short_months[selectMonth] ?? '<?= date('M') ?>';
    month_name = months[selectMonth] ?? '<?= date('F') ?>';
    
    $("#selectedYear").text(`${short_month_name} - ${selectedYear}`); // Year Badge

    $("#FinishedPieChart_name").text(`${month_name} - ${selectedYear}`); // Chart Names
   
    $('#prevMonthBtn, #nextMonthBtn').prop('disabled', false);

    get_lead_src_list();
}

function get_lead_src_list() {

    const src_select = document.getElementById('lead_src_name');
    const src_selectedValues = Array.from(src_select.selectedOptions).map(option => option.value);
    var selectCatDropdown = $(`#lead_src_name`);

    $.ajax({
        url: "{{ route('get_lead_type_list') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                selectCatDropdown.empty().append('<option value="">Select Employee Type</option>');
                response.data.forEach(function(role) {
                    selectCatDropdown.append(
                        $('<option></option>').attr('value', role.sno).text(role.lead_type_name)
                    );
                });

                // Now that options are added, set the selected values and trigger change
                selectCatDropdown.val(src_selectedValues).trigger('change');
            } else {
                console.error('Unexpected response format or status:', response);
            }
        },
        error: function(error) {
            console.error('Error fetching Employee Type list:', error);
        }
    });

    getLeadDetailsTable();
}

function getLeadDetailsTable() {

    year = $('#lead_src_name_year').val().trim();
    month = $('#lead_src_name_month').val().trim();
    lead_src_name = $('#lead_src_name').val();

    $.ajax({
        url: '{{ route("cus_employee_type_report_data") }}',
        method: 'POST',
        dataType: 'json',
        data: {
            year: year,
            month: month,
            search_lead_src_fill: lead_src_name ?? '',
            _token: '{{ csrf_token() }}'
        },
        beforeSend: function () {
            Swal.fire({
                title: 'Processing...',
                text: 'Please wait while we load the data.',
                showConfirmButton: false,
                showCancelButton: false,
                allowOutsideClick: false,
                allowEscapeKey: false,
                customClass: {
                    confirmButton: 'd-none btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false,
                didOpen: () => {
                    Swal.showLoading();
                    document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
                    document.getElementById('total_container').style.setProperty('display', 'none', 'important');
                }
            });

            $('#Monthly_lead_table thead').html('');
            $('#Yearly_lead_footer').empty();
            $('#Monthly_lead_table tbody').html(`
                <tr><td colspan="100%" class="text-center">Loading...</td></tr>
            `);
        },
        success: function (data) {
            try {

                if (!data || typeof data !== 'object') {
                    throw new Error('Invalid response format');
                }

                months = data.months && typeof data.months === 'object' ? data.months : null;
                // year_colors = data.year_colors && typeof data.year_colors === 'object' ? data.year_colors : null;
                // pie_year_colors = Array.isArray(year_colors) ? year_colors : Object.values(year_colors || {});
                // short_months = data.short_months && typeof data.short_months === 'object' ? data.short_months : null;
                condi_months = Array.isArray(short_months) ? short_months : Object.values(short_months || {});
                // years = Array.isArray(data.years) ? data.years : Object.values(data.years || {});
                days = Array.isArray(data.days) ? data.days : Object.values(data.days || {});
                leadTypes = data.leadTypes && typeof data.leadTypes === 'object' ? data.leadTypes : null;
                types_list = data.types_list && typeof data.types_list === 'object' ? data.types_list : null;
                type_keys = Array.isArray(data.type_keys) ? data.type_keys : Object.values(data.type_keys || {});
                pie_MonthColors = Array.isArray(data.pie_MonthColors) ? data.pie_MonthColors : Object.values(data.pie_MonthColors || {});
                intern_data = data.inern_cal_data && typeof data.inern_cal_data === 'object' ? data.inern_cal_data : null;
                pre_intern_data = data.pre_inern_cal_data && typeof data.pre_inern_cal_data === 'object' ? data.pre_inern_cal_data : null;
                totals = data.totals && typeof data.totals === 'object' ? data.totals : null;
                // grandTotals = data.grandTotals && typeof data.grandTotals === 'object' ? data.grandTotals : null;
                grandTypeTotals = data.grandTypeTotals && typeof data.grandTypeTotals === 'object' ? data.grandTypeTotals : null;
                // typeDayTotals = data.typeDayTotals && typeof data.typeDayTotals === 'object' ? data.typeDayTotals : null;
                percentages = data.percentages && typeof data.percentages === 'object' ? data.percentages : null;
                typeMonthTotals = data.typeMonthTotals && typeof data.typeMonthTotals === 'object' ? data.typeMonthTotals : null;
                inern_trend_data = data.inern_trend_data && typeof data.inern_trend_data === 'object' ? data.inern_trend_data : null;
                type_count = parseInt(data.type_count) ?? 0;
                year = parseInt(data.year) ?? 0;

                // MonthTotalActiveTotals = typeMonthTotals && Array.isArray(typeMonthTotals.lead_count) ? typeMonthTotals.lead_count : Object.values(typeMonthTotals.lead_count || {});
                MonthTotalExtendTotals = typeMonthTotals && Array.isArray(typeMonthTotals.conversion_count) ? typeMonthTotals.conversion_count : Object.values(typeMonthTotals.conversion_count || {});
                Lead_types_list = Array.isArray(leadTypes) ? leadTypes : Object.keys(leadTypes || {});

                if (!months || !leadTypes || !types_list || !intern_data) {
                    throw new Error('Required data missing');
                }
                
                buildTableHeader();
                buildLeadsTable();
                create_pie_extend_chart(year);

            } catch (ex) {
                console.error('Data validation error:', ex);
                showNoDataRow(currentMonth,year);
            } finally {
                Swal.close();
            }
        },
        error: function (xhr, status, error) {
            Swal.close();

            let message = 'Failed to load data. Please try again later.';
            if(xhr.status === 0){
                message = 'Network error: Please check your internet connection.';
            } else if(xhr.status >= 500){
                message = 'Server error occurred. Please try again later.';
            } else if(xhr.status === 422){
                message = 'Validation error: Please check your input.';
            } else if(xhr.responseJSON && xhr.responseJSON.message){
                message = xhr.responseJSON.message;
            }

            console.error('Error loading data:', xhr.responseText);

            showNoDataRow(currentMonth,year);

            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: message,
                showConfirmButton: true,
                confirmButtonText: 'Close',
                allowOutsideClick: false,
                allowEscapeKey: false,
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light btn-md'
                },
                buttonsStyling: false
            });
        }
    });
}

function buildTableHeader() {

    var $thead = $('#Monthly_lead_table thead');
    $thead.empty();

    var daysInMonth = new Date(year, currentMonth, 0).getDate();

    let headerRow = `
    <tr class="bg-primary text-center fw-bold fs-6">
        <th class="min-w-150px sticky-col-left fs-5 text-wrap">Employee Type</th>`;
        days.forEach((d) => {
            if (d <= daysInMonth) {
                var row_class = (parseInt(year) === now.getFullYear() && parseInt(currentMonth) === now.getMonth() + 1 && parseInt(d) === currentDate) ? 'current-month-row' : '';
                var dayFormatted = String(d).padStart(2, '0');
                headerRow += `
                <th class="min-w-150px fs-5 text-center ${row_class}">
                    <label class="text-white fw-bold">Day ${dayFormatted}</label>
                </th>`;
            }
        });

    headerRow += `</tr>`;
    $thead.append(headerRow);
}

function buildLeadsTable() {

    var $tbody = $('#Monthly_lead_table tbody');
    $tbody.empty();

    let hasNonZeroData = false;
    
    
    var $table_footer = $('#Yearly_lead_footer');
    $table_footer.empty();
    
    $.each(leadTypes, function (leadTypes_id, leadTypes_Name) {
        
        // leadTypes_id = leadTypes_id.replace("type_", "");

        let leadsRow = `<tr>`;
        
        leadsRow += `<td class="sticky-col-left fs-5 hover_tr_class_${leadTypes_id}"><label class="fw-semibold fs-5 text-wrap">${leadTypes_Name}</label><div class="d-block mb-2 mt-2">
            <span class="bg-info text-white fs-4 py-2 px-2 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Customers">${ String(totals?.[leadTypes_id]?.['conversion_count'] ?? 0).padStart(2, '0') }</span>
        </div></td>`;

        // var td_index = 1;
        
        var daysInMonth = new Date(year, currentMonth, 0).getDate();

        $.each(types_list, function (type_key, type_name) {

            // if(td_index !== 1){
            //     leadsRow += `<tr>`;
            // }
            
            // leadsRow += `<td class="sticky-col-left sticky-col-second hover_td_class_${leadTypes_id}">
            //     <div class="fs-5 fw-semibold">${type_name}</div>
            //     <div class="d-flex flex-row align-items-center justify-content-center gap-2 mt-2 mb-3">
            //         <div class="d-block mb-2 mt-2">
            //             <span class="bg-warning text-black fs-4 py-2 px-2 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Leads">${String(totals[leadTypes_id]?.[type_key] ?? 0).padStart(2, '0')}</span>
            //         </div>
            //         ${ (type_key == 'conversion_count') ? '<div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-2"><span class="fs-4 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Conversions Percentage" style="color: #00246b !important;">'+(percentages[leadTypes_id] ?? 0)+'%</span></div>' : '' }
            //     </div>
            // </td>`;

            let prevLeads = null;
            
            var prevMonth = parseInt(currentMonth) - 1;
            var prevYear = parseInt(year) - 1;
            var predaysInMonth = new Date(year, currentMonth, 0).getDate();
            
            var day_wise_count_lead = 0;

            $.each(days, function (_, d) {

                if (d <= daysInMonth) {

                    const dayData = parseInt(intern_data[leadTypes_id]?.[d]?.[type_key]) ?? 0;
                    var dropPercentData = (percentages?.[leadTypes_id]?.[d] ?? 0);

                    // Check for non-zero data
                    if (dayData > 0) {
                        hasNonZeroData = true;
                    }

                    const r_systemMonth = now.getMonth() + 1;
                    const r_systemYear = now.getFullYear();
                    var isCurrentMonth = (parseInt(currentMonth) === r_systemMonth && parseInt(year) === r_systemYear);

                    if (parseInt(currentMonth) === 1 && parseInt(d) === 1) {
                        prevYear = parseInt(year) - 1;
                        prevMonth = 12;
                        predaysInMonth = new Date(prevYear, prevMonth, 0).getDate();
                        prevLeads = parseInt(pre_intern_data[leadTypes_id]?.[predaysInMonth]?.[type_key]) ?? 0;
                    }else if(parseInt(d) === 1){
                        prevYear = parseInt(year);
                        prevMonth = parseInt(currentMonth) - 1;
                        predaysInMonth = new Date(prevYear, prevMonth, 0).getDate();
                        prevLeads = parseInt(intern_data[leadTypes_id]?.[predaysInMonth]?.[type_key]) ?? 0;
                    }

                    // --- Leads color logic ---
                    let leadsBadgeColor = 'nutral_value'; // green default
                    const day = parseInt(d, 10);
                    var lead_enable_data = true;
                    if (isCurrentMonth) {
                        if (currentDate === day) {
                            leadsBadgeColor = 'current_day_value'; // today
                            lead_enable_data = true;
                        } else if (currentDate < day) {
                            leadsBadgeColor = 'nutral_value'; // future
                            lead_enable_data = false;
                        } else if (prevLeads !== null) {
                            if (dayData > prevLeads) leadsBadgeColor = 'incre_value'; // up
                            else if (dayData < prevLeads) leadsBadgeColor = 'decre_value'; // down
                            else leadsBadgeColor = 'main_value'; // same
                            lead_enable_data = true;
                        }
                    } else if (prevLeads !== null) {
                        if (dayData > prevLeads) leadsBadgeColor = 'incre_value';
                        else if (dayData < prevLeads) leadsBadgeColor = 'decre_value';
                        else leadsBadgeColor = 'main_value';
                        lead_enable_data = true;
                    }

                    prevLeads = parseInt(dayData) ?? 0;
                    day_wise_count_lead += parseInt(dayData ?? 0);
                    
                    leadsRow += `<td class="${ lead_enable_data ? 'hover_day_class_'+leadTypes_id+'_'+d+' ' : ''}text-center ${leadsBadgeColor}">
                        <label class="fw-semibold fs-3 text-black">${lead_enable_data ? String(dayData ?? 0).padStart(2, '0') : ''}</label>
                        <div class="d-block">
                            ${lead_enable_data ? '<span class="bg-white text-info fs-5 py-1 px-2 rounded">'+dropPercentData+'%</span>' : ''}
                        </div>
                    </td>`;
                } else {
                    td_leadsRow += `<td class="text-center">-</td>`;
                }

            });
            
            // td_index++;
        });

        leadsRow += `</tr>`;

        $tbody.append(leadsRow);

        scroll_option();

        document.getElementById('graph_div').style.setProperty('display', 'block', 'important');

    });

    hover_classes(leadTypes,days);
    
    $('[data-bs-toggle="tooltip"]').tooltip({ 'animation' : false });
    
    if (!hasNonZeroData) {
        showNoDataRow(currentMonth,year)
        document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
    }
}

function showNoDataRow(month_key, year) {
    $('#Monthly_lead_table tbody').html(`
        <tr>
            <td colspan="100%" class="text-left text-muted fw-semibold py-4 fs-4 px-6" style="text-align: left;">
                No Employee Type Data found for ${full_months[month_key] ?? '<?= date('M') ?>'} - ${year}.
            </td>
        </tr>
    `);
    $('#Yearly_lead_footer').empty();
    // get_pagination(null,false);
    document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
}

function fr_round(value, decimals) {
    return Number(Math.round(value + 'e' + decimals) + 'e-' + decimals);
}

function create_pie_extend_chart(year){

    var dataSeries = MonthTotalExtendTotals ? MonthTotalExtendTotals?.map(val => val ?? 0) ?? [] : [];
    var $wrapper = $('#FinishedPieChart-wrapper');
    
    // If no data or all 0s, show message
    var allZeros = dataSeries.every(val => val === 0);
        
    if (!dataSeries || dataSeries.length === 0 || allZeros) {
        $wrapper.html(`
        <div class="no-data-message fs-6" style="min-height: auto;align-content: space-evenly;">
            No data found
        </div>`);
        return;
    }
    
    // Clear wrapper and add chart container
    $wrapper.html('<div id="FinishedPieChart"></div>');
    
    var clickedIndex = null;
    var month_id = null; // assuming months is 1-based
    var month_name = 'None'; // assuming months is 1-based
    var trendData = [];
    var SourceColor = '#ffc700';

    var chartPieStudent = new ApexCharts(document.querySelector("#FinishedPieChart"), {
        series: dataSeries,
        chart: { type:'pie', height:350,
            events: {
                dataPointSelection: function(event, chartContext, config){
                    var clickedIndex = config.dataPointIndex;
                    if (comparison_area_extend[clickedIndex]) {
                        delete comparison_area_extend[clickedIndex];
                    } else {
                        clickedIndex = config.dataPointIndex;
                        month_id = Lead_types_list[clickedIndex] ?? 'None'; // assuming months is 1-based
                        month_name = leadTypes[month_id] ?? 'None'; // assuming months is 1-based
                        trendData = inern_trend_data[month_id] ?? [];
                        SourceColor = pie_MonthColors[clickedIndex] ?? '#ffc700';
                        console.log(leadTypes);
                        comparison_area_extend[clickedIndex] = {
                            name: month_name,
                            data: trendData.map(trendD => (trendD.conversion_count ?? 0)),
                            color: SourceColor
                        };
                    }
                    var seriesArray = Object.values(comparison_area_extend);
                    updateExtendTrendChart(seriesArray);
                }
            }
        },
        labels: Object.values(leadTypes ?? {}),
        colors: pie_MonthColors,
        title: { text: '' },
        legend: {
            position: 'right',
            fontSize: '14px',
            labels: {
                colors: 'black'
            },
            markers: {
                width: 14,
                height: 14,
                radius: 3
            }
        },
        tooltip: {
            y: {
                formatter: function (value) {
                    return value + " Customers"; // Customize label
                },
                title: {
                    formatter: function (seriesName) {
                        return seriesName + ":";
                    }
                }
            }
        },
        dataLabels: { enabled:true, formatter: function(val, opts){ return Math.round(opts.w.globals.seriesPercent[opts.seriesIndex]) + ' %'; } }
    });
    chartPieStudent.render();
}

function updateExtendTrendChart(seriesData = null) {
    if(seriesData !== null){
        chartExtendDaily.updateSeries(seriesData);
        chartExtendDaily.updateOptions({
            xaxis: { categories: days }
        });
    }else{
        chartExtendDaily.updateSeries([]);
        chartExtendDaily.updateOptions({
            xaxis: { categories: [] }
        });
    }
}

function close_function(){
    updateExtendTrendChart();
    comparison_area_extend = [];
}

function reset_options() {
    const reset_src_select = document.getElementById('lead_src_name');
    const reset_src_selectedValues = Array.from([]).map(option => option.value);
    var selectCatDropdown = $(`#lead_src_name`);
    selectCatDropdown.val(reset_src_selectedValues).trigger('change');
    getLeadDetailsTable()
}

function scroll_option() {
    const topScrollbar = document.querySelector(".top-scrollbar");
    const bottomScrollbar = document.querySelector(".bottom-scrollbar");
    const topScroller = topScrollbar.querySelector("div");
    const bottomScroller = bottomScrollbar.querySelector("div");

    const tableContainer = document.querySelector(".table-container");

    // Match widths
    topScroller.style.width = tableContainer.scrollWidth + "px";

    // Sync scrolls
    topScrollbar.addEventListener("scroll", function () {
        tableContainer.scrollLeft = topScrollbar.scrollLeft;
    });
    tableContainer.addEventListener("scroll", function () {
        topScrollbar.scrollLeft = tableContainer.scrollLeft;
    });

    bottomScroller.style.width = tableContainer.scrollWidth + "px";

    // Sync scrolls
    bottomScrollbar.addEventListener("scroll", function () {
        tableContainer.scrollLeft = bottomScrollbar.scrollLeft;
    });
    tableContainer.addEventListener("scroll", function () {
        bottomScrollbar.scrollLeft = tableContainer.scrollLeft;
    });
}

function hover_classes(e_months = null, e_days = null) {

    if (e_months !== null) {

        $.each(e_months, function (monthNumber, monthName) {

            // monthNumber = monthNumber.replace("type_", "");

            // Remove old listeners
            document.querySelectorAll(`.hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}`).forEach(el => {
                el.replaceWith(el.cloneNode(true));
            });

            // ============================
            // 🔹 Month-wise Hover
            // ============================

            // Hover on sub-row cell
            document.querySelectorAll(`.hover_td_class_${monthNumber}`).forEach(td => {
                td.addEventListener("mouseenter", () => {
                    highlight(td);

                    // highlight month header
                    let row = td.parentNode;
                    while (row) {
                        const rowspanCell = row.querySelector(`.hover_tr_class_${monthNumber}`);
                        if (rowspanCell) {
                            highlight(rowspanCell);
                            break;
                        }
                        row = row.previousElementSibling;
                    }

                    // 🔸 NEW: expand related day cells (height animation)
                    document.querySelectorAll(`[class^="hover_day_class_${monthNumber}_"]`).forEach(dayCell => {
                        highlight(dayCell,2);
                    });
                });

                td.addEventListener("mouseleave", () => {
                    resetMonth(monthNumber);
                });
            });

            // Hover on month header
            document.querySelectorAll(`.hover_tr_class_${monthNumber}`).forEach(td => {
                td.addEventListener("mouseenter", () => {
                    highlight(td);

                    // highlight ALL sub-row cells
                    let row = td.parentNode;
                    while (row) {
                        const hoverCell = row.querySelector(`.hover_td_class_${monthNumber}`);
                        if (hoverCell) highlight(hoverCell);
                        row = row.nextElementSibling;
                    }

                    // highlight all day cells
                    document.querySelectorAll(`[class^="hover_day_class_${monthNumber}_"]`).forEach(dayCell => {
                        highlight(dayCell,2);
                    });
                });

                td.addEventListener("mouseleave", () => {
                    resetMonth(monthNumber);
                });
            });

            // ============================
            // 🔹 Day-wise Hover
            // ============================
            if (e_days !== null) {
                $.each(e_days, function (day, d_monthName) {
                    document.querySelectorAll(`.hover_day_class_${monthNumber}_${day}`).forEach(td => {
                        td.addEventListener("mouseenter", () => {
                            // highlight the parent row's sub-cell
                            const row = td.closest("tr");
                            if (row) {
                                const rowCell = row.querySelector(`.hover_td_class_${monthNumber}`);
                                if (rowCell) highlight(rowCell);
                            }

                            // highlight the month header cell
                            let prevRow = td.parentNode;
                            while (prevRow) {
                                const monthHeader = prevRow.querySelector(`.hover_tr_class_${monthNumber}`);
                                if (monthHeader) {
                                    highlight(monthHeader);
                                    break;
                                }
                                prevRow = prevRow.previousElementSibling;
                            }
                        });

                        td.addEventListener("mouseleave", () => {
                            resetDay(monthNumber, day);
                        });
                    });
                });
            }
        });
    }

    // Highlight style
    function highlight(cell, type = 1) {
        cell.style.backgroundColor = "#f0913d";
        cell.style.color = "#000";
        cell.style.transition = "background-color 0.3s ease-out, color 0.3s ease-out, transform 0.3s ease-out, box-shadow 0.3s ease-out, height 0.3s ease-out";
        cell.style.transform = "translateZ(5px) scale(1.02)";
        if(type === 2){
            cell.style.borderTop = "4px solid #000";
            cell.style.borderBottom = "4px solid #000";
            cell.style.boxShadow = "0 0 12px 3px #f0913d";
        }else{
            cell.style.border = "2px solid #ffffff";
        }
    }

    // Reset month highlights
    function resetMonth(monthNumber) {
        document.querySelectorAll(`.hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}, [class^="hover_day_class_${monthNumber}_"]`).forEach(cell => {
            resetCell(cell);
        });
    }

    // Reset day highlights
    function resetDay(monthNumber, day) {
        document.querySelectorAll(
            `.hover_day_class_${monthNumber}_${day}, .hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}`
        ).forEach(cell => {
            resetCell(cell);
        });
    }

    // Reset helper
    function resetCell(cell) {
        cell.style.backgroundColor = "";
        cell.style.color = "";
        cell.style.transform = "";
        cell.style.border = "";
        cell.style.borderTop = "";
        cell.style.borderBottom = "";
        cell.style.boxShadow = "";
        cell.style.height = ""; // reset to default
    }
}
</script>

@endsection