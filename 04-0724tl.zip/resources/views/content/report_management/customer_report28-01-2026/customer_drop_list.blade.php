@extends('layouts/layoutMaster')

@section('title', 'Customer '.$report_heading.' - Monthly')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('content')

<style>
    .table-scroll-wrapper {
        position: relative;
        width: 100%;
    }

    .top-scrollbar {
        overflow-x: auto;
        overflow-y: hidden;
        height: 16px; /* top scrollbar height */
    }

    .top-scrollbar div {
        height: 1px;
    }

    .table-container {
        overflow-x: auto;
        overflow-y: auto;
        max-height: calc(99vh - 100px);
        /* width: 100%; */
    }

 /* Base table */
    .sticky_table { 
        border-collapse: collapse; 
        border: 1px solid #222222ff;  
        width: 100%; /* ensures horizontal scroll works */
    }

    /* Sticky header (all th) */
    .sticky_table thead th {
        position: sticky;
        top: 0;
        background: #39484f !important;
        color: #fff;
        text-align: center;
        vertical-align: middle;
        z-index: 50; /* default header z-index */
    }
    
    /* Table cells */
    .sticky_table th, 
    .sticky_table td { 
        padding: 0;                
        text-align: center;
        vertical-align: middle;
        width: 100px;               
        height: 100px;             
        min-width: 80px;           
        max-width: 80px;
        min-height: 80px;           
        max-height: 80px;
        overflow: hidden;
        white-space: nowrap;
        border: 1px solid #222222ff;  
    }


    .sticky_table th.sticky-col-left {
        position: sticky;
        left: 0;
        color: #fff;
        background: #39484f !important;
        z-index: 60;
        border-right: 1px solid #222222ff;
    }

    .sticky_table td.sticky-col-left {
        position: sticky;
        left: 0;
        color: #000;
        background-color: #fff;
        z-index: 15;
        border-right: 1px solid #222222ff;
    }


    .sticky_table td.sticky-col-second {
        position: sticky;
        left: 150px;     
        background: #fff; 
        color: #000;
        z-index: 10;      
        border-right: 1px solid #222222ff;
    }


    .sticky_table th.sticky-col-second {
        position: sticky;
        left: 150px;
        background: #39484f !important;
        color: #fff;
        z-index: 60;      
        border-right: 1px solid #222222ff;
    }

    /* .sticky_table .current-month-row {
        background: #f3f9b8 !important;
        color: #000;
    }

    .current-month-row label {
        color: black !important;
    } */

    .current-month-row td.sticky-col-left{
        background-color: #f3f9b8 !important;
        color: #000;
    }

    .year-vertical {
        writing-mode: vertical-rl;   /* rotates text vertically */
        transform: rotate(180deg);   /* makes it read top-to-bottom */
        white-space: nowrap;         /* avoid breaking year digits */
        vertical-align: middle;      /* keep it centered */
        text-align: center;
    }

    .chart-nav-item button {
        border: 2px solid #39484f !important;
    }

    .incre_value {
        background-color: #28a745 !important;
    }
    .decre_value {
        background-color: #dc3545 !important;
    }
    .main_value {
        background-color: #3dc5e1 !important;
    }
    .nutral_value {
        background-color: #fff !important;
    }
    .current_day_value {
        background-color: #c395ff !important;
    }

    .search {
      position: relative;
      background: #ffffff;
      border-radius: 40px;
      padding: 5px 10px;
      display: flex;
      align-items: center;
      width: 350px;
    }

    /* Buttons */
    .search-btn, .reset-btn {
      color: #ffffff;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: #39484f;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-left: 10px;
      cursor: pointer;
      transition: background 0.3s;
      flex-shrink: 0;
    }

    .search span.select2-selection.select2-selection--multiple {
        border: none !important;
        border-radius: 8px 0px 0px 12px;
        width: 232px;
    }

    .search-btn:hover, .reset-btn:hover{
        color : #fff;
    }
</style>

<style id="my-style-id"></style>

<style>
    /* Sticky header (all th) */
    .sticky_table tfoot tr {
        position: sticky;
        bottom: 0;
        background: #39484f !important;
        color: #000;
        text-align: center;
        vertical-align: middle;
        z-index: 50; /* default header z-index */
    }

    .sticky_table tfoot td.sticky-col-left {
        position: sticky;
        left: 0;
        bottom:0;
        color: #000;
        background: #39484f !important;
        z-index: 15;
        border-right: 1px solid #ccc;
    }

    .sticky_table tfoot td.sticky-col-second {
        position: sticky;
        left: 150px;
        bottom: 0;
        background: #39484f !important;
        color: #000;
        z-index: 10;      
        border-right: 1px solid #ccc;
    }
    /* td.sticky-col-left_2 {
        position: sticky;
        color: #000;
        z-index: 15;
        border-right: 0px solid #222222ff;
        left: 50%;
        max-width: -webkit-fill-available;
    } */
</style>

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1 d-flex align-items-center justify-content-between gap-2">
        <div>
            <h5 class="card-title mb-1">Customer {{ $report_heading }} - Monthly</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Business {{ $report_heading }}</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="{{ url('/manage_reports/customer_report_yearly') }}" class="d-flex align-items-center">Customer {{ $report_heading }}</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="{{ url('/manage_reports/customer_drop_report_yearly') }}" class="d-flex align-items-center">Drop Customer</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/customer_drop_report_yearly') }}"type="button" class="nav-link text-capitalize">Yearly</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/customer_drop_report') }}" type="button" class="nav-link text-capitalize active" >Monthly</a>
                    </li>
                </ul>
            </div>
            
        </div>
    </div>    
    <div class="card-body">
        @php
            $year = date('Y');
        @endphp
        <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-6">
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                        <a href="{{'/manage_reports/customer_drop_report_yearly'}}" type="button" class="nav-link text-capitalize active">Drop Customer</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{'/manage_reports/customer_source_report_yearly'}}" type="button" class="nav-link text-capitalize">Customer Source</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/customer_age_report_yearly') }}" type="button" class="nav-link text-capitalize">Gender</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/customer_employee_type_yearly') }}" type="button" class="nav-link text-capitalize">Employee Type</a>
                    </li>
                </ul>
            </div>
            <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-2">
                <ul class="nav nav-pills justify-content-end" role="tablist">
                    <li class="nav-item me-1">
                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary py-2"  data-bs-toggle="modal" data-bs-target="#kt_modal_course_package_vs_year" id="graph_div" style="display:none !important;">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Graph"><i class="mdi mdi-finance fs-3"></i></span>
                        </a>
                    </li>
                    
                    <!-- Previous Month Button -->
                    <li class="nav-item me-1">
                        <a class="nav-link px-3"
                            href="javascript:;" id="prevMonthBtn">
                            <div class="text-center">
                            <span class="mdi mdi-arrow-left-circle-outline  fs-2" id=""></span>
                            </div>
                        </a>
                    </li>

                    <!-- Current Month Button (Active) -->
                    <li class="nav-item me-1">
                        <a class="nav-link active px-3 border border-dashed border-info"
                            href="javascript:;">
                            <div class="text-center">
                                <span class="fs-4 fw-semibold text-capitalize" id="selectedYear">{{$year}}</span>
                            </div>
                        </a>
                    </li>
                    <li class="nav-item me-1">
                        <a class="nav-link px-3"
                            href="javascript:;" id="nextMonthBtn">
                            <div class="text-center">
                            <span class="mdi mdi-arrow-right-circle-outline  fs-2" id=""></span>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-lg-10 mx-3 mb-2 d-flex align-items-center justify-content-start gap-2  mb-6 border rounded border-primary py-3" style="flex-flow: wrap;max-width: fit-content;">
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #f3f9b8"></span>
                    <span>-</span>
                    <label class="fs-6 fw-semibold text-black">Current Month</label>
                </div>
                <span>|</span>
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #c395ff"></span>
                    <span>-</span>
                    <label class="fs-6 fw-semibold text-black">Current Day</label>
                </div>
                <span>|</span>
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #28a745"></span>
                    <span>-</span>
                    <label class="fs-6 fw-semibold text-black">Increased Value</label>
                </div>
                <span>|</span>
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #dc3545"></span>
                    <span>-</span>
                    <label class="fs-6 fw-semibold text-black">Decreased Value</label>
                </div>
                <span>|</span>
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #3dc5e1"></span>
                    <span>-</span>
                    <label class="fs-6 fw-semibold text-black">Maintained Value</label>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="table-scroll-wrapper">
                    <!-- Top Scrollbar -->
                    <div class="top-scrollbar">
                        <div></div>
                    </div>
                    <div class="table-container">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 sticky_table">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-150px sticky-col-left fs-5 text-center">Month - Year</th>
                                    <th class="min-w-150px sticky-col-left sticky-col-second fs-5 text-center">
                                        <div class="d-flex flex-column justify-content-center">
                                            <label class="fw-semibold fs-5">Customers</label>
                                            <label class="fw-semibold fs-5">Drops</label>
                                        </div>
                                    </th>
                                    @foreach($days as $day)
                                        <th class="min-w-150px fs-5 text-center">Day {{ sprintf('%02d', $day) }}</th>
                                    @endforeach
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7" id="Monthly_lead_table">
                            </tbody>
                            <tfoot class="text-black fw-semibold fs-3" id="Yearly_lead_footer"></tfoot>
                        </table>
                    </div>
                    <div class="bottom-scrollbar">
                        <div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Total Leads Vs Month-->
<div class="modal fade" id="kt_modal_course_package_vs_year" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" onclick="close_function()">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body px-2 py-2 position-relative">
                <div class="rounded-4 border-1 px-5 pt-5">
                    <div class="mb-6">
                        <h3 class=" mb-4 text-black text-center">Customer Vs Drop (Monthly) </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-4" id="all_month_area_div">
                            <div class="container text-center border rounded p-3" style="min-height: auto">
                                <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Monthly Customers vs Drops Trend (<span id="all_month_area_name"><?= date('Y') ?></span>)</h1>
                                <div id="all_month_area-wrapper"><div id="all_month_area"></div></div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6" id="month_customer_pie_div">
                            <div class="col-lg-12 mb-4">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-pie"></i> Monthly Customers Distribution (<span id="month_customer_pie_name"><?= date('Y') ?></span>)</h1>
                                    <div id="month_customer_pie-wrapper"><div id="month_customer_pie"></div></div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-4">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Daily Customers Distribution(<span id="month_customer_area_name"><?= date('Y') ?></span>)</h1>
                                    <div id="month_customer_area-wrapper"><div id="month_customer_area"></div></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6" id="month_drop_pie_div">
                            <div class="col-lg-12 mb-4">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-pie"></i> Monthly Drops Distribution (<span id="month_drop_pie_name"><?= date('Y') ?></span>)</h1>
                                    <div id="month_drop_pie-wrapper"><div id="month_drop_pie"></div></div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-4">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Daily Drops Distribution (<span id="month_drop_area_name"><?= date('Y') ?></span>)</h1>
                                    <div id="month_drop_area-wrapper"><div id="month_drop_area"></div></div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="col-md-6">
                            <div class="col-lg-12 mb-4" id="drop_reason_pie_div">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-pie"></i> Reasons for Drop (<span id="drop_reason_pie_name"><?= date('Y') ?></span>)</h1>
                                    <div id="drop_reason_pie-wrapper"><div id="drop_reason_pie"></div></div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-4" id="drop_reason_area_div">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Drop Count by Reason (<span id="drop_reason_area_name"><?= date('Y') ?></span>)</h1>
                                    <div id="drop_reason_area-wrapper"><div id="drop_reason_area"></div></div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="d-flex justify-content-end align-items-end mt-6 mb-4">
                        <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal" onclick="close_function()">Close</a>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Total Leads Vs Month-->

<script>

    const now = new Date();
    var currentYear = new Date().getFullYear();
    var selectedYear = currentYear;
    var currentMonth = new Date().getMonth() + 1;
    var currentDay = now.getDate();
    var days = @json($days);

    var months = null;
    var year = null;
    var customerData = null;
    var pre_customerData = null;
    var pre_dropData = null;
    var dropData = null;
    var dropPercent = null;
    var monthTotals = null;
    var customerTrendData = null;
    var dropTrendData = null;
    var grandTotals = null;
    var dropReasons = null;
    var dropReasonData = null;
    var condi_months = [];

    // Build arrays of total customers and drops per month
    var monthlyCustomerTotals = null;
    var monthlyDropTotals = null;

    let comparison_area_lead = [];
    let comparison_area_conv = [];

    const line_MonthColors = [
        null,
        'hsl(220,65%,55%)',
        'hsl(250,65%,55%)',
        'hsl(280,65%,55%)',
        'hsl(310,65%,55%)',
        'hsl(340,65%,55%)',
        'hsl(10,65%,55%)',
        'hsl(40,65%,55%)',
        'hsl(70,65%,55%)',
        'hsl(100,65%,55%)',
        'hsl(130,65%,55%)',
        'hsl(160,65%,55%)',
        'hsl(190,65%,55%)'
    ];

    const pie_MonthColors = [
        'hsl(220,65%,55%)',
        'hsl(250,65%,55%)',
        'hsl(280,65%,55%)',
        'hsl(310,65%,55%)',
        'hsl(340,65%,55%)',
        'hsl(10,65%,55%)',
        'hsl(40,65%,55%)',
        'hsl(70,65%,55%)',
        'hsl(100,65%,55%)',
        'hsl(130,65%,55%)',
        'hsl(160,65%,55%)',
        'hsl(190,65%,55%)'
    ];

    var chartAllMonths = new ApexCharts(document.querySelector("#all_month_area"), {
        series: [],
        chart: {
            height: 350,
            type: 'area',
            toolbar: { show: true }
        },
        dataLabels: { enabled: true },
        stroke: { curve: 'smooth'},
        markers: { size: 5 },
        xaxis: {
            categories: [],
            title: { text: `Month (${currentYear})` } // Use Blade variable
        },
        yaxis: {
            title: { text: 'Total Customers / Drops' }
        },
        tooltip: {
            shared: true,
            intersect: false
        },
        legend: {
            position: 'top'
        }
    });
    chartAllMonths.render();

    // Empty Line Chart for trend
    var chartMonthCustomers = new ApexCharts(document.querySelector("#month_customer_area"), {
        chart: { type:'area', height:350 },
        series: [],
        xaxis: {
            categories: days,
            title: {
                text: '', // 🔹 X-axis heading
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333'
                }
            }
        },
        yaxis: {
            title: {
                text: 'Number of Customers', // 🔹 Y-axis heading
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333'
                }
            }
        },
        title: { text:'' },
        stroke: { curve:'smooth' },
        tooltip: {
            shared: true,
            intersect: false,
            x: {
                format: 'dd' // Or 'HH:mm' for time
            },
            y: {
                formatter: function (value) {
                    return value + " Customers"; // Customize label
                },
                title: {
                    formatter: function (seriesName) {
                        return seriesName + ":";
                    }
                }
            }
        },
        legend: {
            position: 'bottom', // Must match the class you're targeting
            horizontalAlign: 'center',
            verticalAlign: 'center' // optionally, to help vertical placement
        }
    });
    chartMonthCustomers.render();

    var chartMonthDrops = new ApexCharts(document.querySelector("#month_drop_area"), {
        chart: { type:'area', height:350 },
        series: [],
        xaxis: {
            categories: days,
            title: {
                text: '', // 🔹 X-axis heading
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333'
                }
            }
        },
        yaxis: {
            title: {
                text: 'Number of Drops', // 🔹 Y-axis heading
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333'
                }
            }
        },
        title: { text:'' },
        stroke: { curve:'smooth' },
        tooltip: {
            shared: true,
            intersect: false,
            x: {
                format: 'dd' // Or 'HH:mm' for time
            },
            y: {
                formatter: function (value) {
                    return value + " Drops"; // Customize label
                },
                title: {
                    formatter: function (seriesName) {
                        return seriesName + ":";
                    }
                }
            }
        },
        legend: {
            position: 'bottom', // Must match the class you're targeting
            horizontalAlign: 'center',
            verticalAlign: 'center' // optionally, to help vertical placement
        }
    });
    chartMonthDrops.render();

    $(document).ready(function () {

        $('#prevMonthBtn').on('click', function (e) {
            e.preventDefault();
            selectedYear--;
            updateMonthDisplay(selectedYear);
            hideYearArrow(selectedYear);
        });

        $('#nextMonthBtn').on('click', function (e) {
            e.preventDefault();
            selectedYear++;
            updateMonthDisplay(selectedYear);
            hideYearArrow(selectedYear);
        });

        updateMonthDisplay(selectedYear);
        hideYearArrow(selectedYear);
    });

    function hideYearArrow(year) {
        if(parseInt(year) === currentYear){
            $('#nextMonthBtn').hide();
        } else {
            $('#nextMonthBtn').show();
        }
    }

    function updateMonthDisplay(year) {

        $("#selectedYear,#all_month_area_name,#month_customer_pie_name,#month_customer_area_name,#month_drop_pie_name,#month_drop_area_name,#drop_reason_pie_name,#drop_reason_area_name").text(year);
    
        $('#prevMonthBtn, #nextMonthBtn').prop('disabled', false);

        if(year === currentYear){
            $('#nextMonthBtn').prop('disabled', true);
        }

        getLeadDetailsTable(year);
    }

    function getLeadDetailsTable(year) {

        $.ajax({
            url: '{{ route("customer_drop_report_data") }}',
            method: 'POST',
            dataType: 'json',
            data: {
                year: year,
                _token: '{{ csrf_token() }}'
            },
            beforeSend: function () {

                $('#prevMonthBtn, #nextMonthBtn').prop('disabled', true);

                Swal.fire({
                    title: 'Processing...',
                    text: 'Please wait while we load the data.',
                    showConfirmButton: false,
                    showCancelButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    customClass: {
                        confirmButton: 'd-none btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false,
                    didOpen: () => {
                        Swal.showLoading();
                        document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
                    }
                });

                $('#Yearly_lead_footer').empty();
                $('#Monthly_lead_table').html('<tr><td colspan="100%" class="text-center">Loading...</td></tr>');
            },
            success: function (data) {
                try {

                    if (!data || typeof data !== 'object') {
                        throw new Error('Invalid response format');
                    }

                    months = data.months && typeof data.months === 'object' ? data.months : null;
                    year = data.year ?? '<?= date('Y') ?>';
                    currentYear = parseInt(data.currentYear) ?? '<?= date('Y') ?>';
                    currentMonth = parseInt(data.currentMonth) ?? '<?= date('n') ?>';
                    currentDay = data.currentDay ?? '<?= date('j') ?>';
                    customerData = data.customerData && typeof data.customerData === 'object' ? data.customerData : null;
                    pre_customerData = data.pre_customerData && typeof data.pre_customerData === 'object' ? data.pre_customerData : null;
                    dropData = data.dropData && typeof data.dropData === 'object' ? data.dropData : null;
                    customerTrendData = data.customerTrendData && typeof data.customerTrendData === 'object' ? data.customerTrendData : null;
                    dropTrendData = data.dropTrendData && typeof data.dropTrendData === 'object' ? data.dropTrendData : null;
                    pre_dropData = data.pre_dropData && typeof data.pre_dropData === 'object' ? data.pre_dropData : null;
                    dropPercent = data.dropPercent && typeof data.dropPercent === 'object' ? data.dropPercent : null;
                    monthTotals = data.monthTotals && typeof data.monthTotals === 'object' ? data.monthTotals : null;
                    grandTotals = data.grandTotals && typeof data.grandTotals === 'object' ? data.grandTotals : null;
                    dropReasons = Array.isArray(data.dropReasons) ? data.dropReasons : null;
                    dropReasonData = data.dropReasonData && typeof data.dropReasonData === 'object' ? data.dropReasonData : null;
                    reasonColors = Array.isArray(data.reasonColors) ? data.reasonColors : null;

                    condi_months = Array.isArray(months) ? months : Object.values(months || {});

                    monthlyCustomerTotals = condi_months.map((_, i) => monthTotals?.[i + 1]?.customers ?? 0);
                    monthlyDropTotals = condi_months.map((_, i) => monthTotals?.[i + 1]?.drops ?? 0);
                    
                    // console.log('monthlyCustomerTotals');
                    // console.log(monthlyCustomerTotals);
                    // console.log('monthlyDropTotals');
                    // console.log(monthlyDropTotals);

                    if (!months || !year || !dropData || !customerData) {
                        throw new Error('Required data missing');
                    }

                    buildLeadsTable(year);
                    overall_month_lead_chart(year);
                    create_pie_chart_lead(year);
                    create_pie_chart_conv(year);
                    updateTrendChart([]);
                    updateDropTrendChart([]);
                    // create_pie_chart_reasons();
                    comparison_area_lead = [];
                    comparison_area_conv = [];
                } catch (ex) {
                    console.error('Data validation error:', ex);
                    showNoDataRow(year);
                } finally {
                    Swal.close();
                    $('#prevMonthBtn, #nextMonthBtn').prop('disabled', false);
                }
            },
            error: function (xhr, status, error) {
                Swal.close();
                $('#prevMonthBtn, #nextMonthBtn').prop('disabled', false);

                let message = 'Failed to load data. Please try again later.';
                if(xhr.status === 0){
                    message = 'Network error: Please check your internet connection.';
                } else if(xhr.status >= 500){
                    message = 'Server error occurred. Please try again later.';
                } else if(xhr.status === 422){
                    message = 'Validation error: Please check your input.';
                } else if(xhr.responseJSON && xhr.responseJSON.message){
                    message = xhr.responseJSON.message;
                }

                console.error('Error loading data:', xhr.responseText);

                showNoDataRow(year);

                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: message,
                    showConfirmButton: true,
                    confirmButtonText: 'Close',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light btn-md'
                    },
                    buttonsStyling: false
                });
            }
        });
    }

    function buildLeadsTable(year) {
        try {
            const $table = $('#Monthly_lead_table');
            $table.empty();

            let hasAnyData = false;

            const today = new Date().getDate();

            const $table_footer = $('#Yearly_lead_footer');
            $table_footer.empty();

            // let leadsFooterRow = `<tr class="tfoot-leads">`;
            //     leadsFooterRow += `<td rowspan="2" class="sticky-col-left fs-5">Grand Total</td>`;
            //     leadsFooterRow += `<td class="sticky-col-left sticky-col-second fs-5"><div class="fs-5 fw-semibold">Customers</div>
            //     <div class="d-block mb-2 mt-2">
            //         <span class="bg-info text-white fs-4 py-2 px-2 rounded" id="day_wise_grand_count_lead" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Grand Total Customers">00</span>
            //     </div></td>`;

            // // 🔸 Drops Row
            // let conversionFooterRow = `<tr class="tfoot-conversion">`;
            //     conversionFooterRow += `<td class="sticky-col-left sticky-col-second fs-5"><div class="fs-5 fw-semibold mt-4">Drops</div>
            //     <div class="d-block mb-2 mt-2">
            //         <span class="bg-info text-white fs-4 py-2 px-2 rounded" id="day_wise_grand_count_conv" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Grand Total Drops">00</span>
            //     </div>
            // </td>`;


            var grand_day_wise_count_lead = 0;
            var grand_day_wise_count_conv = 0;

            const YearWiseLeads = grandTotals.customers ?? {};
            const YearWiseConv = grandTotals.drops ?? {};

            $.each(months, function (monthNumber, monthName) {

                var daysInMonth = new Date(year, monthNumber, 0).getDate();

                var pre_daysInMonth = new Date(parseInt(year) - 1, 12, 0).getDate();

                var isCurrentMonth = (parseInt(monthNumber) === currentMonth && parseInt(year) === currentYear);

                var isPreMonth = (parseInt(year) < currentYear) || (parseInt(year) === currentYear && parseInt(monthNumber) < currentMonth);

                var rowClass = isCurrentMonth ? 'current-month-row' : '';
                var tdClass = isCurrentMonth ? 'text-black' : '';

                var monthTotalsData = monthTotals[monthNumber] || { customers: 0, drops: 0 };

                let leadsRow = `<tr class="${rowClass}">`;
                let conversionRow = `<tr class="${rowClass}">`;

                leadsRow += `<td rowspan="2" style="white-space: pre-wrap;" class="sticky-col-left fs-5 ${tdClass} hover_tr_class_${monthNumber}">${monthName} - ${year}</td>`;

                leadsRow += `<td class="sticky-col-left sticky-col-second ${tdClass} hover_td_class_${monthNumber}"><div class="fs-5 fw-semibold">Customers</div>
                    <div class="d-block mt-2">
                        <span class="bg-warning text-black fs-4 py-2 px-2 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Customers">${ String(monthTotalsData.customers ?? 0).padStart(2, '0') }</span>
                    </div>
                </td>`;

                conversionRow += `<td class="sticky-col-left sticky-col-second ${tdClass} hover_td_class_${monthNumber}"><div class="fs-5 fw-semibold mt-4">Drops</div>
                    <div class="d-block mb-2 mt-2">
                        <span class="bg-warning text-black fs-4 py-2 px-2 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Drops">${ String(monthTotalsData.drops ?? 0).padStart(2, '0') }</span>
                    </div>
                </td>`;

                // Initialize previous values using previous month's last day
                let prevMonth = parseInt(monthNumber) - 1;
                var prevLeads = 0;
                var prevConvr = 0;
                var prevMonthDays = new Date(year, prevMonth, 0).getDate();
              
                var day_wise_count_lead = 0;
                var day_wise_count_conv = 0;

                $.each(days, function (_, d) {

                    if (d <= daysInMonth) {

                        var dayDataCustomer = parseInt(customerData[monthNumber]?.[d]) ?? 0;
                        var dayDataDrops = parseInt(dropData[monthNumber]?.[d]) ?? 0;
                        var dropPercentData = parseInt(dropPercent[monthNumber]?.[d]) ?? 0;

                        if (dayDataCustomer > 0 || dayDataDrops > 0) {
                            hasAnyData = true;
                        }

                        // if (parseInt(monthNumber) === 1 && parseInt(d) === 1) {
                        //     prevLeads = parseInt(pre_customerData[12]?.[pre_daysInMonth]) ?? 0;
                        //     prevConvr = parseInt(pre_dropData[12]?.[pre_daysInMonth]) ?? 0;
                        // }else{
                        //     var prevMonthDays = new Date(year, prevMonth, 0).getDate();
                        //     prevLeads = customerData[prevMonth]?.[prevMonthDays] ?? 0;
                        //     prevConvr = dropData[prevMonth]?.[prevMonthDays] ?? 0;
                        // }

                        if (parseInt(monthNumber) === 1 && parseInt(d) === 1) {
                            prevMonthDays = pre_daysInMonth;
                            prevLeads = parseInt(pre_customerData[12]?.[prevMonthDays]) ?? 0;
                            prevConvr = parseInt(pre_dropData[12]?.[prevMonthDays]) ?? 0;
                        }else {
                            if (parseInt(monthNumber) !== 1 && parseInt(d) === 1) {
                                prevMonthDays = new Date(year, prevMonth, 0).getDate();
                                prevLeads = customerData[prevMonth]?.[prevMonthDays] ?? 0;
                                prevConvr = dropData[prevMonth]?.[prevMonthDays] ?? 0;
                            }
                        }

                        // ----- Leads Row -----
                        let badgeColor = 'nutral_value';
                        const day = parseInt(d, 10);
                        var lead_enable_data = true;
                        if (isCurrentMonth) {
                            if (today === day) {
                                badgeColor = 'current_day_value'; // today
                                lead_enable_data = true;
                            } else if (today < day) {
                                badgeColor = 'nutral_value'; // future
                                lead_enable_data = false;
                            } else if (prevLeads !== null) {
                                if (dayDataCustomer > prevLeads) badgeColor = 'incre_value'; // up
                                else if (dayDataCustomer < prevLeads) badgeColor = 'decre_value'; // down
                                else badgeColor = 'main_value'; // same
                                lead_enable_data = true;
                            }
                        } else if (prevLeads !== null) {
                            if (dayDataCustomer > prevLeads) badgeColor = 'incre_value';
                            else if (dayDataCustomer < prevLeads) badgeColor = 'decre_value';
                            else badgeColor = 'main_value';
                            lead_enable_data = true;
                        }

                        day_wise_count_lead += parseInt(dayDataCustomer);

                        prevLeads = dayDataCustomer ?? 0;
                        
                        leadsRow += `<td class="${ lead_enable_data ? 'hover_day_class_'+monthNumber+'_'+d+' ' : ''}text-center ${badgeColor}">
                        <label class="fw-semibold fs-3 text-black">
                            ${ lead_enable_data ?  String(dayDataCustomer ?? 0).padStart(2, '0') : ''}
                        </label>
                        </td>`;
                        
                        
                        // ----- Conversion Row -----
                        badgeColor = 'nutral_value';
                        var conv_enable_data = true;
                        if (isCurrentMonth) {                            
                            if (today === day) {
                                badgeColor = 'current_day_value'; // today
                                conv_enable_data = true;
                            } else if (today < day) {
                                badgeColor = 'nutral_value'; // future
                                conv_enable_data = false;
                            } else if (prevConvr !== null) {
                                if (dayDataDrops > prevConvr) badgeColor = 'incre_value'; // up
                                else if (dayDataDrops < prevConvr) badgeColor = 'decre_value'; // down
                                else badgeColor = 'main_value'; // same
                                conv_enable_data = true;
                            }
                        } else if (prevConvr !== null) {
                            if (dayDataDrops > prevConvr) badgeColor = 'incre_value';
                            else if (dayDataDrops < prevConvr) badgeColor = 'decre_value';
                            else badgeColor = 'main_value';
                            conv_enable_data = true;
                        }
                        
                        day_wise_count_conv += parseInt(dayDataDrops);

                        prevConvr = dayDataDrops;

                        // YearWiseLeads[d] += parseInt(dayDataCustomer);
                        // YearWiseConv[d] += parseInt(dayDataDrops);

                        conversionRow += `<td class="${ lead_enable_data ? 'hover_day_class_'+monthNumber+'_'+d+' ' : ''}text-center ${badgeColor}">
                            <label class="fw-semibold fs-3 text-black">
                                ${ conv_enable_data ? String(dayDataDrops).padStart(2, '0') : '' }
                            </label>
                            <div class="d-block">
                                ${conv_enable_data ? '<span class="bg-white text-info fs-5 py-1 px-2 rounded">'+dropPercentData+'%</span>' : ''}
                            </div>
                        </td>`;


                    } else {
                        leadsRow += '<td class="text-center"></td>';
                        conversionRow += '<td class="text-center"></td>';
                    }
                });

                leadsRow += `</tr>`;
                conversionRow += `</tr>`;
                
                $table.append(leadsRow).append(conversionRow);

                scroll_option();

                document.getElementById('graph_div').style.setProperty('display', 'block', 'important');
            });
            
            // $.each(days, function (_, d) {
            //     leadsFooterRow += `<th class="text-center">
            //     <label class="fw-semibold fs-3 text-black">${ String(YearWiseLeads[d]).padStart(2, '0') }</label>
            //     </th>`;
            //     conversionFooterRow += `<th class="text-center">
            //     <label class="fw-semibold fs-3 text-black">${ String(YearWiseConv[d]).padStart(2, '0') }</label>
            //     </th>`;

            //     grand_day_wise_count_lead += parseInt(YearWiseLeads[d]) ?? 0;
            //     grand_day_wise_count_conv += parseInt(YearWiseConv[d]) ?? 0;

            // });
            
            // leadsFooterRow += `</tr>`;
            // conversionFooterRow += `</tr>`;
            
            // $table_footer.append(leadsFooterRow).append(conversionFooterRow);
            
            // $(`#day_wise_grand_count_lead`).text(String(grand_day_wise_count_lead).padStart(2, '0'));
            // $(`#day_wise_grand_count_conv`).text(String(grand_day_wise_count_conv).padStart(2, '0'));

            hover_classes(months,days);
            
            $('[data-bs-toggle="tooltip"]').tooltip({ 'animation' : false });
            
            if (!hasAnyData) {
                showNoDataRow(year);
            }

        } catch (ex) {
            console.error('Error building leads table:', ex);
            showNoDataRow(year);
        }
    }

    function overall_month_lead_chart(p_year) {
        chartAllMonths.updateSeries([
            {
                name: 'Total Customers',
                data: monthlyCustomerTotals?.map(val => val ?? 0) ?? [],
                color: '#1E90FF'
            },
            {
                name: 'Total Drops',
                data: monthlyDropTotals?.map(val => val ?? 0) ?? [],
                color: '#FF4500'
            }
        ]);
        chartAllMonths.updateOptions({
            xaxis: {
                categories: condi_months ?? [],
                title: { text: `Month (${p_year})` }
            }
        });
    }

    function create_pie_chart_lead(selectedYear){
    
        const dataSeries = monthlyCustomerTotals ? monthlyCustomerTotals?.map(val => val ?? 0) ?? [] : [];
        const $wrapper = $('#month_customer_pie-wrapper');
        
        // If no data or all 0s, show message
        const allZeros = dataSeries.every(val => val === 0);

        var currentYear = new Date().getFullYear();
        var is_current = (parseInt(selectedYear) === parseInt(currentYear)) ? true : false;
            
        if (!dataSeries || dataSeries.length === 0 || allZeros) {
            $('#month_customer_pie_div').hide();
            $('#month_drop_pie_div').removeClass('col-md-6').addClass('col-md-12');
            $wrapper.html(`
            <div class="no-data-message fs-6" style="min-height: auto;align-content: space-evenly;">
            No data found
                </div>
                `);
            return;
        }
        
        $('#month_customer_pie_div').show();
        $('#month_drop_pie_div').removeClass('col-md-12').addClass('col-md-6');
        // Clear wrapper and add chart container
        $wrapper.html('<div id="month_customer_pie"></div>');
        
        var clickedIndex = null;

        var chartLeads = new ApexCharts(document.querySelector("#month_customer_pie"), {
            series: dataSeries,
            chart: { type:'pie', height:350,
                events: {
                    dataPointSelection: function(event, chartContext, config){
                        var clickedIndex = config.dataPointIndex;
                        var Month_index = parseInt(clickedIndex) + 1;
                        var month_name = months[Month_index];
                        if (comparison_area_lead[clickedIndex]) {
                            delete comparison_area_lead[clickedIndex];
                        } else {
                            var trendData = customerTrendData[month_name] ?? {};
                            var line_color = line_MonthColors[Month_index] ?? '#1e90ff';
                            comparison_area_lead[clickedIndex] = {
                                name: month_name,
                                data: trendData.map(ConvtrendD => ConvtrendD.customer),
                                color: line_color
                            };
                        }
                        var seriesArray = Object.values(comparison_area_lead);
                        updateTrendChart(seriesArray);
                    }
                }
            },
            labels: condi_months ?? [],
            colors: pie_MonthColors,
            title: { text: '' },
            legend: {
                position: 'bottom',
                fontSize: '14px',
                labels: {
                    colors: 'black'
                },
                markers: {
                    width: 14,
                    height: 14,
                    radius: 3
                }
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return val + " Customers";  // Tooltip format for leads
                    },
                    title: {
                        formatter: function (seriesName) {
                            return seriesName + " :";
                        }
                    }
                }
            },
            dataLabels: { enabled:true, formatter: function(val, opts){ return Math.round(opts.w.globals.seriesPercent[opts.seriesIndex]) + ' %'; } }
        });
        chartLeads.render().then(() => {
            if(is_current){
                var clickedIndex = parseInt(new Date().getMonth());
                var Month_index = clickedIndex + 1;
                var month_name = months[Month_index] ?? 'None';
                var trendData = customerTrendData[month_name] ?? [];
                var line_color = line_MonthColors[Month_index] ?? '#1e90ff';
                comparison_area_lead[clickedIndex] = {
                    name: month_name,
                    data: trendData.map(ConvtrendD => ConvtrendD.customer),
                    color: line_color
                };
                updateTrendChart(Object.values(comparison_area_lead)); // Clear or reset the chart
            }else{
                comparison_area_lead = [];
            }
        });
    }

    // function create_pie_chart_reasons(){
    
    //     const reason_dataSeries = dropReasons.map(r => {
    //         // total drops for the reason over year
    //         return Object.values(dropReasonData[r]).reduce((sum, monthData) => {
    //             return sum + Object.values(monthData).reduce((a,b)=>a+b,0);
    //         },0);
    //     });

    //     const $reason_wrapper = $('#drop_reason_pie-wrapper');
        
    //     // If no data or all 0s, show message
    //     const reason_allZeros = reason_dataSeries.every(val => val === 0);

    //     if (!reason_dataSeries || reason_dataSeries.length === 0 || reason_allZeros) {
    //         $reason_wrapper.html(`
    //         <div class="no-data-message fs-6" style="min-height: auto;align-content: space-evenly;">
    //         No data found
    //             </div>
    //             `);
    //         return;
    //     }
        
    //     // Clear wrapper and add chart container
    //     $reason_wrapper.html('<div id="drop_reason_pie"></div>');
        
    //     var reason_clickedIndex = null;

    //     var chartDropReasonPie = new ApexCharts(document.querySelector("#drop_reason_pie"), {
    //         series: reason_dataSeries,
    //         chart: { type:'pie', height:350,
    //             events: {
    //                 dataPointSelection: function(event, chartContext, config){
    //                     // var clickedIndex = config.dataPointIndex;
    //                     // var Month_index = parseInt(clickedIndex) + 1;
    //                     // var month_name = months[Month_index];
    //                     // if (comparison_area_lead[clickedIndex]) {
    //                     //     delete comparison_area_lead[clickedIndex];
    //                     // } else {
    //                     //     var trendData = customerTrendData[month_name] ?? {};
    //                     //     var line_color = line_MonthColors[Month_index] ?? '#1e90ff';
    //                     //     comparison_area_lead[clickedIndex] = {
    //                     //         name: month_name,
    //                     //         data: trendData.map(ConvtrendD => ConvtrendD.customer),
    //                     //         color: line_color
    //                     //     };
    //                     // }
    //                     // var seriesArray = Object.values(comparison_area_lead);
    //                     // updateTrendChart(seriesArray);
    //                 }
    //             }
    //         },
    //         labels: dropReasons ?? [],
    //         colors: reasonColors,
    //         title: { text: '' },
    //         legend: {
    //             position: 'bottom',
    //             fontSize: '14px',
    //             labels: {
    //                 colors: 'black'
    //             },
    //             markers: {
    //                 width: 14,
    //                 height: 14,
    //                 radius: 3
    //             }
    //         },
    //         dataLabels: { enabled:true, formatter: function(val, opts){ return Math.round(opts.w.globals.seriesPercent[opts.seriesIndex]) + ' %'; } }
    //     });

    //     chartDropReasonPie.render();
    // }

    function create_pie_chart_conv(selectedYear){
    
        const conv_dataSeries = monthlyDropTotals ? monthlyDropTotals?.map(val => val ?? 0) ?? [] : [];
        const $conv_wrapper = $('#month_drop_pie-wrapper');
        
        const conv_allZeros = conv_dataSeries.every(val => val === 0);

        if (!conv_dataSeries || conv_dataSeries.length === 0 || conv_allZeros) {
            $('#month_customer_pie_div').removeClass('col-md-6').addClass('col-md-12');
            $('#month_drop_pie_div').hide();
            $conv_wrapper.html(`
            <div class="no-data-message fs-6" style="min-height: auto;align-content: space-evenly;">
            No data found
                </div>
                `);
            return;
        }

        $('#month_drop_pie_div').show();
        $('#month_customer_pie_div').removeClass('col-md-12').addClass('col-md-6');

        var currentYear = new Date().getFullYear();
        var is_current = (parseInt(selectedYear) === parseInt(currentYear)) ? true : false;

        // Clear wrapper and add chart container
        $conv_wrapper.html('<div id="month_drop_pie"></div>');
        
        var conv_Month_index = is_current ?  new Date().getMonth() + 1 : 0;

        var conv_clickedIndex = null;

        var chartConvs = new ApexCharts(document.querySelector("#month_drop_pie"), {
            series: conv_dataSeries,
            chart: { type:'pie', height:350,
                events: {
                    dataPointSelection: function(event, chartContext, config){
                        var conv_clickedIndex = config.dataPointIndex;
                        var conv_Month_index = parseInt(conv_clickedIndex) + 1;
                        var month_name = months[conv_Month_index];
                        if (comparison_area_conv[conv_clickedIndex]) {
                            delete comparison_area_conv[conv_clickedIndex];
                        } else {
                            var trendData = dropTrendData[month_name] ?? {};
                            var line_color = line_MonthColors[conv_Month_index] ?? '#1e90ff';
                            comparison_area_conv[conv_clickedIndex] = {
                                name: month_name,
                                data: trendData.map(ConvtrendD => ConvtrendD.drop),
                                color: line_color
                            };
                        }
                        var seriesArray = Object.values(comparison_area_conv);
                        updateDropTrendChart(seriesArray);
                    }
                }
            },
            labels: condi_months ?? [],
            colors: pie_MonthColors,
            title: { text: '' },
            legend: {
                position: 'bottom',
                fontSize: '14px',
                labels: {
                    colors: 'black'
                },
                markers: {
                    width: 14,
                    height: 14,
                    radius: 3
                }
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return val + " Drops";  // Tooltip format for Drops
                    },
                    title: {
                        formatter: function (seriesName) {
                            return seriesName + " :";
                        }
                    }
                }
            },
            dataLabels: { enabled:true, formatter: function(val, opts){ return Math.round(opts.w.globals.seriesPercent[opts.seriesIndex]) + ' %'; } }
        });
        chartConvs.render().then(() => {
            if(is_current){
                var conv_clickedIndex = parseInt(new Date().getMonth());
                var conv_Month_index = conv_clickedIndex + 1;
                var month_name = months[conv_Month_index] ?? 'None';
                var trendData = dropTrendData[month_name] ?? [];
                var line_color = line_MonthColors[conv_Month_index] ?? '#1e90ff';
                comparison_area_conv[conv_clickedIndex] = {
                    name: month_name,
                    data: trendData.map(ConvtrendD => ConvtrendD.drop),
                    color: line_color
                };
                updateDropTrendChart(Object.values(comparison_area_conv)); // Clear or reset the chart
            }else{
                comparison_area_conv = [];
            }
        });
    }

    function updateTrendChart(seriesData) {
        chartMonthCustomers.updateSeries(seriesData);
    }

    function updateDropTrendChart(seriesData) {
        chartMonthDrops.updateSeries(seriesData);
    }

    function close_function(){
        updateTrendChart([]);
        updateDropTrendChart([]);
        comparison_area_lead = [];
        comparison_area_conv = [];
        var currentYear_close = new Date().getFullYear();
        create_pie_chart_lead(currentYear_close);
        create_pie_chart_conv(currentYear_close);
    }

    function showNoDataRow(year) {
        $('#Monthly_lead_table').html(
            `<tr>
                <td colspan="100%" class="text-center text-muted fw-bold p-4 fs-3">
                    No data found for the year ${year}.
                </td>
            </tr>`
        );
        $('#Yearly_lead_footer').empty();
        document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
    }

    function scroll_option() {
        const topScrollbar = document.querySelector(".top-scrollbar");
        const bottomScrollbar = document.querySelector(".bottom-scrollbar");
        const topScroller = topScrollbar.querySelector("div");
        const bottomScroller = bottomScrollbar.querySelector("div");

        const tableContainer = document.querySelector(".table-container");

        // Match widths
        topScroller.style.width = tableContainer.scrollWidth + "px";

        // Sync scrolls
        topScrollbar.addEventListener("scroll", function () {
            tableContainer.scrollLeft = topScrollbar.scrollLeft;
        });
        tableContainer.addEventListener("scroll", function () {
            topScrollbar.scrollLeft = tableContainer.scrollLeft;
        });

        bottomScroller.style.width = tableContainer.scrollWidth + "px";

        // Sync scrolls
        bottomScrollbar.addEventListener("scroll", function () {
            tableContainer.scrollLeft = bottomScrollbar.scrollLeft;
        });
        tableContainer.addEventListener("scroll", function () {
            bottomScrollbar.scrollLeft = tableContainer.scrollLeft;
        });
    }

    function hover_classes(e_months = null, e_days = null) {

        if (e_months !== null) {

            $.each(e_months, function (monthNumber, monthName) {

                // Remove old listeners
                document.querySelectorAll(`.hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}`).forEach(el => {
                    el.replaceWith(el.cloneNode(true));
                });

                // ============================
                // 🔹 Month-wise Hover
                // ============================

                // Hover on sub-row cell
                document.querySelectorAll(`.hover_td_class_${monthNumber}`).forEach(td => {
                    td.addEventListener("mouseenter", () => {
                        highlight(td);

                        // highlight month header
                        let row = td.parentNode;
                        while (row) {
                            const rowspanCell = row.querySelector(`.hover_tr_class_${monthNumber}`);
                            if (rowspanCell) {
                                highlight(rowspanCell);
                                break;
                            }
                            row = row.previousElementSibling;
                        }

                        // 🔸 NEW: expand related day cells (height animation)
                        document.querySelectorAll(`[class^="hover_day_class_${monthNumber}_"]`).forEach(dayCell => {
                            highlight(dayCell,2);
                        });
                    });

                    td.addEventListener("mouseleave", () => {
                        resetMonth(monthNumber);
                    });
                });

                // Hover on month header
                document.querySelectorAll(`.hover_tr_class_${monthNumber}`).forEach(td => {
                    td.addEventListener("mouseenter", () => {
                        highlight(td);

                        // highlight ALL sub-row cells
                        let row = td.parentNode;
                        while (row) {
                            const hoverCell = row.querySelector(`.hover_td_class_${monthNumber}`);
                            if (hoverCell) highlight(hoverCell);
                            row = row.nextElementSibling;
                        }

                        // highlight all day cells
                        document.querySelectorAll(`[class^="hover_day_class_${monthNumber}_"]`).forEach(dayCell => {
                            highlight(dayCell,2);
                        });
                    });

                    td.addEventListener("mouseleave", () => {
                        resetMonth(monthNumber);
                    });
                });

                // ============================
                // 🔹 Day-wise Hover
                // ============================
                if (e_days !== null) {
                    $.each(e_days, function (_, day) {
                        document.querySelectorAll(`.hover_day_class_${monthNumber}_${day}`).forEach(td => {
                            td.addEventListener("mouseenter", () => {
                                // highlight the parent row's sub-cell
                                const row = td.closest("tr");
                                if (row) {
                                    const rowCell = row.querySelector(`.hover_td_class_${monthNumber}`);
                                    if (rowCell) highlight(rowCell);
                                }

                                // highlight the month header cell
                                let prevRow = td.parentNode;
                                while (prevRow) {
                                    const monthHeader = prevRow.querySelector(`.hover_tr_class_${monthNumber}`);
                                    if (monthHeader) {
                                        highlight(monthHeader);
                                        break;
                                    }
                                    prevRow = prevRow.previousElementSibling;
                                }
                            });

                            td.addEventListener("mouseleave", () => {
                                resetDay(monthNumber, day);
                            });
                        });
                    });
                }
            });
        }

        // Highlight style
        function highlight(cell, type = 1) {
            cell.style.backgroundColor = "#626dff";
            cell.style.color = "#ffffff";
            cell.style.transition = "background-color 0.3s ease-out, color 0.3s ease-out, transform 0.3s ease-out, box-shadow 0.3s ease-out, height 0.3s ease-out";
            cell.style.transform = "translateZ(5px) scale(1.02)";
            if(type === 2){
                cell.style.borderTop = "4px solid #000";
                cell.style.borderBottom = "4px solid #000";
                cell.style.boxShadow = "0 0 12px 3px rgba(98, 109, 255, 0.8)";
            }else{
                cell.style.border = "2px solid #ffffff";
            }
        }

        // Reset month highlights
        function resetMonth(monthNumber) {
            document.querySelectorAll(`.hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}, [class^="hover_day_class_${monthNumber}_"]`).forEach(cell => {
                resetCell(cell);
            });
        }

        // Reset day highlights
        function resetDay(monthNumber, day) {
            document.querySelectorAll(
                `.hover_day_class_${monthNumber}_${day}, .hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}`
            ).forEach(cell => {
                resetCell(cell);
            });
        }

        // Reset helper
        function resetCell(cell) {
            cell.style.backgroundColor = "";
            cell.style.color = "";
            cell.style.transform = "";
            cell.style.border = "";
            cell.style.borderTop = "";
            cell.style.borderBottom = "";
            cell.style.boxShadow = "";
            cell.style.height = ""; // reset to default
        }
    }
</script>
@endsection