@extends('layouts/layoutMaster')

@section('title', 'Customer '.$report_heading.' - Yearly')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('content')

<style>
    .table-scroll-wrapper {
        position: relative;
        width: 100%;
    }

    .top-scrollbar {
        overflow-x: auto;
        overflow-y: hidden;
        height: 16px; /* top scrollbar height */
    }

    .top-scrollbar div {
        height: 1px;
    }

    .table-container {
        overflow-x: auto;
        overflow-y: auto;
        max-height: calc(99vh - 100px);
        /* width: 100%; */
    }

 /* Base table */
    .sticky_table { 
        border-collapse: collapse; 
        border: 1px solid #222222ff;  
        width: 100%; /* ensures horizontal scroll works */
    }

    /* Sticky header (all th) */
    .sticky_table thead th {
        position: sticky;
        top: 0;
        background: #39484f !important;
        color: #fff;
        text-align: center;
        vertical-align: middle;
        z-index: 50; /* default header z-index */
    }
    
    /* Table cells */
    .sticky_table th, 
    .sticky_table td { 
        padding: 0;                
        text-align: center;
        vertical-align: middle;
        width: 100px;               
        height: 100px;             
        min-width: 80px;           
        max-width: 80px;
        min-height: 80px;           
        max-height: 80px;
        overflow: hidden;
        white-space: nowrap;
        border: 1px solid #222222ff;  
    }


    .sticky_table th.sticky-col-left {
        position: sticky;
        left: 0;
        color: #fff;
        background: #39484f !important;
        z-index: 60;
        border-right: 1px solid #222222ff;
    }

    .sticky_table td.sticky-col-left {
        position: sticky;
        left: 0;
        color: #000;
        background-color: #fff;
        z-index: 15;
        border-right: 1px solid #222222ff;
    }


    .sticky_table td.sticky-col-second {
        position: sticky;
        left: 150px;     
        background: #fff; 
        color: #000;
        z-index: 10;      
        border-right: 1px solid #222222ff;
    }


    .sticky_table th.sticky-col-second {
        position: sticky;
        left: 150px;
        background: #39484f !important;
        color: #fff;
        z-index: 60;      
        border-right: 1px solid #222222ff;
    }

    /* .sticky_table .current-month-row {
        background: #f3f9b8 !important;
        color: #000;
    }

    .current-month-row label {
        color: black !important;
    } */

    .current-month-row td.sticky-col-left{
        background-color: #f3f9b8 !important;
        color: #000;
    }

    .year-vertical {
        writing-mode: vertical-rl;   /* rotates text vertically */
        transform: rotate(180deg);   /* makes it read top-to-bottom */
        white-space: nowrap;         /* avoid breaking year digits */
        vertical-align: middle;      /* keep it centered */
        text-align: center;
    }

    .chart-nav-item button {
        border: 2px solid #39484f !important;
    }

    .incre_value {
        background-color: #28a745 !important;
    }
    .decre_value {
        background-color: #dc3545 !important;
    }
    .main_value {
        background-color: #3dc5e1 !important;
    }
    .nutral_value {
        background-color: #fff !important;
    }
    .current_day_value {
        background-color: #c395ff !important;
    }

    .search {
      position: relative;
      background: #ffffff;
      border-radius: 40px;
      padding: 5px 10px;
      display: flex;
      align-items: center;
      width: 350px;
    }

    /* Buttons */
    .search-btn, .reset-btn {
      color: #ffffff;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: #39484f;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-left: 10px;
      cursor: pointer;
      transition: background 0.3s;
      flex-shrink: 0;
    }

    .search span.select2-selection.select2-selection--multiple {
        border: none !important;
        border-radius: 8px 0px 0px 12px;
        width: 232px;
    }

    .search-btn:hover, .reset-btn:hover{
        color : #fff;
    }
</style>

<style id="my-style-id"></style>

<style>
    /* Sticky header (all th) */
    .sticky_table tfoot tr {
        position: sticky;
        bottom: 0;
        background: #39484f !important;
        color: #000;
        text-align: center;
        vertical-align: middle;
        z-index: 50; /* default header z-index */
    }

    .sticky_table tfoot td.sticky-col-left {
        position: sticky;
        left: 0;
        bottom:0;
        color: #000;
        background: #39484f !important;
        z-index: 15;
        border-right: 1px solid #ccc;
    }

    .sticky_table tfoot td.sticky-col-second {
        position: sticky;
        left: 150px;
        bottom: 0;
        background: #39484f !important;
        color: #000;
        z-index: 10;      
        border-right: 1px solid #ccc;
    }
    /* td.sticky-col-left_2 {
        position: sticky;
        color: #000;
        z-index: 15;
        border-right: 0px solid #222222ff;
        left: 50%;
        max-width: -webkit-fill-available;
    } */
</style>

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1 d-flex align-items-center justify-content-between gap-2">
        <div>
            <h5 class="card-title mb-1">Customer {{ $report_heading }} - Yearly</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Business {{ $report_heading }}</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="{{ url('/manage_reports/customer_report_yearly') }}" class="d-flex align-items-center">Customer {{ $report_heading }}</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="{{ url('/manage_reports/customer_drop_report_yearly') }}" class="d-flex align-items-center">Drop Customer</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/customer_drop_report_yearly') }}"type="button" class="nav-link text-capitalize active">Yearly</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/customer_drop_report') }}" type="button" class="nav-link text-capitalize" >Monthly</a>
                    </li>
                </ul>
            </div>
            
        </div>
    </div>    
    <div class="card-body">
        @php
            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];
            $days = range(1,31); // always show 1-31
            $yearShort = date('y'); // e.g., 25 for 2025
            $year = date('Y');
        @endphp
        <div  class="d-flex flex-row align-items-center justify-content-between gap-2 mb-6">
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                        <a href="{{'/manage_reports/customer_drop_report_yearly'}}" type="button" class="nav-link text-capitalize active">Drop Customer</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{'/manage_reports/customer_source_report_yearly'}}" type="button" class="nav-link text-capitalize">Customer Source</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/customer_age_report_yearly') }}" type="button" class="nav-link text-capitalize">Gender</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/manage_reports/customer_employee_type_yearly') }}" type="button" class="nav-link text-capitalize">Employee Type</a>
                    </li>
                </ul>
            </div>
            <div class="d-flex flex-row align-items-center justify-content-between gap-2 mb-2">
                <ul class="nav nav-pills justify-content-end" role="tablist">
                    <li class="nav-item me-1">
                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary py-2"  data-bs-toggle="modal" data-bs-target="#kt_modal_course_package_vs_year" id="graph_div" style="display:none !important;">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Graph"><i class="mdi mdi-finance fs-3"></i></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-lg-10 mx-3 mb-2 d-flex align-items-center justify-content-start gap-2  mb-6 border rounded border-primary py-3" style="flex-flow: wrap;max-width: fit-content;">
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #f3f9b8"></span>
                    <span>-</span>
                    <label class="fs-6 fw-semibold text-black">Current Year</label>
                </div>
                <span>|</span>
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #c395ff"></span>
                    <span>-</span>
                    <label class="fs-6 fw-semibold text-black">Current Month</label>
                </div>
                <span>|</span>
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #28a745"></span>
                    <span>-</span>
                    <label class="fs-6 fw-semibold text-black">Increased Value</label>
                </div>
                <span>|</span>
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #dc3545"></span>
                    <span>-</span>
                    <label class="fs-6 fw-semibold text-black">Decreased Value</label>
                </div>
                <span>|</span>
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <span class="py-2 px-2 rounded border border-2 border-black" style="background-color: #3dc5e1"></span>
                    <span>-</span>
                    <label class="fs-6 fw-semibold text-black">Maintained Value</label>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="table-scroll-wrapper">
                    <!-- Top Scrollbar -->
                    <div class="top-scrollbar">
                        <div></div>
                    </div>
                   <div class="table-container">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 sticky_table">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-150px sticky-col-left fs-5 text-center">Year</th>
                                    <th class="min-w-150px sticky-col-left sticky-col-second fs-5 text-center">
                                        <div class="d-flex flex-column justify-content-center">
                                            <label class="fw-semibold fs-5">Customers</label>
                                            <label class="fw-semibold fs-5">Drops</label>
                                        </div>
                                    </th>
                                    @foreach($months as $monthName)
                                        <th class="min-w-150px fs-5 text-center">{{ $monthName }}</th>
                                    @endforeach
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7" id="Monthly_lead_table">
                            </tbody>
                            <tfoot class="text-black fw-semibold fs-3" id="Yearly_lead_footer"></tfoot>
                        </table>
                    </div>
                    <div class="bottom-scrollbar">
                        <div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Total Leads Vs Month-->
<div class="modal fade" id="kt_modal_course_package_vs_year" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" onclick="close_function()">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body px-2 py-2 position-relative">
                <div class="rounded-4 border-1 px-5 pt-5">
                    <div class="mb-6">
                        <h3 class=" mb-4 text-black text-center">Customer Vs Drop (Yearly) <span id="year_head_div"></span></h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-4" id="all_year_area_div">
                            <div class="container text-center border rounded p-3" style="min-height: auto">
                                <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Yearly Customers vs Drops Trend </h1>
                                <div id="all_year_area-wrapper"><div id="all_year_area"></div></div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6" id="year_customer_pie_div">
                            <div class="col-lg-12 mb-4">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-pie"></i> Yearly Customers Distribution</h1>
                                    <div id="year_customer_pie-wrapper"><div id="year_customer_pie"></div></div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-4">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Monthly Customers Distribution </h1>
                                    <div id="month_customer_area-wrapper"><div id="month_customer_area"></div></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6" id="year_drop_pie_div">
                            <div class="col-lg-12 mb-4">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-pie"></i> Yearly Drops Distribution</h1>
                                    <div id="year_drop_pie-wrapper"><div id="year_drop_pie"></div></div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-4">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Monthly Drops Distribution </h1>
                                    <div id="month_drop_area-wrapper"><div id="month_drop_area"></div></div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="col-md-6">
                            <div class="col-lg-12 mb-4" id="drop_reason_pie_div">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-pie"></i> Reasons for Drop (<span id="drop_reason_pie_name">All Years</span>)</h1>
                                    <div id="drop_reason_pie-wrapper"><div id="drop_reason_pie"></div></div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-4" id="drop_reason_area_div">
                                <div class="container text-center border rounded p-3" style="min-height: auto">
                                    <h1 class="mb-4" style="font-family: Helvetica, Arial, sans-serif;opacity: 1;font-size:14px;f;font-weight: 900;color: #373d3f;"><i class="mdi mdi-chart-areaspline"></i> Monthly Drop Count by Year </h1>
                                    <div id="drop_reason_area-wrapper"><div id="drop_reason_area"></div></div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="d-flex justify-content-end align-items-end mt-6 mb-4">
                        <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Close</a>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Total Leads Vs Month-->


<script>
    const now = new Date();
    var currentYear = new Date().getFullYear();
    var currentMonth = new Date().getMonth() + 1;
    var currentDay = now.getDate();
    var months = @json($months);
    var customerData = null;
    var dropData = null;
    var dropPercent = null;
    var monthTotals = null;
    var yearlyCustomers = null;
    var yearlyDrops = null;
    var year_colors = null;
    var years = null;

    let comparison_area_lead = [];
    let comparison_area_conv = [];

    var chartAllMonths = new ApexCharts(document.querySelector("#all_year_area"), {
        series: [],
        chart: {
            height: 350,
            type: 'area',
            toolbar: { show: true }
        },
        dataLabels: { enabled: true },
        stroke: { curve: 'smooth'},
        markers: { size: 5 },
        xaxis: {
            categories: [],
            title: { text: 'Years' } // Use Blade variable
        },
        yaxis: {
            title: { text: 'Total Customers / Drops' }
        },
        tooltip: {
            shared: true,
            intersect: false
        },
        legend: {
            position: 'top'
        }
    });
    chartAllMonths.render();

    // Empty Line Chart for trend
    var chartMonthCustomers = new ApexCharts(document.querySelector("#month_customer_area"), {
        chart: { type:'area', height:350 },
        series: [],
        xaxis: {
            categories: Object.values(months),
            title: {
                text: '', // 🔹 X-axis heading
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333'
                }
            }
        },
        yaxis: {
            title: {
                text: 'Number of Customers', // 🔹 Y-axis heading
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333'
                }
            }
        },
        title: { text:'' },
        stroke: { curve:'smooth' },
        tooltip: {
            shared: true,
            intersect: false,
            x: {
                format: 'MMM' // Or 'HH:mm' for time
            },
            y: {
                formatter: function (value) {
                    return value + " Customers"; // Customize label
                },
                title: {
                    formatter: function (seriesName) {
                        return seriesName + ":";
                    }
                }
            }
        },
        legend: {
            position: 'bottom', // Must match the class you're targeting
            horizontalAlign: 'center',
            verticalAlign: 'center' // optionally, to help vertical placement
        }
    });
    chartMonthCustomers.render();

    var chartMonthDrops = new ApexCharts(document.querySelector("#month_drop_area"), {
        chart: { type:'area', height:350 },
        series: [],
        xaxis: {
            categories: Object.values(months),
            title: {
                text: '', // 🔹 X-axis heading
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333'
                }
            }
        },
        yaxis: {
            title: {
                text: 'Number of Drops', // 🔹 Y-axis heading
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333'
                }
            }
        },
        title: { text:'' },
        stroke: { curve:'smooth' },
        tooltip: {
            shared: true,
            intersect: false,
            x: {
                format: 'MMM' // Or 'HH:mm' for time
            },
            y: {
                formatter: function (value) {
                    return value + " Drops"; // Customize label
                },
                title: {
                    formatter: function (seriesName) {
                        return seriesName + ":";
                    }
                }
            }
        },
        legend: {
            position: 'bottom', // Must match the class you're targeting
            horizontalAlign: 'center',
            verticalAlign: 'center' // optionally, to help vertical placement
        }
    });
    chartMonthDrops.render();

    $(document).ready(function () {
        getLeadDetailsTable();
    });


    function getLeadDetailsTable() {

        $.ajax({
            url: '{{ route("customer_drop_report_yearly_data") }}',
            method: 'POST',
            dataType: 'json',
            data: {
                _token: '{{ csrf_token() }}'
            },
            beforeSend: function () {

                Swal.fire({
                    title: 'Processing...',
                    text: 'Please wait while we load the data.',
                    showConfirmButton: false,
                    showCancelButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    customClass: {
                        confirmButton: 'd-none btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false,
                    didOpen: () => {
                        Swal.showLoading();
                        document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
                    }
                });

                $('#Yearly_lead_footer').empty();
                $('#Monthly_lead_table').html('<tr><td colspan="100%" class="text-center">Loading...</td></tr>');
            },
            success: function (data) {
                try {

                    if (!data || typeof data !== 'object') {
                        throw new Error('Invalid response format');
                    }

                    months = data.months && typeof data.months === 'object' ? data.months : null;
                    customerData = data.customerData && typeof data.customerData === 'object' ? data.customerData : null;
                    dropData = data.dropData && typeof data.dropData === 'object' ? data.dropData : null;
                    dropPercent = data.dropPercent && typeof data.dropPercent === 'object' ? data.dropPercent : null;
                    monthTotals = data.monthTotals && typeof data.monthTotals === 'object' ? data.monthTotals : null;
                    yearlyCustomers = data.yearlyCustomers && typeof data.yearlyCustomers === 'object' ? data.yearlyCustomers : null;
                    yearlyDrops = data.yearlyDrops && typeof data.yearlyDrops === 'object' ? data.yearlyDrops : null;
                    year_colors = data.year_colors && typeof data.year_colors === 'object' ? data.year_colors : null;
                    years = Array.isArray(data.years) ? data.years : null;
                    
                    if (!months || !years || !dropData || !customerData) {
                        throw new Error('Required data missing');
                    }

                    buildLeadsTable();
                    overall_month_lead_chart();
                    create_pie_chart_lead();
                    create_pie_chart_conv();
                    updateTrendChart([]);
                    updateDropTrendChart([]);
                    comparison_area_lead = [];
                    comparison_area_conv = [];
                } catch (ex) {
                    console.error('Data validation error:', ex);
                    showNoDataRow();
                } finally {
                    Swal.close();
                    $('#prevMonthBtn, #nextMonthBtn').prop('disabled', false);
                }
            },
            error: function (xhr, status, error) {
                Swal.close();
                $('#prevMonthBtn, #nextMonthBtn').prop('disabled', false);

                let message = 'Failed to load data. Please try again later.';
                if(xhr.status === 0){
                    message = 'Network error: Please check your internet connection.';
                } else if(xhr.status >= 500){
                    message = 'Server error occurred. Please try again later.';
                } else if(xhr.status === 422){
                    message = 'Validation error: Please check your input.';
                } else if(xhr.responseJSON && xhr.responseJSON.message){
                    message = xhr.responseJSON.message;
                }

                console.error('Error loading data:', xhr.responseText);

                showNoDataRow();

                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: message,
                    showConfirmButton: true,
                    confirmButtonText: 'Close',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light btn-md'
                    },
                    buttonsStyling: false
                });
            }
        });
    }

    function buildLeadsTable() {

        try {

            const $table = $('#Monthly_lead_table');
            $table.empty();

            let hasAnyData = false;

            const $table_footer = $('#Yearly_lead_footer');
            $table_footer.empty();

            // let leadsFooterRow = `<tr class="tfoot-leads">`;
            //     leadsFooterRow += `<td rowspan="2" class="sticky-col-left fs-5">Grand Total</td>`;
            //     leadsFooterRow += `<td class="sticky-col-left sticky-col-second fs-5"><div class="fs-5 fw-semibold">Customers</div>
            //     <div class="d-block mb-2 mt-2">
            //         <span class="bg-info text-white fs-4 py-2 px-2 rounded" id="day_wise_grand_count_lead" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Grand Total Customers">00</span>
            //     </div></td>`;

            // // 🔸 Drops Row
            // let conversionFooterRow = `<tr class="tfoot-conversion">`;
            //     conversionFooterRow += `<td class="sticky-col-left sticky-col-second fs-5"><div class="fs-5 fw-semibold mt-4">Drops</div>
            //     <div class="d-block mb-2 mt-2">
            //         <span class="bg-info text-white fs-4 py-2 px-2 rounded" id="day_wise_grand_count_conv" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Grand Total Drops">00</span>
            //     </div>
            // </td>`;

            // let leadsFooterRow = `<tr class="tfoot-leads">`;
            // leadsFooterRow += `<td style="border-left: 1px solid #39484f;border-right: 1px solid #39484f;" class="sticky-col-left_2 text-white fs-2">
            //     <div class="d-flex flex-row align-items-center gap-2">
            //         <div class="d-flex flex-row align-items-center gap-2">
            //             Customer
            //             <div class="d-flex flex-row align-items-center gap-2">
            //                 <span class="badge bg-warning text-black fs-1 fw-semibold rounded" id="day_wise_grand_count_lead">00</span>
            //             </div>
            //         </div>
            //         <div class="d-flex flex-row align-items-center gap-2">
            //             Drops
            //             <div class="d-flex flex-row align-items-center gap-2">
            //                 <span class="badge bg-warning text-black fs-1 fw-semibold rounded" id="day_wise_grand_count_lead">00</span>
            //             </div>
            //         </div>
            //     </div>
            // </td>`;

            var grand_day_wise_count_lead = 0;
            var grand_day_wise_count_conv = 0;

            years.forEach(year => {

                const isCurrentYear = parseInt(year) === new Date().getFullYear();

                var isPreMonth = (parseInt(year) < new Date().getFullYear());

                const rowClass = isCurrentYear ? 'current-month-row' : '';
                var tdClass = isCurrentYear ? 'text-black' : '';

                var yearlyCustomersCount = yearlyCustomers[year] ?? 0;
                var yearlyDropsCount = yearlyDrops[year] ?? 0;

                let leadsRow = `<tr class="${rowClass}">`;
                let conversionRow = `<tr class="${rowClass}">`;

                leadsRow += `<td rowspan="2" style="white-space: pre-wrap;" class="sticky-col-left fs-5 ${tdClass} hover_tr_class_${year}">${year}</td>`;

                leadsRow += `<td class="hover_td_class_${year} sticky-col-left sticky-col-second ${tdClass}"><div class="fs-5 fw-semibold">Customers</div>
                    <div class="d-block mt-2">
                        <span class="bg-warning text-black fs-4 py-2 px-2 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Customers">${ String(yearlyCustomersCount ?? 0).padStart(2, '0') }</span>
                    </div>
                </td>`;

                conversionRow += `<td class="hover_td_class_${year} sticky-col-left sticky-col-second ${tdClass}"><div class="fs-5 fw-semibold mt-4">Drops</div>
                    <div class="d-block mb-2 mt-2">
                        <span class="bg-warning text-black fs-4 py-2 px-2 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Drops">${ String(yearlyDropsCount ?? 0).padStart(2, '0') }</span>
                    </div>
                </td>`;

                // Initialize previous values using previous month's last day
                let prevYear = parseInt(year) - 1;
                var prevLeads = 0;
                var prevConvr = 0;
              
                var day_wise_count_lead = 0;
                var day_wise_count_conv = 0;

                $.each(months, function (monthNumber, monthName) {

                    var dayDataCustomer = parseInt(customerData[year]?.[monthNumber]) ?? 0;
                    var dayDataDrops = parseInt(dropData[year]?.[monthNumber]) ?? 0;
                    var dropPercentData = parseInt(dropPercent[year]?.[monthNumber]) ?? 0;

                    if (dayDataCustomer > 0 || dayDataDrops > 0) {
                        hasAnyData = true;
                    }

                    if (parseInt(monthNumber) === 1) {
                        var prevLeads = parseInt(customerData[prevYear]?.[12]) ?? 0;
                        var prevConvr = parseInt(dropData[prevYear]?.[12]) ?? 0;
                    }else{
                        if (parseInt(monthNumber) > 1) {
                            var prevMonth = parseInt(monthNumber) - 1;
                            var prevLeads = customerData[year]?.[prevMonth] ?? 0;
                            var prevConvr = dropData[year]?.[prevMonth] ?? 0;
                        }
                    }

                    // ----- Leads Row -----
                    let badgeColor = 'nutral_value';
                    var lead_enable_data = true;
                    if (isCurrentYear) {
                        if (parseInt(currentMonth) === parseInt(monthNumber)) {
                            badgeColor = 'current_day_value'; // today
                            lead_enable_data = true;
                        } else if (parseInt(currentMonth) < parseInt(monthNumber)) {
                            badgeColor = 'nutral_value'; // future
                            lead_enable_data = false;
                        } else if (prevLeads !== null) {
                            if (dayDataCustomer > prevLeads) badgeColor = 'incre_value'; // up
                            else if (dayDataCustomer < prevLeads) badgeColor = 'decre_value'; // down
                            else badgeColor = 'main_value'; // same
                            lead_enable_data = true;
                        }
                    } else if (prevLeads !== null) {
                        if (dayDataCustomer > prevLeads) badgeColor = 'incre_value';
                        else if (dayDataCustomer < prevLeads) badgeColor = 'decre_value';
                        else badgeColor = 'main_value';
                        lead_enable_data = true;
                    }

                    day_wise_count_lead += parseInt(dayDataCustomer);
                    
                    leadsRow += `<td class="${ lead_enable_data ? 'hover_day_class_'+year+'_'+monthNumber+' ' : ''}text-center ${badgeColor}">
                    <label class="fw-semibold fs-3 text-black">
                        ${ lead_enable_data ?  String(dayDataCustomer ?? 0).padStart(2, '0') : ''}
                    </label>
                    </td>`;
                    
                    prevLeads = dayDataCustomer ?? 0;
                    
                    // ----- Conversion Row -----
                    badgeColor = 'nutral_value';
                    var conv_enable_data = true;
                    if (isCurrentYear) {                            
                        if (parseInt(currentMonth) === parseInt(monthNumber)) {
                            badgeColor = 'current_day_value'; // today
                            conv_enable_data = true;
                        } else if (parseInt(currentMonth) < parseInt(monthNumber)) {
                            badgeColor = 'nutral_value'; // future
                            conv_enable_data = false;
                        } else if (prevConvr !== null) {
                            if (dayDataDrops > prevConvr) badgeColor = 'incre_value'; // up
                            else if (dayDataDrops < prevConvr) badgeColor = 'decre_value'; // down
                            else badgeColor = 'main_value'; // same
                            conv_enable_data = true;
                        }
                    } else if (prevConvr !== null) {
                        if (dayDataDrops > prevConvr) badgeColor = 'incre_value';
                        else if (dayDataDrops < prevConvr) badgeColor = 'decre_value';
                        else badgeColor = 'main_value';
                        conv_enable_data = true;
                    }
                    
                    day_wise_count_conv += parseInt(dayDataDrops);

                    conversionRow += `<td class="${ lead_enable_data ? 'hover_day_class_'+year+'_'+monthNumber+' ' : ''}text-center ${badgeColor}">
                        <label class="fw-semibold fs-3 text-black">
                            ${ conv_enable_data ? String(dayDataDrops).padStart(2, '0') : '' }
                        </label>
                        <div class="d-block">
                            ${conv_enable_data ? '<span class="bg-white text-info fs-5 py-1 px-2 rounded">'+dropPercentData+'%</span>' : ''}
                        </div>
                    </td>`;

                    prevConvr = dayDataDrops;

                });

                leadsRow += `</tr>`;
                conversionRow += `</tr>`;
                
                $table.append(leadsRow).append(conversionRow);

                
                document.getElementById('graph_div').style.setProperty('display', 'block', 'important');
            });

            // leadsFooterRow += `<td colspan="${parseInt(Object.keys(months).length)+2 ?? 14}" style="border-left: 1px solid #39484f;border-right: 1px solid #39484f;" class="sticky-col-left sticky-col-second fs-5">
            //     <div class="d-flex flex-row align-items-center gap-2" style="place-content: center;">
            //         <div class="d-flex flex-row align-items-center gap-2 text-white">
            //             Customer
            //             <div class="d-flex flex-row align-items-center gap-2">
            //                 <span class="badge bg-warning text-black fs-1 fw-semibold rounded" id="day_wise_grand_count_lead">00</span>
            //             </div>
            //         </div>
            //         <div class="text-white" style="font-size: 36px;font-weight: 100"> | </div>
            //         <div class="d-flex flex-row align-items-center gap-2 text-white">
            //             Drops
            //             <div class="d-flex flex-row align-items-center gap-2">
            //                 <span class="badge bg-warning text-black fs-1 fw-semibold rounded" id="day_wise_grand_count_lead">00</span>
            //             </div>
            //         </div>
            //     </div>
            // </td>`;

            // leadsFooterRow += `</tr>`;
            
            // $table_footer.append(leadsFooterRow);
            
            // $.each(months, function (monthNumber, monthName) {
            //     leadsFooterRow += `<th class="text-center">
            //     <label class="fw-semibold fs-3 text-black">${ String(monthTotals?.[monthNumber].customers).padStart(2, '0') }</label>
            //     </th>`;
            //     conversionFooterRow += `<th class="text-center">
            //     <label class="fw-semibold fs-3 text-black">${ String(monthTotals?.[monthNumber].drops).padStart(2, '0') }</label>
            //     </th>`;

            //     grand_day_wise_count_lead += parseInt(monthTotals?.[monthNumber].customers) ?? 0;
            //     grand_day_wise_count_conv += parseInt(monthTotals?.[monthNumber].drops) ?? 0;

            // });
            
            // leadsFooterRow += `</tr>`;
            // conversionFooterRow += `</tr>`;
            
            // $table_footer.append(leadsFooterRow).append(conversionFooterRow);
            
            // $(`#day_wise_grand_count_lead`).text(String(grand_day_wise_count_lead).padStart(2, '0'));
            // $(`#day_wise_grand_count_conv`).text(String(grand_day_wise_count_conv).padStart(2, '0'));
            
            $('[data-bs-toggle="tooltip"]').tooltip({ 'animation' : false });
            
            hover_classes(years,months);

            scroll_option();

            if (!hasAnyData) {
                showNoDataRow();
            }

        } catch (ex) {
            console.error('Error building leads table:', ex);
            showNoDataRow();
        }
    }

    function showNoDataRow() {
        $('#Monthly_lead_table').html(
            `<tr>
                <td colspan="100%" class="text-center text-muted fw-bold p-4 fs-3">
                    No data found.
                </td>
            </tr>`
        );
        $('#Yearly_lead_footer').empty();
        document.getElementById('graph_div').style.setProperty('display', 'none', 'important');
    }

    function overall_month_lead_chart() {
        chartAllMonths.updateSeries([
            {
                name: 'Total Customers',
                data: Object.values(yearlyCustomers) ?? [],
                color: '#1E90FF'
            },
            {
                name: 'Total Drops',
                data: Object.values(yearlyDrops) ?? [],
                color: '#FF4500'
            }
        ]);
        chartAllMonths.updateOptions({
            xaxis: {
                categories: years ?? [],
                title: { text: 'Years' }
            }
        });
    }

    function create_pie_chart_lead(){
    
        const dataSeries = yearlyCustomers ? Object.values(yearlyCustomers)?.map(val => val ?? 0) ?? [] : [];
        const $wrapper = $('#year_customer_pie-wrapper');
        
        // If no data or all 0s, show message
        const allZeros = dataSeries.every(val => val === 0);

        var currentYear = new Date().getFullYear();
            
        if (!dataSeries || dataSeries.length === 0 || allZeros) {
            $('#year_customer_pie_div').hide();
            $('#year_drop_pie_div').removeClass('col-md-6').addClass('col-md-12');
            $wrapper.html(`
            <div class="no-data-message fs-6" style="min-height: auto;align-content: space-evenly;">
            No data found
                </div>
                `);
            return;
        }
        
        $('#year_customer_pie_div').show();
        $('#year_drop_pie_div').removeClass('col-md-12').addClass('col-md-6');
        // Clear wrapper and add chart container
        $wrapper.html('<div id="year_customer_pie"></div>');
        
        var clickedIndex = null;

        var chartLeads = new ApexCharts(document.querySelector("#year_customer_pie"), {
            series: dataSeries,
            chart: { type:'pie', height:350,
                events: {
                    dataPointSelection: function(event, chartContext, config){
                        var clickedIndex = config.dataPointIndex;
                        var year_index = years[clickedIndex] ?? currentYear;
                        if (comparison_area_lead[year_index]) {
                            delete comparison_area_lead[year_index];
                        } else {
                            var trendData = customerData[year_index] ?? {};
                            var line_color = year_colors[year_index] ?? '#1e90ff';
                            comparison_area_lead[year_index] = {
                                name: year_index,
                                data: Object.values(trendData),
                                color: line_color
                            };
                        }
                        var seriesArray = Object.values(comparison_area_lead);
                        updateTrendChart(seriesArray);
                    }
                }
            },
            labels: years ?? [],
            colors: Object.values(year_colors),
            title: { text: '' },
            legend: {
                position: 'bottom',
                fontSize: '14px',
                labels: {
                    colors: 'black'
                },
                markers: {
                    width: 14,
                    height: 14,
                    radius: 3
                }
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return val + " Customers";  // Tooltip format for leads
                    },
                    title: {
                        formatter: function (seriesName) {
                            return seriesName + " :";
                        }
                    }
                }
            },
            dataLabels: { enabled:true, formatter: function(val, opts){ return Math.round(opts.w.globals.seriesPercent[opts.seriesIndex]) + ' %'; } }
        });
        chartLeads.render().then(() => {
            var clickedIndex = currentYear;
            var trendData = customerData[clickedIndex] ?? {};
            var line_color = year_colors[clickedIndex] ?? '#1e90ff';
            comparison_area_lead[clickedIndex] = {
                name: clickedIndex,
                data: Object.values(trendData),
                color: line_color
            };
            updateTrendChart(Object.values(comparison_area_lead)); // Clear or reset the chart
        });
    }

    function updateTrendChart(seriesData) {
        chartMonthCustomers.updateSeries(seriesData);
    }

    function create_pie_chart_conv(){
    
        const conv_dataSeries = yearlyDrops ? Object.values(yearlyDrops)?.map(val => val ?? 0) ?? [] : [];
        const $conv_wrapper = $('#year_drop_pie-wrapper');
        
        const conv_allZeros = conv_dataSeries.every(val => val === 0);

        if (!conv_dataSeries || conv_dataSeries.length === 0 || conv_allZeros) {
            $('#year_customer_pie_div').removeClass('col-md-6').addClass('col-md-12');
            $('#year_drop_pie_div').hide();
            $conv_wrapper.html(`
            <div class="no-data-message fs-6" style="min-height: auto;align-content: space-evenly;">
            No data found
                </div>
                `);
            return;
        }

        $('#year_drop_pie_div').show();
        $('#year_customer_pie_div').removeClass('col-md-12').addClass('col-md-6');

        var currentYear = new Date().getFullYear();

        // Clear wrapper and add chart container
        $conv_wrapper.html('<div id="year_drop_pie"></div>');
        
        // var conv_Month_index = is_current ?  new Date().getMonth() + 1 : 0;

        var conv_clickedIndex = null;

        var chartConvs = new ApexCharts(document.querySelector("#year_drop_pie"), {
            series: conv_dataSeries,
            chart: { type:'pie', height:350,
                events: {
                    dataPointSelection: function(event, chartContext, config){
                        var conv_clickedIndex = config.dataPointIndex;
                        var conv_year_index = years[conv_clickedIndex] ?? currentYear;
                        if (comparison_area_conv[conv_year_index]) {
                            delete comparison_area_conv[conv_year_index];
                        } else {
                            var trendData = dropData[conv_year_index] ?? {};
                            var line_color = year_colors[conv_year_index] ?? '#1e90ff';
                            comparison_area_conv[conv_year_index] = {
                                name: conv_year_index,
                                data: Object.values(trendData),
                                color: line_color
                            };
                        }
                        var seriesArray = Object.values(comparison_area_conv);
                        updateDropTrendChart(seriesArray);
                    }
                }
            },
             labels: years ?? [],
            colors: Object.values(year_colors),
            title: { text: '' },
            legend: {
                position: 'bottom',
                fontSize: '14px',
                labels: {
                    colors: 'black'
                },
                markers: {
                    width: 14,
                    height: 14,
                    radius: 3
                }
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return val + " Drops";  // Tooltip format for Drops
                    },
                    title: {
                        formatter: function (seriesName) {
                            return seriesName + " :";
                        }
                    }
                }
            },
            dataLabels: { enabled:true, formatter: function(val, opts){ return Math.round(opts.w.globals.seriesPercent[opts.seriesIndex]) + ' %'; } }
        });
        chartConvs.render().then(() => {
            var conv_clickedIndex = currentYear;
            var trendData = dropData[conv_clickedIndex] ?? {};
            var line_color = year_colors[conv_clickedIndex] ?? '#1e90ff';
            comparison_area_conv[conv_clickedIndex] = {
                name: conv_clickedIndex,
                data: Object.values(trendData),
                color: line_color
            };
            updateDropTrendChart(Object.values(comparison_area_conv)); // Clear or reset the chart
        });
    }

    function updateDropTrendChart(seriesData) {
        chartMonthDrops.updateSeries(seriesData);
    }

    function close_function(){
        updateTrendChart([]);
        updateDropTrendChart([]);
        comparison_area_lead = [];
        comparison_area_conv = [];
        create_pie_chart_lead();
        create_pie_chart_conv();
    }

    function scroll_option() {
        const topScrollbar = document.querySelector(".top-scrollbar");
        const bottomScrollbar = document.querySelector(".bottom-scrollbar");
        const topScroller = topScrollbar.querySelector("div");
        const bottomScroller = bottomScrollbar.querySelector("div");

        const tableContainer = document.querySelector(".table-container");

        // Match widths
        topScroller.style.width = tableContainer.scrollWidth + "px";

        // Sync scrolls
        topScrollbar.addEventListener("scroll", function () {
            tableContainer.scrollLeft = topScrollbar.scrollLeft;
        });
        tableContainer.addEventListener("scroll", function () {
            topScrollbar.scrollLeft = tableContainer.scrollLeft;
        });

        bottomScroller.style.width = tableContainer.scrollWidth + "px";

        // Sync scrolls
        bottomScrollbar.addEventListener("scroll", function () {
            tableContainer.scrollLeft = bottomScrollbar.scrollLeft;
        });
        tableContainer.addEventListener("scroll", function () {
            bottomScrollbar.scrollLeft = tableContainer.scrollLeft;
        });
    }

    function hover_classes(e_months = null, e_days = null) {

        if (e_months !== null) {

            e_months.forEach(monthNumber => {

                // Remove old listeners
                document.querySelectorAll(`.hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}`).forEach(el => {
                    el.replaceWith(el.cloneNode(true));
                });

                // ============================
                // 🔹 Month-wise Hover
                // ============================

                // Hover on sub-row cell
                document.querySelectorAll(`.hover_td_class_${monthNumber}`).forEach(td => {
                    td.addEventListener("mouseenter", () => {
                        highlight(td);

                        // highlight month header
                        let row = td.parentNode;
                        while (row) {
                            const rowspanCell = row.querySelector(`.hover_tr_class_${monthNumber}`);
                            if (rowspanCell) {
                                highlight(rowspanCell);
                                break;
                            }
                            row = row.previousElementSibling;
                        }

                        // 🔸 NEW: expand related day cells (height animation)
                        document.querySelectorAll(`[class^="hover_day_class_${monthNumber}_"]`).forEach(dayCell => {
                            highlight(dayCell,2);
                        });
                    });

                    td.addEventListener("mouseleave", () => {
                        resetMonth(monthNumber);
                    });
                });

                // Hover on month header
                document.querySelectorAll(`.hover_tr_class_${monthNumber}`).forEach(td => {
                    td.addEventListener("mouseenter", () => {
                        highlight(td);

                        // highlight ALL sub-row cells
                        let row = td.parentNode;
                        while (row) {
                            const hoverCell = row.querySelector(`.hover_td_class_${monthNumber}`);
                            if (hoverCell) highlight(hoverCell);
                            row = row.nextElementSibling;
                        }

                        // highlight all day cells
                        document.querySelectorAll(`[class^="hover_day_class_${monthNumber}_"]`).forEach(dayCell => {
                            highlight(dayCell,2);
                        });
                    });

                    td.addEventListener("mouseleave", () => {
                        resetMonth(monthNumber);
                    });
                });

                // ============================
                // 🔹 Day-wise Hover
                // ============================
                if (e_days !== null) {
                    $.each(e_days, function (day, day_name) {
                        document.querySelectorAll(`.hover_day_class_${monthNumber}_${day}`).forEach(td => {
                            td.addEventListener("mouseenter", () => {
                                // highlight the parent row's sub-cell
                                const row = td.closest("tr");
                                if (row) {
                                    const rowCell = row.querySelector(`.hover_td_class_${monthNumber}`);
                                    if (rowCell) highlight(rowCell);
                                }

                                // highlight the month header cell
                                let prevRow = td.parentNode;
                                while (prevRow) {
                                    const monthHeader = prevRow.querySelector(`.hover_tr_class_${monthNumber}`);
                                    if (monthHeader) {
                                        highlight(monthHeader);
                                        break;
                                    }
                                    prevRow = prevRow.previousElementSibling;
                                }
                            });

                            td.addEventListener("mouseleave", () => {
                                resetDay(monthNumber, day);
                            });
                        });
                    });
                }
            });
        }

        // Highlight style
        function highlight(cell, type = 1) {
            cell.style.backgroundColor = "#626dff";
            cell.style.color = "#ffffff";
            cell.style.transition = "background-color 0.3s ease-out, color 0.3s ease-out, transform 0.3s ease-out, box-shadow 0.3s ease-out, height 0.3s ease-out";
            cell.style.transform = "translateZ(5px) scale(1.02)";
            if(type === 2){
                cell.style.borderTop = "4px solid #000";
                cell.style.borderBottom = "4px solid #000";
                cell.style.boxShadow = "0 0 12px 3px rgba(98, 109, 255, 0.8)";
            }else{
                cell.style.border = "2px solid #ffffff";
            }
        }

        // Reset month highlights
        function resetMonth(monthNumber) {
            document.querySelectorAll(`.hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}, [class^="hover_day_class_${monthNumber}_"]`).forEach(cell => {
                resetCell(cell);
            });
        }

        // Reset day highlights
        function resetDay(monthNumber, day) {
            document.querySelectorAll(
                `.hover_day_class_${monthNumber}_${day}, .hover_td_class_${monthNumber}, .hover_tr_class_${monthNumber}`
            ).forEach(cell => {
                resetCell(cell);
            });
        }

        // Reset helper
        function resetCell(cell) {
            cell.style.backgroundColor = "";
            cell.style.color = "";
            cell.style.transform = "";
            cell.style.border = "";
            cell.style.borderTop = "";
            cell.style.borderBottom = "";
            cell.style.boxShadow = "";
            cell.style.height = ""; // reset to default
        }
    }

</script>
@endsection