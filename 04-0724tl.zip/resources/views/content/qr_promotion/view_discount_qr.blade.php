@extends('layouts/blankLayout')

@section('title', 'Discount QR')

@section('content')
<link href="https://fonts.googleapis.com/css2?family=Wendy+One&display=swap" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css2?family=Sawarabi+Mincho" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@300;700;900&display=swap" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Black Han Sans" rel="stylesheet">

<style>
    body {
        background: transparent !important;
        /* font-family: "Sawarabi Mincho", sans-serif !important; */
    }

    .bg_img {
        /* background-image: url('../../../../assets/phdizone_images/discount/dis_4.jpeg'), url('../../../../assets/phdizone_images/discount/dis.gif'); */
        /* background-size: cover !important;
        background-repeat: no-repeat;
        background-position: center; */
        /* background-position: center center, top right;
        background-repeat: no-repeat, no-repeat;
        background-size: cover, 200px 200px;
        border-radius: 10px !important; */

        background-image: url('../../../../assets/phdizone_images/discount/coupon_jif.gif'), url('../../../../assets/phdizone_images/discount/coupon_jif.gif');
        background-position: center, center center;
        background-repeat: no-repeat, no-repeat;
        background-size: cover, cover;
        background-blend-mode: lighten;
    }
    .bg_img2 {
        background-image: url('../../../../assets/phdizone_images/discount/dis_2.jpg');
        background-position: center, center center;
        background-repeat: no-repeat, no-repeat;
        background-size: cover, cover;
    }

    .txt_efft {
        text-decoration: none;
        text-align: center;
        line-height: 1;
        /* -webkit-text-stroke: 0.3px rgb(255, 255, 255); */
        -webkit-text-stroke: 0.001px rgb(255, 255, 255);
        transition: all 250ms;
        /* text-shadow: 10px 1px 10px rgb(107, 107, 107); */
        text-shadow: 10px 1px 10px #2e145a;
    }
    .txt_efft2 {
        text-decoration: none;
        text-align: center;
        line-height: 1;
        /* -webkit-text-stroke: 0.3px rgb(255, 255, 255); */
        -webkit-text-stroke: 1px #2e145a;
        transition: all 250ms;
        /* text-shadow: 10px 1px 10px rgb(107, 107, 107); */
        text-shadow: 10px 1px 10px #2e145a;
    }

    /* .txt_efft:hover {
        transform: translate(-1px, -1px)
    } */
    @media (max-width: 576px) {
        .comm {
            width: 250px !important;
            height: 250px !important;
            font-size: 40px !important;
        }

        .justify-content-xs-center {
            justify-content: center !important;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) {
        .w-sm-100 {
            width: 100% !important;
        }

        .comm {
            width: 375px !important;
            height: 375px !important;
            font-size: 40px !important;
        }

        .justify-content-sm-center {
            justify-content: center !important;
        }

        .text-sm-center {
            text-align: center !important;
        }
    }

    /* Medium devices (tablets, 768px and up) */
    @media (min-width: 768px) {
        .w-md-100 {
            width: 100% !important;
        }

        .comm {
            width: 400px !important;
            height: 400px !important;
            font-size: 80px !important;
        }

        .justify-content-md-center {
            justify-content: center !important;
        }

        .text-md-center {
            text-align: center !important;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) {
        .w-lg-50 {
            width: 50% !important;
        }

        .w-lg-350px {
            width: 350px !important;
        }

        .justify-content-lg-end {
            justify-content: end !important;
        }

        .h-lg-350px {
            height: 350px !important;
        }

        .comm {
            font-size: 70px !important;
        }
    }


    .circle-animation {
        background-color: transparent;
        border-radius: 50%;
        animation: pulse 2s infinite ease-in-out;
        margin: 50px auto;
    }

    @keyframes pulse {
        0% {
            transform: scale(1);
            opacity: 1;
        }

        50% {
            transform: scale(1.1);
            opacity: 1;
        }

        100% {
            transform: scale(1);
            opacity: 1;
        }
    }

    .button_call_now {
        font-weight: 400 !important;
        font-size: 2rem;
        margin: 0;
        cursor: pointer;
        padding: .1em .3em;
        --c: #e3e3e3;
        background-color: rgb(0, 38, 255) !important;
        color: rgb(214, 214, 214) !important;
        border: none;
        transform: perspective(500px) rotateY(calc(20deg*var(--_i, -1)));
        text-shadow: calc(var(--_i, -1)* 0.08em) -.01em 0 var(--c),
            calc(var(--_i, -1)*-0.08em) .01em 2px #0004;
        outline-offset: .1em;
        transition: 0.3s;
    }

    .button_call_now:hover,
    .button_call_now:focus-visible {
        --_p: 0%;
        --_i: 1;
        box-shadow: 0px 4px 9px 8px rgba(0, 0, 0, 0.42) !important;
    }

    .button_call_now:active {
        text-shadow: none;
        color: var(--c);
        box-shadow: inset 0 0 9e9q #0005;
        transition: 0s;
    }


    .button_download {
        font-weight: 400 !important;
        font-size: 2rem;
        margin: 0;
        cursor: pointer;
        padding: .1em .3em;
        --c: #e3e3e3;
        --_i: 1;
        /* Default left tilt */
        background-color: rgb(0, 38, 255) !important;
        color: rgb(214, 214, 214) !important;
        border: none;
        display: inline-block;
        transform: perspective(500px) rotateY(calc(20deg * var(--_i)));
        text-shadow: calc(var(--_i) * 0.08em) -.01em 0 var(--c),
            calc(var(--_i) * -0.08em) .01em 2px #0004;
        outline-offset: .1em;
        transition: transform 0.3s, box-shadow 0.3s, text-shadow 0.3s;
    }

    .button_download:hover,
    .button_download:focus-visible {
        --_i: -1;
        /* Reverse to right tilt on hover */
        box-shadow: 4px 4px 9px 8px rgba(0, 0, 0, 0.42) !important;
    }

    .button_download:active {
        text-shadow: none;
        color: var(--c);
        box-shadow: inset 0 0 9e9q #0005;
        transition: 0s;
    }
    @media (max-width: 576px) {
        .w-xs-25 {
            width: 25% !important;
        }

        .w-xs-50 {
            width: 50% !important;
        }

        .w-xs-75 {
            width: 75% !important;
        }

        .w-xs-100 {
            width: 100% !important;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) {

        .w-sm-25 {
            width: 25% !important;
        }

        .w-sm-50 {
            width: 50% !important;
        }

        .w-sm-75 {
            width: 75% !important;
        }

        .w-sm-100 {
            width: 100% !important;
        }

        .text-sm-center {
            text-align: center !important;
        }
    }

    /* Medium devices (tablets, 768px and up) */
    @media (min-width: 768px) {
        .w-md-25 {
            width: 25% !important;
        }

        .w-md-50 {
            width: 50% !important;
        }

        .w-md-75 {
            width: 75% !important;
        }

        .w-md-100 {
            width: 100% !important;
        }

        .text-md-center {
            text-align: center !important;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) {

        .w-lg-25 {
            width: 25% !important;
        }

        .w-lg-45 {
            width: 45% !important;
        }

        .w-lg-50 {
            width: 50% !important;
        }

        .w-lg-75 {
            width: 75% !important;
        }

        .w-lg-100 {
            width: 100% !important;
        }
    }
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $encryptedValue = $helper->encrypt_decrypt($QR_data->sno, 'encrypt');
    $url = url('/Event-Qr-Verify/' . $encryptedValue);
@endphp
@if($QR_main->discount_type == 0)
<!-- Disount In Percentage Start -->
<center>
    <div class="p-5 pb-0 mt-0 w-lg-50 w-md-100 w-sm-100">
        <div class="bg_img h-100">
            <div class="border border-gray-400i rounded pb-6">
                <div class="fs-2hx fw-bold mb-1 mx-3 mt-6">
                    <span class="text-black pt-1 bg-transparant txt_efft message1" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;" >"Congrats, Buddy!"</span>
                </div>
                <div class="fs-2hx fw-bold mb-10 mx-3 mt-2">
                    <span class="text-black pt-1 bg-transparant txt_efft message2" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;" >"This Offer is Just for You!"</span>
                </div>
                <div class="d-flex align-items-center justify-content-center comm bg-info text-white circle-animation flex-column fw-bold mb-1 mt-6 w-lg-350px h-lg-350px h-md-200px w-md-200px" style="padding:1.5rem !important;box-shadow: 0 0 15px 20px rgb(255 255 255 / 23%);">
                    <div>{{ number_format($QR_data->discount_value ?? 0) }}%</div>
                    <div class="d-block fs-4"><i>You've Unlocked a Special Deal & Saving Big!</i></div>
                </div>
                <div class="d-flex align-items-center justify-content-xs-center justify-content-sm-center justify-content-md-center justify-content-lg-end flex-wrap mb-2">
                    <div class="me-2 mb-4">
                        <div class="fs-2hx fw-bold mb-4 ms-3 mt-1">
                            <span class="bg-transparant text-black fw-semibold pt-1 txt_efft" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">Your Coupon Code!!!</span>
                        </div>
                        <div class="fs-2hx fw-bold ms-3 mt-1">
                            <div class="bg-white px-3 py-1">
                                <span class="text-black fw-semibold">{{ $QR_data->discount_code??'' }}</span>
                               @if($QR_main->expiry_date)
                                    @php
                                        $expiryDate = \Carbon\Carbon::parse($QR_main->expiry_date)->startOfDay();
                                        $today = now()->startOfDay();
                                    @endphp
                                
                                    <span class="d-block text-danger fw-bold fs-3" style="font-family: 'Exo 2', sans-serif !important;">
                                        (
                                        @if ($expiryDate->equalTo($today))
                                            Expires Today
                                        @elseif ($expiryDate->lessThan($today))
                                          <span class="mdi mdi-emoticon-sad-outline fs-4"></span>  Expired {{ $expiryDate->diffInDays($today) }} Day{{ $expiryDate->diffInDays($today) > 1 ? 's' : '' }} Ago
                                        @elseif ($expiryDate->greaterThan($today))
                                           Expires in {{ $expiryDate->diffInDays($today) }} Day{{ $expiryDate->diffInDays($today) > 1 ? 's' : '' }}
                                        @else
                                            Expired 
                                        @endif
                                        )
                                    </span>
                                @endif


                            </div>
                        </div>
                    </div>
                    <div class="mb-0 w-150px">
                        <img src="{{asset('assets/phdizone_images/discount/kid_2.gif')}}" width="150" height="150">
                    </div>
                </div>
                
                <div class="d-flex align-items-center justify-content-center flex-wrap gap-2 mb-2">
                    <a href="javascript:;" class="btn fw-bold btn-sm button_download mt-2" onclick="captureScreenshot()">Capture Offer</a>
                    <a href="{{ $Branch_data->mobile ?'tel:+91'.$Branch_data->mobile: 'javascript:;' }}" class="btn fw-bold btn-sm mt-2 button_call_now" onclick="call_try_count_save()">Connect Support</a>
                </div>
            </div>
        </div>
    </div>
</center>
<!-- Disount In Percentage End -->
@endif
@if($QR_main->discount_type == 1)
<!-- Disount In Amount Start -->
<center>
    <div class="p-5 pb-0 mt-0 w-lg-50 w-md-100 w-sm-100">
        <div class="bg_img h-100">
            <div class="border border-gray-400i rounded pb-6">
                <div class="fs-2hx fw-bold mb-1 mx-3 mt-6">
                    <span class="text-black pt-1 bg-transparant txt_efft message1" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">"Congrats, Buddy!"</span>
                </div>
                <div class="fs-2hx fw-bold mb-10 mx-3 mt-2">
                    <span class="text-black pt-1 bg-transparant txt_efft message2" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">"This Offer is Just for You!"</span>
                </div>
                <div class="d-flex align-items-center justify-content-center comm bg-info text-white circle-animation flex-column fw-bold mb-1 mt-6 w-lg-350px h-lg-350px h-md-200px w-md-200px" style="padding:1.5rem !important;box-shadow: 0 0 15px 20px rgb(255 255 255 / 23%);">
                    <div>&#8377;{{ number_format($QR_data->discount_value ?? 0) }}</div>
                    <div class="d-block fs-4"><i>Great Choice! Your Savings have Kicked In</i></div>
                </div>
                <div class="d-flex align-items-center justify-content-xs-center justify-content-sm-center justify-content-md-center justify-content-lg-end flex-wrap mb-2">
                    <div class="me-2 mb-4">
                        <div class="fs-2hx fw-bold mb-4 ms-3 mt-1">
                            <span class="bg-transparant text-black fw-semibold pt-1 txt_efft" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">Your Coupon Code!!!</span>
                        </div>
                        <div class="fs-2hx fw-bold ms-3 mt-1">
                            <div class="bg-white px-3 py-1">
                                <span class="text-black fw-semibold">{{ $QR_data->discount_code??'' }}</span>
                                @if($QR_main->expiry_date)
                                    @php
                                        $expiryDate = \Carbon\Carbon::parse($QR_main->expiry_date)->startOfDay();
                                        $today = now()->startOfDay();
                                    @endphp
                                
                                    <span class="d-block text-danger fw-bold fs-3" style="font-family: 'Exo 2', sans-serif !important;">
                                        (
                                        @if ($expiryDate->equalTo($today))
                                            Expires Today
                                        @elseif ($expiryDate->lessThan($today))
                                          <span class="mdi mdi-emoticon-sad-outline fs-4"></span>  Expired {{ $expiryDate->diffInDays($today) }} Day{{ $expiryDate->diffInDays($today) > 1 ? 's' : '' }} Ago
                                        @elseif ($expiryDate->greaterThan($today))
                                           Expires in {{ $expiryDate->diffInDays($today) }} Day{{ $expiryDate->diffInDays($today) > 1 ? 's' : '' }}
                                        @else
                                            Expired 
                                        @endif
                                        )
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="mb-0 w-150px">
                        <img src="{{asset('assets/phdizone_images/discount/kid_2.gif')}}" width="150" height="150">
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-center flex-wrap gap-2 mb-2">
                    <a href="javascript:;" class="btn fw-bold btn-sm button_download mt-2" onclick="captureScreenshot()">Capture Offer</a>
                    <a href="{{ $Branch_data->mobile ?'tel:+91'.$Branch_data->mobile: 'javascript:;' }}" class="btn fw-bold btn-sm mt-2 button_call_now" onclick="call_try_count_save()">Connect Support</a>
                </div>
            </div>
        </div>
    </div>
</center>
<!-- Disount In Amount End -->
@endif
@if($QR_main->discount_type == 2)
<!-- Disount In Free Course Start -->
<center>
    <div class="p-5 pb-0 mt-0 w-lg-50 w-md-100 w-sm-100">
        <div class="bg_img h-100">
            <div class="border border-gray-400i rounded pb-6">
                <div class="fs-2hx fw-bold mb-1 mx-3 mt-6">
                    <span class="text-black pt-1 bg-transparant txt_efft message1" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">"Congrats, Buddy!"</span>
                </div>
                <div class="fs-2hx fw-bold mb-1 mx-3 mt-2">
                    <span class="text-black pt-1 bg-transparant txt_efft message2" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">"This Offer is Just for You!"</span>
                </div>
                <div class="d-flex align-items-center justify-content-center fs-1 fw-bold mb-1">
                    <div class="bg-info rounded text-white circle-animation mb-4" style="font-size: 26px !important;padding:0rem 1.5rem 0rem 1.5rem !important;box-shadow: 0 0 15px 20px rgb(255 255 255 / 23%);">Free Course</div>
                </div>
                <div class="d-flex align-items-center justify-content-center fs-1 mb-8">
                    <div class="badge bg-warning text-black border border-dark fw-bold fs-2 flex-column rounded mx-4" style="padding:0rem 1.5rem 0rem 1.5rem !important; word-break: break-word; white-space: normal;line-height:35px !important;">{{$Course_name??''}}</div>
                </div>
                <div class="d-flex align-items-center justify-content-xs-center justify-content-sm-center justify-content-md-center justify-content-lg-end flex-wrap mb-2">
                    <div class="me-2 mb-4">
                        <div class="fs-2hx fw-bold mb-4 ms-3 mt-1">
                            <span class="bg-transparant text-black fw-semibold pt-1 txt_efft" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">Your Coupon Code!!!</span>
                        </div>
                        <div class="fs-2hx fw-bold ms-3 mt-1">
                            <div class="bg-white px-3 py-1">
                                <span class="text-black fw-semibold">{{ $QR_data->discount_code??'' }}</span>
                               @if($QR_main->expiry_date)
                                    @php
                                        $expiryDate = \Carbon\Carbon::parse($QR_main->expiry_date)->startOfDay();
                                        $today = now()->startOfDay();
                                    @endphp
                                
                                    <span class="d-block text-danger fw-bold fs-3" style="font-family: 'Exo 2', sans-serif !important;">
                                        (
                                        @if ($expiryDate->equalTo($today))
                                            Expires Today
                                        @elseif ($expiryDate->lessThan($today))
                                          <span class="mdi mdi-emoticon-sad-outline fs-4"></span>  Expired {{ $expiryDate->diffInDays($today) }} Day{{ $expiryDate->diffInDays($today) > 1 ? 's' : '' }} Ago
                                        @elseif ($expiryDate->greaterThan($today))
                                           Expires in {{ $expiryDate->diffInDays($today) }} Day{{ $expiryDate->diffInDays($today) > 1 ? 's' : '' }}
                                        @else
                                            Expired 
                                        @endif
                                        )
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="mb-0 w-150px">
                        <img src="{{asset('assets/phdizone_images/discount/kid_2.gif')}}" width="150" height="150">
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-center flex-wrap gap-2 mb-2">
                    <a href="javascript:;" class="btn fw-bold btn-sm button_download mt-2" onclick="captureScreenshot()">Capture Offer</a>
                    <a href="{{ $Branch_data->mobile ?'tel:+91'.$Branch_data->mobile: 'javascript:;' }}" class="btn fw-bold btn-sm mt-2 button_call_now" onclick="call_try_count_save()">Connect Support</a>
                </div>
            </div>
        </div>
    </div>
</center>
<!-- Disount In Free Course End -->
@endif
@if($QR_main->discount_type == 3)
<!-- Disount In Free Workshop Start -->
<center>
    <div class="p-5 pb-0 mt-0 w-lg-50 w-md-100 w-sm-100">
        <div class="bg_img h-100">
            <div class="border border-gray-400i rounded pb-6">
                <div class="fs-2hx fw-bold mb-1 mx-3 mt-6">
                    <span class="text-black pt-1 bg-transparant txt_efft message1" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">"Congrats, Buddy!"</span>
                </div>
                <div class="fs-2hx fw-bold mb-1 mx-3 mt-2">
                    <span class="text-black pt-1 bg-transparant txt_efft message2" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">"This Offer is Just for You!"</span>
                </div>
                <div class="d-flex align-items-center justify-content-center fs-1 fw-bold mb-1">
                    <div class="bg-info rounded text-white circle-animation mb-4" style="font-size: 26px !important;padding:0rem 1.5rem 0rem 1.5rem !important;box-shadow: 0 0 15px 20px rgb(255 255 255 / 23%);">Free Workshop</div>
                </div>
                <div class="d-flex align-items-center justify-content-center fs-1 fw-bold mb-8">
                    <div class="badge bg-warning text-black border border-dark fw-bold fs-2 flex-column rounded mx-4" style="padding:0rem 1.5rem 0rem 1.5rem !important; word-break: break-word; white-space: normal;line-height:35px !important;">{{$QR_main->discount_name??''}}</div>
                </div>
                <div class="d-flex align-items-center justify-content-xs-center justify-content-sm-center justify-content-md-center justify-content-lg-end flex-wrap mb-2">
                    <div class="me-2 mb-4">
                        <div class="fs-2hx fw-bold mb-4 ms-3 mt-1">
                            <span class="bg-transparant text-black fw-semibold pt-1 txt_efft" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">Your Coupon Code!!!</span>
                        </div>
                        <div class="fs-2hx fw-bold ms-3 mt-1">
                            <div class="bg-white px-3 py-1">
                                <span class="text-black fw-semibold">{{ $QR_data->discount_code??'' }}</span>
                                @if($QR_main->expiry_date)
                                    @php
                                        $expiryDate = \Carbon\Carbon::parse($QR_main->expiry_date)->startOfDay();
                                        $today = now()->startOfDay();
                                    @endphp
                                
                                    <span class="d-block text-danger fw-bold fs-3" style="font-family: 'Exo 2', sans-serif !important;">
                                        (
                                        @if ($expiryDate->equalTo($today))
                                            Expires Today
                                        @elseif ($expiryDate->lessThan($today))
                                          <span class="mdi mdi-emoticon-sad-outline fs-4"></span>  Expired {{ $expiryDate->diffInDays($today) }} Day{{ $expiryDate->diffInDays($today) > 1 ? 's' : '' }} Ago
                                        @elseif ($expiryDate->greaterThan($today))
                                           Expires in {{ $expiryDate->diffInDays($today) }} Day{{ $expiryDate->diffInDays($today) > 1 ? 's' : '' }}
                                        @else
                                            Expired 
                                        @endif
                                        )
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="mb-0 w-150px">
                        <img src="{{asset('assets/phdizone_images/discount/kid_2.gif')}}" width="150" height="150">
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-center flex-wrap gap-2 mb-2">
                    <a href="javascript:;" class="btn fw-bold btn-sm button_download mt-2" onclick="captureScreenshot()">Capture Offer</a>
                    <a href="{{ $Branch_data->mobile ?'tel:+91'.$Branch_data->mobile: 'javascript:;' }}" class="btn fw-bold btn-sm mt-2 button_call_now" onclick="call_try_count_save()">Connect Support</a>
                </div>
            </div>
        </div>
    </div>
</center>
<!-- Disount In Free Workshop End -->
@endif
@if($QR_main->discount_type == 4)
<center>
    
    <div class="p-5 pb-0 mt-0 w-lg-50 w-md-100 w-sm-100 ">
        <div class="bg_img2 h-100 rounded">
            <div class="d-flex align-items-center justify-content-center mb-3" style="border-top-left-radius:5px !important;border-top-right-radius:5px !important;">
                <div class="mb-1 mt-2">
                    <img src="{{asset('assets/phdizone_images/ea_full_logo.png')}}" class="w-xs-75 w-sm-50 w-md-50 w-lg-50">
                </div>
            </div>
            <div class="mb-4">
                 @php
                    $eventname = $helper->get_event_name_data($QR_data->discount_value)->event_name ?? '-';
                @endphp
                
                @if($Verifed == 1)
                <div class="text-black fs-2hx fw-bold mb-3 txt_efft2 px-1" style="font-family: 'Black Han Sans', sans-serif !important;color:#FFFFFF !important;">
                    {{$eventname??''}} Event 
                </div>
                <div class="d-flex align-items-center justify-content-xs-center justify-content-sm-center justify-content-md-center justify-content-lg-center flex-wrap mb-2">
                    <div class="me-2 mb-4">
                        <div class="fs-2hx fw-bold ms-3 mt-1">
                            <div class="px-3 py-1 rounded">
                                <img src="{{asset('assets/phdizone_images/discount/Verified.gif')}}" alt="Verified Pass" class="image-input-wrapper" style="width:300px !important;height:300px  !important;" />
                                <!--<label class="text-black fw-semibold " style="font-family: cursive;color: #478324 !important;">Verified Pass</label>-->
                            </div>
                        </div>
                    </div>
                </div>
                @else
                <div class="text-black fs-2hx fw-bold mb-3 txt_efft2 px-1" style="font-family: 'Black Han Sans', sans-serif !important;color:#FFFFFF !important;">
                    Welcome to {{$eventname??''}} Event 
                </div>
                <div class="d-flex align-items-center justify-content-xs-center justify-content-sm-center justify-content-md-center justify-content-lg-center flex-wrap mb-2">
                    <div class="me-2 mb-4">
                        <div class="fs-2hx fw-bold ms-3 mt-1">
                            <div class="bg-white px-3 py-1">
                                <span class="text-black fw-semibold" id="Qr_codediv">{{ $QR_data->discount_code??'' }}</span>
                            </div>
                        </div>
                    </div>
                </div>
                @endif
                
                <div class="fs-2hx fw-bold mb-4 ms-3 mt-1">
                    <span class="bg-transparant text-black fw-semibold pt-1 txt_efft2" style="font-family: 'Black Han Sans', sans-serif !important;color:#FFFFFF !important;">{{$QR_data->discount_lead_name??'N/A'}}</span>
                </div>
                <div class="fs-2hx fw-bold mb-4 ms-3 mt-1">
                   <span class="bg-transparant text-black fw-semibold pt-1 txt_efft2" style="font-family: 'Black Han Sans', sans-serif !important;color:#FFFFFF !important;">{{$QR_data->discount_lead_phone??'N/A'}}</span>
                </div>
                @if($Verifed == 0)
                <div class="d-flex align-items-center justify-content-center flex-wrap gap-2 mb-4">
                    <a href="javascript:;" class="btn fw-bold btn-sm button_download mt-2 mb-2" onclick="captureScreenshot()">Download Pass</a>
                </div>
                @endif
            </div>
        </div>
    </div>
</center>
<!-- Disount In Free Seminar End -->
@endif
@if($QR_main->discount_type == 5)
<!-- Disount In Free Gift Start -->
<center>
    <div class="p-5 pb-0 mt-0 w-lg-50 w-md-100 w-sm-100">
        <div class="bg_img h-100">
            <div class="border border-gray-400i rounded pb-6">
                <div class="fs-2hx fw-bold mb-1 mx-3 mt-6">
                    <span class="text-black pt-1 bg-transparant txt_efft message1" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">"Congrats, Buddy!"</span>
                </div>
                <div class="fs-2hx fw-bold mb-1 mx-3 mt-2">
                    <span class="text-black pt-1 bg-transparant txt_efft message2" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">"This Offer is Just for You!"</span>
                </div>
                <div class="d-flex align-items-center justify-content-center fs-1 fw-bold mb-1">
                    <div class="bg-info rounded text-white circle-animation mb-4" style="font-size: 26px !important;padding:0rem 1.5rem 0rem 1.5rem !important;box-shadow: 0 0 15px 20px rgb(255 255 255 / 23%);">Free Gifts</div>
                </div>
                <div class="d-flex align-items-center justify-content-center gap-2 fs-1 fw-bold mb-8">
                    <div class="badge bg-warning text-black border border-dark fw-bold fs-2 flex-column rounded mx-4" style="padding:0rem 1.5rem 0rem 1.5rem !important; word-break: break-word; white-space: normal;line-height:35px !important;">
                        @php
                            $name = $helper->get_gifts_data($QR_data->discount_value)->gift_name ?? 'Try Again Later';
                        @endphp
                        {{$name??'Try Again Later'}}
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-xs-center justify-content-sm-center justify-content-md-center justify-content-lg-end flex-wrap mb-2">
                    <div class="me-2 mb-4">
                        <div class="fs-2hx fw-bold mb-4 ms-3 mt-1">
                            <span class="bg-transparant text-black fw-semibold pt-1 txt_efft" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">Your Coupon Code!!!</span>
                        </div>
                        <div class="fs-2hx fw-bold ms-3 mt-1">
                            <div class="bg-white px-3 py-1">
                                <span class="text-black fw-semibold">{{ $QR_data->discount_code??'' }}</span>
                                @if($QR_main->expiry_date)
                                    @php
                                        $expiryDate = \Carbon\Carbon::parse($QR_main->expiry_date)->startOfDay();
                                        $today = now()->startOfDay();
                                    @endphp
                                
                                    <span class="d-block text-danger fw-bold fs-3" style="font-family: 'Exo 2', sans-serif !important;">
                                        (
                                        @if ($expiryDate->equalTo($today))
                                            Expires Today
                                        @elseif ($expiryDate->lessThan($today))
                                          <span class="mdi mdi-emoticon-sad-outline fs-4"></span>  Expired {{ $expiryDate->diffInDays($today) }} Day{{ $expiryDate->diffInDays($today) > 1 ? 's' : '' }} Ago
                                        @elseif ($expiryDate->greaterThan($today))
                                           Expires in {{ $expiryDate->diffInDays($today) }} Day{{ $expiryDate->diffInDays($today) > 1 ? 's' : '' }}
                                        @else
                                            Expired 
                                        @endif
                                        )
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="mb-0 w-150px">
                        <img src="{{asset('assets/phdizone_images/discount/kid_2.gif')}}" width="150" height="150">
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-center flex-wrap gap-2 mb-2">
                    <a href="javascript:;" class="btn fw-bold btn-sm button_download mt-2" onclick="captureScreenshot()">Capture Offer</a>
                    <a href="{{ $Branch_data->mobile ?'tel:+91'.$Branch_data->mobile: 'javascript:;' }}" class="btn fw-bold btn-sm mt-2 button_call_now" onclick="call_try_count_save()">Connect Support</a>
                </div>
                <!--<small><u>Tc Apply</u></small>-->
            </div>
        </div>
    </div>
</center>
<!-- Disount In Free Gift End -->
@endif
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
@if($QR_main->discount_type == 4)
generateQRCode()
@endif

    function generateQRCode() {
      const val = '{{$url}}';
      const qrText = val;
      const qrcodeContainer = document.getElementById("Qr_codediv");
      qrcodeContainer.innerHTML = ""; // Clear previous QR

      const qr = new QRCode(qrcodeContainer, {
        text: qrText,
        width: 256,
        height: 256,
        correctLevel: QRCode.CorrectLevel.H
      });

      // Wait for QR to render, then convert to image and download
    //   setTimeout(() => {
    //     const img = qrcodeContainer.querySelector("img") || qrcodeContainer.querySelector("canvas");
    //     if (img) {
    //       const dataUrl = img.src || img.toDataURL();
    //       const link = document.createElement("a");
    //       link.href = dataUrl;
    //       link.download = name+"-qr-code.png";
    //       link.click();
    //     }
    //   }, 500); // Give it a moment to render
    }
</script>
 <script>
    function captureScreenshot() {
      html2canvas(document.body).then(canvas => {
        const link = document.createElement("a");
        link.download = "Elysium-QR-Discount.png";
        link.href = canvas.toDataURL("image/png");
        link.click();
      }).catch(error => {
        // console.error("Screenshot failed:", error);
        // alert("Screenshot failed. See console for error.");
      });
    }
  </script>
<!--<script src="{{url ('assets/custom_file/animation.js')}}"></script>-->
 <script>
    !function(t,e){!function t(e,n,a,i){var o=!!(e.Worker&&e.Blob&&e.Promise&&e.OffscreenCanvas&&e.OffscreenCanvasRenderingContext2D&&e.HTMLCanvasElement&&e.HTMLCanvasElement.prototype.transferControlToOffscreen&&e.URL&&e.URL.createObjectURL);function r(){}function l(t){var a=n.exports.Promise,i=void 0!==a?a:e.Promise;return"function"==typeof i?new i(t):(t(r,r),null)}var c,s,u,d,f,h,m,g,b,v=(u=Math.floor(1e3/60),d={},f=0,"function"==typeof requestAnimationFrame&&"function"==typeof cancelAnimationFrame?(c=function(t){var e=Math.random();return d[e]=requestAnimationFrame((function n(a){f===a||f+u-1<a?(f=a,delete d[e],t()):d[e]=requestAnimationFrame(n)})),e},s=function(t){d[t]&&cancelAnimationFrame(d[t])}):(c=function(t){return setTimeout(t,u)},s=function(t){return clearTimeout(t)}),{frame:c,cancel:s}),p=(g={},function(){if(h)return h;if(!a&&o){var e=["var CONFETTI, SIZE = {}, module = {};","("+t.toString()+")(this, module, true, SIZE);","onmessage = function(msg) {","  if (msg.data.options) {","    CONFETTI(msg.data.options).then(function () {","      if (msg.data.callback) {","        postMessage({ callback: msg.data.callback });","      }","    });","  } else if (msg.data.reset) {","    CONFETTI.reset();","  } else if (msg.data.resize) {","    SIZE.width = msg.data.resize.width;","    SIZE.height = msg.data.resize.height;","  } else if (msg.data.canvas) {","    SIZE.width = msg.data.canvas.width;","    SIZE.height = msg.data.canvas.height;","    CONFETTI = module.exports.create(msg.data.canvas);","  }","}"].join("\n");try{h=new Worker(URL.createObjectURL(new Blob([e])))}catch(t){return void 0!==typeof console&&"function"==typeof console.warn&&console.warn("🎊 Could not load worker",t),null}!function(t){function e(e,n){t.postMessage({options:e||{},callback:n})}t.init=function(e){var n=e.transferControlToOffscreen();t.postMessage({canvas:n},[n])},t.fire=function(n,a,i){if(m)return e(n,null),m;var o=Math.random().toString(36).slice(2);return m=l((function(a){function r(e){e.data.callback===o&&(delete g[o],t.removeEventListener("message",r),m=null,i(),a())}t.addEventListener("message",r),e(n,o),g[o]=r.bind(null,{data:{callback:o}})}))},t.reset=function(){for(var e in t.postMessage({reset:!0}),g)g[e](),delete g[e]}}(h)}return h}),y={particleCount:50,angle:90,spread:45,startVelocity:45,decay:.9,gravity:1,drift:0,ticks:200,x:.5,y:.5,shapes:["square","circle"],zIndex:100,colors:["#26ccff","#a25afd","#ff5e7e","#88ff5a","#fcff42","#ffa62d","#ff36ff"],disableForReducedMotion:!1,scalar:1};function M(t,e,n){return function(t,e){return e?e(t):t}(t&&null!=t[e]?t[e]:y[e],n)}function w(t){return t<0?0:Math.floor(t)}function x(t){return parseInt(t,16)}function C(t){return t.map(k)}function k(t){var e=String(t).replace(/[^0-9a-f]/gi,"");return e.length<6&&(e=e[0]+e[0]+e[1]+e[1]+e[2]+e[2]),{r:x(e.substring(0,2)),g:x(e.substring(2,4)),b:x(e.substring(4,6))}}function I(t){t.width=document.documentElement.clientWidth,t.height=document.documentElement.clientHeight}function S(t){var e=t.getBoundingClientRect();t.width=e.width,t.height=e.height}function T(t,e,n,o,r){var c,s,u=e.slice(),d=t.getContext("2d"),f=l((function(e){function l(){c=s=null,d.clearRect(0,0,o.width,o.height),r(),e()}c=v.frame((function e(){!a||o.width===i.width&&o.height===i.height||(o.width=t.width=i.width,o.height=t.height=i.height),o.width||o.height||(n(t),o.width=t.width,o.height=t.height),d.clearRect(0,0,o.width,o.height),u=u.filter((function(t){return function(t,e){e.x+=Math.cos(e.angle2D)*e.velocity+e.drift,e.y+=Math.sin(e.angle2D)*e.velocity+e.gravity,e.wobble+=e.wobbleSpeed,e.velocity*=e.decay,e.tiltAngle+=.1,e.tiltSin=Math.sin(e.tiltAngle),e.tiltCos=Math.cos(e.tiltAngle),e.random=Math.random()+2,e.wobbleX=e.x+10*e.scalar*Math.cos(e.wobble),e.wobbleY=e.y+10*e.scalar*Math.sin(e.wobble);var n=e.tick++/e.totalTicks,a=e.x+e.random*e.tiltCos,i=e.y+e.random*e.tiltSin,o=e.wobbleX+e.random*e.tiltCos,r=e.wobbleY+e.random*e.tiltSin;return t.fillStyle="rgba("+e.color.r+", "+e.color.g+", "+e.color.b+", "+(1-n)+")",t.beginPath(),"circle"===e.shape?t.ellipse?t.ellipse(e.x,e.y,Math.abs(o-a)*e.ovalScalar,Math.abs(r-i)*e.ovalScalar,Math.PI/10*e.wobble,0,2*Math.PI):function(t,e,n,a,i,o,r,l,c){t.save(),t.translate(e,n),t.rotate(o),t.scale(a,i),t.arc(0,0,1,r,l,c),t.restore()}(t,e.x,e.y,Math.abs(o-a)*e.ovalScalar,Math.abs(r-i)*e.ovalScalar,Math.PI/10*e.wobble,0,2*Math.PI):(t.moveTo(Math.floor(e.x),Math.floor(e.y)),t.lineTo(Math.floor(e.wobbleX),Math.floor(i)),t.lineTo(Math.floor(o),Math.floor(r)),t.lineTo(Math.floor(a),Math.floor(e.wobbleY))),t.closePath(),t.fill(),e.tick<e.totalTicks}(d,t)})),u.length?c=v.frame(e):l()})),s=l}));return{addFettis:function(t){return u=u.concat(t),f},canvas:t,promise:f,reset:function(){c&&v.cancel(c),s&&s()}}}function E(t,n){var a,i=!t,r=!!M(n||{},"resize"),c=M(n,"disableForReducedMotion",Boolean),s=o&&!!M(n||{},"useWorker")?p():null,u=i?I:S,d=!(!t||!s)&&!!t.__confetti_initialized,f="function"==typeof matchMedia&&matchMedia("(prefers-reduced-motion)").matches;function h(e,n,i){for(var o,r,l,c,s,d=M(e,"particleCount",w),f=M(e,"angle",Number),h=M(e,"spread",Number),m=M(e,"startVelocity",Number),g=M(e,"decay",Number),b=M(e,"gravity",Number),v=M(e,"drift",Number),p=M(e,"colors",C),y=M(e,"ticks",Number),x=M(e,"shapes"),k=M(e,"scalar"),I=function(t){var e=M(t,"origin",Object);return e.x=M(e,"x",Number),e.y=M(e,"y",Number),e}(e),S=d,E=[],F=t.width*I.x,N=t.height*I.y;S--;)E.push((o={x:F,y:N,angle:f,spread:h,startVelocity:m,color:p[S%p.length],shape:x[(c=0,s=x.length,Math.floor(Math.random()*(s-c))+c)],ticks:y,decay:g,gravity:b,drift:v,scalar:k},r=void 0,l=void 0,r=o.angle*(Math.PI/180),l=o.spread*(Math.PI/180),{x:o.x,y:o.y,wobble:10*Math.random(),wobbleSpeed:Math.min(.11,.1*Math.random()+.05),velocity:.5*o.startVelocity+Math.random()*o.startVelocity,angle2D:-r+(.5*l-Math.random()*l),tiltAngle:(.5*Math.random()+.25)*Math.PI,color:o.color,shape:o.shape,tick:0,totalTicks:o.ticks,decay:o.decay,drift:o.drift,random:Math.random()+2,tiltSin:0,tiltCos:0,wobbleX:0,wobbleY:0,gravity:3*o.gravity,ovalScalar:.6,scalar:o.scalar}));return a?a.addFettis(E):(a=T(t,E,u,n,i)).promise}function m(n){var o=c||M(n,"disableForReducedMotion",Boolean),m=M(n,"zIndex",Number);if(o&&f)return l((function(t){t()}));i&&a?t=a.canvas:i&&!t&&(t=function(t){var e=document.createElement("canvas");return e.style.position="fixed",e.style.top="0px",e.style.left="0px",e.style.pointerEvents="none",e.style.zIndex=t,e}(m),document.body.appendChild(t)),r&&!d&&u(t);var g={width:t.width,height:t.height};function b(){if(s){var e={getBoundingClientRect:function(){if(!i)return t.getBoundingClientRect()}};return u(e),void s.postMessage({resize:{width:e.width,height:e.height}})}g.width=g.height=null}function v(){a=null,r&&e.removeEventListener("resize",b),i&&t&&(document.body.removeChild(t),t=null,d=!1)}return s&&!d&&s.init(t),d=!0,s&&(t.__confetti_initialized=!0),r&&e.addEventListener("resize",b,!1),s?s.fire(n,g,v):h(n,g,v)}return m.reset=function(){s&&s.reset(),a&&a.reset()},m}function F(){return b||(b=E(null,{useWorker:!0,resize:!0})),b}n.exports=function(){return F().apply(this,arguments)},n.exports.reset=function(){F().reset()},n.exports.create=E}(function(){return void 0!==t?t:"undefined"!=typeof self?self:this||{}}(),e,!1),t.confetti=e.exports}(window,{});

    function startConfetti() {
        window.confetti({particleCount: 100, spread: 90, startVelocity: 60, colors: ['#ff6b6b', '#ff9f43', '#4ecdc4', '#f7fff7']});
    }
</script>
<script>
    // Array of possible messages for message1 and message2
    const messages1 = [
                        "You're Crushing It!",
                        "Legendary Effort!",
                        "That's the Spirit!",
                        "Victory Looks Good on You!",
                        "You Nailed It!",
                        "Look at You Go!",
                        "Success Suits You!",
                        "You're a Natural!",
                        "Killing It Today!",
                        "That's How It's Done!",
                        "Power Move!",
                        "You Make It Look Easy!",
                        "Shining Bright Like a Star!",
                        "You're a Rockstar!",
                        "Boom! Done Like a Pro!",
                        "Every Step Counts — Keep Going!",
                        "Greatness Achieved!",
                        "Onwards and Upwards!",
                        "Top of Your Game!",
                        "Your Effort is Paying Off!",
                        "Superb Move!",
                        "That Was Flawless!",
                        "One More Win for the Books!",
                        "You've Got the Midas Touch!",
                        "Another Victory in the Bag!"
                    ];
    
    const messages2 = [
                        "You've Earned Something Special!",
                        "Get Ready to Be Surprised!",
                        "A Handpicked Offer Awaits You!",
                        "This One's Just for You!",
                        "Congratulations! Claim Your Reward!",
                        "You're Just in Time for a Deal!",
                        "Don't Miss This VIP Offer!",
                        "The Clock is Ticking on This Gift!",
                        "It's All Yours — Just Click!",
                        "Limited Time, Unlimited Joy!",
                        "Seize Your Exclusive Opportunity!",
                        "Gift Unlocked: Open Now!",
                        "Your Reward is a Click Away!",
                        "Time-Sensitive Surprise Inside!",
                        "Celebrate with a Special Deal!",
                        "Perks Just Got Personal!",
                        "Discount Magic Has Arrived!",
                        "This Deal is Hot — Don't Wait!",
                        "Rewards Like These Don't Last!",
                        "It's Reward Time!",
                        "Your Treat is Waiting!",
                        "Open Your Surprise!",
                        "Take Advantage Before It's Gone!",
                        "Personalized. Exclusive. Yours."
                    ];
    // Function to pick a random message from an array
    function getRandomMessage(messages) {
        return messages[Math.floor(Math.random() * messages.length)];
    }
</script>
<script>
    window.onload = function() {
        confetti({
            particleCount: 1000,
            spread: 150,
            origin: {
                y: 0.5
            }
        });

        setTimeout(() => {}, 20000); // Wait for 10 seconds
        $('.message1').html(getRandomMessage(messages1));
        $('.message2').html(getRandomMessage(messages2));
        $('#page-loader').html('');
        $('#page-loader').removeAttr('style');


    }
</script>
<script>
function call_try_count_save(){
    const branch_id = {{ $QR_data->branch_id }};
    const lead_id = {{ $QR_data->sno }};
    const discount_id = {{ $QR_main->sno }};
    // alert(lead_id)
    $.ajax({
        url: '{{ route("add_call_try_count") }}',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        data: JSON.stringify({ 
            branch_id: branch_id,
            discount_id: discount_id,
            lead_id: lead_id,
        }),
        success: function(response) {
            if (response.success) {
            //   alert('updated')
            } else {
                
            }
        },
        error: function() {
        }
    });
}
</script>
@endsection