@extends('layouts/blankLayout')

@section('title', 'Discount QR')

@section('content')
<link href="https://fonts.googleapis.com/css2?family=Wendy+One&display=swap" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Black Han Sans" rel="stylesheet">
<style>
    body {
        background: transparent !important;
    }

    table tbody td {
        padding: 10px !important;
    }

    .bg_img {
        background-image: url('../../../../assets/phdizone_images/discount/izone_bg.jpg');
        background-size: cover !important;
        background-repeat: no-repeat;
        background-position: center;
        /* border-radius: 10px !important; */
    }

    @media (max-width: 576px) {
        .w-xs-25 {
            width: 25% !important;
        }

        .w-xs-50 {
            width: 50% !important;
        }

        .w-xs-75 {
            width: 75% !important;
        }

        .w-xs-100 {
            width: 100% !important;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) {

        .w-sm-25 {
            width: 25% !important;
        }

        .w-sm-50 {
            width: 50% !important;
        }

        .w-sm-75 {
            width: 75% !important;
        }

        .w-sm-100 {
            width: 100% !important;
        }

        .text-sm-center {
            text-align: center !important;
        }
    }

    /* Medium devices (tablets, 768px and up) */
    @media (min-width: 768px) {
        .w-md-25 {
            width: 25% !important;
        }

        .w-md-50 {
            width: 50% !important;
        }

        .w-md-75 {
            width: 75% !important;
        }

        .w-md-100 {
            width: 100% !important;
        }

        .text-md-center {
            text-align: center !important;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) {

        .w-lg-25 {
            width: 25% !important;
        }

        .w-lg-45 {
            width: 45% !important;
        }

        .w-lg-50 {
            width: 50% !important;
        }

        .w-lg-75 {
            width: 75% !important;
        }

        .w-lg-100 {
            width: 100% !important;
        }
    }

    .txt_efft {
        text-decoration: none;
        text-align: center;
        line-height: 1;
        /* -webkit-text-stroke: 0.3px rgb(255, 255, 255); */
        -webkit-text-stroke: 0.001px rgb(255, 255, 255);
        transition: all 250ms;
        /* text-shadow: 10px 1px 10px rgb(107, 107, 107); */
        text-shadow: 10px 1px 10px #2e145a;
    }

    .txt_efft_label {
        color:#efefef !important;
    }
    .w-70{
        width:70% !important;
    }
</style>
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
<center>
     <div class="p-5 mt-0 w-lg-45 w-md-100 w-sm-100">
        <div class="border border-gray-500i bg_img rounded">
            <!--style="background-color: #dddddd;border-top-left-radius:5px !important;border-top-right-radius:5px !important;"-->
            <div class="d-flex align-items-center justify-content-center mb-3" >
                <div class="mb-1 mt-2">
                    <img src="{{asset('assets/phdizone_images/phdizone_logo.png')}}" class="w-xs-75 w-sm-50 w-md-50 w-lg-50">
                </div>
            </div>
            <div class="mb-4">
                <hr class="mt-1 mb-6">
                <div class="text-black fs-2hx fw-bold mb-3 txt_efft px-1" style="font-family: 'Black Han Sans', sans-serif !important;color:#2d0b65 !important;">
                    @if($QR_data->discount_type == 4) 
                    Welcome to Event 
                    @else 
                    Welcome to Discount Zone 
                    @endif
                </div>
                <hr class="mt-1 mb-6">
                <div class="">
                    <div class="w-70 mb-5">
                       <label class="text-black float-start mb-1 fs-6 fw-semibold txt_efft_label">Enter Your Mobile No <span class="text-black">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Your Mobile No" id="mobile_number" maxlength="10" placeholder="Enter Mobile Number" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                        <div class="text-center mt-1" id="mobile_div" style="display:none;">
                            <span class="bg-danger rounded fw-bold fs-7 text-white text-start border border-white px-2 py-1" id="mobile_number_err"></span>
                        </div>
                    </div>
                    <div class="w-70 mb-5">
                        <label class="text-black float-start mb-1 fs-6 fw-semibold txt_efft_label">Enter Your Name <span class="text-black">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Your Name" id="lead_name"  oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"/>
                        <div class="text-center mt-1" id="name_div" style="display:none;"> 
                            <span class="bg-danger rounded fw-bold fs-7 text-white text-start border border-white px-2 py-1" id="lead_name_err"></span>
                        </div>
                    </div>
                </div>
            </div>
            @if($QR_data->discount_type == 0)
             <button type="button" class="btn fw-bold btn-primary border border-white mb-8 mt-4" onclick="generate_discount()">GET MY DISCOUNT</button>
            @elseif($QR_data->discount_type == 1)
             <button type="button" class="btn fw-bold btn-primary border border-white mb-8 mt-4" onclick="generate_discount()">GET MY DISCOUNT AMOUNT</button>
            <!--@elseif($QR_data->discount_type == 2)-->
            <!-- <button type="button" class="btn fw-bold btn-primary border border-white mb-8 mt-4" onclick="generate_discount()">GET MY FREE COURSE</button>-->
            <!--@elseif($QR_data->discount_type == 4)-->
            <!--    <button type="button" class="btn fw-bold btn-primary border border-white mb-8 mt-4" onclick="generate_discount()">GET MY EVENT</button>-->
            <!--@elseif($QR_data->discount_type == 5)-->
            <!--    <button type="button" class="btn fw-bold btn-primary border border-white mb-8 mt-4" onclick="generate_discount()">GET MY FREE GIFT</button>-->
            @else
                <button type="button" class="btn fw-bold btn-primary border border-white mb-8 mt-4" onclick="generate_discount()">GET MY DISCOUNT</button>
            @endif
           
        </div>
    </div>
</center>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
</style>
<script>
function generateCouponCode() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let couponCode = '';
    for (let i = 0; i < 10; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        couponCode += characters[randomIndex];
    }
    return couponCode;
}

function generate_discount() {
    
    var mobile = document.getElementById('mobile_number').value.trim();
    var name = document.getElementById('lead_name').value.trim();
    const mobilePattern = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;

    $('#mobile_number_err').html('');
    $('#lead_name_err').html('');
    $('#mobile_div').hide();
    $('#name_div').hide();
    

    if (mobile === '' || !mobilePattern.test(mobile)) {
        $('#mobile_div').show();
        $('#mobile_number_err').html('Enter a valid 10-digit Mobile Number is Required.');
        
        return;
    }

    if (name === '') {
        $('#lead_name_err').text('Enter Your Name is Required.');
        $('#name_div').show();
        return;
    }

    $.ajax({
        url: '{{ route("checkdDiscountMobileExists") }}',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        data: JSON.stringify({ mobile: mobile }),
        success: function(response) {
            if (response.exists) {
                $('#mobile_div').show();
                $('#mobile_number_err').text('This mobile number is already registered.');
                
            } else {
                const code = generateCouponCode();
                const branch_id = {{ $QR_data->branch_id }};
                const discount_id = {{ $QR_data->sno }};
                const min_num = {{ $QR_data->min_value ?? 0 }};
                const max_num = {{ $QR_data->max_value ?? 0 }};
                const dis_type = {{$QR_data->discount_type}};
                
                // Declare random_discount once
                let random_discount = 0;
                // If the discount type is 0 or 1, calculate a random discount value
                if(dis_type == 0 || dis_type == 1){
                    random_discount = Math.floor(Math.random() * (max_num - min_num + 1)) + min_num;
                }
                else if(dis_type == 4){
                    random_discount = {{ $QR_data->event_id ?? 0 }};
                }
                else if (dis_type == 5) {
                    // For discount type 5, pick a random gift ID
                    const giftsids = JSON.parse('{!! $QR_data->free_gifts_id !!}');
                    
                    if (Array.isArray(giftsids) && giftsids.length > 0) {
                        const randomIndex = Math.floor(Math.random() * giftsids.length);
                        random_discount = giftsids[randomIndex]; // Random gift ID
                    } else {
                        $('#mobile_number_err').text('Try again after sometime, no gifts available now..');
                    }
                }
                // alert(random_discount);
                // return random_discount;

                $.ajax({
                    url: '{{ route("add_discount_lead") }}',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    data: JSON.stringify({ 
                        lead_mobile: mobile,
                        lead_name: name,
                        code: code,
                        branch_id: branch_id,
                        discount_id: discount_id,
                        discount_value: random_discount,
                    }),
                    success: function(response) {
                        if (response.success) {
                            // alert('Discount saved successfully!');
                            // alert(response.link);
                            // Redirect to the view page with the encrypted link
                            window.location.href = '/Discount-Qr-View/' + response.link;
                        } else {
                            // alert('Try Again Later.');
                            $('#mobile_div').show();
                            $('#mobile_number_err').text('Try Again After Some Time.');
                        }
                    },
                    error: function() {
                        $('#mobile_div').show();
                        $('#mobile_number_err').text('Try Again After Some Time.');
                        
                    }
                });
            }
        },
        error: function() {
            $('#mobile_div').show();
            $('#mobile_number_err').text('Error checking mobile number.');
           
        }
    });
}
scanner_count_save()
function scanner_count_save(){
    const branch_id = {{ $QR_data->branch_id }};
    const discount_id = {{ $QR_data->sno }};
    // alert(discount_id)
    $.ajax({
        url: '{{ route("add_scanners_count") }}',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        data: JSON.stringify({ 
            branch_id: branch_id,
            discount_id: discount_id,
        }),
        success: function(response) {
            if (response.success) {
            //   alert('updated')
            } else {
                
            }
        },
        error: function() {
            $('#mobile_div').show();
            $('#mobile_number_err').text('Try Again After Some Time.');
            
        }
    });
}
</script>

@endsection