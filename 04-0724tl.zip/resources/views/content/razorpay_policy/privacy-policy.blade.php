@extends('layouts/blankLayout')

@section('title', 'Privacy Policy')

@section('content')
<div class="container py-5 d-flex flex-column align-items-center " style="min-height:100vh; max-width: 900px;">

    <!-- Logo -->
    <div class="text-center mb-4">
        <img src="{{ $logoUrl }}" alt="Company Logo" style="max-width: 220px; width:100%; height:auto;">
    </div>

    <!-- Title -->
    <div class="text-center mb-4">
        <h1 class="fw-bold">Privacy Policy</h1>
        <p class="text-muted fs-5">
            This Privacy Policy describes Our policies and procedures on the collection, use and disclosure of Your information when You use the Service.
        </p>
    </div>

    <!-- Content -->
    <div class="w-100" style="text-align:left; line-height:1.8; color:#333;">

        <h5 class="fw-bold">Interpretation and Definitions</h5>
        <p><strong>Interpretation:</strong> The words of which the initial letter is capitalized have meanings defined under the following conditions.</p>

        <h6 class="fw-bold mt-3">Definitions</h6>
        <p><strong>Account</strong> means a unique account created for You to access our Service.</p>
        <p><strong>Country</strong> refers to: Tamil Nadu, India</p>
        <p><strong>Company</strong> refers to Corporate Company, #227, First Floor, B Block, Elysium Campus, Church Road, Anna Nagar, Madurai, Tamil Nadu, India.</p>
        <p><strong>Personal Data</strong> is any information that relates to an identified or identifiable individual.</p>

        <h5 class="fw-bold mt-4">Collecting and Using Your Personal Data</h5>
        <p><strong>Personal Data</strong> may include, but is not limited to: Email address, Phone number.</p>

        <h5 class="fw-bold mt-4">Tracking Technologies and Cookies</h5>
        <p>We use Cookies and similar tracking technologies to track activity on our Service and store certain information.</p>

        <h5 class="fw-bold mt-4">Use of Your Personal Data</h5>
        <p>We use your Personal Data to provide and maintain our Service, manage your account, contact you, and for business transfers.</p>

        <h5 class="fw-bold mt-4">Retention of Your Personal Data</h5>
        <p>We retain your Personal Data only as long as necessary to comply with legal obligations and improve our Service.</p>

        <h5 class="fw-bold mt-4">Transfer of Your Personal Data</h5>
        <p>Your data may be transferred to locations outside your country.</p>

        <h5 class="fw-bold mt-4">Delete Your Personal Data</h5>
        <p>You have the right to delete or request deletion of your Personal Data.</p>

        <h5 class="fw-bold mt-4">Disclosure of Your Personal Data</h5>
        <p>We may disclose your data for business transfers, law enforcement, and legal requirements.</p>

        <h5 class="fw-bold mt-4">Children’s Privacy</h5>
        <p>Our Service does not address anyone under the age of 13.</p>

        <h5 class="fw-bold mt-4">Links to Other Websites</h5>
        <p>We have no control over third party websites and assume no responsibility for their privacy practices.</p>

        <h5 class="fw-bold mt-4">Changes to this Privacy Policy</h5>
        <p>We may update our Privacy Policy from time to time and notify users accordingly.</p>

        <h5 class="fw-bold mt-4">Contact Us</h5>
        <p>
            Email: <a href="mailto:info@elysiumtechnologies.com">info@elysiumtechnologies.com</a><br>
            Phone: <a href="tel:+919677761442">+91 96777 61442</a>
        </p>
    </div>

</div>
@endsection
