@extends('layouts/blankLayout')

@section('title', 'Terms and Conditions')

@section('content')
<div class="container py-5 d-flex flex-column align-items-center " style="min-height:100vh; max-width: 900px;">

    <!-- Logo -->
    <div class="text-center mb-4">
        <img src="{{ $logoUrl }}" alt="Company Logo" style="max-width: 220px; width:100%; height:auto;">
    </div>

    <!-- Title -->
    <div class="text-center mb-4">
        <h1 class="fw-bold">Terms & Conditions</h1>
        <p class="text-muted fs-5">
            Please read these terms and conditions carefully before using Our Service.
        </p>
    </div>

    <!-- Content -->
    <div class="w-100" style="text-align:left; line-height:1.8; color:#333;">

        <h5 class="fw-bold">Interpretation and Definitions</h5>
        <p><strong>Interpretation:</strong> The words of which the initial letter is capitalized have meanings defined under the following conditions.</p>

        <h6 class="fw-bold mt-3">Definitions</h6>
        <p><strong>Company</strong> refers to Corporate Company, #227, First Floor, B Block, Elysium Campus, Church Road, Anna Nagar, Madurai, Tamil Nadu, India.</p>
        <p><strong>Country</strong> refers to: Tamil Nadu, India</p>
        <p><strong>Website</strong> refers to Elysium Corp, accessible from https://elysiumtechnologies.com/</p>

        <h5 class="fw-bold mt-4">Acknowledgment</h5>
        <p>By accessing or using the Service you agree to be bound by these Terms and Conditions.</p>

        <h5 class="fw-bold mt-4">Links to Other Websites</h5>
        <p>We are not responsible for the content or policies of third-party websites.</p>

        <h5 class="fw-bold mt-4">Termination</h5>
        <p>We may terminate or suspend your access immediately for any reason including breach of these Terms.</p>

        <h5 class="fw-bold mt-4">Limitation of Liability</h5>
        <p>The entire liability of the Company shall be limited to the amount actually paid by you or 100 USD if no purchase was made.</p>

        <h5 class="fw-bold mt-4">"AS IS" and "AS AVAILABLE" Disclaimer</h5>
        <p>The Service is provided “AS IS” and “AS AVAILABLE” without warranty of any kind.</p>

        <h5 class="fw-bold mt-4">Governing Law</h5>
        <p>The laws of the Country shall govern these Terms and your use of the Service.</p>

        <h5 class="fw-bold mt-4">Translation Interpretation</h5>
        <p>The original English text shall prevail in case of dispute.</p>

        <h5 class="fw-bold mt-4">Disputes Resolution</h5>
        <p>If you have any dispute, you agree to first resolve it informally by contacting us.</p>

        <h5 class="fw-bold mt-4">Changes to These Terms and Conditions</h5>
        <p>We may modify or replace these Terms at any time with reasonable notice.</p>

        <h5 class="fw-bold mt-4">Contact Us</h5>
        <p>
            Email: <a href="mailto:info@elysiumtechnologies.com">info@elysiumtechnologies.com</a><br>
            Phone: <a href="tel:+919677761442">+91 96777 61442</a>
        </p>
    </div>

</div>
@endsection
