@extends('layouts/blankLayout')

@section('title', 'Contact Us')

@section('content')
<div class="container-fluid d-flex justify_content-center" style="min-height:100vh;">
    <div class="container d-flex flex-column align-items-center" style="max-width:900px;">

        <!-- Logo -->
        @if(!empty($logoUrl))
            <div class="mb-4">
                <img src="{{ $logoUrl }}" alt="Company Logo"
                     style="max-height:70px; width:auto;">
            </div>
        @endif

        <!-- Header -->
        <div class="text-center mb-5">
            <h1 class="fw-bold">Contact Us</h1>
            <p class="text-muted fs-5 mb-4">
                We’re always happy to assist you. Reach out to us anytime for academic support and guidance.
            </p>
        </div>

        <!-- Contact Details -->
        <div class="row gy-4 w-100 text-center">

            <!-- Address -->
            <div class="col-md-6">
                <h5 class="fw-semibold mb-2">
                    <i class="mdi mdi-map-marker-outline text-danger me-2"></i>
                    Office Address
                </h5>
                <p class="text-muted mb-0">
                    #229, Ist & IInd Floor, A Block,<br>
                    Elysium Campus, Church Road,<br>
                    Anna Nagar, Madurai,<br>
                    Tamil Nadu – 625020
                </p>
            </div>

            <!-- Contact -->
            <div class="col-md-6">
                <h5 class="fw-semibold mb-2">
                    <i class="mdi mdi-phone-outline text-primary me-2"></i>
                    Contact Details
                </h5>
                <p class="mb-1">
                    <strong>Phone:</strong>
                    <a href="tel:+919944049888" class="text-decoration-none text-dark">
                        +91-99440-49888
                    </a>,
                    <a href="tel:+919677772623" class="text-decoration-none text-dark">
                        +91-96777-22623
                    </a>
                </p>
                <p class="mb-0">
                    <strong>Email:</strong>
                    <a href="mailto:info@phdizone.com" class="text-decoration-none">
                        info@phdizone.com
                    </a>
                </p>
            </div>

            <!-- Divider -->
            <div class="col-12">
                <hr class="my-4">
            </div>

            <!-- Business Hours -->
            <div class="col-md-6">
                <h5 class="fw-semibold mb-2">
                    <i class="mdi mdi-clock-outline text-success me-2"></i>
                    Business Hours
                </h5>
                <p class="text-muted mb-0">
                    Monday – Sunday<br>
                    <strong>24 Hours Support Available</strong>
                </p>
            </div>

            <!-- Social -->
            <div class="col-md-6">
                <h5 class="fw-semibold mb-2">
                    <i class="mdi mdi-share-variant-outline text-secondary me-2"></i>
                    Connect With Us
                </h5>
                <div class="d-flex align-items-center justify-content-center gap-3 fs-4">
                    <a href="https://www.facebook.com/PhDiZone" target="_blank" class="text-primary">
                        <i class="mdi mdi-facebook"></i>
                    </a>
                    <a href="https://www.instagram.com/phdizoneresearch/" target="_blank" class="text-danger">
                        <i class="mdi mdi-instagram"></i>
                    </a>
                    <a href="https://x.com/PHDIZONE1" target="_blank" class="text-info">
                        <i class="mdi mdi-twitter"></i>
                    </a>
                    <a href="https://www.linkedin.com/company/phdizone-research-division/" target="_blank" class="text-primary">
                        <i class="mdi mdi-linkedin"></i>
                    </a>
                    <a href="https://www.youtube.com/@PhDiZone" target="_blank" class="text-danger">
                        <i class="mdi mdi-youtube"></i>
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection
