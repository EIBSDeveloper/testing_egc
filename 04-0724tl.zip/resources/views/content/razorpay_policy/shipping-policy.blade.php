@extends('layouts/blankLayout')

@section('title', 'Shipping Policy')

@section('content')
<div class="container-fluid d-flex  justify-content-center" style="min-height:100vh;">
    <div class="container d-flex flex-column align-items-center" style="max-width:900px;">

        <!-- Logo -->
        @if(!empty($logoUrl))
            <div class="mb-4">
                <img src="{{ $logoUrl }}" alt="Company Logo" style="max-height:70px;">
            </div>
        @endif

        <!-- Header -->
        <div class="text-center mb-4">
            <h1 class="fw-bold">Shipping Policy</h1>
            <p class="text-muted fs-5 mb-0">
                This policy explains how orders, documents, and services are delivered to customers.
            </p>
        </div>

        <!-- Content -->
        <div class="w-100">

            <div class="mb-4">
                <h6 class="fw-semibold">
                    <i class="mdi mdi-package-variant text-primary me-2"></i>
                    Order Processing
                </h6>
                <p class="text-muted mb-0">
                    All orders are processed after successful payment confirmation.
                    Customers will receive order updates via email or registered contact details.
                </p>
            </div>

            <div class="mb-4">
                <h6 class="fw-semibold">
                    <i class="mdi mdi-truck-fast-outline text-success me-2"></i>
                    Delivery Method
                </h6>
                <p class="text-muted mb-0">
                    Most services and documents are delivered digitally through email
                    or secure online platforms. Physical deliveries, if applicable,
                    will be handled by trusted courier partners.
                </p>
            </div>

            <div class="mb-4">
                <h6 class="fw-semibold">
                    <i class="mdi mdi-clock-outline text-warning me-2"></i>
                    Delivery Timeline
                </h6>
                <p class="text-muted mb-0">
                    Delivery timelines vary based on the nature of the service,
                    project requirements, and customer specifications.
                    Estimated timelines will be communicated clearly during order confirmation.
                </p>
            </div>

            <div class="mb-0">
                <h6 class="fw-semibold">
                    <i class="mdi mdi-currency-inr text-secondary me-2"></i>
                    Shipping Charges
                </h6>
                <p class="text-muted mb-0">
                    Shipping or delivery charges, if applicable, are displayed at the time of checkout
                    and may vary based on location and service type.
                </p>
            </div>

        </div>

    </div>
</div>
@ends
