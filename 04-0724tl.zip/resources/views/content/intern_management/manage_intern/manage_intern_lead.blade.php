@extends('layouts/layoutMaster')
@section('title', 'Manage Intern Lead')
@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
])
@endsection
@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection
@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
<!-- Customer List Table -->
<style>
      table thead tr th{
        padding: 5px !important;
    }
    table tbody tr td{
        padding: 5px !important;
    }
</style>
<div class="card">
    <div class="card-header border-bottom pb-1 ">
        @php
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        @endphp
         <div class="row">
            <div class="col-lg-6">
              <h5 class="card-title mb-1">Manage Intern Lead</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Intern Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="col-lg-6">
              <ul class="nav nav-pills justify-content-end" role="tablist">
                  <li class="nav-item me-1">
                    <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_intern" class="btn btn-sm fw-bold btn-primary waves-effect waves-light">
                      <span class="me-2"><i class="mdi mdi-plus"></i></span>Create Intern Lead
                  </a>
                </li>
              </ul>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="d-flex justify-content-between align-items-center">
                <div class="mb-4">
                    @php $perpage_count = $perpage ? $perpage : 25; @endphp
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                            @php
                            $options = [10, 25, 100, 500]; // Define available options
                            @endphp
                            @php foreach ($options as $option): @endphp
                            <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                @php echo $option; @endphp
                            </option>
                            @php endforeach; @endphp
                        </select>
                    </div>
                </div>
                <div class="mb-4">
                    <form id="search_form" method="POST" action="/manage_intern_lead">
                    @csrf
                        <div class="d-flex align-items-center gap-2">
                            <div class="mb-1">
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="1">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                                <input type="text" class="form-control" id="cus_fill" name="cus_fill" value="{{ $customer_fill ?? "" }}" placeholder="Enter Search" />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div>
        <div class="col-lg-12">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
            <thead>
                <tr class=" align-top fw-bold fs-6 gs-0 bg-primary">
                    <th class="text-start"  style="width: 30%;">Lead</th>
                    <th class="text-start"  style="width: 30%;">Mobile</th>
                    <th class="text-start"  style="width: 30%;">Mail</th>
                    <th class="text-start"  style="width: 10%;">Action</th>
                </tr>
            </thead>
            <tbody class="text-black fw-semibold fs-7" id="payment-table-body">
                @if (isset($interns))
                     @foreach ($interns as $i => $pay)
                        <tr>
                            <td class="text-start" style="width: 30%;">{{ $pay->intern_name }}</td>
                            <td class="text-start" style="width: 30%;">{{ $pay->intern_mobile }}</td>
                            <td class="text-start" style="width: 30%;">{{ $pay->intern_email }}</td>
            
                            <!-- Action -->
                            <td>  
                               <div class="d-flex align-items-center">
                                    <a class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_to_intern" onclick="ConvertIntern('{{ $pay->sno }}','{{ $pay->intern_name }}','{{ $pay->intern_mobile }}')" >
                                        <i class="mdi mdi-account-arrow-right fs-3  text-black"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                @endif
            </tbody>
            </table>

        </div>
        <div class="mt-4">
            {{ $interns->appends(request()->except(['page', '_token']))->links() }}
        </div>
        </div>
    </div>
</div>

     <!--begin::Modal - Transfer Lead to Customer-->
    <div class="modal fade" id="kt_modal_lead_to_intern" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead To Intern</h3>
                    </div>
                    <form method="POST" action="{{ route('convert_intern_lead') }}" autocomplete="off">
                        @csrf
                        <div class="row">
                            <input type="hidden" name="lead_id" id="lead_id_intern" value="">
                            <div class="col-lg-12 mt-4">
                                <h5 class="text-dark mb-1 fw-semibold">Are You Sure Want To Convert Lead To Intern?</h5>
                                <div class="text-center">
                                    <label class="fw-bold fs-5 text-danger" id="lead-name_intern" ></label>
                                    <span class="fw-bold fs-5 text-danger" id="lead-mobile_intern">[]</span>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center pt-8 pb-4">
                                <button type="submit" class="btn btn-primary me-3" >Yes</button>
                                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Transfer Lead to Customer-->


<!--begin::Modal - Update intern-->
<div class="modal fade" id="kt_modal_edit_intern" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-s">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
        </div>
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-6">
          <h3 class="text-center text-black">Create Intern Lead</h3>
        </div>
        <form>
            <div class="row">
                <div class="col-lg-12 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Intern Lead Name<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="intern_name_edit" name="intern_name_edit"
                        placeholder="Enter Intern Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"/>
                    <div class="text-danger" id="intern_name_edit_err"></div>
                </div>
                <div class="col-lg-12 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Intern Lead Mobile No<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="intern_mobile_editt" name="intern_mobile_editt"
                        placeholder="Enter Intern Mobile No" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                    <div class="text-danger" id="intern_mobile_editt_err"></div>
                </div>
                <div class="col-lg-12 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Intern Email Id<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="intern_email_edit" name="intern_email_edit"
                        placeholder="Intern Email Id"  oninput="this.value = this.value.toLowerCase();"/>
                    <div class="text-danger" id="intern_email_edit_err"></div>
                </div>
            </div>
         <div class="d-flex justify-content-end align-items-center mt-4">
            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" id="edit_submit_button" class="btn btn-primary">Create Intern Lead</button>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!--end::Modal - Update intern-->
<style>
  .w-40 { width: 40%; }
  .w-5 { width: 5%; }
  .w-55 { width: 55%; }
  
      
</style>



  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>

    // $(document).ready(function () {
    //     $('#edit_submit_button').on('click', function (e) {
    //         e.preventDefault();
    
    //         // Clear previous error messages
    //         $('.text-danger').text('');
    
    //         let isValid = true;
    
    //         const fields = [
                
    //             { id: 'intern_name_edit', name: 'Intern Lead Name' },
    //             { id: 'intern_email_edit', name: 'Intern Lead Email Id' },
    //             { id: 'intern_mobile_editt', name: 'Intern Lead Mobile No' },
    //         ];
    
    //         fields.forEach(field => {
    //             const value = $('#' + field.id).val();
    //             if (!value || value.trim() === '') {
    //                 $('#'+ field.id + '_err').text(`${field.name} is required`);
    //                 isValid = false;
    //             }
    //         });
    
    //         if (isValid) {
    //             // Proceed to AJAX update function or form submissio
    //             updateInternData();
    //         }
    //     });
    // });
    $(document).ready(function () {
        $('#edit_submit_button').on('click', function (e) {
            e.preventDefault();
    
            // Clear previous error messages
            $('.text-danger').text('');
    
            let isValid = true;
    
            const fields = [
                { id: 'intern_name_edit', name: 'Intern Lead Name' },
                { id: 'intern_email_edit', name: 'Intern Lead Email Id' },
                { id: 'intern_mobile_editt', name: 'Intern Lead Mobile No' }, // fixed typo here
            ];
    
            // Basic email regex pattern
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
            fields.forEach(field => {
                const value = $('#' + field.id).val().trim();
    
                if (value === '') {
                    $('#' + field.id + '_err').text(`${field.name} is required`);
                    isValid = false;
                } else if (field.id === 'intern_email_edit' && !emailPattern.test(value)) {
                    $('#' + field.id + '_err').text('Please enter a valid email address');
                    isValid = false;
                }
            });
    
            if (isValid) {
                // Proceed to AJAX update function or form submission
                updateInternData();
            }
        });
    });

    function updateInternData() {
        const formData = {
            intern_name: $('#intern_name_edit').val(),
            intern_mobile: $('#intern_mobile_editt').val(),
            intern_email: $('#intern_email_edit').val(),
            _token: '{{ csrf_token() }}'
        };
    
        $.ajax({
            url: "{{ route('create_intern_lead') }}",
            type: "POST",
            data: formData,
            success: function(response) {
                if (response.status === 'success') {
                    toastr.success(response.message || 'Intern created successfully!');
                    $('#kt_modal_edit_intern').modal('hide');
                    location.reload();
                } else {
                    toastr.error(response.message || 'Failed to create intern.');
                }
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    // Validation errors
                    const errors = xhr.responseJSON.errors;
                    if (errors) {
                        $.each(errors, function(key, value) {
                            toastr.error(value[0]);
                        });
                    } else if (xhr.responseJSON.message) {
                        toastr.error(xhr.responseJSON.message);
                    } else {
                        toastr.error('Validation failed.');
                    }
                } else {
                    toastr.error('Server error. Please try again.');
                }
                console.error(xhr.responseText);
            }
        });
    }
     function ConvertIntern(id, leadName, mobile) {
            document.getElementById('lead_id_intern').value = id;
            document.getElementById('lead-name_intern').innerText = leadName;
            document.getElementById('lead-mobile_intern').innerText = `[${mobile}]`;
        }
</script>
<script>
  // Display Toastr messages
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
  toastr[type](message);
  @endif
</script>
<script>
    $(".list_page").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
</script>
<script>
    function sort_filter(val) {
      if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
      } else {
        $('.sorting_filter_class').val(10);
        $('#search_form').submit();
      }
    }
  </script>
@endsection
