@extends('layouts/blankLayout')

<!--@section('title', 'Invoice ')-->
<title>Elysium Academy&reg; Customer Invoive Print</title>


@section('content')
<style>
  body {
    background: transparent !important;
    font-family: Calibri;
    font-size: 14px;
  }

  p {
    margin: 0px !important;
  }

  .ft_wgt {
    font-weight: 600;
  }

  table {title
    border-collapse: collapse;
    width: 100%;
  }

  table tr,
  td,
  th {
    border: 1px solid #acaaaa;
  }

  .fw-semi_bold {
    font-family: 500 !important;
  }

  .shadow_lg {
    box-shadow: 0.rem 0.625rem 0.7rem 0.575rem rgba(0, 0, 0, 0.1) !important;
  }

  .bg_img {
    background-image: url('../../../../assets/eapl_images/invoice_bg.png');
    background-size: contain !important;
    background-repeat: no-repeat;
    position: sticky;
    top: 100%;
    /* opacity: 0.2; */
    /* width: 100% !important; */
    /* height: 200px !important; */
    /* margin-top: -25rem !important; */
  }

  @media (max-width: 991.98px) {
    .w-md-100 {
      width: 100% !important;
    }
  }

  @media (min-width: 992px) {
    .w-lg-100 {
      width: 100% !important;
    }

    .mt-lg-8 {
      margin-top: 2.2rem !important;
    }
  }


  @media print {
      header, footer {
    display: none !important;
  }
  
    * {
      box-sizing: border-box;
      /* Ensure padding and border are included in element's total width and height */
    }

    @page {
      size: A4 portrait;
    }
    

    .page-break {
      /* width: 210mm;
      height: 300mm; */
      /* border: 1px solid black; */
      /* border-radius: 10px !important; */
      page-break-before: always;
      break-before: always;
      padding: 0px 0px 10px 0px !important;


      /* background: #EAEADF; */
    }
  }
</style>
 @php
  $helper = new \App\Helpers\Helpers();
  $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
  @endphp
   @php
        $total_amount =4900;
@endphp
<center>
  <div class="bg_img" style="height:566px !important;width: 797px !important;font-family: calibri !important;border:1px solid #acaaaa !important;border-top-left-radius:10px;border-top-right-radius:10px;border-bottom-left-radius:10px;border-bottom-right-radius:10px;margin-top:20px !important;">
    <table>
      <tr>
        <td colspan="3" style="border-top-style: hidden;border-left-style: hidden;border-right-style: hidden; border-top-left-radius:10px;border-top-right-radius:10px;" class="bg-primary">
          <div class="d-flex align-items-center">
            <div style="width: 85% !important;">
              <h2 class="fw-bold fs-1hx m-0 text-center text-white">
                <span>INVOICE</span>&nbsp;-&nbsp;<span>{{ $transaction['invoice_id'] }}</span>
              </h2>
              <div class="d-block fs-4 text-white fw-bold text-center">Receipt ID - [ {{ $transaction['receipt_id'] ?? '-' }} ]</div>
            </div>
            <div style="width: 15% !important;">
              <h5 class="fw-bold m-0 text-white">Customer Copy</h5>
            </div>
          </div>
        </td>
      </tr>
      <tr style="background-color: #dddddd;">
        <!--<td rowspan="2" style="border-left-style: hidden;">-->
        <!--  <img src="{{asset('assets/eapl_images/ea_full_logo.png')}}" width="325" height="80" style="float:left;padding-top: 0px;">-->
        <!--</td>-->
        <td colspan="4" style="padding-left:5px;padding-bottom: 5px;border-right-style: hidden;">
          <div class="text-black text-start ms-2">
            <h2 class="fw-bold m-0" style="font-size: 31px !important;">@if($payment->branch_type == 1) {{$payment->branch_name }} @elseif($payment->branch_type == 2) {{ $payment->franchise_name }} @endif</h2>
            <div class="d-flex justify-content-start align-items-center">
              <div class="d-block fs-7">
                <i class="mdi mdi-map-marker-radius text-dark fs-4"></i>
              </div>
              <div class="d-block fs-6 ms-2">
                <div>{{ $payment->door_no ? $payment->door_no.", ":"" }}{{ $payment->area_street ? $payment->area_street.", ":"" }}{{ $payment->city_name ? $payment->city_name.", ":"" }}{{$payment->state_name ? $payment->state_name:"" }}{{ $payment->pincode ? " - ".$payment->pincode:"" }}</div>
                <!-- <div>2nd Floor, Ponmanam Plaza, Above Reliance Trends, Near New Bus Stand,Perambalur, Tamil Nadu - 625020</div> -->
              </div>
            </div>
            <div class="d-flex justify-content-start align-items-center">
              <div class="d-block fs-7">
                <i class="mdi mdi mdi-cellphone text-dark fs-5"></i>
              </div>
              <div class="d-block fs-6 ms-2 fw-bold">{{ $payment->mobile }}</div>
            </div>
          </div>
        </td>
      </tr>
      <tr style="background-color: #dddddd;">
        <td style="width:60%;height: 15px;">
          <div class="d-flex justify-content-start align-items-center text-black">
            <div class="d-block fs-6 fw-bold ms-2">{{$payment->mail ?$payment->mail : "info@elysiumacademy.org"}}</div>
          </div>
        </td>
        <td colspan="2" style="width:40%;border-right-style: hidden;">
          <div class="d-flex justify-content-start align-items-center text-black">
            <div class="d-block fs-6 ms-2">Date</div>
            <div class="d-block fs-6 ms-2 fw-bold">{{ \Carbon\Carbon::parse($transaction['timestamp'])->format($common_date_format) }}</div>
          </div>
        </td>
      </tr>
    </table>
    <div class="d-flex align-items-start justify-content-between my-1">
      <div class="fs-7 fw-bold text-start" style="width: 40% !important;">
        <div class="d-flex align-items-start fs-7 fw-bold ms-1">
          <div class="fs-5 fw-bold" style="width: 25% !important;">Customer</div>
          <div class="fs-5 fw-bold" style="width: 5% !important;">:</div>
          <div class="fs-5 text-black fw-bold" style="width: 70% !important;">{{ $payment->intern_name }}</div>
        </div>
      </div>
      <div class="fs-7 fw-bold text-start" style="width: 28% !important;">
        <div class="d-flex align-items-start fs-7 fw-bold ms-1">
          <div class="fs-5 fw-bold" style="width: 38% !important;">Mobile No</div>
          <div class="fs-5 fw-bold" style="width: 6% !important;">:</div>
          <div class="fs-5 text-black fw-bold" style="width: 56% !important;">{{ $payment->intern_mobile }}</div>
        </div>
      </div>
      <div class="fs-7 fw-bold text-start" style="width: 32% !important;">
        <div class="d-flex align-items-start fs-7 fw-bold ms-1">
          <div class="fs-5 fw-bold" style="width: 10% !important;">ID</div>
          <div class="fs-5 fw-bold" style="width: 5% !important;">:</div>
          <div class="fs-5 text-black fw-bold" style="width: 85% !important;">{{ $payment->intern_id }}</div>
        </div>
      </div>
    </div>
    <div class="fs-7 fw-bold text-start" style="width: 100% !important;">
      <div class="d-flex align-items-start fs-7 fw-bold ms-1">
        <div class="fs-5 fw-bold" style="width: 10% !important;">Topic</div>
        <div class="fs-5 fw-bold" style="width: 2% !important;">:</div>
        <div class="fs-5 text-black fw-bold" style="width: 88% !important;">{{ $payment->title }}</div>
      </div>
    </div>
    @php
    $ordinal = $print_decryptedValue;
    if ($ordinal == 1) {
    $suffix = 'st';
    } elseif ($ordinal == 2) {
    $suffix = 'nd';
    } elseif ($ordinal == 3) {
    $suffix = 'rd';
    } else {
    $suffix = 'th';
    }
    @endphp
    <div class="d-flex">
        <div class="w-75 mt-3">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 mb-0">
      <thead>
        <tr class="text-start align-top fw-bold fs-5 bg-primary">
          <th class="text-center px-1 py-0" style="width: 5% !important;">S.No</th>
          <th class="text-center px-1 py-0" style="width: 70% !important;">Particular</th>
          <th class="text-center px-1 py-0" style="width: 25% !important;">Gross Amount</th>
        </tr>
      </thead>
      <tbody class="text-black fs-5">
        <tr>
          <td class="px-1 py-0 fw-semi_bold" align="center">1</td>
          <td class="px-1 py-0 fw-semi_bold">{{ $print_decryptedValue }}{{ $suffix }} Part Fees Payment</td>
          <td class="px-1 py-0 fw-semi_bold" align="right">&#8377; {{ number_format(round($transaction['subtotal']), 2) }}</td>
        </tr>
        <tr>
             <!--$gst_amount = $transaction['payment_amount'] * $gstPercentage/100;-->
        <!--$total_amount =$transaction['payment_amount'] + $gst_amount;-->
        @php
        $gst_amount     = $transaction['gst_amount'];
        $gstPercentage  = $transaction['gst_per'];
        $total_amount   = ($transaction['gst_type'] == 0) ? $transaction['payment_amount'] + $gst_amount : $transaction['payment_amount'] ;
        @endphp
          <td colspan="2" class="px-0 py-0 pe-2 fw-bold" align="right">
     
            <div class="fs-5">
              <span>GST</span>
              <span>( {{$gstPercentage}}% )</span>
            </div>
          </td>
          <td class="px-0 py-0 pe-1 fw-semi_bold" align="right">&#8377; {{ number_format($gst_amount, 2) }}</td>
        </tr>
        <tr>
          <td colspan="2" class="px-0 py-0 pe-2 fw-bold" align="right">
            <div class="fs-5">Grand Total</div>
          </td>
          <td class="px-0 py-0 pe-1 fw-bold fs-3" align="right">&#8377; {{ number_format(round($total_amount, 2)) }}</td>
        </tr>
      </tbody>
    </table>
        </div>
        <div class="w-25">
            <div class="mb-1">
              <label class="fs-5 text-black pb-0">Payment Mode</label>
              <div class="d-block">
                <label class="fs-5 fw-bold text-black">{{ $transaction['payment_mode'] ?? '-' }}</label>
              </div>
            </div>
            <div class="mb-1">
              <label class="fs-5 text-black pb-0">Transaction ID</label>
              <div class="d-block">
                <label class="fs-5 fw-bold text-black">{{ $transaction['Transaction ID'] ?? '-' }}</label>
              </div>
            </div>
        </div>
    </div>
    
  

    @php
    $amount = $total_amount;
    $amountInWords = $helper->convertNumberToWords($amount);
    @endphp
    <!-- <hr style="color:rgb(195, 194, 194);width:797px !important;margin:0px 0px 0px -4px !important;"> -->
    <div class="fs-6 text-black fw-bold text-start ms-1">{{ ucfirst($amountInWords) }} Only.</div>
    <hr style="color:rgb(195, 194, 194);width:797px !important;margin:1px 0px 0px -2px !important;">
    <div class="d-flex align-items-start">
      <div style="width:75% !important;">
        <div class="text-start" style="padding-left:5px;font-size: 12px;font-weight: 700 !important;margin-bottom:5px !important;">TERMS & CONDITIONS</div>
        <div class="text-start" style="padding-left:5px;font-size: 12px;">1. @if(isset($terms[0]['terms_1'])) {{$terms[0]['terms_1'] }}@endif</div>
        <div class="text-start" style="padding-left:5px;font-size: 12px;">2. @if(isset($terms[0]['terms_2'])) {{$terms[0]['terms_2'] }}@endif</div>
        <div class="text-start" style="padding-left:5px;font-size: 12px;">3. @if(isset($terms[0]['terms_3'])) {{$terms[0]['terms_3'] }}@endif</div>
        <div class="text-start" style="padding-left:5px;font-size: 12px;">4. @if(isset($terms[0]['terms_4'])) {{$terms[0]['terms_4'] }}@endif</div>
      </div>
      <div style="width:25% !important;">
        <div class="d-flex justify-content-center align-items-center text-center mt-1" id="qrcode1">
          <!--<div  width="150" height="150" id="qrcode2" style="float:left;padding-top: 0px;"></div>-->
        </div>
      </div>
    </div>
    <div class="text-start">
      <h5 class="fw-bold ms-2">Authorized Signature</h5>
    </div>
  </div>
</center>
<center>
  <div class="bg_img" style="height:566px !important;width: 797px !important;font-family: calibri !important;border:1px solid #acaaaa !important;border-top-left-radius:10px;border-top-right-radius:10px;border-bottom-left-radius:10px;border-bottom-right-radius:10px;margin-top:5px !important;">
    <table>
      <tr>
        <td colspan="3" style="border-top-style: hidden;border-left-style: hidden;border-right-style: hidden; border-top-left-radius:10px;border-top-right-radius:10px;" class="bg-primary">
          <div class="d-flex align-items-center">
            <div style="width: 85% !important;">
              <h2 class="fw-bold fs-1hx m-0 text-center text-white">
                <span>INVOICE</span>&nbsp;-&nbsp;<span>{{ $transaction['invoice_id'] }}</span>
              </h2>
              <div class="d-block fs-4 text-white fw-bold text-center">Receipt ID - [ {{ $transaction['receipt_id'] ?? '-' }} ]</div>
            </div>
            <div style="width: 15% !important;">
              <h5 class="fw-bold m-0 text-white">Office Copy</h5>
            </div>
          </div>
        </td>
      </tr>
      <tr style="background-color: #dddddd;">
        <!--<td rowspan="2" style="border-left-style: hidden;">-->
        <!--  <img src="{{asset('assets/eapl_images/ea_full_logo.png')}}" width="325" height="80" style="float:left;padding-top: 0px;">-->
        <!--</td>-->
        <td colspan="4" style="padding-left:5px;padding-bottom: 5px;border-right-style: hidden;">
          <div class="text-black text-start ms-2">
            <h2 class="fw-bold m-0" style="font-size: 31px !important;">@if($payment->branch_type == 1) {{$payment->branch_name }} @elseif($payment->branch_type == 2) {{ $payment->franchise_name }} @endif</h2>
            <div class="d-flex justify-content-start align-items-center">
              <div class="d-block fs-7">
                <i class="mdi mdi-map-marker-radius text-dark fs-4"></i>
              </div>
              <div class="d-block fs-6 ms-2">
                <div>{{ $payment->door_no ? $payment->door_no.", ":"" }}{{ $payment->area_street ? $payment->area_street.", ":"" }}{{ $payment->city_name ? $payment->city_name.", ":"" }}{{$payment->state_name ? $payment->state_name:"" }}{{ $payment->pincode ? " - ".$payment->pincode:"" }}</div>
                <!-- <div>2nd Floor, Ponmanam Plaza, Above Reliance Trends, Near New Bus Stand,Perambalur, Tamil Nadu - 625020</div> -->
              </div>
            </div>
            <div class="d-flex justify-content-start align-items-center">
              <div class="d-block fs-7">
                <i class="mdi mdi mdi-cellphone text-dark fs-5"></i>
              </div>
              <div class="d-block fs-6 ms-2 fw-bold">{{ $payment->mobile }}</div>
            </div>
          </div>
        </td>
      </tr>
      <tr style="background-color: #dddddd;">
        <td style="width:60%;height: 15px;">
          <div class="d-flex justify-content-start align-items-center text-black">
            <div class="d-block fs-6 fw-bold ms-2">{{$payment->mail ?$payment->mail : "info@elysiumacademy.org"}}</div>
          </div>
        </td>
        <td colspan="2" style="width:40%;border-right-style: hidden;">
          <div class="d-flex justify-content-start align-items-center text-black">
            <div class="d-block fs-6 ms-2">Date</div>
            <div class="d-block fs-6 ms-2 fw-bold">{{ \Carbon\Carbon::parse($transaction['timestamp'])->format($common_date_format) }}</div>
          </div>
        </td>
      </tr>
    </table>
    <div class="d-flex align-items-start justify-content-between my-1">
      <div class="fs-7 fw-bold text-start" style="width: 40% !important;">
        <div class="d-flex align-items-start fs-7 fw-bold ms-1">
          <div class="fs-5 fw-bold" style="width: 25% !important;">Customer</div>
          <div class="fs-5 fw-bold" style="width: 5% !important;">:</div>
          <div class="fs-5 text-black fw-bold" style="width: 70% !important;">{{ $payment->intern_name }}</div>
        </div>
      </div>
      <div class="fs-7 fw-bold text-start" style="width: 28% !important;">
        <div class="d-flex align-items-start fs-7 fw-bold ms-1">
          <div class="fs-5 fw-bold" style="width: 38% !important;">Mobile No</div>
          <div class="fs-5 fw-bold" style="width: 6% !important;">:</div>
          <div class="fs-5 text-black fw-bold" style="width: 56% !important;">{{ $payment->intern_mobile }}</div>
        </div>
      </div>
      <div class="fs-7 fw-bold text-start" style="width: 32% !important;">
        <div class="d-flex align-items-start fs-7 fw-bold ms-1">
          <div class="fs-5 fw-bold" style="width: 10% !important;">ID</div>
          <div class="fs-5 fw-bold" style="width: 5% !important;">:</div>
          <div class="fs-5 text-black fw-bold" style="width: 85% !important;">{{ $payment->intern_id }}</div>
        </div>
      </div>
    </div>
    <div class="fs-7 fw-bold text-start" style="width: 100% !important;">
      <div class="d-flex align-items-start fs-7 fw-bold ms-1">
        <div class="fs-5 fw-bold" style="width: 10% !important;">Topic</div>
        <div class="fs-5 fw-bold" style="width: 2% !important;">:</div>
        <div class="fs-5 text-black fw-bold" style="width: 88% !important;">{{ $payment->title }}</div>
      </div>
    </div>
    @php
    $ordinal = $print_decryptedValue;
    if ($ordinal == 1) {
    $suffix = 'st';
    } elseif ($ordinal == 2) {
    $suffix = 'nd';
    } elseif ($ordinal == 3) {
    $suffix = 'rd';
    } else {
    $suffix = 'th';
    }
    @endphp
    <div class="d-flex">
        <div class="w-75 mt-2">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 mb-0">
          <thead>
            <tr class="text-start align-top fw-bold fs-5 bg-primary">
              <th class="text-center px-1 py-0" style="width: 5% !important;">S.No</th>
              <th class="text-center px-1 py-0" style="width: 70% !important;">Particular</th>
              <th class="text-center px-1 py-0" style="width: 25% !important;">Gross Amount</th>
            </tr>
          </thead>
          <tbody class="text-black fs-5">
            <tr>
              <td class="px-1 py-0 fw-semi_bold" align="center">1</td>
              <td class="px-1 py-0 fw-semi_bold">{{ $print_decryptedValue }}{{ $suffix }} Part Fees Payment</td>
              <td class="px-1 py-0 fw-semi_bold" align="right">&#8377; {{ number_format(round($transaction['subtotal']), 2) }}</td>
            </tr>
            <tr>
            @php
                $gst_amount     = $transaction['gst_amount'];
                $gstPercentage  = $transaction['gst_per'];
                $total_amount   = ($transaction['gst_type'] == 0) ? $transaction['payment_amount'] + $gst_amount : $transaction['payment_amount'] ;
            @endphp
              <td colspan="2" class="px-0 py-0 pe-2 fw-bold" align="right">
                  
                <div class="fs-5">
                  <span>GST</span>
                  <span>( {{$gstPercentage}}% )</span>
                </div>
              </td>
              <td class="px-0 py-0 pe-1 fw-semi_bold" align="right">&#8377; {{ number_format($gst_amount, 2) }}</td>
            </tr>
            <tr>
              <td colspan="2" class="px-0 py-0 pe-2 fw-bold" align="right">
                <div class="fs-5">Grand Total</div>
              </td>
              <td class="px-0 py-0 pe-1 fw-bold fs-3" align="right">&#8377; {{ number_format(round($total_amount, 2)) }}</td>
            </tr>
          </tbody>
        </table>
        </div>
        <div class="w-25">
            <div class="mb-1">
              <label class="fs-5 text-black pb-0">Payment Mode</label>
              <div class="d-block">
                <label class="fs-5 fw-bold text-black">{{ $transaction['payment_mode'] ?? '-' }}</label>
              </div>
            </div>
            <div class="mb-1">
              <label class="fs-5 text-black pb-0">Transaction ID</label>
              <div class="d-block">
                <label class="fs-5 fw-bold text-black">{{ $payment['transaction_id'] ?? '-' }}</label>
              </div>
            </div>
        </div>
    </div>
    @php
    $amount = $total_amount;
    $amountInWords = $helper->convertNumberToWords($amount);
    @endphp
    <!-- <hr style="color:rgb(195, 194, 194);width:797px !important;margin:0px 0px 0px -4px !important;"> -->
    <div class="fs-6 text-black fw-bold text-start ms-1">{{ ucfirst($amountInWords) }} Only.</div>
    <hr style="color:rgb(195, 194, 194);width:797px !important;margin:1px 0px 0px -2px !important;">
    <div class="d-flex align-items-start">
      <div style="width:75% !important;">
        <div class="text-start" style="padding-left:5px;font-size: 12px;font-weight: 700 !important;margin-bottom:5px !important;">TERMS & CONDITIONS</div>
        <div class="text-start" style="padding-left:5px;font-size: 12px;">1. @if(isset($terms[0]['terms_1'])) {{$terms[0]['terms_1'] }}@endif</div>
        <div class="text-start" style="padding-left:5px;font-size: 12px;">2. @if(isset($terms[0]['terms_2'])) {{$terms[0]['terms_2'] }}@endif</div>
        <div class="text-start" style="padding-left:5px;font-size: 12px;">3. @if(isset($terms[0]['terms_3'])) {{$terms[0]['terms_3'] }}@endif</div>
        <div class="text-start" style="padding-left:5px;font-size: 12px;">4. @if(isset($terms[0]['terms_4'])) {{$terms[0]['terms_4'] }}@endif</div>
      </div>
      <div style="width:25% !important;">
        <div class="d-flex justify-content-center align-items-center text-center mt-1" id="qrcode2">
          <!--<div  width="150" height="150" id="qrcode2" style="float:left;padding-top: 0px;"></div>-->
        </div>
      </div>
    </div>
    <div class="text-start">
      <h5 class="fw-bold ms-2">Authorized Signature</h5>
    </div>
  </div>
</center>
<input type="hidden" id="brand_val" value="Elysium Academy&#174;">

<script src="https://cdn.jsdelivr.net/npm/qrcode/build/qrcode.min.js"></script>


<script>
    // Generate QR code function
    function generateQRCode(qrData, targetElementId) {
        QRCode.toDataURL(
            qrData,
            {
                width: 150, // Adjust size for visibility
                height: 150, // Adjust size for visibility
                margin: 1 // Ensure scannability with a small margin
            },
            function (error, url) {
                if (error) {
                    console.error('QR Code Error:', error);
                } else {
                    console.log(`QR Code generated successfully for ${targetElementId}!`);
                    // Create an img element and set its src to the generated data URL
                    const img = document.createElement('img');
                    img.src = url;
                    document.getElementById(targetElementId).appendChild(img); // Append the img to the div
                }
            }
        );
    }

      // Get the CSRF token from the meta tag
  var csrfToken = $('meta[name="csrf-token"]').attr('content');

    // Prepare the data for the first QR code
  
    // Prepare the data to be encrypted
  const qrData1 = `{{$payment->invoice_id}}~{{$print_decryptedValue}}`.trim();


    $.ajax({
      url: '/customer/encrypt', // Your encryption route
      type: 'POST',
      data: {
          values: qrData1,
          _token: csrfToken // Include CSRF token here
      },
      success: function(encrypted_course_id) {
          // alert(encrypted_course_id);
          const baseUrl = `{{ url('/') }}`;
          const qrDataForQRCode = `${baseUrl}/payment_verified/${encrypted_course_id}`;
        //   const qrDataForQRCode = `https://erp.elysium.academy/verified/${encrypted_course_id}`;
          
          // Log the URL for debugging
          console.log(qrDataForQRCode);

          // Generate the QR code after encryption
          generateQRCode(qrDataForQRCode, 'qrcode1'); // Generate QR code with the encrypted course ID
      },
      error: function(xhr) {
          Swal.fire({
              title: 'Error!',
              text: xhr.responseJSON.message || 'Encryption failed.',
              icon: 'error',
              customClass: {
                  confirmButton: 'btn btn-primary waves-effect waves-light'
              },
              buttonsStyling: false
          });
      }
  });



    const qrData2 = `{{$payment->invoice_id}}~{{$print_decryptedValue}}`.trim();
   

    $.ajax({
      url: '/customer/encrypt', // Your encryption route
      type: 'POST',
      data: {
          values: qrData1,
          _token: csrfToken // Include CSRF token here
      },
      success: function(encrypted_course_id) {
          // alert(encrypted_course_id);
          const baseUrl = `{{ url('/') }}`;
          const qrDataForQRCode = `${baseUrl}/payment_verified/${encrypted_course_id}`;
        //   const qrDataForQRCode = `https://erp.elysium.academy/verified/${encrypted_course_id}`;
          
          // Log the URL for debugging
          console.log(qrDataForQRCode);

          // Generate the QR code after encryption
          generateQRCode(qrDataForQRCode, 'qrcode2'); // Generate QR code with the encrypted course ID
      },
      error: function(xhr) {
          Swal.fire({
              title: 'Error!',
              text: xhr.responseJSON.message || 'Encryption failed.',
              icon: 'error',
              customClass: {
                  confirmButton: 'btn btn-primary waves-effect waves-light'
              },
              buttonsStyling: false
          });
      }
  });

</script>
<script>
$(document).ready(function() {
  setTimeout(function() {
    window.print();
  }, 2000); // 2000 milliseconds = 2 seconds
});
</script>



@endsection