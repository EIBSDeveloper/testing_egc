@extends('layouts/layoutMaster')

@section('title', 'Manage Intern')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
<!-- Customer List Table -->


<div class="card">
    <div class="card-header border-bottom pb-1 ">
        @php
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        @endphp

         <div class="row">

            <div class="col-lg-6">
              <h5 class="card-title mb-1">Manage Intern</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Create Intern</a>
                        </li>
                    </ol>
                </nav>
            </div>

        </div>
    </div>
    <div class="card-body">
      <form method="POST" action="{{ route('create_intern') }}" id="AddDropRefundForm">
          @csrf
          <fieldset class="border p-3 mb-4">
            <legend class="w-auto px-2 text-primary fw-bold">Common Section</legend>
              <div class="row mb-3">
                <div class="col-lg-4 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">College<span class="text-danger">*</span></label>
                  <select id="colleage_id" name="colleage_id" class="select3 form-select">
                      <option value="">Select Colleage</option>
                  </select>
                  <div class="text-danger mt-1" id="error_colleage_id"></div>
                </div>
                <div class="col-lg-4 mb-3 branch_row">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Topic Name<span
                          class="text-danger">*</span></label>
                  <!--<input type="text" class="form-control" id="topic_id" name="topic_id"-->
                  <!--    placeholder="Enter Topic Name"-->
                  <!--    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />-->
                       <select id="topic_id" name="topic_id" class="select3 form-select">
                      <option value="">Select Topic</option>
                  </select>
                  <div class="text-danger mt-1" id="error_topic_id"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Payment<span
                            class="text-danger">* (Without GST)</span></label>
                    <input type="text" class="form-control" id="payment" name="payment" maxlength="6"
                        placeholder="Enter Payment"
                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                        <div class="text-danger mt-1" id="error_payment"></div>
                </div>
                <div class="col-lg-4 mb-2 ">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date<span
                      class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="share_start_date" name="start_date" placeholder="Select Date"
                            class="common_date_class form-control" value="<?php echo date('d-M-Y'); ?>" />

                    </div>
                </div>
                <div class="col-lg-4 mb-2 ">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date<span
                      class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="share_end_date" name="end_date" placeholder="Select Date"
                            class=" common_date_class form-control" value="<?php echo date('d-M-Y'); ?>" />

                    </div>
                    <div class="text-danger mt-1" id="error_end_date"></div>
                </div>
                <div class="col-lg-4 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                  <select id="staff_id" name="staff_id" class="select3 form-select">
                      <option value="">Select Staff</option>
                  </select>
                  <div class="text-danger mt-1" id="error_staff_id"></div>
                </div>
              </div>
          </fieldset>
          <fieldset class="border p-3 mb-4">
            <legend class="w-auto px-2 text-success fw-bold">Intern Section</legend>
            <div id="intern-container">
                <div class="row mb-3">
                    <div class="col-lg-3 mb-3 branch_row">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Intern Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="intern_name" name="intern_name"
                            placeholder="Enter Intern Name"
                            oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                        <div class="text-danger mt-1" id="error_intern_name"></div>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Intern Email Id<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="intern_email_id" name="intern_email_id"
                            oninput="this.value = this.value.toLowerCase();" placeholder="Enter Intern Email Id" />
                        <div class="text-danger mt-1" id="error_intern_email_id"></div>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Intern Mobile No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" maxlength="10"
                            oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                            id="intern_mobile_no" name="intern_mobile_no" placeholder="Enter Intern Mobile Number" />
                        <div class="text-danger mt-1" id="error_intern_mobile_no"></div>
                    </div>
                </div>
            </div>
            <button type="button" class="btn btn-outline-success mt-2" onclick="addInternRow()">+ Add Intern</button>
          </fieldset>
          <div class="d-flex justify-content-end align-items-center gap-2 px-4 py-2 mb-4">
            <button type="submit" class="btn btn-primary mt-2" id="submit_butt">Create Intern</button>
          </div>
      </form>
    </div>
</div>
  <script>
   $(document).ready(function () {
        // Fetch College list and populate dropdown
        $.ajax({
            url: "{{ route('College') }}", // Endpoint for College list
            type: 'GET',
           success: function (response) {
               console.log(response);
                const collegeSelect = $('select[name="colleage_id"]');
                collegeSelect.empty(); // Clear existing options
                collegeSelect.append('<option value="">Select College</option>'); // Default option
    
                // Loop through the data and append options to the select element
                response.data.forEach(college => {
                    collegeSelect.append(`<option value="${college.sno}">${college.college_name}</option>`);
                });
            },
            error: function () {
                console.error('Error fetching college data');
            }
        });
        // Fetch Staff list and populate dropdown
        $.ajax({
            url: "{{ route('topic') }}",  // Endpoint for Staff list url: "{{ route('topic') }}",
            type: 'GET',
            success: function (response) {
                const staffSelect = $('select[name="topic_id"]');
                staffSelect.empty(); // Clear existing options
                staffSelect.append('<option value="">Select Topic</option>'); // Default option
    
                // Loop through the data and append options to the select element
                response.data.forEach(topic => {
                    staffSelect.append(`<option value="${topic.sno}">${topic.title}</option>`);
                });
            },
            error: function () {
                console.error('Error fetching Topic data');
            }
        });
    
        // Fetch Staff list and populate dropdown
            var branch = {{ auth()->user()->branch_id }}; // PHP value embedded into JS
            $.ajax({
                url: "/staff_list_by_branch_id/" + branch, // Build the URL dynamically in JS
                type: 'GET',
                success: function (response) {
                    const staffSelect = $('select[name="staff_id"]');
                    staffSelect.empty(); // Clear existing options
                    staffSelect.append('<option value="">Select Staff</option>'); // Default option

                    response.data.forEach(staff => {
                        staffSelect.append(`<option value="${staff.sno}">${staff.staff_name} - ${staff.job_position_name}</option>`);
                    });
                },
                error: function () {
                    console.error('Error fetching staff data');
                }
            });
    });


    let internIndex = 0;

    function addInternRow() {
        internIndex++;
        const container = document.getElementById('intern-container');
        const row = document.createElement('div');
        row.classList.add('row', 'mb-3');
        row.innerHTML = `
            <div class="col-lg-3 mb-3">
                <input type="text" class="form-control" name="interns[${internIndex}][name]" placeholder="Enter Intern Name" required id="intern_name_${internIndex}">
                <div class="text-danger mt-1" id="error_intern_name_${internIndex}"></div>
            </div>
            <div class="col-lg-3 mb-3">
                <input type="email" class="form-control" name="interns[${internIndex}][email]" placeholder="Enter Intern Email" required id="intern_email_${internIndex}">
                <div class="text-danger mt-1" id="error_intern_email_${internIndex}"></div>
            </div>
            <div class="col-lg-3 mb-3">
                <input type="text" maxlength="10" class="form-control" name="interns[${internIndex}][mobile]" placeholder="Enter Intern Mobile" required id="intern_mobile_${internIndex}">
                <div class="text-danger mt-1" id="error_intern_mobile_${internIndex}"></div>
            </div>
            <div class="col-lg-3 mb-3 d-flex align-items-center">
                <button type="button" class="btn btn-danger" onclick="this.closest('.row').remove()">Remove</button>
            </div>
        `;
        container.appendChild(row);
    }

    function validateInternRows() {
        let isValid = true;

        // Loop through each intern row and validate
        const internRows = document.querySelectorAll('[id^="intern_name_"]');
        internRows.forEach((row, index) => {
            const internIndex = index + 1;  // Get the intern index
            const internName = document.getElementById(`intern_name_${internIndex}`).value.trim();
            const internEmail = document.getElementById(`intern_email_${internIndex}`).value.trim();
            const internMobile = document.getElementById(`intern_mobile_${internIndex}`).value.trim();

            // Validate Intern Name
            if (!internName) {
                document.getElementById(`error_intern_name_${internIndex}`).innerText = "Please enter intern name.";
                isValid = false;
            } else {
                document.getElementById(`error_intern_name_${internIndex}`).innerText = "";
            }

            // Validate Intern Email
            if (!internEmail || !/\S+@\S+\.\S+/.test(internEmail)) {
                document.getElementById(`error_intern_email_${internIndex}`).innerText = "Please enter a valid email.";
                isValid = false;
            } else {
                document.getElementById(`error_intern_email_${internIndex}`).innerText = "";
            }

            // Validate Intern Mobile
            if (!internMobile || internMobile.length !== 10) {
                document.getElementById(`error_intern_mobile_${internIndex}`).innerText = "Please enter a valid mobile number.";
                isValid = false;
            } else {
                document.getElementById(`error_intern_mobile_${internIndex}`).innerText = "";
            }
        });

        return isValid;
    }
  </script>

<script>
  function submit_func() {
      let isValid = true;

      // Clear previous errors
      document.querySelectorAll(".text-danger").forEach(el => el.innerText = '');

      // Validate Colleage
      if (!document.getElementById("colleage_id").value) {
          document.getElementById("error_colleage_id").innerText = "Please select a college.";
          isValid = false;
      }

      // Validate Topic Name
      if (!document.getElementById("topic_id").value.trim()) {
          document.getElementById("error_topic_id").innerText = "Please enter topic name.";
          isValid = false;
      }

      // Validate Payment
      if (!document.getElementById("payment").value.trim()) {
          document.getElementById("error_payment").innerText = "Please enter payment amount.";
          isValid = false;
      }

      // Validate Dates
      if (!document.getElementById("share_start_date").value) {
          document.getElementById("error_start_date").innerText = "Please select start date.";
          isValid = false;
      }

      if (!document.getElementById("share_end_date").value) {
          document.getElementById("error_end_date").innerText = "Please select end date.";
          isValid = false;
      }

      // Validate Staff
      if (!document.getElementById("staff_id").value) {
          document.getElementById("error_staff_id").innerText = "Please select staff.";
          isValid = false;
      }

      // Prevent form submission if validation fails
      if (isValid) {
          // Call the validateInternRows function to check intern validations
          if (validateInternRows()) {
              // If all validations pass, submit the form
              $('#AddDropRefundForm').submit();
              $('#submit_butt').prop('disabled', true);  // Disable the submit button
          } else {
              event.preventDefault();  // Prevent form submission if intern validation fails
          }
      } else {
          event.preventDefault();  // Prevent form submission if general validation fails
      }

  }

  document.querySelector("#AddDropRefundForm").addEventListener("submit", function(e) {
      let isValid = true;

      // Clear previous errors
      document.querySelectorAll(".text-danger").forEach(el => el.innerText = '');

      // Validate Colleage
      if (!document.getElementById("colleage_id").value) {
          document.getElementById("error_colleage_id").innerText = "Please select a college.";
          isValid = false;
      }

      // Validate Topic Name
      if (!document.getElementById("topic_id").value.trim()) {
          document.getElementById("error_topic_id").innerText = "Please enter topic name.";
          isValid = false;
      }

      // Validate Payment
      if (!document.getElementById("payment").value.trim()) {
          document.getElementById("error_payment").innerText = "Please enter payment amount.";
          isValid = false;
      }

      // Validate Dates
      if (!document.getElementById("share_start_date").value) {
          document.getElementById("error_start_date").innerText = "Please select start date.";
          isValid = false;
      }

      if (!document.getElementById("share_end_date").value) {
          document.getElementById("error_end_date").innerText = "Please select end date.";
          isValid = false;
      }

      // Validate Staff
      if (!document.getElementById("staff_id").value) {
          document.getElementById("error_staff_id").innerText = "Please select staff.";
          isValid = false;
      }

      if (!isValid) {
          e.preventDefault();
      }
  });
</script>





@endsection
