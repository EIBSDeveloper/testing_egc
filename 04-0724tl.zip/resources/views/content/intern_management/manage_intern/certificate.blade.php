<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <style>
    @font-face {
      font-family: 'Mustica Pro';
      src: url('{{ public_path("fonts/MusticaPro-Regular.ttf") }}') format('truetype');
    }
    body {
      margin: 0;
      padding: 0;
      width: 190mm;
    }
    @page {
      /*size: A4 portrait;*/
      margin: 0;
    }
    .container {
      position: relative;
      width: 794px;
      height: 1110px;
      padding: 30px;
      box-sizing: border-box;
    }
    .bg-logo {
      position: absolute;
      bottom: 200px;
      left: 50px;
      width: 700px;
      height: auto;
      opacity: 0.1;
      z-index: 0;
    }
    .header-logo {
      width: 305px;
      height: 75px;
    }
    .text-content {
      position: relative;
      z-index: 2;
      color: #000000;
    }
    .section-title {
      text-align: center;
      font-size: 20px;
      font-weight: bold;
      padding: 30px 0;
      text-decoration: underline;
      font-family: 'Times New Roman', serif;
    }
    .paragraph {
      text-align: justify;
      font-size: 17px;
      line-height: 1.6rem;
      padding: 10px 50px;
      font-family: 'Times New Roman', serif;
    }
    .footer {
      display: flex;
      justify-content: space-between;
      font-size: 13px;
      font-weight: 800;
      padding: 20px 50px;
      border-top: 1px solid #ccc;
    }
    .footer div {
      width: 30%;
    }
    @media print
  </style>
</head>
<body>

    <div style="position: relative; width: 794px !important; height: 990px; padding: 30px !important; box-sizing: border-box;overflow:hidden !important; ">
    
        <!-- Background Logo -->
        <div style="position: absolute;bottom:18%;right: -140px;width: 100%;height: 215px;opacity: 0.1;transform: rotate(-23deg);pointer-events: none;z-index: 1;
        ">
          <img src="{{asset('logo_image/' . $interns->letter_logo) }}" alt="bg logo" style="width: 100%; height: 100%; object-fit: contain;" />
        </div>
        <!-- Foreground Content -->
        <div class="text-content">
          <img src="{{ asset('header_image/' . $interns->letter_header) }}" alt="Header Image" style="width: 90%; max-width: 1000px; height: auto;" />
            <div style="font-size:15px; font-weight:bold; padding:10px 50px 30px 50px; font-family:'Times New Roman', serif; display: block;">
                <div>
                    {{$interns->short_code ?? 'EGC:' }} {{ date('Y', strtotime($interns->certificate_issue_date)) }} – {{ date('Y', strtotime('+1 year', strtotime($interns->certificate_issue_date))) }}
                </div>
                <div>
                    Date: {{$interns->certificate_issue_date}}
                </div>
            </div>
          <div style="text-align:center !important; font-size:20px !important; font-weight:bold !important; padding:10px 50px 15px 50px !important;font-family: 'Times New Roman', serif;">
            <u>TO WHOM SO EVER IT MAY CONCERN</u>
          </div><div style="text-align:justify !important; font-size:17px !important; font-weight:400 !important; line-height:1.6rem !important; padding: 0 100px  10px 50px !important;font-family: 'Times New Roman', serif;">
            This is to certify that <strong>{{$interns->intern_name}}</strong>, a <strong>{{$interns->year}}</strong> <strong>{{$interns->education}}</strong> student from <strong>{{$interns->college_name}}</strong>, has successfully completed his/her<strong> INTERNSHIP in ({{$interns->title}})</strong> traning at <strong>{{$interns->company}}</strong>.
          </div>
          <div style="text-align:justify !important; font-size:17px !important; font-weight:400 !important; line-height:1.6rem !important; padding:10px 100px  10px 50px !important;font-family: 'Times New Roman', serif;">
          The internship took place from <strong>{{$interns->start_date_formatted}}</strong> to <strong>{{$interns->end_date_formatted}}</strong>. During this period, he/she exhibited a strong interest in the assigned responsibilities and maintained <strong>100% attendance</strong>.
          </div>
          <div style="text-align:justify !important; font-size:17px !important; font-weight:400 !important; line-height:1.6rem !important; padding: 10px 25px 10px 50px !important;font-family: 'Times New Roman', serif;">
            With Best Regards,
          </div>
    
           <div style="margin-top: 10px; padding: 0 90px; text-align: left;">
              <img src="{{ asset('signature/' . $interns->signature) }}" alt="Signature Image"
                   style="width: auto; max-width: 105px; height: 100px;" />
            </div>
          <div style="text-align:justify !important; font-size:18px !important; font-weight:400 !important; line-height:2rem !important; padding: 40px 50px 30px 50px !important;font-family: 'Times New Roman', serif;">
            <span style="font-weight: bold !important;">Authorized Signatory</span>
          </div>
    
          <div style="text-align:justify !important; font-size:18px !important; font-weight:400 !important; line-height:2rem !important; padding: 0px 50px 0px 50px !important;font-family: 'Times New Roman', serif;">
            <span style="font-weight: bold !important;">{{$interns->company}}</span>
          </div>
           <div style="text-align:justify !important; font-size:18px !important; font-weight:400 !important; line-height:2rem !important; padding: 0px 50px 0px 50px !important;font-family: 'Times New Roman', serif;">
            <span style="font-weight: bold !important;">Date: {{$interns->certificate_issue_date}}</span>
          </div>
           <div style="text-align:justify !important;padding: 0px 50px 0px 50px !important;">
                @if($qrBase64)
                    <div>
                        <img src="{{ $qrBase64 }}" alt="QR Code" style="width: 150px; height: 150px;">
                    </div>
                @else
                    <p style="color: red;">QR could not be generated.</p>
                @endif
            </div>
          <!--  Head HR-->
          <!--</div>-->
          <!-- Place this footer OUTSIDE .text-content if possible -->
            <table style="width: 100%; padding-top: 20px; font-size: 13px; font-weight: bold;margin-top:5px;">
              <tr>
                <td style="width: 30%; vertical-align: top; line-height: 1.4; border-right: 2px solid #0000004f; padding-left: 30px;">
                   <div style="font-size: 16px;">{{ $interns->mobile }}</div>
                   <div style="font-size: 16px;">{{ $interns->email }}</div>
                </td>
                <td style="width: 40%; vertical-align: top; line-height: 1.4; padding-right: 40px;">
                  <div style="margin-left:20px;">{{ $interns->letter_pad_desc }}</div>
                </td>
              </tr>
            </table>


        </div>
    </div>


</body>
</html>
