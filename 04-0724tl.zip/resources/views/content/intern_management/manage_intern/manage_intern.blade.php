@extends('layouts/layoutMaster')
@section('title', 'Manage Intern')
@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
])
@endsection
@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection
@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
<!-- Customer List Table -->
<style>
      table thead tr th{
        padding: 5px !important;
    }
    table tbody tr td{
        padding: 5px !important;
    }
</style>
<div class="card">
    <div class="card-header border-bottom pb-1 ">
        @php
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        @endphp
         <div class="row">
            <div class="col-lg-6">
              <h5 class="card-title mb-1">Manage Intern</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Manage Intern</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="col-lg-6">
              <ul class="nav nav-pills justify-content-end" role="tablist">
                  <li class="nav-item me-1">
                    <a href="{{ url('/add_intern') }}" class="btn btn-sm fw-bold btn-primary waves-effect waves-light">
                      <span class="me-2"><i class="mdi mdi-plus"></i></span>Create Intern
                  </a>
                </li>
              </ul>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
          <div class="col-lg-6 d-flex flex-wrap align-items-center mb-2 gap-2">
            
           <a href="#" class="text-center border border-2 p-2 mb-2">
                <div class="fw-semibold fs-6 text-black text-center">Total Intern</div>
               <div><img src="{{ asset('assets/phdizone_images/Group.gif') }}" alt="emoji" class="rounded ms-2 align-middle" style="max-width: 70px; height: 70px;"></div>
                <div class="d-block">
                <div class="badge bg-success rounded fw-bold fs-6"> {{ $allInternCount }}  </div>
                </div>
            </a>
             <a href="#" class="text-center border border-2 p-2 mb-2">
                <div class="fw-semibold fs-6 text-black text-center">Total Payment</div>
                <div><img src="{{ asset('assets/phdizone_images/Euro_Coins_Chest.gif') }}" alt="emoji" class="rounded ms-2 align-middle" style="max-width: 70px; height: 70px;"></div>
                <div class="d-block">
                <div class="badge bg-info rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i> {{ number_format($totalPayment, 2) }}  </div>
                </div>
            </a>
             <a href="" class="text-center border border-2 p-2 mb-2">
                <div class="fw-semibold fs-6 text-black text-center">Total Paid</div>
                <div><img src="{{ asset('assets/phdizone_images/Rupee_Inflation.gif') }}" alt="emoji" class="rounded ms-2 align-middle" style="max-width: 70px; height: 70px;"></div>
                <div class="d-block">
                <div class="badge bg-success rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i> {{ number_format($totalPaid, 2) }}  </div>
                </div>
            </a>
             <a href="" class="text-center border border-2 p-2 mb-2">
                <div class="fw-semibold fs-6 text-black text-center">Total Balance</div>
                <div><img src="{{ asset('assets/phdizone_images/Rupee_Deflation.gif') }}" alt="emoji" class="rounded ms-2 align-middle" style="max-width: 70px; height: 70px;"></div>
                <div class="d-block">
                <div class="badge bg-danger rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i> {{ number_format($totalBalance, 2) }}  </div>
                </div>
            </a>
        </div>
          <div class="col-lg-6 d-flex justify-content-end align-items-end mb-10">
                <a href="javascript:;"
                   class="nav-link px-4 py-2 btn btn-primary text-capitalize mt-3"
                   title="Intern Summary"
                   id="intern_summary"
                   data-bs-toggle="modal"
                   data-bs-target="#kt_modal_intern_summary">
                   <i class="mdi mdi-compare me-1"></i> Intern Summary
                </a>
            </div>
         </div>
        <div class="row">
            <div class="d-flex justify-content-between align-items-center">
                <div class="mb-4">
                    @php $perpage_count = $perpage ? $perpage : 25; @endphp
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                            @php
                            $options = [10, 25, 100, 500]; // Define available options
                            @endphp
                            @php foreach ($options as $option): @endphp
                            <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                @php echo $option; @endphp
                            </option>
                            @php endforeach; @endphp
                        </select>
                    </div>
                </div>
                <div class="mb-4">
                    <form id="search_form" method="POST" action="/manage_intern">
                    @csrf
                        <div class="d-flex align-items-center gap-2">
                            <div class="mb-1">
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="1">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                                <input type="text" class="form-control" id="cus_fill" name="cus_fill" value="{{ $customer_fill ?? "" }}" placeholder="Enter Intern - ID / Name/ Mob. No"/>
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div>
        <div class="col-lg-12">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
            <thead>
                <tr class=" align-top fw-bold fs-6 gs-0 bg-primary">
                    <th class="text-start"  style="width: 15%;">Intern</th>
                    <th class="text-start"  style="width: 20%;">College</th>
                    <th class="text-start"  style="width: 20%;">Date</th>
                    <th class="text-start" style="width: 10%;">Payment</th>
                    <th class="text-start" style="width: 10%;">Paid</th>
                    <th class="text-start" style="width: 10%;">Balance</th>
                    <th class="text-start" style="width: 10%;">Staff</th>
                    <th class="text-start" style="width: 10%;">Status</th>
                    <th class="min-w-100px">Action</th>
                </tr>
            </thead>
            <tbody class="text-black fw-semibold fs-7" id="payment-table-body">
                @if (isset($interns))
                     @foreach ($interns as $i => $pay)
                        <tr>
                            <!-- Intern -->
                            <td class="text-start">
                                 <div class="d-flex  px-1">
                                    <div class="symbol symbol-35px me-2 ">
                                        @php
                                        $initial = strtoupper(substr($pay->intern_name, 0, 1)); // Only keeps and
                                        @endphp
                                        <div class="avatar h-50px w-50px mt-2 me-2">
                                            <span class="avatar-initial rounded-circle bg-label-info">{{$initial}}</span>
                                        </div>
                                    </div>
                                    <div class="mb-0" style="max-width: 100px;"> <!-- Adjust width as needed -->
                                        <label>
                                            <span class="fs-7 me-1 text-truncate d-inline-block w-100" style="max-width: 100%;" title="{{ $pay->intern_name }}">
                                                {{ $pay->intern_name }}
                                            </span>
                                        </label>
                                        <div class="d-flex flex-column text-primary fs-8">
                                            <a href="javascript:;" class="text-primary fs-8 text-truncate d-inline-block w-100"
                                               data-bs-toggle="tooltip" data-bs-placement="bottom" title="Intern Email: {{ $pay->intern_email }}">
                                                {{ $pay->intern_email }}
                                            </a>
                                            <a href="javascript:;" class="text-primary fs-8 text-truncate d-inline-block w-100"
                                               data-bs-toggle="tooltip" data-bs-placement="bottom" title="Intern Mobile: {{ $pay->intern_mobile }}">
                                                {{ $pay->intern_mobile }}
                                            </a>
                                            <a href="javascript:;" class="text-info fs-8 text-truncate d-inline-block w-100"
                                               data-bs-toggle="tooltip" data-bs-placement="bottom" title="Intern ID: {{ $pay->intern_id }}">
                                                {{ $pay->intern_id }}
                                            </a>
                                        </div>
                                    </div>

                                </div>
                            </td>
            
                            <!-- College -->
                            <td class="text-start">{{ $pay->college_name }}</td>
            
                            <!-- Date -->
                           <td class="text-start align-middle fs-6">
                                <div class="d-flex flex-column gap-1">
                                    <div>
                                        <span class="badge bg-info text-white" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Start Date">
                                            {{ \Carbon\Carbon::parse($pay->start_date)->format('d-M-Y') }}
                                        </span>
                                    </div>
                                    @php
                                        $endDate = \Carbon\Carbon::parse($pay->end_date)->startOfDay();
                                        $today = \Carbon\Carbon::today();
                                        $isExpired = $today->greaterThan($endDate); // Only danger if today > end_date
                                    @endphp
                                    
                                    <div>
                                        <span class="badge {{ $isExpired ? 'bg-danger' : 'bg-success' }} text-white" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="End Date">
                                            {{ $endDate->format('d-M-Y') }}
                                        </span>
                                    </div>


                                </div>
                            </td>

            
                            <!-- Payment -->
                            <td class="text-center">
                                <div class="d-block">
                                    <label class="badge bg-info rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Payment">
                                      <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                                      <span class="fs-7">{{number_format($pay->payment, 2)}}</span>
                                    </label>
                                 </div>
                            </td>
                             <td class="text-center">
                                <div class="d-block">
                                    <label class="badge bg-success rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Paid">
                                      <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                                      <span class="fs-7">{{number_format($pay->paid, 2)}}</span>
                                    </label>
                                 </div>
                            </td>
                             <td class="text-center">
                                    <label class="badge bg-danger rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Balance">
                                      <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                                      <span class="fs-7">{{number_format($pay->balance, 2)}}</span>
                                    </label>
                            </td>

                            <td>
                                <div class="d-flex px-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff : {{ $pay->staff_name }}">
                                    @if (!empty($pay->staff_image) && file_exists(public_path('staff_images/' . $pay->staff_image)))
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input border rounded-pill image-input-circle" data-kt-image-input="true">
                                                <img src="{{ asset('staff_images/' . $pay->staff_image) }}"
                                                    alt="user-avatar" class="rounded-circle w-50px h-50px"
                                                    id="uploadedlogo" />
                                            </div>
                                        </div>
                                    @else
                                        <div class="symbol symbol-35px me-2">
                                            @php
                                                $initial = strtoupper(substr($pay->staff_name, 0, 1));
                                            @endphp
                                            <div class="avatar h-55px w-55px mt-2 me-2">
                                                <span class="avatar-initial rounded-circle bg-label-info">{{$initial}}</span>
                                            </div>
                                        </div>
                                    @endif

                                </div>
                            </td>
            
                            <!-- Status -->
                            <td class="text-start">
                                @if ($pay->balance == 0)
                                    <span class="badge bg-success fs-8 fw-semibold">Completed</span>
                                @else
                                    <span class="badge bg-warning text-dark fs-8 fw-semibold">Pending</span>
                                @endif
                            </td>
            
                            <!-- Action -->
                            <td> 
                               <div class="d-flex align-items-center">
                                    @if ($pay->balance == 0)
                                   
                                    @else
                                        <a class="btn btn-sm text-white fw-bold rounded-pill px-4 py-1"
                                           style="background: linear-gradient(to right, #ff416c, #ff4b2b); box-shadow: 0 4px 10px rgba(255, 75, 43, 0.4); transition: all 0.3s ease;"
                                           onclick="pyaIntern({{ $pay->sno }})">
                                           PAY
                                        </a>
                                    @endif
                            
                                    <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                       <a href="javascript:;" class="dropdown-item" onclick="viewModel({{ $pay->sno }})">
                                            <span><i class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                            <span>View</span>
                                        </a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_intern" onclick='populateUpdateModal(@json($pay))'>
                                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                            <span>Edit</span>
                                        </a>
                                         <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_invoice_intern" onclick="viewinvoiceModel({{ $pay->sno }})">
                                            <span><i class="mdi mdi-invoice-text-arrow-right-outline fs-3 text-black me-1"></i></span>
                                            <span>Invoice</span>
                                        </a>
                                       
                                       @if (is_null($pay->certificate_issue_date))
                                        @if($pay->balance < 1)
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_generate_certificate"  onclick="generateCert('{{$pay->sno}}', '{{ $pay->intern_name }}')">
                                                <span><i class="mdi mdi-domain fs-3 text-black me-1"></i></span>
                                                <span>Create Certificate</span>
                                            </a>
                                            @endif
                                        @else
                                        
                                            @if($pay->user_type == 1) 
                                                @if ($pay->generate_status == 1)
                                                    <a href="javascript:;" class="dropdown-item" onclick="downloadCert_confirm('{{$pay->sno}}')">
                                                        <span><i class="mdi mdi-download-circle-outline fs-3 text-black me-1"></i></span>
                                                        <span>Download Confirmation Certificate </span> 
                                                    </a>
                                                @else
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_intern_preview_confirm" onclick="viewPreviewModel_confirm({{ $pay->sno }})">
                                                        <span><i class="mdi mdi-printer-eye fs-3 text-black me-1"></i></span>
                                                        <span>Preview Confirmation Certificate</span> 
                                                     </a>
                                                @endif
                                            @else
                                                @if ($pay->generate_status == 1)
                                                <a href="javascript:;" class="dropdown-item" onclick="downloadCertStaff('{{$pay->sno}}')">
                                                    <span><i class="mdi mdi-download-circle-outline fs-3 text-black me-1"></i></span>
                                                    <span>Download Confirmation Certificate</span>
                                                </a>
                                                @else
                                                   <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_intern_preview_staff" onclick="viewPreviewModelStaff({{ $pay->sno }})">
                                                        <span><i class="mdi mdi-printer-eye fs-3 text-black me-1"></i></span>
                                                        <span>Preview Confirmation Certificate</span> 
                                                    </a>
                                                @endif
                                            @endif
                                       
                                            @if($pay->user_type == 1) 
                                                @if ($pay->generate_status == 1)
                                                    <a href="javascript:;" class="dropdown-item" onclick="downloadCert('{{$pay->sno}}')">
                                                        <span><i class="mdi mdi-download-circle-outline fs-3 text-black me-1"></i></span>
                                                        <span>Download Completion Certificate </span> 
                                                    </a>
                                                @else
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_intern_preview" onclick="viewPreviewModel({{ $pay->sno }})">
                                                        <span><i class="mdi mdi-printer-eye fs-3 text-black me-1"></i></span>
                                                        <span>Preview Completion Certificate</span> 
                                                     </a>
                                                @endif
                                            @else
                                                @if ($pay->generate_status == 1)
                                                <a href="javascript:;" class="dropdown-item" onclick="downloadCertStaff('{{$pay->sno}}')">
                                                    <span><i class="mdi mdi-download-circle-outline fs-3 text-black me-1"></i></span>
                                                    <span>Download Completion Certificate</span>
                                                </a>
                                                @else
                                                   <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_intern_preview_staff" onclick="viewPreviewModelStaff({{ $pay->sno }})">
                                                        <span><i class="mdi mdi-printer-eye fs-3 text-black me-1"></i></span>
                                                        <span>Preview Completion Certificate</span> 
                                                    </a>
                                                @endif
                                            @endif
                                            
                                        @endif
                                    </div>
                                </div>
                                
                            </td>
                        </tr>
                    @endforeach
                @endif
            </tbody>
            </table>

        </div>
        <div class="mt-4">
            {{ $interns->appends(request()->except(['page', '_token']))->links() }}
        </div>
        </div>
    </div>
</div>


<!--begin::Modal - Update intern-->
<div class="modal fade" id="kt_modal_edit_intern" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
        </div>
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-6">
          <h3 class="text-center text-black">Update Intern</h3>
        </div>
        <form>
             <input type="hidden" class="form-control" id="sno_edit" name="sno_edit"
                    placeholder="Enter Sno" />
            <div class="row">
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">College<span
                            class="text-danger">*</span></label>
                         <select id="college_id_edit" name="college_id_edit"
                        class="select3 form-select select_dropdown" data-parent-dropdown="kt_modal_edit_intern">
                        <option value="">Select College</option>
                    </select>
                    <div class="text-danger" id="college_id_edit_err"></div>
                </div>
                 <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Topic<span
                            class="text-danger">*</span></label>
                         <select id="topic_name_edit" name="topic_name_edit"
                        class="select3 form-select select_dropdown" >
                        <option value="">Select Topic</option>
                    </select>
                    <div class="text-danger" id="college_id_edit_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Payment<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="payment_edit" name="payment_edit"
                        placeholder="Enter Payment"  oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                    <div class="text-danger" id="payment_edit_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date<span
                            class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="hold_st_date" placeholder="Select Date" readonly class="start_date_edit form-control" name="start_date_edit" value="" />
                        </div>
                    <div class="text-danger" id="start_date_edit_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date<span
                            class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="end_date_edit" placeholder="Select Date" readonly class="end_date_edit form-control" name="end_date_edit" value="" />
                    </div>
                    <div class="text-danger" id="end_date_edit_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span
                            class="text-danger">*</span></label>
                    <select id="staff_id_edit" name="staff_id_edit"
                        class="select3 form-select" data-parent-dropdown="kt_modal_edit_intern">
                        <option value="">Select Staff</option>
                    </select>
                    <div class="text-danger" id="staff_id_edit_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Intern Name<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="intern_name_edit" name="intern_name_edit"
                        placeholder="Enter Intern Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"/>
                    <div class="text-danger" id="intern_name_edit_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Intern Email Id<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="intern_email_edit" name="intern_email_edit"
                        placeholder="Intern Email Id"  oninput="this.value = this.value.toLowerCase();"/>
                    <div class="text-danger" id="intern_email_edit_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Intern Mobile No<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="intern_mobile_editt" name="intern_mobile_editt"
                        placeholder="Enter Intern Mobile No" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                    <div class="text-danger" id="intern_mobile_editt_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Confirmation Letter TO</label>
                    <textarea class="form-control" name="college_to" id="college_to_edit" rows="3" placeholder="Enter College Confirmation Letter TO"></textarea>
                </div>
                
            </div>
         <div class="d-flex justify-content-end align-items-center mt-4">
            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" id="edit_submit_button" class="btn btn-primary">Update Intern</button>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!--end::Modal - Update intern-->

<!--begin::Modal - Update intern-->
<div class="modal fade" id="kt_modal_generate_certificate" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
        </div>
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-6">
          <h3 class="text-center text-black">Create Certificate</h3>
          <div class="text-center mb-4">
            <h5 id="intern_name_display" class="fw-bold text-info"></h5>
          </div>
        </div>
        <form id="generate_certificate_form">
             <input type="hidden" class="form-control" id="generate_id" name="generate_id"
                    placeholder="Enter Sno" />
            <div class="row">
                <div class="col-lg-12 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Company<span
                            class="text-danger">*</span></label>
                         <select id="company_id" name="company_id"
                        class="select3 form-select select_dropdown" data-parent-dropdown="kt_modal_generate_certificate">
                        <option value="">Select Company</option>
                    </select>
                    <div class="text-danger" id="company_id_edit_err"></div>
                </div>
                <!--<div class="col-lg-4 mb-3">-->
                <!--    <label class="text-dark mb-1 fs-6 fw-semibold">Degree<span-->
                <!--            class="text-danger">*</span></label>-->
                <!--         <select id="degree_id" name="degree_id"-->
                <!--        class="select3 form-select select_dropdown" data-parent-dropdown="kt_modal_generate_certificate">-->
                <!--        <option value="">Select Degree</option>-->
                <!--    </select>-->
                <!--    <div class="text-danger" id="degree_id_edit_err"></div>-->
                <!--</div>-->
                <div class="col-lg-12 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Type <span class="text-danger">*</span></label><br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="user_type" id="type_student" value="Student">
                        <label class="form-check-label" for="type_student">Student</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="user_type" id="type_employee" value="Employee">
                        <label class="form-check-label" for="type_employee">Employee</label>
                    </div>
                    <div class="text-danger" id="user_type_err"></div>
                </div>
                 <div class="col-lg-12 mb-3" id="degree_section">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Degree<span
                            class="text-danger">*</span></label>
                         <select id="degree_id" name="degree_id"
                        class="select3 form-select select_dropdown" data-parent-dropdown="kt_modal_generate_certificate">
                        <option value="">Select Degree</option>
                    </select>
                    <div class="text-danger" id="degree_id_err"></div>
                </div>
                
                <div class="col-lg-12 mb-3" id="year_section">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Year<span class="text-danger">*</span></label>
                    <select id="year" name="year" class="select3 form-select select_dropdown">
                        <option value="">Select Year</option>
                        <option value="I Year">I Year</option>
                        <option value="II Year">II Year</option>
                        <option value="III Year">III Year</option>
                        <option value="IV Year">IV Year</option>
                    </select>
                    <div class="text-danger" id="year_err"></div>
                </div>
                <div class="col-lg-12 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Confirmation Date<span
                            class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="confirmation_date" placeholder="Select Date" readonly class="end_date_edit form-control" name="confirmation_date" value="{{date('d-M-Y')}}" />
                    </div>
                    <div class="text-danger" id="confirmation_date_err"></div>
                </div>
                <div class="col-lg-12 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Certificate Issue Date<span
                            class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="certificate_issue_date" placeholder="Select Date" class="certificate_issue_date form-control" name="certificate_issue_date" value="" />
                        </div>
                    <div class="text-danger" id="certificate_issue_date_err"></div>
                </div>
                
            </div>
         <div class="d-flex justify-content-end align-items-center mt-4">
            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" id="generate_submit_button" class="btn btn-primary">
                <span class="indicator-label">Preview Certificate</span>
                <span class="indicator-progress" style="display: none;">
                    Submitting... <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                </span>
            </button>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!--end::Modal - Update intern-->

<!--begin::Modal - view intern-->
<div class="modal fade" id="kt_modal_view_intern" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
        </div>
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-6">
          <h3 class="text-center text-black">Intern Details</h3>
        </div>
        <div class="row">
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">College</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="college_id_view" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Topic Name</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="topic_name_view" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Payment</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="payment_view" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Start Date</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="start_date_view" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">End Date</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="end_date_view" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Staff</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="staff_id_view" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Intern Name</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="intern_name_view" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Intern Email Id</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="intern_email_view" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Intern Mobile No</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="intern_mobile_view" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--end::Modal - view intern-->
<!--begin::Modal - view intern-->
<div class="modal fade" id="kt_modal_invoice_intern" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
        </div>
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-6">
          <h3 class="text-center text-black">Intern Details</h3>
        </div>
        <div class="row">
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">College</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="college_id_view_invoice" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Topic Name</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="topic_name_view_invoice" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Payment</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="payment_view_invoice" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Start Date</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="start_date_view_invoice" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">End Date</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="end_date_view_invoice" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Staff</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="staff_id_view_invoice" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Intern Name</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="intern_name_view_invoice" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Intern Email Id</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="intern_email_view_invoice" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
        
          <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
              <div class="w-40 text-dark fs-6 fw-semibold">Intern Mobile No</div>
              <div class="w-5 text-dark fs-6 fw-semibold text-center">:</div>
              <div id="intern_mobile_view_invoice" class="w-55 fs-6 text-black">—</div>
            </div>
          </div>
          <div class="col-12 mt-5">
              <h4 class="text-center text-primary mb-3">Transaction History</h4>
              <div class="table-responsive">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                  <thead >
                   <tr class=" align-top fw-bold fs-6 gs-0 bg-primary">
                      <th>#</th>
                      <th>Invoice ID</th>
                      <th>Receipt ID</th>
                      <th>Payment Mode</th>
                      <th>Amount</th>
                      <th>Date & Time</th>
                      <th>Print</th>
                    </tr>
                  </thead>
                  <tbody id="transaction_table_body">
                    <tr><td colspan="6" class="text-center">Loading...</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--end::Modal - view intern-->
<!--begin::Modal - Add Payment Option-->
<div class="modal fade" id="kt_modal_payment_option" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!-- begin::Modal dialog -->
  <div class="modal-dialog modal-xl">
    <!-- begin::Modal content -->
    <div class="modal-content px-5 py-5 rounded">
      <!-- begin::Modal header -->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!-- begin::Close -->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!-- begin::Svg Icon | path: icons/duotune/arrows/arr061.svg -->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!-- end::Svg Icon -->
        </div>
        <!-- end::Close -->
      </div>
      <!-- end::Modal header -->
      <!-- begin::Modal body -->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!-- begin::Heading -->
        <div class="row mb-4">
          <div class="col-lg-7 d-flex justify-content-end mb-2">
              <h3 class="text-center mb-4 text-black">Payment Mode</h3>
          </div>
          <div class="col-lg-5 d-flex justify-content-end">
              
          </div>
        </div>
        <div class="row mb-4">
            <div class="col-lg-3 d-flex align-items-center mb-2">
              <div class="d-flex align-items-center px-1">
                <div class="symbol symbol-35px border border-gray-600i rounded me-2">
                  <div class="image-input image-input-circle" data-kt-image-input="true" id="intern_initial_symbol">
                   
                  </div>
                </div>
                <div class="mb-0 align-items-center">
                  <label>
                    <span class="fs-5 me-1 fw-bold" id="intern_name_pay"></span>
                  </label>
                  <div class="d-block text-secondary fs-6" title="Mobile"  id="intern_mobile_pay"></div>
                  <div class="d-block text-primary fs-6" title="Email ID" id="intern_email_pay"></div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 text-center">
              <div class="fw-bold text-black fs-6">Total Payment</div>
              <div class="fw-bold fs-4">
                <span class="badge bg-info p-3 rounded  fs-5" id="intern_total_payment">₹0.00</span>
              </div>
            </div>
            
            <div class="col-lg-3 text-center">
              <div class="fw-bold text-black fs-6">Total Paid</div>
              <div class="fw-bold fs-4">
                <span class="badge bg-success rounded  p-3 fs-5" id="intern_paid_payment">₹0.00</span>
              </div>
            </div>
            
            <div class="col-lg-3 text-center">
              <div class="fw-bold text-black fs-6">Total Balance</div>
              <div class="fw-bold fs-4">
                <span class="badge bg-danger rounded  p-3 fs-5 intern_balance_payment" id="intern_balance_payment">₹0.00</span>
              </div>
            </div>

          </div>
        </div>

        <div class="d-flex align-items-center flex-wrap px-5">
            <div id="payment_modes_container" class="fv-row mb-4 me-2"></div>
        </div>
        <div class="row px-5" id="dynamic_fields_payment"></div>
          <hr>
          <div id="payment_div" class="row" >
            <div  class="col-lg-4 text-center">
            </div>
          </div>

          <div class="row mt-2">
              <div  class="col-lg-4 text-center">
                
              </div>
              <div  class="col-lg-8">
                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                  <label class="fw-bold fs-5 me-13">Sub Total</label>
                  <div class="fw-bold fs-2">
                    <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                    <span class="fs-3" id="sub_total">0.00</span>
                  </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                  <div class="fw-bold fs-5 me-13">GST({{ $branch_data->gst_percentage }} %)
                    <div class="d-block fs-8 text-center">
                    <div class="d-block fw-bold fs-8">[{{ $branch_data->gst_check == 1 ? 'Inclusive' :'Exclusive' }}]</div>
                    </div>
                  </div>
                  <div class="fw-bold fs-2">
                    <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                    <label class="fs-2" id="sub_total_gst" >0.00</label>
                  </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                  <label class="fw-bold fs-3 me-13">Grand Total</label>
                  <div class="fw-bold fs-2">
                    <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                    <label class="fs-2" id="grand_total" >0.00</label>
                  </div>
                </div>
              </div>
          </div>
        <div class="d-flex justify-content-end align-items-center mt-4">
          <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
          <a href="javascript:;" class="btn btn-primary d-nones" data-bs-toggle="modal" data-bs-target="#kt_modal_update_payment" id="initial_fee_paid">Paid</a>
        </div>
        <!-- end::Modal body -->
      </div>
      <!-- end::Modal content -->
    </div>
    <!-- end::Modal dialog -->
  </div>
</div>
<!--end::Modal - Add Payment Option-->
<!--begin::Modal - Payment Confirmation-->
<div class="modal fade" id="kt_modal_update_payment" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!-- begin::Modal dialog -->
  <div class="modal-dialog modal-m">
    <!-- begin::Modal content -->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to Update Payment ?

        <div class="modal-body">
          <div class="d-flex justify-content-between mb-2">
              <span class="fw-semibold">Intern Name:</span>
              <span class="fw-bold text-danger" id="intern_name_display" ></span>
          </div>
          <input type="hidden" class="form-control" id="intern_sno_display" name="intern_sno_display"
                    placeholder="Enter Sno" />
          <div class="d-flex justify-content-between mb-2">
              <span class="fw-semibold">Intern ID:</span>
              <span class="fw-bold text-danger" id="intern_id_display"></span>
          </div>
          <div class="d-flex justify-content-between mb-2">
              <span class="fw-semibold">Mobile Number:</span>
              <span class="fw-bold text-danger" id="intern_mobile_display"></span>
          </div>
          <div class="d-flex justify-content-between mb-2">
              <span class="fw-semibold">Total Payment:</span>
              <span class="fw-bold text-danger" id="intern_payment_display"></span>
          </div>
          <div class="d-flex justify-content-between mb-2">
              <span class="fw-semibold">Paid Payment:</span>
              <span class="fw-bold text-danger" id="paid_payment_display"></span>
          </div>
          <div class="d-flex justify-content-between mb-2">
              <span class="fw-semibold">Payment Mode:</span>
              <span class="fw-bold text-danger" id="payment_mode_display"></span>
              <input type="hidden" name="payment_mode_display_hidden" id="payment_mode_display_hidden"/>
          </div>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="button" class="btn btn-primary me-3" id="confirm_update_button">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!-- end::Modal content -->
  </div>
  <!-- end::Modal dialog -->
</div>
<!--end::Modal - Payment Confirmation-->

<!--begin::Modal - Success Notification-->
<div class="modal fade" id="success_modal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content text-center p-4">
      <div class="modal-body">
        <h4 class="text-success mb-3">Success!</h4>
        <p id="success_modal_message" class="mb-4"></p>
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>
<!--end::Modal-->
<!-- Full Image Modal -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Profile Image</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body d-flex justify-content-center align-items-center">
        <img id="fullImage" src="" class="img-fluid rounded" style="max-height: 80vh;" />
      </div>
    </div>
  </div>
</div>

<!-- Summary Modal -->
<div class="modal fade" id="kt_modal_intern_summary" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl">
        <div class="modal-content rounded">
            <!--begin::Header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                  <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                      </svg>
                    </span>
                  </div>
                </div>
            <!--end::Header-->

            <!--begin::Body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-6 text-center">
                    <h3 class="text-black">Intern Summary</h3>                          
                </div>                      
                    <ul class="nav nav-pills justify-content-between" role="tablist">
                      <p class="fw-semibold fs-5 text-primary mb-0">
                        Total Interns: <span class="badge bg-info fs-6 px-3 py-2" id="totalInternCount">
                                    
                                  </span>
                      </p>
                      <div class="d-flex align-items-center gap-3 mb-2">
                        <div class="text-center">
                          <a href="#" id="prevMonthBtnpopup">
                            <div class="text-center">
                                <span class="mdi mdi-arrow-left-circle-outline fs-2"></span>
                            </div>
                          </a>
                        </div>
                        <a class="text-center bg-primary active rounded fw-semibold text-white fs-6 px-6 py-0"   href="#">
                          <div class="text-center">
                              <span class="fs-6 fw-semibold text-capitalize" id="selectedMonthpopup">
                                  {{ \Carbon\Carbon::now()->format('F') }}
                              </span>
                              <div class="d-block">
                                  <span class="fw-semibold fs-6" id="selectedYear">
                                      {{ \Carbon\Carbon::now()->year }}
                                  </span>
                              </div>
                          </div>
                        </a>
                        <div class="text-center">
                          <a  href="#" id="nextMonthBtnpopup">
                                <div class="text-center">
                                    <span class="mdi mdi-arrow-right-circle-outline fs-2"></span>
                                </div>
                            </a>
                        </div>
                      </div>
                    </ul>
                

                <div class="table-responsive" id="lead_comparison_view">
                    <table class="table table-striped gy-0 gs-1">
                        <thead>
                            <tr class="bg-primary text-white fw-bold">
                                <th class="min-w-50px">College</th>
                                <th class="min-w-50px">Count</th>
                                 <th class="min-w-50px">Course (Topic)</th>
                                <th class="min-w-50px">Count </th>
                            </tr>
                        </thead>
                        <tbody id="college-table-body" class="text-black fw-semibold fs-7 position-relative">
                           
                        </tbody>
                    </table>

                </div>
            </div>
            
            <!--end::Body-->
        </div>
    </div>
</div>

<!--begin::Modal - Payment Confirmation-->
<div class="modal fade" id="kt_modal_intern_preview" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!-- begin::Modal dialog -->
  <div class="modal-dialog modal-xl">
    <!-- begin::Modal content -->
    <div class="modal-content rounded">
        <div class="modal-header justify-content-end border-0 pb-0">
           <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
            <span class="svg-icon svg-icon-1">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
              </svg>
            </span>
          </div>
        </div>
        <div class="modal-body " style="display:flex; 
      justify-content:center;">
          
        </div>
        <input type="hidden" class="intern_id_preview" id="intern_id_preview" name="intern_id_preview" value="">
      <div class="d-flex justify-content-end align-items-center pt-8">
        <button type="button" class="btn btn-primary me-3" id="generate_certificate_student_button">Generate Certificate</button>
      </div><br><br>
    </div>
    <!-- end::Modal content -->
  </div>
  <!-- end::Modal dialog -->
</div>
<!--end::Modal - Payment Confirmation-->
<!--begin::Modal - Payment Confirmation-->
<div class="modal fade" id="kt_modal_intern_preview_confirm" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!-- begin::Modal dialog -->
  <div class="modal-dialog modal-xl">
    <!-- begin::Modal content -->
    <div class="modal-content rounded">
        <div class="modal-header justify-content-end border-0 pb-0">
           <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
            <span class="svg-icon svg-icon-1">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
              </svg>
            </span>
          </div>
        </div>
        <div class="modal-body " style="display:flex; 
      justify-content:center;">
          
        </div>
        <input type="hidden" class="intern_id_preview" id="intern_id_preview_confirm" name="intern_id_preview" value="">
      <div class="d-flex justify-content-end align-items-center pt-8">
        <button type="button" class="btn btn-primary me-3" id="generate_certificate_student_button_confirm">Generate Confirmation Certificate</button>
      </div><br><br>
    </div>
    <!-- end::Modal content -->
  </div>
  <!-- end::Modal dialog -->
</div>
<!--end::Modal - Payment Confirmation-->
<!--begin::Modal - Payment Confirmation-->
<div class="modal fade" id="kt_modal_intern_preview_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!-- begin::Modal dialog -->
  <div class="modal-dialog modal-xl">
    <!-- begin::Modal content -->
    <div class="modal-content rounded">
        <div class="modal-header justify-content-end border-0 pb-0">
           <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
            <span class="svg-icon svg-icon-1">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
              </svg>
            </span>
          </div>
        </div>
         <div class="modal-body " style="display:flex; 
           justify-content:center;">
        </div>
         <input type="hidden" id="intern_id_preview_staff" name="intern_id_preview_staff" value="">
      <div class="d-flex justify-content-end align-items-center pt-8">
         <button type="button" class="btn btn-primary me-3" id="generate_certificate_staff_button">Generate Certificate</button>
      </div><br><br>
    </div>
    <!-- end::Modal content -->
  </div>
  <!-- end::Modal dialog -->
</div>
<!--end::Modal - Payment Confirmation-->
<style>
  .w-40 { width: 40%; }
  .w-5 { width: 5%; }
  .w-55 { width: 55%; }
  
      
</style>
<style>
    /* Add this in your stylesheet */
    .d-nones {
        display: none !important;
    }
   .select2-container {
      z-index: 9999 !important;
    }
</style>
<script>
    $('#generate_certificate_student_button').click(function () {
        const intern_id = $('.intern_id_preview').val();
    
        $.ajax({
            url: "{{ route('update_certificate_status') }}", // adjust route name
            type: "POST",
            data: {
                _token: '{{ csrf_token() }}',
                intern_id: intern_id
            },
            success: function(response) {
                if (response.status === 200) {
                     $('#generate_certificate_student_button').text("Certificate Generated").prop("disabled", true);
                     toastr.success('Certificate Generated successfully!');
                    location.reload();
                    // optionally disable button or change text
                   
                } else {
                    alert("Failed to update certificate status.");
                }
            },
            error: function() {
                alert("Server error. Try again.");
            }
        });
    });
    $('#generate_certificate_student_button_confirm').click(function () {
        const intern_id = $('.intern_id_preview').val();
    
        $.ajax({
            url: "{{ route('update_certificate_status') }}", // adjust route name
            type: "POST",
            data: {
                _token: '{{ csrf_token() }}',
                intern_id: intern_id
            },
            success: function(response) {
                if (response.status === 200) {
                     $('#generate_certificate_student_button_confirm').text("Certificate Generated").prop("disabled", true);
                     toastr.success('Certificate Generated successfully!');
                    location.reload();
                    // optionally disable button or change text
                   
                } else {
                    alert("Failed to update certificate status.");
                }
            },
            error: function() {
                alert("Server error. Try again.");
            }
        });
    });
     $('#generate_certificate_staff_button').click(function () {
        const intern_id = $('#intern_id_preview_staff').val();
    
        $.ajax({
            url: "{{ route('update_certificate_status') }}", // adjust route name
            type: "POST",
            data: {
                _token: '{{ csrf_token() }}',
                intern_id: intern_id
            },
            success: function(response) {
                if (response.status === 200) {
                     $('#generate_certificate_student_button').text("Certificate Generated").prop("disabled", true);
                     toastr.success('Certificate Generated successfully!');
                    location.reload();
                    // optionally disable button or change text
                   
                } else {
                    alert("Failed to update certificate status.");
                }
            },
            error: function() {
                alert("Server error. Try again.");
            }
        });
    });

    document.addEventListener('DOMContentLoaded', function () {
        let monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
    
        let currentMonth = new Date().getMonth(); // 0-based
        let currentYear = new Date().getFullYear();
    
        function updateCalendarDisplay() {
            document.getElementById('selectedMonthpopup').innerText = monthNames[currentMonth];
            document.getElementById('selectedYear').innerText = currentYear;
        }

    function fetchInternData(month, year) {
        fetch(`/intern-date?month=${month + 1}&year=${year}`, {
            method: 'GET',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            console.log(data);
            document.getElementById('totalInternCount').innerText = data.totalInternCount;

            const colleges = data.collegeCounts;
            const courses = data.courseCounts;

            const maxLength = Math.max(colleges.length, courses.length);
            let tableBody = '';

            for (let i = 0; i < maxLength; i++) {
                const college = colleges[i] || {};
                const course = courses[i] || {};

                const collegeName = college.college_name || '-';
                const internCount = college.intern_count || '-';

                const courseTitle = course.course_title || '-';
                const courseCount = course.course_count || '-';

                    tableBody += `
                        <tr>
                            <td>${collegeName} </td>
                            <td><span class="badge  bg-info fs-6 px-3 py-2">${internCount}</span></td>
                            <td>${courseTitle}</td>
                            <td><span class="badge  bg-info fs-6 px-3 py-2">${courseCount}</span></td>
                            
                        </tr>
                    `;
            }

            document.getElementById('college-table-body').innerHTML = tableBody;
        })
        .catch(error => console.error('Error fetching intern data:', error));
    }

    document.getElementById('prevMonthBtnpopup').addEventListener('click', function (e) {
        e.preventDefault();
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        updateCalendarDisplay();
        fetchInternData(currentMonth, currentYear);
    });

    document.getElementById('nextMonthBtnpopup').addEventListener('click', function (e) {
        e.preventDefault();
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        updateCalendarDisplay();
        fetchInternData(currentMonth, currentYear);
    });

    // Initial fetch on load
    updateCalendarDisplay();
    fetchInternData(currentMonth, currentYear);
  });

    $(document).ready(function () {
    // Initially hide the Year and Degree fields
    $("#year_section").hide();
    $("#degree_section").hide();

    // Listen for radio button changes
    $("input[name='user_type']").change(function () {
        const selectedType = $(this).val();
        if (selectedType === "Student") {
            $("#year_section").show();
            $("#degree_section").show();
        } else {
            $("#year_section").hide();
            $("#degree_section").hide();
            $("#year").val(""); // clear year
            $("#degree_id").val(""); // clear degree
        }
    });

    // Reload on success modal close
    $('#success_modal').on('hidden.bs.modal', function () {
        location.reload();
    });

    // Handle form submission
    const form = document.getElementById("generate_certificate_form");
    const submitBtn = document.getElementById("generate_submit_button");

    form.addEventListener("submit", function (e) {
            e.preventDefault();
    
            // Clear previous errors
            $("#company_id_edit_err").text("");
            $("#degree_id_err").text("");
            $("#year_err").text("");
            $("#certificate_issue_date_err").text("");
            $("#confirmation_date_err").text("");
            $("#user_type_err").text("");
    
            let hasError = false;
    
            const company_id = $("#company_id").val().trim();
            const degree_id = $("#degree_id").val().trim();
            const year = $("#year").val().trim();
            const issue_date = $("#certificate_issue_date").val().trim();
            const confirmation_date = $("#confirmation_date").val().trim();
            const sno = $("input[name='generate_id']").val();
            const user_type = $("input[name='user_type']:checked").val();
    
            if (!user_type) {
                $("#user_type_err").text("Please select user type");
                hasError = true;
            }
    
            if (!company_id) {
                $("#company_id_edit_err").text("Please select company");
                hasError = true;
            }
    
            if (user_type === "Student") {
                if (!degree_id) {
                    $("#degree_id_err").text("Please select degree");
                    hasError = true;
                }
                if (!year) {
                    $("#year_err").text("Please select year");
                    hasError = true;
                }
            }
    
            if (!issue_date) {
                $("#certificate_issue_date_err").text("Please select certificate issue date");
                hasError = true;
            }
            if (!confirmation_date) {
                $("#confirmation_date_err").text("Please select Confirmation date");
                hasError = true;
            }
    
            if (hasError) return;
    
            // Disable button and show spinner
            submitBtn.disabled = true;
            submitBtn.querySelector(".indicator-label").style.display = "none";
            submitBtn.querySelector(".indicator-progress").style.display = "inline-block";
    
            const formData = new FormData();
            formData.append("company_id", company_id);
            formData.append("degree_id", degree_id);
            formData.append("year", year);
            formData.append("certificate_issue_date", issue_date); 
            formData.append("confirmation_date", confirmation_date); 
            formData.append("generate_id", sno);
            formData.append("user_type", user_type);
    
            fetch("/generate-certificate", {
                method: "POST",
                headers: {
                    "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').getAttribute("content")
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                submitBtn.disabled = false;
                submitBtn.querySelector(".indicator-label").style.display = "inline-block";
                submitBtn.querySelector(".indicator-progress").style.display = "none";
    
                if (data.success) {
                      const internId = data.intern_id;
                    if (data.user_type == 1) {
                        viewPreviewModel(internId);
                        new bootstrap.Modal(document.getElementById("kt_modal_intern_preview")).show();
                    } else {
                        viewPreviewModelStaff(internId);
                        new bootstrap.Modal(document.getElementById("kt_modal_intern_preview_staff")).show();
                    }
            
                    form.reset();
                    $("#intern_name_display").text("");
                    $('#kt_modal_generate_certificate').modal('hide');
                } else {
                    alert(data.message || "Something went wrong.");
                }
            })
            .catch(error => {
                console.error("Error:", error);
                Swal.fire("Error!", "Internal Server Error", "error");
                submitBtn.disabled = false;
                submitBtn.querySelector(".indicator-label").style.display = "inline-block";
                submitBtn.querySelector(".indicator-progress").style.display = "none";
            });
        });
    });

        function viewPreviewModel(sno) {
            $('.intern_id_preview').val(sno);  // sets hidden input
            const modalBody = $('#kt_modal_intern_preview .modal-body');
            modalBody.html('<div class="text-center p-5">Loading preview...</div>');
        
            $.ajax({
                url: '/intern/preview/' + sno,
                type: 'GET',
                success: function (response) {
                    modalBody.html(response); // Replace modal body with the preview HTML
                },
                error: function (xhr) {
                    modalBody.html('<div class="text-danger text-center">Failed to load preview. Please try again later.</div>');
                }
            });
        }
        function viewPreviewModel_confirm(sno) {
            $('.intern_id_preview').val(sno);  // sets hidden input
            const modalBody = $('#kt_modal_intern_preview_confirm .modal-body');
            modalBody.html('<div class="text-center p-5">Loading preview...</div>');
        
            $.ajax({
                url: '/intern/preview_confirm/' + sno,
                type: 'GET',
                success: function (response) {
                    modalBody.html(response); // Replace modal body with the preview HTML
                },
                error: function (xhr) {
                    modalBody.html('<div class="text-danger text-center">Failed to load preview. Please try again later.</div>');
                }
            });
        }
        
        function viewPreviewModelStaff(sno) {
             $('#intern_id_preview_staff').val(sno);
              const modalBody = $('#kt_modal_intern_preview_staff .modal-body');
            modalBody.html('<div class="text-center p-5">Loading preview...</div>');
        
            $.ajax({
                url: '/intern/preview/staff/' + sno,
                type: 'GET',
                success: function (response) {
                     console.log("Staff preview content loaded."); 
                    modalBody.html(response || '<div class="text-danger text-center">No preview available.</div>');
                },
                error: function (xhr) {
                    modalBody.html('<div class="text-danger text-center">Failed to load preview. Please try again later.</div>');
                }
            });
        }
        
</script>


<script>
    function downloadCert(id) {
       
 
         // Combine the IDs to be sent for encryption
         var values = id;
 
         // Get the CSRF token from the meta tag
         var csrfToken = $('meta[name="csrf-token"]').attr('content');
 
         // Use AJAX to encrypt the combined values using a PHP route
         $.ajax({
             url: '/ids/encrypt', // Your encryption route
             type: 'POST',
             data: {
                 values: values,
                 _token: csrfToken // Include CSRF token here
             },
             success: function(encrypted_course_id) {
                 // Redirect to the PDF generation route with the encrypted ID
                     const iframe = document.createElement('iframe');
                    iframe.style.display = 'none';
                    iframe.src = '/intern_certificate/' + encrypted_course_id;
                    document.body.appendChild(iframe);
                
                    // Wait a bit before refreshing the page
                    // setTimeout(function () {
                    //     location.reload();
                    // }, 2000); // Adjust the delay as needed
                 
             },
             error: function(xhr) {
                 Swal.fire({
                     title: 'Error!',
                     text: xhr.responseJSON.message || 'Encryption failed.',
                     icon: 'error',
                     customClass: {
                         confirmButton: 'btn btn-primary waves-effect waves-light'
                     },
                     buttonsStyling: false
                 });
             }
         });
     }
     function downloadCert_confirm(id) {
       
 
         // Combine the IDs to be sent for encryption
         var values = id;
 
         // Get the CSRF token from the meta tag
         var csrfToken = $('meta[name="csrf-token"]').attr('content');
 
         // Use AJAX to encrypt the combined values using a PHP route
         $.ajax({
             url: '/ids/encrypt', // Your encryption route
             type: 'POST',
             data: {
                 values: values,
                 _token: csrfToken // Include CSRF token here
             },
             success: function(encrypted_course_id) {
                 // Redirect to the PDF generation route with the encrypted ID
                     const iframe = document.createElement('iframe');
                    iframe.style.display = 'none';
                    iframe.src = '/intern_certificate_confirm/' + encrypted_course_id;
                    document.body.appendChild(iframe);
                
                    // Wait a bit before refreshing the page
                    // setTimeout(function () {
                    //     location.reload();
                    // }, 2000); // Adjust the delay as needed
                 
             },
             error: function(xhr) {
                 Swal.fire({
                     title: 'Error!',
                     text: xhr.responseJSON.message || 'Encryption failed.',
                     icon: 'error',
                     customClass: {
                         confirmButton: 'btn btn-primary waves-effect waves-light'
                     },
                     buttonsStyling: false
                 });
             }
         });
     }
     function downloadCertStaff(id) {
     
 
         // Combine the IDs to be sent for encryption
         var values = id;
 
         // Get the CSRF token from the meta tag
         var csrfToken = $('meta[name="csrf-token"]').attr('content');
 
         // Use AJAX to encrypt the combined values using a PHP route
         $.ajax({
             url: '/ids/encrypt', // Your encryption route
             type: 'POST',
             data: {
                 values: values,
                 _token: csrfToken // Include CSRF token here
             },
             success: function(encrypted_course_id) {
                 // Redirect to the PDF generation route with the encrypted ID
                     const iframe = document.createElement('iframe');
                    iframe.style.display = 'none';
                    iframe.src = '/intern_certificate_employee/' + encrypted_course_id;
                    document.body.appendChild(iframe);
                
                    // Wait a bit before refreshing the page
                    setTimeout(function () {
                        location.reload();
                    }, 2000); // Adjust the delay as needed
                 
             },
             error: function(xhr) {
                 Swal.fire({
                     title: 'Error!',
                     text: xhr.responseJSON.message || 'Encryption failed.',
                     icon: 'error',
                     customClass: {
                         confirmButton: 'btn btn-primary waves-effect waves-light'
                     },
                     buttonsStyling: false
                 });
             }
         });
     }
     
</script>
<script>
    function generateCert(sno, intern_name) {
    // Set hidden input
        document.querySelector("input[name='generate_id']").value = sno;
    
        // Display intern name
        document.getElementById("intern_name_display").textContent = intern_name;
    }


      // Fetch letter_pad
        $.ajax({
            url: "{{ route('letter_pad') }}",
            type: 'GET',
            success: function (response) {
               
                const collegeSelect = $('select[name="company_id"]');
                collegeSelect.empty();
                collegeSelect.append('<option value="">Select Company</option>');
    
                response.data.forEach(company => {
                    collegeSelect.append(`<option value="${company.sno}">${company.company}</option>`);
                });
                
            },
            error: function () {
                console.error('Error fetching company data');
            }
        });
        
         // Fetch education list and populate dropdown
        $.ajax({
            url: "{{ route('education') }}",  // Endpoint for Staff list url: "{{ route('education') }}",
            type: 'GET',
            success: function (response) {
                const staffSelect = $('select[name="degree_id"]');
                staffSelect.empty(); // Clear existing options
                staffSelect.append('<option value="">Select Degree</option>'); // Default option
    
                // Loop through the data and append options to the select element
                response.data.forEach(education => {
                    staffSelect.append(`<option value="${education.sno}">${education.education}</option>`);
                });
            },
            error: function () {
                console.error('Error fetching Topic data');
            }
        });


   function pyaIntern(sno) {
      $.ajax({
        url: '/intern/view',
        type: 'POST',
        data: { sno: sno, _token: '{{ csrf_token() }}' },
        success: function(response) {
          if (response.status === 'success') {
            let intern = response.data;
    
            // Populate modal fields
            $('#intern_sno_display').val(intern.sno);
            $('#intern_mobile_pay').text(intern.intern_mobile);
            $('#intern_name_pay').text(intern.intern_name);
            $('#intern_email_pay').text(intern.intern_email);
            $('#intern_name_display').text(intern.intern_name);
            $('#intern_id_display').text(intern.intern_id);
            $('#intern_mobile_display').text(intern.intern_mobile);
            $('#intern_payment_display').text(intern.payment);
            $('#paid_payment_display').text(intern.paid);
             $('#intern_total_payment_modal').text(intern.payment);
            $('#intern_total_payment').text(`₹${parseFloat(intern.payment).toFixed(2)}`);
            $('#intern_paid_payment').text(`₹${parseFloat(intern.paid).toFixed(2)}`);
            $('#intern_balance_payment').text(`₹${parseFloat(intern.payment - intern.paid).toFixed(2)}`);
            
            const initial = intern.intern_name.charAt(0).toUpperCase();
            const gender = intern.gender; // Assume 1 = male, 2 = female, etc.
            
            // If you want to replicate PHP helper, you'd need a JS version of `name_image`
            let bgColor = gender == 1 ? '#3498db' : '#e91e63'; // Male or Female color
            let initialHtml = `
              <span class="symbol-label fs-6 fw-bold text-white d-flex align-items-center justify-content-center"
                    style="background-color: ${bgColor}; width: 35px; height: 35px; border-radius: 50%;">
                ${initial}
              </span>
            `;
            $('#intern_initial_symbol').html(initialHtml);
          
            // Show the payment modal
            $('#kt_modal_payment_option').modal('show');
          } else {
            alert('Failed to fetch intern data: ' + response.message);
          }
        },
        error: function(xhr) {
          alert('Failed to load payment data');
          console.log(xhr.responseText);
        }
      });
    }
        $(document).on('input', '#payment_amount', function () {
            updateFees();
        });
        
       $('#kt_modal_edit_intern').on('shown.bs.modal', function () {
      $('#college_id_edit').select2({
        dropdownParent: $('#kt_modal_edit_intern')
      });
    
      $('#topic_name_edit').select2({
        dropdownParent: $('#kt_modal_edit_intern')
      });
    
      $('#staff_id_edit').select2({
        dropdownParent: $('#kt_modal_edit_intern')
      });
    });
</script>

<script>
 function viewModel(sno) {
    $.ajax({
        url: '/intern/view', // Adjust if using a named route like route('intern.view')
        method: 'POST',
        data: {
            sno: sno,
            _token: '{{ csrf_token() }}'
        },
        success: function(response) {
            if (response.status === 'success') {
                const data = response.data;

                $('#college_id_view').text(data.college_name); // or map from ID
                $('#topic_name_view').text(data.topic);
                $('#payment_view').text(data.payment);
                $('#start_date_view').text(data.start_date);
                $('#end_date_view').text(data.end_date);
                $('#staff_id_view').text(data.staff_name); // or map from ID
                $('#intern_name_view').text(data.intern_name);
                $('#intern_email_view').text(data.intern_email);
                $('#intern_mobile_view').text(data.intern_mobile);

                $('#kt_modal_view_intern').modal('show');
            } else {
                alert(response.message || 'Something went wrong');
            }
        },
        error: function(xhr) {
            console.error(xhr);
            alert('Failed to fetch intern data.');
        }
    });
}
</script>
<script>
 function viewinvoiceModel(sno) {
    $.ajax({
        url: '/intern/view/invoice', // Adjust if using a named route like route('intern.view')
        method: 'POST',
        data: {
            sno: sno,
            _token: '{{ csrf_token() }}'
        },
        success: function(response) {
            if (response.status === 'success') {
                const data = response.data;

                $('#college_id_view_invoice').text(data.college_name); // or map from ID
                $('#topic_name_view_invoice').text(data.topic);
                $('#payment_view_invoice').text(data.payment);
                $('#start_date_view_invoice').text(data.start_date);
                $('#end_date_view_invoice').text(data.end_date);
                $('#staff_id_view_invoice').text(data.staff_name); // or map from ID
                $('#intern_name_view_invoice').text(data.intern_name);
                $('#intern_email_view_invoice').text(data.intern_email);
                $('#intern_mobile_view_invoice').text(data.intern_mobile);

               // Populate transaction history table
                let tableBody = '';
                if (data.transactions && data.transactions.length > 0) {
                    data.transactions.forEach((txn, index) => {
                        tableBody += `
                            <tr>
                                <td>${index + 1}</td>
                                <td>${txn.invoice_id ?? '—'}</td>
                                <td>${txn.receipt_id ?? '—'}</td>
                                <td>${txn.payment_mode ?? '—'}</td>
                                <td>₹${txn.payment_amount ?? '0'}</td>
                                <td>${new Date(txn.timestamp).toLocaleDateString('en-GB', {
                                        day: '2-digit',
                                        month: 'short',
                                        year: 'numeric'
                                    }).replace(/ /g, '-')}
                                </td>
                                <td>
                                    <a href="/customer/manage_intern/intern_print/${txn.encryptedValue}/${txn.printValue}/${data.sno}" target="_blank">
                                        <img src="/assets/phdizone_images/print.svg" alt="Print Invoice" style="height: 30px;">
                                    </a>
                                </td>
                            </tr>
                        `;
                    });
                } else {
                    tableBody = `<tr><td colspan="7" class="text-center text-muted">No transactions found</td></tr>`;
                }
                $('#transaction_table_body').html(tableBody);
                
                // Finally show modal
                $('#kt_modal_invoice_intern').modal('show');
            } else {
                alert(response.message || 'Something went wrong');
            }
        },
        error: function(xhr) {
            console.error(xhr);
            alert('Failed to fetch intern data.');
        }
    });
}
</script>
<script>
 function safelyParseJSONPayment(json) {
      try {
          if (typeof json === 'object') {
              return json;
          }
          return JSON.parse(json);
      } catch (e) {
          console.error('Error parsing JSON:', e);
          return [];
      }
  }

  let PaymentOptionData = [];
  let oldStepDataPay = {}; // Placeholder for old step data, adjust accordingly

  // Fetch payment mode on page load
 
  function fetchPaymentOption() {
      $.ajax({
          url: "{{ route('payment_mode') }}",
          type: "GET",
          success: function(response) {
              if (response.status === 200 && response.data) {
                  const paymentModesContainer = $('#payment_modes_container');
                  paymentModesContainer.empty();
                  let defaultPaymentModeId = null; // This can be set to your desired default ID

                  response.data.forEach(function(type) {
                      const isChecked = type.sno === defaultPaymentModeId ? 'checked' : '';
                      const radioHtml = `
                          <label class="form-check form-check-inline form-check-solid">
                              <input class="form-check-input" name="payment_mode_id" type="radio" value="${type.sno}" data-paymentmode-name="${type.paymentmode_name}" ${isChecked}>
                              <span class="col-form-label fw-semibold fs-6">${type.paymentmode_name}</span>
                          </label>`;
                      paymentModesContainer.append(radioHtml);
                  });

                  // Set the default selected radio button if none is selected
                  if (!defaultPaymentModeId) {
                      $('input[name="payment_mode_id"]:first').prop('checked', true);
                  }


                  // Trigger change event to handle default selection
                  $('input[name="payment_mode_id"]').change(handlePaymentModeChange);

                  // Call to handle payment mode change to initialize the dynamic fields
                  handlePaymentModeChange();
              } else {
                  console.error('Error fetching payment mode:', response.message);
              }
          },
          error: function(error) {
              console.error('Error fetching payment mode:', error);
          }
      });
  }

   // Fetch payment options based on selected payment mode
   function handlePaymentModeChange() {
      const selectedPaymentModeId = $('input[name="payment_mode_id"]:checked').val();
      const selectedPaymentModeName = $('input[name="payment_mode_id"]:checked').data('paymentmode-name'); // Get the name of the selected payment mode
      const url = `/payment_option_list/${selectedPaymentModeId}`;


      const totalPaymentModeElement = document.getElementById('payment_mode_display');
      if (totalPaymentModeElement) {
          totalPaymentModeElement.textContent = selectedPaymentModeName; // Update the total payment mode name
      } else {
          console.error('Element with ID "payment_mode_display" does not exist in the DOM.');
      }
      if (selectedPaymentModeId) {
          $.ajax({
              url: url,
              method: 'GET',
              success: function(response) {
                  if (response.status === 200) {
                      PaymentOptionData = response.data;
                      generatePaymentDynamicFields(selectedPaymentModeId, selectedPaymentModeName);
                  } else {
                      console.error('Error:', response.message);
                  }
              },
              error: function(error) {
                  console.error('Error fetching payment options:', error);
              }
          });
      } else {
          $('#dynamic_fields_payment').empty();
      }
      $('#payment_mode_display_hidden').val(totalPaymentModeElement.textContent);
  }
  
   let fieldLabels = {}; // Global object to store field mappings
  
   function generatePaymentDynamicFields(paymentModeId, paymentModeName) {
    $('#dynamic_fields_payment').empty();
    fieldLabels = {}; // Reset labels
    // Add the dynamic label
    const dynamicLabelHtml = `<label class="col-lg-12 mb-2 fs-5 fw-bold text-black">${paymentModeName} Details</label>`;
    $('#dynamic_fields_payment').append(dynamicLabelHtml);

    // Check if the payment amount field already exists
    if (!document.getElementById('payment_amount')) {
        const paidAmountFieldHtml = `
            <div class="field-container col-lg-4 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Paid Amount <span class="text-danger">*</span></label>
                <input type="text" name="payment_amount" id="payment_amount" class="form-control payment_amount" placeholder="Enter Amount" oninput="this.value = this.value.replace(/[^0-9]/g, '');" min="1" required>
                <div id="paid_amount_err" class="text-danger mt-1"></div> <!-- Error message container -->
            </div>
             <div class="field-container col-lg-4 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Receipt ID <span class="text-danger">*</span></label>
                <input type="text" name="receipt_id" id="receipt_id" class="form-control receipt_id " required placeholder="Enter Receipt ID" oninput="this.value = this.value.replace(/[^0-9,]/g, '');" min="1" required>
                <div id="receipt_id_err" class="text-danger mt-1"></div> <!-- Error message container -->
            </div>`;
        $('#dynamic_fields_payment').append(paidAmountFieldHtml);
        console.log('Payment amount input field appended');
    }

    const paymentModeOptions = PaymentOptionData.filter(option => option.payment_mode_id == paymentModeId);
    const fieldsWithoutDepends = paymentModeOptions.filter(option => option.is_depends == 0);
    const fieldsWithDepends = paymentModeOptions.filter(option => option.is_depends == 1);

    function createField(option) {
        const isMandatory = option.is_mandatory == 1 ? '<span class="text-danger">*</span>' : '';
        const fieldOptions = option.field_option || [];
        const fieldName = option.field_name || '';
        const fieldValue = option.field_value || '';
        fieldLabels[`field_${option.payment_mode_option_id}`] = fieldName; // Store field mapping
        const dependsOn = option.depends_on ? JSON.stringify(option.depends_on) : "[]";
        console.log('LabelName:', fieldName);
        const oldFieldValue = oldStepDataPay['field_' + option.payment_mode_option_id] || '';
        const oldRadioValue = oldStepDataPay['radio_' + option.payment_mode_option_id] || '';

        let html = `<div class="field-container col-lg-4 mb-3" data-depends='${dependsOn}'>
                        <label class="text-dark mb-1 fs-6 fw-semibold">${fieldName} ${isMandatory}</label>`;

        if (fieldValue === 'list_box') {
            html += `<select class="select3 form-select" id="field_${option.payment_mode_option_id}" name="field_${option.payment_mode_option_id}">
                        <option value="">Select ${fieldName}</option>`;
            fieldOptions.forEach(opt => {
                html += `<option value="${opt.value}" ${opt.value == oldFieldValue ? 'selected' : ''}>${opt.label}</option>`;
            });
            html += `</select>`;
        } else if (fieldValue === 'text_field') {
            html += `<input type="text" class="form-control" placeholder="Enter ${fieldName}" id="field_${option.payment_mode_option_id}" name="field_${option.payment_mode_option_id}" value="${oldFieldValue}">`;
        } else if (fieldValue === 'text_area') {
            html += `<textarea class="form-control" rows="1" placeholder="Enter ${fieldName}" id="field_${option.payment_mode_option_id}" name="field_${option.payment_mode_option_id}">${oldFieldValue}</textarea>`;
        } else if (fieldValue === 'date_field') {
            html += `<input type="text" class="form-control common_date_class" placeholder="Enter ${fieldName}" id="field_${option.payment_mode_option_id}" name="field_${option.payment_mode_option_id}" value="${oldFieldValue}">`;
        } else if (fieldValue === 'multiple_images') {
            html += `<textarea class="form-control" placeholder="Enter ${fieldName}" id="field_${option.payment_mode_option_id}" name="field_${option.payment_mode_option_id}">${oldFieldValue}</textarea>`;
        } else if (fieldValue === 'radio_button') {
            fieldOptions.forEach((opt, index) => {
                // Set the default checked state for the first radio button if no previous value exists
                const isChecked = opt.value == oldRadioValue || (oldRadioValue === '' && index === 0) ? 'checked' : '';
                html += `<div class="form-check">
                            <input class="form-check-input" type="radio" name="radio_${option.payment_mode_option_id}" id="radio_${option.payment_mode_option_id}_${opt.value}" value="${opt.value}" ${isChecked}>
                            <label class="form-check-label" for="radio_${option.payment_mode_option_id}_${opt.value}">${opt.label}</label>
                        </div>`;
            });
        }

        html += `</div>`;
        return html;
    }

    let fieldContainerHtml = '<div class="row">';
    fieldsWithoutDepends.forEach(option => {
        const html = createField(option);
        fieldContainerHtml += html;
    });

    fieldsWithDepends.forEach(option => {
        const html = createField(option);
        fieldContainerHtml += html;
    });

    fieldContainerHtml += '</div>';
    $('#dynamic_fields_payment').append(fieldContainerHtml);

    $('.select3').select2({
        width: '100%'
    });

    // Attach change event listener to dynamically generated fields
    $('#dynamic_fields_payment').on('input change', 'input[type="text"]', updateFees);
    $('#dynamic_fields_payment').on('change', 'select', handleDependencyChange);
    $('#dynamic_fields_payment').on('change', 'input[type="radio"]', handleDependencyChange);

    handleDependencyChange();

    // Initial call to update the fees based on default values
    updateFees();
  }



   function handleDependencyChange() {
      $('#dynamic_fields_payment').find('.field-container').each(function() {
          const dependsOn = $(this).data('depends');
          const dependsOnArray = safelyParseJSONPayment(dependsOn);

          let showField = dependsOnArray.length === 0;

          for (const dependency of dependsOnArray) {
              const dependencyField = $(`#field_${dependency.value}`);
              const dependencyFieldRadio = $(`input[name='radio_${dependency.value}']:checked`);

              let dependencyFieldValue;
              if (dependencyField.length) {
                  dependencyFieldValue = dependencyField.val();
              } else if (dependencyFieldRadio.length) {
                  dependencyFieldValue = dependencyFieldRadio.val();
              }

              if (dependencyFieldValue == dependency.value) {
                  showField = true;
                  break;
              }
          }

          if (showField) {
              $(this).show();
          } else {
              $(this).hide();
          }
      });
  }

   $(document).ready(function() {
      fetchPaymentOption();
      $('#payment_modes_container').on('change', 'input[name="payment_mode_id"]', handlePaymentModeChange);
  });
  
     function updateFees() {
        // let gstRate = 0.18;
        let gstRate = {{ $branch_data->gst_percentage }} / 100;
        let initialFee = parseFloat(document.getElementById('intern_total_payment').textContent.replace(/,/g, '')) || 0;

        const balanceElement = document.getElementById('intern_balance_payment');
        let finalAmount = 0; // Declare finalAmount in a broader scope

        if (balanceElement) {
            console.log('balance-amount element exists');
             finalAmount = balanceElement.textContent.replace(/₹|,/g, '').trim();
            console.log(finalAmount);
        } else {
            console.log('balance-amount element not found');
        }

        let totalAmountEntered = 0;

        // Get entered amount
        const paidAmount = parseFloat(document.getElementById('payment_amount').value) || 0;
        if (isNaN(paidAmount)) paidAmount = 0;
        totalAmountEntered += paidAmount;
          console.log(paidAmount);
        const paidAmountErr = document.getElementById('paid_amount_err');
        const initialFeePaidBtn = document.getElementById('initial_fee_paid');
        // Validation: Show error if paidAmount exceeds finalAmount
        if (paidAmount > finalAmount) {
            paidAmountErr.textContent = 'Paid amount cannot exceed the final fee!';
            initialFeePaidBtn.classList.add('d-nones'); // Hide button
            return;
        } else {
            paidAmountErr.textContent = ''; // Clear error
        }
        
        // Show or hide the button based on range
        if (paidAmount > 100 && paidAmount <= finalAmount) {
            initialFeePaidBtn.classList.remove('d-nones'); // Show button
        } else {
            initialFeePaidBtn.classList.add('d-nones'); // Hide button
        }

        // Update the balance fees
        // let balanceFees = initialFee - totalAmountEntered;
        // let balanceFeesgst = balanceFees * gstRate;
        // let balanceFeesgstwith = balanceFees + balanceFeesgst;

        // // Update the balance fee elements
        // document.getElementById('balance_fees').textContent = balanceFees.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        // document.getElementById('balance_fees_gst').textContent = balanceFeesgst.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        // document.getElementById('balance_fees_gst_with').textContent = balanceFeesgstwith.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

        // Hide the payment div if balance fees is 0
        // const paymentDiv = document.getElementById('payment_div'); // Make sure to assign the correct ID to your div
        // if (balanceFees <= 0) {
        //     paymentDiv.classList.add('d-nones'); // Hide the div when balance is 0
        // } else {
        //     paymentDiv.classList.remove('d-nones'); // Show the div when balance is not 0
        // }

        // Calculate GST and totals
        const gstAmount = (paidAmount * gstRate); // Calculate GST
        const subTotal = paidAmount <?php echo ($branch_data->gst_check == 1) ? '- gstAmount' : ''; ?>;
        const grandTotal = subTotal + gstAmount; // Grand Total is Sub Total + GST

        // Update the values in the DOM
        document.getElementById('sub_total').textContent = subTotal.toFixed(2);
        document.getElementById('sub_total_gst').textContent = gstAmount.toFixed(2);
        document.getElementById('grand_total').textContent = grandTotal.toFixed(2);
        document.getElementById('paid_payment_display').textContent = paidAmount.toFixed(2);
    }
    
     function validateInput(input) {
      // Remove all non-numeric characters except the decimal point
      input.value = input.value.replace(/[^0-9.]/g, '');

      // Ensure only one decimal point
      input.value = input.value.replace(/(\..*)\./g, '$1');

      // Limit to 5 characters
      if (input.value.length > 1) {
          input.value = input.value.slice(0, 1);
      }

      // Optional: Validate that the value is a valid number (e.g., not just ".")
      if (input.value.startsWith('.')) {
          input.value = '0' + input.value;
      }
    }
    
     function updatePayment() {
      let initialFee = parseFloat(document.getElementById('intern_total_payment').textContent.replace(/,/g, '')) || 0;
       let pay_amount = parseFloat(document.getElementById('paid_payment_display').textContent.replace(/,/g, '')) || 0;
        const payment = document.getElementById('intern_sno_display').value;
         let paymentMode = document.getElementById('payment_mode_display_hidden').value || '';
         
        // Calculate total amount entered from dynamic fields
        let totalAmountEntered = 0;
         let reciptid = ''; // Initialize as empty or appropriate type
        let transactionAll = {}; // Object to store all transaction data

          // Loop through all dynamic fields
            $('#dynamic_fields_payment input, #dynamic_fields_payment select, #dynamic_fields_payment textarea').each(function () {
                let fieldName = $(this).attr('name');
                let fieldValue = $(this).val();
                if ($(this).attr('type') === 'radio' && !$(this).is(':checked')) {
                    return; // Skip unchecked radio buttons
                }
                if (fieldName) {
                    transactionAll[fieldName] = fieldValue;
                }
            });
            $('#dynamic_fields_payment input[type="text"]').each(function() {
                let amount = parseFloat($(this).val().replace(/,/g, '')) || 0;
                if (isNaN(amount)) amount = 0;
                totalAmountEntered += amount;
            });
            // recipt_id
             $('#dynamic_fields_payment .receipt_id').each(function () {
                reciptid = $(this).val(); // Correctly get the value from input field
            });
            let balanceFees = initialFee - totalAmountEntered;
            let invoice_id = $('#invoice_id').val();
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        let formattedTransactionAll = {};
        var subtotal = parseFloat(document.getElementById('sub_total').textContent.replace(/,/g, '')) || 0;
        var gst_type = <?php echo ($branch_data->gst_check == 1) ? '1' : '0'; ?>;
        var gst_per  = <?php echo $branch_data->gst_percentage??0; ?>;
        var gst_amount  = parseFloat(document.getElementById('sub_total_gst').textContent.replace(/,/g, '')) || 0;
         Object.keys(transactionAll).forEach(key => {
            const label = fieldLabels[key] || key; // Use mapped label if availabl
             formattedTransactionAll[label] = transactionAll[key];
            
         });
         formattedTransactionAll['subtotal'] = subtotal;
         formattedTransactionAll['gst_type'] = gst_type;
         formattedTransactionAll['gst_per'] = gst_per;
         formattedTransactionAll['gst_amount'] = gst_amount;
         
         console.log('formattedTransactionAll',formattedTransactionAll);
         
        fetch(`/payment_update/${payment}`, {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                body: JSON.stringify({
                  pay_amount: pay_amount,
                  total_amount_entered: totalAmountEntered,
                  reciptid: reciptid,
                  payment_mode: paymentMode,  // Include payment mode
                  transaction_all: formattedTransactionAll // Include all dynamic transaction fields

                }),
            })

            .then(data => {
                if (data.status === 200) {
                  console.log(data)
                    toastr.success('Payment Updated successfully!');
                    location.reload();
                } else {
                    toastr.error('Payment Failed to update!');
                }
            })
            .catch(error => {
                console.error('Error updating Payment:', error);

            });
    }

    document.getElementById('confirm_update_button').addEventListener('click', function() {
        updatePayment();
    });
</script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    $(document).ready(function() {
        $(".certificate_issue_date").datepicker({ format: "dd-M-yyyy", autoclose: true, todayHighlight: true }).datepicker("setDate", new Date());
        $(".start_date_edit").datepicker({ format: "dd-M-yyyy", autoclose: true, todayHighlight: true }).datepicker("setDate", new Date());
        
        $(".end_date_edit").datepicker({ format: "dd-M-yyyy", autoclose: true, todayHighlight: true }).datepicker("setDate", new Date());
    });
    $(document).ready(function () {
        $('#edit_submit_button').on('click', function (e) {
            e.preventDefault();
    
            // Clear previous error messages
            $('.text-danger').text('');
    
            let isValid = true;
    
            const fields = [
                { id: 'college_id_edit', name: 'College' },
                { id: 'topic_name_edit', name: 'Topic Name' },
                { id: 'payment_edit', name: 'Payment' },
                { id: 'hold_st_date', name: 'Start Date' },
                { id: 'end_date_edit', name: 'End Date' },
                { id: 'staff_id_edit', name: 'Staff' },
                { id: 'intern_name_edit', name: 'Intern Name' },
                { id: 'intern_email_edit', name: 'Intern Email Id' },
                { id: 'intern_mobile_editt', name: 'Intern Mobile No' },
            ];
    
            fields.forEach(field => {
                const value = $('#' + field.id).val();
                if (!value || value.trim() === '') {
                    $('#'+ field.id + '_err').text(`${field.name} is required`);
                    isValid = false;
                }
            });
    
            if (isValid) {
                // Proceed to AJAX update function or form submissio
                updateInternData();
            }
        });
    });
    function updateInternData() {
        const formData = {
            sno: $('#sno_edit').val(),
            college_id: $('#college_id_edit').val(),
            topic_name: $('#topic_name_edit').val(),
            payment: $('#payment_edit').val(),
            start_date: $('.start_date_edit').val(),
            end_date: $('.end_date_edit').val(),
            staff_id: $('#staff_id_edit').val(),
            intern_name: $('#intern_name_edit').val(),
            intern_email: $('#intern_email_edit').val(),
            intern_mobile: $('#intern_mobile_editt').val(),
            college_to: $('#college_to_edit').val(),
            _token: '{{ csrf_token() }}' // important for Laravel CSRF protection
        };
    
        $.ajax({
            url: "{{ route('update_intern') }}", // replace with your actual update route
            type: "POST",
            data: formData,
            success: function(response) {
                if (response.status === 'success') {
                    toastr.success('Intern updated successfully!');
                    $('#kt_modal_edit_intern').modal('hide');
                    location.reload();
                    // Optionally refresh your intern list or table here
                } else {
                    toastr.error(response.message || 'Failed to update intern.');
                }
            },
            error: function(xhr) {
                toastr.error('Server error. Please try again.');
                console.error(xhr.responseText);
            }
        });
    }


    function loadDropdownsAndSetValues(data) {
        // Fetch Colleges
        $.ajax({
            url: "{{ route('College') }}",
            type: 'GET',
            success: function (response) {
               
                const collegeSelect = $('select[name="college_id_edit"]');
                collegeSelect.empty();
                collegeSelect.append('<option value="">Select College</option>');
    
                response.data.forEach(college => {
                     console.log(college.sno, college.college_name);
                    collegeSelect.append(`<option value="${college.sno}">${college.college_name}</option>`);
                });
               console.log("Setting college_id to:", data.college_id);
                // Select after initializing
                setTimeout(() => {
                    collegeSelect.val(data.college_id).trigger('change.select2');
                }, 200);
            },
            error: function () {
                console.error('Error fetching college data');
            }
        });
        
         // Fetch Staff list and populate dropdown
        $.ajax({
            url: "{{ route('topic') }}",  // Endpoint for Staff list url: "{{ route('topic') }}",
            type: 'GET',
            success: function (response) {
                const staffSelect = $('select[name="topic_name_edit"]');
                staffSelect.empty(); // Clear existing options
                staffSelect.append('<option value="">Select Topic</option>'); // Default option
    
                // Loop through the data and append options to the select element
                response.data.forEach(topic => {
                    staffSelect.append(`<option value="${topic.sno}">${topic.title}</option>`);
                });
                 setTimeout(() => {
                    staffSelect.val(data.topic).trigger('change.select2');
                }, 200);
            },
            error: function () {
                console.error('Error fetching Topic data');
            }
        });
    
        // Fetch Staff
        var branch = {{ auth()->user()->branch_id }}; // PHP value embedded into JS
            $.ajax({
                url: "/staff_list_by_branch_id/" + branch, // Build the URL dynamically in JS
            type: 'GET',
            success: function (response) {
                const staffSelect = $('select[name="staff_id_edit"]');
                staffSelect.empty();
                staffSelect.append('<option value="">Select Staff</option>');
    
                response.data.forEach(staff => {
                    staffSelect.append(`<option value="${staff.sno}">${staff.staff_name} - ${staff.job_position_name}</option>`);
                });
    
                setTimeout(() => {
                    staffSelect.val(data.staff_id).trigger('change.select2');
                }, 200);
            },
            error: function () {
                console.error('Error fetching staff data');
            }
        });
    }
    
    function populateUpdateModal(data) {
        $('#intern_name_edit').val(data.intern_name);
        $('#intern_email_edit').val(data.intern_email);
        $('#intern_mobile_editt').val(data.intern_mobile);
        $('#college_to_edit').val(data.college_to);
        $('#topic_name_edit').val(data.topic);
        $('#payment_edit').val(data.payment);
        $('.start_date_edit').val(data.start_date);
        $('.end_date_edit').val(data.end_date);
        $('#sno_edit').val(data.sno);
        console.log(data);
        loadDropdownsAndSetValues(data);
    }



    // Function to show full image in modal
    function showFullImage(imageUrl) {
        document.getElementById('fullImage').src = imageUrl;
        new bootstrap.Modal(document.getElementById('imageModal')).show();
    }
    
    function showFullTextAvatar(letter, bgColor) {
        let encodedSvg = encodeURIComponent(`
            <svg xmlns="http://www.w3.org/2000/svg" width="400" height="400">
                <rect width="100%" height="100%" fill="${bgColor}"/>
                <text x="50%" y="50%" font-size="150" fill="white" font-family="Arial" text-anchor="middle" dy=".3em">${letter}</text>
            </svg>
        `);
    
        let dataUrl = `data:image/svg+xml,${encodedSvg}`;
    
        document.getElementById('fullImage').src = dataUrl;
        new bootstrap.Modal(document.getElementById('imageModal')).show();
    }
    function fsc_sts_func(val) {

        if (val == "reject") {
            document.getElementById("rejct_tbox").style.display = "block";
            document.getElementById("smt_butt").innerHTML = "Rejected";
        } else if (val == "accept") {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        } else {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        }
    }
</script>
<script>

  function viewCustomerDetails(customerId) {
    // Fetch customer and payment details based on customerId
    $.ajax({
      url: '/get_customer_details/' + customerId,
      method: 'GET',
      success: function(response) {
        // Inject customer details into the modal
        let customerDetails = `
        <div class="customer-info">
          <div class="row">
            <div class="col-12 col-md-6">
              <div class="info-item">
                <span class="info-label"><i class="mdi mdi-account fs-5"></i> <strong>Name:</strong></span>
                <span class="info-value">${response.customer.cus_name}</span>
              </div>
            </div>
            <div class="col-12">
              <div class="info-item">
                <span class="info-label"><i class="mdi mdi-phone-in-talk fs-5"></i> <strong>Mobile:</strong></span>
                <span class="info-value">${response.customer.cus_mobile}</span>
              </div>
            </div>
          </div>
        </div>
      `;

        // Extract payment details from response.payments array
       let totalFees = parseFloat(response.payments[0]?.total_amount || 0);
        let paidFees = 0;

        // Loop through payments array and sum up the total and paid fees
        response.payments.forEach(payment => {
            paidFees += parseFloat(payment.paidAmount || 0);
        });

        // Calculate balance fees
        let balanceFees = totalFees - paidFees;

       let paymentsDetails = `
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex flex-wrap gap-3 mt-2">
                    <span class="badge bg-info rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Total Fees:</strong>
                        <i class="mdi mdi-currency-rupee"></i> ${totalFees.toFixed(2)}
                    </span>
                    <span class="badge bg-success rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Paid Fees:</strong>
                        <i class="mdi mdi-currency-rupee"></i> ${paidFees.toFixed(2)}
                    </span>
                    <span class="badge bg-danger rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Balance Fees:</strong>
                        <i class="mdi mdi-currency-rupee"></i> ${balanceFees.toFixed(2)}
                    </span>
                </div>
            </div>
        </div>
    `;





        $('#customer-details').html(customerDetails);
        $('#customer-payments').html(paymentsDetails);
        let paymentRows = '';
        $.each(response.payments, function(index, payment) {
          const gstPercentage = parseFloat(response.gstPercentage) || 0;  // Ensure valid GST percentage

          // Calculate GST and totals once for reuse
          const courseFeeGST = parseFloat(payment.amount) * gstPercentage;
          const totalCourseFee = parseFloat(payment.amount) + courseFeeGST;

          const paidAmountGST = parseFloat(payment.paidAmount) * gstPercentage;
          const totalPaidAmount = parseFloat(payment.paidAmount) + paidAmountGST;

          const balanceFeeGST = parseFloat(payment.balanceFee) * gstPercentage;
          const totalBalanceFee = parseFloat(payment.balanceFee) + balanceFeeGST;

          // Start building payment row
          paymentRows += '<tr>';

          // Display the initial payment date
          paymentRows += '<td>' + payment.initialPayDate + '</td>';

          // Display next payment date with tooltip for maximum due date
          paymentRows += `<td>
            <div class="d-block mt-1">
              <label class="badge bg-label-danger fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Maximum Due Date">
                ${payment.nextPayDate}
              </label>
            </div>
          </td>`;

          // Display scheduled fees with currency and GST
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Fees">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.amount).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 "><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${courseFeeGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <label class="badge bg-info rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Fees">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalCourseFee.toFixed(2)}</span>
              </label>
            </div>
          `;
          paymentRows += '</td>';

          // Display paid fees with GST calculation
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Fees">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.paidAmount).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${paidAmountGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <label class="badge bg-success rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Fees">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalPaidAmount.toFixed(2)}</span>
              </label>
            </div>
          `;
          paymentRows += '</td>';

          // Display balance fees with GST calculation
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Fees">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.balanceFee).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${balanceFeeGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <label class="badge bg-danger rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Fees">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalBalanceFee.toFixed(2)}</span>
              </label>
            </div>
          `;
          paymentRows += '</td>';

          // Status column (Paid or Pending)
          paymentRows += `<td>
            ${payment.status == 1 ?
              '<label class="badge bg-success text-black fw-semibold fs-6">Paid</label>' :
              '<label class="badge bg-danger fw-semibold fs-6">Pending</label>'
          }</td>`;

          paymentRows += '</tr>';
        });
        $('#payment-table-body-model').html(paymentRows);
      }
    });
  }

</script>
<style>
.btn-red-pay:hover {
    filter: brightness(1.1);
    transform: scale(1.05);
}
    #course {
        /* background-image: linear-gradient(to bottom, #1397c7, #007fbe, #0066b3, #004da4, #11318f); */
        background: rgb(13, 214, 80);
        background: linear-gradient(90deg, rgba(13, 214, 80, 1) 0%, rgba(64, 121, 9, 1) 35%, rgba(134, 255, 0, 1) 100%);
    }
    .txt_vertical {
      writing-mode: vertical-lr;
      transform: rotate(180deg);
    }
    .select_dropdown {
            z-index: 9999 !important; /* Ensure it is higher than the modal's z-index */
        }
</style>
<style>


    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: rgb(196, 3, 3);
    }
    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
     .payment-btn.notify {
        position: relative;
        animation: pulseOuter 1.5s infinite; /* Outer pulse effect */
        border: 2px solid red; /* Red border to indicate urgency */
        border-radius: 50%;
        overflow: hidden;
    }

    .payment-btn.notify i {
        color: white; /* Ensure inner icon is visible */
        /* background: radial-gradient(circle, #ffcccc 0%, #ff9999 70%, transparent 100%); */
        border-radius: 50%; /* Make the icon circular */
        animation: pulseInner 1.5s infinite; /* Inner subtle glow */
    }

    /* Outer pulse animation */
    @keyframes pulseOuter {
        0% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }
        50% {
            box-shadow: 0 0 30px rgba(255, 0, 0, 1);
            transform: scale(1.1);
        }
        100% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }
    }

    /* Inner subtle glow animation */
    @keyframes pulseInner {
        0% {
            transform: scale(1);
            opacity: 1;
        }
        50% {
            transform: scale(1.1);
            opacity: 0.7;
        }
        100% {
            transform: scale(1);
            opacity: 1;
        }
    }
</style>
<script>
  // Display Toastr messages
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
  toastr[type](message);
  @endif
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
    $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.customer_tbox').slideToggle('fast');
                $('.filter_tbox').slideToggle('fast');
                // });
            @endif
        });
</script>






<script>
    $(".list_page").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
</script>
<script>
  $(".list_page2").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
</script>
<script>
    function sort_filter(val) {
      if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
      } else {
        $('.sorting_filter_class').val(10);
        $('#search_form').submit();
      }
    }
  </script>
@endsection
