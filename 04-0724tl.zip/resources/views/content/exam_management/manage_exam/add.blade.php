@extends('layouts/layoutMaster')

@section('title', 'Create Exam')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<!-- Staff Add -->
<div class="card mb-2">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Exam</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                            class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Exam Management</a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Exam</a>
                </li>
            </ol>
        </nav>
    </div>
</div>

<!-- Question Bank Basic Information -->
<div class="card mb-2 px-4 py-2">
    <form action="{{ route('manage_exam_create') }}" method="POST" id="add_exam_form">
        @csrf
        <div class="row">
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Exam Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control title_case" placeholder="Enter Exam Name" name="exam_name" id="exam_name" maxlength="80" />
                <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Exam Level<span class="text-danger">*</span></label>
                <select class="select3 form-select" name="level_id" id="level_id" onchange="questionGeneration(this.value)">
                    <option value="">Select Question Level</option>
                    <option value="0">Beginner</option>
                    <option value="1">Intermediate</option>
                    <option value="2">Expert</option>
                </select>
                <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Question Bank<span class="text-danger">*</span></label>
                <select class="select3 form-select" name="question_bnk_id[]" id="question_bnk_id" multiple data-placeholder="Select Question Bank" onchange="fetchQuestionBank()">
                    <option value="">Select Question Bank</option>
                    <!-- AJAx WIll Populate Here -->
                </select>
                <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                <select class="select3 form-select" name="role_id[]" id="role_id" multiple data-placeholder="Select Job Role"  onchange="fetchExamSchedules()">
                    <!-- AJAx WIll Populate Here -->
                </select>
                <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Exam Schedule<span class="text-danger">*</span></label>
                <select class="select3 form-select" data-placeholder="Select Exam Schedule" name="schedule_id" id="schedule_id">
                    <!-- AJAX Will Populate Here -->
                </select>
                <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Question Count<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Question Count" name="question_count" id="question_count" maxlength="3" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Duration (In Minutes)<span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Duration (In Minutes)" name="duration" id="duration" maxlength="3" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Positive Mark Per Question<span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Positive Mark Per Question" name="pst_mark" id="pst_mark" maxlength="3" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Negative Mark Per Question<span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Negative Mark Per Question" name="ngt_mark" id="ngt_mark" maxlength="3" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
            </div>
            
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Exam Attempt<span class="text-danger">*</span></label>
                <div class="d-flex align-items-center mt-1">
                    <div class="form-check form-check-inline me-3">
                        <input class="form-check-input" type="radio" id="unlt_id_add_chk" name="exam_attempt"
                            value="0" checked onchange="badgeHideShow(this.value)" />
                        <label for="unlt_id_add_chk" class="text-black mb-1 fs-6 fw-semibold">Trial</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" id="not_id_add_chk" name="exam_attempt" value="1" onchange="badgeHideShow(this.value)" />
                        <label for="not_id_add_chk" class="text-black mb-1 fs-6 fw-semibold">Limited</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 mb-3" id="no_of_attempt_tbox" style="display: none;">
                <label class="text-black mb-1 fs-6 fw-semibold">No. of Attempt<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter No. of Attempt" name="attempts" id="attempts" maxlength="3" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
            </div>

            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Pass Mark<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Pass Mark" name="pass_mark" id="pass_mark" maxlength="3" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/^(\d{10})\d*/, '$1');" />
                <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
            </div>

            

            <div class="col-lg-4 mb-3" id="badge-hide-conatiner" style="display: none;">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="badge_check" id="showAsteriskCheckbox" onclick="toggleAsterisk()" />
                    <label class="text-black fs-6 fw-semibold" id="toggleBadge">
                        Badge <span class="text-danger" style="display:none" id="requiredMark">*</span>
                    </label>
                </div>
                <div style="display:none" id="show_upload">
                    <select class="select3 form-select" name="badge" id="badge">
                    </select>
                    <div class="error_msg text-danger mt-1 fs-7 fw-semibold"></div>
                </div>
            </div>

            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Question Generate<span class="text-danger">*</span></label>
                <div class="d-flex align-items-center mt-1">
                    <div class="form-check form-check-inline me-3">
                        <input class="form-check-input" type="radio" name="trail" value="0" checked />
                        <label class="text-black mb-1 fs-6 fw-semibold">Random</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="trail" value="1" />
                        <label class="text-black mb-1 fs-6 fw-semibold">Sequence</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="detailed_view" name="detailed_view" value="1" />
                    <label class="text-black fs-6 fw-semibold" for="detailed_view">Detailed View</label>
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="IsCertificate" name="IsCertificate" value="1" />
                    <label class="text-black fs-6 fw-semibold" for="IsCertificate">Certificate</label>
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="tips_check" name="tips_check" />
                    <label class="text-black fs-6 fw-semibold" for="tips_check">
                        Tips
                    </label>
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="explanation_check" name="explanation_check" />
                    <label class="text-black fs-6 fw-semibold" for="explanation_check">
                        Explanation
                    </label>
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="case_study_check" name="case_study_check" />
                    <label class="text-black fs-6 fw-semibold" for="case_study_check">
                        Case Study
                    </label>
                </div>
            </div>
            <input type="hidden" name="selected_questions" id="selected_questions" />
            <div class="col-lg-4 mb-3 d-flex justify-content-start align-items-center">
                <label class="text-black bg-warning px-3 py-2 fs-5 fw-bold rounded shadow-sm checked-count"
                    style="min-width: 50px; text-align: center;">
                    00
                </label>
            </div>
            <div class="col-lg-4">
                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                <textarea class="form-control" rows="1" placeholder="Enter Description" name="exam_desc" id="exam_desc"></textarea>
            </div>
        </div>
        <div class="row py-2 mb-2 mt-4">
            <div class="row" id="question-container"></div>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-4 mb-4">
            <a href="{{url ('/manage_exam')}}" class="btn btn-secondary me-3">Cancel</a>
            <a href="#" class="btn btn-primary" data-bs-toggle="modal" onclick="addValidation(event)">Create
                Exam</a>
        </div>
    </form>
</div>
<!-- End  Question Bank Basic Information -->

<!--begin::Modal - Confirmation Staff-->
<div class="modal fade" id="kt_modal_confirmation_create_exam" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                Create Exam ?
                <div class="d-block fw-bold fs-5 py-2">
                    <label id="create_exam_modal" class="text-danger fw-bold">Thesis Writing Service</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <a href="javascript:;" onclick="submitForm()" class="btn btn-primary me-3">Yes</a>
                <a href="#" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Confirmation Staff-->

<!-- Trial/Limited Hide and Show -->
<script>
    $('input:radio[name="exam_attempt"]').change(function() {
        var no_of_attempt_tbox = document.getElementById("no_of_attempt_tbox");

        if ($(this).val() == 1) {
            no_of_attempt_tbox.style.display = "block";
        } else {
            no_of_attempt_tbox.style.display = "none";
        }
    });
</script>

<!-- Badge Hide and Show and Data Fetch -->
<script>
    function toggleAsterisk() {
        const checkbox = document.getElementById('showAsteriskCheckbox');
        const asterisk = document.getElementById('requiredMark');
        const uploadDiv = document.getElementById('show_upload');

        if (checkbox.checked) {
            asterisk.style.display = 'inline';
            uploadDiv.style.display = 'block';
        } else {
            asterisk.style.display = 'none';
            uploadDiv.style.display = 'none';
        }

        $.ajax({
            url: `/list_exam_badge`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response && response.status === 200) {
                    const badges = response.data;
                    const badgeId = $('#badge');
                    badgeId.empty();

                    if(badges && badges.length > 0) {
                        badgeId.append(
                            `<option value="">Select Badge</option>`
                        );

                        badges.forEach(badge => {
                            badgeId.append(
                                `<option value="${badge.sno}">${badge.badge_name}</option>`
                            );
                        });
                    }

                } else {
                    console.log('Data Fetching Failed !')
                }
            },
            error: function (err) {
                console.error('Data Fetching Failed !');
            }
        });
    }
</script>

<script>
    // ✅ Make this function global (accessible from other scripts)
    function updateTotalCheckedCount() {
        const checkedCountLabel = document.querySelector('.checked-count');
        const selectedQuestions = document.getElementById('selected_questions');

        let total = 0;
        document.querySelectorAll('.section-checkbox:checked').forEach(cb => {
            total += parseInt(cb.getAttribute('data-question-count')) || 0;
        });

        checkedCountLabel.textContent = total.toString().padStart(2, '0');
        selectedQuestions.value = total;
    }

    document.addEventListener('DOMContentLoaded', () => {
        const container = document.getElementById('question-container');

        // Use event delegation for dynamically added checkboxes
        container.addEventListener('change', function (e) {
            if (e.target.classList.contains('section-checkbox')) {
                updateTotalCheckedCount();
            }
        });

        // Initialize if any pre-checked
        updateTotalCheckedCount();
    });
</script>

<!-- Fetch Job Roles -->
<script>
    $(document).ready(function () {
        $.ajax({
            url: `/fetch_job_roles`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response && response.status === 200) {
                    const roles = response.data;
                    const roleId = $('#role_id');
                    roleId.empty();

                    if(roles && roles.length > 0) {
                        roleId.append(`<option value="all">All</option>`);

                        roles.forEach(role => {
                            roleId.append(
                                `<option value="${role.sno}">${role.role_name}</option>`
                            );
                        });
                    }

                    // Exclusive selection: either "All" or specific roles, not both
                    roleId.on('change', function() {
                        const selectedValues = $(this).val();
                        
                        if (!selectedValues) return;
                        
                        const hasAll = selectedValues.includes('all');
                        const hasOtherRoles = selectedValues.some(val => val !== 'all');
                        
                        if (hasAll && hasOtherRoles) {
                            // If both "all" and other roles are selected, keep only "all"
                            $(this).val(['all']).trigger('change');
                        }
                    });

                } else {
                    console.log('Data Fetching Failed !')
                }
            },
            error: function (err) {
                console.error('Data Fetching Failed !');
            }
        });
    });
</script>

<!-- Exam Schedule Fetch -->
<script>
    function fetchExamSchedules() {
        $.ajax({
            url: `/list_job_role_schedule`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response && response.status === 200) {
                    const schedules = response.data;
                    const scheduleId = $('#schedule_id');
                    scheduleId.empty();

                    if(schedules && schedules.length > 0) {
                        scheduleId.append(
                            `<option value="">Select Exam schedules</option>`
                        );

                        schedules.forEach(schedule => {
                            scheduleId.append(
                                `<option value="${schedule.sno}">${schedule.schedule_name} - ( ${schedule.duration} ${schedule.unit} ) </option>`
                            );
                        });
                    }

                } else {
                    console.log('Data Fetching Failed !')
                }
            },
            error: function (err) {
                console.error('Data Fetching Failed !');
            }
        });
    }
</script>

<!-- Validation -->
<script>
    function addValidation(e) {
        // Prevent default form submission
        if (e) {
            e.preventDefault();
        }
        
        let isValid = true;
        const requiredFields = [
            {
                id: 'exam_name',
                msg: 'Exam Name Is Required.'
            },
            {
                id: 'level_id',
                msg: 'Exam Level Is Required.'
            },
            {
                id: 'question_bnk_id',
                msg: 'Question Bank Is Required.'
            },
            {
                id: 'role_id',
                msg: 'Job Role Is Required.'
            },
            {
                id: 'schedule_id',
                msg: 'Exam Schedule Is Required.'
            },
            {
                id: 'question_count',
                msg: 'Question Count Is Required.'
            },
            {
                id: 'duration',
                msg: 'Duration Is Required.'
            },
            {
                id: 'pst_mark',
                msg: 'Positive Mark Is Required.'
            },
            {
                id: 'ngt_mark',
                msg: 'Negative Mark Is Required.'
            },
            {
                id: 'pass_mark',
                msg: 'Pass Mark Is Required.'
            }
        ];

        // Clear all error messages first
        $('.error_msg').text('');

        // Check conditional fields
        const examAttempt = $('input[name="exam_attempt"]:checked').val();
        if (examAttempt === '1') {
            requiredFields.push({
                id: 'attempts',
                msg: 'Attempts Is Required.'
            });
        }

        const badge = $('input[name="badge_check"]').is(':checked');
        if (badge) {
            requiredFields.push({
                id: 'badge',
                msg: 'Badge Is Required.'
            });
        }

        // Validate all required fields
        requiredFields.forEach(field => {
            const input = $('#' + field.id);
            const errorDiv = input.closest('.mb-3').find('.error_msg');
            
            // Check if field is empty
            if (!input.val() || input.val().toString().trim() === '') {
                errorDiv.text(field.msg);
                isValid = false;
            }
        });

        // Only validate question count if other fields are valid
        if (isValid) {
            const hiddenInput = parseInt($('#selected_questions').val()) || 0;
            const questionCount = parseInt($('#question_count').val()) || 0;
            
            if (questionCount > hiddenInput) {
                isValid = false;
                Swal.fire({
                    icon: 'error',
                    iconColor: '#dc3545',
                    title: '<div class="fs-3 fw-bold text-danger">Selection Limit Too Low</div>',
                    html: `
                        <div class="fs-6 text-secondary">
                            You must select at least the <span class="fw-semibold text-danger">required number of questions</span>.<br>
                            Please review your selections and <span class="text-primary fw-semibold">increase the count</span> to continue.
                        </div>
                    `,
                    showConfirmButton: true,
                    confirmButtonText: 'Got it',
                    customClass: {
                        popup: 'border-start border-4 border-danger rounded-3 shadow-lg px-4 py-3',
                        confirmButton: 'btn btn-danger fw-semibold px-4',
                    },
                    buttonsStyling: false,
                });
            }
        }

        // Show confirmation modal or prevent submission
        if (isValid) {
            const modal = new bootstrap.Modal(document.getElementById('kt_modal_confirmation_create_exam'));
            modal.show();
        }
        
        return false; // Always return false to prevent form submission
    }

    function submitForm() {
        // Remove any existing validation handlers to prevent infinite loop
        $('#add_exam_form').off('submit').submit();
    }

    // Add event listener when document is ready
    $(document).ready(function() {
        $('#add_exam_form').on('submit', addValidation);
    });

    $('#exam_name').on('input', () => {
        const examName = $('#exam_name').val();
        $('#create_exam_modal').html(examName);
    });
</script>

<script>
    window.addEventListener('input', function (e) {
        if (e.target.classList.contains('title_case')) {
            e.target.value = e.target.value
                .toLowerCase()
                .replace(/\b\w/g, char => char.toUpperCase());
        }
    });
</script>
<!-- Question Bank Section Generate -->
<script>
    function questionGeneration (id) {
        $('.checked-count').text('00');
        $.ajax({
            url: `/fetch_question_bank_name/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {
                    const banks = response.data.banks;
                    var questionBankContainer = $('#question_bnk_id');
                    questionBankContainer.empty();
                    $('#question-container').empty();

                    banks.forEach(bank => {
                        questionBankContainer.append(`<option value="${bank.sno}">${bank.bank_name}</option>`);
                    });

                } else {
                    $('#question-container').html('<p class="text-danger">No Question Bank Found!</p>');
                }
            },
            error: function (err) {
                console.error('Data Fetching Failed !');
            }
        });
    }
</script>

<script>
    function fetchQuestionBank() {
        $('.checked-count').text('00');

        const ids = $('#question_bnk_id').val(); // returns an array

        if (!ids || ids.length === 0) {
            $('#question-container').html('<p class="text-muted">Select a Question Bank to view sections.</p>');
            return;
        }

        $.ajax({
            url: `/level_based_exam_questions`,
            method: 'GET',
            data: { ids: ids },
            dataType: 'json',
            success: function (response) {
                if (response.status === 200) {
                    const { banks, sections } = response.data;
                    let html = '';

                    banks.forEach(bank => {
                        const bankSections = sections[bank.sno] || [];

                        html += `
                            <div class="col-lg-4 mb-2">
                                <div class="border rounded px-3 py-3 card shadow-none h-100">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <div class="form-check">
                                            <input class="form-check-input select-all-bank" type="checkbox" id="selectAll_${bank.sno}" data-bank-id="${bank.sno}">
                                            <label class="form-check-label text-primary fs-5 fw-semibold" for="selectAll_${bank.sno}">
                                                ${bank.bank_name}
                                            </label>
                                        </div>
                                    </div>
                                    <div class="row scroll-y max-h-250px sections-container" data-bank-id="${bank.sno}">
                        `;

                        if (bankSections.length > 0) {
                            bankSections.forEach(section => {
                                html += `
                                    <div class="col-lg-12 d-flex justify-content-between align-items-center">
                                        <div class="form-check form-check-inline ms-3">
                                            <input class="form-check-input section-checkbox" type="checkbox" 
                                                name="selected_sections[]" 
                                                value="${bank.sno}_${section.section_id}" 
                                                data-bank-id="${bank.sno}" 
                                                data-question-count="${section.question_count}" />
                                            <label class="text-black mb-1 fs-6 fw-semibold">${section.section_name}</label>
                                        </div>
                                        <div>
                                            <label class="badge bg-info border border-info rounded fw-semibold text-white fs-6 py-1 px-1 cursor-pointer">
                                                ${String(section.question_count).padStart(2, '0')}
                                            </label>
                                        </div>
                                    </div>
                                `;
                            });
                        } else {
                            html += `<p class="text-danger text-center mb-0">No Sections Found</p>`;
                        }

                        html += `
                                    </div>
                                </div>
                            </div>
                        `;
                    });

                    $('#question-container').html(html);

                    // ✅ Select All toggle (with total update)
                    $('.select-all-bank').on('change', function () {
                        const bankId = $(this).data('bank-id');
                        const isChecked = $(this).is(':checked');
                        $(`.section-checkbox[data-bank-id="${bankId}"]`).prop('checked', isChecked);
                        updateTotalCheckedCount(); // ✅ now works globally
                    });
                } else {
                    $('#question-container').html('<p class="text-danger">No Question Banks Found!</p>');
                }
            },
            error: function () {
                console.error('Data Fetching Failed!');
            }
        });
    }
</script>

<!-- BADGE HIDE / SHOW -->
<script>
    function badgeHideShow (val) {
        if (val == '1') {
            $('#badge-hide-conatiner').show();
        } else {
            $('#badge-hide-conatiner').hide();
            $('#showAsteriskCheckbox').prop('checked', false);
            toggleAsterisk();
            $('#badge').val('').trigger('change');
        }
    }
</script>

@endsection