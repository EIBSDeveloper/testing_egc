@extends('layouts/layoutMaster')

@section('title', 'Manage Question Bank')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection

@section('content')
@php
$helper = new \App\Helpers\Helpers();
@endphp
<!-- Users List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Exam</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Exam Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
                <a href="/manage_exam/add" class="btn btn-sm fw-bold btn-primary text-white">
                    <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Create Exam
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                        onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form id="search_form" method="POST" action="/manage_exam">
                        @csrf
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <div>
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="0">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                    id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <input type="text" class="form-control" id="search_fill" name="search_fill"
                                    value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Exam Name</th>
                            <th class="min-w-80px">Exam Level</th>
                            <th class="min-w-80px">Question Count</th>
                            <th class="min-w-100px text-center">Duration</th>
                            <th class="min-w-80px">Status</th>
                            <th class="min-w-100px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        @foreach($lists as $list)
                        <tr>
                            <td>
                                <div class="text-truncate max-w-200px" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="{{ $list->exam_name }}">{{ $list->exam_name }}
                                </div>

                            </td>
                            <td>
                                @if($list->level_id == 0)
                                <div class="text-black">Beginner</div>
                                @elseif ($list->level_id == 1)
                                <div class="text-black">Intermediate</div>
                                @elseif ($list->level_id == 2)
                                <div class="text-black">Expert</div>
                                @endif
                            </td>
                            <td class="text-center dt-type-numeric">
                                <div
                                    class="badge bg-success border border-success rounded text-black  fs-7 fw-semibold">
                                    {{ str_pad($list->question_count, 2, '0', STR_PAD_LEFT) }}</div>
                            </td>
                            <td class="text-center">
                                <label class="badge bg-info border border-info rounded  text-white fs-7 fw-semibold">{{
                                    str_pad($list->duration, 2, '0', STR_PAD_LEFT) }} Mins</label>
                            </td>

                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" {{ $list->status == 0 ? 'checked' : ''
                                    }} onchange="statusChange('{{ $list->sno }}', this.checked)" />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                @php
                                $encryptedValue = $helper->encrypt_decrypt($list->sno,'encrypt');
                                $edit_url = url('/edit_manage_exam/' . $encryptedValue);
                                $view_url = url('/view_manage_exam/' . $encryptedValue);
                                @endphp
                                <span class="text-end">
                                    <a href="{{ $view_url }}" class="btn btn-icon btn-sm me-2"
                                        data-bs-placement="bottom" title="View">
                                        <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                                    </a>
                                    <a href="{{ $edit_url }}" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Edit">
                                        <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                    </a>
                                    <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" onclick="deleteFetch('{{ $list->sno }}', '{{ $list->exam_name }}')"
                                        data-bs-target="#kt_modal_delete_badge">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i
                                                class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                    </a>
                                </span>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $lists->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="kt_modal_delete_badge" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content kt_modal_delete_badge-content rounded-3 shadow-lg border-0">
            <!-- Modal Header with gradient background -->
            <div class="modal-header kt_modal_delete_badge-header bg-gradient-danger text-white rounded-top-3 py-4">
                <div class="d-flex align-items-center">
                    <div class="kt_modal_delete_badge-icon">
                        <i class="fas fa-exclamation-triangle fs-2 text-dark"></i>
                    </div>
                    <div>
                        <h5 class="modal-title kt_modal_delete_badge-title fw-bold mb-0"> <span id="delete_exam_name"></span> Delete Exam</h5>
                        <p class="kt_modal_delete_badge-subtitle mb-0 opacity-75">Confirm deletion of exam</p>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Modal Body -->
            <div class="modal-body kt_modal_delete_badge-body p-0" id="delete_message">
                <!-- Loading state -->
                <div class="kt_modal_delete_badge-loading text-center py-5">
                    <div class="spinner-grow text-danger" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="kt_modal_delete_badge-loading-text mt-3 text-muted">Fetching exam details...</p>
                </div>
            </div>
            <div id="Important_Notice">

            </div>

            <!-- Modal Footer -->
            <div class="modal-footer kt_modal_delete_badge-footer bg-light rounded-bottom-3 py-3">
                <button type="button" class="btn kt_modal_delete_badge-cancel-btn btn-light-primary fw-semibold px-4" data-bs-dismiss="modal">
                    <i class="mdi mdi-close-circle-outline me-2"></i>Cancel
                </button>
                <button type="button" class="btn kt_modal_delete_badge-delete-btn btn-danger fw-semibold px-4" onclick="finalDeleteExam()">
                    <i class="mdi mdi-delete-outline me-2"></i>Delete Exam
                </button>
            </div>
        </div>
    </div>
</div>

<style>
    :root {
        --kt-danger: #f1416c;
        --kt-danger-light: #fff5f8;
        --kt-primary: #009ef7;
        --kt-warning: #ffc700;
        --kt-success: #50cd89;
        --kt-info: #7239ea;
        --kt-dark: #181c32;
    }
    
    /* Custom styles for the delete modal */
    .kt_modal_delete_badge-content {
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        border: none;
        overflow: hidden;
    }
    
    .kt_modal_delete_badge-header {
        background: linear-gradient(135deg, #f5365c 0%, #f56036 100%);
        border-bottom: none;
    }
    
    .kt_modal_delete_badge-footer {
        border-top: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .kt_modal_delete_badge-icon {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .kt_modal_delete_badge-icon {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(255, 255, 255, 0.2);
        margin-right: 1rem;
    }
    
    .kt_modal_delete_badge-title {
        font-size: 1.25rem;
    }
    
    .kt_modal_delete_badge-subtitle {
        font-size: 0.875rem;
    }
    
    .kt_modal_delete_badge-body {
        max-height: 60vh;
        overflow-y: auto;
    }
    
    .kt_modal_delete_badge-loading {
        padding: 3rem 1rem;
    }
    
    .kt_modal_delete_badge-loading-text {
        font-size: 0.9rem;
    }
    
    .kt_modal_delete_badge-cancel-btn {
        transition: all 0.2s ease;
    }
    
    .kt_modal_delete_badge-delete-btn {
        transition: all 0.2s ease;
    }
    
    .kt_modal_delete_badge-cancel-btn:hover {
        background-color: #e8f0fe;
        transform: translateY(-1px);
    }
    
    .kt_modal_delete_badge-delete-btn:hover {
        background-color: #d32f2f;
        transform: translateY(-1px);
    }
    
    /* Content styles for dynamic content */
    .kt_modal_delete_badge-exam-name {
        font-size: 1.1rem;
        font-weight: 600;
        color: #f5365c;
        padding: 1rem 1.5rem;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        background-color: rgba(245, 54, 92, 0.05);
    }
    
    .kt_modal_delete_badge-section {
        padding: 1.25rem 1.5rem;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .kt_modal_delete_badge-section:last-child {
        border-bottom: none;
    }
    
    .kt_modal_delete_badge-section-title {
        font-size: 1rem;
        font-weight: 600;
        margin-bottom: 0.75rem;
        display: flex;
        align-items: center;
    }
    
    .kt_modal_delete_badge-section-title i {
        margin-right: 0.5rem;
    }
    
    .kt_modal_delete_badge-assessment-title {
        color: var(--kt-primary);
    }
    
    .kt_modal_delete_badge-badge-title {
        color: var(--kt-warning);
    }
    
    .kt_modal_delete_badge-points-title {
        color: var(--kt-info);
    }
    
    .kt_modal_delete_badge-list {
        margin: 0;
        padding: 0;
        list-style: none;
    }
    
    .kt_modal_delete_badge-list-item {
        padding: 0.75rem 1rem;
        border-radius: 0.5rem;
        margin-bottom: 0.5rem;
        background-color: rgba(0, 0, 0, 0.02);
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
    }
    
    .kt_modal_delete_badge-list-item:hover {
        background-color: rgba(0, 0, 0, 0.05);
        transform: translateX(5px);
    }
    
    .kt_modal_delete_badge-list-item:last-child {
        margin-bottom: 0;
    }
    
    .kt_modal_delete_badge-list-item i {
        margin-right: 0.75rem;
        font-size: 1.1rem;
    }
    
    .kt_modal_delete_badge-list-item-assessment i {
        color: var(--kt-primary);
    }
    
    .kt_modal_delete_badge-list-item-badge i {
        color: var(--kt-warning);
    }
    
    .kt_modal_delete_badge-list-item-points i {
        color: var(--kt-info);
    }
    
    .kt_modal_delete_badge-warning {
        background-color: rgba(245, 54, 92, 0.08);
        border-radius: 0.5rem;
        padding: 1.25rem;
        margin: 1rem 1.5rem;
    }
    
    .kt_modal_delete_badge-warning-title {
        color: #f5365c;
        font-weight: 600;
        margin-bottom: 0.5rem;
        display: flex;
        align-items: center;
    }
    
    .kt_modal_delete_badge-warning-title i {
        margin-right: 0.5rem;
    }
    
    .kt_modal_delete_badge-warning-text {
        color: #6c757d;
        margin-bottom: 0;
    }
    
    .kt_modal_delete_badge-empty-state {
        text-align: center;
        padding: 2rem 1rem;
        color: #6c757d;
    }
    
    .kt_modal_delete_badge-empty-state i {
        font-size: 2.5rem;
        margin-bottom: 1rem;
        opacity: 0.5;
    }

    /* Mini Dashboard Styles */
    .kt_modal_delete_badge-dashboard {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        gap: 1rem;
        padding: 1.5rem 1.75rem;
        background: #f8f9fa;
        border-bottom: 1px solid #e9ecef;
    }

    .kt_modal_delete_badge-stat-card {
        background: white;
        border-radius: 0.5rem;
        padding: 1rem;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        border: 1px solid #e9ecef;
        text-align: center;
    }
    
    .kt_modal_delete_badge-stat-value {
        font-size: 1.75rem;
        font-weight: 700;
        line-height: 1;
        margin-bottom: 0.25rem;
    }
    
    .kt_modal_delete_badge-stat-label {
        font-size: 0.85rem;
        color: #6c757d;
        font-weight: 500;
    }
    
    .kt_modal_delete_badge-stat-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 0.75rem;
        font-size: 1.25rem;
    }
    
    .kt_modal_delete_badge-stat-icon-assessment {
        background: rgba(0, 158, 247, 0.1);
        color: var(--kt-primary);
    }
    
    .kt_modal_delete_badge-stat-icon-badge {
        background: rgba(255, 199, 0, 0.1);
        color: var(--kt-warning);
    }
    
    .kt_modal_delete_badge-stat-icon-points {
        background: rgba(114, 57, 234, 0.1);
        color: var(--kt-info);
    }
    
    .kt_modal_delete_badge-stat-assessment {
        color: var(--kt-primary);
    }
    
    .kt_modal_delete_badge-stat-badge {
        color: var(--kt-warning);
    }
    
    .kt_modal_delete_badge-stat-points {
        color: var(--kt-info);
    }
    
    .points-value {
        font-weight: 600;
        color: var(--kt-info);
        margin-left: 0.5rem;
    }
    
    @media (max-width: 768px) {
        .kt_modal_delete_badge-dashboard {
            grid-template-columns: 1fr;
        }
    }
</style>





<!--begin::Modal - Add Session-->
<div class="modal fade" id="kt_modal_add_section" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Create Section</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Question Bank Name</label>
                        <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2">Writing
                            Skills for Business Final Exam

                        </div>
                    </div>

                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Section</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Session-->

<!-- Sort Filter -->
<script>
    function sort_filter(val) {
        if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
        } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
        }
    }
</script>
<!-- Delete Exam Category -->
<script>
    let deleteExamId = null;
    let examName = '';
    let hasProcess = false;
    let processCount = 0;
    let badgeCount = 0;
    let pointsCount = 0;

    function deleteFetch(sno, cat_name) {
        fetch(`/check-exam-process/${sno}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
            },
        })
        .then(response => response.json())
        .then(data => {
            const processCount = data.process_count || 0;
            const badgeCount = data.badge_count || 0;
            const pointsCount = data.points_count || 0;
            const assessments = data.assessments || [];
            const badges = data.badges || [];
            const points = data.points || [];

            let html = `
                <div class="kt_modal_delete_badge-dashboard">
                    <div class="kt_modal_delete_badge-stat-card">
                        <div class="kt_modal_delete_badge-stat-icon kt_modal_delete_badge-stat-icon-assessment">
                            <i class="mdi mdi-clipboard-check"></i>
                        </div>
                        <div class="kt_modal_delete_badge-stat-value kt_modal_delete_badge-stat-assessment">${processCount}</div>
                        <div class="kt_modal_delete_badge-stat-label">Total Assessments</div>
                    </div>
                    <div class="kt_modal_delete_badge-stat-card">
                        <div class="kt_modal_delete_badge-stat-icon kt_modal_delete_badge-stat-icon-badge">
                            <i class="mdi mdi-badge-account"></i>
                        </div>
                        <div class="kt_modal_delete_badge-stat-value kt_modal_delete_badge-stat-badge">${badgeCount}</div>
                        <div class="kt_modal_delete_badge-stat-label">Total Badges</div>
                    </div>
                    <div class="kt_modal_delete_badge-stat-card">
                        <div class="kt_modal_delete_badge-stat-icon kt_modal_delete_badge-stat-icon-points">
                            <i class="mdi mdi-star-circle"></i>
                        </div>
                        <div class="kt_modal_delete_badge-stat-value kt_modal_delete_badge-stat-points">${pointsCount}</div>
                        <div class="kt_modal_delete_badge-stat-label">Points Records</div>
                    </div>
                </div>
            `;

            $('#delete_exam_name').html(cat_name);

            // 🟡 Assessments
            if (processCount > 0) {
                html += `
                    <div class="kt_modal_delete_badge-section">
                        <div class="kt_modal_delete_badge-section-title kt_modal_delete_badge-assessment-title">
                            <i class="mdi mdi-clipboard-edit-outline"></i>
                            ${cat_name} Assessment ( ${processCount} )
                        </div>
                        <ul class="kt_modal_delete_badge-list">
                            ${assessments.map(a => `
                                <li class="kt_modal_delete_badge-list-item kt_modal_delete_badge-list-item-assessment">
                                    <i class="mdi mdi-account-circle"></i>
                                    <div>
                                        <div class="fw-medium">${a.staff_name || 'Unknown'}</div>
                                        <small class="text-muted">${a.nick_name || 'N/A'} - ${a.staff_id || 'N/A'}</small>
                                    </div>
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                `;
            } else {
                html += `
                    <div class="kt_modal_delete_badge-section">
                        <div class="kt_modal_delete_badge-empty-state">
                            <i class="mdi mdi-account-group-outline"></i>
                            <p>No linked assessments found</p>
                        </div>
                    </div>
                `;
            }

            // 🟢 Badges
            if (badgeCount > 0) {
                const badge_name = badges[0]?.badge_name ?? 'Earned';
                html += `
                    <div class="kt_modal_delete_badge-section">
                        <div class="kt_modal_delete_badge-section-title kt_modal_delete_badge-badge-title">
                            <i class="mdi mdi-badge-account"></i>
                            ${badge_name} Badge ( ${badgeCount} )
                        </div>
                        <ul class="kt_modal_delete_badge-list">
                            ${badges.map(b => `
                                <li class="kt_modal_delete_badge-list-item kt_modal_delete_badge-list-item-badge">
                                    <i class="mdi mdi-badge-account"></i>
                                    <div>
                                        <div class="fw-medium">${b.staff_name || 'Unknown'}</div>
                                        <small class="text-muted">${b.nick_name || 'N/A'} - ${b.staff_id || 'N/A'}</small>
                                    </div>
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                `;
            } else {
                html += `
                    <div class="kt_modal_delete_badge-section">
                        <div class="kt_modal_delete_badge-empty-state">
                            <i class="mdi mdi-medal-outline"></i>
                            <p>No earned badges found</p>
                        </div>
                    </div>
                `;
            }

            // 🔵 Points Records
            if (pointsCount > 0) {
                html += `
                    <div class="kt_modal_delete_badge-section">
                        <div class="kt_modal_delete_badge-section-title kt_modal_delete_badge-points-title">
                            <i class="mdi mdi-star-circle"></i>
                            Points Records ( ${pointsCount} )
                        </div>
                        <ul class="kt_modal_delete_badge-list">
                            ${points.map(p => `
                                <li class="kt_modal_delete_badge-list-item kt_modal_delete_badge-list-item-points">
                                    <i class="mdi mdi-star"></i>
                                    <div>
                                        <div class="fw-medium">${p.staff_name || 'Unknown'}</div>
                                        <small class="text-muted">
                                            ${p.nick_name || 'N/A'} - ${p.staff_id || 'N/A'} 
                                            <span class="points-value">${p.points || 0} points</span>
                                        </small>
                                    </div>
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                `;
            } else {
                html += `
                    <div class="kt_modal_delete_badge-section">
                        <div class="kt_modal_delete_badge-empty-state">
                            <i class="mdi mdi-star-circle-outline"></i>
                            <p>No points records found</p>
                        </div>
                    </div>
                `;
            }
            html2='';
            if (processCount > 0 || badgeCount > 0 || pointsCount > 0) {
                html2 += `
                    <div class="kt_modal_delete_badge-warning">
                        <div class="kt_modal_delete_badge-warning-title">
                            <i class="mdi mdi-alert-circle-outline"></i>
                            Important Notice
                        </div>
                        <p class="kt_modal_delete_badge-warning-text">
                            Deleting this exam will permanently remove all linked assessments, earned badges, and points records shown above. This action cannot be undone.
                        </p>
                    </div>
                `;
            } else {
                html2 += `
                    <div class="kt_modal_delete_badge-warning">
                        <div class="kt_modal_delete_badge-warning-title">
                            <i class="mdi mdi-information-outline"></i>
                            Confirm Deletion
                        </div>
                        <p class="kt_modal_delete_badge-warning-text">
                            Are you sure you want to delete this exam? This action cannot be undone.
                        </p>
                    </div>
                `;
            }

            $('#delete_message').html(html);
            $('#Important_Notice').html(html2);
            $('#kt_modal_delete_badge .kt_modal_delete_badge-delete-btn')
                .attr('data-id', sno)
                .attr('onclick', 'finalDeleteExam()')
                .show();

            $('#kt_modal_delete_badge .kt_modal_delete_badge-cancel-btn').text('Cancel');
            $('#kt_modal_delete_badge').modal('show');
        })
        .catch(error => {
            console.error('Error checking exam process:', error);
            toastr.error('Error checking exam status.');
        });
    }

    function finalDeleteExam() {
        const Id = $('#kt_modal_delete_badge .kt_modal_delete_badge-delete-btn').attr('data-id');
        
        // Show loading state on delete button
        const deleteBtn = $('#kt_modal_delete_badge .kt_modal_delete_badge-delete-btn');
        const originalText = deleteBtn.html();
        deleteBtn.html('<span class="spinner-border spinner-border-sm me-2" role="status"></span> Deleting...').prop('disabled', true);
        
        fetch(`/delete-exam/${Id}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
            },
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                toastr.success('Exam deleted successfully!');
                $('#kt_modal_delete_badge').modal('hide');
                setTimeout(() => location.reload(), 1000);
            } else {
                toastr.error('Error deleting exam!');
                deleteBtn.html(originalText).prop('disabled', false);
            }
        })
        .catch(error => {
            console.error('Error deleting exam:', error);
            toastr.error('Something went wrong.');
            deleteBtn.html(originalText).prop('disabled', false);
        });
    }
</script>

<!-- Data Table -->
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<!-- Toastr Starts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
<!-- Toastr Ends -->

<!-- Status Change -->
<script>
    function statusChange(sno, isChecked) {
        const status = isChecked ? 0 : 1;

        fetch(`/status_manage_exam/${sno}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
            },
            body: JSON.stringify({
                status: status
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                toastr.success('Manage Exam Status Changed Succesfully !');
            } else {
                toastr.error('Manage Exam Status Changing Failed !');
            }
        })
        .catch(error => {
            console.log('Error Changing Status :', error);
        });
    }
</script>

@endsection