@extends('layouts/contentNavbarLayout')

@section('title', 'Staff Report')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/nouislider/nouislider.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/nouislider/nouislider.js', 'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js', 'resources/assets/vendor/js/dropdown-hover.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

{{-- DropDown style --}}
<style>
  /* normal hover dropdown */
  .dropdown-hover:hover .dropdown-menu {
      display: block !important;
      top: 100%;
      bottom: auto;
  }

  /* drop-up behavior */
  .drop-up-row .dropdown-hover:hover .dropdown-menu {
      top: auto !important;
      bottom: 100% !important;
      margin-bottom: 5px;
  }

</style>
{{-- overlay style --}}
<style>
    .locked-image-box {
        position: relative;
        width: 90px;
        height: 90px;
    }

    .locked-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .image-overlay {
        position: absolute;
        inset: 0;
        background: rgba(46, 43, 43, 0.35);
        border-radius: 50%;
        z-index: 2;
    }

    .overlay-icon {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 3;
        color: white;
        font-size: 28px;
    }

  .locked-center {
      display: flex;
      justify-content: center;
      align-items: center;
  }

</style>
<style>
.badge-hover {
    position: relative;
}


.hover-ease {
    transition: box-shadow 0.25s ease-out, background-color 0.25s ease-out;
}

.hover-ease:hover {
    transition: box-shadow 0.3s ease-in, background-color 0.3s ease-in;
    box-shadow: 0 6px 16px rgba(0,0,0,0.12);
    background-color: #fafafa;
    transform: translateY(-4px) scale(1.02);
    z-index: 30 !important;

}

/* Hidden by default */
.badge-dropdown {
    position: absolute;
    top: 100%;
    left: 50%;
    transform: translateX(-50%);
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.15);
    display: none;
    z-index: 9999;
}

/* Show only on hover */
.badge-hover:hover .badge-dropdown {
    display: block;
    animation: fadeUp 0.2s ease-in-out;
}

/* Smooth animation */
@keyframes fadeUp {
    from {
        opacity: 0;
        transform: translate(-50%, 6px);
    }
    to {
        opacity: 1;
        transform: translate(-50%, 0);
    }
}
</style>
<style>
  .staff-card {
    position: relative;
    width: 200px;
    height: 120px;
    background: #fff;
    border-radius: 8px;

    /* default border */
    border: 1px solid #e2e2e2;
    border-top: 3px solid #1976d2;

    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

/* gradient border layer */
.staff-card::before {
    content: "";
    position: absolute;
    inset: 0;
    border-radius: 2px;
    padding: 1px; /* border thickness */

    background: linear-gradient(90deg, #42a5f5, #1976d2);
    -webkit-mask:
        linear-gradient(#fff 0 0) content-box,
        linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    opacity: 0;
    transition: opacity 0.3s ease;
    pointer-events: none;
}

.staff-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

/* show rounded gradient border on hover */
.staff-card:hover::before {
    opacity: 1;
}

</style>
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Staff Report</h5>
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                      <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-black opacity-75 me-1 ms-1">
                      <i class="mdi mdi-chevron-double-right fs-5"></i>
                    </span>
                    <li class="breadcrumb-item">
                      <a href="javascript:;" class="d-flex align-items-center">Assesment Management</a>
                    </li>
                  </ol>
                </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2">
            </div>
        </div>
    </div>
    {{-- <button onclick="myFunction()">ajax</button> --}}
    <div class="card-body">
        <div class="row">
          <div class="col-lg-12 mb-3 d-flex gap-3 align-items-center ">
            <div class="staff-card d-flex flex-column px-2 py-1">
                <div class="d-flex justify-content-between align-items-center gap-3">
                    <label class="fw-semibold fs-7 text-secondary mb-0">Total Staff</label>
                    <div class="rounded-circle d-flex align-items-center justify-content-center"
                        style="width:36px; height:36px; background:#e3f2fd; color:#1976d2;">
                        <span class="mdi mdi-account-group"></span>
                    </div>
                </div>
                <label class="fw-bold fs-3 text-black mb-0" id="totalStaffCount">05</label>
                <label class="fw-bold fs-8 text-secondary mb-0">Active team members</label>
            </div>
            <div class="staff-card d-flex flex-column px-2 py-1">
                <div class="d-flex justify-content-between align-items-center gap-3">
                    <label class="fw-semibold fs-7 text-secondary mb-0">Completion Rate</label>
                    <div class="rounded-circle d-flex align-items-center justify-content-center"
                        style="width:36px; height:36px; background:#e3f2fd; color:#1976d2;">
                          <span class="mdi mdi-chart-line"></span>
                    </div>
                </div>
                <label class="fw-bold fs-3 text-black mb-0" id="completionRate">33.3%</label>

                <div class="progress bg-label-primary rounded " style="height: 8px;">
                  <div class="progress-bar" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <label class="fw-bold fs-8 text-secondary mt-1" id="completionText">3 of 9 assessments</label>
            </div>
            <div class="staff-card d-flex flex-column px-2 py-1">
                <div class="d-flex justify-content-between align-items-center gap-3">
                    <label class="fw-semibold fs-7 text-secondary mb-0">Active Participants</label>
                    <div class="rounded-circle d-flex align-items-center justify-content-center"
                        style="width:36px; height:36px; background:#e3f2fd; color:#1976d2;">
                      <span class="mdi mdi-account-multiple-check"></span>
                    </div>
                </div>
                <label class="fw-bold fs-3 text-black mb-0" id="completedStaffCount">0</label>
                <label class="fw-bold fs-8 text-secondary mb-0">Staff with completed assessments</label>
            </div>
            <div class="staff-card d-flex flex-column px-2 py-1">
                <div class="d-flex justify-content-between align-items-center gap-3">
                    <label class="fw-semibold fs-7 text-secondary mb-0">Pending</label>
                    <div class="rounded-circle d-flex align-items-center justify-content-center"
                        style="width:36px; height:36px; background:#e3f2fd; color:#1976d2;">
                        <span class="mdi mdi-account-clock"></span>
                    </div>
                </div>
                <label class="fw-bold fs-3 text-black mb-0" id="pendingStaffCount">0</label>
                <label class="fw-bold fs-8 text-secondary mb-0">Assessments remaining</label>
            </div>
          </div>
          <div class="col-lg-12 mb-3">
            <div class="d-flex align-items-center justify-content-between bg-primary px-3 py-2">
              <label class="text-white fw-semibold fs-6 ">Staff</label>
              <label class="text-white fw-semibold fs-6 ps-5 ms-5">Badges</label>
              <label class="text-white fw-semibold fs-6 ">Claimed </label>
            </div>
          </div>
          <div class="col-lg-12 mb-3 border-bottom" >
            <div class="row " id="staffReportContainer">

            </div>
          </div>
        </div>
    </div>
</div>
<!--begin::Modal - Report View-->
<!-- Modal HTML (unchanged) -->
<div class="modal fade" id="kt_modal_exam_report" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20"></div>
        </div>
    </div>
</div>
<!--end::Modal - Report View-->

<script>

  // ---------------- LOADING SKELETON ----------------
  function showStaffSkeleton() {
    let html = "";
    for (let i = 0; i < 6; i++) {
      html += `
        <tr class="placeholder-glow">
          <td colspan="10">
            <div class="d-flex align-items-center gap-2 p-2">
              <span class="rounded-circle placeholder" style="width:50px;height:50px;"></span>
              <div class="w-25 placeholder"></div>
              <div class="w-25 placeholder"></div>
              <div class="w-25 placeholder"></div>
            </div>
          </td>
        </tr>`;
    }
    $("#staffTableBody").html(html);
  }


  function renderStaffTableHeader(maxBadges) {
    let thBadges = `<th class="day-col" colspan="${maxBadges}">Badges</th>`;

    let thead = `
      <tr>
        <th class="col-staff bg-primary">Staff</th>
        ${thBadges}
        <th class="col-action bg-primary">Action</th>
      </tr>
    `;

    document.querySelector("#staffTableBody").closest('table').querySelector('thead').innerHTML = thead;
  }


  function loadStaffReport() {
      const container = $("#staffReportContainer"); // replace with your container
      container.html(''); // clear existing content
      showStaffSkeleton(); // optional skeleton loader

      $.ajax({
          url: "/exam-management/staff-report",
          type: "GET",
          success: function(res) {

            const summary = res.summary;

            // Total Staff
            $("#totalStaffCount").text(summary.total_staff);

            // Completion Rate
            $("#completionRate").text(summary.completion_rate + "%");
            $("#completionProgress")
                .css("width", summary.completion_rate + "%")
                .attr("aria-valuenow", summary.completion_rate);

            $("#completionText").text(
                `${summary.completed_exams} of ${summary.total_exams} assessments`
            );

            // Completed & Pending
            $("#completedStaffCount").text(summary.complete_count);
            $("#pendingStaffCount").text(summary.pending_count);

              const staffData = res.data;

              container.empty(); // remove skeleton

              staffData.forEach(staff => {
                  container.append(buildStaffCard(staff));
              });
          }
      });
  }

  function buildStaffCard(staff) {
      const totalRequired = staff.total_required ?? 0;
      const passed = staff.passed_exam_count ?? 0;
      const badges = staff.badges ?? [];

      // Staff Info
      let staffInfo = `
          <div class="col-lg-3 d-flex justify-content-start align-item-start my-auto">
              <div class="d-flex gap-2 align-items-center ms-3">
                  <img src="${staff.staff_image_url}" alt="avatar" class="rounded-circle img-fluid"
                      style="width:60px; height:60px;object-fit:cover;padding:3px;background: linear-gradient(135deg, #6a11cb, #2575fc); border-radius:50%;">
                  <div class="d-flex flex-column justify-content-center">
                      <label class="fw-semibold fs-6 text-black mb-0">${staff.staff_name}</label>
                      <label class="fw-semibold fs-7 text-white mb-0 py-1 px-2"
                          style="border-radius:6px; width:fit-content; background: linear-gradient(to right, #4e54c8, #8f94fb);">
                          ${staff.role_name}
                      </label>
                  </div>
              </div>
          </div>
      `;

      // Badges
      let badgesHtml = '<div class="col-lg-7 d-flex justify-content-center align-items-center">';
      badgesHtml += '<div class="d-flex flex-shrink-0 align-items-center gap-3 p-2" style="max-width:730px; white-space: nowrap;">';

      for (let i = 0; i < totalRequired; i++) {
          let b = badges[i];
          let img = b ? b.badge_image_url : "assets/phdizone_images/gray-badge.png";
          let style = (b && b.passed) ? "" : "filter:brightness(2) saturate(0) blur(3px);pointer-events:none;";
          let modalAttrs = (b && b.passed)
              ? `data-bs-toggle="modal" data-bs-target="#kt_modal_exam_report" data-exam-id="${b.exam_id}" data-staff-id="${staff.staff_id}"`
              : "";

          let examName = b ? b.exam_name : "N/A";
          let examLevel = b ? b.level : "N/A";
          let examDuration = b ? b.exam_duration + " mins" : "-";
          let questionCount = b ? b.question_count : "-";

          badgesHtml += `
              <div class="flex-shrink-0 badge-hover">
                  <img src="${img}" class="img-fluid" style="width:80px;height:80px;object-fit:cover;${style}" ${modalAttrs}>
                  <div class="badge-dropdown p-3 text-black" style="width:300px;">
                      <div class="row mb-2"><label class="col-4 fs-8 fw-semibold">Exam Name</label><label class="col-1">:</label><label class="col-7 fw-bold fs-8 text-wrap">${examName}</label></div>
                      <div class="row mb-2"><label class="col-4 fs-8 fw-semibold">Exam Level</label><label class="col-1">:</label><label class="col-7 text-danger fw-bold fs-8">${examLevel}</label></div>
                      <div class="row mb-2"><label class="col-4 fs-8 fw-semibold">Duration</label><label class="col-1">:</label><label class="col-7 fw-bold fs-8">${examDuration}</label></div>
                      <div class="row mb-2"><label class="col-4 fs-8 fw-semibold">Question Count</label><label class="col-1">:</label><label class="col-7 fw-bold fs-8">${questionCount}</label></div>
                  </div>
              </div>
          `;
      }

      badgesHtml += '</div></div>';

      // Claimed / Progress
      let progressPercent = totalRequired === 0 ? 0 : Math.round((passed / totalRequired) * 100);
      let claimedHtml = `
          <div class="col-lg-2 d-flex justify-content-end align-item-end my-auto">
              <div class="me-3">
                  <div class="d-flex flex-column justify-content-around p-1" style="border-radius:6px; background:#e8f5e9; color:#1b5e20; border:1px solid #1b5e20;">
                      <div class="d-flex align-items-center justify-content-center gap-1 fw-bold fs-6 px-2 py-0">
                          <label class="text-black fw-semibold fs-1">${passed}</label>
                          <label class="text-black fw-semibold fs-6">/</label>
                          <label class="text-black fw-semibold fs-6">${totalRequired}</label>
                      </div>
                      <div class="progress bg-label-primary" style="border-radius:6px; height:8px;">
                          <div class="progress-bar" role="progressbar" style="width:${progressPercent}%" aria-valuenow="${progressPercent}" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                  </div>
              </div>
          </div>
      `;

      return `
          <div class="col-lg-12 mb-3 hover-ease border-bottom">
              <div class="row">
                  ${staffInfo}
                  ${badgesHtml}
                  ${claimedHtml}
              </div>
          </div>
      `;
  }






// function myFunction() {
  loadStaffReport();
// }

document.addEventListener('DOMContentLoaded', function() {

// Bootstrap 5 modal event
$('#kt_modal_exam_report').on('show.bs.modal', function (event) {
    const badgeEl = $(event.relatedTarget); // clicked badge
    const examId = badgeEl.data('exam-id');
    const staffId = badgeEl.data('staff-id');
    const modal = $(this);

    // Show skeleton while loading
    modal.find('.modal-body').html(showStaffModalSkeleton());

    // Fetch report from backend
    $.ajax({
        url: '/exam-management/exam-report-modal',
        type: 'GET',
        data: { exam_id: examId, staff_id: staffId },
        success: function(res) {
            modal.find('.modal-body').html(buildExamReportHtml(res.data));
        },
        error: function() {
            modal.find('.modal-body').html('<div class="text-center text-danger py-10">Failed to load report.</div>');
        }
    });
});

// Skeleton placeholder
function showStaffModalSkeleton() {
    let html = '';
    for (let i = 0; i < 6; i++) {
        html += `
        <div class="mb-4 placeholder-glow">
            <div class="placeholder w-50 mb-2"></div>
            <div class="placeholder w-25"></div>
        </div>`;
    }
    return html;
}

// Build full report HTML with all icons/labels exactly like your static modal
function buildExamReportHtml(data) {
    if (!data) return '<div class="text-center text-black">No report available</div>';

    // Build attempt rows
    let attemptsHtml = data.attempts.map(a => `
        <tr>
            <td><label class="text-black fw-semibold fs-7">${a.attempt}</label></td>
            <td><label class="text-black fw-semibold fs-7">${a.scored}</label></td>
            <td><label class="text-black fw-semibold fs-7">${a.time}</label></td>
            <td><label class="${a.result === 'Pass' ? 'text-success' : 'text-danger'} fw-semibold fs-7">${a.result}</label></td>
        </tr>
    `).join('');

    // Build modal HTML exactly like your static example
    return `
    <div class="mb-4">
        <h3 class="text-black text-center">Report Details</h3>
    </div>

    <div class="row">
        <div class="col-lg-12 mb-5">
            <div class="row">
                <div class="col-lg-12 pb-5 border-bottom mb-3">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="d-flex flex-column gap-2">
                                <label class="text-black fs-4 fw-semibold"><span class="mdi mdi-file-edit me-1 text-black fs-2"></span>${data.exam_name}</label>
                                <div class="d-flex gap-2 align-items-center">
                                    <label class="badge fs-6 fw-semibold py-2 rounded" style="background:#fff8e1; color:#ff6f00; border:1px solid #ff6f00;">${data.level}</label>
                                    <label class="badge bg-label-success fs-6 fw-semibold py-2 rounded"><span class="mdi mdi-checkbox-marked me-1">Question <span class="mdi mdi-checkbox-marked me-1"></span></label>
                                    <label class="badge  ${data.badge_id > 0 ? 'bg-label-success' : 'bg-label-danger'} py-2 fw-semibold rounded">Badge  <span class="mdi ${data.badge_id > 0 ? 'mdi mdi-checkbox-marked me-1 text-success' : 'mdi mdi-alpha-x-box me-1 text-danger'} ms-1 fs-4"></span></label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 d-flex justify-content-end align-items-end gap-4">
                            <div class="d-flex flex-column justify-content-end align-items-end my-auto">
                                <div class="d-flex align-items-baseline justify-content-end gap-1">
                                    <label class="text-success fs-1 fw-semibold mb-0">${data.total_marks}</label>
                                    <span class="mdi mdi-thumb-up text-success fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pass"></span>
                                </div>
                                <div>
                                    <label class="text-black fs-7 fw-semibold">
                                        <span class="mdi mdi-timer-check-outline text-danger me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Exam Duration"></span>
                                        ${data.duration} min
                                    </label>
                                </div>
                            </div>
                        </div>
                      </div>
                    </div>
                </div>


                <div class="col-lg-12 mb-4">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="card border border-dark" style="height: 71px; box-shadow:none !important;" >
                        <div class="card-body px-2 py-3 d-flex flex-column align-items-start justify-content-center">
                          <label class="text-secondary fw-semibold fs-7">Job Role</label>
                          <label class="text-black fw-semibold fs-6">${data.role_name}</label>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="row">
                        <div class="col-lg-4">
                          <div class="card border border-dark"   style="box-shadow:none !important;">
                          <div class="card-body px-2 py-3 d-flex flex-column align-items-center justify-content-center">
                            <label class="text-secondary fw-semibold fs-7">Limited</label>
                            <label class="text-black fw-semibold fs-5">${data.exam_attempt}</label>
                          </div>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="card border border-dark"  style="box-shadow:none !important;" >
                          <div class="card-body px-2 py-3 d-flex flex-column align-items-center justify-content-center">
                            <label class="text-secondary fw-semibold fs-7">Q Count</label>
                            <label class="text-black fw-semibold fs-5">${data.question_count}</label>
                          </div>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="card border border-dark"    style="box-shadow:none !important;">
                          <div class="card-body px-2 py-3 d-flex flex-column align-items-center justify-content-center">
                            <label class="text-secondary fw-semibold fs-7">Pass Mark</label>
                            <label class="text-black fw-semibold fs-5">${data.pass_mark}</label>
                          </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-50px">Attempted</th>
                                <th class="min-w-100px">Scored</th>
                                <th class="min-w-100px">Completion Time</th>
                                <th class="min-w-100px">Result</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                            ${attemptsHtml}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>`;
}


});

</script>
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

@endsection
