@extends('layouts/layoutMaster')

@section('title', 'Manage Result')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
@php
$helper = new \App\Helpers\Helpers();
@endphp

<style>
    .status-badge {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }
    
    .status-pass {
        background-color: #e8f5e8;
        color: #2e7d32;
        border: 1px solid #2e7d32;
    }
    
    .status-fail {
        background-color: #ffebee;
        color: #c62828;
        border: 1px solid #c62828;
    }
    
    .status-schedule {
        background-color: #e3f2fd;
        color: #1565c0;
        border: 1px solid #1565c0;
    }
    
    .status-not-started {
        background-color: #f5f5f5;
        color: #616161;
        border: 1px solid #9e9e9e;
    }
    
    .status-in-progress {
        background-color: #fff8e1;
        color: #ff8f00;
        border: 1px solid #ff8f00;
    }
    
    .status-expired {
        background-color: #fafafa;
        color: #424242;
        border: 1px solid #757575;
    }
    
    .progress-container {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .progress-bar-custom {
        height: 8px;
        border-radius: 4px;
        background-color: #e9ecef;
        overflow: hidden;
        flex-grow: 1;
    }
    
    .progress-fill {
        height: 100%;
        border-radius: 4px;
    }
    
    .progress-pass {
        background-color: #28a745;
    }
    
    .progress-fail {
        background-color: #dc3545;
    }
    
    .progress-time {
        background-color: #17a2b8;
    }
    
    .staff-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
    }
    
    .exam-level-badge {
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 0.7rem;
        font-weight: 500;
    }
    
    .level-beginner {
        background-color: #e8f5e9;
        color: #2e7d32;
    }
    
    .level-intermediate {
        background-color: #e3f2fd;
        color: #1565c0;
    }
    
    .level-expert {
        background-color: #fce4ec;
        color: #c2185b;
    }
    
    .filter-toggle {
        transition: all 0.3s ease;
    }
    
    .filter-toggle.active {
        background-color: #e7f1ff;
        color: #0d6efd;
    }
    
    .table-responsive {
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 0 0 1px rgba(0,0,0,0.1);
    }
    
    .empty-state {
        padding: 3rem 1rem;
        text-align: center;
        color: #6c757d;
    }
    
    .empty-state-icon {
        font-size: 3rem;
        margin-bottom: 1rem;
        opacity: 0.5;
    }
</style>

<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Results</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center">
                            <i class="mdi mdi-home-outline text-body fs-4"></i>
                        </a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Exam Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center flex-wrap">
                <a href="javascript:;" class="btn btn-sm fw-bold text-white btn-primary me-2 mb-2 filter-toggle" id="filter" title="Filter">
                    <i class="mdi mdi-filter-outline text-center me-1"></i> Filter
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="filter_tbox" style="display:none;">
            <form id="search_form" method="POST" action="/manage-result">
                <div class="row py-1">
                    @csrf
                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                    <input type="hidden" name="filter_on" value="1">
                    <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                        value="@php echo $perpage ? $perpage : 10; @endphp" />
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Staff</label>
                        <select class="select3 form-select" name="staff_fill" id="staff_fill">
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Role</label>
                        <select class="select3 form-select" name="role_fill" id="role_fill">
                            <option value="" selected>All</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Exam Attempt</label>
                        <select class="select3 form-select" name="attempt_fill" name="attempt_fill"> 
                            <option value="" @if($attempt_fill === null || $attempt_fill === '') selected @endif>All</option>
                            <option value="0" @if($attempt_fill == 0) selected @endif >Trial</option>
                            <option value="1" @if($attempt_fill == 1) selected @endif >Limited</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date Range</label>
                        <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt"
                            onchange="date_fill_issue_rpt();">
                            <option value="all" @if($date_filter=="all" ) selected @endif>All Time</option>
                            <option value="today" @if($date_filter=="today" )selected @endif>Today</option>
                            <option value="week" @if($date_filter=="week" ) selected @endif>This Week</option>
                            <option value="monthly" @if($date_filter=="monthly" ) selected @endif>This Month</option>
                            <option value="custom_date" @if($date_filter=="custom_date" ) selected @endif>Custom Date</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_acc_today_dt_fill" placeholder="Select Date" class="form-control"
                                value="<?php echo date(" d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_acc_week_st_dt_fill" placeholder="Select Date" class="form-control"
                                value="<?php echo date(" d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_acc_week_ed_dt_fill" placeholder="Select Date" class="form-control"
                                value="<?php echo date(" d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_acc_month_dt_fill" placeholder="Select Date" class="form-control"
                                value="<?php echo date(" M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_from_dt_fill" readonly name="from_date_fillter_textbox"
                                placeholder="Select Date" class="form-control common_date_class" value="<?php echo date(" d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_to_dt_fill" readonly name="to_date_fillter_textbox" placeholder="Select Date"
                                class="form-control common_date_class" value="<?php echo date(" d-M-Y"); ?>" />
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                    <a href="{{ url('/manage-result') }}" type="button"
                        class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
                    <button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Apply Filters</button>
                </div>
            </form>
        </div>
        <div class="row">
            <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                        onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form id="search_form" method="POST" action="/manage-result">
                        @csrf
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <div>
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="0">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                                    value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <input type="text" class="form-control" id="search_fill" name="search_fill"
                                    value="{{ $search_fill ?? "" }}" placeholder="Search by staff or exam name..." />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-12">
                @if(count($lists) > 0)
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary text-white">
                                <th class="min-w-100px">Staff</th>
                                <th class="min-w-150px">Exam</th>
                                <th class="min-w-100px text-center">Date</th>
                                <th class="min-w-180px text-center">Score / Duration</th>
                                <th class="min-w-100px text-center">Status</th>
                                <th class="min-w-100px text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                            @foreach($lists as $list)
                                <tr>
                                    @php
                                        // Start and end date calculation
                                        $startDateObj = new DateTime($list->date_of_joining);
                                        $sch_duration = $list->sch_duration;
                                        $unit = strtolower(trim($list->unit));
                
                                        switch($unit) {
                                            case 'day': case 'days':
                                                $endDateObj = (clone $startDateObj)->add(new DateInterval("P{$sch_duration}D"));
                                                break;
                                            case 'month': case 'months':
                                                $endDateObj = (clone $startDateObj)->add(new DateInterval("P{$sch_duration}M"));
                                                break;
                                            case 'year': case 'years':
                                                $endDateObj = (clone $startDateObj)->add(new DateInterval("P{$sch_duration}Y"));
                                                break;
                                            default:
                                                $endDateObj = clone $startDateObj;
                                                break;
                                        }
                
                                        $startdate = $startDateObj->format('d-M-Y');
                                        $enddate = $endDateObj->format('d-M-Y');
                                        $currentdate = new DateTime();
                
                                        $Process_status = $list->status ?? 0;
                                        $Process_pass_fail = $list->pass_fail ?? 0;
                
                                        // Decode exam answers
                                        $answers = !empty($list->exam_question_answers_datas) 
                                            ? json_decode($list->exam_question_answers_datas, true)
                                            : [];
                
                                        // Marks calculation
                                        $positiveMarks  = $list->positive_mark;
                                        $negativeMarks  = $list->negative_mark;
                                        $totalQuestions = $list->question_count;
                                        $correctCount   = collect($answers)->where('correctness', 'correct')->count();
                                        $incorrectCount = collect($answers)->where('correctness', 'incorrect')->count();
                
                                        $marksScored = max(0, ($positiveMarks * $correctCount) - ($negativeMarks * $incorrectCount));
                                        $totalMarks = $positiveMarks * $totalQuestions;
                                        $marksPercentage = $totalMarks > 0 ? min(100, ($marksScored / $totalMarks) * 100) : 0;
                                        $isPassed = $marksScored >= $list->pass_mark;
                
                                        // Time calculation (balance stored in DB)
                                        $totalDurationInSeconds = ($list->duration ?? 0) * 60;
                                        $balanceDuration = !empty($list->total_attended_duration) && $list->total_attended_duration != 0 ? $list->total_attended_duration : '0:0:0';


                                        [$h, $m, $s] = array_map('intval', explode(':', $balanceDuration));
                                        $balanceSeconds = ($h*3600)+($m*60)+$s;
                                        $balanceSeconds = min($balanceSeconds, $totalDurationInSeconds);
                                        $usedSeconds = max(0, $totalDurationInSeconds - $balanceSeconds);
                                        $usedMinutes = floor($usedSeconds/60);
                                        $usedRemainSeconds = $usedSeconds % 60;
                                        $usedTime = sprintf("%d Mins %d Sec", $usedMinutes, $usedRemainSeconds);
                                        $timePercentage = $totalDurationInSeconds > 0 ? min(100, ($usedSeconds/$totalDurationInSeconds)*100) : 0;
                
                                        // Schedule / expiry check
                                        $scheduleDate = !empty($list->next_schedule) 
                                                        ? new DateTime($list->next_schedule) 
                                                        : null;
                                        $isExpired = $scheduleDate ? $currentdate > $scheduleDate : false;
                
                                        $hasSchedule = $list->schedule_id != 0;
                                        $limitReached = ($list->exam_attempt == 1 && ($list->attempted_count ?? 0) >= ($list->attempts ?? 0));
                                        
                                         $currentDateStr = (new DateTime())->format('Y-m-d');
                                        $scheduleDateStr = !empty($list->next_schedule) 
                                                            ? (new DateTime($list->next_schedule))->format('Y-m-d') 
                                                            : null;
                                    
                                        $isExpired = $scheduleDateStr && $currentDateStr > $scheduleDateStr;
                                        $isToday = $scheduleDateStr && $currentDateStr == $scheduleDateStr;
                                        
                                        // Default status
                                        // Default status
                                        $status = 'not-started';
                                        $statusText = 'Not Started';
                                            $showDelete = false;
                                        
                                        // Determine status
                                        if ($isExpired) {
                                            $status = 'fail';
                                            $statusText = 'Fail';
                                        } elseif ($Process_status == 1) {
                                            $status = 'in-progress';
                                            $statusText = 'In Progress';
                                        } elseif ($isPassed) {
                                            $status = 'pass';
                                            $statusText = 'Pass';
                                        } elseif (!empty($scheduleDate) && $currentdate < $scheduleDate) {
                                            $status = 'schedule';
                                            $statusText = 'Re-Scheduled';
                                        } elseif (!empty($scheduleDate)) {
                                            $status = 'schedule';
                                            $statusText = 'Re-Scheduled';
                                        } elseif (!empty($list)) { // assuming $list indicates failed items
                                            $status = 'fail';
                                            $statusText = 'Fail';
                                            $showDelete = true;
                                        }


                                        
                                        // Determine level class
                                        $levelClass = '';
                                        switch ($list->level_id) {
                                            case 0:
                                                $level = 'Beginner';
                                                $levelClass = 'level-beginner';
                                                break;
                                            case 1:
                                                $level = 'Intermediate';
                                                $levelClass = 'level-intermediate';
                                                break;
                                            case 2:
                                                $level = 'Expert';
                                                $levelClass = 'level-expert';
                                                break;
                                            default:
                                                $level = 'UnKnown';
                                                break;
                                        }
                                    @endphp
                                    <td>
                                        <div class="d-flex align-items-center px-1">
                                            @if ($list->staff_image != '' && file_exists(public_path('staff_images/' .$list->staff_image)))
                                            <div class="me-3">
                                                <img src="{{ asset('staff_images/' . $list->staff_image) }}" alt="user-avatar"
                                                    class="staff-avatar" />
                                            </div>
                                            @else
                                            <div class="me-3">
                                                @php
                                                $initial = strtoupper(substr($list->nick_name, 0, 1));
                                                echo $helper->name_image($initial, $list->gender);
                                                @endphp
                                            </div>
                                            @endif
                                            <div class="mb-0">
                                                <div class="fs-7 text-black fw-semibold">{{ $list->staff_name }}</div>
                                                <div class="fs-8 text-muted">{{ $list->role_name ?? 'N/A' }}</div>
                                                <div class="fs-8 text-info">{{ $list->branch_name ? $list->branch_name: $list->franchise_name;}}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="text-truncate max-w-250px fw-semibold" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="{{ $list->exam_name }}">{{ $list->exam_name }}
                                        </div>
                                        <div class="d-block mt-1">
                                            <span class="exam-level-badge {{ $levelClass }}" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Exam Level">{{ $level }}</span>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <div class="text-black fs-7 fw-semibold">{{ \Carbon\Carbon::parse($list->created_at)->format('d-M-Y') }}</div>
                                        <div class="text-muted fs-8">{{ \Carbon\Carbon::parse($list->created_at)->format('h:i A') }}</div>
                                    </td>
                                    <td class="text-center">
                                        <div class="progress-container">
                                            <div class="progress-bar-custom">
                                                <div class="progress-fill {{ $isPassed ? 'progress-pass' : 'progress-fail' }}" 
                                                     style="width: {{ $marksPercentage }}%"></div>
                                            </div>
                                            <span class="fs-7 fw-bold">{{ round($marksPercentage) }}%</span>
                                        </div>
                                        <div class="mt-1 fs-8 text-muted">
                                            {{ $marksScored }}/{{ $totalMarks }}
                                        </div>
                                        <div class="progress-container">
                                            <div class="progress-bar-custom">
                                                <div class="progress-fill progress-time" 
                                                     style="width: {{ $timePercentage }}%"></div>
                                            </div>
                                            <span class="fs-7 fw-bold">{{ round($timePercentage) }}%</span>
                                        </div>
                                        <div class="mt-1 fs-8 text-muted">{{$usedTime}} / {{ $list->duration }} Mins</div>
                                    </td>

                                    <td class="text-center">
                                        @php
                                            $new_limit = $helper->get_new_exam_limits($list->exam_id,$list->staff_id);
                                            if($new_limit){
                                                $list->attempts = $new_limit;
                                            }
                                            $viewExtend = false;
                                            if($list->curattempt_count == $list->attempts){
                                                if(!$isPassed){
                                                    $viewExtend = true;
                                                }
                                            }
                                        @endphp
                                        <div>
                                            @if(empty($list->attempts) || $list->attempts == 0)
                                                <label class="fs-7 fw-bold text-black"><span data-bs-toggle="tooltip" data-bs-placement="top" title="Current Attempt">{{ $list->curattempt_count }}</span> / <span class="fs-4" data-bs-toggle="tooltip" data-bs-placement="top" title="Total Attempt">∞</span></label>
                                            @else
                                                <label class="fs-7 fw-bold text-black"><span data-bs-toggle="tooltip" data-bs-placement="top" title="Current Attempt">{{ $list->curattempt_count }}</span> / <span data-bs-toggle="tooltip" data-bs-placement="top" title="Total Attempt">{{ $list->attempts }}</span></label>
                                            @endif
                                        </div>
                                        <span class="status-badge status-{{ $status }}">
                                            @if($status == 'pass')
                                                <i class="mdi mdi-check-circle-outline fs-6"></i>
                                            @elseif($status == 'fail')
                                                <i class="mdi mdi-close-circle-outline fs-6"></i>
                                            @elseif($status == 'in-progress')
                                                <i class="mdi mdi-progress-clock fs-6"></i>
                                            @elseif($status == 'schedule')
                                                <i class="mdi mdi-calendar-clock fs-6"></i>
                                            @else
                                                <i class="mdi mdi-circle-outline fs-6"></i>
                                            @endif
                                            {{ $statusText }}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        @php
                                            $exam_sno  = $list->exam_id;
                                            $satff_sno = $list->staff_id;
                                            $process_sno = $list->sno;
                                            $enc_id = $exam_sno .'~'. $satff_sno.'~'.$process_sno;
                                            $encryptedValue = $helper->encrypt_decrypt($enc_id,'encrypt');
                                            $view_url = url('/staff-exam-report/' . $encryptedValue);
                                            $cert_url = url('/staff-assessment-certificate/' . $encryptedValue);
                                        @endphp
                                        <div class="d-flex justify-content-center gap-1">
                                            @if(in_array($status, ['pass', 'fail', 'schedule']))
                                                <a href="{{ $view_url }}" class="btn btn-icon btn-sm btn-outline-primary" 
                                                    data-bs-toggle="tooltip" data-bs-placement="top" title="View Details">
                                                    <i class="mdi mdi-eye-outline fs-4"></i>
                                                </a>
                                                @if($isPassed)
                                                <a href="{{ $cert_url }}" target="_blank" class="btn btn-icon btn-sm btn-outline-primary" 
                                                    data-bs-toggle="tooltip" data-bs-placement="top" title="View certificate">
                                                    <i class="mdi mdi-certificate-outline fs-4"></i>
                                                </a>
                                                @endif
                                                @if($viewExtend)
                                                    @if(empty($list->attempts) || $list->attempts == 0)
                                                    @else
                                                        <a href="javascript:;" 
                                                            class="btn btn-icon btn-sm btn-outline-danger" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#increaseLimitModal"
                                                            onclick="openIncreaseLimitModal(
                                                                    '{{ $list->exam_name }}',
                                                                    '{{ $list->staff_id }}',
                                                                    '{{ $exam_sno }}',
                                                                    '{{ $list->staff_name }}',
                                                                    '{{ $list->attempts }}',
                                                                    '{{ $list->curattempt_count }}',
                                                                    '{{ \Carbon\Carbon::parse($list->created_at)->format('d-M-Y h:i A') }}',
                                                                    '{{ $marksScored }} / {{ $totalMarks }}'
                                                            )">
                                                                <i class="mdi mdi-plus-circle-outline fs-4" data-bs-toggle="tooltip" data-bs-placement="top" title="Increase Limit"></i>
                                                        </a>
                                                    @endif
                                                @endif
                                                @if($showDelete) 
                                                    <a href="javascript:;" 
                                                        class="btn btn-icon btn-sm btn-outline-danger" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#DeleteModal"
                                                        onclick="openDeleteModal(
                                                                '{{ $list->exam_name }}',
                                                                '{{ $list->staff_id }}',
                                                                '{{ $exam_sno }}',
                                                                '{{ $process_sno }}',
                                                                '{{ $list->staff_name }}',
                                                                '{{ $list->attempts }}',
                                                                '{{ $list->curattempt_count }}',
                                                                '{{ \Carbon\Carbon::parse($list->created_at)->format('d-M-Y h:i A') }}',
                                                                '{{ $marksScored }} / {{ $totalMarks }}'
                                                        )">
                                                            <i class="mdi mdi-delete-outline fs-4" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete Assessment"></i>
                                                    </a>
                                                @endif
                                                
                                            @elseif($status == 'in-progress')
                                                -
                                            @endif

                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @else
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="mdi mdi-clipboard-text-outline"></i>
                    </div>
                    <h4 class="text-muted">No Results Found</h4>
                    <p class="text-muted">There are no exam results matching your current filters.</p>
                    <a href="{{ url('/manage-result') }}" class="btn btn-primary mt-3">Clear Filters</a>
                </div>
                @endif
            </div>
            @if(count($lists) > 0)
            <div class="mt-4">
                {{ $lists->appends(request()->except(['page', '_token']))->links() }}
            </div>
            @endif
        </div>
    </div>
</div>




<div class="modal fade" id="increaseLimitModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Increase Assessment Attempts</h3>
                </div>
                <div class="row">   
                    <form>                 
                        <div class="info-grid">
                            <div class="info-item">
                                <div class="info-label">Assessment Name</div>
                                <div class="info-value" id="exam_name_lim">-</div>
                                <input type="hidden" id="exam_sno" name="exam_sno">
                                <input type="hidden" id="staff_sno" name="staff_sno">
                                <input type="hidden" id="process_sno" name="process_sno">
                                <input type="hidden" id="current_limit" name="current_limit">
                            </div>
                            
                            <div class="info-item">
                                <div class="info-label">Staff Name</div>
                                <div class="info-value" id="staff_name_lim">-</div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-label">Last Attempt Score</div>
                                <div class="info-value" id="last_att_score">-</div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-label">Last Attempt Date</div>
                                <div class="info-value" id="last_att_date">-</div>
                            </div>
                            
                            
                            <div class="info-item">
                                <div class="info-label">Limits</div>
                                <div class="info-value"><span id="limit_count">-</span> Attempts</div>
                            </div>
                            <div class="col-lg-9 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Increase Attempt Limit<span class="text-danger">*</span></label>
                                <input 
                                    type="number" 
                                    class="form-control" 
                                    placeholder="Enter New Attempt Limit" 
                                    id="new_attempts" 
                                    name="new_attempts" 
                                    min="1" 
                                    max="9"
                                    required 
                                    />
                                <div class="error_msg text-danger"></div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update Limit</button>
                        </div>
                    </form>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<div class="modal fade" id="DeleteModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                 <div class="mb-5 text-center">
                    <div class="warning-icon">
                        <i class="fas fa-exclamation-triangle animation-blink"></i>
                    </div>
                    <h3 class="text-center mb-2 text-black">Delete Assessment</h3>
                    <p class="text-muted">Are you sure you want to delete this assessment? <br> This action cannot be undone.</p>
                </div>
                <div class="row">   
                    <form>                 
                        <div class="row align-center text-center">
                            <div class="col-lg-12 mb-2">
                                <div class="info-label">Assessment Name</div>
                                <div class="info-value" id="exam_name_del">-</div>
                                <input type="hidden" id="exam_sno_del" name="exam_sno_del">
                                <input type="hidden" id="staff_sno_del" name="staff_sno_del">
                                <input type="hidden" id="process_sno_del" name="process_sno_del">
                            </div>
                            
                            <div class="col-lg-12 mb-2">
                                <div class="info-label">Staff Name</div>
                                <div class="info-value" id="staff_name_del">-</div>
                            </div>
                            <div class="col-lg-12 mb-2">
                                <div class="info-label">Limits</div>
                                <div class="info-value"><span id="limit_count_del">-</span> Attempts</div>
                            </div>
                            
                            <div class="col-lg-12 mb-2">
                                <div class="info-label">Last Attempt Score</div>
                                <div class="info-value" id="last_att_score_del">-</div>
                            </div>
                            
                            <div class="col-lg-12 mb-2">
                                <div class="info-label">Last Attempt Date</div>
                                <div class="info-value" id="last_att_date_del">-</div>
                            </div>
                        </div>

                        <div class="form-check text-center mt-4">
                            
                            <label class="form-check-label fw-semibold" for="confirm_delete_check">
                                <input class="form-check-input" type="checkbox" id="confirm_delete_check">
                                <span class="ms-2">I confirm that I want to delete this assessment.</span>
                            </label>
                        </div>
                        <div class="row" id="delete_button_div" style="display: none;">
                            <div class="d-flex justify-content-center align-items-center mb-2 mt-4" >
                                <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-danger">Delete Assessment</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        .warning-icon {
            font-size: 4rem;
            color: #dc3545;
        }
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>

<style>
    .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .info-item {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 16px;
        }
        
        .info-label {
            font-size: 14px;
            color: #7e8299;
            margin-bottom: 6px;
        }
        
        .info-value {
            font-size: 16px;
            font-weight: 600;
            color: #1e1e2d;
        }
        
        .input-group {
            margin-bottom: 30px;
        }
        
        .input-label {
            display: block;
            font-weight: 600;
            color: #1e1e2d;
            margin-bottom: 10px;
            font-size: 16px;
        }
        
        .input-container {
            position: relative;
        }
        
        .input-field {
            width: 100%;
            padding: 14px 16px 14px 45px;
            border: 1px solid #e1e3ea;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .input-field:focus {
            outline: none;
            border-color: #009ef7;
            box-shadow: 0 0 0 3px rgba(0, 158, 247, 0.1);
        }
        
        .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #7e8299;
        }
</style>


<script>

function openIncreaseLimitModal(
                examName,      // Assessment Name
                staffSno,      // Staff ID
                examSno,       // Exam ID
                staffName,     // Staff Name
                totalAttempts, // Total Allowed Attempts
                usedAttempts,  // Current Attempt Count
                lastAttemptDate,// Last Attempt Date
                Score
            ) {
    // Set visible info
    document.getElementById('exam_name_lim').textContent = examName;
    document.getElementById('staff_name_lim').textContent = staffName;
    document.getElementById('limit_count').textContent = usedAttempts+' / '+totalAttempts;

    // Hidden inputs for backend submission
    document.getElementById('exam_sno').value = examSno;
    document.getElementById('staff_sno').value = staffSno;
    document.getElementById('current_limit').value = totalAttempts;

    // Extra info
    document.getElementById('last_att_date').textContent = lastAttemptDate || '-';
    document.getElementById('last_att_score').textContent = Score || '-';

    // Clear old input value
    document.getElementById('new_attempts').value = '';
}

document.querySelector('#increaseLimitModal form').addEventListener('submit', function (e) {
    e.preventDefault();

    const exam_id = document.getElementById('exam_sno').value;
    const staff_id = document.getElementById('staff_sno').value;
    const current_limit = parseInt(document.getElementById('current_limit').value, 10);
    const new_limit = parseInt(document.getElementById('new_attempts').value, 10);
    const error = document.querySelector('.error_msg');

    // Client-side validation
    if (isNaN(new_limit) || new_limit <= current_limit) {
        error.textContent = `New limit must be greater than the current limit (${current_limit}).`;
        return;
    }
    error.textContent = "";

    // Send AJAX to backend
    fetch('/exam-limit-increase', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({
            exam_id,
            staff_id,
            old_limit: current_limit,
            new_limit
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            toastr.success('Attempt limit updated successfully!');
            location.reload();
        } else {
            toastr.error('Something went wrong.');
            // error.textContent = data.message || "Something went wrong.";
        }
    })
    .catch(err => {
        console.error(err);
    });
});


    document.getElementById('confirm_delete_check').addEventListener('change', function() {
        const deleteDiv = document.getElementById('delete_button_div');
        deleteDiv.style.display = this.checked ? 'flex' : 'none';
    });

function openDeleteModal(
                examName,      // Assessment Name
                staffSno,      // Staff ID
                examSno,       // Exam ID
                processSno,       // Exam ID
                staffName,     // Staff Name
                totalAttempts, // Total Allowed Attempts
                usedAttempts,  // Current Attempt Count
                lastAttemptDate,// Last Attempt Date
                Score
            ) {
    // Set visible info
    document.getElementById('exam_name_del').textContent = examName;
    document.getElementById('staff_name_del').textContent = staffName;
    document.getElementById('limit_count_del').textContent = usedAttempts+' / '+totalAttempts;

    // Hidden inputs for backend submission
    document.getElementById('exam_sno_del').value = examSno;
    document.getElementById('staff_sno_del').value = staffSno;
    document.getElementById('process_sno_del').value = processSno;

    // Extra info
    document.getElementById('last_att_date_del').textContent = lastAttemptDate || '-';
    document.getElementById('last_att_score_del').textContent = Score || '-';

}

document.querySelector('#DeleteModal form').addEventListener('submit', function (e) {
    e.preventDefault();

    const exam_id = document.getElementById('exam_sno_del').value;
    const staff_id = document.getElementById('staff_sno_del').value;
    const Process_id = document.getElementById('process_sno_del').value;

    // Send AJAX to backend
    fetch('/exam-process-delete', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({
            exam_id,
            staff_id,
            Process_id,
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            toastr.success('Assessment Deleted successfully!');
            location.reload();
        } else {
            toastr.error(data.message || 'Something went wrong.');
        }
    })
    .catch(err => {
        console.error(err);
    });
});

</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        "searching": false,
        "info": false,
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            ">" +
            "<'table-responsive'tr>" +
            "<'row'" +
            ">"
    });
</script>

<script>
    $(document).ready(function() {
        // Filter toggle
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
            $(this).toggleClass('active');
        });
    });
    
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date;
            var first = curr.getDate() - curr.getDay();
            var last = first + 6;

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#acc_daily_acc_week_st_dt_fill').val(firstday);
            $('#acc_daily_acc_week_ed_dt_fill').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
    
    function sort_filter(value) {
        document.getElementById('sorting_filter').value = value;
        document.getElementById('search_form').submit();
    }
    
    function search_filter_func() {
        document.getElementById('search_form').submit();
    }
    
    
</script>

<script>
    $(document).ready(function () {
        
        const selectedStaff = @json($staff_fill);
        const selectedRoles = @json($role_fill);

        $.ajax({
            url: `/staff_list`,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {

                    const staffs = response.data;
                    const staffFill = $('#staff_fill');
                    staffFill.empty();
                    staffFill.append(`<option value=''>All Staff</option>`);

                    staffs.forEach(staff => {
                        staffFill.append(`<option value='${staff.sno}'>${staff.staff_name}</option>`);
                    });

                    staffFill.val(selectedStaff).change();

                } else {
                    console.log(`Error Fetching Data!`);
                }
            },
            error: function(error) {
                console.log(`Error Fetching Data!`);
            }
        });

        $.ajax({
            url: `/user_role`,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {

                    const roles = response.data;
                    const roleFill = $('#role_fill');
                    roleFill.empty();
                    roleFill.append(`<option value=''>All Roles</option>`);

                    roles.forEach(role => {
                        roleFill.append(`<option value='${role.sno}'>${role.role_name}</option>`);
                    });

                    roleFill.val(selectedRoles).change();

                } else {
                    console.log(`Error Fetching Data!`);
                }
            },
            error: function(error) {
                console.log(`Error Fetching Data!`);
            }
        });
    });
</script>
<script>

function downloadCertStaff(id) { 
         // Combine the IDs to be sent for encryption
         var values = id;
 
         // Get the CSRF token from the meta tag
         var csrfToken = $('meta[name="csrf-token"]').attr('content');
 
         // Use AJAX to encrypt the combined values using a PHP route
         $.ajax({
             url: '/ids/encrypt', // Your encryption route
             type: 'POST',
             data: {
                 values: values,
                 _token: csrfToken // Include CSRF token here
             },
             success: function(encrypted_course_id) {
                 // Redirect to the PDF generation route with the encrypted ID
                     const iframe = document.createElement('iframe');
                    iframe.style.display = 'none';
                    iframe.src = '/assesment_certificate_download/' + encrypted_course_id;
                    document.body.appendChild(iframe);
                
                    // Wait a bit before refreshing the page
                    setTimeout(function () {
                        location.reload();
                    }, 2000); // Adjust the delay as needed
                 
             },
             error: function(xhr) {
                //  Swal.fire({
                //      title: 'Error!',
                //      text: xhr.responseJSON.message || 'Encryption failed.',
                //      icon: 'error',
                //      customClass: {
                //          confirmButton: 'btn btn-primary waves-effect waves-light'
                //      },
                //      buttonsStyling: false
                //  });
             }
         });
     }
     
</script>
@endsection