<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <style>
    /* Embed fonts for DOMPDF/wkhtmltopdf */
    @font-face {
      font-family: 'Mustica Pro';
      src: url("{{ public_path('fonts/MusticaPro-Regular.ttf') }}") format('truetype');
      font-weight: normal;
      font-style: normal;
    }
    @font-face {
      font-family: 'Mustica Pro';
      src: url("{{ public_path('fonts/MusticaPro-Bold.ttf') }}") format('truetype');
      font-weight: bold;
      font-style: normal;
    }

    /* Reset */
    html, body {
      margin: 0;
      padding: 0;
      height: 100%;
      width: 100%;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
      font-family: 'Mustica Pro', sans-serif;
      background: transparent;
    }

    /* Force one page sized exactly to A4 landscape */
    @page {
      size: A4 landscape;
      margin: 0mm;
    }

    /* Container exactly A4 landscape in mm (precise for PDF) */
    .certificate {
      width: 297mm;    /* A4 width in landscape */
      height: 210mm;   /* A4 height in landscape */
      position: relative;
      overflow: hidden;
      box-sizing: border-box;
      page-break-after: avoid;
      page-break-inside: avoid;
      background-image: url("{{ public_path('assets/phdizone_images/assessement_certificate/exam_certificate.jpg') }}");
      background-repeat: no-repeat;
      /* background-size exactly cover the page */
      background-size: 297mm 210mm;
      background-position: center center;
    }

    /* Generic text style - colors/weight can be adjusted */
    .cert-text {
      position: absolute;
      color: #0b4f6c; /* adjust to your branding */
      font-weight: 600;
      text-align: center;
      line-height: 1;
      word-break: break-word;
    }

    /* Use percentage/transform for robust positioning */
    .staff-name {
      top: 40%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 76%;
      font-size: 20pt; /* use pt for print-friendly scaling */
    }

    .exam-name {
      top: 46%;
      left: 63%;
      transform: translate(-50%, -50%);
      width: 84%;
      font-size: 15pt;
      text-align: center;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    /* Date group (compact) */
    .date-group {
      position: absolute;
      top: 53%;
      left: 27%;
      transform: translate(-0%, -50%);
      font-size: 16pt;
      color: #004c70;
      display: inline-block;
      width: 20%;
      text-align: left;
    }

    .date-group .date-item {
      display: inline-block;
      min-width: 45px;
      margin-right: 6px;
    }

    /* Level on right side */
    .exam-level {
      top: 52%;
      left: 65%;
      transform: translate(-50%, -50%);
      font-size: 16pt;
      width: 20%;
      text-align: center;
    }

    /* Achievement / prize */
    .achievement {
      top: 59%;
      left: 63%;
      transform: translate(-50%, -50%);
      width: 80%;
      font-size: 16pt;
      text-align: center;
    }

    /* Marks pair, centered under achievement */
  .marks {
    position: absolute;
    top: 75%;
    left: 54%;
    transform: translate(-50%, -50%);
    font-size: 14pt;
    font-weight: bold;
    color: #004c70;
    text-align: center;
    z-index: 10;

    /* this keeps everything in one horizontal line */
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px; /* space between numbers and slash */
  }

  .marks-left,
  .marks-right{
    display: inline-block;
    min-width: 45px;
  }




    /* Badge & signature images - scaled and positioned */
    .badge {
      position: absolute;
      top: 82%;
      left: 18%;
      transform: translate(-0%, -50%);
      width: 90px; height: auto;
      max-height: 70px;
    }

    .authority-sign {
      position: absolute;
      top: 82%;
      left: 78%;
      transform: translate(-50%, -50%);
      width: 140px; height: auto;
      max-height: 90px;
    }

    /* Small helpers */
    .hide-on-pdf { display: none; } /* if you used any non-PDF content */
  </style>
</head>
<body>
  @php
    $staffLevel = $view->level_id;
    switch ($staffLevel) {
      case 0: $level = 'Beginner'; break;
      case 1: $level = 'Intermediate'; break;
      case 2: $level = 'Expert'; break;
      default: $level = 'Unknown'; break;
    }
  @endphp

  @php
    $marksScored = 0;
    $totalMarks = 0;
    if (isset($process[0])) {
      $p = $process[0];
      $answers = json_decode($p->exam_question_answers_datas, true) ?? [];
      $positiveMarks = $view->positive_mark ?? 1;
      $negativeMarks = $view->negative_mark ?? 0;
      $totalQuestions = $view->question_count ?? 0;
      $correctCount = collect($answers)->where('correctness', 'correct')->count();
      $incorrectCount = collect($answers)->where('correctness', 'incorrect')->count();
      $totalMarks = $positiveMarks * $totalQuestions;
      $marksScored = max(0, $positiveMarks * $correctCount - $negativeMarks * $incorrectCount);
      $isPassed = $marksScored >= $view->pass_mark;
    }
  @endphp

  <!-- main certificate page -->
  <div class="certificate">
    <div class="cert-text staff-name">{{ $process[0]->staff_name ?? '' }}</div>

    <div class="cert-text exam-name">{{ $view->exam_name ?? '' }}</div>

    <div class="date-group">
      <span class="date-item">{{ $process[0]->completed_date ? date('d', strtotime($process[0]->completed_date)) : '' }}</span>
      <span class="date-item">{{ $process[0]->completed_date ? date('m', strtotime($process[0]->completed_date)) : '' }}</span>
      <span class="date-item">{{ $process[0]->completed_date ? date('Y', strtotime($process[0]->completed_date)) : '' }}</span>
    </div>

    <div class="cert-text exam-level">{{ $level }}</div>

    <div class="cert-text achievement">
      @if ($view->prize_id == 1 && $view->gift)
          {{ $view->gift ?? 'Gift' }}
      @elseif($view->prize_id == 2 && $view->points)
          + {{ $view->points }} Points
      @elseif($view->prize_id == 3 && $view->promotion_id)
          {{ $view->job_position_name ?? 'Career Advancement' }}
      @else
          Achievement Unlocked
      @endif
    </div>

    <div class="marks">
      <span class="marks-left">{{ str_pad($marksScored, 2, '0', STR_PAD_LEFT) }}</span>
      <span class="marks-right">{{ str_pad($totalMarks, 2, '0', STR_PAD_LEFT) }}</span>
    </div>



    @if ($view->badge_check == 1 && $isPassed)
      <img src="{{ public_path('exam/badges/' . $view->badge_image) }}" class="badge" alt="Badge Image">
    @endif

    <img src="{{ public_path('assets/phdizone_images/assessement_certificate/assesment_authority.png') }}"
         class="authority-sign" alt="Signature Image">
  </div>

</body>
</html>
