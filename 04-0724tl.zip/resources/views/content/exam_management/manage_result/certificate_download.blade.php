<html>
<head>
<title>Assessment Certificate | {{ $view->exam_name ?? '' }} | Elysium Groups</title>
<style>
  @font-face {
    font-family: 'sofia';
    src: url('{{ public_path("fonts/Sofia-Regular.ttf") }}') format("truetype");
  }
 
  body {
    margin: 0;
    padding: 0;
  }
 
  @page {
    size: 1123px 794px;
    margin: 0;
  }
 
  .certificate {
    width: 1123px;
    height: 794px;
    /* background-image: url('{{ asset("assets/phdizone_images/assessement_certificate/exam_certificate.jpg") }}'); */
    background-image: url('../../../../assets/phdizone_images/assessement_certificate/exam_certificate.jpg');
    background-size: cover;
    background-repeat: no-repeat;
    position: relative;
 
  }
 
  .participant_name {
   font-family: 'sofia';
    position: absolute;
    top:300px; left: 120px;
    width: 800px;
    text-align: center;
    font-size: 30px;
    color: #000080;
    font-weight:bold
  }
 
      .event_name {
        font-family: 'sofia';
        position: absolute;
        top: 380px; left: 420px;
        width: 500px;       /* fixed box */
        text-align: center;
        font-size: 20px;    /* maximum size */
        font-weight: bold;
        color: #000080;
        white-space: nowrap;   /* force single line */
        transform-origin: left center;
        display: inline-block;
        overflow: visible;
    }
 
  .event_category {
      font-family: 'sofia';
    position: absolute;
    top: 440px; left: 180px;
    font-size: 26px;
    font-weight: bold;
    color: #000080;
  }
 
  .event_date {
      font-family: 'sofia';
    position: absolute;
    top: 440px; left: 600px;
    font-size: 24px;
    font-weight: bold;
    color: #000080;
  }
 
  .branch_name {
      font-family: 'sofia';
    position: absolute;
    top: 510px; left: 0;
    width: 1123px;
    text-align: center;
    font-size: 26px;
    font-weight: bold;
    color: #000080;
  }
 
  .cert_auth_name {
    position: absolute;
    bottom: 100px; left: 450px;
    width: 250px;
    text-align: center;
    font-size: 22px;
    font-weight: bold;
      color:black;
  }
 
 
  .cert_auth_sign {
    position: absolute;
    bottom: 30px; left: 450px;
    width: 250px;
 
    text-align: center;
  }
 
  .cert_auth_sign img {
    width: 150px;
    height: 75px;
    object-fit: contain;
  }
</style>
</head>
<body>
    @php
        $marksScored = 0;
        $totalMarks = 0;

        if (isset($process[0])) {
            $p = $process[0];
            $answers = json_decode($p->exam_question_answers_datas, true) ?? [];
            $positiveMarks = $view->positive_mark ?? 1;
            $negativeMarks = $view->negative_mark ?? 0;
            $totalQuestions = $view->question_count ?? 0;

            $correctCount = collect($answers)->where('correctness', 'correct')->count();
            $incorrectCount = collect($answers)->where('correctness', 'incorrect')->count();

            $totalMarks = $positiveMarks * $totalQuestions;
            $marksScored = max(0, $positiveMarks * $correctCount - $negativeMarks * $incorrectCount);
            // Check if exam is passed
            $isPassed = $marksScored >= $view->pass_mark;
        }
    @endphp
  <div class="certificate">
    <div class="participant_name">
      {{ $process[0]->staff_name ?? '' }}
    </div>
 
    <div class="event_name">
        {{ $view->exam_name ?? '' }}
    </div>
 
 
    <div class="event_category">
      --
    </div>
 
    <div class="event_date">
      {{ $process[0]->completed_date ? date('d-M-Y', strtotime($process[0]->completed_date)) : '' }}
    </div>
 
    <div class="d-flex align-items-center">
    <div style="width: 48% !important;padding-top: 47px !important;"></div>
    <div class="fw-bold text-info text-center"
        style="width:5% !important;padding-top: 52px !important;font-size:21px !important;">
        {{ str_pad($marksScored, 2, '0', STR_PAD_LEFT) }}</div>
    <div style="width:2% !important;padding-top: 47px !important;"></div>
    <div class="fw-bold text-info text-center"
        style="width:5% !important;padding-top: 52px !important;font-size:21px !important;">
        {{ str_pad($totalMarks, 2, '0', STR_PAD_LEFT) }}</div>
    <div style="width:41% !important;padding-top: 47px !important;"></div>
</div>
 
    <div class="cert_auth_sign">
      <img src="{{ asset('assets/phdizone_images/assessement_certificate/assesment_authority.png') }}" alt="Signature" />
    </div>
  </div>
</body>
 
</html>
 
 