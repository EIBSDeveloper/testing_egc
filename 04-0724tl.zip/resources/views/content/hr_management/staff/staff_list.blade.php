@extends('layouts/layoutMaster')

@section('title', 'Manage Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js',
'resources/assets/vendor/js/dropdown-hover.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

<!-- Lead List Table -->
@php
$helper = new \App\Helpers\Helpers();
@endphp
@php
    $module_name = 'HR Management';
    $menu_name   = 'Manage Staff';
@endphp
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Staff</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">HR Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        
    </div>
    <div class="card-body">
        <div class="nav-align-top mb-4">
            <ul class="nav nav-pills flex-wrap gap-2" role="tablist">
                <li class="nav-item" role="presentation">
                    <a href="{{ url('/hr_management/staff') }}" class="nav-link text-capitalize active" role="tab">
                        Staffs
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a href="{{ url('/hr_management/staff/Exit_staff_list') }}" class="nav-link text-capitalize "
                        role="tab">
                        Exit Staff
                    </a>
                </li>
            </ul>
            <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2">
                <!--<a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-1" id="filter">-->
                <!--    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>-->
                <!--</a>-->
                @if(auth()->user()->hasPermission($module_name, 'Add', $menu_name))
                <a href="/manage_staff/staff_add" class="btn btn-sm fw-bold text-white btn-primary">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Staff
                </a>
                @endif
            </div>
        </div>
        </div>
        <div class="filter_tbox" style="display: none;">
            <form id="filter_form" method="POST" action="/hr_management/staff">
                @csrf
                <div class="row py-1">
                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                    <input type="hidden" name="filter_on" value="1">
                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Job Position</label>
                        <select class="select3 form-select" id="job_position_fill_sno" name="job_position_fill_sno">
                            <option value="" selected>All</option>
                            @if (count($jop_position_list_fill) > 0)
                            @foreach ($jop_position_list_fill as $pos_list)
                            <option value="{{ $pos_list->sno }}" @if($pos_list->sno== $job_position_fill??'') selected
                                @endif>{{ $pos_list->job_position_name }}</option>
                            @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department</label>
                        <select class="select3 form-select" id="department_fill" name="department_fill" >
                            <option value="" selected>All</option>
                            @if (count($department_list_fill) > 0)
                            @foreach ($department_list_fill as $drp_list)
                            <option value="{{ $drp_list->sno }}" @if($drp_list->sno== $department_fill??'') selected
                                @endif>{{ $drp_list->department_name }}</option>
                            @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Job Role</label>
                        <select class="select3 form-select" id="job_roll_fill_sno" name="job_roll_fill_sno">
                            <option value="" selected>All</option>
                            @if (count($job_roll_list_fill) > 0)
                            @foreach ($job_roll_list_fill as $roll_list)
                            <option value="{{ $roll_list->sno }}" @if($roll_list->sno== $job_roll_fill??'') selected
                                @endif>{{ $roll_list->job_roll_name }}</option>
                            @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
                        <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                            <option value="all" @if($date_filter =="all") selected @endif>All</option>
                            <option value="today"  @if($date_filter =="today")selected @endif>Today</option>
                            <option value="week"  @if($date_filter =="week") selected @endif>This Week</option>
                            <option value="monthly"  @if($date_filter =="monthly") selected @endif>This Month</option>
                            <option value="custom_date"  @if($date_filter =="custom_date") selected @endif>Custom Date</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">Today</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">This Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_custom_from_dt_fill" name="from_date_fillter_textbox" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_custom_to_dt_fill" name="to_date_fillter_textbox" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                    <a href="{{ url('/hr_management/staff') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                    <button type="submit"  class="btn btn-primary btn-sm">Go</button>
                </div>
            </form>
        </div>
        @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
        <div class="row">
            <div class="d-flex justify-content-between align-items-center ">
                <div class="">
                    @php $perpage_count = $perpage ? $perpage : 25; @endphp
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                            @php
                            $options = [10, 25, 100, 500]; // Define available options
                            @endphp
                            @php foreach ($options as $option): @endphp
                            <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                @php echo $option; @endphp
                            </option>
                            @php endforeach; @endphp
                        </select>
                    </div>
                </div>
                <div class="">
                    <form id="filter_form" method="POST" action="/hr_management/staff">
                        @csrf
                        <div class="d-flex align-items-center gap-2">
                            <div class="">
                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                            <input type="hidden" name="filter_on" value="1">
                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />
                            <input
                                type="text"
                                class="form-control"
                                id="search_filter" name="staff_fill" value="{{ $staff_fill ?? "" }}"
                                placeholder="Enter Staff - Name/Nick/Mobile"
                            />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" >Search</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Staff</th>
                            <th class="min-w-100px">Email ID / Mobile</th>
                            <th class="min-w-100px">Job Position</th>
                            <th class="min-w-100px">Staff Role</th>
                            <th class="min-w-80px">Salary</th>
                            <th class="min-w-50px">Status</th>
                            <th class="min-w-80px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        @if (count($staff) > 0)
                        @foreach ($staff as $slist)
                        @csrf
                            <tr>
                                <td>
                                    <div class="d-flex  px-1">
                                    @if ($slist->staff_image != '' && file_exists(public_path('staff_images/' .$slist->staff_image)))
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle" data-kt-image-input="true" >
                                                <img src="{{ asset('staff_images/' . $slist->staff_image) }}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                            </div>
                                        </div>
                                    @else
                                        <div class="symbol symbol-35px me-2">
                                            @php
                                            $initial = strtoupper(substr($slist->staff_name, 0, 1)); // Only keeps and
                                            // capitalizes the first
                                            echo $helper->name_image($initial, $slist->gender);
                                            @endphp
                                        </div>
                                    @endif
                                        <div class="mb-0">
                                            <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">{{ $slist->staff_name }}</label>
                                            <div class="d-block">
                                                <div class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Nick Name"> {{ $slist->nick_name }}</div>
                                                 @if($slist->notice_check == 1)
                                                    <label class="fs-7 fw-semibold bg-danger text-white px-1 rounded animation-blink" >Notice Period</label>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <label class="fs-7 text-black fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $slist->email_id }}">{{ $slist->email_id }}</label>
                                    <div class="d-block">
                                        <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile No">{{ $slist->mobile_no }}</label>
                                    </div>
                                </td>
                                <td>
                                    <label class="badge fs-7 text-white fw-bold rounded" style="background-color:#5f2c70;"> 
                                        @php
                                        $position = $helper->get_position_id($slist->position_role);
                                        $positionName = $position ? $position->job_position_name : '-';
                                        echo $positionName;
                                        @endphp
                                    </label>
                                </td>
                                <td>
                                    <label class="badge fs-7 text-white fw-bold rounded" style="background-color:#577dad;"> 
                                    {{$slist->role_name ?? '-'}}
                                    </label>
                                </td>
                                <td align="right">
                                    <label class="badge bg-success fs-8 text-black fw-bold mb-2">
                                        <span class=" mdi mdi-currency-rupee text-black fw-bold fs-8"></span>
                                        <span class="fs-7">{{ $slist->basic_salary }}</span>
                                    </label>
                                </td>
                                <td>
                                    <label class="switch switch-square">
                                        <input type="checkbox" class="switch-input" {{ $slist->staff_status == 0 ? 'checked': '' }}  onchange="updatelevelStatus('{{ $slist->sno }}', this.checked)" />
                                        <span class="switch-toggle-slider">
                                            <span class="switch-on"></span>
                                            <span class="switch-off"></span>
                                        </span>
                                    </label>
                                </td>
                                <td>
                                    @php
                                        $encryptedValue = $helper->encrypt_decrypt($slist->sno, 'encrypt');
                                        $url = url('/hr_management/staff/staff_view/' . $encryptedValue);
                                         $edit_url = url('/manage_staff/staff_edit/' . $encryptedValue);
                                    @endphp
                                    <span class="text-end">
                                        <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-end">
                                            @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff" onclick="staff_view_func('{{$slist->sno}}')">
                                                <span><i class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                                <span>View</span>
                                            </a>
                                            @endif
                                            @if(auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                                            <a href="{{ $edit_url }}" class="dropdown-item">
                                                <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                                <span>Edit</span>
                                            </a>
                                            @endif
                                            @if(auth()->user()->hasPermission($module_name, 'Delete', $menu_name))
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_staff" onclick="confirmDelete('{{ $slist->sno }}', '{{ $slist->staff_name }}', '{{ $slist->staff_id }}')">
                                                <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i></span>
                                                <span>Delete</span>
                                            </a>
                                            @endif
                                            @if($slist->notice_check != 1)
                                                <a href="javascript:;" class="dropdown-item" style="background-color: #ec8282;"
                                                    onclick="departure_data_fetch_func({{ $slist }})">
                                                    <span><i class="mdi mdi-exit-to-app fs-3 text-black me-1"></i></span>
                                                    <span>Exit</span>
                                                </a>
                                            @endif
                                            @if($slist->notice_check == 1)
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_extend_notice_period" onclick="editNoticeDate('{{ $slist->sno }}')" >
                                                    <span><i class="mdi mdi-account-arrow-right fs-3 text-black me-1"></i></span>
                                                    <span>Extend Notice Period</span>
                                                </a>
                                            @endif
                                        </div>
                                    </span>
                                </td>
                            </tr>
                        @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $staff->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
        @endif
    </div>
</div>

<!--begin::Modal - Extend Notice Period -->
<div class="modal fade" id="kt_modal_extend_notice_period" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6 text-center">
                    <span class="d-inline-block px-2 py-1 bg-label-danger rounded fs-4 fw-bold">
            
                        Extend Notice Period
                    </span>
                </div>
            
                <div class="row mt-4">
                    <!-- Profile Image -->
                    <div class="col-lg-3 text-center mb-4 mb-lg-0">
                        <img src="{{ asset('staff_images/admin.png') }}" alt="user-avatar"
                            class="w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo" />
                    </div>
            
                    <!-- Staff Info -->
                    <div class="col-lg-9">
                        <div class="row mb-3">
                            <div class="col-4 text-dark fs-6 fw-semibold">Staff</div>
                            <div class="col-1 text-dark fs-6 fw-bold">:</div>
                            <div class="col-7 text-black fs-6 fw-bold" id="notice_staff_name">Priya</div>
                        </div>
            
                        <div class="row mb-3">
                            <div class="col-4 text-dark fs-6 fw-semibold">Nickname</div>
                            <div class="col-1 text-dark fs-6 fw-bold">:</div>
                            <div class="col-7 text-black fs-6 fw-bold" id="notice_nick_name" >Ramya</div>
                        </div>
            
                        <div class="row mb-3">
                            <div class="col-4 text-dark fs-6 fw-semibold">Date of Joining</div>
                            <div class="col-1 text-dark fs-6 fw-bold">:</div>
                            <div class="col-7 text-black fs-6 fw-bold" id="notice_joining">20-02-3020</div>
                        </div>
            
                        <div class="row mb-3">
                            <div class="col-4 text-dark fs-6 fw-semibold">Department</div>
                            <div class="col-1 text-dark fs-6 fw-bold">:</div>
                            <div class="col-7 text-black fs-6 fw-bold" id="notice_department">Journal</div>
                        </div>
                    </div>
                </div>
                <form action="{{ route('reschedule_notice_period') }}" method="POST" >
                    @csrf
                    <div class="row mt-2 mb-3">
                        <input type="hidden" name="notice_id" id="notice_id">
                        <div class="col-lg-6 mt-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Starting Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-label-info"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="notice_st_date" name="notice_st_date" placeholder="Select Date" disabled
                                    class="form-control area_andarkottaram bg-label-info"  >
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Ending Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="notice_re_end" name="notice_re_end" placeholder="Select Date"
                                    class="form-control area_andarkottaram" readonly>
                            </div>
                        </div>
                        <div class="col-lg-12 mt-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                            <textarea class="form-control" rows="1" id="notice_re_reason" name="notice_re_reason" placeholder="Enter Reason"></textarea>
                            <div id="dep_reason_err" class="text-danger"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="submit" class="btn btn-primary me-3 waves-effect waves-light" id="departure_submit_butt">Extend Notice
                            Period</button>
                        <button type="reset" class="btn btn-secondary waves-effect waves-light" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Extend Notice Period-->

<!--begin::Modal exit staff--->
<div class="modal fade" id="kt_modal_exit_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form id="cus_drp_form" action="{{ route('Departure_staff') }}" method="POST" enctype="multipart/form-data"
                autocomplete="off" onsubmit="return status_change_validation()">
                @csrf
                <div class="modal-body pt-0 pb-6 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Exit Status</h3>
                    </div>
                    <div id="staff_data_view"></div>
                    <input type="hidden" id="sts_change_id" name="sts_change_id" />
                    <div class="row mt-2">
                        <div class="col-lg-12 d-flex flex-wrap align-items-center gap-3">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="depature_status" id="notice_period"
                                    value="4" onchange="departure_func(4);" checked />
                                <label class="form-check-label" for="notice_period">Notice Period</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="depature_status" id="relieve"
                                    value="5" onchange="departure_func(5);" />
                                <label class="form-check-label" for="relieve">Relieve</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="depature_status" id="upscond"
                                    value="6" onchange="departure_func(6);" />
                                <label class="form-check-label" for="franchise">Abscond</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="depature_status" id="terminate"
                                    value="7" onchange="departure_func(7);" />
                                <label class="form-check-label" for="franchise">Terminate</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="depature_status" id="internal_transfer"
                                    value="8" onchange="departure_func(8);" />
                                <label class="form-check-label" for="internal_transfer">Internal Transfer</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mt-2" style="display:none;" id="date_view">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Last Attend Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="staff_last_date" name="staff_last_date" placeholder="Select Date"
                                class="form-control common_date_class" readonly value="<?php echo date(" d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mt-2" style="display:none;" id="starting_date">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Starting Date<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="notice_start_date" name="notice_start_date"
                                    placeholder="Select Date" class="form-control common_date_class" readonly
                                    value="<?php echo date(" d-M-Y"); ?>" />
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2" style="display:none;" id="ending_date">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Ending Date<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="notice_end_date" name="notice_end_date" placeholder="Select Date"
                                    class="form-control common_date_class" readonly />
                            </div>
                            <div id="notice_end_date_err" class="text-danger"></div>
                        </div>
                    </div>
                    <div class="col-lg-12 mt-2" style="display:none;" id="reason_add">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="dep_reason" name="dep_reason"
                            placeholder="Enter Reason"></textarea>
                        <div id="dep_reason_err" class="text-danger"></div>
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-center align-items-center mb-4">
                    <button type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - exit staff-->

<div class="modal fade" id="kt_modal_lead_balance" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-6 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Exit Status</h3>
                    </div>
                    <div id="lead_balance_staff_data_view"></div>
                    <input type="hidden" id="sts_change_id" name="sts_change_id" />
                    <div class="swal2-html-container text-center px-3 py-3" id="delete_message" style="display: block;">
                        <div class="border rounded-3 px-4 py-5 bg-label-success">
                            <h5 class="text-black mb-3 fw-bold">Pending Lead Transfers</h5>
                            <p class="mb-0 fs-6 text-black fw-bold">
                                <label class="text-center mb-3"><span class="fw-bold fs-2 text-danger badge bg-label-danger rounded animation-blink me-2" id="lead_counts">00</span></label><br> leads assigned to <span class="text-info fs-5 fw-semibold" id="exit_staff_name">-</span> have not been transferred.<br> Please take action or provide further instruction.
                            </p>
                        </div>
                    </div>
                    <div id="loader"
                        style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(255,255,255,0.7); z-index:9999; text-align:center; padding-top:20%;">
                        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <div>Converting, please wait...</div>
                    </div>
                    <div id="bulk_staff_assign_container" style="display: none">
                        <form id="bulk_staff_convert_form">
                            @csrf
                            <input type="hidden" name="lead_count_staff" id="lead_count_staff">
                            <input type="hidden" name="created_by" id="created_by">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Assign Staff<span class="text-danger">*</span></label>
                                <select class="select3 form-select" id="staff_assgn_bulk" name="staff_assgn_bulk">
                                </select>
                                <div class="text-danger" id="aptment_err"></div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center pt-4 pb-2">
                                <button type="submit" class="btn btn-primary px-4 fw-semibold">Convert</button>
                            </div>
                        </form>
                    </div>
                    <div id="lead_balance_button" style="display: block">
                        <div class="d-flex justify-content-center align-items-center gap-3 pt-4 pb-2">
                            <button type="button" class="btn btn-danger px-4 fw-semibold shadow" id="bulk_transfer_btn">
                                <i class="mdi mdi-transfer me-1"></i> Transfer All
                            </button>
                            <a href="{{ url('/manage_lead') }}" class="btn btn-secondary px-4 fw-semibold shadow">
                                <i class="mdi mdi-account-switch me-1"></i> Transfer Manually
                            </a>
                        </div>
                    </div>
                </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<!--begin::Modal - View Staff-->
<div class="modal fade" id="kt_modal_view_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">View Staff Details <span class="fs-4 fw-semibold bg-danger text-white px-2 ms-2 py-1 rounded" id="notice_check" style="display: none">Notice Period</span></h3>
                </div>
                 <div id="staff_viewContainer"></div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Staff-->


<!--begin::Modal - Delete Staff-->
<div class="modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="delete_message" style="display: block;">Are you sure you want to
                delete Staff ?
                <div class="d-block fw-bold fs-5 py-2 mt-6">
                    <label>Naveen S</label>
                    <span class="ms-2 me-2">-</span>
                    <label>ETS-0001/2</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-6 pb-4">
                <button type="submit" class="btn btn-danger me-3"  onclick="deleteStaff()">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


<style>
  /* Customize Toastr container */
  .toast {
      background-color: #39484f;
  }

  /* Customize Toastr notification */
  .toast-success {
      background-color: green;
  }

  /* Customize Toastr notification */
  .toast-error {
      background-color: red;
  }

</style>
<script>
  // Display Toastr messages
      @if (Session::has('toastr'))
          var type = "{{ Session::get('toastr')['type'] }}";
          var message = "{{ Session::get('toastr')['message'] }}";
          toastr[type](message);
      @endif
</script>

<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>

<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
  function sort_filter(val) {
    if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#filter_form').submit();
    } else {
      $('.sorting_filter_class').val(25);
      $('#filter_form').submit();
    }
  }
</script>

<script>
    function confirmDelete(id, name, ids) {
        console.log(name)
            document.querySelector('#kt_modal_delete_staff .btn-danger').setAttribute('data-id', id);
            $('#delete_message').html(
                'Are you sure you want to delete Staff <br> <b class="text-danger fw-bold fs-4">' +
                name +
                '</b> ?');
        }

        function deleteStaff() {
            var categoryId = document.querySelector('#kt_modal_delete_staff .btn-danger').getAttribute('data-id');

            fetch('/staff_delete/' + categoryId, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success(data.message);
                        location.reload();
                    } else {
                        toastr.error(data.error_msg);
                    }
                })
                .catch(error => {

                });
        }
</script>
<script>
    function updatelevelStatus(TypeId, isChecked) {
            const status = isChecked ? 0 : 1;
            fetch(`/staff_status/${TypeId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Staff status Updated successfully!');
                    }
                })
                .catch(error => {});
        }
</script>

<script>
    function formatDate(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }
</script>
<script>
    function getExperienceCount(startDate, endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);

        let years = end.getFullYear() - start.getFullYear();
        let months = end.getMonth() - start.getMonth();

        if (months < 0) {
            years -= 1;
            months += 12;
        }

        let expCount = '';
        if (years > 0) {
            expCount += `${years} Year${years > 1 ? 's' : ''}`;
        }
        if (months > 0) {
            if (expCount) expCount += ' ';
            expCount += `${months} Month${months > 1 ? 's' : ''}`;
        }

        return expCount || '0 Month';
        }
</script>
<script>
      function staff_view_func(staff_id) {

         $.ajax({
            url: '/staff_view/' + staff_id, // URL to your route
            type: 'GET',
            success: function(response) {
                if(response.success) {
                    let studentTableBody = $('#staff_viewContainer');
                    studentTableBody.empty();
                    if(response.data){
                        let staff = response.data;
                        let img_src = '';
                        let staff_initial = '';

                        if (staff.staff_image) {
                            img_src = `{{ asset('staff_images/') }}/${staff.staff_image}`;
                        } else {
                            img_src = ''; // No image to show
                        }

                        // Get staff initial if name exists
                        if (staff.staff_name && !staff.staff_image) {
                            staff_initial = staff.staff_name.charAt(0).toUpperCase();
                        }

                      if(response.data.notice_check == 1) {
                        $('#notice_check').show();
                      } else {
                        $('#notice_check').hide();
                      }
                      
                        let studentRow = `
                           <h5 class="title fw-bold mb-3">Basic Information</h5>
                            <div class="row mt-4">
                                <div class="col-lg-6">
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Staff Photo</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">
                                            <div class="row">
                                                <div class="align-items-sm-center gap-4">
                                                    ${img_src ? `
                                                    <img src="${img_src}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid"
                                                        id="uploadedlogo" />
                                                    ` : `
                                                    <div class="d-flex align-items-center justify-content-center bg-label-info rounded"
                                                        style="width: 100px; height: 100px; font-size: 36px; font-weight: bold;">
                                                        ${staff_initial}
                                                    </div>
                                                    `}
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Staff</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.staff_name}</label>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Branch</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.branch_name}</label>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Department</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.department_name}</label>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Division</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.division_name}</label>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Gender</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.gender== '1 ' ? 'Male' :(staff.gender== '2' ?'Female':'Others')}</label>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Date of Birth</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.dob ? formatDate(staff.dob) :'-'}</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Mobile Number</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.mobile_no}</label>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Alternate Number</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.alternative_no || '-'}</label>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <div class="col-7">
                                            <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${staff.email_id || '-'}">${staff.email_id || '-'}</div>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Marital Status</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.martial_status || '-'}</label>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Contact Person</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.contact_person_name}</label>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Contact Person No</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.contact_person_no}</label>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                        <label class="col-7 text-black fs-6 fw-bold">${staff.address || '-'}</label>
                                    </div>`;

                                    if(response.data.notice_check == 1) {
                                        studentRow += `
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Notice Period Start Date</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.notice_start_date ? formatDate(staff.notice_start_date) : '-'}</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Notice Period End Date</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.notice_end_date ? formatDate(staff.notice_end_date) : '-'}</label>
                                        </div>`;
                                    }
                                studentRow += `
                                    </div>
                            </div>
                            <h5 class="title mt-4 fw-bold mb-3">
                                <span>Work Information</span>
                                <span class="ms-1 me-1">-</span>
                                ${staff.exp_type == 1 ?
                                    `<span class="badge bg-warning text-black fs-6 fw-semibold">Fresher</span>` :
                                    `<span class="badge bg-info text-white fs-6 fw-semibold">Experience</span>`}
                            </h5>`;
                       
                                if(staff.exp_type == 2  && response.workInfo.length > 0){
                                    response.workInfo.forEach(function(work) {
                                   const expCount = getExperienceCount(work.work_start_date, work.work_end_date);
                                    studentRow += `<div class="row mt-4">
                                                    <div class="col-lg-6">
                                                        <div class="row mb-4">
                                                            <label class="col-4 text-dark fs-6 fw-semibold">Position</label>
                                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                            <label class="col-7 text-black fs-6 fw-bold">${work.position || '-'}</label>
                                                        </div>
                                                        <div class="row mb-4">
                                                            <label class="col-4 text-dark fs-6 fw-semibold">Company</label>
                                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                            <label class="col-7 text-black fs-6 fw-bold">${work.company_name || '-'}</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="row mb-4">
                                                            <label class="col-4 text-dark fs-6 fw-semibold">Experience</label>
                                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                            <label class="col-7 text-black fs-6 fw-bold">${expCount || '0 Month'}</label>
                                                        </div>
                                                        <div class="row mb-4">
                                                            <label class="col-4 text-dark fs-6 fw-semibold">Start / End Date</label>
                                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                            <label class="col-7 text-black fs-6 fw-bold">
                                                                <span class="text-success">${work.work_start_date ? formatDate(work.work_start_date) :'-'}</span>
                                                                <span class="ms-1 me-1">to</span>
                                                                <span class="text-danger">${work.work_end_date ? formatDate(work.work_end_date) :'-'}</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr class="mt-2 mb-2 border-gray-300i">
                                            `
                                    });
                                }
                          
                            
                           studentRow +=   `
                                <h5 class="title mt-4 fw-bold mb-3">Designation Information</h5>
                                    <div class="row mt-4">
                                        <div class="col-lg-6">
                                            <div class="row mb-4">
                                                <label class="col-4 text-dark fs-6 fw-semibold">Nick Name</label>
                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                <label class="col-7 text-black fs-6 fw-bold">${staff.nick_name || '-'}</label>
                                            </div>
                                            <div class="row mb-4">
                                                <label class="col-4 text-dark fs-6 fw-semibold">Date of Joining</label>
                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                <label class="col-7 text-black fs-6 fw-bold">${staff.date_of_joining ? formatDate(staff.date_of_joining) :'-'}</label>
                                            </div>
                                            <div class="row mb-4">
                                                <label class="col-4 text-dark fs-6 fw-semibold">Job Position</label>
                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                <label class="col-7 text-black fs-6 fw-bold">${staff.job_position_name || '-'}</label>
                                            </div>
                                            <div class="row mb-4">
                                                <label class="col-4 text-dark fs-6 fw-semibold">Job Role</label>
                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                <label class="col-7 text-black fs-6 fw-bold">${staff.role_name || '-'}</label>
                                            </div>
                                            <div class="row mb-4">
                                                <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Description</label>
                                                <label class="col-12 text-black fs-6 text-justify fw-bold text-wrap">${staff.description || '-'}</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-4">
                                                <label class="col-4 text-dark fs-6 fw-semibold">Username</label>
                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                <label class="col-7 text-black fs-6 fw-bold">${staff.user_name || '-'}</label>
                                            </div>
                                            <div class="row mb-4">
                                                <label class="col-4 text-dark fs-6 fw-semibold">Password</label>
                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                <label class="col-7 text-black fs-6 fw-bold">${staff.password || '-'}</label>
                                            </div>
                                            <div class="row mb-4">
                                                <label class="col-4 text-dark fs-6 fw-semibold">Basic Salary</label>
                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                <label class="col-7 fs-6 fw-bold">
                                                    <span class="badge bg-success fw-semibold fs-7 text-black">
                                                        <span class="mdi mdi-currency-rupee text-black fw-bold"></span>
                                                        <span class="fs-6">${staff.basic_salary || '0'}</span>
                                                    </span>
                                                </label>
                                            </div>
                                            <div class="row mb-4">
                                                <label class="col-4 text-dark fs-7 fw-semibold">Shift Time</label>
                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                <label class="col-7 text-dark fs-6 fw-bold text-truncate mw-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${staff.shift_times_lab}">
                                                ${staff.shift_times_lab}
                                                </label>
                                            </div>
                                            <div class="row mb-4">
                                                <label class="col-4 text-dark fs-6 fw-semibold">Per Hour Cost</label>
                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                <label class="col-7 text-black fs-6 fw-bold">
                                                    <span class="mdi mdi-currency-rupee text-black fw-bold"></span>
                                                    <span class="text-black fw-bold">${staff.per_hour_cost || '0'}</span>
                                                </label>
                                            </div>`

                    studentRow += `
                            <div class="row mb-4">
                                <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Attachment</label>
                                <div class="col-12 mb-1">
                                    <div class="border border-gray-600i border-dashed rounded py-1 px-1">
                                        <div class="d-flex mb-1 align-items-center flex-wrap">
                                            ${
                                            staff.attachment && staff.attachment.length > 0
                                            ? staff.attachment.map(file => {
                                            const fileExt = file.split('.').pop().toLowerCase();
                                            const fileUrl = `{{ asset('staff_attachments/') }}/staff_${staff.sno}/${file}`;
                            
                                            let preview = '';
                            
                                            if (['jpg', 'jpeg', 'png', 'gif'].includes(fileExt)) {
                                            // ✅ Image Preview
                                            preview = `
                                            <img src="${fileUrl}" alt="Image" class="w-75px h-75px rounded border" style="object-fit: cover;" />
                                            `;
                                            } else if (['mp4', 'webm', 'ogg'].includes(fileExt)) {
                                                preview = `
                                                <video class="w-75px h-75px rounded border" controls>
                                                    <source src="${fileUrl}" type="video/${fileExt}">
                                                    Your browser does not support the video tag.
                                                </video>
                                                `;
                                                } else if (fileExt === 'pdf') {
                                                // 🧾 PDF Icon
                                                preview = `<img src="{{ asset('assets/phdizone_images/def_pdf.png') }}" class="w-75px h-75px" />`;
                                                } else {
                                                // 🧾 Generic File Icon
                                                preview = `<img src="{{ asset('assets/phdizone_images/def_doc.png') }}" class="w-75px h-75px" />`;
                                                }
                            
                                                return `
                                                <div class="me-2 mb-2 text-center">
                                                    <div class="d-block">
                                                        ${preview}
                                                    </div>
                                                    <a href="${fileUrl}" download class="d-block text-muted small mt-1"
                                                        style="max-width: 80px; word-wrap: break-word;">Download</a>
                                                </div>`;
                                                }).join('')
                                                : '<p class="text-muted ms-2">No attachments available.</p>'
                                                }
                                        </div>
                                    </div>
                                </div>
                            </div>`;
                    studentRow +=    `</div>
                                    </div>
                                    `;
                        studentTableBody.append(studentRow);
                    }

                } else {
                    console.error('Error: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('An error occurred while fetching the Staff data.');
            }
        });
    }
</script>

<script>
    function departure_data_fetch_func(data){
        console.log(data);

        const departmentId = Number(data.department_id);
        const leadsCount = Number(data.leads_count);
        
        // Sales Staff lead Balance
        if (departmentId === 1 && leadsCount > 0) {

            let image = '';
            if (data.staff_image) {
            var imgUrl = "{{ asset('staff_images/') }}/" + data.staff_image;
            image = `<img src="${imgUrl}" alt="user-avatar" class="image-input-wrapper w-60px h-60px" id="uploadedlogo" />`;
            } else if (data.cus_gender == 1 || data.cus_gender === '1') {
            image = `<img src="{{ asset('assets/eapl_images/user_1.png') }}" alt="user-avatar"
                class="image-input-wrapper w-60px h-60px" id="uploadedlogo" />`;
            } else if (data.cus_gender == 2 || data.cus_gender === '2') {
            image = `<img src="{{ asset('assets/eapl_images/user_2.png') }}" alt="user-avatar"
                class="image-input-wrapper w-60px h-60px" id="uploadedlogo" />`;
            }
            var html = `<div class="row mt-4">
                <input type="hidden" id="sts_change_sno" name="sts_change_sno" value="${data.sno}" />
            
                <div class="col-lg-3 mb-2">
                    <div class="row">
                        <div class="align-items-sm-center gap-4">
                            ${image}
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 mb-2">
                    <div class="row mb-1">
                        <label class="col-4 text-dark fs-7 fw-semibold">Staff Name</label>
                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                        <label class="col-7 text-dark fs-6 fw-bold">${data.staff_name}</label>
                    </div>
                    <div class="row mb-1">
                        <label class="col-4 text-dark fs-7 fw-semibold">Nick Name</label>
                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                        <label class="col-7 text-dark fs-6 fw-bold">${data.nick_name}</label>
                    </div>
                    <div class="row mb-1">
                        <label class="col-4 text-dark fs-7 fw-semibold">Date of Joining</label>
                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                        <label class="col-7 text-dark fs-6 fw-bold">${formatDate(data.date_of_joining)}</label>
                    </div>
                    <div class="row mb-1">
                        <label class="col-4 text-dark fs-7 fw-semibold">Department</label>
                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                        <label class="col-7 text-dark fs-6 fw-bold">
                            <span class="badge bg-info">${data.department_name}</span></label>
                    </div>
                </div>
            </div>`;
            document.getElementById('lead_balance_staff_data_view').innerHTML = html;
            $('#exit_staff_name').html(data.staff_name);
            document.getElementById('lead_counts').textContent = leadsCount;
            const leadModal = new bootstrap.Modal(document.getElementById('kt_modal_lead_balance'));
            leadModal.show();

            var leadBalanceButton = document.getElementById('lead_balance_button');

            // Hide Buttons On Bulk Transfer
            document.getElementById('bulk_transfer_btn').addEventListener('click', (e) => {
                leadBalanceButton.style.setProperty('display', 'none', 'important');
                document.getElementById('bulk_staff_assign_container').style.setProperty('display', 'block', 'important');
            });

            const currentStaffId = data.sno;
            $('#lead_count_staff').val(data.leads_count);
            $('#created_by').val(data.sno);
            

            $.ajax({
                url: '/staff_list_lead_balance',
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    const $select = $('#staff_assgn_bulk');
                    $select.empty();

                    $select.append(`<option value="">Select Assign Staff</option>`);

                    (data.data || []).forEach(staff => {
                        if(staff.sno !== currentStaffId) {
                            $select.append(`<option value="${staff.sno}">${staff.staff_name}</option>`);
                        }
                    });

                    $select.trigger('change');
                },
                error: function () {
                    $('#aptment_err').text('Failed to load staff list.');
                }
            });
        } else {

            let image = '';
            if (data.staff_image) {
            var imgUrl = "{{ asset('staff_images/') }}/" + data.staff_image;
            image = `<img src="${imgUrl}" alt="user-avatar" class="image-input-wrapper w-60px h-60px" id="uploadedlogo" />`;
            } else if (data.cus_gender == 1 || data.cus_gender === '1') {
            image = `<img src="{{ asset('assets/eapl_images/user_1.png') }}" alt="user-avatar"
                class="image-input-wrapper w-60px h-60px" id="uploadedlogo" />`;
            } else if (data.cus_gender == 2 || data.cus_gender === '2') {
            image = `<img src="{{ asset('assets/eapl_images/user_2.png') }}" alt="user-avatar"
                class="image-input-wrapper w-60px h-60px" id="uploadedlogo" />`;
            }
            var html = `<div class="row mt-4">
                <input type="hidden" id="sts_change_sno" name="sts_change_sno" value="${data.sno}" />
            
                <div class="col-lg-3 mb-2">
                    <div class="row">
                        <div class="align-items-sm-center gap-4">
                            ${image}
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 mb-2">
                    <div class="row mb-1">
                        <label class="col-4 text-dark fs-7 fw-semibold">Staff Name</label>
                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                        <label class="col-7 text-dark fs-6 fw-bold">${data.staff_name}</label>
                    </div>
                    <div class="row mb-1">
                        <label class="col-4 text-dark fs-7 fw-semibold">Nick Name</label>
                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                        <label class="col-7 text-dark fs-6 fw-bold">${data.nick_name}</label>
                    </div>
                    <div class="row mb-1">
                        <label class="col-4 text-dark fs-7 fw-semibold">Date of Joining</label>
                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                        <label class="col-7 text-dark fs-6 fw-bold">${formatDate(data.date_of_joining)}</label>
                    </div>
                    <div class="row mb-1">
                        <label class="col-4 text-dark fs-7 fw-semibold">Department</label>
                        <label class="col-1 text-dark fs-6 fw-bold">:</label>
                        <label class="col-7 text-dark fs-6 fw-bold">
                            <span class="badge bg-info">${data.department_name}</span></label>
                    </div>
                </div>
            </div>`;
            document.getElementById('staff_data_view').innerHTML = html;

            const exitModal = new bootstrap.Modal(document.getElementById('kt_modal_exit_staff'));
            exitModal.show();
        }

    
  }

  departure_func(4);

  function departure_func(val) {
    // Fetch elements required for all conditions
    $('#sts_change_id').val(val);
    $('#dep_reason_err').html('');
    $('#notice_end_date_err').html('');
    var reason_add = document.getElementById("reason_add");
    var date_view = document.getElementById("date_view");
    var starting_date = document.getElementById("starting_date");
    var ending_date = document.getElementById("ending_date");
    // Hide all elements initially
    reason_add.style.display = "none";
    date_view.style.display = "none";
    starting_date.style.display = "none";
    ending_date.style.display = "none";
    // Handle specific conditions based on `val`
    switch (val) {
        case 4: // Show both dates and reason
            starting_date.style.display = "block";
            ending_date.style.display = "block";
            reason_add.style.display = "block";
            $('#departure_submit_butt').html('Notice Period');
            break;
        case 5: // Show reason only
            reason_add.style.display = "block";
            $('#departure_submit_butt').html('Relive');
            break;
        case 6: // Show reason and date view only
            reason_add.style.display = "block";
            date_view.style.display = "block";
            $('#departure_submit_butt').html('Abscond');
            break;
        case 7: // Show reason only
            reason_add.style.display = "block";
            $('#departure_submit_butt').html('Terminate');
            break;
        case 8: // Show reason only
            reason_add.style.display = "block";
            $('#departure_submit_butt').html('Internal Transfer');
            break;
    }
  }
  function status_change_validation(){
    var err = 0;
    var sts_change_id = $('#sts_change_id').val();
    if(sts_change_id==4){
      var notice_end_date = $('#notice_end_date').val().trim();
      if(notice_end_date==''){
        $('#notice_end_date_err').html('Notice end date is requered..!');
        err++;
      }else{
        $('#notice_end_date_err').html('');
      }
    }

    var dep_reason = $('#dep_reason').val().trim();
    if(dep_reason==''){
      $('#dep_reason_err').html('Enter Reason is requered..!');
      err++;
    }else{
      $('#dep_reason_err').html('');
    }
    return err===0;
  }
</script>

<script>
    $(document).ready(function() {
        $('#bulk_staff_convert_form').on('submit', function(e) {
            e.preventDefault(); // prevent normal form submit
            
            // Show loader
            $('#loader').show();

            // Collect form data
            var formData = $(this).serialize();

            $.ajax({
            url: "{{ route('convert_bulk_transfer_staff_list') }}",  // Laravel route for form POST
            method: 'POST',
            data: formData,
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}" // Laravel CSRF token
            },
            success: function(response) {
                $('#loader').hide();

                if (response.status === 200) {
                toastr.success(response.message);
                } else {
                toastr.error(response.message);
                }

                setTimeout(() => location.reload(), 1000);

                // OR display a custom message
                // alert('Sales Staff Converted Successfully!');
            },
            error: function(xhr) {
                $('#loader').hide();
                
                // Attempt to show any Laravel error response
                try {
                    var err = JSON.parse(xhr.responseText);
                    toastr.error(err.message || 'Something went wrong.');
                } catch (e) {
                    toastr.error('An unexpected error occurred.');
                }
            }
            });
        });
    });
    $(document).ready(function() {
        var isRtl = false;

        // Initialize datepicker once
        $('.area_andarkottaram').datepicker({
            todayHighlight: true,
            autoclose: true,
            format: 'd-M-yyyy',
            orientation: isRtl ? 'auto right' : 'auto left',
            startDate: new Date() // prevent past dates
        });
    });

    function formatDateToPicker(dateStr) {
        // dateStr format: yyyy-mm-dd
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        var parts = dateStr.split('-');
        if(parts.length === 3){
            var day = parseInt(parts[2], 10);
            var month = months[parseInt(parts[1], 10) - 1];
            var year = parts[0];
            return day + '-' + month + '-' + year;
        }
        return dateStr;  // fallback
    }
    function editNoticeDate(id) {
        $.ajax({
            url: `/edit_notice_date/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(res) {
                if (res.status === 200) {
                    $('#notice_id').val(res.data.sno);
                    $('#notice_staff_name').html(res.data.staff_name);
                    $('#notice_nick_name').html(res.data.nick_name);
                    $('#notice_joining').html(res.data.date_of_joining);
                    $('#department_name').html(res.data.department_name);
                    $('#notice_st_date').val(res.data.notice_start_date);
                    // $('#notice_re_end').val(res.data.notice_end_date);
                    $('#notice_re_reason').val(res.data.dep_reason);

                    var formattedDate = formatDateToPicker(res.data.notice_end_date);
                    $('#notice_re_end').datepicker('update', formattedDate);

                } else {
                    console.error('Data Fetching Failed!');
                }
            },
            error: function(err) {
                console.error('Data Fetching Failed: ', err);
            }
        });
    }
</script>

@endsection