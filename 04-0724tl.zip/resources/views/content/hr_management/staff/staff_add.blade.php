@extends('layouts/layoutMaster')

@section('title', 'Create Staff')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/tagify/tagify.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/tagify/tagify.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite('resources/assets/js/forms_tagify.js')
    @vite('resources/assets/js/forms_file_upload.js')
@endsection

@section('content')
    <!-- Staff Add -->
    @php
        $helper = new \App\Helpers\Helpers();
    @endphp

    @if (session('branch_id_ses'))
        @php
            $auth_branch_id = session('branch_id_ses');
        @endphp
    @else
        @php
            $auth_branch_id = auth()->user()->branch_id ?? 1;
        @endphp
    @endif
    <div class="card mb-2">
        <div class="card-header border-bottom pb-1">
            <h5 class="card-title mb-1">Create Staff</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-black opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">HR Management</a>
                    </li>
                    <span class="text-black opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Manage Staff</a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Staff Basic Information -->
    <form id="addStaffForm" method="POST" action="{{ route('add_staff') }}" enctype="multipart/form-data"
        autocomplete="off">
        @csrf
        <div class="card mb-2 px-4 py-2">
            <h5 class="title mt-4 fw-bold">Basic Information</h5>
            <div class="row mt-4">
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                    <select class="select3 form-select" id="branch_name" name="branch_name"
                        onchange="get_department(this.value)" disabled>
                        <option value="">Select Branch</option>
                        <optgroup label="Branch" class="fw-bold">
                            @foreach ($branch_list as $blist)
                                @if ($blist->branch_type == 1)
                                    <option value="{{ $blist->sno }}">{{ $blist->branch_name ?? '-' }}</option>
                                @endif
                            @endforeach
                        </optgroup>
                        <optgroup label="Franchise" class="fw-bold">
                            @foreach ($branch_list as $flist)
                                @if ($flist->branch_type == 2)
                                    <option value="{{ $flist->sno }}">{{ $flist->franchise_name ?? '-' }}</option>
                                @endif
                            @endforeach
                        </optgroup>
                    </select>
                    <input type="hidden" name="auth_branch_id" id="auth_branch_id" value="{{ $auth_branch_id }}" />
                    <div class="text-danger" id="branch_name_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                    <select class="select3 form-select" name="department_id" id="department_id"
                        onchange="get_sub_department(this.value)">
                        <option value="">Select Department</option>
                    </select>
                    <div class="text-danger" id="department_id_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Division<span class="text-danger">*</span></label>
                    <select class="select3 form-select" name="division_id" id="division_id"
                        onchange="get_job_position(this.value)">
                        <option value="">Select Division</option>
                    </select>
                    <div class="text-danger" id="division_id_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" placeholder="Enter Staff Name" name="staff_name"
                        id="staff_name" maxlength="255" />
                    <div class="text-danger" id="staff_name_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold d-block">Gender<span class="text-danger">*</span></label>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="gender_male" value="1"
                            checked />
                        <label class="form-check-label" for="inlineRadio1">Male</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="gender_female" value="2" />
                        <label class="form-check-label" for="inlineRadio2">Female</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="gender_others"
                            value="3" />
                        <label class="form-check-label" for="inlineRadio3">Others</label>
                    </div>
                    <div class="text-danger" id="gender_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Date of Birth<span
                            class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="staff_dob" name="dob" placeholder="Select Date"
                            class="form-control" />
                    </div>
                    <div class="text-danger" id="staff_dob_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Mobile Number<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" placeholder="Enter Mobile Number" id="mobile_no"
                        name="mobile_no" maxlength="10"
                        oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                        onkeyup="mobile_chk(this.value)" />
                    <div class="text-danger" id="mobile_no_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                    <input type="text" class="form-control me-2" placeholder="Enter Alternate Mobile Number"
                        oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                        maxlength="10" id="alternative_no" name="alternative_no" />
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" placeholder="Enter E-Mail ID" id="email_id"
                        name="email_id" oninput=" this.value = this.value.toLowerCase();" />
                    <div class="text-danger" id="email_id_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Contact Person<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" placeholder="Enter Contact Person Name"
                        id="contact_person_name" name="contact_person_name" maxlength="255" />
                    <div class="text-danger" id="contact_person_name_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile Number<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control me-2" placeholder="Enter Contact Person Mobile Number"
                        oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                        maxlength="10" id="contact_person_no" name="contact_person_no" />
                    <div class="text-danger" id="contact_person_no_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Marital Status</label>
                    <select class="select3 form-select" id="martial_status" name="martial_status">
                        <option value="">Select Marital Status</option>
                        <option value="1">Married</option>
                        <option value="2">Un Married</option>
                    </select>
                </div>
                <div class="col-lg-4">
                    <label class="text-black mb-1 fs-6 fw-semibold">Address</label>
                    <textarea class="form-control" rows="3" placeholder="Enter Description" id="address" name="address"
                        maxlength="255"></textarea>
                    <div class="text-danger" id="address_err"></div>
                </div>
                <div class="col-lg-4">
                    <div class="row">
                        <label class="col-lg-6 text-black fs-6 fw-semibold">Staff Image</label>
                        <div class="align-items-sm-center gap-4">
                            <img src="{{ asset('assets/phdizone_images/user_2.png') }}" alt="user-avatar"
                                class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid"
                                id="staff_add" />
                            <div class="button-wrapper">
                                <div class="d-flex align-items-start mt-2 mb-2">
                                    <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0"
                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Logo">
                                        <i class="mdi mdi-tray-arrow-up"></i>
                                        <input type="file" id="upload" name="staff_add_icon" class="staff_add_cls"
                                            hidden accept="image/png, image/jpeg" />
                                    </label>
                                    <button type="button" class="btn btn-sm btn-outline-danger staff-add-reset"
                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Logo">
                                        <i class="mdi mdi-reload"></i>
                                    </button>
                                </div>
                                <div class="small">Allowed JPG, PNG. Max size of 800KB</div>
                                <div class="text-danger" id="upload_err"></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- End Staff Basic Information -->
        <!-- Staff Experience Information Start-->
        <div class="card px-4 py-2 mb-2">
            <h5 class="title mb-1 fw-bold mt-4">Work Information</h5>
            <div class="row mt-4">
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
                    <select id="staff_type" name="staff_type" class="select3 form-select" onchange="staff_func();">
                        <option value="">Select Type</option>
                        <option value="1">Fresher</option>
                        <option value="2">Experience</option>
                    </select>
                    <div class="text-danger" id="staff_type_err"></div>
                </div>
            </div>
            <div class="row" id="staff_experience" style="display: none !important;">
                <div class="form-repeater_staff_exp_add">
                    <div data-repeater-list="staff_experience">
                        <div data-repeater-item>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-3 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Position<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="position_0"
                                                name="position_[0]" placeholder="Enter Position" />
                                            <div class="text-danger" id="position_0_err"></div>
                                        </div>
                                        <div class="col-lg-3 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="company_name_0"
                                                name="company_name_[0]" placeholder="Enter Company Name" />
                                            <div class="text-danger" id="company_name_0_err"></div>
                                        </div>
                                        <!--<div class="col-lg-1 mb-3">-->
                                        <!--    <label class="text-black mb-1 fs-6 fw-semibold">Exp.Years<span class="text-danger">*</span></label>-->
                                        <!--    <input type="text" class="form-control text-center" id="year_of_experience_0" name="year_of_experience_[0] " maxlength="3"  oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" placeholder="Count" />-->
                                        <!--    <div class="text-danger" id="year_of_experience_0_err"></div>-->
                                        <!--</div>-->
                                        <div class="col-lg-2 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Start Date<span
                                                    class="text-danger">*</span></label>
                                            <div class="cursor-pointer input-group input-group-merge">
                                                <span class="input-group-text text-black"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="exper_srt_date_0" name="exper_srt_date_[0]"
                                                    class="cursor-pointer form-control text-black common_date_class "
                                                    value="<?php echo date('d-M-Y'); ?>" readonly>

                                            </div>
                                            <div class="text-danger" id="exper_srt_date_0_err"></div>
                                        </div>
                                        <div class="col-lg-2 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">End Date<span
                                                    class="text-danger">*</span></label>
                                            <div class="cursor-pointer input-group input-group-merge">
                                                <span class="input-group-text text-black"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="exper_end_date_0" name="exper_end_date_[0]"
                                                    class="cursor-pointer form-control text-black common_date_class"
                                                    value="<?php echo date('d-M-Y'); ?>" readonly>
                                            </div>
                                            <div class="text-danger" id="exper_end_date_0_err"></div>
                                        </div>
                                        <div class="col-lg-1">
                                            <a href="javascript:;"
                                                class="btn btn-outline-danger mt-6 px-1 py-2 staff_del_button"
                                                data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"
                                                id="staff_del_button" style="display: none !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-1 mt-1">
                    <button type="button" class="btn btn-primary staff_exp_add" data-bs-toggle="tooltip"
                        data-bs-placement="top" title="Add" data-repeater-create id="staff_exp_add"
                        onclick="addMoreExperience()">
                        <i class="mdi mdi-plus me-1"></i>
                    </button>
                </div>
            </div>
        </div>
        <!-- Staff Experience Information End-->
        <!-- Staff Designation Information -->
        <div class="card px-4 py-2 mb-2">
            <h5 class="title mb-1 fw-bold mt-4">Designation Information</h5>
            <div class="row mt-4">
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Nick Name<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" placeholder="Enter Nick Name" id="nick_name"
                        name="nick_name" maxlength="255" />
                    <div class="text-danger" id="nick_name_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Date of Joining<span
                            class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="staff_doj" name="date_of_joinig" placeholder="Select Date"
                            class="form-control" value="<?php echo date('d-M-Y'); ?>" />

                    </div>
                    <div class="text-danger" id="staff_doj_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Job Position<span class="text-danger">*</span></label>
                    <select class="select3 form-select" id="position_role" name="position_role">
                        <option value="">Select Job Position</option>
                    </select>
                    <div class="text-danger" id="position_role_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Role<span class="text-danger">*</span></label>
                    <select class="select3 form-select" id="role_id" name="role_id"
                        onchange="get_branch_access(this.value)">
                        <option value="">Select Role</option>
                        @php
                            $get_role_list = $helper->get_role_list();
                        @endphp
                        @foreach ($get_role_list as $rlist)
                            @if ($rlist->sno > 1)
                                <option value="{{ $rlist->sno }}">
                                    {{ $rlist->role_name }}</option>
                            @endif
                        @endforeach
                    </select>
                    <div class="text-danger" id="role_id_err"></div>
                </div>
                <div class="col-lg-4 mb-3" id="access_branch_div" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Access Branch</label>
                    <select class="select3 form-select acces_branch_id_valid" name="acces_branch_id[]"
                        id="acces_branch_id" data-placeholder="Select Access Branch" multiple>
                        @php
                            $get_branch_list = $helper->get_branch_list();
                        @endphp
                        @foreach ($get_branch_list as $br_list)
                            <option value="{{ $br_list->sno }}">
                                {{ $br_list->branch_name }}</option>
                        @endforeach
                    </select>
                    <div class="text-danger" id="multi_branch_frans_err"></div>
                </div>
                <div class="col-lg-4 mb-3" id="access_fran_div" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Access Franchise</label>
                    <select class="select3 form-select acces_branch_id_valid" name="acces_franchise_id[]"
                        id="acces_franchise_id" data-placeholder="Select Access Franchise" multiple>
                        @php
                            $get_franchise_list = $helper->get_franchise_list();
                        @endphp
                        @foreach ($get_franchise_list as $fr_list)
                            <option value="{{ $fr_list->sno }}">{{ $fr_list->franchise_name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-lg-4 mb-3">
                    <input class="form-check-input" type="checkbox" id="login_access" name="login_access"
                        value="1" onclick="login_credt_func();" />
                    <label class="text-black mb-1 fs-6 fw-semibold" id="log_cred_txt">Login Credentials</label>
                    <label class="text-black mb-1 fs-6 fw-semibold" id="usern_txt" style="display: none;">Username<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="loginuser_name" name="loginuser_name"
                        onkeyup="user_name_chk(this.value)" placeholder="Enter User Name"
                        style="display: none !important;" maxlength="255" />
                    <div class="text-danger" id="loginuser_name_err"></div>
                </div>
                <div class="col-lg-4 mb-3" id="pw_tbox" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                    <div class="form-password-toggle">
                        <div class="input-group input-group-merge">
                            <input type="password" class="form-control" placeholder="Enter Password"
                                aria-describedby="password" id="loginpassword" name="loginpassword" value=""
                                maxlength="255" />
                            <span class="input-group-text cursor-pointer"><i
                                    class="mdi mdi-eye-off-outline fs-4"></i></span>
                        </div>
                    </div>
                    <div class="text-danger" id="loginpassword_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Shift Time<span class="text-danger">*</span></label>
                    <select id="shift_time" name="shift_time" class="select3 form-select">
                        <option value="">Select Shift Time</option>
                        @foreach ($shift_time as $stlist)
                            <option value="{{ $stlist->sno }}"> {{ $stlist->shift_time_name }}
                                {{ date('h:i A', strtotime($stlist->shift_start_time)) }} -
                                {{ date('h:i A', strtotime($stlist->shift_end_time)) }}
                                Lunch {{ date('h:i A', strtotime($stlist->shift_lunch_start)) }} -
                                {{ date('h:i A', strtotime($stlist->shift_lunch_end)) }}</option>
                        @endforeach
                    </select>
                    <div class="text-danger" id="shift_time_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Employee Skill<span class="text-danger">*</span></label>
                    <select id="employee_skill" name="employee_skill" class="select3 form-select">
                        <option value="">Select Employee Skill</option>
                        @foreach ($skills as $skill)
                            <option value="{{ $skill->sno }}">{{ $skill->employee_skill }}</option>
                        @endforeach
                    </select>
                    <div class="text-danger" id="employee_skill_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Basic Salary<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" placeholder="Enter Basic Salary"
                        oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 8);" id="salary"
                        name="salary" onkeyup="get_per_hour_cost(this.value)" />
                    <div class="text-danger" id="salary_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Per Hour Cost</label>
                    <div>
                        <label class="badge bg-info text-white fs-5 px-2" id="perhour_label">0</label>
                    </div>
                    <input type="hidden" class="form-control" placeholder="Enter Per Hour Cost"
                        oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 8);" id="hour_cost"
                        name="hour_cost" />

                    <div class="text-danger" id="hour_cost_err"></div>
                </div>
            </div>
            <div class="row mt-4 px-2 py-2">
                <div class="col-lg-6">
                    <div class="row">
                        <label class="text-black fs-6 fw-semibold mt-2">Other Attachment</label>
                        <div action="/upload" class="dropzone needsclick" id="dropzone-multi">
                            <div class="dz-message needsclick fs-6">
                                <div class="text-center me-3">Drop files here or click to upload</div>
                            </div>
                            <div class="">
                                <input type="file" name="attachment[]" multiple>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="3" placeholder="Enter Description" id="description" name="description"></textarea>
                </div>
            </div>
            <div class="d-flex justify-content-end align-items-center mt-4">
                <a href="{{ url('/hr_management/staff') }}" class="btn btn-secondary me-3">Cancel</a>
                <button type="button" class="btn btn-primary" id="submit_btn" onclick="AddvalidateForm_staff()">Create
                    Staff</button>
            </div>
            <input type="hidden" name="submit_popup" id="submit_popup" data-bs-toggle="modal"
                data-bs-target="#kt_modal_confirmation_staff">
        </div>
    </form>
    <!-- End Staff Designation Information -->

    <!--begin::Modal - Confirmation Staff-->
    <div class="modal fade" id="kt_modal_confirmation_staff" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want
                    to
                    Create Staff ?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label id="create_staff_label"></label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="javascript:;" class="btn btn-primary me-3" onclick="submit_form()">Yes</a>
                    <a href="#" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Confirmation Staff-->


    <script>
        function get_branch_access(val) {
            if (val !== "") {
                $.ajax({
                    url: "{{ route('get_branch_access_role') }}",
                    type: "GET",
                    data: {
                        id: val
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            var type = response.data.manage_branch;
                            // alert(type)
                            if (type == 2) {
                                var accesss = response.data.access_head ?? 0;
                                // Show/hide divs based on access level
                                switch (accesss) {
                                    case 1:
                                        $('#access_branch_div').show();
                                        $('#access_fran_div').hide();
                                        break;
                                    case 2:
                                        $('#access_branch_div').hide();
                                        $('#access_fran_div').show();
                                        break;
                                    case 3:
                                        $('#access_branch_div').show();
                                        $('#access_fran_div').show();
                                        break;
                                    default:
                                        $('#access_branch_div').hide();
                                        $('#access_fran_div').hide();
                                        break;
                                }
                            } else {
                                $('#access_branch_div').hide();
                                $('#access_fran_div').hide();
                            }
                        } else {
                            // Optionally handle the case where access role is not available
                            $('#access_branch_div').hide();
                            $('#access_fran_div').hide();
                        }
                    },
                    error: function(error) {
                        // console.error('Error fetching branch access role:', error);
                        // alert('An error occurred while fetching access role.'); // Optional user feedback
                    }
                });
            } else {
                $('#access_branch_div').hide();
                $('#access_fran_div').hide();
            }
        }

        function get_per_hour_cost(val) {
            if (val !== "") {
                $.ajax({
                    url: "{{ route('get_per_hour_cost_staff') }}",
                    type: "GET",
                    data: {
                        amount: val
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            var data = response.data;
                            $('#hour_cost').val(data.per_hour_cost);
                            $('#perhour_label').html(data.per_hour_cost);
                        } else if (response.status === 302) {
                            // Not found: reset fields
                            $('#hour_cost').val('0');
                            $('#perhour_label').html('0');
                        }
                    },
                    error: function(xhr) {
                        if (xhr.status === 302) {
                            $('#hour_cost').val('0');
                            $('#perhour_label').html('0');
                        } else {
                            console.error('Error fetching per hour cost:', xhr);
                            alert('An unexpected error occurred.');
                        }
                    }
                });
            } else {
                $('#hour_cost').val('');
                $('#perhour_label').html('');
            }
        }
    </script>
    <script>
        $(document).ready(function() {
            var branch_id = $('#auth_branch_id').val();
            get_department(branch_id)
        });
    </script>


    <script>
        function staff_func() {
            var create_staff = document.getElementById("staff_type").value;
            var staff_experience = document.getElementById("staff_experience");
            if (create_staff == "2") {
                staff_experience.style.display = "block";
            } else {
                staff_experience.style.display = "none";
            }
        }
    </script>
    <!-- <script>
        $('.staff_exp_add').on('click', e => {
            var bt = parseFloat($('.form-repeater_staff_exp_add').length);
            let $clone = $('.form-repeater_staff_exp_add').first().clone().hide();
            $clone.insertBefore('.form-repeater_staff_exp_add:first').slideDown();
            if (bt == 1) {
                $('.staff_del_button').attr('style', 'display: block !important');
            } else {
                $('.staff_del_button').attr('style', 'display: block !important');
            }
        });

        $(document).on('click', '.form-repeater_staff_exp_add .staff_del_button', e => {
            var bt = parseFloat($('.staff_del_button').length);
            // alert(bt);
            $(e.target).closest('.form-repeater_staff_exp_add').slideUp(400, function() {
                $(this).remove()
            });
            if (bt == 2) {
                $('.staff_del_button').attr('style', 'display: none !important');
            } else {}
        });
    </script> -->

    <script>
        function login_credt_func() {
            var login_crent = document.getElementById("login_access");
            var log_cred_txt = document.getElementById("log_cred_txt");
            var usern_txt = document.getElementById("usern_txt");
            var user_name = document.getElementById("loginuser_name");
            var pw_tbox = document.getElementById("pw_tbox");

            if (login_crent.checked) {
                log_cred_txt.style.display = "none";
                usern_txt.style.display = "inline";
                user_name.style.display = "inline";
                pw_tbox.style.display = "block";
            } else {
                log_cred_txt.style.display = "inline";
                usern_txt.style.display = "none";
                user_name.style.display = "none";
                pw_tbox.style.display = "none";
            }
        }
    </script>
    <script>
        function get_department(branch_id) {
            $.ajax({
                url: "{{ route('branch_department_list') }}",
                type: "GET",
                data: {
                    branch_id: branch_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('select[name="department_id"]');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Department</option>'));
                        response.data.forEach(function(dept) {
                            selectDropdown.append($('<option></option>').attr('value', dept
                                    .sno)
                                .text(dept.department_name));
                        });
                    }
                },
                error: function(error) {
                    selectDropdown.append($(
                        '<option value="">Select Department</option>'));
                    // console.error('Error fetching course Brand:', error);
                }
            });
        }

        function get_sub_department(id) {

            $.ajax({
                url: "{{ route('get_division') }}",
                type: "GET",
                data: {
                    department_id: id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('select[name="division_id"]');
                        selectDropdown.empty();
                        selectDropdown.append($('<option value="">Select Division</option>'));
                        response.data.forEach(function(sub_dept) {
                            selectDropdown.append($('<option></option>').attr('value', sub_dept
                                .sno).text(sub_dept.division_name));
                        });
                    }
                },
                error: function(error) {
                    // console.error('Error fetching course sub categories:', error);
                }
            });

        }
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            let staff_add = document.getElementById('staff_add');
            const staff_add_fileInput = document.querySelector('.staff_add_cls'),
                staff_add_resetFileInput = document.querySelector('.staff-add-reset');
            if (staff_add) {
                const staff_add_resetImage = staff_add.src;
                staff_add_fileInput.onchange = () => {
                    if (staff_add_fileInput.files[0]) {
                        staff_add.src = window.URL.createObjectURL(staff_add_fileInput.files[0]);
                    }
                };
                staff_add_resetFileInput.onclick = () => {
                    staff_add_fileInput.value = '';
                    staff_add.src = staff_add_resetImage;
                };
            }
        });
    </script>

    <script>
        let expCounter = 1; // Initialize a counter for unique IDs

        // Function to add more experience fields
        function addMoreExperience() {

            let newExperience = `
              <div data-repeater-item>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-lg-3 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Position<span class="text-danger">*</span></label>
                                <input type="text" class="form-control"  id="position_${expCounter}" name="position_[${expCounter}]" placeholder="Enter Position" />
                                <div class="text-danger" id="position_${expCounter}_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="company_name_${expCounter}" name="company_name_[${expCounter}]" placeholder="Enter Company Name" />
                                <div class="text-danger" id="company_name_${expCounter}_err"></div>
                            </div>
                          
                            <div class="col-lg-2 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Start Date<span class="text-danger">*</span></label>
                                <div class="cursor-pointer input-group input-group-merge">
                                    <span class="input-group-text text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="exper_srt_date_${expCounter}" name="exper_srt_date_[${expCounter}]" class="cursor-pointer form-control text-black common_date_class_addMore " value="<?php echo date('d-M-Y'); ?>" readonly>
                                    
                                </div>
                                <div class="text-danger" id="exper_srt_date_${expCounter}_err"></div>
                            </div>
                            <div class="col-lg-2 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">End Date<span class="text-danger">*</span></label>
                                <div class="cursor-pointer input-group input-group-merge">
                                    <span class="input-group-text text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="exper_end_date_${expCounter}" name="exper_end_date_[${expCounter}]" class="cursor-pointer form-control text-black common_date_class_addMore" value="<?php echo date('d-M-Y'); ?>" readonly>
                                </div>
                                <div class="text-danger" id="exper_end_date_${expCounter}_err"></div>
                            </div>
                            <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_del_button" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="staff_del_button" style="display: none !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
          `;


            // Append the new experience fields to the container
            document.querySelector('[data-repeater-list="staff_experience"]').insertAdjacentHTML('beforeend',
                newExperience);
            // Show the delete button for the newly added row
            let deleteButton = document.querySelector(
                `[data-repeater-list="staff_experience"] [data-repeater-item]:last-child .staff_del_button`);
            deleteButton.style.display = 'block';

            // Attach event listener to the delete button
            deleteButton.addEventListener('click', function() {
                // Remove the parent element (the entire row) when the delete button is clicked
                this.closest('[data-repeater-item]').remove();
            });
            $(".common_date_class_addMore").datepicker({
                format: "dd-M-yyyy",
                autoclose: true,
                todayHighlight: true
            }).datepicker("setDate", new Date());
            expCounter++; // Increment the counter for unique IDs
        }
    </script>

    <script>
        function submit_form() {
            $('#addStaffForm').submit();
        }

        function AddvalidateForm_staff() {
            var err = 0;

            var branch_name = $('#branch_name').val();
            if (branch_name === "") {
                $('#branch_name_err').text('Select Branch / Franchise is required.');
                err++;
            } else {
                $('#branch_name_err').text('');
            }

            // department
            var department_id = $("#department_id").val().trim();
            if (department_id === "") {
                $('#department_id_err').text('Select Department is required.');
                err++;
            } else {
                $('#department_id_err').text('');
            }

            var sub_department_id = $("#division_id").val().trim();
            if (sub_department_id === "") {
                $('#division_id_err').text('Select Division is required.');
                err++;
            } else {
                $('#division_id_err').text('');
            }

            // Staff Name validation
            var staff_name = $("#staff_name").val().trim();
            if (staff_name === "") {
                $('#staff_name_err').text('Staff Name is required.');
                err++;
            } else {
                $('#staff_name_err').text('');
            }

            // Date of Birth validation
            var staff_dob = $("#staff_dob").val().trim();
            if (staff_dob === "") {
                $('#staff_dob_err').text('Date of Birth is required.');
                err++;
            } else {
                $('#staff_dob_err').text('');
            }

            var mobile = $('#mobile_no').val().trim();
            if (mobile == '') {
                $('#mobile_no_err').text('Enter Mobile Number is Required..!');
                err++;
            } else {
                var filter = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
                if (filter.test(mobile)) {
                    $('#mobile_no_err').text('');
                } else {
                    $('#mobile_no_err').text('Enter a valid Mobile number (e.g., 6311111111)..!');
                    err++;
                }
            }

            var email = $('#email_id').val();
            if (email.trim() == '') {
                $('#email_id_err').text('Enter Email is Required..!');
                err++;

            } else {
                var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/;

                if (filter.test(email)) {
                    $('#email_id_err').text('');
                } else {
                    $('#email_id_err').text('Enter a valid email (e.g., staff@gmail.com)..!');
                    err++;
                }
            }
            // Contact Person Name validation
            var contact_person_name = $("#contact_person_name").val().trim();
            if (contact_person_name === "") {
                $('#contact_person_name_err').text('Contact Person Name is required..!');
                err++;
            } else {
                $('#contact_person_name_err').text('');
            }

            // Contact Person Mobile Number validation
            var contact_person_no = $("#contact_person_no").val().trim();
            if (contact_person_no === "") {
                $('#contact_person_no_err').text('Contact Person Mobile Number is required..!');
                err++;
            } else {
                var filter = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
                if (filter.test(mobile)) {
                    $('#contact_person_no_err').text('');
                } else {
                    $('#contact_person_no_err').text('Enter a valid Contact Person Mobile number..!');
                    err++;
                }
            }
            // // Thumbnail Image
            // var staff_img = document.getElementById("upload");
            // var fileSize = staff_img.files.length > 0 ? staff_img.files[0].size : 0;
            // var maxSize = 800 * 1024; // Maximum size in bytes (800KB)
            // if (fileSize > maxSize) {
            //     $('#upload_err').text('Staff Image File size should be less than 800KB..!');
            //     err++;
            // }

            console.log(expCounter)

            var staff_type = $("#staff_type").val().trim();
            if (staff_type === "") {
                $('#staff_type_err').text('Work Type is Required..!');
                err++;
            } else {
                $('#staff_type_err').text('');
            }

            if (staff_type == 2) {
                $('[data-repeater-item]').each(function(index) {

                    var positionInput = $(this).find('input[id^="position_"]');
                    var positionVal = positionInput.val().trim();
                    var positionErr = $(this).find('div[id^="position_"][id$="_err"]');
                    if (positionVal === '') {
                        positionErr.text('Enter Position is Required..!');
                        err++;
                    } else {
                        positionErr.text('');
                    }

                    // Validate Company Name
                    var companyInput = $(this).find('input[id^="company_name_"]');
                    var companyVal = companyInput.val().trim();
                    var companyErr = $(this).find('div[id^="company_name_"][id$="_err"]');
                    if (companyVal === '') {
                        companyErr.text('Enter Company Name is Required..!');
                        err++;
                    } else {
                        companyErr.text('');
                    }

                    // // Validate Years of Experience
                    // var yearInput = $(this).find('input[id^="year_of_experience_"]');
                    // var yearVal = yearInput.val().trim();
                    // var yearErr = $(this).find('div[id^="year_of_experience_"][id$="_err"]');
                    // if (yearVal === '' || isNaN(yearVal) || Number(yearVal) <= 0) {
                    //     yearErr.text('Experience is Required..!');
                    //     err++;
                    // } else {
                    //     yearErr.text('');
                    // }

                    // Validate Start Date
                    var startDate = $(this).find('input[id^="exper_srt_date_"]').val().trim();
                    var startErr = $(this).find('div[id^="exper_srt_date_"][id$="_err"]');
                    if (startDate === '') {
                        startErr.text('Start Date is Required..!');
                        err++;
                    } else {
                        startErr.text('');
                    }

                    // Validate End Date
                    var endDate = $(this).find('input[id^="exper_end_date_"]').val().trim();
                    var endErr = $(this).find('div[id^="exper_end_date_"][id$="_err"]');
                    if (endDate === '') {
                        endErr.text('End Date is Required..!');
                        err++;
                    } else {
                        endErr.text('');
                    }
                });
            }
            // alert(department_id)

            var nick_name = $("#nick_name").val().trim();
            if (nick_name === "") {
                $('#nick_name_err').text('Enter Nick Name is Required..!');
                err++;
            } else {
                $('#nick_name_err').text('');
            }
            var staff_doj = $("#staff_doj").val().trim();
            if (staff_doj === "") {
                $('#staff_doj_err').text('Enter Date of Joining is Required..!');
                err++;
            } else {
                $('#staff_doj_err').text('');
            }
            var position_role = $("#position_role").val().trim();
            if (position_role === "") {
                $('#position_role_err').text('Enter Job Position is Required..!');
                err++;
            } else {
                $('#position_role_err').text('');
            }
            var role_id = $("#role_id").val().trim();
            if (role_id === "") {
                $('#role_id_err').text('Select Role is Required..!');
                err++;
            } else {
                $('#role_id_err').text('');
            }

            var shift_time = $("#shift_time").val().trim();
            if (shift_time === "") {
                $('#shift_time_err').text('Select Shift Time is Required..!');
                err++;
            } else {
                $('#shift_time_err').text('');
            }
            
            var employeeSkill = $('#employee_skill').val();
            if(employeeSkill === '') {
                $('#employee_skill_err').text('Select Employee Skill.');
                err++;
            } else {
                $('#employee_skill_err').text('');
            }

            var salary = $("#salary").val().trim();
            if (salary === "") {
                $('#salary_err').text('Enter Salary is Required..!');
                err++;
            } else {
                $('#salary_err').text('');
            }



            // var hour_cost = $("#hour_cost").val().trim();
            // if (hour_cost === "") {
            //         $('#hour_cost_err').text('Enter Per Hour Cost is Required..!');
            //         err++;
            // }else{
            //     $('#hour_cost_err').text('');
            // }
            var selectedBranches = $('#acces_branch_id').val(); // array or null
            var selectedFranchise = $('#acces_franchise_id').val(); // array or null

            // Check if both divs are visible (as you said, both are visible)
            if ($('#access_branch_div').is(':visible') && $('#access_fran_div').is(':visible')) {
                if (
                    (!selectedBranches || selectedBranches.length === 0) &&
                    (!selectedFranchise || selectedFranchise.length === 0)
                ) {
                    $('#multi_branch_frans_err').text('Select Access Branch Or Franchise Required..!');
                    err++;
                } else {
                    $('#multi_branch_frans_err').text(''); // clear error
                }
            }


            var login_access = document.getElementById("login_access");

            if (login_access.checked) {

                var user_name = $("#loginuser_name").val().trim();
                if (user_name === "") {
                    $('#loginuser_name_err').text('Enter Username is Required..!');
                    err++;
                } else {
                    $('#loginuser_name_err').text('');
                }
                var password = $("#loginpassword").val().trim();
                if (password === "") {
                    $('#loginpassword_err').text('Enter Password is Required..!');
                    err++;
                } else {
                    $('#loginpassword_err').text('');
                }

            } else {
                $('#loginuser_name_err').text('');
                $('#loginpassword_err').text('');
            }

            if (err == 0) {
                var staff_name = $("#staff_name").val().trim();
                $('#create_staff_label').html(staff_name);
                $('#submit_popup').click();

            }

        }
    </script>
    <script>
document.getElementById("upload").addEventListener("change", function () {
    var fileInput = this;
    var file = fileInput.files[0];
    var errorDiv = document.getElementById("upload_err");
    var allowedTypes = ['image/jpeg', 'image/png'];
    var maxSize = 800 * 1024; // 800KB
    errorDiv.textContent = ''; // Clear old errors

    if (!file) return;

    // Check file type
    if (!allowedTypes.includes(file.type)) {
        errorDiv.textContent = 'Unsupported file type. Only JPG and PNG are allowed.';
        fileInput.value = ""; // Reset file input
        return;
    }

    // Check file size
    if (file.size > maxSize) {
        errorDiv.textContent = 'Staff Image File size should be less than 800KB..!';
        fileInput.value = ""; // Reset file input
        return;
    }

    // Preview Image (Optional)
    const reader = new FileReader();
    reader.onload = function (e) {
        document.getElementById("staff_add").src = e.target.result;
    };
    reader.readAsDataURL(file);
});

document.querySelector('.staff-add-reset').addEventListener('click', function () {
    document.getElementById('upload').value = '';
    document.getElementById('staff_add').src = "{{asset('assets/phdizone_images/user_2.png')}}";
    document.getElementById('upload_err').textContent = '';
});
</script>


    {{-- username unique check --}}
    <script>
        function user_name_chk(val) {
            if (val != "") {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });

                $.ajax({
                    url: "{{ route('checkunique_user_name') }}",
                    type: 'POST',
                    data: {
                        value: val
                    },
                    dataType: 'json', // Expect JSON response from server
                    success: function(response) {
                        if (response.data !== 0) {
                            $('#loginuser_name_err').text('Staff username already assigned!.');
                            $('#submit_btn').prop('disabled', true); // Disable submit button
                        } else {
                            $('#loginuser_name_err').text('');
                            $('#submit_btn').prop('disabled', false); // Enable submit button
                        }
                    },
                    error: function(xhr, status, error) {
                        // alert("Error: " + error); // Display error message
                    }
                });
            }

        }
    </script>

    {{-- mobile unique check --}}
    <script>
        function mobile_chk(val) {
            if (val != "") {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });

                $.ajax({
                    url: "{{ route('checkStaffMobileExists') }}",
                    type: 'POST',
                    data: {
                        mobile: val
                    },
                    dataType: 'json', // Expect JSON response from server
                    success: function(response) {
                        console.log(response)
                        if (response.data !== 0) {
                            $('#mobile_no_err').text('Mobile Number is already assigned!.');
                            $('#submit_btn').prop('disabled', true); // Disable submit button
                        } else {
                            $('#mobile_no_err').text('');
                            $('#submit_btn').prop('disabled', false); // Enable submit button
                        }
                    },
                    error: function(xhr, status, error) {
                        // alert("Error: " + error); // Display error message
                    }
                });
            }
        }
    </script>
    <script>
        function get_job_position(id) {
            $.ajax({
                url: "{{ route('job_position') }}", // Ensure this is correct
                type: "GET",
                data: {
                    id: id,
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('select[name="position_role"]');
                        selectDropdown.empty();
                        selectDropdown.append($('<option value="">Select Job Position</option>'));
                        response.data.forEach(function(job) {
                            selectDropdown.append($('<option></option>').attr('value', job.sno).text(job
                                .job_position_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching job positions:', error);
                }
            });
        }
    </script>
    <script>
        $(document).ready(function() {
            $('#branch_name').val({{ $auth_branch_id }}).change();
        });
    </script>
@endsection
