@extends('layouts/layoutMaster')

@section('title', 'Update Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/tagify/tagify.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/tagify/tagify.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms_tagify.js')
@vite('resources/assets/js/forms_file_upload.js')
@endsection

@section('content')
<!-- Staff Add -->
@php
$helper = new \App\Helpers\Helpers();
$auth_branch_id = auth()->user()->branch_id ;
@endphp
<div class="card mb-2">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Update Staff</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">HR Management</a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Staff</a>
                </li>
            </ol>
        </nav>
    </div>
</div>
<form id="addStaffForm" method="POST" action="{{ route('update_staff') }}" enctype="multipart/form-data"
    autocomplete="off">

    @csrf
    <input type="hidden" name="edit_id" id="edit_id" value="{{ $edit->staff_sno ?? '' }}">
<!-- Staff Basic Information -->
<div class="card mb-2 px-4 py-2">
    <h5 class="title mt-4 fw-bold">Basic Information</h5>
    <div class="row mt-4">
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
            <select class="select3 form-select" name="branch_id" id="branch_id" onchange="get_department(this.value)" disabled>
                <option value="">Select Branch</option>
                <optgroup label="Branch" class="fw-bold">
                    @foreach ($branch_list as $blist)
                    @if ($blist->branch_type == 1)
                    <option value="{{ $blist->sno }}" @if ($edit->branch_id == $blist->sno) selected @endif >{{ $blist->branch_name ?? '-' }}</option>
                    @endif
                    @endforeach
                </optgroup>
                <optgroup label="Franchise" class="fw-bold">
                    @foreach ($branch_list as $flist)
                    @if ($flist->branch_type == 2)
                    <option value="{{ $flist->sno }}" @if ($edit->branch_id == $flist->sno) selected @endif >{{ $flist->franchise_name ?? '-' }}</option>
                    @endif
                    @endforeach
                </optgroup>
            </select>
              <input type="hidden" name="auth_branch_id" id="auth_branch_id" value="{{$auth_branch_id}}" />
            <div class="text-danger" id="branch_id_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
            <select class="select3 form-select" name="department_id" id="department_id" onchange="get_sub_department(this.value)">
                <option value="" selected>Select Department</option>
               
            </select>
            <div class="text-danger" id="department_id_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Division<span class="text-danger">*</span></label>
            <select class="select3 form-select" name="division_id" id="division_id" onchange="get_job_position(this.value)">
                <option value="">Select Division</option>
            </select>
            <div class="text-danger" id="division_id_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" maxlength="80" placeholder="Enter Staff Name" name="staff_name" id="staff_name" value="{{$edit->staff_name ?? ''}}" />
            <div class="text-danger" id="staff_name_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold d-block">Gender<span class="text-danger">*</span></label>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" id="gender_male" value="1"  <?php echo ($edit->gender ?? 1) == 1 ? 'checked' : ''; ?>  />
                <label class="form-check-label" for="inlineRadio1">Male</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" id="gender_female" value="2" <?php echo ($edit->gender ?? 1) == 2 ? 'checked' : ''; ?>  />
                <label class="form-check-label" for="inlineRadio2">Female</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" id="gender_others" value="3"  <?php echo ($edit->gender ?? 1) == 3 ? 'checked' : ''; ?>  />
                <label class="form-check-label" for="inlineRadio3">Others</label>
            </div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Date of Birth<span class="text-danger">*</span></label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                <input type="text" id="staff_dob" name="dob"  placeholder="Select Date" class="form-control" value="{{ date('d-m-Y', strtotime($edit->dob ?? date('d-m-Y'))) }}" />
              
            </div>
            <div class="text-danger" id="staff_dob_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Mobile Number<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Mobile Number" id="mobile_no" name="mobile_no" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" value="{{ $edit->mobile_no ?? '' }}" onkeyup="mobile_chk(this.value)" />
            <div class="text-danger" id="mobile_no_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
            <input type="text" class="form-control me-2" placeholder="Enter Alternate Mobile Number" id="alternative_no" name="alternative_no" maxlength="10" value="{{ $edit->alternative_no ?? '' }}"  oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter E-Mail ID" value="{{ $edit->email_id ?? '' }}"  oninput=" this.value = this.value.toLowerCase();" maxlength="80" id="email_id" name="email_id"  />
            <div class="text-danger" id="email_id_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Contact Person Name"  value="{{ $edit->contact_person_name ?? '' }}" id="contact_person_name" name="contact_person_name" maxlength="70" />
            <div class="text-danger" id="contact_person_name_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile Number<span class="text-danger">*</span></label>
            <input type="text" class="form-control me-2" placeholder="Enter Contact Person Mobile Number" value="{{ $edit->contact_person_no ?? '' }}"  oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"  maxlength="10"  id="contact_person_no" name="contact_person_no" />
            <div class="text-danger" id="contact_person_no_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Marital Status</label>
            <select class="select3 form-select" id="martial_status" name="martial_status">
                <option value="">Select Marital Status</option>
                <option @if ($edit->martial_status == 1) selected @endif value="1">Married</option>
                <option @if ($edit->martial_status == 2) selected @endif value="2">Unmarried</option>
            </select>
        </div>
        <div class="col-lg-4">
            <label class="text-black mb-1 fs-6 fw-semibold">Address</label>
            <textarea class="form-control" rows="3" id="address" name="address" placeholder="Enter Description" maxlength="80">{{ $edit->address ?? '' }}</textarea>
        </div>
        <div class="col-lg-4">
            <div class="row">
                <label class="col-lg-6 text-black fs-6 fw-semibold">Staff Image</label>
                <!-- <div class="col-lg-6"> -->
                <div class="align-items-sm-center gap-4">
                    @if ($edit->staff_image ?? '' != '' && file_exists(public_path('staff_images/' .
                    $edit->staff_image)))
                    <img src="{{ asset('staff_images/' . $edit->staff_image) }}" alt="user-avatar"
                                class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid"
                                id="staff_add" />
                    @else
                    <img src="{{asset('assets/phdizone_images/user_1.png')}}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="staff_add" />
                    @endif
                    <div class="button-wrapper">
                        <div class="d-flex align-items-start mt-2 mb-2">
                            <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Logo">
                                <i class="mdi mdi-tray-arrow-up"></i>
                                <input type="file" id="upload" name='staff_add_icon' class="file-in staff_add_cls" hidden accept="image/png, image/jpeg" />
                                <input type="hidden" name="old_staff_image" id="old_staff_image"
                                            value="{{ $edit->staff_image ?? '' }}">
                            </label>
                            <button type="button" class="btn btn-sm btn-outline-danger file-reset staff-add-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Logo">
                                <i class="mdi mdi-reload"></i>
                            </button>
                        </div>
                        <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                    </div>
                </div>
                <!-- </div> -->
            </div>
        </div>
    </div>
</div>
<!-- End Staff Basic Information -->
<!-- Staff Experience Information Start-->
<div class="card px-4 py-2 mb-2">
    <h5 class="title mb-1 fw-bold mt-4">Work Information</h5>
    <div class="row mt-4">
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
            <select id="staff_type" name="staff_type" class="select3 form-select" onchange="staff_func();">
                <option value="">Select Type</option>
                <option value="1"  @if ($edit->staff_type ?? 1 == 1) selected @endif>Fresher</option>
                <option value="2"  @if ($edit->staff_type ?? 1 == 2) selected @endif>Experience</option>
            </select>
            <div class="text-danger" id="staff_type_err"></div>
        </div>
    </div>
    <div class="row" id="staff_experience" style="display:@if ($edit->staff_type ?? 1 == 2) block @else none @endif;">
        <div class="form-repeater_staff_exp_add">
            <div data-repeater-list="staff_experience">
                @foreach ($workInfo as $wkey => $work)
                    <div data-repeater-item>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col-lg-3 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Position<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="position_{{ $wkey }}" name="position_[{{ $wkey }}]" value="{{ $work->position ?? '' }}"  placeholder="Enter Position" />
                                        <input type="hidden" name="work_sno[{{ $wkey }}]" value="{{ $work->sno }}">
                                        <div class="text-danger" id="position_err_{{ $wkey }}"></div>
                                    </div>
                                    <div class="col-lg-3 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control"  id="company_name_{{ $wkey }}" name="company_name_[{{ $wkey }}]" value="{{ $work->company_name ?? '' }}" placeholder="Enter Company Name" maxlength="80" />
                                        <div class="text-danger" id="company_name_err_{{ $wkey }}"></div>
                                    </div>
                                    <!--<div class="col-lg-1 mb-3">-->
                                    <!--    <label class="text-black mb-1 fs-6 fw-semibold">Exp.Years<span class="text-danger">*</span></label>-->
                                    <!--    <input type="text" class="form-control text-center"  id="year_of_experience_{{ $wkey }}" name="year_of_experience_[{{ $wkey }}]"  maxlength="3"  oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  value="{{ $work->year_of_experience ?? '' }}"  placeholder="Count" />-->
                                    <!--    <div class="text-danger" id="year_of_experience_err_{{ $wkey }}"></div>-->
                                    <!--</div>-->
                                    <div class="col-lg-2 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Start Date<span class="text-danger">*</span></label>
                                        <div class="cursor-pointer input-group input-group-merge">
                                            <span class="input-group-text text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="work_start_date_{{ $wkey }}" name="work_start_date_[{{ $wkey }}]" class="cursor-pointer form-control text-black common_date_class" value="{{ date('d-m-Y', strtotime($work->work_start_date ?? date('d-m-Y')))}}" readonly>
                                            
                                        </div>
                                        <div class="text-danger" id="work_start_date_err_{{ $wkey }}"></div>
                                    </div>
                                    <div class="col-lg-2 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">End Date<span class="text-danger">*</span></label>
                                        <div class="cursor-pointer input-group input-group-merge">
                                            <span class="input-group-text text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="work_end_date_{{ $wkey }}" name="work_end_date_[{{ $wkey }}]" class="cursor-pointer form-control text-black common_date_class" value="{{ date('d-m-Y', strtotime($work->work_end_date ?? date('d-m-Y')))}}" readonly>
                                           
                                        </div>
                                        <div class="text-danger" id="work_end_date_err_{{ $wkey }}"></div>
                                    </div>
                                    <div class="col-lg-1">
                                        <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_del_button" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="staff_del_button" style="display: none !important;">
                                            <i class="mdi mdi-delete fs-4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
        <div class="mb-1 mt-1">
            <button type="button" class="btn btn-primary staff_exp_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" onclick="addMoreExperience()" data-repeater-create id="staff_exp_add">
                <i class="mdi mdi-plus me-1"></i>
            </button>
        </div>
    </div>
</div>
<!-- Staff Experience Information End-->
<!-- Staff Designation Information -->
<div class="card px-4 py-2 mb-2">
    <h5 class="title mb-1 fw-bold mt-4">Designation Information</h5>
    <div class="row mt-4">
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Nick Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Nick Name" id="nick_name" name="nick_name" maxlength="70" value="{{ $edit->nick_name ?? '' }}" />
            <div class="text-danger" id="nick_name_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Date of Joining<span class="text-danger">*</span></label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                <input type="text" id="staff_doj" name="date_of_joinig" placeholder="Select Date" class="form-control"  value="<?php echo date('d-M-Y', strtotime($edit->date_of_joining ?? '')); ?>"  />
            </div>
            <div class="text-danger" id="staff_doj_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Job Position<span class="text-danger">*</span></label>
            <select class="select3 form-select" id="position_role" name="position_role">
                <option value="">Select Job Position</option>
            </select>
            <div class="text-danger" id="position_role_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Role<span class="text-danger">*</span></label>
            <select class="select3 form-select" id="role_id" name="role_id">
                <option value="">Select Role</option>
                @php
                $get_role_list = $helper->get_role_list();
                @endphp
                @foreach ($get_role_list as $rlist)
                 @if($rlist->sno > 1)
                <option value="{{ $rlist->sno }}" @if ($rlist->sno == $edit->role_id ?? '') selected @endif>
                    {{ $rlist->role_name }}</option>
                     @endif
                @endforeach
            </select>
            <div class="text-danger" id="role_id_err"></div>
        </div>
        <div class="col-lg-4 mb-3" id="access_branch_div" style="display: none;">
              <label class="text-dark mb-1 fs-6 fw-semibold">Access Branch<span class="text-danger">*</span></label>
              <select class="select3 form-select acces_branch_id_valid" name="acces_branch_id[]" id="acces_branch_id" data-placeholder="Select Access Branch" multiple>
                @php
                $get_branch_list = $helper->get_branch_list();
                $edit_access_branch = json_decode($edit->multi_branch_access, true) ?? [];
                @endphp
    
            @foreach ($get_branch_list as $br_list)
                <option value="{{ $br_list->sno }}" {{ in_array($br_list->sno, $edit_access_branch) ? 'selected' : '' }}>
                    {{ $br_list->branch_name }}
                </option>
            @endforeach
            </select>
            <div class="text-danger" id="multi_branch_frans_err"></div>
            </div>
            <div class="col-lg-4 mb-3" id="access_fran_div" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">Access Franchise<span class="text-danger">*</span></label>
                <select class="select3 form-select acces_franchise_id_valid" name="acces_franchise_id[]" id="acces_franchise_id" data-placeholder="Select Access Franchise" multiple>
                    @php
                    $get_franchise_list = $helper->get_franchise_list();
                    $edit_access_fra = json_decode($edit->multi_branch_access, true) ?? [];
                    @endphp
                    @foreach ($get_franchise_list as $fr_list)
                    <option value="{{ $fr_list->sno }}" {{ in_array($fr_list->sno, $edit_access_branch) ? 'selected' : '' }}>{{ $fr_list->franchise_name }}</option>
                    @endforeach
                </select>
            </div>
        <div class="col-lg-4 mb-3">
            <input class="form-check-input" type="checkbox" id="login_access" name="login_access" value="1" @if ($edit->login_access ?? 0 == 1) checked @endif onclick="login_credt_func();" />
            <label class="text-black mb-1 fs-6 fw-semibold" id="log_cred_txt" style="display: none;">Login Credentials</label>
            <label class="text-black mb-1 fs-6 fw-semibold" id="usern_txt" style="display: inline;">Username<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="loginuser_name" name="loginuser_name" placeholder="Enter User Name" value="{{ $edit->loginuser_name ?? '' }}"  onkeyup="user_name_chk(this.value)"  style="display: inline !important;" />
            <div class="text-danger" id="loginuser_name_err"></div>
        </div>
        <div class="col-lg-4 mb-3" id="pw_tbox" style="display: inline;">
            <label class="text-black mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
            <div class="form-password-toggle">
                <div class="input-group input-group-merge">
                    <input type="password" class="form-control" id="loginpassword" name="loginpassword" maxlength="30" value="{{ $edit->loginpassword ?? '' }}" placeholder="Enter Password" aria-describedby="password"  />
                    <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline fs-4"></i></span>
                </div>
            </div>
            <div class="text-danger" id="loginpassword_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Shift Time<span class="text-danger">*</span></label>
            <select id="shift_time" name="shift_time" class="select3 form-select">
                <option value="">Select Shift Time</option>
                @foreach ($shift_time as $stlist)
                <option value="{{ $stlist->sno }}" @if ($stlist->sno == $edit->shift_time_id) selected @endif> {{ $stlist->shift_time_name }}
                    {{ date('h:i A', strtotime($stlist->shift_start_time)) }} -
                    {{ date('h:i A', strtotime($stlist->shift_end_time)) }}
                    Lunch {{ date('h:i A', strtotime($stlist->shift_lunch_start)) }} -
                    {{ date('h:i A', strtotime($stlist->shift_lunch_end)) }}</option>
                @endforeach
            </select>
            <div class="text-danger" id="shift_time_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Employee Skill<span class="text-danger">*</span></label>
            <select id="employee_skill" name="employee_skill" class="select3 form-select">
                <option value="">Select Employee Skill</option>
                @foreach ($skills as $skill)
                <option value="{{ $skill->sno }}" @if ($skill->sno == $edit->employee_skill_id) selected @endif>{{ $skill->employee_skill }}</option>
                @endforeach
            </select>
            <div class="text-danger" id="employee_skill_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Basic Salary<span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Basic Salary" id="salary" name="salary"  maxlength="11"  value="{{ $edit->basic_salary ?? '' }}"   oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 8);" onkeyup="get_per_hour_cost(this.value)" />
            <div class="text-danger" id="salary_err"></div>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Per Hour Cost<span class="text-danger">*</span></label>
            <div>
            <label class="badge bg-info text-white fs-5 px-2" id="perhour_label">{{ $edit->per_hour_cost ?? '0' }}</label>
            </div>
            <input type="hidden" class="form-control" placeholder="Enter Per Hour Cost"  id="hour_cost" name="hour_cost" value="{{ $edit->per_hour_cost ?? '0' }}"   oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 8);" />
            <div class="text-danger" id="hour_cost_err"></div>
        </div>
    </div>
    <div class="row mt-4 px-2 py-2">
        <div class="col-lg-6">
            <div class="row">
                <label class="text-black fs-6 fw-semibold mt-2">Other Attachment</label>
                <div action="/upload" class="dropzone needsclick" id="dropzone-multi">
                    <div class="dz-message needsclick fs-6">
                        <div class="text-center me-3">Drop files here or click to upload</div>
                    </div>
                    <div class="">
                        <input type="file" name="attachment[]" multiple  />
                        <input type="hidden" name="old_attachment" id="old_attachment" value="{{ $edit->attachment ?? '' }}">
                        <div class="fs-8 text-success">
                            @php
                                $attachments = json_decode($edit->attachment, true);
                                echo $attachments ? implode(', ', $attachments) : '';
                            @endphp
                        </div>
                    </div>
                   
                </div>
            </div>
            
        </div>
        <div class="col-lg-6">
            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="3" name="description" placeholder="Enter Description" maxlength="80">{{ $edit->description ?? '' }}</textarea>
        </div>
    </div>
    <div class="d-flex justify-content-end align-items-center mt-4">
        <a href="{{url ('hr_management/staff')}}" class="btn btn-secondary me-3">Cancel</a>
        <button type="button" class="btn btn-primary" id="submit_btn" onclick="AddvalidateForm_staff()">Update Staff</button>
        <input type="hidden" name="submit_popup" id="submit_popup" data-bs-toggle="modal"
        data-bs-target="#kt_modal_confirmation_staff">
    </div>
</div>
<!-- End Staff Designation Information -->
</form>
<!--begin::Modal - Confirmation Staff-->
<div class="modal fade" id="kt_modal_confirmation_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                Update Staff ?
                <div class="d-block fw-bold fs-5 py-2">
                <label id="create_staff_label" class="text-success"></label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="button" class="btn btn-primary me-3" id="confirmBtn"  onclick="submit_form()">Yes</button>
                <a href="#" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Confirmation Staff-->


<script>
  get_branch_access({{ $edit->role_id }})
  function get_branch_access(val) {
    if (val !== "") {
        $.ajax({
            url: "{{ route('get_branch_access_role') }}",
            type: "GET",
            data: {
                id: val
            },
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var type = response.data.manage_branch;
                    if (type == 2) {
                        var accesss = response.data.access_head??0;
                        // Show/hide divs based on access level
                        switch (accesss) {
                            case 1:
                                $('#access_branch_div').show();
                                $('#access_fran_div').hide();
                                break;
                            case 2:
                                $('#access_branch_div').hide();
                                $('#access_fran_div').show();
                                break;
                            case 3:
                                $('#access_branch_div').show();
                                $('#access_fran_div').show();
                                break;
                            default:
                                $('#access_branch_div').hide();
                                $('#access_fran_div').hide();
                                break;
                        }
                    }else{
                      $('#access_branch_div').hide();
                      $('#access_fran_div').hide();
                    }
                } else {
                    // Optionally handle the case where access role is not available
                    $('#access_branch_div').hide();
                    $('#access_fran_div').hide();
                }
            },
            error: function(error) {
                // console.error('Error fetching branch access role:', error);
                // alert('An error occurred while fetching access role.'); // Optional user feedback
            }
        });
    }else{
      $('#access_branch_div').hide();
      $('#access_fran_div').hide();
    }
}
get_per_hour_cost({{ $edit->basic_salary }})
function get_per_hour_cost(val) {
    if (val !== "") {
        $.ajax({
            url: "{{ route('get_per_hour_cost_staff') }}",
            type: "GET",
            data: {
                amount: val
            },
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var data = response.data;
                    $('#hour_cost').val(data.per_hour_cost);
                    $('#perhour_label').html(data.per_hour_cost);
                } else if (response.status === 302) {
                    // Not found: reset fields
                    $('#hour_cost').val('0');
                    $('#perhour_label').html('0');
                }
            },
            error: function(xhr) {
                if (xhr.status === 302) {
                    $('#hour_cost').val('0');
                    $('#perhour_label').html('0');
                } else {
                    console.error('Error fetching per hour cost:', xhr);
                    alert('An unexpected error occurred.');
                }
            }
        });
    } else {
        $('#hour_cost').val('');
        $('#perhour_label').html('');
    }
}
</script>

<script>
     $(document).ready(function() {
        var branch_id=$('#branch_id').val();
        get_department(branch_id)
        staff_func()
        login_credt_func()
     });
</script>

<script>
    
    function staff_func() {
        var create_staff = document.getElementById("staff_type").value;
        var staff_experience = document.getElementById("staff_experience");
        if (create_staff == "2") {
            staff_experience.style.display = "block";
        } else {
            staff_experience.style.display = "none";
        }
    }
</script>


<script>
    function login_credt_func() {
        var login_crent = document.getElementById("login_access");
        var log_cred_txt = document.getElementById("log_cred_txt");
        var usern_txt = document.getElementById("usern_txt");
        var user_name = document.getElementById("loginuser_name");
        var pw_tbox = document.getElementById("pw_tbox");

        if (login_crent.checked) {
            log_cred_txt.style.display = "none";
            usern_txt.style.display = "inline";
            user_name.style.display = "inline";
            pw_tbox.style.display = "block";
        } else {
            log_cred_txt.style.display = "inline";
            usern_txt.style.display = "none";
            user_name.style.display = "none";
            pw_tbox.style.display = "none";
        }
    }
</script>
<script>

function get_department(branch_id) {
    // This assumes you're writing inside a .blade.php file
    var department_id = {{ $edit->department_id ?? '0' }};

    $.ajax({
        url: "{{ route('branch_department_list') }}",
        type: "GET",
        data: {
            branch_id: branch_id
        },
        success: function(response) {
            if (response.status === 200 && response.data) {
                var selectDropdown = $('select[name="department_id"]');
                selectDropdown.empty();
                selectDropdown.append('<option value="">Select Department</option>');

                response.data.forEach(function(dept) {
                    selectDropdown.append(
                        $('<option></option>').attr('value', dept.sno).text(dept.department_name)
                    );
                    if(department_id !=0){
                        if(department_id ==dept.sno){
                            selectDropdown.val(department_id).trigger('change');
                            get_sub_department(department_id);
                        }
                    }
                });
            }else{
                    var selectDropdown = $('select[name="department_id"]');
                    selectDropdown.empty().append('<option value="">Select Department</option>');
                }
        },
        error: function(error) {
            // Moved inside success/error to avoid scope issue
            var selectDropdown = $('select[name="department_id"]');
            selectDropdown.empty().append('<option value="">Select Department</option>');
            // Optional: log the error
            // console.error('Error fetching departments:', error);
        }
    });
}


    function get_sub_department(id) {
        var sub_department_id={{$edit->sub_department_id ?? '0'}};
        $.ajax({
            url: "{{ route('get_division') }}",
            type: "GET",
            data: {
                department_id: id
            },
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var selectDropdown = $('select[name="division_id"]');
                    selectDropdown.empty();
                    selectDropdown.append($('<option value="">Select Division</option>'));
                    response.data.forEach(function(sub_dept) {
                        selectDropdown.append($('<option></option>').attr('value', sub_dept
                            .sno).text(sub_dept.division_name));
                           
                            if(sub_department_id !=0){
                                if(sub_department_id ==sub_dept.sno){
                                    selectDropdown.val(sub_department_id).trigger('change');
                                }
                            }
                    });
                    
                }else{
                    var selectDropdown = $('select[name="division_id"]');
                    selectDropdown.empty().append('<option value="">Select Division</option>');
                }
            },
            error: function(error) {
                // console.error('Error fetching course sub categories:', error);
                var selectDropdown = $('select[name="division_id"]');
                selectDropdown.empty().append('<option value="">Select Division</option>');
            }
        });

    }
</script>

<script>
    document.addEventListener('DOMContentLoaded', () => {
            let staff_add = document.getElementById('staff_add');
           
            const staff_add_fileInput = document.querySelector('.staff_add_cls'),
                staff_add_resetFileInput = document.querySelector('.staff-add-reset');
            if (staff_add) {
                const staff_add_resetImage = staff_add.src;
                staff_add_fileInput.onchange = () => {
                    console.log(staff_add)
                    if (staff_add_fileInput.files[0]) {
                        staff_add.src = window.URL.createObjectURL(staff_add_fileInput.files[0]);
                    }
                };
                staff_add_resetFileInput.onclick = () => {
                    staff_add_fileInput.value = '';
                    staff_add.src = staff_add_resetImage;
                };
            }
        });
</script>

<script>
    let expCounter = {{ count($workInfo) ?? 0 }};

        function addMoreExperience() {

            let newExperience = `
              <div data-repeater-item>
                  <div class="row">
                      <div class="col-lg-12">
                        <div class="row">
                            <div class="col-lg-3 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Position<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="position_${expCounter}" name="position_[${expCounter}]" value=""  placeholder="Enter Position" />
                                    <input type="hidden" name="work_sno[${expCounter}]"  value="">
                                <div class="text-danger" id="position_err_${expCounter}"></div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                                <input type="text" class="form-control"  id="company_name_${expCounter}" name="company_name_[${expCounter}]" value="{{ $work->company_name ?? '' }}" placeholder="Enter Company Name" />
                                <div class="text-danger" id="company_name_err_${expCounter}"></div>
                            </div>
                           
                            <div class="col-lg-2 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Start Date<span class="text-danger">*</span></label>
                                <div class="cursor-pointer input-group input-group-merge">
                                    <span class="input-group-text text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="work_start_date_${expCounter}" name="work_start_date_[${expCounter}]" class="cursor-pointer form-control text-black common_date_class_addMore" value="<?php echo date("d-M-Y"); ?>" readonly>
                                   
                                </div>
                                 <div class="text-danger" id="work_start_date_err_${expCounter}"></div>
                            </div>
                            <div class="col-lg-2 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">End Date<span class="text-danger">*</span></label>
                                <div class="cursor-pointer input-group input-group-merge">
                                    <span class="input-group-text text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="work_end_date_${expCounter}" name="work_end_date_[${expCounter}]" class="cursor-pointer form-control text-black common_date_class_addMore" value="<?php echo date("d-M-Y"); ?>" readonly>
                                   
                                </div>
                                 <div class="text-danger" id="work_end_date_err_${expCounter}"></div>
                            </div>
                            <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_del_button" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="staff_del_button" style="display: none !important;">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                      </div>
                  </div>
              </div>
          `;
            // Append the new experience fields to the container
            document.querySelector('[data-repeater-list="staff_experience"]').insertAdjacentHTML('beforeend',
                newExperience);
            // Show the delete button for the newly added row
            let deleteButton = document.querySelector(
                `[data-repeater-list="staff_experience"] [data-repeater-item]:last-child .staff_del_button`);
            deleteButton.style.display = 'block';

            // Attach event listener to the delete button
            deleteButton.addEventListener('click', function() {
                // Remove the parent element (the entire row) when the delete button is clicked
                this.closest('[data-repeater-item]').remove();
            });
            $(".common_date_class_addMore").datepicker({
                format: "dd-M-yyyy",
                autoclose: true,
                todayHighlight: true
            }).datepicker("setDate", new Date());
            
            expCounter++; // Increment the counter for unique IDs
        }
</script>

<script>
    function submit_form() {
            $('#addStaffForm').submit();
        }

        function AddvalidateForm_staff() {
            var err = 0;
            var branch_id = $('#branch_id').val();

            if (branch_id === "") {
                    $('#branch_id_err').text('Select Branch / Franchise is required.');
                    err++;
            }else{
                $('#branch_id_err').text('');
            }

            // department
            var department_id_edit = $("#department_id").val().trim();
            if (department_id_edit === "") {
                $('#department_id_err').text('Select Department is required.');
                err++;
            }else{
                $('#department_id_err').text('');
            }

            var sub_department_id = $("#division_id").val().trim();
            if (sub_department_id === "") {
                $('#division_id_err').text('Select Division is required.');
                err++;
            }else{
                $('#division_id_err').text('');
            }

            // Staff Name validation
            var staff_name = $("#staff_name").val().trim();
            if (staff_name === "") {
                $('#staff_name_err').text('Staff Name is required.');
                err++;
            }else{
                $('#staff_name_err').text('');
            }

            // Date of Birth validation
            var staff_dob = $("#staff_dob").val().trim();
            if (staff_dob === "") {
                $('#staff_dob_err').text('Date of Birth is required.');
                err++;
            }else{
                $('#staff_dob_err').text('');
            }

            var mobile = $('#mobile_no').val().trim();
            if (mobile == '') {
                $('#mobile_no_err').text('Enter Mobile Number is Required..!');
                    err++;
            } else {
                var filter = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
                if (filter.test(mobile)) {
                    $('#mobile_no_err').text('');
                } else {
                        $('#mobile_no_err').text('Enter a valid Mobile number (e.g., 6311111111)..!');
                        err++;
                }
            }

            var email = $('#email_id').val();
            if (email.trim() == '') {
                    $('#email_id_err').text('Enter Email is Required..!');
                    err++;
                
            } else {
                var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/;

                if (filter.test(email)) {
                    $('#email_id_err').text('');
                } else {
                        $('#email_id_err').text('Enter a valid email (e.g., staff@gmail.com)..!');
                        err++;
                }
            }
            // Contact Person Name validation
            var contact_person_name = $("#contact_person_name").val().trim();
            if (contact_person_name === "") {
                $('#contact_person_name_err').text('Contact Person Name is required..!');
                err++;
            }else{
                $('#contact_person_name_err').text('');
            }

            // Contact Person Mobile Number validation
            var contact_person_no = $("#contact_person_no").val().trim();
            if (contact_person_no === "") {
                $('#contact_person_no_err').text('Contact Person Mobile Number is required..!');
                err++;
            } else {
                $('#contact_person_no_err').text('');
            }
            // Thumbnail Image
            var staff_img = document.getElementById("upload");
            var fileSize = staff_img.files.length > 0 ? staff_img.files[0].size : 0;
            var maxSize = 800 * 1024; // Maximum size in bytes (800KB)
             if (fileSize > maxSize) {
                    $('#upload_err').text('Staff Image File size should be less than 800KB..!');
                    err++;
            }

         
            var staff_type = $("#staff_type").val().trim();
            if (staff_type === "") {
                    $('#staff_type_err').text('Work Type is Required..!');
                    err++;
            }else{
                $('#staff_type_err').text('');
            }

           
            if (staff_type == 2) {
                $('[data-repeater-item]').each(function(index) {
                    let itemIndex = index;

                    // Validate Position
                    let positionInput = $(this).find(`#position_${itemIndex}`);
                    let positionVal = positionInput.val().trim();
                    let positionErr = $(`#position_err_${itemIndex}`);
                    if (positionVal === '') {
                        positionErr.text('Position is Required..!');
                        err++;
                    } else {
                        positionErr.text('');
                    }

                    // Validate Company Name
                    let companyInput = $(this).find(`#company_name_${itemIndex}`);
                    let companyVal = companyInput.val().trim();
                    let companyErr = $(`#company_name_err_${itemIndex}`);
                    if (companyVal === '') {
                        companyErr.text('Company Name is Required..!');
                        err++;
                    } else {
                        companyErr.text('');
                    }

                    // // Validate Years of Experience
                    // let yearInput = $(this).find(`#year_of_experience_${itemIndex}`);
                    // let yearVal = yearInput.val().trim();
                    // let yearErr = $(`#year_of_experience_err_${itemIndex}`);
                    // if (yearVal === '' || isNaN(yearVal) || Number(yearVal) <= 0) {
                    //     yearErr.text('Year is Required');
                    //     err++;
                    // } else {
                    //     yearErr.text('');
                    // }

                    // Validate Start Date
                    let startDateInput = $(this).find(`#work_start_date_${itemIndex}`);
                    let startDateVal = startDateInput.val().trim();
                    let startErr = $(`#work_start_date_err_${itemIndex}`);
                    if (startDateVal === '') {
                        startErr.text('Start Date is Required..!');
                        err++;
                    } else {
                        startErr.text('');
                    }

                    // Validate End Date
                    let endDateInput = $(this).find(`#work_end_date_${itemIndex}`);
                    let endDateVal = endDateInput.val().trim();
                    let endErr = $(`#work_end_date_err_${itemIndex}`);
                    if (endDateVal === '') {
                        endErr.text('End Date is Required..!');
                        err++;
                    } else {
                        endErr.text('');
                    }
                });
            }
            // alert(department_id)

            var nick_name = $("#nick_name").val().trim();
            if (nick_name === "") {
                    $('#nick_name_err').text('Enter Nick Name is Required..!');
                    err++;
            }else{
                $('#nick_name_err').text('');
            }
            var staff_doj = $("#staff_doj").val().trim();
            if (staff_doj === "") {
                $('#staff_doj_err').text('Enter Date of Joining is Required..!');
                err++;
            }else{
                $('#staff_doj_err').text('');
            }
            var position_role = $("#position_role").val().trim();
            if (position_role === "") {
                $('#position_role_err').text('Enter Job Position is Required..!');
                err++;
            }else{
                $('#position_role_err').text('');
            }
            var role_id = $("#role_id").val().trim();
            if (role_id === "") {
                    $('#role_id_err').text('Select Role is Required..!');
                    err++;
            }else{
                $('#role_id_err').text('');
            }
            var selectedBranches = $('#acces_branch_id').val(); // array or null
            var selectedFranchise = $('#acces_franchise_id').val(); // array or null
            
            // Check if both divs are visible (as you said, both are visible)
            if ($('#access_branch_div').is(':visible') && $('#access_fran_div').is(':visible')) {
                if (
                    (!selectedBranches || selectedBranches.length === 0) &&
                    (!selectedFranchise || selectedFranchise.length === 0)
                ) {
                    $('#multi_branch_frans_err').text('Select Access Branch Or Franchise Required..!');
                    err++;
                } else {
                    $('#multi_branch_frans_err').text(''); // clear error
                }
            }
            var shift_time = $("#shift_time").val().trim();
            if (shift_time === "") {
                    $('#shift_time_err').text('Select Shift Time is Required..!');
                    err++;
            }else{
                $('#shift_time_err').text('');
            }
           
            var salary = $("#salary").val().trim();
            if (salary === "") {
                    $('#salary_err').text('Enter Salary is Required..!');
                    err++;
            }else{
                $('#salary_err').text('');
            }
            
            var employeeSkill = $('#employee_skill').val();
            if(employeeSkill === '') {
                $('#employee_skill_err').text('Select Employee Skill.');
                err++;
            } else {
                $('#employee_skill_err').text('');
            }



            // var hour_cost = $("#hour_cost").val().trim();
            // if (hour_cost === "") {
            //         $('#hour_cost_err').text('Enter Per Hour Cost is Required..!');
            //         err++;
            // }else{
            //     $('#hour_cost_err').text('');
            // }
            var login_access = document.getElementById("login_access");

            if (login_access.checked) {

                var user_name = $("#loginuser_name").val().trim();
                if (user_name === "") {
                    $('#loginuser_name_err').text('Enter Username is Required..!');
                    err++;
                }else{
                    $('#loginuser_name_err').text('');
                }
                var password = $("#loginpassword").val().trim();
                if (password === "") {
                        $('#loginpassword_err').text('Enter Password is Required..!');
                        err++;
                }else{
                    $('#loginpassword_err').text('');
                }

            }else{
                $('#loginuser_name_err').text('');
                $('#loginpassword_err').text('');
            }

            if (err == 0) {
                var staff_name = $("#staff_name").val().trim();
                $('#create_staff_label').html(staff_name);
                $('#submit_popup').click();

            }
            
        }
</script>

{{-- username unique check --}}
<script>
 function user_name_chk(val) {
        var id = '{{ $edit->staff_sno ?? '' }}';
        if (val != "") {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            });

            $.ajax({
                url: "{{ route('checkunique_user_name_edit') }}",
                type: 'POST',
                data: {
                    value: val,
                    id: id
                },
                dataType: 'json', // Expect JSON response from server
                success: function(response) {
                    if (response.data !== 0) {
                        $('#loginuser_name_err').text('Staff username already assigned!');
                        $('#submit_btn').prop('disabled', true); // Disable submit button
                    } else {
                        $('#loginuser_name_err').text('');
                        $('#submit_btn').prop('disabled', false); // Enable submit button
                    }
                },
                error: function(xhr, status, error) {
                    // alert("Error: " + error); // Display error message
                }
            });
        }
    }
</script>

{{-- mobile unique check --}}
<script>
  function mobile_chk(val) {
        var id = '{{ $edit->staff_sno ?? '' }}';
        if (val != "") {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            });

            $.ajax({
                url: "{{ route('checkunique_mobile_edit') }}",
                type: 'POST',
                data: {
                    mobile: val,
                    id: id
                },
                dataType: 'json', // Expect JSON response from server
                success: function(response) {
                    if (response.data !== 0) {
                        $('#mobile_no_err').text('Staff Mobile Number already assigned!');
                        $('#submit_btn').prop('disabled', true); // Disable submit button
                    } else {
                            $('#mobile_no_err').text('');
                        $('#submit_btn').prop('disabled', false); // Enable submit button
                    }
                },
                error: function(xhr, status, error) {
                    // alert("Error: " + error); // Display error message
                }
            });
        }
    }
</script>
<script>
    function get_job_position(id) {
        var position_role={{$edit->position_role ?? '0'}};
        $.ajax({
            url: "{{ route('job_position') }}", // Ensure this is correct
            type: "GET",
            data: {
                id: id,
            },
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var selectDropdown = $('select[name="position_role"]');
                    selectDropdown.empty();
                    selectDropdown.append($('<option value="">Select Job Position</option>'));
                    response.data.forEach(function(job) {
                        selectDropdown.append($('<option></option>').attr('value', job.sno).text(job.job_position_name));
                        if(position_role !=0){
                            if(position_role ==job.sno){
                                selectDropdown.val(position_role).trigger('change');
                            }
                        }
                    });
                    
                }else{
                    var selectDropdown = $('select[name="position_role"]');
                    selectDropdown.empty().append('<option value="">Select Job Position</option>');
                }
            },
            error: function(error) {
                var selectDropdown = $('select[name="position_role"]');
                selectDropdown.empty().append('<option value="">Select Job Position</option>');
            }
        });
    }
</script>
@endsection