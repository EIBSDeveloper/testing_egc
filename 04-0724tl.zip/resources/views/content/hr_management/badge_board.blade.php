@extends('layouts/layoutMaster')

@section('title', 'Badges')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js', 'resources/assets/vendor/js/dropdown-hover.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')
<style>
    :root {
        --primary: #7e57c2;
        --primary-dark: #5e35b1;
        --secondary: #26c6da;
        --accent: #ff4081;
        --gold: #ffd700;
        --silver: #c0c0c0;
        --bronze: #cd7f32;
        --dark: #1a1a2e;
        --darker: #0f0f1b;
        --light: #f8f9fa;
    }

    .particles {
        position: fixed;
        display: none;
    }

    /* .particle {
        position: absolute;
        border-radius: 50%;
        background: rgba(126, 87, 194, 0.3);
        animation: float 15s infinite linear;
    } */


    .header {
        text-align: center;
        padding: 0rem 1rem;
        position: relative;
        overflow: hidden;
    }

    .header h1 {
        font-size: 3.5rem;
        font-weight: 800;
        margin-bottom: 1rem;
        background: #8A2BE2;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        position: relative;
        display: inline-block;
    }

    .header h1::after {
        content: '';
        position: absolute;
        bottom: -10px;
        left: 50%;
        transform: translateX(-50%);
        width: 200px;
        height: 4px;
        background: linear-gradient(90deg, transparent, var(--accent), transparent);
        border-radius: 2px;
    }

    .header p {
        max-width: 640px;
        margin: 0 auto;
    }

    .badge-container {
        max-width: 1400px;
        margin: 0 auto;
    }

    .achievement-count {
        display: flex;
        justify-content: space-around;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 20px;
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        margin: 1rem 0;
        position: relative;
        overflow: hidden;
    }

    .achievement-count::before {
        content: "";
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
        transform: rotate(45deg);
        animation: shimmer 3s infinite;
    }

    @keyframes shimmer {
        0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
        100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
    }

    .count-item {
        text-align: center;
        position: relative;
        z-index: 1;
        padding: 0 1.5rem;
    }

    .count-number {
        display: block;
        font-size: 2.75rem;
        font-weight: 800;
        color: white;
        margin-bottom: 0.75rem;
        text-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
    }

    .count-label {
        font-size: 0.9rem;
        color: rgba(255, 255, 255, 0.9);
        text-transform: uppercase;
        letter-spacing: 1.5px;
        font-weight: 600;
    }

    .badge-card {
            background: #00246b;
            border-radius: 25px;
            overflow: hidden;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            box-shadow: 
                0 15px 35px rgba(0, 0, 0, 0.5),
                inset 0 1px 0 rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            height: 100%;
            display: flex;
            flex-direction: column;
            transform-style: preserve-3d;
            perspective: 1000px;
        }
        
        .badge-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, 
                var(--primary) 0%, 
                var(--secondary) 25%, 
                var(--accent) 50%, 
                var(--secondary) 75%, 
                var(--primary) 100%);
            background-size: 200% 100%;
            animation: shimmer 3s infinite linear;
            z-index: 2;
        }
        
        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
        
        .badge-card::after {
            content: '';
            position: absolute;
            top: 5px;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, rgba(126, 87, 194, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(38, 198, 218, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(255, 64, 129, 0.05) 0%, transparent 50%);
            z-index: 1;
            opacity: 0;
            transition: opacity 0.5s ease;
        }
        
        .badge-card:hover {
            transform: 
                translateY(-20px) 
                scale(1.05) 
                rotateX(5deg) 
                rotateY(5deg);
            box-shadow: 
                0 25px 50px rgba(0, 0, 0, 0.6),
                0 0 0 1px rgba(255, 255, 255, 0.05),
                0 0 30px rgba(126, 87, 194, 0.3);
        }
        
        .badge-card:hover::after {
            opacity: 1;
        }
        
        .badge-card.pinned {
            border: 2px solid var(--gold);
            box-shadow: 
                0 25px 50px rgba(0, 0, 0, 0.6),
                0 0 30px rgba(255, 215, 0, 0.4);
            animation: pulse-gold 2s infinite alternate;
        }
        
        @keyframes pulse-gold {
            0% {
                box-shadow: 
                    0 25px 50px rgba(0, 0, 0, 0.6),
                    0 0 20px rgba(255, 215, 0, 0.3);
            }
            100% {
                box-shadow: 
                    0 25px 50px rgba(0, 0, 0, 0.6),
                    0 0 40px rgba(255, 215, 0, 0.6);
            }
        }
        
        .badge-header {
            padding: 2rem 1.5rem 0.5rem;
            text-align: center;
            position: relative;
            z-index: 3;
        }
        
        .badge-name {
            font-size: 1.4rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            color: #FFD700;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
            line-height: 1.3;
            position: relative;
            display: inline-block;
            max-width: 100%;
            padding: 0 1rem;
            margin-top: 30px;
        }
        
        /* Alternative: Multi-line with line clamping */
        .badge-name.multiline {
            white-space: normal;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            line-height: 1.4;
            max-height: 3.8rem;
            overflow: hidden;
        }
        
        /* Or use responsive font sizing */
        .badge-name.responsive {
            font-size: clamp(1.1rem, 2.5vw, 1.4rem);
            white-space: normal;
            word-wrap: break-word;
            word-break: break-word;
            padding: 0 0.5rem;
        }
        
        .badge-name::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 50%;
            transform: translateX(-50%);
            width: 50px;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--secondary), transparent);
            border-radius: 1px;
        }
        
        .badge-type {
            font-size: 0.9rem;
            color: var(--secondary);
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-top: 0.5rem;
        }
        
        .badge-image-container {
            position: relative;
            padding: 1.5rem;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-grow: 1;
            z-index: 3;
            overflow: hidden;
        }
        
        .badge-icon-wrapper {
            position: relative;
            width: 160px;
            height: 160px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .badge-icon {
            width: 130px;
            height: 130px;
            object-fit: contain;
            filter: 
                drop-shadow(0 10px 20px rgba(0, 0, 0, 0.5))
                brightness(1.1)
                saturate(1.2);
            z-index: 4;
            transition: all 0.7s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            transform-style: preserve-3d;
        }
        
        .badge-card:hover .badge-icon {
            transform: 
                scale(1.2) 
                rotate(10deg)
                translateZ(20px);
            filter: 
                drop-shadow(0 15px 25px rgba(0, 0, 0, 0.6))
                brightness(1.3)
                saturate(1.4);
        }
        
        .badge-glow {
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: radial-gradient(circle, var(--primary) 0%, transparent 70%);
            opacity: 0.3;
            z-index: 2;
            animation: pulse-glow 3s infinite alternate;
            filter: blur(10px);
        }
        
        @keyframes pulse-glow {
            0% {
                transform: scale(0.8);
                opacity: 0.2;
                filter: blur(10px);
            }
            100% {
                transform: scale(1.3);
                opacity: 0.5;
                filter: blur(15px);
            }
        }
        
        .orbital-ring {
            position: absolute;
            width: 180px;
            height: 180px;
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            z-index: 1;
            animation: rotate 20s linear infinite;
        }
        
        .orbital-ring::before,
        .orbital-ring::after {
            content: '';
            position: absolute;
            width: 15px;
            height: 15px;
            background: var(--accent);
            border-radius: 50%;
            top: -7.5px;
            left: 50%;
            transform: translateX(-50%);
            box-shadow: 0 0 10px var(--accent);
        }
        
        .orbital-ring::after {
            background: var(--secondary);
            top: auto;
            bottom: -7.5px;
            box-shadow: 0 0 10px var(--secondary);
        }
        
        @keyframes rotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .floating-particles {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 2;
        }
        
        .particle {
            position: absolute;
            width: 6px;
            height: 6px;
            background: var(--secondary);
            border-radius: 50%;
            opacity: 0;
            animation: float-particle 6s infinite linear;
        }
        
        @keyframes float-particle {
            0% {
                transform: translateY(0) translateX(0);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100px) translateX(20px);
                opacity: 0;
            }
        }
        
        .badge-footer {
            padding: 0.5rem 1.5rem 2rem;
            text-align: center;
            position: relative;
            z-index: 3;
        }
        
        .badge-name-bottom {
            font-size: 1.2rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: white;
            text-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            position: relative;
        }
        
        .badge-name-bottom::before {
            content: '✦';
            position: absolute;
            left: -25px;
            color: var(--secondary);
            animation: twinkle 2s infinite alternate;
        }
        
        .badge-name-bottom::after {
            content: '✦';
            position: absolute;
            right: -25px;
            color: var(--secondary);
            animation: twinkle 2s infinite alternate-reverse;
        }
        
        @keyframes twinkle {
            0% { opacity: 0.3; transform: scale(0.8); }
            100% { opacity: 1; transform: scale(1.2); }
        }
        
        .badge-status {
            display: inline-block;
            padding: 0.7rem 2rem;
            border-radius: 50px;
            font-weight: 800;
            font-size: 0.9rem;
            letter-spacing: 1px;
            background: #099dda;
            color: white;
            box-shadow: 
                0 8px 20px rgba(0, 0, 0, 0.4),
                inset 0 1px 0 rgba(255, 255, 255, 0.2);
            position: relative;
            overflow: hidden;
            transition: all 0.4s ease;
            text-transform: uppercase;
            z-index: 2;
        }
        
        .badge-status::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: all 0.6s ease;
        }
        
        .badge-status:hover::before {
            left: 100%;
        }
        
        .badge-status:hover {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 
                0 12px 25px rgba(0, 0, 0, 0.5),
                inset 0 1px 0 rgba(255, 255, 255, 0.3);
        }
        
        .badge-status.achieved {
            background: linear-gradient(45deg, var(--secondary), #00acc1);
            animation: status-pulse 3s infinite;
        }
        
        @keyframes status-pulse {
            0%, 100% {
                box-shadow: 
                    0 8px 20px rgba(0, 0, 0, 0.4),
                    inset 0 1px 0 rgba(255, 255, 255, 0.2);
            }
            50% {
                box-shadow: 
                    0 8px 25px rgba(38, 198, 218, 0.5),
                    inset 0 1px 0 rgba(255, 255, 255, 0.3);
            }
        }
        
        .pin-button-subtle {
            position: absolute;
            top: 12px;
            right: 17px;
            width: 36px;
            height: 36px;
            border-radius: 8px;
            display: flex
        ;
            align-items: center;
            justify-content: center;
            background: transparent;
            border: 2px solid #00b5ff !important;
            cursor: pointer;
            transition: all 0.3s 
        cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 10;
            border: none;
            color: #00b5ff;
        }
        
        .pin-button-subtle:hover {
            background: #dbeafe;
            color: #2563eb;
        }
        
        .pin-button-subtle.pinned {
            background: #1cbfd4;
            color: white;
            border: none !important;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        }
        
        .ribbon {
            position: absolute;
            top: 15px;
            left: -40px;
            padding: 10px 40px;
            background: linear-gradient(45deg, var(--gold), #ffed4e, var(--gold));
            color: var(--dark);
            font-size: 0.8rem;
            font-weight: 900;
            transform: rotate(-45deg);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            z-index: 5;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            animation: ribbon-shimmer 2s infinite alternate;
        }
        
        @keyframes ribbon-shimmer {
            0% {
                background: linear-gradient(45deg, var(--gold), #ffed4e, var(--gold));
            }
            100% {
                background: linear-gradient(45deg, #ffed4e, var(--gold), #ffed4e);
            }
        }
        
        .sparkle {
            position: absolute;
            width: 8px;
            height: 8px;
            background: white;
            border-radius: 50%;
            opacity: 0;
            z-index: 2;
        }
        
        .badge-card:hover .sparkle {
            animation: sparkle 1.5s ease-out;
        }
        
        @keyframes sparkle {
            0% {
                transform: scale(0) rotate(0deg);
                opacity: 0;
            }
            50% {
                opacity: 1;
            }
            100% {
                transform: scale(1) rotate(180deg);
                opacity: 0;
            }
        }

        .count-badge {
            position: absolute;
            top: 14px;
            right: 15px;
            background: var(--gold);
            color: var(--dark);
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-size: 20px;
            font-weight: 800;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            z-index: 10;
            border: 2px solid rgba(255, 255, 255, 0.5);
        }

        .awaiting-badge {
            position: absolute;
            top: 8px;
            right: 12px;
            background: #ff9e9e;
            color: var(--dark);
            padding: 0.3rem 0.8rem;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 800;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            z-index: 10;
            border: 2px solid rgba(255, 255, 255, 0.5);
        }
</style>

<!-- Awaiting Badges CSS -->
<style>
.awaiting-title {
    color: #ff3131;
    font-size: 2.2rem;
    font-weight: 700;
    margin-top: 10px;
    margin-bottom: 2rem;
    padding-left: 1.5rem;
    position: relative;
    text-align: center;
    display: block;
}

.awaiting-badge-card {
    background: #A9A9A9;
    border-radius: 25px;
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    position: relative;
    backdrop-filter: blur(15px);
    height: 100%;
    display: flex;
    flex-direction: column;
    opacity: 0.8;
    transform-style: preserve-3d;
    perspective: 1000px;
}

.awaiting-badge-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, 
        #64748b 0%, 
        #94a3b8 25%, 
        #cbd5e1 50%, 
        #94a3b8 75%, 
        #64748b 100%);
    background-size: 200% 100%;
    animation: shimmer 4s infinite linear;
    z-index: 2;
    opacity: 0.6;
}

.awaiting-badge-card::after {
    content: '';
    position: absolute;
    top: 4px;
    left: 0;
    right: 0;
    bottom: 0;
    background: 
        radial-gradient(circle at 20% 80%, rgba(100, 116, 139, 0.1) 0%, transparent 50%),
        radial-gradient(circle at 80% 20%, rgba(148, 163, 184, 0.1) 0%, transparent 50%),
        radial-gradient(circle at 40% 40%, rgba(203, 213, 225, 0.05) 0%, transparent 50%);
    z-index: 1;
    opacity: 0;
    transition: opacity 0.5s ease;
}

.awaiting-badge-card:hover {
    transform: translateY(-10px) scale(1.02);
    opacity: 0.9;
}

.awaiting-badge-card:hover::after {
    opacity: 1;
}

.awaiting-badge-header {
    padding: 2rem 1.5rem 0.5rem;
    text-align: center;
    position: relative;
    z-index: 3;
}

.awaiting-badge-name {
    font-size: 15px;
    font-weight: 800;
    margin-bottom: 0.5rem;
    color: #e2e8f0;
    text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
    line-height: 1.3;
    position: relative;
    display: block;
    max-width: 100%;
    padding: 0 1rem;
}

.awaiting-badge-name::after {
    content: '';
    position: absolute;
    bottom: -8px;
    left: 50%;
    transform: translateX(-50%);
    width: 40px;
    height: 2px;
    background: linear-gradient(90deg, transparent, #94a3b8, transparent);
    border-radius: 1px;
    opacity: 0.6;
}

.awaiting-badge-type {
    font-size: 11px;
    color: #000;
    font-weight: 600;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    margin-top: 0.8rem;
    opacity: 0.8;
}

.awaiting-badge-image-container {
    position: relative;
    padding: 0.5rem;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-grow: 1;
    z-index: 3;
}

.awaiting-badge-icon-wrapper {
    position: relative;
    width: 140px;
    height: 140px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.awaiting-badge-icon {
    width: 100px;
    height: 100px;
    object-fit: contain;
    filter: grayscale(100%) brightness(0.6) opacity(0.7);
    transition: all 0.5s ease;
    z-index: 4;
}

.awaiting-badge-card:hover .awaiting-badge-icon {
    filter: grayscale(80%) brightness(0.8) opacity(0.9);
    transform: scale(1.1);
}

.awaiting-orbital-ring {
    position: absolute;
    width: 150px;
    height: 150px;
    border: 2px solid rgb(21 21 22 / 20%);
    border-radius: 50%;
    z-index: 1;
    animation: rotate-slow 25s linear infinite;
}

@keyframes rotate-slow {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.awaiting-badge-footer {
    padding: 0.5rem 1.5rem 2rem;
    text-align: center;
    position: relative;
    z-index: 3;
}

.awaiting-badge-status {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 0.8rem 2.2rem;
    border-radius: 50px;
    font-weight: 800;
    font-size: 0.85rem;
    letter-spacing: 2px;
    background: linear-gradient(135deg, #4a5568 0%, #2d3748 100%);
    color: #cbd5e1;
    box-shadow: 
        0 8px 20px rgba(0, 0, 0, 0.4),
        inset 0 1px 0 rgba(255, 255, 255, 0.1),
        inset 0 -1px 0 rgba(0, 0, 0, 0.3);
    position: relative;
    overflow: hidden;
    text-transform: uppercase;
    border: 1px solid rgba(255, 255, 255, 0.05);
    transition: all 0.3s ease;
}

.awaiting-badge-status::before {
    content: '🔒';
    margin-right: 8px;
    font-size: 0.9rem;
}

.awaiting-badge-status::after {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    transition: all 0.6s ease;
}

.awaiting-badge-card:hover .awaiting-badge-status {
    color: #e2e8f0;
    box-shadow: 
        0 10px 25px rgba(0, 0, 0, 0.5),
        inset 0 1px 0 rgba(255, 255, 255, 0.15);
}

.awaiting-badge-card:hover .awaiting-badge-status::after {
    left: 100%;
}

/* Floating particles for awaiting badges */
.awaiting-particles {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: 2;
}

.awaiting-particle {
    position: absolute;
    width: 4px;
    height: 4px;
    background: #94a3b8;
    border-radius: 50%;
    opacity: 0;
    animation: float-particle-slow 8s infinite linear;
}

@keyframes float-particle-slow {
    0% {
        transform: translateY(0) translateX(0);
        opacity: 0;
    }
    10% {
        opacity: 0.3;
    }
    90% {
        opacity: 0.3;
    }
    100% {
        transform: translateY(-80px) translateX(15px);
        opacity: 0;
    }
}
</style>

<div class="particles" id="particles"></div>

<!-- Header Section -->
<div class="header">
    <h1>Leader Board</h1>
    <p class="fs-5 text-danger fw-semibold">Celebrating your achievements and milestones with exclusive badges</p>
</div>

<!-- Badge Container -->
<div class="badge-container">
    <!-- Achievement Stats -->
    <div class="achievement-count py-2">
        <div class="count-item mb-2">
            <span class="count-number" id="total-badges">0</span>
            <span class="count-label">Total Badges</span>
        </div>
        <div class="count-item">
            <span class="count-number" id="achieved-badges">0</span>
            <span class="count-label">Achieved</span>
        </div>
        <div class="count-item">
            <span class="count-number" id="pinned-badges">0</span>
            <span class="count-label">Pinned</span>
        </div>
    </div>

    <div class="container py-2">
        <div class="row mt-2" id="achieved-heading-container" style="display: none;">
            <div class="col-12">
                <h3 class="section-title awaiting-title">Achieved Badges</h3>
            </div>
        </div>
        <div class="card rounded shadow-sm mb-4" id="achieved-badges-card" style="display: none;">
            <div class="card-body">
                <div class="row" id="badge-container">
                    <!-- Cards will be generated here -->
                </div>
            </div>
        </div>

        <div class="row mt-4" id="awaiting-heading-container" style="display: none;">
            <div class="col-12">
                <h3 class="section-title awaiting-title">Awaiting Badges</h3>
            </div>
        </div>
        <div class="card rounded shadow-sm mb-4" id="awaiting-badges-card" style="display: none;">
            <div class="card-body">
                <div class="row" id="awaiting-badges-container">
                    <!-- 6 placeholder cards will be generated here -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Toastr Starts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .toast-info {
            background-color: #7239ea;
        }
    </style>

    <script>
        @if (Session::has('toastr'))
                        var type = "{{ Session::get('toastr')['type'] }}";
                        var message = "{{ Session::get('toastr')['message'] }}";
                        toastr[type](message);
                    @endif
    </script>
<!-- Toastr Ends -->

<script>
    // Create animated background particles
    function createParticles() {
        const particlesContainer = document.getElementById('particles');
        const colors = ['#7e57c2', '#26c6da', '#ff4081', '#5e35b1'];
        
        for (let i = 0; i < 50; i++) {
            const particle = document.createElement('div');
            particle.classList.add('particle');
            
            const size = Math.random() * 30 + 10;
            particle.style.width = `${size}px`;
            particle.style.height = `${size}px`;
            
            particle.style.left = `${Math.random() * 100}vw`;
            particle.style.top = `${Math.random() * 100}vh`;
            
            const color = colors[Math.floor(Math.random() * colors.length)];
            particle.style.background = color;
            
            particle.style.animationDuration = `${Math.random() * 20 + 10}s`;
            particle.style.animationDelay = `${Math.random() * 5}s`;
            
            particlesContainer.appendChild(particle);
        }
    }
    
    // Sample badge data
    function createEnhancedBadgeCard() {
        const badgeContainer = document.getElementById('badge-container');

        $.ajax({
            url: `/exam_badge_data_fetch`,
            method: 'GET',
            success: function (response) {
                if (response.status === 200) {
                    const badges = [];

                    if(response.data.length > 0) {
                        $('#achieved-badges-card').show();
                        $('#achieved-heading-container').show();
                    } else {
                        $('#achieved-badges-card').hide();
                        $('#achieved-heading-container').hide();
                    }

                    // ✅ Collect all badges
                    response.data.forEach(badge => {
                        badges.push({
                            id: badge.id,
                            name: badge.name,
                            type: badge.type,
                            badgeType : badge.badge_type,
                            image: badge.image,
                            category: badge.category,
                            desc: badge.desc,
                            status: badge.status,
                            pinned: badge.pinned,
                            count: badge.count
                        });
                    });

                    // ✅ Clear old cards
                    badgeContainer.innerHTML = '';

                    // ✅ Render all badge cards
                    badges.forEach(badge => {
                        // Generate sparkles
                        let sparklesHTML = '';
                        for (let i = 0; i < 12; i++) {
                            const x = Math.random() * 100;
                            const y = Math.random() * 100;
                            const delay = Math.random() * 2;
                            sparklesHTML += `<div class="sparkle" style="top:${y}%; left:${x}%; animation-delay:${delay}s;"></div>`;
                        }

                        // Generate floating particles
                        let particlesHTML = '';
                        for (let i = 0; i < 8; i++) {
                            const x = Math.random() * 100;
                            const delay = Math.random() * 6;
                            const duration = 3 + Math.random() * 4;
                            particlesHTML += `<div class="particle" style="left:${x}%; bottom:0; animation-delay:${delay}s; animation-duration:${duration}s;"></div>`;
                        }

                        // Create outer col div (6 per row)
                        const col = document.createElement('div');
                        col.className = 'col-lg-3 col-md-4 col-sm-6 mb-4';

                        // Create card
                        const card = document.createElement('div');
                        card.className = `badge-card ${badge.pinned ? 'pinned' : ''}`;

                        card.innerHTML = `
                            ${badge.pinned ? '<div class="ribbon">PINNED</div>' : ''}

                            <div class="count-badge">${badge.count}</div>

                            <div class="floating-particles">${particlesHTML}</div>
                            ${sparklesHTML}

                            <div class="badge-header">
                                <div class="badge-name">${badge.name}</div>
                                <div class="badge-type">${badge.type}</div>
                            </div>

                            <div class="badge-image-container">
                                <div class="orbital-ring"></div>
                                <div class="badge-icon-wrapper">
                                    <div class="badge-glow"></div>
                                    <img src="${badge.image}" alt="${badge.name}" class="badge-icon">
                                </div>
                            </div>

                            <div class="badge-name-bottom d-block text-center">${badge.category}</div>

                            <div class="badge-footer d-flex justify-content-center gap-4 align-items-center">
                                <div>
                                    <div class="badge-status ${badge.status.toLowerCase()}">${badge.status}</div>
                                </div>
                                <button class="pin-button-subtle ${badge.pinned ? 'pinned' : ''}" onclick="togglePin(this, ${badge.id}, 'exam')">
                                    <i class="mdi mdi-pin"></i>
                                </button>
                            </div>
                        `;

                        // Append
                        col.appendChild(card);
                        badgeContainer.appendChild(col);
                    });

                    // renderBadges(response.data);
                    updateBadgeCounts();
                    updateBadge();
                    animateCounts();
                }
            },
            error: function (err) {
                console.error('Error Fetching Exam Badges:', err);
            }
        });
    }
        
    // Toggle pin function
    function togglePin(button, id, type) {
        const badgeCard = button.closest('.badge-card');
        const ribbon = badgeCard.querySelector('.ribbon');
        const icon = button.querySelector('i');
        const isPinned = button.classList.contains('pinned');
        
        if (isPinned) {
            // Unpin
            button.classList.remove('pinned');
            badgeCard.classList.remove('pinned');
            icon.classList.remove('mdi-pin');
            icon.classList.add('mdi-pin-outline');
            if (ribbon) ribbon.remove();
        } else {
            // Pin
            button.classList.add('pinned');
            badgeCard.classList.add('pinned');
            icon.classList.remove('mdi-pin-outline');
            icon.classList.add('mdi-pin');
            if (!ribbon) {
                const newRibbon = document.createElement('div');
                newRibbon.className = 'ribbon';
                newRibbon.textContent = 'PINNED';
                badgeCard.prepend(newRibbon);;
            }
        }
        

        fetch('/toggle_pin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                sno: id,
                pinned: !isPinned
            })
        })
        .then(res => res.json())
        .then(data => {
            toastr.success(data.message);
            updateBadgeCounts();
            updateBadge();
        })
        .catch(err => {
            console.error('Error toggling pin:', err);
        });
    }
        
        // Initialize the badge card
        document.addEventListener('DOMContentLoaded', createEnhancedBadgeCard);
    
    // Update badge counts
    function updateBadgeCounts() {
        const totalBadges = document.querySelectorAll('.badge-card').length;
        const achievedBadges = totalBadges;
        const pinnedBadges = document.querySelectorAll('.pin-button-subtle.pinned').length;
        
        document.getElementById('total-badges').textContent = totalBadges;
        document.getElementById('achieved-badges').textContent = totalBadges;
        document.getElementById('pinned-badges').textContent = pinnedBadges;
    }
    
    // Initialize the page
    document.addEventListener('DOMContentLoaded', function() {
        createParticles();
        // renderBadges();
        
        // Animate counting up the badge numbers
        animateCounts();
        updateBadge();
    });
    
    // Animate the counting up of badge numbers
    function animateCounts() {
        const totalElement = document.getElementById('total-badges');
        const achievedElement = document.getElementById('achieved-badges');
        const pinnedElement = document.getElementById('pinned-badges');
        
        const total = document.querySelectorAll('.badge-card').length;
        const achieved = total;
        const pinned = document.querySelectorAll('.pin-button-subtle.pinned').length;

        animateValue(totalElement, 0, total, 1500);
        animateValue(achievedElement, 0, achieved, 1500);
        animateValue(pinnedElement, 0, pinned, 1500);
    }
    
    // Helper function to animate counting up
    function animateValue(element, start, end, duration) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            const value = Math.floor(progress * (end - start) + start);
            element.textContent = value;
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    }
</script>

<!-- AWAITING BADGES -->
<script>

    $(document).ready(function() {
        createAwaitingBadges();
    });
    function createAwaitingBadges() {
        const awaitingContainer = document.getElementById('awaiting-badges-container');

        $.ajax({
            url: `/exam_badge_data_fetch`,
            method: 'GET',
            success: function (response) {
                if (response.status === 200) {
                    const awaitingBadges = [];

                    if(response.missed.length > 0) {
                        $('#awaiting-heading-container').show();
                        $('#awaiting-badges-card').show();
                    } else {
                        $('#awaiting-heading-container').hide();
                        $('#awaiting-badges-card').hide();
                    }

                    response.missed.forEach(badge => {
                        awaitingBadges.push({
                            id: badge.id,
                            name: badge.name,
                            type: badge.type,
                            badgeType : badge.badge_type,
                            image: badge.image,
                            category: badge.category,
                            desc: badge.desc,
                            status: badge.status,
                            pinned: badge.pinned,
                            count: badge.count
                        });
                    });

                    awaitingContainer.innerHTML = '';

                    awaitingBadges.forEach((badge, index) => {
                        // Generate particles for each card
                        let particlesHTML = '';
                        for (let i = 0; i < 6; i++) {
                            const x = Math.random() * 100;
                            const delay = Math.random() * 8;
                            const duration = 4 + Math.random() * 4;
                            particlesHTML += `<div class="awaiting-particle" style="left:${x}%; bottom:0; animation-delay:${delay}s; animation-duration:${duration}s;"></div>`;
                        }

                        const col = document.createElement('div');
                        col.className = 'col-lg-2 col-md-4 col-sm-6 mb-4';
                        col.setAttribute('data-bs-toggle', 'tooltip');
                        col.setAttribute('data-bs-placement', 'top');
                        col.setAttribute('title', `Locked - Complete challenges to unlock`);

                        col.innerHTML = `
                            <div class="awaiting-badge-card">
                                 <div class="awaiting-badge">${badge.count}</div>
                                <div class="awaiting-particles">${particlesHTML}</div>
                                
                                <div class="awaiting-badge-header">
                                    <div class="awaiting-badge-name">${badge.name}</div>
                                    <div class="awaiting-badge-type text-truncate text-secondary">${badge.type}</div>
                                </div>

                                <div class="awaiting-badge-image-container">
                                    <div class="awaiting-orbital-ring"></div>
                                    <div class="awaiting-badge-icon-wrapper">
                                        <img src="${badge.image}" alt="${badge.name}" class="awaiting-badge-icon">
                                    </div>
                                </div>

                                <div class="awaiting-badge-footer">
                                    <div class="awaiting-badge-status">Locked</div>
                                </div>
                            </div>
                        `;

                        awaitingContainer.appendChild(col);
                    });

                    // Initialize tooltips
                    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                    tooltipTriggerList.map(function (tooltipTriggerEl) {
                        return new bootstrap.Tooltip(tooltipTriggerEl);
                    });
                }
            },
            error: function (err) {
                console.error('Error Fetching Awaiting Badges:', err);
            }
        });
    }
</script>
@endsection