@extends('layouts/layoutMaster')

@section('title', 'Manage Attendance')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

<!-- Lead List Table -->
 @php
    $helper = new \App\Helpers\Helpers();
@endphp
<style>
    .fixed-attendance-btn,
.fixed-attendance-btn:hover,
.fixed-attendance-btn:focus,
.fixed-attendance-btn:active {
    background-color: #099dd9 !important; /* or your theme color */
    color: #fff !important;
    border-color: #099dd9 !important;
}
</style>
<div class="card">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between flex-wrap">
        <div class="card-action-title fs-5 mb-1">
            <h5 class="card-title mb-1">Manage Attendance</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">HR Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="mb-0 d-flex justify-content-end align-items-center align-self-end justify-self-end">
            <div class="me-2 mb-2 w-60">
                <div class="cursor-pointer input-group input-group-merge">
                    <span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="ovr_month_fill" class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class" value="<?php echo $month_filter ?? date("M-Y"); ?>" readonly onchange="month_filter(this.value)">
                    <!--<span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-menu-down fs-4"></i></span>-->
                </div>
            </div>
            <div class=" mb-2">
                 <a  href="javascript:;"  data-bs-toggle="modal" data-bs-target="#kt_modal_view_individual_staff_attendance_year" aria-selected="false"  class="btn btn-md fw-bold btn-primary"   onclick="fetchYearlyAttendance(new Date().getFullYear())">OverAll</a>
            </div>
        </div>
    </div>
   
    <div class="card-body">
        <div class="d-flex justify-content-end align-items-center mb-2" >
            <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_staff_attendance">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Attendance
            </a> -->
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white fixed-attendance-btn" data-bs-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Attendance
            </a>
            <div class="dropdown-menu dropdown-menu-end">
                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_attendance_present">
                    <label class="badge bg-success fw-bold text-black fw-bold rounded px-2 py-1"><span>P</span></label> 
                    Present
                </a>
                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_attendance_absent">
                    <label class="badge bg-danger text-white rounded px-2 py-1"><span>A</span></label>
                    Absent
                </a>
                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_attendance_leave">
                    <label class="badge bg-info text-white rounded px-2 py-1"><span>L</span></label>
                    Leave
                </a>
                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_attendance_permission">
                    <label class="badge bg-primary text-white rounded px-2 py-1"><span>Pr</span></label>
                    Permission
                </a>
                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_attendance_onduty">
                    <label class="badge bg-secondary text-white rounded px-2 py-1"><span>OD</span></label>
                    On Duty
                </a>
                
            </div>
            
        </div>
        <div class="d-flex justify-content-end align-items-center mt-2">
            <div class="d-flex align-items-cstify-center me-3">
                <label class="badge rounded text-black fw-bold px-2 py-1 mb-1"
                    style="background-image: linear-gradient(to right, #4facfe 0%, #00f2fe 100%);">
                    <span>HD</span>
                </label>
                <span class="fs-6 fw-semibold ms-1">Holiday</span>
            </div>
            <div class="d-flex align-items-cstify-center me-3">
                <label class="badge bg-success fw-bold text-black fw-bold rounded px-2 py-1"><span>P</span></label>
                <span class="fs-6 fw-semibold ms-1">Present</span>
            </div>
            <div class="d-flex align-items-center justify-center me-3">
                <label class="badge bg-danger text-white rounded px-2 py-1"><span>A</span></label>
                <span class="fs-6 fw-semibold ms-1">Absent</span>
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Leave Without Intimation"><i class="mdi mdi-information-slab-circle"></i></span>
            </div>
            <div class="d-flex align-items-center justify-center me-3">
                <label class="badge bg-info text-white rounded px-2 py-1"><span>L</span></label>
                <span class="fs-6 fw-semibold ms-1">Leave</span>
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Leave With Intimation"><i class="mdi mdi-information-slab-circle"></i></span>
            </div>
            <div class="d-flex align-items-center justify-center me-3">
                <label class="badge bg-secondary text-white rounded px-2 py-1"><span>OD</span></label>
                <span class="fs-6 fw-semibold ms-1">On Duty</span>
                <div class="">
                    <a href="#" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown" data-trigger="hover" aria-expanded="false">
                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"><i class="mdi mdi-information-slab-circle text-dark"></i></span>
                    </a>
                    <div class="dropdown-menu py-2 px-4 text-black scroll-y w-250px max-h-250px">
                        <div class="d-flex align-items-center mb-2 ">
                            <label><span class="badge bg-secondary rounded text-white px-2 py-1">30 M</span></label>
                            <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                            <label class="fs-6 fw-semibold">30 Minutes</label>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <label><span class="badge bg-secondary rounded text-white px-2 py-1">1 H</span></label>
                            <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                            <label class="fs-6 fw-semibold">1 Hour</label>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <label><span class="badge bg-secondary rounded text-white px-2 py-1">1.5 H</span></label>
                            <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                            <label class="fs-6 fw-semibold">1.5 Hours</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-center me-3">
                <label class="badge bg-primary text-white rounded px-2 py-1"><span>Pr</span></label>
                <span class="fs-6 fw-semibold ms-1">Permission</span>
                <a href="#" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown" data-trigger="hover" aria-expanded="false">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom"><i class="mdi mdi-information-slab-circle text-dark"></i></span>
                </a>
                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-250px max-h-250px">
                    <div class="d-flex align-items-center mb-2 ">
                        <label><span class="badge bg-primary rounded text-white px-2 py-1">30 M</span></label>
                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                        <label class="fs-6 fw-semibold">30 Minutes</label>
                    </div>
                    <div class="d-flex align-items-center mb-2">
                        <label><span class="badge bg-primary rounded text-white px-2 py-1">1 H</span></label>
                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                        <label class="fs-6 fw-semibold">1 Hour</label>
                    </div>
                    <div class="d-flex align-items-center mb-2">
                        <label><span class="badge bg-primary rounded text-white px-2 py-1">1.5 H</span></label>
                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                        <label class="fs-6 fw-semibold">Half Day</label>
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-center me-3">
                <label class="badge text-white rounded px-2 py-1" style="background-color:#f47507;"><span>WK</span></label>
                <span class="fs-6 fw-semibold ms-1">Week End</span>
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Leave With Intimation"><i class="mdi mdi-information-slab-circle"></i></span>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                 <div class="table-container1">
                    <table class="table_1 sticky_table table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page ">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-200px text-center">Staff</th>
                                @foreach($dates as $date)
                                @php
                                    $dateFormatted = \Carbon\Carbon::parse($date)->format('d/m');
                                    $dayOfWeek = \Carbon\Carbon::parse($date)->format('D');
                                @endphp
                                <th class="min-w-25px text-center">
                                    <a href="javascript:;"  class="attendance-date text-white" data-date="{{ $date }}" data-bs-toggle="modal" data-bs-target="#kt_modal_view_individual_day_attendance">
                                        <div>{{ $dateFormatted }}</div>
                                        <div>{{ $dayOfWeek }}</div>
                                    </a>
                                </th>
                                @endforeach
                                <th class="min-w-150px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold">
                            @if(isset($staffs))
                            @foreach($staffs as $staff)

                                @php
                                $position = $helper->get_position_id($staff->position_role);
                                $positionName = $position ? $position->job_position_name : '-';
                                @endphp
                            <tr>
                                <td>
                                    <div class="d-flex px-1">
                                    @if ($staff->staff_image && file_exists(public_path('staff_images/' . $staff->staff_image)))
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle" data-kt-image-input="true" style="background-image: url(assets/images/staff_1.png)">
                                                <img src="{{ asset('staff_images/' . $staff->staff_image) }}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                            </div>
                                        </div>
                                        @else
                                            <div class="symbol symbol-35px me-2">
                                                @php
                                                    $initial = strtoupper(substr($staff->staff_name, 0, 1));
                                                    echo $helper->name_image($initial, $staff->gender);
                                                @endphp
                                            </div>
                                        @endif
                                           <div class="ms-2 d-flex align-items-center staff-member" data-staff-id="{{ $staff->staff_id }}">
                                                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_view_individual_staff_attendance"
                                                    onclick="showStaffAttendance({{ $staff->staff_id }})">
                                                    <div class="d-flex flex-column">
                                                        <!-- Name and Gender Icon on the Same Line -->
                                                        <div class="d-flex align-items-center">
                                                            <span class="fs-7 me-1 text-black text-truncate max-w-150px" title="Staff Name" data-bs-toggle="tooltip" data-bs-placement="bottom">{{ $staff->staff_name }}</span>
                                                            @if ($staff->gender === 1)
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male">
                                                                    <i class="mdi mdi-face-man text-info"></i>
                                                                </span>
                                                            @elseif ($staff->gender === 2)
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Female">
                                                                    <i class="mdi mdi-face-woman text-danger"></i>
                                                                </span>
                                                            @else
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Other">
                                                                    <i class="mdi mdi-face text-primary"></i>
                                                                </span>
                                                            @endif
                                                        </div>
                                    
                                                        <!-- Department and Percentage on the Same Line -->
                                                        <div class="d-flex align-items-center gap-1">
                                                            <label class="badge bg-label-info text-info fw-bold fs-9" title="Department" data-bs-toggle="tooltip" data-bs-placement="bottom">{{ $staff->department_name }}</label>
                                                            <span class="badge bg-primary text-white rounded fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Overall Percentage For Present">
                                                                {{ $attendanceSummary[$staff->staff_id]['present_percentage'] ?? '0' }} %
                                                            </span>
                                                        </div>
                                                        
                                                    </div>
                                                    @if($staff->notice_check == 1)
                                                    <label class="fs-7 fw-semibold bg-danger text-white px-2 animation-blink">Notice Period</label>
                                                    @endif
                                                </a>
                                            </div>
                                    </div>
                                </td>
                                @foreach ($dates as $date) 
                                    @php
                                        // Get attendance records for the current staff member on the specific date
                                        $attendanceRecordsForDate = $attendanceRecords->get($staff->staff_id, collect())->filter(function ($record) use ($date) {
                                            // Convert the record's date to Y-m-d format to match the date format of your backend date data
                                            $recordDate = \Carbon\Carbon::parse($record['date'])->format('Y-m-d');
                                            
                                            // Also convert the current date to Y-m-d format (since backend data has a timestamp)
                                            $formattedDate = \Carbon\Carbon::parse($date)->format('Y-m-d');
                                            
                                            return $recordDate === $formattedDate;
                                        });

                                        
                                        // Check if the date is a week off
                                        $isWeekoff = $staff->weekoff === \Carbon\Carbon::parse($date)->format('D');
                                
                                        // Initialize variables for different attendance types
                                        $hasP = $attendanceRecordsForDate->contains('attendance', 'P');
                                        $hasL = $attendanceRecordsForDate->contains('attendance', 'L');
                                        $hasA = $attendanceRecordsForDate->contains('attendance', 'A');
                                        $hasOD = $attendanceRecordsForDate->contains('attendance', 'OD');
                                        $hasPR = $attendanceRecordsForDate->contains('attendance', 'PR');
                                    @endphp
                                    
                                                <td>
                                                    @if ($isWeekoff)
                                                        <label class="badge rounded text-white fw-bold px-2 py-1" style="background-color: #F67D2A">
                                                            <span>WK</span>
                                                        </label>
                                                    @elseif ($attendanceRecordsForDate->isNotEmpty())
                                                        @foreach ($attendanceRecordsForDate as $attendance)
                                                            @switch($attendance['attendance'])
                                                                @case('P')
                                                                    <label class="badge bg-success text-black rounded px-2 py-1">
                                                                        <span>P</span>
                                                                    </label>
                                                                    @break
                                                                @case('L')
                                                                    <label class="badge bg-info rounded text-white fw-bold px-2 py-1">
                                                                        <span>L</span>
                                                                    </label>
                                                                    @break
                                                                @case('A')
                                                                    <label class="badge bg-danger text-white rounded px-2 py-1">
                                                                        <span>A</span>
                                                                    </label>
                                                                    @break
                                                                @case('OD')
                                                                    <label class="badge rounded bg-secondary text-white px-2 py-1 mb-1" >
                                                                        <span>{{ $attendance['time_difference'] ?? 'OD' }}</span>
                                                                    </label>
                                                                    @break
                                                                @case('PR')
                                                                    <label class="badge rounded bg-primary text-white px-2 py-1 mb-1" >
                                                                        <span>{{ $attendance['time_difference'] ?? 'PR' }}</span>
                                                                    </label>
                                                                    @break
                                                                @case('HD')
                                                                    <label class="badge rounded text-black fw-bold px-2 py-1 mb-1"
                                                                        style="background-image: linear-gradient(to right, #4facfe 0%, #00f2fe 100%);">
                                                                        <span>HD</span>
                                                                    </label>
                                                                    @break
                                                                @default
                                                                    <label class="badge rounded text-black fw-bold px-2 py-1">
                                                                        <span>-</span>
                                                                    </label>
                                                            @endswitch
                                                        @endforeach
                                                    @else
                                                        <label class="badge rounded text-black fw-bold px-2 py-1">
                                                            <span>-</span>
                                                        </label>
                                                    @endif
                                                </td>
                                            @endforeach
                                <td align="center">
                                    <span class="text-end">
                                        <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff_attendance"  onclick="ViewFetch('{{ $staff->staff_id }}','{{ $staff->staff_name }}','{{ $staff->gender }}','{{ $staff->department_name }}','{{ $staff->branch_name }}','{{ $staff->nick_name }}','{{ $staff->email_id }}','{{ $staff->mobile_no }}','{{$positionName}}', '{{ $staff->notice_check }}')">
                                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span></a>
                                        <!-- <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_staff_attendance" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                        </a> -->
                                    </span>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Mark Present Attendance   -->
<div class="modal fade" id="kt_modal_attendance_present" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Mark Present Attendance</h3>
                </div>
                <form id="attendanceForm">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text "><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" class="form-control common_date_class" id="attend_date" name="attend_date" readonly value="<?php echo date("d-M-Y"); ?>"  />
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                            <select id="department_add" name="department_id" class="select3 form-select select2-hidden-accessible validation_feild" tabindex="-1" aria-hidden="true">
                                <option value="" >Select Department</option>
                            </select>
                            <div id="department_add_err" class="text-danger"></div>
                        </div>
                        
                        <div class="col-lg-2 mb-3 text-center">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Attendance</label>
                            <div class="d-block">
                                <label class="badge bg-success text-white mb-1 fs-6 fw-semibold">Present</label>
                                <input type="hidden" class="form-control" name="entry_select" value="1"  />
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                            <select id="staff_add" name="staff_id[]" class="select3 form-select validation_feild" multiple onchange="staff_change()">
                                <option value="all" selected>All</option>
                            </select>
                              <div id="staff_add_err" class="text-danger"></div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="markPresentBtn" class="btn btn-primary" onclick="mark_present_att_func()">Mark Present Attendance</button>
                        </div>
                    </div>
                </form>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
</div>
<!--end::Modal - Mark Present Attendance-->

<!--begin::Modal - Mark Absent Attendance   -->
<div class="modal fade" id="kt_modal_attendance_absent" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Mark Absent Attendance</h3>
                </div>
                <form id="attendanceFormabsent">
                    <div class="row">
                        <div class="col-lg-8 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text "><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" class="form-control common_date_class" id="attend_date_absent" name="attend_date" readonly value="<?php echo date("d-M-Y"); ?>"  />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3 text-center">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Attendance</label>
                            <div class="d-block">
                                <label class="badge bg-danger text-white mb-1 fs-6 fw-semibold">Absent</label>
                                <input type="hidden" class="form-control" name="entry_select" value="2"  />
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                            <select id="department_add_absent" name="department_id" class="select3 form-select validation_message_absent"
                            placeholder="Select Department Name">
                            </select>
                            <div id="department_add_absent_err" class="text-danger"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                            <select id="staff_add_absent" name="staff_id[]" class="select3 form-select validation_message_absent" multiple placeholder="Select Staff">
                                
                            </select>
                            <div id="staff_add_absent_err" class="text-danger"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Reason</label>
                            <textarea class="form-control" rows="3" name="reason" placeholder="Enter Reason"></textarea>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                            <button type="button" id="absentBtn" class="btn btn-primary" onclick="mark_absent_att_func()">Mark Absent Attendance</button>
                            {{-- <a href="{{url('/hr_management/staff/staff_reschedule')}}" class="btn btn-primary">Mark Absent Attendance</a> --}}
                        </div>
                    </div>
                </form>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
</div>
<!--end::Modal - Mark Absent Attendance-->

<!--begin::Modal - Mark Leave Attendance   -->
<div class="modal fade" id="kt_modal_attendance_leave" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Mark Leave Attendance</h3>
                </div>
                <form id="attendanceFormleave">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Attendance Type<span class="text-danger">*</span></label>
                            <select id="attendance_type_add" name="attendance_type_add" class="select3 form-select" onchange="attendance_type_func_add()">
                                <option value="today">Today</option>
                                <option value="tomorrow">Tomorrow</option>
                                <option value="custom">Custom</option>
                            </select>
                            <div id="attendance_type_add_err" class="text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3" id="attd_type_today_add" style="display: block;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Today Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200i"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3" id="attd_type_tomor_add" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Tomorrow Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200i"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <?php
                                $currentDate = new DateTime();
                                $currentDate->modify('+1 days');
                                $futureDate = $currentDate->format('d-M-Y');
                                ?>
                                <input type="text" class="form-control" value="<?php echo $futureDate; ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3" id="attd_type_custom_add" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Custom Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="custom_date_add" name="attendance_date_range_add" class="form-control common_date_class" readonly value="<?php echo date("d-M-Y"); ?>" />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3 text-center">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Attendance</label>
                            <div class="d-block">
                                <label class="badge bg-warning text-black mb-1 fs-6 fw-semibold">Leave</label>
                                <input type="hidden" class="form-control" name="entry_select" value="5"  />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                            <select id="department_add_leave" name="department_id" class="select3 form-select validation_message_leave"
                            placeholder="Select Department Name">
                            </select>
                            <div id="department_add_leave_err" class="text-danger"></div>
                        </div>
                        <div class="col-lg-8 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                            <select id="staff_add_leave" name="staff_id[]" class="select3 form-select validation_message_leave" multiple placeholder="Select Staff">
                                    
                            </select>
                            <div id="staff_add_leave_err" class="text-danger"></div>
                        </div>
                        
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3" name="reason" id="reason_leave"  placeholder="Enter Reason"></textarea>
                             <div id="reason_leave_err" class="text-danger"></div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                            <button type="button" id="leaveBtn" class="btn btn-primary" onclick="mark_leave_att_func()" >Mark Leave Attendance</button>
                        </div>
                    </div>
                </form>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
</div>
<!--end::Modal - Mark Leave Attendance-->

<!--begin::Modal - Mark Permission Attendance   -->
<div class="modal fade" id="kt_modal_attendance_permission" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Mark Permission Attendance</h3>
                </div>
                <form id="attendanceFormpermission">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Attendance Type<span class="text-danger">*</span></label>
                            <select id="perm_attendance_type_add" name="attendance_type_add" class="select3 form-select" onchange="perm_attendance_type_func_add()">
                                <option value="today">Today</option>
                                <option value="tomorrow">Tomorrow</option>
                                <option value="custom">Custom</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3" id="perm_attd_type_today_add" style="display: block;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Today Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200i"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3" id="perm_attd_type_tomor_add" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Tomorrow Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200i"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <?php
                                $perm_currentDate = new DateTime();
                                $perm_currentDate->modify('+1 days');
                                $perm_futureDate = $perm_currentDate->format('d-M-Y');
                                ?>
                                <input type="text" class="form-control" value="<?php echo $perm_futureDate; ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3" id="perm_attd_type_custom_add" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Custom Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="custom_date_add_pr" name="attendance_date_range_add" class="form-control common_date_class" readonly value="<?php echo date("d-M-Y"); ?>" />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3 text-center">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Attendance</label>
                            <div class="d-block">
                                <label class="badge text-white mb-1 fs-6 fw-semibold" style="background-color:#2A9FF6;">Permission</label>
                                <input type="hidden" class="form-control" name="entry_select" value="4"  />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                            <select id="department_add_pr" name="department_id" class="select3 form-select validation_message_pr" placeholder="Select Department Name">
                            </select>
                             <div id="department_add_pr_err" class="text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                            <select id="staff_add_pr" name="staff_id[]" class="select3 form-select validation_message_pr" multiple placeholder="Select Staff">
                                        
                            </select>
                             <div id="staff_add_pr_err" class="text-danger"></div>
                        </div>
                        
                        
                    </div>
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Start Time<span
                                    class="text-danger">*</span></label>
                            <input class="form-control form-control-solid srt_time_pr" id="perm_st_time_add" name="st_time" placeholder="Pick time" />
                             <div id="perm_st_time_add_err" class="text-danger "></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark fs-6 mb-1 fw-semibold">End Time<span
                                    class="text-danger">*</span></label>
                            <input class="form-control form-control-solid common_time_class" id="perm_ed_time_add" name="end_time" placeholder="Pick time" />
                             <div id="perm_ed_time_add_err" class="text-danger"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                            <textarea class="form-control" id="pr_reason" name="reason" rows="3" placeholder="Enter Reason"></textarea>
                             <div id="pr_reason_err" class="text-danger"></div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                            <button type="button" id="prBtn" class="btn btn-primary" onclick="mark_pr_att_func()">Mark Permission Attendance</button>
                        </div>
                    </div>
                </form>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
</div>
<!--end::Modal - Mark Permission Attendance-->

<!--begin::Modal - Mark On Duty Attendance   -->
<div class="modal fade" id="kt_modal_attendance_onduty" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Mark On Duty Attendance</h3>
                </div>
                <form id="attendanceFormonduty">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Attendance Type<span class="text-danger">*</span></label>
                            <select id="onduty_attendance_type_add" name="attendance_type_add" class="select3 form-select" onchange="onduty_attendance_type_func_add()">
                                <option value="today">Today</option>
                                <option value="tomorrow">Tomorrow</option>
                                <option value="custom">Custom</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3" id="onduty_attd_type_today_add" style="display: block;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Today Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200i"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3" id="onduty_attd_type_tomor_add" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Tomorrow Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200i"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <?php
                                $onduty_currentDate = new DateTime();
                                $onduty_currentDate->modify('+1 days');
                                $onduty_futureDate = $onduty_currentDate->format('d-M-Y');
                                ?>
                                <input type="text" class="form-control" value="<?php echo $onduty_futureDate; ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3" id="onduty_attd_type_custom_add" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Custom Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" class="form-control common_date_class" id="custom_date_add_on" name="attendance_date_range_add" readonly value="<?php echo date("d-M-Y"); ?>" />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3 text-center">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Attendance</label>
                            <div class="d-block">
                                <label class="badge bg-secondary text-white mb-1 fs-6 fw-semibold" >On Duty</label>
                                <input type="hidden" class="form-control" name="entry_select" value="3"  />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                            <select id="department_add_od" name="department_id" class="select3 form-select validation_message_od" placeholder="Select Department Name">
                            </select>
                            <div id="department_add_od_err" class="text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                            <select id="staff_add_od" name="staff_id[]" class="select3 form-select validation_message_od" multiple placeholder="Select Staff">
                                        
                            </select>
                            <div id="staff_add_od_err" class="text-danger"></div>
                        </div>
                        
                        
                    </div>
                    <div class="row">
                       
                        <div class="col-lg-4 mb-3" >
                            <label class="text-dark mb-1 fs-6 fw-semibold">Start Time<span
                                    class="text-danger">*</span></label>
                            <input class="form-control form-control-solid srt_time_pr" id="onduty_st_time_add" name="st_time" placeholder="Pick time" />
                            <div id="onduty_st_time_add_err" class="text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark fs-6 mb-1 fw-semibold">End Time<span
                                    class="text-danger">*</span></label>
                            <input class="form-control form-control-solid end_time_class" id="onduty_ed_time_add" name="end_time" placeholder="Pick time" />
                            <div id="onduty_ed_time_add_err" class="text-danger"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3" id="od_reason" name="reason" placeholder="Enter Reason"></textarea>
                            <div id="od_reason_err" class="text-danger"></div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                            <button type="button" id="odDutyBtn" class="btn btn-primary" onclick="mark_onDuty_att_func()">Mark On Duty Attendance</button>
                        </div>
                    </div>
                </form>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
</div>
<!--end::Modal - Mark On Duty Attendance-->

<!--begin::Modal - Add Staff Attendance-->
<div class="modal fade" id="kt_modal_add_staff_attendance" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Add Staff Attendance</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="staff_dob" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                        <select  class="select3 form-select" name="department_id" id="department_add_e">
                            <option value="">Select Department</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select" multiple>
                            <option value="">Select Staff</option>
                            <option value="1">Sabanaa Barveen</option>
                            <option value="2">Vidhuba</option>
                            <option value="3">Kavi Priya</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Entry<span class="text-danger">*</span></label>
                        <select id="mark_attendance" name="mark_attendance" class="select3 form-select" onchange="entry_func();">
                            <option value="">Select Entry</option>
                            <option value="present">Present</option>
                            <option value="absent">Absent (Leave Without Intimation)</option>
                            <option value="leave">Leave (Leave With Intimation)</option>
                            <option value="permission">Permission</option>
                            <option value="on_duty">On Duty</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-3" style="display:none;" id="start_time_view">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Time<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="HH:MM" id="per_start_time" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-3" style="display:none;" id="end_time_view">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Time<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="HH:MM" id="per_end_time" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="absent_view">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
                        <select id="type" name="type" class="select3 form-select" onchange="type_func();">
                            <option value="">Select Type</option>
                            <option value="today">Today</option>
                            <option value="another_days">Another Days</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="another_days_view">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Another Days<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="another_days_multi" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="leave_view">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="" placeholder="Enter Reason"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Add Attendance</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Staff Attendance-->

<!--begin::Modal - Edit Staff Attendance-->
<div class="modal fade" id="kt_modal_edit_staff_attendance" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Staff Attendance</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="staff_att_date_edit" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Branch</option>
                            <option value="1">Madurai - Anna Nagar</option>
                            <option value="2">Chennai - CIT Nagar</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Department</option>
                            <option value="1">Production</option>
                            <option value="2">Sales</option>
                            <option value="2">IS</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                        <select id="" class="select3 form-select">
                            <option value="">Select Staff</option>
                            <option value="1" selected>Sabanaa Barveen</option>
                            <option value="2">Vidhuba</option>
                            <option value="3">Kavi Priya</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Entry<span class="text-danger">*</span></label>
                        <select id="mark_attendance_edit" name="mark_attendance_edit" class="select3 form-select" onchange="entry_edit_func();">
                            <option value="">Select Entry</option>
                            <option value="present">Present</option>
                            <option value="absent">Absent (Leave Without Intimation)</option>
                            <option value="leave">Leave (Leave With Intimation)</option>
                            <option value="permission">Permission</option>
                            <option value="on_duty">On Duty</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-3" style="display:none;" id="start_time_view_edit">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Time<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="HH:MM" id="per_start_time_edit" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-3" style="display:none;" id="end_time_view_edit">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Time<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="HH:MM" id="per_end_time_edit" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="absent_view_edit">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
                        <select id="type_edit" name="type_edit" class="select3 form-select" onchange="type_func_edit();">
                            <option value="">Select Type</option>
                            <option value="today">Today</option>
                            <option value="another_days">Another Days</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="another_days_view_edit">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Another Days<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="another_days_multi" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3" style="display:none;" id="leave_view_edit">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="" placeholder="Enter Description"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Attendance</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal Staff Attendance--->

<!--begin::Modal - View Staff Attendance-->
<div class="modal fade" id="kt_modal_view_staff_attendance" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">View Staff Attendance <span class="fs-4 fw-semibold bg-danger text-white px-2 ms-2 py-1 rounded" id="notice_check" style="display: none">Notice Period</span></h3>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <!-- <div class="col-lg-12">
                                <div class="d-flex px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true" style="background-image: url(assets/images/staff_1.png)">
                                            <img src="{{asset('assets/phdizone_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-1" title="Staff Name" data-bs-toggle="tooltip" data-bs-placement="bottom">Vidhuba</span>
                                        </label>
                                        <div class="d-block">
                                            <label class="d-block badge bg-label-info text-info fw-bold fs-9" title="Department" data-bs-toggle="tooltip" data-bs-placement="bottom">Sales</label>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                            <input type="hidden" id="staff_id_view" name="staff_id_view">
                            <div class="col-lg-2">
                                <div class="row">
                                    <div class="align-items-sm-center gap-4">
                                        <img src="{{asset('assets/phdizone_images/user_2.png')}}" id="staff_view_img" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="justify-content-start">
                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">
                                                <i class="mdi mdi-account-box-outline fs-3 text-black"></i>
                                            </label>
                                            <label class="fs-6 align-items-center text-black fw-bold">
                                                <span id="staff_name_view">Priya Dharshini </span><span   ><i class="mdi mdi-information-slab-circle text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" id="staff_nickname_view" title="Nick Name" ></i></span> 
                                                <span class=" fs-8 " id="gender_view"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <!-- <div class="col-lg-12">
                                        <div class="justify-content-start">
                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Date">
                                                <i class="mdi mdi-calendar-range fs-3 text-black"></i>
                                            </label>
                                            <label class="fs-6 align-items-center text-black fw-semibold">
                                                02-Sep-2024
                                            </label>
                                        </div>
                                    </div> -->
                                    <div class="col-lg-12">
                                        <div class="justify-content-start">
                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Branch">
                                                <i class="mdi mdi-graph-outline fs-3 text-black"></i>
                                            </label>
                                            <label class="fs-6 align-items-center text-black fw-semibold"  id="branch_name_view">
                                                Madurai - Anna Nagar
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="justify-content-start">
                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Department">
                                                <i class="mdi mdi-account-question-outline fs-3 text-black"></i>
                                            </label>
                                            <label class="fs-6 align-items-center text-black fw-semibold" id="department_view">
                                                Production
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="col-lg-12">
                                    <div class="justify-content-start">
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Role">
                                            <i class="mdi mdi-shield-account-outline fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold">
                                            <span class="badge bg-info" id="job_role_view">Developer</span></label>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="justify-content-start">
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email">
                                            <i class="mdi mdi-email-edit-outline fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold" id="email_id_view">sabana@gmail.com</label>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="justify-content-start">
                                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile No">
                                            <i class="mdi mdi-phone-outline fs-3 text-black"></i>
                                        </label>
                                        <label class="fs-6 align-items-center text-black fw-semibold"  id="mob_no_view">9876543210</label>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <div class="d-flex align-items-center justify-center me-3">
                            <label class="badge bg-danger text-white rounded px-2 py-1"><span>A</span></label>
                            <span class="fs-6 fw-semibold ms-1">Absent</span>
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Leave Without Intimation"><i class="mdi mdi-information-slab-circle"></i></span>
                        </div>
                        <div class="d-flex align-items-center justify-center me-3">
                            <label class="badge bg-info text-white rounded px-2 py-1"><span>L</span></label>
                            <span class="fs-6 fw-semibold ms-1">Leave</span>
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Leave With Intimation"><i class="mdi mdi-information-slab-circle"></i></span>
                        </div>
                        <div class="d-flex align-items-center justify-center me-3">
                            <label class="badge bg-secondary text-white rounded px-2 py-1"><span>OD</span></label>
                            <span class="fs-6 fw-semibold ms-1">On Duty</span>

                            <div class="">
                                <a href="#" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown" data-trigger="hover" aria-expanded="false">
                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom"><i class="mdi mdi-information-slab-circle text-dark"></i></span>
                                </a>
                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-250px max-h-250px">
                                    <div class="d-flex align-items-center mb-2 ">
                                        <label><span class="badge bg-secondary rounded text-white px-2 py-1">30 M</span></label>
                                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                        <label class="fs-6 fw-semibold">30 Minutes</label>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <label><span class="badge bg-secondary rounded text-white px-2 py-1">1 H</span></label>
                                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                        <label class="fs-6 fw-semibold">1 Hour</label>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <label><span class="badge bg-secondary rounded text-white px-2 py-1">1.5 H</span></label>
                                        <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                        <label class="fs-6 fw-semibold">1.5 Hours</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-center me-3">
                            <label class="badge bg-primary text-white rounded px-2 py-1"><span>Pr</span></label>
                            <span class="fs-6 fw-semibold ms-1">Permission</span>
                            <a href="#" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown" data-trigger="hover" aria-expanded="false">
                                <span data-bs-toggle="tooltip" data-bs-placement="bottom"><i class="mdi mdi-information-slab-circle text-dark"></i></span>
                            </a>
                            <div class="dropdown-menu py-2 px-4 text-black scroll-y w-250px max-h-250px">
                                <div class="d-flex align-items-center mb-2 ">
                                    <label><span class="badge bg-primary rounded text-white px-2 py-1">30 M</span></label>
                                    <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                    <label class="fs-6 fw-semibold">30 Minutes</label>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <label><span class="badge bg-primary rounded text-white px-2 py-1">1 H</span></label>
                                    <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                    <label class="fs-6 fw-semibold">1 Hour</label>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <label><span class="badge bg-primary rounded text-white px-2 py-1">1.5 H</span></label>
                                    <label class="fs-6 fw-semibold me-2 ms-2">-</label>
                                    <label class="fs-6 fw-semibold">Half Day</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mt-4">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2  scroll_table">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-150px">Date</th>
                                    <th class="min-w-150px">Attendance</th>
                                    <th class="min-w-100px">Timing</th>
                                    <th class="min-w-150px">Reason</th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7"  id="staff_attendance_view">
                               
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal Staff Attendance--->

<!--begin::Modal - View Individual Staff Monthly Attendance-->
<div class="modal fade" id="kt_modal_view_individual_staff_attendance" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">View Monthly Attendance</h3>
                </div>
                <div class="nav-align-top mb-2">
                    @php
                    $currentMonth = date('n'); // Get the current month as a number (1-12)
                    $currentYear = date('Y');  // Get the current year
                @endphp
                
                <ul class="nav nav-pills" id="month-tabs" role="tablist">
                    @foreach(range(1, 12) as $month)
                        @php
                            $isFutureMonth = $month > $currentMonth; // Check if this month is in the future
                        @endphp
                        <li class="nav-item me-1">
                            <button type="button"
                                class="nav-link text-capitalize px-3 border border-dashed border-info {{ $month == $currentMonth ? 'active' : '' }}"
                                data-month="{{ $month }}" 
                                role="tab" 
                                data-bs-toggle="tab"
                                {{ $isFutureMonth ? 'disabled' : '' }} {{-- Disable future months --}}
                            >
                                <div class="text-center">
                                    <span class="fs-6 fw-semibold">{{ DateTime::createFromFormat('!m', $month)->format('M') }}</span>
                                    <div class="d-block">
                                        <span class="fw-semibold fs-8">( {{ $currentYear }} )</span>
                                    </div>
                                </div>
                            </button>
                        </li>
                    @endforeach
                </ul>
                
                </div>
               <!-- Tab Content for Monthly Attendance -->
               <div class="tab-content p-0">
                    <div class="tab-pane fade show active" id="attendance-data">
                        <!-- Attendance details will be loaded here dynamically via AJAX -->
                        <div class="row mt-4">
                            <div class="col-lg-3 mb-1">
                                <div class="d-flex align-items-center justify-content-start">
                                    <!-- Avatar -->
                                    <div class="avatar w-60px h-60px">
                                        <img src="{{asset('assets/eapl_images/default_image.png')}}" alt="Staff Image" id="staff-imageattendance" class="border border-dark rounded">
                                        <div id="staff-initialattendance"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                                    </div>
                                    <!-- Staff Name and Department -->
                                    <div class="ms-2">
                                        <label class="text-black fw-semibold fs-6 me-1 staff-name"></label> <!-- Update with staff_name -->
                                        <div class="d-block">
                                            <label class="badge bg-info text-white fs-8 me-1 department-name" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Department"></label> <!-- Update with department_name -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-9 d-flex align-items-center justify-content-center gap-5">
                                <div class="mb-0 text-center">
                                    <label class="fs-6 mb-1 fw-bold">Present</label>
                                    <div class="d-block">
                                        <label class="badge bg-success text-white fs-7 fw-bold badge-present">22</label>
                                    </div>
                                </div>
                                <div class="mb-0 text-center">
                                    <label class="fs-6 mb-1 fw-bold">Absent</label>
                                    <div class="d-block">
                                        <label class="badge bg-danger text-white fs-7 fw-bold badge-absent">01</label>
                                    </div>
                                </div>
                                <div class="mb-0 text-center">
                                    <label class="fs-6 mb-1 fw-bold">Leave</label>
                                    <div class="d-block">
                                        <label class="badge bg-warning text-black fs-7 fw-bold badge-leave">02</label>
                                    </div>
                                </div>
                                <div class="mb-0 text-center">
                                    <label class="fs-6 mb-1 fw-bold">Permission</label>
                                    <div class="d-block">
                                        <label class="badge bg-success text-white fs-7 fw-bold badge-permission" style="background-color: #2A9FF6 !important;">02 H</label>
                                    </div>
                                </div>
                                <div class="mb-0 text-center">
                                    <label class="fs-6 mb-1 fw-bold">On Duty</label>
                                    <div class="d-block">
                                        <label class="badge bg-success text-white fs-7 fw-bold badge-onduty" style="background-color: #F62AA9 !important;">02 H</label>
                                    </div>
                                </div>
                                <div class="mb-0 text-center">
                                    <label class="fs-6 mb-1 fw-bold text-black">Overall</label>
                                    <div class="d-block">
                                        <label class="badge bg-primary text-white fs-7 fw-bold badge-overall">96%</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-12">
                                <table class="table align-top gy-1 gs-2 list_page_empty" id="attendance-table">
                                    <!-- Table Headings (Days of the week) -->
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-80px text-center">Monday</th>
                                            <th class="min-w-80px text-center">Tuesday</th>
                                            <th class="min-w-80px text-center">Wednesday</th>
                                            <th class="min-w-80px text-center">Thursday</th>
                                            <th class="min-w-80px text-center">Friday</th>
                                            <th class="min-w-80px text-center">Saturday</th>
                                            <th class="min-w-80px text-center">Sunday</th>
                                        </tr>
                                    </thead>
                                    <tbody id="attendance-body">
                                        <!-- Attendance rows will be dynamically injected here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Individual Staff Monthly Attendance-->

<!--begin::Modal - View Individual Staff Monthly Attendance-->
<div class="modal fade" id="kt_modal_view_individual_day_attendance" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    {{-- date will be displayed here click --}}
                    <h3 class="text-center mb-4 text-black">View <span class="badge bg-label-info" id="attendance-date"></span> Attendance</h3>
                </div>
                <div class="row">
                    <div class="col-lg-12 d-flex align-items-center justify-content-start gap-3 mb-3">
                        <div class="mb-0 text-center border border-info border-dashed rounded px-2 py-1">
                            <label class="fs-6 mb-1 fw-bold">Present</label>
                            <div class="d-block">
                                <label id="present_percentage" class="badge bg-success text-white fs-7 fw-bold">0 %</label>
                            </div>
                        </div>
                        <div class="mb-0 text-center border border-info border-dashed rounded px-2 py-1">
                            <label class="fs-6 mb-1 fw-bold">Absent</label>
                            <div class="d-block">
                                <label id="absent_percentage" class="badge bg-danger text-white fs-7 fw-bold">0 %</label>
                            </div>
                        </div>
                        <div class="mb-0 text-center border border-info border-dashed rounded px-2 py-1">
                            <label class="fs-6 mb-1 fw-bold">Leave</label>
                            <div class="d-block">
                                <label id="leave_percentage" class="badge bg-warning text-black fs-7 fw-bold">0 %</label>
                            </div>
                        </div>
                        <div class="mb-0 text-center border border-info border-dashed rounded px-2 py-1">
                            <label class="fs-6 mb-1 fw-bold">Permission</label>
                            <div class="d-block">
                                <label id="permission_percentage" class="badge bg-info text-white fs-7 fw-bold">0 %</label>
                            </div>
                        </div>
                        <div class="mb-0 text-center border border-info border-dashed rounded px-2 py-1">
                            <label class="fs-6 mb-1 fw-bold">On Duty</label>
                            <div class="d-block">
                                <label id="onduty_percentage" class="badge bg-primary text-white fs-7 fw-bold">0 %</label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-12">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 indiv_date_scroll_table">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-100px">Staff's</th>
                                    <th class="min-w-80px">Mobile</th>
                                    <th class="min-w-100px">Dept / Sub Dept</th>
                                    <th class="min-w-100px">Job Position</th>
                                    <th class="min-w-50px">Status</th>
                                </tr>
                            </thead>
                            <tbody class="text-gray-600 fw-semibold fs-7" id="attendanceDetails">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Individual Staff Monthly Attendance-->


<!--begin::Modal - View Individual Staff Yearly Attendance-->
<div class="modal fade" id="kt_modal_view_individual_staff_attendance_year" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <!--begin::Svg Icon-->
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                        <!--end::Svg Icon-->
                    </span>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">View Yearly Attendance</h3>
                </div>
                <div class="nav-align-top mb-2">
                    @php $currentYear = date('Y'); @endphp
                    <!-- Yearly Filter Tabs -->
                    <ul class="nav nav-pills" id="year-tabs" role="tablist">
                        @foreach(range(2023, $currentYear) as $year)
                            <li class="nav-item me-1">
                                <button type="button" class="nav-link text-capitalize px-3 border border-dashed border-info {{ $year == $currentYear ? 'active' : '' }}"
                                    data-year="{{ $year }}" role="tab" data-bs-toggle="tab" onclick="fetchYearlyAttendance({{ $year }})">
                                    <div class="text-center">
                                        <span class="fs-6 fw-semibold">{{ $year }}</span>
                                    </div>
                                </button>
                            </li>
                        @endforeach
                    </ul>
                </div>
            
                <!-- Tab Content for Yearly Attendance -->
                <div class="tab-content p-0">
                    <div class="tab-pane fade show active" id="attendance-data">
                        <div class="row mt-4">
                            <div class="col-lg-12">
                                <div class="table-container">
                                    <table class="table sticky_table popup-table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 min-w-100%">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="sticky-lefts min-w-80px text-center">Staff's</th>
                                                @foreach(range(1, 12) as $month)
                                                    <th class="min-w-80px text-center month-header" data-month="{{ $month }}">
                                                        {{ date('M', mktime(0, 0, 0, $month, 10)) }} ({{ $currentYear }})
                                                    </th>
                                                @endforeach
                                                <th class="sticky-rights min-w-80px text-center">Overall%</th>
                                            </tr>
                                        </thead>
                                        <tbody id="attendance-body-year">
                                            
                                            <!-- Attendance rows will be injected here by JavaScript -->
                                        </tbody>
                                    </table>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
    </div>
</div>
<!--end::Modal-->


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
    .custom-od-class {
        background-color: #F62AA9; /* Your desired color for On Duty */
        color: white; /* Optional: Change text color if needed */
    }

    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
</style>
<style>
    .dataTables_scroll {
        position: relative;
        overflow: auto;
        min-height: 200px;
        max-height: 200px;
        /*the maximum height you want to achieve*/
        width: 100%;
    }

    .dataTables_scroll thead {

        position: -webkit-sticky;
        position: sticky;
        top: 0;
        background-color: #fff;
        z-index: 2;
    }
</style>

{{-- year attendance view --}}
<script>
    function fetchYearlyAttendance(year) {
        const attendanceBody = $('#attendance-body-year');
        updateTableHeaders(year);
        // Show loading row inside tbody
        attendanceBody.html(`
            <tr>
                <td colspan="100%" class="text-center">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    Loading...
                </td>
            </tr>
        `);

        $.ajax({
            url: '/attendance/yearly',
            method: 'GET',
            data: { year: year },
            success: function(data) {
                attendanceBody.empty(); // Clear previous data

                data.forEach(item => {
                    const staffName = item.staff.staff_name;
                    const departmentName = item.staff.department_name;
                    const avatarUrl = item.staff.staff_image;
                    const monthlyAttendance = item.monthlyAttendance;
                    let monthlyColumns = '';

                   for (let month = 1; month <= 12; month++) {
                        let formattedMonth = month.toString().padStart(2, '0'); // Convert 1 -> "01", 2 -> "02"
                        const attendancePercentage = monthlyAttendance[formattedMonth] || 0;
                        let progressColor = attendancePercentage < 20 ? 'red' :
                        attendancePercentage < 70 ? '#ffa500' : '#03ff75';

                          monthlyColumns += `
                              <td>
                                  <div class="progress rounded h-20px border border-gray-400i shadow-lg">
                                      <div class="progress-bar progress-bar-striped progress-bar-animated fs-7"
                                          role="progressbar"
                                          style="width: ${attendancePercentage}%; background-color: ${progressColor}; transition: width 0.5s ease;"
                                          aria-valuenow="${attendancePercentage}"
                                          aria-valuemin="0"
                                          aria-valuemax="100">
                                      </div>
                                      <div class="progress-label">${attendancePercentage}%</div>
                                  </div>
                              </td>`;
                      }


                    attendanceBody.append(`
                        <tr>
                            <td>
                                <div class="d-flex align-items-center justify-content-start">
                                    <div class="avatar rounded-circle bg-label-info d-flex justify-content-center align-items-center"
                                        style="width:40px; height:40px; font-weight:bold; font-size:18px;">
                                        ${
                                        avatarUrl
                                        ? `<img src="{{ asset('staff_images/') }}/${avatarUrl}" alt="user image"
                                            class="w-px-40 h-auto rounded-circle">`
                                        : staffName.charAt(0).toUpperCase()
                                        }
                                    </div>
                                    <div class="ms-2">
                                        <div>
                                            <span class="staff-name-container fs-7 me-1">${staffName}</span>
                                        </div>
                                        <span class="badge bg-info text-white fs-8 me-2">${departmentName}</span>
                                    </div>
                                </div>
                            </td>
                            ${monthlyColumns}
                            <td class=" fw-bold text-center"
                                style="background-color: ${item.attendancePercentage >= 75 ? '#d4edda' : item.attendancePercentage >= 50 ? '#fff3cd' : '#f8d7da'};
                                    color: ${item.attendancePercentage >= 75 ? '#155724' : item.attendancePercentage >= 50 ? '#856404' : '#721c24'};
                                    font-size: 1rem; padding: 10px; border-radius: 4px;">
                                ${item.attendancePercentage}%
                            </td>
                        </tr>
                    `);
                });
            },
            error: function() {
                // Handle error case
                attendanceBody.empty(); // Clear the loading row
                alert('Error fetching data');
            }
        });
    }
    
    
    
     function updateTableHeaders(year) {
        $(".month-header").each(function () {
            let month = $(this).data("month");
            let monthName = new Date(year, month - 1, 1).toLocaleString('default', { month: 'short' });
            $(this).text(`${monthName} (${year})`);
        });
    }
</script>

{{-- date attendance view --}}
<script>
    $(document).on('click', '.attendance-date', function() {
        let selectedDate = $(this).data('date');

        // AJAX request to fetch attendance data for the selected date
        $.ajax({
            url: "{{ route('ViewAttendanceDate') }}",
            method: "POST",
            data: {
                date: selectedDate,
                _token: "{{ csrf_token() }}" // CSRF token for security
            },
            beforeSend: function() {
                // Show loading text while the request is being processed
                $('#attendanceDetails').html('<p class="text-primary">Loading data...</p>');
            },
            success: function(response) {
                if (response.status === 200) {
                    let attendanceData = response.data;
                    let attendanceHtml = '';

                    // Initialize counters for different statuses
                    let total = attendanceData.length;
                    let presentCount = 0, absentCount = 0, leaveCount = 0, permissionCount = 0, ondutyCount = 0;

                    // Loop through the data to count each attendance status
                    $.each(attendanceData, function(index, staff) {
                        switch (staff.attendance) {
                            case 'P': presentCount++; break;
                            case 'A': absentCount++; break;
                            case 'L': leaveCount++; break;
                            case 'PR': permissionCount++; break;
                            case 'OD': ondutyCount++; break;
                        }

                        // Generate table rows for staff attendance details
                        attendanceHtml += `
                            <tr>
                                <!-- Staff Name with Avatar and Gender Icon -->
                                <td>
                                    <div class="d-flex align-items-center justify-content-start">
                                        <div class="avatar">
                                        <img src="${staff.staff_image ? '{{ asset('staff_images/') }}/' + staff.staff_image : '{{ asset('assets/eapl_images/user_1.png') }}'}" alt="user image" class="w-px-40 h-auto rounded-circle">
                                        </div>
                                        <div class="ms-2">
                                            <div data-bs-toggle="modal" data-bs-target="#kt_modal_view_individual_staff_attendance">
                                                <span class="fs-7 me-1">${staff.staff_name}</span>
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Gender">
                                                    ${staff.gender == '1' ? '<i class="mdi mdi-face-man text-danger"></i>' : '<i class="mdi mdi-face-woman text-info"></i>'}
                                                </span>
                                            </div>
                                            <div class="d-block text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Nick Name">${staff.nick_name}</div>
                                        </div>
                                    </div>
                                </td>  
                                <!-- Staff Mobile Number -->
                                <td>${staff.mobile_no}</td>
                                <!-- Department -->
                                <td>
                                    <label class="text-black fs-7">${staff.department_name}</label>
                                    <div class="d-block">
                                        <label class="badge bg-secondary text-white rounded fs-8">${staff.sub_department_name}</label>
                                    </div>
                                </td>
                                <!-- Job Role -->
                                <td>${staff.job_roll_name}</td>
                                <!-- Attendance Status -->
                                <td><span class="badge ${getStatusClassView(staff.attendance)}">${getAttendanceStatusFullName(staff.attendance)}</span></td>
                            </tr>`;
                    });

                    // Calculate percentages
                    let presentPercentage = ((presentCount / total) * 100).toFixed(2);
                    let absentPercentage = ((absentCount / total) * 100).toFixed(2);
                    let leavePercentage = ((leaveCount / total) * 100).toFixed(2);
                    let permissionPercentage = ((permissionCount / total) * 100).toFixed(2);
                    let ondutyPercentage = ((ondutyCount / total) * 100).toFixed(2);

                    // Update the HTML with the calculated percentages
                    $('#present_percentage').text(presentPercentage + ' %');
                    $('#absent_percentage').text(absentPercentage + ' %');
                    $('#leave_percentage').text(leavePercentage + ' %');
                    $('#permission_percentage').text(permissionPercentage + ' %');
                    $('#onduty_percentage').text(ondutyPercentage + ' %');

                    // Generate the attendance table
                    attendanceHtml += '</tbody></table>';
                    $('#attendanceDetails').html(attendanceHtml);
                } else {
                    $('#attendanceDetails').html('<p>No data found for the selected date.</p>');
                }
            },
            error: function() {
                $('#attendanceDetails').html('<p>An error occurred while fetching data.</p>');
            }
        });

        // Show the modal
        $('#kt_modal_view_individual_day_attendance').modal('show');
    });

    // Helper function to add CSS class based on attendance status
    function getStatusClassView(status) {
        switch (status) {
            case 'P': return 'bg-success';
            case 'A': return 'bg-danger';
            case 'L': return 'bg-warning';
            case 'PR': return 'bg-info';
            case 'OD': return 'bg-primary';
            default: return 'bg-secondary';
        }
    }
    // Helper function to get the full name of the attendance status
    function getAttendanceStatusFullName(status) {
        switch (status) {
            case 'P': return 'Present';
            case 'A': return 'Absent';
            case 'L': return 'Leave';
            case 'PR': return 'Permission';
            case 'OD': return 'On Duty';
            default: return 'Unknown';
        }
    }
</script>

{{-- person attendance view --}}
<script>
    
    $(document).ready(function() {
        let staffId = null; // Variable to store the selected staff ID

        // Event handler for staff member click
        $(document).on('click', '.staff-member', function() {
            staffId = $(this).data('staff-id'); // Get the staff ID from the clicked element
            $('#month-tabs .nav-link.active').trigger('click'); // Trigger the first month's tab to load attendance
        });
        // Event handler for month tab click
       $(document).on('click', '#month-tabs .nav-link', function() {
            if (!staffId) return; // Check if staff ID is available

            var month = $(this).data('month');
            var year = {{ date('Y') }}; // Current year

            // AJAX request to fetch attendance for the selected month
            $.ajax({
                url: '{{ route("fetchStaffMonthlyAttendance") }}',
                method: 'POST',
                data: {
                    month: month,
                    year: year,
                    staff_id: staffId,
                    _token: '{{ csrf_token() }}'
                },
                beforeSend: function() {
                    $('#attendance-body').html('<tr><td colspan="7">Loading...</td></tr>');
                },
                success: function(response) {
                    var attendanceBody = $('#attendance-body').empty(); // Clear the table
                    // Get the summary object from the response
                    var summary = response.summary;

                    // Dynamically update the attendance summary badges
                    $('.badge-present').text(summary.present || 0);
                    $('.badge-absent').text(summary.absent || 0);
                    $('.badge-leave').text(summary.leave || 0);
                    $('.badge-permission').text(summary.permission || '0 H');
                    $('.badge-onduty').text(summary.onduty || '0 H');
                    $('.badge-overall').text(summary.present_percentage + '%' || '0%');

                    var attendanceMap = response.attendanceData.reduce((map, item) => {
                        map[new Date(item.date).getDate()] = item.attendance;
                        return map;
                    }, {});

                    var totalDays = new Date(year, month, 0).getDate();
                    var startDate = new Date(year, month - 1, 1);
                    var dayOfWeek = (startDate.getDay() + 6) % 7; // Start from Monday

                    var row = '<tr>';

                    // Fill initial empty cells
                    for (var i = 0; i < dayOfWeek; i++) {
                        row += '<td></td>';
                    }

                    // Iterate through each day of the month
                    for (var day = 1; day <= totalDays; day++) {
                        var attendanceStatus = attendanceMap[day];
                        var statusClass = getStatusClass(attendanceStatus);
                        var statusText = getStatusText(attendanceStatus);

                        // Apply the special format only for 'Absent' and 'Leave'
                        if (attendanceStatus === 'A' || attendanceStatus === 'L') {
                            row += `
                                <td class="${statusClass}">
                                    <div class="d-flex justify-content-end align-items-start">
                                        <label class="text-black fw-bold fs-8">${day}</label>
                                    </div>
                                    <div class="d-flex justify-content-center mt-4 mb-8 align-items-center">
                                        <div class="fs-7 fw-bold mx-3 px-2 ${statusClass}">${statusText}</div>
                                    </div>
                                </td>
                            `;
                        } else {
                            // Old format for other statuses
                            row += `
                                <td>
                                    <div class="d-flex justify-content-end align-items-start">
                                        <label class="text-black fw-bold fs-8">${day}</label>
                                    </div>
                                    <div class="d-flex justify-content-center mt-4 mb-8 align-items-center">
                                        <div class="fs-7 fw-bold mx-3 px-2 ${statusClass}">${statusText}</div>
                                    </div>
                                </td>
                            `;
                        }

                        // Start a new row after Saturday (day 6)
                        if ((dayOfWeek + day) % 7 === 0) {
                            row += '</tr><tr>';
                        }
                    }

                    // Fill remaining empty cells to complete the row
                    var remainingCells = 7 - ((dayOfWeek + totalDays) % 7);
                    for (var j = 0; j < remainingCells && remainingCells < 7; j++) {
                        row += '<td></td>';
                    }

                    row += '</tr>';
                    attendanceBody.append(row);
                },
                error: function(xhr, status, error) {
                    $('#attendance-body').html('<tr><td colspan="7">Error fetching data. Please try again.</td></tr>');
                    console.error('Error:', error);
                }
            });
        });


        // Event handler for showing individual staff attendance
        $('#month-tabs .nav-link').on('click', function() {
            if (!staffId) return; // Ensure staff ID is set
            showStaffAttendance(staffId);
        });
    });

    // Function to show individual staff attendance
    function showStaffAttendance(staffId) {
        $('#modal-body-content').html('<p>Loading attendance data...</p>');

        $.ajax({
            url: '{{ route("fetchIndividualStaffAttendance") }}',
            method: 'POST',
            data: {
                staff_id: staffId,
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                if (response) {

                    let staffImage = response.staff_image;
                    let staffName = response.staff_name || 'No Name Provided';

                    if (staffImage) {
                        $('#staff-imageattendance').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#staff-initialattendance').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#staff-initialattendance').text(initial).removeClass('d-none');
                        $('#staff-imageattendance').addClass('d-none');
                    }

                    $('.staff-name').text(staffName);
                    
                    // Displaying department name
                    $('.department-name').text(response.department_name || 'No Department');

                    // Display other fields
                    $('#mobile_no').text(response.mobile_no || 'No Mobile Number');
                    $('#email_id').text(response.email_id || 'No Email ID');
                } else {
                    console.error('No data found in response.');
                }
            },
            error: function() {
                console.error('Failed to retrieve data.');
            }
        });
    }

    // Helper functions
    function getStatusClass(attendance) {
        if (!attendance) return 'bg-secondary text-white';
        const classes = {
            'P': 'bg-success text-white',  // Present
            'A': 'bg-danger text-white',    // Absent
            'L': 'bg-warning text-black',    // Leave
            'OD': 'custom-od-class',         // On Duty with custom class
            'W': 'bg-secondary text-white'   // Weekend
        };
        return classes[attendance] || 'bg-secondary text-white';
    }


    function getStatusText(attendance) {
        if (!attendance) return '-';
        const texts = {
            'P': 'Present',
            'A': 'Absent',
            'L': 'Leave',
            'OD': 'On Duty',
            'W': 'Weekend'
        };
        return texts[attendance] || '-';
    }
</script>


<script>
    $(".list_page").DataTable({
        "ordering": false,
         "pageLength": 50, 
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
    $(".scroll_table").DataTable({
        // "ordering": false,
        "aaSorting":[],
        // "pagingType": 'simple_numbers',
        "pagingType": "full_numbers",
        // "sorting":false,
        "paging": false,
        // "buttons": [
        //             'copy', 'csv', 'excel', 'pdf', 'print'
        //         ],
         "language": {
          "lengthMenu": "Show _MENU_",
         },
          // "pageLength": 5,
         "dom":
          "<'row'" +
          // "<'col-sm-6 d-flex align-items-center justify-conten-start my-3'l>" +
          "<'col-sm-12 d-flex align-items-center justify-content-end my-3'f>" +
          ">" +

          "<'table-responsive'tr>" +

          "<'row'" +
        //   "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
          // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
          ">"
        });
    $('.scroll_table').wrap('<div class="dataTables_scroll" />');
</script>
<script>
    $(".view_list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +

            "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>"


    });
</script>

<style>
    .table-container {
        overflow-x: auto;
        overflow-y: auto;
        max-height: 600px;
        position: relative;
    }

    .sticky_table {
        border-collapse: separate;
        border-spacing: 0;  /* Prevents collapse of borders */
        width: 100%;        /* Full width */
    }

    .sticky_table thead th,
    .sticky_table tbody td {
        position: relative; /* Default positioning */
        z-index: 1;        /* Default z-index */
        padding: 8px;      /* Padding for table cells */
        background: #fff;  /* Default background for cells */
        color: #000;       /* Default text color */
    }

    /* Sticky header */
    .sticky_table thead th {
        position: sticky;  /* Sticky positioning for the header */
        /* top: 0;           */
        background: #099dda; /* Background color for header */
        color: #fff;      /* Text color for header */
        z-index: 3;       /* Higher z-index for the header */
    }

    /* Sticky first column */
    .sticky_table thead th:first-child,
    .sticky_table tbody td:first-child {
        position: sticky;  /* Sticky positioning for first column */
        left: 0;           /* Sticks to the left */
        z-index: 4;       /* Higher z-index for first column */
    }

    /* Sticky last column */
    .sticky_table thead th:last-child,
    .sticky_table tbody td:last-child {
        position: sticky;  /* Sticky positioning for last column */
        right: 0;          /* Sticks to the right */
        z-index: 4;   
         background: #099dda;    /* Higher z-index for last column */
    }

    /* Make the last sticky cell display correctly */
    .sticky_table tbody td:last-child {
        background: #fff; /* Ensure the last cell's background matches the normal cell */
    }

    /* Adjust padding and border for empty table rows */
    .list_page_empty tbody td {
        padding: 5px !important; /* Ensures consistent padding */
        border: 1px solid #cdcdcd; /* Border styling */
    }

    


</style>
<style>
    .table_2-container {
        max-height: 100px;
        /* Adjust the height as needed */
        overflow-y: scroll;
    }

    .table_2 thead th {
        position: sticky;
        top: 0;
    }
</style>

<script>
    function month_filter(val) {
        var url = "{{ url('') }}";
        window.location = '/hr_management/staff_attendance/?month_filter=' + val;
        
    }

</script>
<script>
        $(document).ready(function () {

     // Fetch departments
        $.ajax({
            url: "{{ route('department') }}",
            type: "GET",
            success: function (response) {
                var selectDropdown = $('#department_add');
                selectDropdown.empty().append('<option value="">Select Department</option>');
                if (response.status === 200 && response.data) {
                 
                    response.data.forEach(function (val) {
                        selectDropdown.append($('<option></option>').attr('value', val.sno).text(val.department_name));
                    });
                }
            },
            error: function (error) {
                console.error('Error fetching departments:', error);
            }
        });
    });
</script>

<script>
    function entry_func() {
        var mark_attendance = document.getElementById("mark_attendance").value;
        var leave = document.getElementById("leave");
        var present = document.getElementById("present");
        var permission = document.getElementById("permission");
        var on_duty = document.getElementById("on_duty");
        var absent = document.getElementById("absent");
        var another_days = document.getElementById("another_days");
        if (mark_attendance == "leave") {
            leave_view.style.display = "block";
            start_time_view.style.display = "none";
            end_time_view.style.display = "none";
            another_days_view.style.display = "none";
            absent_view.style.display = "none";
        } else if (mark_attendance == "permission") {
            start_time_view.style.display = "block";
            end_time_view.style.display = "block";
            leave_view.style.display = "block";
            absent_view.style.display = "none";
            another_days_view.style.display = "none";
        } else if (mark_attendance == "on_duty") {
            start_time_view.style.display = "block";
            end_time_view.style.display = "block";
            leave_view.style.display = "block";
            absent_view.style.display = "none";
            another_days_view.style.display = "none";
        } else if (mark_attendance == "absent") {
            start_time_view.style.display = "none";
            end_time_view.style.display = "none";
            leave_view.style.display = "none";
            absent_view.style.display = "block";
            another_days_view.style.display = "none";
        }
    }
</script>

<script>
    function type_func() {
        var type = document.getElementById("type").value;
        var today = document.getElementById("today");
        var another_days = document.getElementById("another_days");
        if (type == "today") {
            another_days_view.style.display = "none";
            leave_view.style.display = "block";
        } else if (type == "another_days") {
            another_days_view.style.display = "block";
            leave_view.style.display = "block";
        }
    }
</script>

<script>
    function entry_edit_func() {
        var mark_attendance_edit = document.getElementById("mark_attendance_edit").value;
        var leave = document.getElementById("leave");
        var present = document.getElementById("present");
        var permission = document.getElementById("permission");
        var on_duty = document.getElementById("on_duty");
        var absent = document.getElementById("absent");
        var another_days = document.getElementById("another_days");
        if (mark_attendance_edit == "leave") {
            leave_view_edit.style.display = "block";
            start_time_view_edit.style.display = "none";
            end_time_view_edit.style.display = "none";
            another_days_view_edit.style.display = "none";
            absent_view_edit.style.display = "none";
        } else if (mark_attendance_edit == "permission") {
            start_time_view_edit.style.display = "block";
            end_time_view_edit.style.display = "block";
            leave_view_edit.style.display = "block";
            absent_view_edit.style.display = "none";
            another_days_view_edit.style.display = "none";
        } else if (mark_attendance_edit == "on_duty") {
            start_time_view_edit.style.display = "block";
            end_time_view_edit.style.display = "block";
            leave_view_edit.style.display = "block";
            another_days_view_edit.style.display = "none";
            absent_view_edit.style.display = "none";
        } else if (mark_attendance_edit == "absent") {
            start_time_view_edit.style.display = "none";
            end_time_view_edit.style.display = "none";
            leave_view_edit.style.display = "none";
            absent_view_edit.style.display = "block";
            another_days_view_edit_edit.style.display = "none";
        }
    }
</script>
<script>
    function type_func_edit() {
        var type_edit = document.getElementById("type_edit").value;
        var today = document.getElementById("today");
        var another_days = document.getElementById("another_days");
        if (type_edit == "today") {
            another_days_view_edit.style.display = "none";
            leave_view_edit.style.display = "block";
        } else if (type_edit == "another_days") {
            another_days_view_edit.style.display = "block";
            leave_view_edit.style.display = "block";
        }
    }
</script>

<script>
   
    $(document).ready(function () {
        // Function to clear error message
        function clearErrorMessage() {
            $('#error-message').text('').hide(); // Adjust '#error-message' to your actual span ID or class
        }

        // Function to display error message
        function displayErrorMessage(message) {
            $('#error-message').text(message).show(); // Adjust '#error-message' to your actual span ID or class
        }

   

        // Fetch departments
        $.ajax({
            url: "{{ route('department') }}",
            type: "GET",
            success: function (response) {
                clearErrorMessage(); // Clear any previous error messages
                if (response.status === 200 && response.data) {
                    var selectDropdown = $('select[name="department_id"]');
                    selectDropdown.empty().append('<option value="">Select Department</option>');
                    response.data.forEach(function (k) {
                        selectDropdown.append($('<option></option>').attr('value', k.sno).text(k.department_name));
                    });
                } else {
                    displayErrorMessage('Failed to fetch departments. Please try again.');
                }
            },
            error: function (error) {
                console.error('Error fetching departments:', error);
                displayErrorMessage('Error fetching departments. Please check your connection and try again.');
            }
        });

        // Fetch staff based on branch and department
        function fetchStaff() {
            var branchId = $('#branch_add').val();
            var departmentId = $('#department_add').val();
            var date = $('#attend_date').val();

            $.ajax({
                url: "{{ route('staff_att') }}",
                type: "GET",
                data: {
                    department_id: departmentId,
                    date: date,
                },
                success: function (response) {
                    clearErrorMessage(); // Clear any previous error messages
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('#staff_add');
                        selectDropdown.empty().append('<option value="all">All</option>');
                        response.data.forEach(function (k) {
                            selectDropdown.append($('<option></option>').attr('value', k.sno).text(k.nick_name + ' - ' + k.staff_name));
                        });
                        // Destroy previous Select2 instance if it exists
                        // selectDropdown.select3('destroy');

                        // // Initialize Select2 with the formatted options
                        // selectDropdown.select3({
                        //     templateResult: formatStaffOption,
                        //     templateSelection: formatStaffOption,
                        //     dropdownParent: $('#kt_modal_attendance_present') // Set the dropdown parent to the modal
                        // });

                    } else {
                        displayErrorMessage('Failed to fetch staff. Please try again.');
                    }
                },
                error: function (error) {
                    console.error('Error fetching staff:', error);
                    displayErrorMessage('Error fetching staff. Please check your connection and try again.');
                }
            });
        }

        $('#branch_add').change(fetchStaff);
        $('#department_add').change(fetchStaff);

        // Format staff option for display
        function formatStaffOption(staff) {
            if (!staff.id) {
                return staff.text; // Return the text if no id (for the placeholder)
            }

            // Split the text to get the nick name and staff name
            var staffDetails = staff.text.split(' - ');
            var $option = $('<span class="badge bg-danger">' + staffDetails[1] + '</span> <span style="font-size: small;">' + staffDetails[0] + '</span>');
            
            return $option; // Return the formatted option
        }
       

        // Ensure this is only run when the modal is opened
        $('#kt_modal_attendance_present').on('shown.bs.modal', function () {
            fetchStaff(); // Fetch staff when modal is shown
        });
    });


    //absent function
    $(document).ready(function () {

        // Fetch departments
        $.ajax({
            url: "{{ route('department') }}",
            type: "GET",
            success: function (response) {
                if (response.status === 200 && response.data) {
                    var selectDropdown = $('#department_add_absent');
                    selectDropdown.empty().append('<option value="">Select Department</option>');
                    response.data.forEach(function (k) {
                        selectDropdown.append($('<option></option>').attr('value', k.sno).text(k.department_name));
                    });
                }
            },
            error: function (error) {
                console.error('Error fetching departments:', error);
            }
        });

        // Fetch staff based on branch and department
        function fetchStaffabsent() {
            var departmentId = $('#department_add_absent').val();
            var date = $('#attend_date_absent').val();

            $.ajax({
                url: "{{ route('staff_att') }}",
                type: "GET",
                data: {
                    department_id: departmentId,
                    date: date,
                },
                success: function (response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('#staff_add_absent');
                        selectDropdown.empty().append('<option value="">Select Staff</option>');
                        response.data.forEach(function (k) {
                            selectDropdown.append($('<option></option>').attr('value', k.sno).text(k.nick_name+' - '+ k.staff_name));
                        });
                    }
                },
                error: function (error) {
                    console.error('Error fetching staff:', error);
                }
            });
        }

        // Trigger staff filtering when branch or department changes
        $('#department_add_absent').change(fetchStaffabsent);
    });

    //leave function
    $(document).ready(function () {

        $('.srt_time_pr').flatpickr({
                enableTime: true,
                format: 'H:i:K',
                noCalendar: true
        });

         $('.end_time_class').flatpickr({
                enableTime: true,
                format: 'H:i:K',
                noCalendar: true
        });

         
     // Fetch departments
        $.ajax({
            url: "{{ route('department') }}",
            type: "GET",
            success: function (response) {
                if (response.status === 200 && response.data) {
                    var selectDropdown = $('#department_add_leave');
                    selectDropdown.empty().append('<option value="">Select Department</option>');
                    response.data.forEach(function (k) {
                        selectDropdown.append($('<option></option>').attr('value', k.sno).text(k.department_name));
                    });
                }
            },
            error: function (error) {
                console.error('Error fetching departments:', error);
            }
        });

        // Fetch staff based on branch and department
        function fetchStaffLeave() {
            var departmentId = $('#department_add_leave').val();
            var type = $('#attendance_type_add').val();
            var custom_date = $('#custom_date_add').val();

            $.ajax({
                url: "{{ route('staff_att') }}",
                type: "GET",
                data: {
                    department_id: departmentId,
                    type: type,
                    date: custom_date,
                },
                success: function (response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('#staff_add_leave');
                        selectDropdown.empty().append('<option value="">Select Staff</option>');
                        response.data.forEach(function (k) {
                            selectDropdown.append($('<option></option>').attr('value', k.sno).text(k.nick_name+' - '+ k.staff_name));
                        });
                    }
                },
                error: function (error) {
                    console.error('Error fetching staff:', error);
                }
            });
        }

        $('#department_add_leave').change(fetchStaffLeave);

        
        // Fetch staff based on branch and department
        function fetchStaffPermission() {
            var departmentId = $('#department_add_pr').val();
              var type = $('#perm_attendance_type_add').val();
            var custom_date = $('#custom_date_add_pr').val();

            $.ajax({
                url: "{{ route('staff_att') }}",
                type: "GET",
                data: {
                    department_id: departmentId,
                    type: type,
                    date: custom_date,
                },
                success: function (response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('#staff_add_pr');
                        selectDropdown.empty().append('<option value="">Select Staff</option>');
                        response.data.forEach(function (k) {
                            selectDropdown.append($('<option></option>').attr('value', k.sno).text(k.nick_name+' - '+ k.staff_name));
                        });
                    }
                },
                error: function (error) {
                    console.error('Error fetching staff:', error);
                }
            });
        }

        $('#department_add_pr').change(fetchStaffPermission);

         function fetchStaffOnduty() {
            var departmentId = $('#department_add_od').val();
              var type = $('#onduty_attendance_type_add').val();
            var custom_date = $('#custom_date_add_on').val();

            $.ajax({
                url: "{{ route('staff_att') }}",
                type: "GET",
                data: {
                    department_id: departmentId,
                     type: type,
                    date: custom_date,
                },
                success: function (response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('#staff_add_od');
                        selectDropdown.empty().append('<option value="">Select Staff</option>');
                        response.data.forEach(function (k) {
                            selectDropdown.append($('<option></option>').attr('value', k.sno).text(k.nick_name+' - '+ k.staff_name));
                        });
                    }
                },
                error: function (error) {
                    console.error('Error fetching staff:', error);
                }
            });
        }

        $('#department_add_od').change(fetchStaffOnduty);


    });

</script>



<script>
    // Clear previous validation error messages for Absent form
    function clearValidationAbsentErrors() {
        $('.validation_message_absent').text(''); // Clear all previous error messages
    }

    function validateFormabsent() {
        var errors = {};

        $('.validation_feild').each(function() {
            var fieldName = $(this).attr('name');
            var fieldValue = $(this).val();

            // Apply .trim() only for input or textarea fields
            if ($(this).is('input') || $(this).is('textarea')) {
                fieldValue = fieldValue.trim();
            }

            // Validate staff_id dropdown separately (multi-select case)
            if (fieldName === 'staff_id[]') {
                var selectedValues = $('#staff_add').val();
                if (!selectedValues || selectedValues.length === 0) {
                    errors[fieldName] = 'Please select at least one staff.';
                }

                // Handle 'All' selection
                if (selectedValues && selectedValues.includes('all')) {
                    $(this).val(['all']); // Select only 'All'
                } else {
                    $(this).find('option[value="all"]').prop('selected', false); // Deselect 'All'
                }
                console.log('trigger 2')
                // Trigger change event for select2 to refresh UI
                $(this).trigger('change.select3');
            }

            // Check if the field is empty and visible
            if (!fieldValue && $(this).is(':visible') && fieldName !== 'staff_id[]') {
                errors[fieldName] = 'This field is required.';
            }
        });

        return errors; // Return the errors object
    }

    // Display validation errors for Absent form
    function displayValidationAbsentErrors(errors) {
        $.each(errors, function(fieldName, errorMessage) {
            $('[name="' + fieldName + '"]').closest('.mb-3').find('.validation_message_absent').text(errorMessage);
        });
    }

    // Clear previous validation error messages for Present form
    function clearValidationErrors() {
        $('.validation_message').text(''); // Clear all previous error messages
    }

    // Validate Present form
    function validateForm() {
        var errors = {};

        $('.validation_feild').each(function() {
            var fieldName = $(this).attr('name');
            var fieldValue = $(this).val();

            // Apply .trim() only for input or textarea fields
            if ($(this).is('input') || $(this).is('textarea')) {
                fieldValue = fieldValue.trim();
            }

            // Validate staff_id dropdown separately (multi-select case)
            if (fieldName === 'staff_id[]') {
                var selectedValues = $('#staff_add').val();
                if (!selectedValues || selectedValues.length === 0) {
                    errors[fieldName] = 'Please select at least one staff.';
                }

                // Handle 'All' selection
                if (selectedValues && selectedValues.includes('all')) {
                    $(this).val(['all']); // Select only 'All'
                } else {
                    $(this).find('option[value="all"]').prop('selected', false); // Deselect 'All'
                }
                console.log('triiggger 1')
                // Trigger change event for select2 to refresh UI
                $(this).trigger('change.select3');
            }

            // Check if the field is empty and visible
            if (!fieldValue && $(this).is(':visible') && fieldName !== 'staff_id[]') {
                errors[fieldName] = 'This field is required.';
            }
        });

        return errors; // Return the errors object
    }

    // Display validation errors for Present form
    function displayValidationErrors(errors) {
        $.each(errors, function(fieldName, errorMessage) {
            $('[name="' + fieldName + '"]').closest('.mb-3').find('.validation_message').text(errorMessage);
        });
    }

    // Handling the 'All' selection in the staff dropdown
    function staff_change() {
        var selectedValues = $('#staff_add').val();
        console.log("jdvhhg")
        if (selectedValues && selectedValues.includes('all')) {
            $('#staff_add').val(['all']);
        } else if (!selectedValues || !selectedValues.includes('all')) {
            $('#staff_add').find('option[value="all"]').prop('selected', false);
        }
        
    }
</script>

<script>
    function mark_present_att_func() { 
        $("#markPresentBtn").prop('disabled', true); // Disable the button
    
        let err = false; // Initialize error flag

        var department_add = $('#department_add').val();
        if(department_add == ''){
            $('#department_add_err').text('Department is Required..!');
            err=true;
        }else{
              $('#department_add_err').text('');
        }

         var staff_add = $('#staff_add').val();
            if(staff_add == ''){
                $('#staff_add_err').text('Staff is Required..!');
                err=true;
            }else{
                $('#staff_add_err').text('');
            }
    
        // If there's an error, enable the button again and exit the function
        if (err) {
            $("#markPresentBtn").prop('disabled', false);
            return false;
        }
    
        // Get the form data
        var formData = $('#attendanceForm').serialize(); // Serialize form data
    
        // AJAX setup with CSRF token
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    
        // Perform AJAX request
        $.ajax({
            url: "{{ route('staff_attendance') }}", // Replace with your route
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.status === 200) {
                    toastr.success(response.message); // Show success message
                    location.reload(); // Reload page after success
                } else {
                    toastr.error('An error occurred while submitting the form.'); // Error message
                    $("#markPresentBtn").prop('disabled', false); // Enable button if there's an error
                }
            },
            error: function(xhr) {
                toastr.error('An error occurred while submitting the form.'); // Handle AJAX error
                console.error('Error:', xhr); // Log error for debugging
                $("#markPresentBtn").prop('disabled', false); // Enable button in case of an error
            }
        });
    }

      
    function mark_absent_att_func() { 
        $("#absentBtn").prop('disabled', true); // Disable the button
    
        let err = false; // Initialize error flag

        var department_add_absent = $('#department_add_absent').val();
        if(department_add_absent == ''){
            $('#department_add_absent_err').text('Department is Required..!');
            err=true;
        }else{
            $('#department_add_absent_err').text('');
        }

        var staff_add_absent = $('#staff_add_absent').val();
            if(staff_add_absent == ''){
                $('#staff_add_absent_err').text('Staff is Required..!');
                err=true;
            }else{
                $('#staff_add_absent_err').text('');
            }
    
        // If there's an error, enable the button again and exit the function
        if (err) {
            $("#absentBtn").prop('disabled', false);
            return false;
        }
    
        // Get the form data
        var formData = $('#attendanceFormabsent').serialize(); // Serialize form data
    
        // AJAX setup with CSRF token
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    
        // Perform AJAX request
        $.ajax({
            url: "{{ route('staff_attendance') }}", // Replace with your route
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.status === 200) {
                    toastr.success(response.message); // Show success message
                    location.reload(); // Reload page after success
                } else {
                    toastr.error('An error occurred while submitting the form.'); // Error message
                    $("#absentBtn").prop('disabled', false); // Enable button if there's an error
                }
            },
            error: function(xhr) {
                toastr.error('An error occurred while submitting the form.'); // Handle AJAX error
                console.error('Error:', xhr); // Log error for debugging
                $("#absentBtn").prop('disabled', false); // Enable button in case of an error
            }
        });
    }

    function mark_leave_att_func() { 
        $("#leaveBtn").prop('disabled', true); // Disable the button
    
        let err = false; // Initialize error flag

        var department_add_leave = $('#department_add_leave').val();
        if(department_add_leave == ''){
            $('#department_add_leave_err').text('Department is Required..!');
            err=true;
        }else{
            $('#department_add_leave_err').text('');
        }

        var staff_add_leave = $('#staff_add_leave').val();
            if(staff_add_leave == ''){
                $('#staff_add_leave_err').text('Staff is Required..!');
                err=true;
            }else{
                $('#staff_add_leave_err').text('');
            }

            var reason_leave = $('#reason_leave').val();
            if(reason_leave == ''){
                $('#reason_leave_err').text('Reason is Required..!');
                err=true;
            }else{
                $('#reason_leave_err').text('');
            }
    
        // If there's an error, enable the button again and exit the function
        if (err) {
            $("#leaveBtn").prop('disabled', false);
            return false;
        }
    
        // Get the form data
        var formData = $('#attendanceFormleave').serialize(); // Serialize form data

        // Define variables for staff ID and leave date based on the attendance type
        var staffId = $('#staff_add_leave').val(); // Get selected staff_id
        var attendanceType = $('#attendance_type_add').val();
        var leaveDate;

        // Determine leave date based on attendance type
        if (attendanceType === 'today') {
            leaveDate = "{{ date('Y-m-d') }}"; // Today's date
        } else if (attendanceType === 'tomorrow') {
            leaveDate = "{{ now()->addDay()->format('Y-m-d') }}"; // Tomorrow's date
        } else if (attendanceType === 'custom') {
            leaveDate = $('#custom_date_add').val(); // Custom date from input
        }

    
        // AJAX setup with CSRF token
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    
        // Perform AJAX request
        $.ajax({
            url: "{{ route('staff_attendance') }}", // Replace with your route
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.status === 200) {
                    toastr.success(response.message); // Show success message
                    location.reload(); // Reload page after success
                } else {
                    toastr.error('An error occurred while submitting the form.'); // Error message
                    $("#leaveBtn").prop('disabled', false); // Enable button if there's an error
                }
            },
            error: function(xhr) {
                toastr.error('An error occurred while submitting the form.'); // Handle AJAX error
                console.error('Error:', xhr); // Log error for debugging
                $("#leaveBtn").prop('disabled', false); // Enable button in case of an error
            }
        });
    }

     function mark_pr_att_func() { 
        $("#prBtn").prop('disabled', true); // Disable the button
    
        let err = false; // Initialize error flag

        var department_add_pr = $('#department_add_pr').val();
        if(department_add_pr == ''){
            $('#department_add_pr_err').text('Department is Required..!');
            err=true;
        }else{
            $('#department_add_pr_err').text('');
        }

        var staff_add_pr = $('#staff_add_pr').val();
            if(staff_add_pr == ''){
                $('#staff_add_pr_err').text('Staff is Required..!');
                err=true;
            }else{
                $('#staff_add_pr_err').text('');
            }

             var perm_st_time_add = $('#perm_st_time_add').val();
            if(perm_st_time_add == ''){
                $('#perm_st_time_add_err').text('Start Time is Required..!');
                err=true;
            }else{
                $('#perm_st_time_add_err').text('');
            }

             var perm_ed_time_add = $('#perm_ed_time_add').val();
            if(perm_ed_time_add == ''){
                $('#perm_ed_time_add_err').text('End Time is Required..!');
                err=true;
            }else{
                $('#perm_ed_time_add_err').text('');
            }

            var pr_reason = $('#pr_reason').val();
            if(pr_reason == ''){
                $('#pr_reason_err').text('Reason is Required..!');
                err=true;
            }else{
                $('#pr_reason_err').text('');
            }
    
        // If there's an error, enable the button again and exit the function
        if (err) {
            $("#prBtn").prop('disabled', false);
            return false;
        }
    
        // Get the form data
        var formData = $('#attendanceFormpermission').serialize(); // Serialize form data

        // Define variables for staff ID and leave date based on the attendance type
          var staffId = $('#staff_add_pr').val(); // Get selected staff_id
        var attendanceType = $('#perm_attendance_type_add').val();
        var startTime = $('#perm_st_time_add').val(); // Get selected staff_id
        var endtime = $('#perm_ed_time_add').val(); // Get selected staff_id
        var prDate;

        // Determine leave date based on attendance type
        if (attendanceType === 'today') {
            prDate = "{{ date('Y-m-d') }}"; // Today's date
        } else if (attendanceType === 'tomorrow') {
            prDate = "{{ now()->addDay()->format('Y-m-d') }}"; // Tomorrow's date
        } else if (attendanceType === 'custom') {
            prDate = $('#custom_date_add_pr').val(); // Custom date from input
        }

    
        // AJAX setup with CSRF token
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    
        // Perform AJAX request
        $.ajax({
            url: "{{ route('staff_attendance') }}", // Replace with your route
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.status === 200) {
                    toastr.success(response.message); // Show success message
                    location.reload(); // Reload page after success
                } else {
                    toastr.error('An error occurred while submitting the form.'); // Error message
                    $("#prBtn").prop('disabled', false); // Enable button if there's an error
                }
            },
            error: function(xhr) {
                toastr.error('An error occurred while submitting the form.'); // Handle AJAX error
                console.error('Error:', xhr); // Log error for debugging
                $("#prBtn").prop('disabled', false); // Enable button in case of an error
            }
        });
    }

     function mark_onDuty_att_func() { 
        $("#odDutyBtn").prop('disabled', true); // Disable the button
    
        let err = false; // Initialize error flag

        var department_add_od = $('#department_add_od').val();
        if(department_add_od == ''){
            $('#department_add_od_err').text('Department is Required..!');
            err=true;
        }else{
            $('#department_add_od_err').text('');
        }

        var staff_add_od = $('#staff_add_od').val();
            if(staff_add_od == ''){
                $('#staff_add_od_err').text('Staff is Required..!');
                err=true;
            }else{
                $('#staff_add_od_err').text('');
            }

             var onduty_st_time_add = $('#onduty_st_time_add').val();
            if(onduty_st_time_add == ''){
                $('#onduty_st_time_add_err').text('Start Time is Required..!');
                err=true;
            }else{
                $('#onduty_st_time_add_err').text('');
            }

             var onduty_ed_time_add = $('#onduty_ed_time_add').val();
            if(onduty_ed_time_add == ''){
                $('#onduty_ed_time_add_err').text('End Time is Required..!');
                err=true;
            }else{
                $('#onduty_ed_time_add_err').text('');
            }

            var od_reason = $('#od_reason').val();
            if(od_reason == ''){
                $('#od_reason_err').text('Reason is Required..!');
                err=true;
            }else{
                $('#od_reason_err').text('');
            }
    
        // If there's an error, enable the button again and exit the function
        if (err) {
            $("#odDutyBtn").prop('disabled', false);
            return false;
        }
    
        // Get the form data
        var formData = $('#attendanceFormonduty').serialize(); // Serialize form data

         var staffId = $('#staff_add_od').val(); // Get selected staff_id
        var attendanceType = $('#onduty_attendance_type_add').val();
        var startTime = $('#onduty_st_time_add').val(); // Get selected staff_id
        var endtime = $('#onduty_ed_time_add').val(); // Get selected staff_id
        var odDate;

        // Determine leave date based on attendance type
        if (attendanceType === 'today') {
            odDate = "{{ date('Y-m-d') }}"; // Today's date
        } else if (attendanceType === 'tomorrow') {
            odDate = "{{ now()->addDay()->format('Y-m-d') }}"; // Tomorrow's date
        } else if (attendanceType === 'custom') {
            odDate = $('#custom_date_add_on').val(); // Custom date from input
        }

    
        // AJAX setup with CSRF token
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    
        // Perform AJAX request
        $.ajax({
            url: "{{ route('staff_attendance') }}", // Replace with your route
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.status === 200) {
                    toastr.success(response.message); // Show success message
                    location.reload(); // Reload page after success
                } else {
                    toastr.error('An error occurred while submitting the form.'); // Error message
                    $("#odDutyBtn").prop('disabled', false); // Enable button if there's an error
                }
            },
            error: function(xhr) {
                toastr.error('An error occurred while submitting the form.'); // Handle AJAX error
                console.error('Error:', xhr); // Log error for debugging
                $("#odDutyBtn").prop('disabled', false); // Enable button in case of an error
            }
        });
    }


</script>

<script>
    function attendance_type_func_add() {
        var attendance_type_add = document.getElementById("attendance_type_add").value;

        if (attendance_type_add == "today") {
            document.getElementById("attd_type_today_add").style.display = "block";
            document.getElementById("attd_type_tomor_add").style.display = "none";
            document.getElementById("attd_type_custom_add").style.display = "none";
        } else if (attendance_type_add == "tomorrow") {
            document.getElementById("attd_type_today_add").style.display = "none";
            document.getElementById("attd_type_tomor_add").style.display = "block";
            document.getElementById("attd_type_custom_add").style.display = "none";
        } else {
            document.getElementById("attd_type_today_add").style.display = "none";
            document.getElementById("attd_type_tomor_add").style.display = "none";
            document.getElementById("attd_type_custom_add").style.display = "block";
        }
    }
</script>
<!-- Add - Attendance Type - Permission Start -->
<script>
    function perm_attendance_type_func_add() {
        var perm_attendance_type_add = document.getElementById("perm_attendance_type_add").value;

        if (perm_attendance_type_add == "today") {
            document.getElementById("perm_attd_type_today_add").style.display = "block";
            document.getElementById("perm_attd_type_tomor_add").style.display = "none";
            document.getElementById("perm_attd_type_custom_add").style.display = "none";

        } else if (perm_attendance_type_add == "tomorrow") {
            document.getElementById("perm_attd_type_today_add").style.display = "none";
            document.getElementById("perm_attd_type_tomor_add").style.display = "block";
            document.getElementById("perm_attd_type_custom_add").style.display = "none";
        } else {
            document.getElementById("perm_attd_type_today_add").style.display = "none";
            document.getElementById("perm_attd_type_tomor_add").style.display = "none";
            document.getElementById("perm_attd_type_custom_add").style.display = "block";
        }
    }
</script>
<!-- Add - Attendance Type - Permission End -->
<!-- Add - Attendance Type - On Duty Start -->
<script>
    function onduty_attendance_type_func_add() {
        var onduty_attendance_type_add = document.getElementById("onduty_attendance_type_add").value;

        if (onduty_attendance_type_add == "today") {
            document.getElementById("onduty_attd_type_today_add").style.display = "block";
            document.getElementById("onduty_attd_type_tomor_add").style.display = "none";
            document.getElementById("onduty_attd_type_custom_add").style.display = "none";

        } else if (onduty_attendance_type_add == "tomorrow") {
            document.getElementById("onduty_attd_type_today_add").style.display = "none";
            document.getElementById("onduty_attd_type_tomor_add").style.display = "block";
            document.getElementById("onduty_attd_type_custom_add").style.display = "none";
        } else {
            document.getElementById("onduty_attd_type_today_add").style.display = "none";
            document.getElementById("onduty_attd_type_tomor_add").style.display = "none";
            document.getElementById("onduty_attd_type_custom_add").style.display = "block";
        }
    }
</script>
<!-- Add - Attendance Type - On Duty End -->

<script>
     // View
    function ViewFetch(id, staffName, gender, department, branch, nickname, emailid, mobileno,jobRole, noticeCheck) {

console.log(jobRole)
        // Set the hidden input value with the staff ID
        document.getElementById('staff_id_view').value = id;
        // Update the staff name in the modal
        $('#staff_name_view').text(staffName || '-');
      $('#staff_nickname_view')
            .attr('data-bs-original-title', nickname || '-') // For Bootstrap 5
            .tooltip('dispose')                       // Remove old tooltip instance
            .tooltip();

        // Update the gender icon based on the gender value
        var genderIcon = document.querySelector('#gender_view');
        if (gender == '1') { // Assuming '1' is male
            genderIcon.innerHTML = '<i class="mdi mdi-face-man text-info"></i>';
        } else if (gender == '2') { // Assuming '2' is female
            genderIcon.innerHTML = '<i class="mdi mdi-face-woman text-danger"></i>';
        } else {
            genderIcon.innerHTML = '<i class="mdi mdi-face text-primary"></i>';
        }
        
        if(noticeCheck == 1) {
            $('#notice_check').show();
        } else {
            $('#notice_check').hide();
        }

        // Update the department and branch in the modal
        document.getElementById('department_view').innerText = department;
        document.getElementById('branch_name_view').innerText = branch;
        document.getElementById('mob_no_view').innerText = mobileno;
        document.getElementById('email_id_view').innerText = emailid;
        document.getElementById('job_role_view').innerText = jobRole;

        fetch(`/attendance_view/${id}`)
            .then(response =>response.json())
            .then(data => {
                    if (data.status === 200) {
                        const att = data.data;
                        console.log(att);


        // Function to format date to '10-Jun-2024'
        function formatDate(dateString) {
            const date = new Date(dateString);
            const day = date.getDate().toString().padStart(2, '0');
            const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            const month = monthNames[date.getMonth()];
            const year = date.getFullYear();
            return `${day}-${month}-${year}`;
        }
        function formatTime(timeString) {
            const date = new Date(`1970-01-01T${timeString}Z`);
            let hours = date.getUTCHours();
            const minutes = date.getUTCMinutes().toString().padStart(2, '0');
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // the hour '0' should be '12'
            return `${hours}:${minutes} ${ampm}`;
        }

        const historicalTableBody = document.getElementById('staff_attendance_view');
        historicalTableBody.innerHTML = '';

        if (att.length > 0) {
            for (let index = 0; index < att.length; index++) {

                // console.log(att[index]);
                const category = att[index];

                const row = `
                                <tr>
                                    <td>
                                        <label>${formatDate(category.date)}</label>
                                    </td>
                                    <td>
                                        ${category.attendance === 'OD'
                                            ? `<label class="badge bg-secondary rounded text-white px-2 py-1 mb-1" style="">OD ${category.time_difference}</label>`
                                            : category.attendance === 'PR'
                                            ? `<label class="badge rounded text-white px-2 py-1 mb-1" style="background-color: #2A9FF6">PR ${category.time_difference}</label>`
                                            : category.attendance === 'WO'
                                            ? `<label class="badge rounded text-white px-2 py-1 mb-1" style="background-color: #2A9FF6">WO ${category.time_difference}</label>`
                                            : category.attendance === 'L'
                                            ? `<label class="badge bg-warning rounded text-black fw-bold px-2 py-1"><span>L</span></label>`
                                            : category.attendance === 'A'
                                            ? `<label class="badge bg-danger rounded px-2 py-1"><span>A</span></label>`
                                             : category.attendance === 'P'
                                            ? `<label class="badge bg-success text-black rounded px-2 py-1"><span>P</span></label>`
                                            : `<label class="badge bg-secondary rounded px-2 py-1"><span>Unknown</span></label>` // Handling unexpected values
                                        }
                                    </td>
                                    <td>
                                            <label>
                                        ${category.attendance === 'L' || category.attendance === 'A'  ? '-' :
                                            `${category.date ? formatDate(category.date) : '-'}
                                            ${category.time_start ? formatTime(category.time_start) : '-'}
                                            ${category.date ? `to ${formatDate(category.date)}` : '-'}
                                            ${category.time_end ? formatTime(category.time_end) : '-'}`}
                                        </label>
                                    </td>
                                    <td>
                                        <label>${category.reason || '-'}</label>
                                    </td>
                                </tr>
                            `;

                historicalTableBody.innerHTML += row;
            }
        } else {
            const row = `<tr>
                            <td colspan="6" class="text-center">No data available</td>
                            </tr>`;
            historicalTableBody.innerHTML += row;
        }
        }});
    }
</script>

@endsection