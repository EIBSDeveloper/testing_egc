@extends('layouts/layoutMaster')

@section('title', 'Staff')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Staff</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{ url('/dashboard/crm') }}" class="d-flex align-items-center"><i
                            class="mdi mdi-home text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">HR Management</a>
                </li>
            </ol>
        </nav>
    </div>
    @php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    @endphp
    <div class="card-body">
        <div class="nav-align-top mb-0">
            <ul class="nav nav-pills flex-wrap gap-2" role="tablist">
                <li class="nav-item" role="presentation">
                    <a href="{{ url('/hr_management/staff') }}" class="nav-link text-capitalize" role="tab">
                        Staffs
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a href="{{ url('/hr_management/staff/Exit_staff_list') }}" class="nav-link text-capitalize active" role="tab">
                        Exit Staff
                    </a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content p-0">
                <div class="tab-pane fade show active" id="tab_sunday" role="tabpanel">
                    <div class="row mt-4">
                        <div class="row mb-4">
                            @php $perpage_count = $perpage ? $perpage : 10; @endphp
                            <div class="col-lg-2">
                                <span>Show</span>
                                <br>
                                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                    onchange="sort_filter(this.value);">
                                    @php
                                    $options = [10, 25, 100, 500]; // Define available options
                                    @endphp
                                    @php foreach ($options as $option): @endphp
                                    <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                                        @php echo $option; @endphp
                                    </option>
                                    @php endforeach; @endphp
                                </select>
                            </div>
                            <div class="col-lg-10 d-flex align-items-end justify-content-end">
                                <form id="search_form" method="POST" action="/hr_management/staff/Exit_staff_list">
                                    @csrf
                                    <div class="d-flex align-items-center gap-2 mt-2">
                                        <div>
                                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                            <input type="hidden" name="filter_on" value="0">
                                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                                                value="@php echo $perpage ? $perpage : 10; @endphp" />
                                            <input type="text" class="form-control" id="search_fill" name="search_fill"
                                                value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                            onclick="search_filter_func()">Search</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Staff</th>
                                        <th class="min-w-100px">Exit Status</th>
                                        <th class="min-w-200px">Reason</th>
                                        <th class="min-w-80px">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                    @if (isset($staff))
                                        @foreach ($staff as $list)
                                            <tr>
                                                <td>
                                                    <div class="d-flex  px-1">
                                                        <div class="d-flex  px-1">
                                                            @if ($list->staff_image != '' && file_exists(public_path('staff_images/' .$list->staff_image)))
                                                                <div class="symbol symbol-35px me-2">
                                                                    <div class="image-input image-input-circle" data-kt-image-input="true" >
                                                                        <img src="{{ asset('staff_images/' . $list->staff_image) }}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                                                    </div>
                                                                </div>
                                                            @else
                                                                <div class="symbol symbol-35px me-2">
                                                                    @php
                                                                    $initial = strtoupper(substr($list->staff_name, 0, 1)); // Only keeps and
                                                                    // capitalizes the first
                                                                    echo $helper->name_image($initial, $list->gender);
                                                                    @endphp
                                                                </div>
                                                            @endif
                                                        <div class="mb-0">
                                                            <label>
                                                                <span class="fs-7 me-1">{{ $list->staff_name }}</span>
                                                            </label>
                                                            <!-- <div class="d-block text-primary fs-8">Sabana</div> -->
                                                            <div class="d-flex text-primary fs-8">
                                                                <a href="javascript:;" class="text-primary fs-8"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Staff Nick Name">
                                                                    {{ $list->nick_name }}</a>
                                                                <div class="">
                                                                    <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                                                        data-bs-toggle="dropdown" data-trigger="hover">
                                                                        <i class="ms-1 mdi mdi-information fs-9"></i>
                                                                    </a>
                                                                    <div
                                                                        class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                                        <div class="row mt-4 mb-2">
                                                                            <label
                                                                                class="col-3 text-black fs-8 fw-semibold">Name</label>
                                                                            <label
                                                                                class="col-1 text-black fs-8 fw-semibold">:</label>
                                                                            <label class="col-8 text-black fw-bold fs-8">{{
                                                                                $list->staff_name }}</label>
                                                                        </div>
                                                                        <div class="row mb-2">
                                                                            <label
                                                                                class="col-3 text-black fs-8 fw-semibold">Nick
                                                                                Name</label>
                                                                            <label
                                                                                class="col-1 text-black fs-8 fw-semibold">:</label>
                                                                            <label class="col-8 text-black fs-8 fw-bold">{{
                                                                                $list->nick_name }}</label>
                                                                        </div>
                                                                        <div class="row mb-2">
                                                                            <label class="col-3 text-black fs-8 fw-semibold">Mob
                                                                                No</label>
                                                                            <label
                                                                                class="col-1 text-black fs-8 fw-semibold">:</label>
                                                                            <label class="col-8 text-black fs-8 fw-bold">{{
                                                                                $list->mobile_no }}
                                                                            </label>
                                                                        </div>
                                                                        <div class="row mb-2">
                                                                            <label
                                                                                class="col-3 text-black fs-8 fw-semibold">Email
                                                                                ID</label>
                                                                            <label
                                                                                class="col-1 text-black fs-8 fw-semibold">:</label>
                                                                            <label class="col-8 text-black fs-8 fw-bold">{{
                                                                                $list->email_id
                                                                                }}
                                                                            </label>
                                                                        </div>
                                                                        <div class="row mb-2">
                                                                            <label
                                                                                class="col-3 text-black fs-8 fw-semibold">Work</label>
                                                                            <label
                                                                                class="col-1 text-black fs-8 fw-semibold">:</label>
                                                                            <label class="col-8 text-black fs-8 fw-bold">
                                                                                @if ($list->exp_type == 1)
                                                                                    Fresher
                                                                                @else
                                                                                    Experience
                                                                                @endif
                                                                            </label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    @if ($list->status == 4)
                                                    <label class="badge bg-success text-black fw-bold rounded">Notice Period
                                                    </label>
                                                    <div class="d-block mt-1">
                                                        <label class="fw-semibold fs-8 text-dark" data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom" title="Notice Start Date">{{
                                                            date($common_date_format, strtotime($list->notice_start_date))
                                                            }}</label> |
                                                        <label class="fw-semibold fs-8 text-dark" data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom" title="Notice End Date">{{
                                                            date($common_date_format, strtotime($list->notice_end_date))
                                                            }}</label>
                                                    </div>
                                                    @elseif ($list->status == 5)
                                                    <label class="badge bg-danger text-white fw-bold rounded">Relieve</label>
                                                    @elseif ($list->status == 6)
                                                    <label class="badge bg-info text-white fw-bold rounded">Abscond</label>
                                                    <div class="d-block mt-1">
                                                        <label class="fw-semibold fs-8 text-dark" data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom" title="Last Attend Date">{{ date($common_date_format, strtotime($list->staff_last_date)) }}</label>
                                                    </div>
                                                    @elseif ($list->status == 7)
                                                    <label class="badge bg-warning text-black fw-bold rounded">Terminate</label>
                                                    @elseif ($list->status == 8)
                                                    <label class="badge bg-info text-black fw-bold rounded">Internal Transfer</label>
                                                    @else
                                                    -
                                                    @endif

                                                </td>
                                                <td>
                                                    <label class="text-black fw-bold text-truncate w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="{{ $list->dep_reason ?? '-' }}">{{ $list->dep_reason??'-'
                                                        }}</label>
                                                </td>
                                                <td>
                                                    @php

                                                    $encryptedValue = $helper->encrypt_decrypt($list->sno, 'encrypt');
                                                    $url = url('/hr_management/staff/staff_view/' . $encryptedValue);

                                                    $edit_url = url('/hr_management/staff/staff_edit/' . $encryptedValue);
                                                    @endphp
                                                    <span class="text-end">

                                                        <a href="javascript:;" class="btn btn-icon btn-sm" id=""
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            @if(auth()->user()->hasPermission('HR Management', 'View', 'Manage Staff'))
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_view_staff"
                                                                onclick="staff_view_func('{{$list->sno}}')">
                                                                <span> <i
                                                                        class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                                            @endif
                                                            @if ($list->status == 4)
                                                            <!--<a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"-->
                                                            <!--    data-bs-target="#kt_modal_exit_staff"-->
                                                            <!--    onclick="departure_data_fetch_func({{ $list }})">-->
                                                            <!--    <span><i-->
                                                            <!--            class="mdi mdi-exit-to-app fs-3 text-black me-1"></i></span>-->
                                                            <!--    <span>Extend</span>-->
                                                            <!--</a>-->
                                                            @endif
                                                        </div>
                                                    </span>
                                                </td>
                                            </tr>
                                        @endforeach
                                    @endif
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-4">
                            {{ $staff->appends(request()->except(['page', '_token']))->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--begin::Modal exit staff--->
    <div class="modal fade" id="kt_modal_exit_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                    fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <form id="cus_drp_form" action="{{ route('Departure_staff') }}" method="POST"
                    enctype="multipart/form-data" autocomplete="off" onsubmit="return status_change_validation()">
                    @csrf
                    <div class="modal-body pt-0 pb-6 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-4 text-center">
                            <h3 class="text-center mb-4 text-black">Extend Exit Status</h3>
                        </div>
                        <div id="staff_data_view"></div>
                        <input type="hidden" id="sts_change_id" name="sts_change_id" />
                        <div class="row mt-2">
                            <div class="col-lg-3">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="depature_status"
                                        id="notice_period" value="4" onchange="departure_func(4);" checked />
                                    <label class="form-check-label" for="notice_period">Notice Period</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mt-2" style="display:none;" id="date_view">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Last Attend Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="staff_last_date" name="staff_last_date" placeholder="Select Date"
                                    class="form-control common_date_class" readonly value="<?php echo date(" d-M-Y");
                                    ?>" />
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 mt-2" style="display:none;" id="starting_date">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Starting Date<span
                                        class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="notice_start_date" name="notice_start_date"
                                        placeholder="Select Date" class="form-control common_date_class" readonly />
                                </div>
                                <div id="notice_start_date_err" class="text-danger"></div>
                            </div>
                            <div class="col-lg-6 mt-2" style="display:none;" id="ending_date">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Ending Date<span
                                        class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="notice_end_date" name="notice_end_date"
                                        placeholder="Select Date" class="form-control common_date_class" readonly />
                                </div>
                                <div id="notice_end_date_err" class="text-danger"></div>
                            </div>
                        </div>
                        <div class="col-lg-12 mt-2" style="display:none;" id="reason_add">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="1" id="dep_reason" name="dep_reason"
                                placeholder="Enter Reason"></textarea>
                            <div id="dep_reason_err" class="text-danger"></div>
                        </div>
                    </div>
                    <!--end::Modal body-->
                    <div class="d-flex justify-content-center align-items-center mb-4">
                        <button type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button>
                        <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - exit staff-->

    <!--begin::Modal Staff View--->
    <div class="modal fade" id="kt_modal_view_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                    fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">View Staff Details <span class="bg-danger px-2 py-1 text-white fw-semibold ms-2" id="exit_staff_status_title">Notice Period</span></h3>
                    </div>
                    <div id="staff_viewContainer"></div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Staff View-->



    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>



    <script>
        // Check if 'filter_on' session variable is set and trigger click event
    $(document).ready(function() {
        @if ($filter_on ?? '')
            $('.staff_filter').slideToggle('fast');
            // });
        @endif
    });

    // Toggle branch filter section
    $('#staff_filter').click(function() {
        $('.staff_filter').slideToggle('slow');
    });
    </script>
    <script>
        function formatDate(dateString) {
    const date = new Date(dateString);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
        return '-'; // Return '-' if the date is invalid
    }

    // Get the day, month (abbreviated), and year
    const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
    const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
    const year = date.getFullYear(); // Get full year

    // Construct and return the formatted date string
    return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
  }
  function departure_data_fetch_func(data){
    let image = '';
    if (data.staff_image) {
      var imgUrl = "{{ asset('staff_images/') }}/" + data.staff_image;
      image = `<img src="${imgUrl}" alt="user-avatar" class="image-input-wrapper w-60px h-60px" id="uploadedlogo" />`;
    } else if (data.cus_gender == 1 || data.cus_gender === '1') {
      image = `<img src="{{ asset('assets/eapl_images/user_1.png') }}" alt="user-avatar" class="image-input-wrapper w-60px h-60px" id="uploadedlogo" />`;
    } else if (data.cus_gender == 2 || data.cus_gender === '2') {
      image = `<img src="{{ asset('assets/eapl_images/user_2.png') }}" alt="user-avatar" class="image-input-wrapper w-60px h-60px" id="uploadedlogo" />`;
    }
    var html = `<div class="row mt-4">
                <input type="hidden" id="sts_change_sno" name="sts_change_sno" value="${data.sno}"/>

                  <div class="col-lg-3 mb-2">
                      <div class="row">
                          <div class="align-items-sm-center gap-4">
                              ${image}
                          </div>
                      </div>
                  </div>
                  <div class="col-lg-9 mb-2">
                      <div class="row mb-1">
                          <label class="col-4 text-dark fs-7 fw-semibold">Staff Name</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${data.staff_name}</label>
                      </div>
                      <div class="row mb-1">
                          <label class="col-4 text-dark fs-7 fw-semibold">Nick Name</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${data.nick_name}</label>
                      </div>
                      <div class="row mb-1">
                          <label class="col-4 text-dark fs-7 fw-semibold">Date of Joining</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${formatDate(data.date_of_joining)}</label>
                      </div>
                      <div class="row mb-1">
                          <label class="col-4 text-dark fs-7 fw-semibold">Department</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">
                              <span class="badge bg-info">${data.department_name}</span></label>
                      </div>
                  </div>
              </div>`;
    document.getElementById('staff_data_view').innerHTML = html;

    $('#dep_reason').val(data.dep_reason);
    $('#notice_start_date').val(formatDate(data.notice_start_date));
    $('#notice_end_date').val(formatDate(data.notice_end_date));


  }
  departure_func(4)
  function departure_func(val) {
    // Fetch elements required for all conditions
    $('#sts_change_id').val(val);
    $('#dep_reason_err').html('');
    $('#notice_end_date_err').html('');
    var reason_add = document.getElementById("reason_add");
    var date_view = document.getElementById("date_view");
    var starting_date = document.getElementById("starting_date");
    var ending_date = document.getElementById("ending_date");
    // Hide all elements initially
    reason_add.style.display = "none";
    date_view.style.display = "none";
    starting_date.style.display = "none";
    ending_date.style.display = "none";
    // Handle specific conditions based on `val`
    switch (val) {
        case 4: // Show both dates and reason
            starting_date.style.display = "block";
            ending_date.style.display = "block";
            reason_add.style.display = "block";
            $('#departure_submit_butt').html('Notice Period');
            break;
    }
  }
  function status_change_validation(){
    var err = 0;
    var sts_change_id = $('#sts_change_id').val();
    if(sts_change_id==4){
      var notice_start_date = $('#notice_start_date').val().trim();
      if(notice_start_date==''){
        $('#notice_start_date_err').html('Notice Start date is requered..!');
        err++;
      }else{
        $('#notice_start_date_err').html('');
      }
      var notice_end_date = $('#notice_end_date').val().trim();
      if(notice_end_date==''){
        $('#notice_end_date_err').html('Notice end date is requered..!');
        err++;
      }else{
        $('#notice_end_date_err').html('');
      }
    }

    var dep_reason = $('#dep_reason').val().trim();
    if(dep_reason==''){
      $('#dep_reason_err').html('Enter Reason is requered..!');
      err++;
    }else{
      $('#dep_reason_err').html('');
    }
    return err===0;
  }
    </script>
    <script>
        function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#acc_daily_acc_week_st_dt_fill').val(firstday);
            $('#acc_daily_acc_week_ed_dt_fill').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
    </script>
    <script>
        function add_staff_branch(id, type) {
        $.ajax({
            url: "/staff/Add_staff_branch"
            , headers: {
                'Content-Type': 'application/json'
                , 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
            , type: "POST"
            , data: JSON.stringify({
                id: id
                , type: type
            })
            , success: function(response) {
                // Handle success response here if needed
                console.log(response);
                if (response.id != "") {
                    window.location.href = '/hr_management/staff/staff_add';
                }
            }
            , error: function(xhr, status, error) {
                // Handle error
                console.error(xhr.responseText);
            }
        });
    }

    </script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +
    
                "<'table-responsive'tr>" +
    
                "<'row'" +
                //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>

    <script>

        function getExperienceCount(startDate, endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        
        let years = end.getFullYear() - start.getFullYear();
        let months = end.getMonth() - start.getMonth();
        
        if (months < 0) { years -=1; months +=12; } let expCount='' ; if (years> 0) {
            expCount += `${years} Year${years > 1 ? 's' : ''}`;
            }
            if (months > 0) {
            if (expCount) expCount += ' ';
            expCount += `${months} Month${months > 1 ? 's' : ''}`;
            }
        
            return expCount || '0 Month';
        }

        function staff_view_func(staff_id) {
    
            $.ajax({
                url: '/exit_staff_view/' + staff_id, // URL to your route
                type: 'GET',
                success: function(response) {
                    if(response.success) {
                        let studentTableBody = $('#staff_viewContainer');
                        studentTableBody.empty();
                        if(response.data){
                            let staff= response.data;
                            let img_src = `{{ asset('assets/phdizone_images/user_1.png') }}`;
        
                            if (response.data.staff_image) {
                                img_src = `{{ asset('staff_images/') }}/${response.data.staff_image}`;
                            } else if (response.data.gender == 1) {
                                img_src = `{{ asset('assets/phdizone_images/user_1.png') }}`;
                            } else if (response.data.gender == 2) {
                                img_src = `{{ asset('assets/phdizone_images/user_2.png') }}`;
                            }

                            var exitStatus = staff.status;
                            var exitReason;

                            $exitTitle = $('#exit_staff_status_title');
                            $exitTitle.removeClass('bg-danger bg-success bg-info bg-warning text-white text-black');

                            if (exitStatus === 0 || exitStatus === 1 || exitStatus === 2) {
                                $exitTitle.html('');
                                exitReason = '';
                            } else if (exitStatus === 4) {
                                $exitTitle.html('Notice Period').addClass('bg-success text-black');
                                exitReason = 'Notice Period';
                            } else if (exitStatus === 5) {
                                $exitTitle.html('Relive').addClass('bg-danger text-white');
                                exitReason = 'Relive';
                            } else if (exitStatus === 6) {
                                $exitTitle.html('Abscond').addClass('bg-info text-white');
                                exitReason = 'Abscond';
                            } else if (exitStatus === 7) {
                                $exitTitle.html('Terminate').addClass('bg-warning text-black');
                                exitReason = 'Terminate';
                            } else {
                                $exitTitle.html('');
                                exitReason = '';
                            }

                            let studentRow = `
                               <h5 class="title fw-bold mb-3">Basic Information</h5>
                                <div class="row mt-4">
                                    <div class="col-lg-6">
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Staff Photo</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">
                                                <div class="row">
                                                    <div class="align-items-sm-center gap-4">
                                                        <img src="${img_src}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo" />
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Staff</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.staff_name}</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Branch</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.branch_name}</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Department</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.department_name}</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Division</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.division_name}</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Gender</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.gender== '1 ' ? 'Male' :(staff.gender== '2' ?'Female':'Others')}</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Date of Birth</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.dob ? formatDate(staff.dob) :'-'}</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Mobile Number</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.mobile_no}</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Alternate Number</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.alternative_no || '-'}</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <div class="col-7">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${staff.email_id || '-'}">${staff.email_id || '-'}</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Marital Status</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.martial_status || '-'}</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Contact Person</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.contact_person_name}</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Contact Person No</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.contact_person_no}</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                            <label class="col-7 text-black fs-6 fw-bold">${staff.address || '-'}</label>
                                        </div>
                                        ${exitStatus != 0 || exitStatus != 1 || exitStatus == 2 ? 
                                            `<div class="row mb-4">
                                                <label class="col-4 text-dark fs-6 fw-semibold">${exitReason} Reason</label>
                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                <label class="col-7 text-black fs-6 fw-bold">${staff.dep_reason || '-'}</label>
                                            </div>` : ''
                                        }
                                        ${exitStatus == 4 ? 
                                            `<div class="row mb-4">
                                                <label class="col-4 text-dark fs-6 fw-semibold">Notice Date</label>
                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                <label class="col-7 text-black fs-6 fw-bold"><span class="badge bg-success px-2 py-1">${formatDate(staff.notice_start_date)}</span> | <span class="badge bg-danger px-2 py-1">${formatDate(staff.notice_end_date)}</span></label>
                                            </div>` : ''
                                        }
                                    </div>
                                </div>
                                <h5 class="title mt-4 fw-bold mb-3">
                                    <span>Work Information</span>
                                    <span class="ms-1 me-1">-</span>
                                    ${staff.exp_type == 1 ?
                                        `<span class="badge bg-warning text-black fs-6 fw-semibold">Fresher</span>` :
                                        `<span class="badge bg-info text-white fs-6 fw-semibold">Experience</span>`}
                                </h5>`;
                           
                                    if(staff.exp_type == 2  && response.workInfo.length > 0){
                                        response.workInfo.forEach(function(work) {
                                       const expCount = getExperienceCount(work.work_start_date, work.work_end_date);
                                        studentRow += `<div class="row mt-4">
                                                        <div class="col-lg-6">
                                                            <div class="row mb-4">
                                                                <label class="col-4 text-dark fs-6 fw-semibold">Position</label>
                                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                                <label class="col-7 text-black fs-6 fw-bold">${work.position || '-'}</label>
                                                            </div>
                                                            <div class="row mb-4">
                                                                <label class="col-4 text-dark fs-6 fw-semibold">Company</label>
                                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                                <label class="col-7 text-black fs-6 fw-bold">${work.company_name || '-'}</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="row mb-4">
                                                                <label class="col-4 text-dark fs-6 fw-semibold">Experience</label>
                                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                                <label class="col-7 text-black fs-6 fw-bold">${expCount || '0 Month'}</label>
                                                            </div>
                                                            <div class="row mb-4">
                                                                <label class="col-4 text-dark fs-6 fw-semibold">Start / End Date</label>
                                                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                                <label class="col-7 text-black fs-6 fw-bold">
                                                                    <span class="text-success">${work.work_start_date ? formatDate(work.work_start_date) :'-'}</span>
                                                                    <span class="ms-1 me-1">to</span>
                                                                    <span class="text-danger">${work.work_end_date ? formatDate(work.work_end_date) :'-'}</span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <hr class="mt-2 mb-2 border-gray-300i">
                                                `
                                        });
                                    }
                              
                                
                               studentRow +=   `
                                    <h5 class="title mt-4 fw-bold mb-3">Designation Information</h5>
                                        <div class="row mt-4">
                                            <div class="col-lg-6">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Nick Name</label>
                                                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">${staff.nick_name || '-'}</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Date of Joining</label>
                                                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">${staff.date_of_joining ? formatDate(staff.date_of_joining) :'-'}</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Job Position</label>
                                                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">${staff.job_position_name || '-'}</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Job Role</label>
                                                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">${staff.role_name || '-'}</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Description</label>
                                                    <label class="col-12 text-black fs-6 text-justify fw-bold text-wrap">${staff.description || '-'}</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Username</label>
                                                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">${staff.user_name || '-'}</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Password</label>
                                                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">${staff.password || '-'}</label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Basic Salary</label>
                                                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                    <label class="col-7 fs-6 fw-bold">
                                                        <span class="badge bg-success fw-semibold fs-7 text-black">
                                                            <span class="mdi mdi-currency-rupee text-black fw-bold"></span>
                                                            <span class="fs-6">${staff.basic_salary || '0'}</span>
                                                        </span>
                                                    </label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-7 fw-semibold">Shift Time</label>
                                                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-dark fs-6 fw-bold text-truncate mw-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${staff.shift_times_lab}">
                                                    ${staff.shift_times_lab}
                                                    </label>
                                                </div>
                                                <div class="row mb-4">
                                                    <label class="col-4 text-dark fs-6 fw-semibold">Per Hour Cost</label>
                                                    <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                                    <label class="col-7 text-black fs-6 fw-bold">
                                                        <span class="mdi mdi-currency-rupee text-black fw-bold"></span>
                                                        <span class="text-black fw-bold">${staff.per_hour_cost || '0'}</span>
                                                    </label>
                                                </div>`
    
                        studentRow += `
                                <div class="row mb-4">
                                    <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Attachment</label>
                                    <div class="col-12 mb-1">
                                        <div class="border border-gray-600i border-dashed rounded py-1 px-1">
                                            <div class="d-flex mb-1 align-items-center flex-wrap">
                                                ${
                                                    staff.attachment && staff.attachment.length > 0 
                                                    ? staff.attachment.map(file => {
                                                        let fileExt = file.split('.').pop().toLowerCase();
                                                        let isImage = ['jpg', 'jpeg', 'png', 'gif'].includes(fileExt);
                                                        let fileUrl = `{{asset('staff_attachments/')}}/staff_${staff.sno}/${file}`;
                                                        let previewSrc = isImage ? fileUrl : `{{ asset('assets/phdizone_images/def_pdf.png') }}`;
    
                                                        return `
                                                        <div class="d-block overlay text-center me-1 px-2 py-2">
                                                            <a href="${fileUrl}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded w-75px h-75px border border-gray-600i rounded" target="_blank" download>
                                                                <img src="${previewSrc}" class="h-75px w-75px" />
                                                            </a>
                                                        </div>`;
                                                    }).join('')
                                                    : '<p class="text-muted ms-2">No attachments available.</p>'
                                                }
                                            </div>
                                        </div>
                                    </div>
                                </div>`;
                        studentRow +=    `</div>
                                        </div>
                                        `;
                            studentTableBody.append(studentRow);
                        }
    
                    } else {
                        console.error('Error: ' + response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('An error occurred while fetching the Staff data.');
                }
            });
        }
    </script>

    <script>
        function sort_filter(val) {
            if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
            } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
            }
        }
    </script>
    @endsection