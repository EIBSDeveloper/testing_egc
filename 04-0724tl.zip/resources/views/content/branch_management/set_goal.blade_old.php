@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Goal Set')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
    <!-- Users List Table -->
    <div class="card">
        <div class="card-header border-bottom pb-1">
            <div class="row">
                <div class="col-lg-6">
                    <h5 class="card-title mb-1">Goal Set</h5>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="{{ url('/dashboard/crm') }}" class="d-flex align-items-center"><i
                                        class="mdi mdi-home text-body fs-4"></i></a>
                            </li>
                            <span class="text-dark opacity-75 me-1 ms-1">
                                <i class="mdi mdi-chevron-double-right fs-4"></i>
                            </span>
                            <li class="breadcrumb-item">
                                <a href="javascript:void(0);" class="d-flex align-items-center">Team Goal</a>
                            </li>
                        </ol>
                    </nav>
                </div>
                <div class="col-lg-6 text-end">
                    <label class="mt-1 fs-3 bg-label-info px-2 py-2 rounded"
                        id="branch_name_lab">{{ $branch_common->branch_name ?? '' }}</label>
                </div>
            </div>
        </div>



        <div class="card-body">
            <div class="row">
                <input type="hidden" id="teamIdInput" value="0">
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                    @php
                        $helper = new \App\Helpers\Helpers();
                        $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id; // Get branch_id from query or user session
                    @endphp

                    @if (isset($role_permission->manage_branch))
                        @if ($role_permission->manage_branch == 2)
                            @php
                                // Get the logged-in user_id
                                $user_id = auth()->user()->user_id;
                                $branch_data = $helper->get_branch_control_list($user_id);
                                $branches = $branch_data['branches'];
                                $franchises = $branch_data['franchises'];
                            @endphp
                            <select name="branch_id" class="select3 form-select" id="branchSelectsgoal"
                                onchange="branch_change()">
                                @if ($user_id == 0)
                                    <option value="0" selected>All Branches</option>
                                @endif
                                @if ($branches->isNotEmpty())
                                    <optgroup label="Branches">
                                        @foreach ($branches as $branch)
                                            <!--@ if($branch->sno!=1)-->
                                            <option value="{{ $branch->sno }}"
                                                {{ $selectedBranch == $branch->sno ? 'selected' : '' }}>
                                                {{ $branch->branch_name }}
                                            </option>
                                            <!--@ endif-->
                                        @endforeach
                                    </optgroup>
                                @endif


                                @if ($franchises->isNotEmpty())
                                    <optgroup label="Franchises">
                                        @foreach ($franchises as $franchise)
                                            <option value="{{ $franchise->sno }}"
                                                {{ $selectedBranch == $franchise->sno ? 'selected' : '' }}>
                                                {{ $franchise->franchise_name }}
                                            </option>
                                        @endforeach
                                    </optgroup>
                                @endif
                            </select>
                        @elseif($role_permission->manage_branch == 1)
                            @if ($branch_common)
                                <div class="d-flex align-items-center mt-2">
                                    <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                                    <div>
                                        <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                                        <small class="text-truncate max-w-10px text-muted"
                                            title="{{ $branch_common->branch_name }}">{{ $branch_common->branch_name }}</small>
                                    </div>
                                </div>
                            @else
                            @endif
                        @endif

                    @endif

                </div>
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                    <select id="department_filter" name="department_id"
                        class="select3 form-select validation_message_department" onchange="fetchTeamGoals()">
                        <!-- Options will be dynamically populated -->
                    </select>
                </div>
                <div class="col-lg-3 mb-3">
                    <div class="nav-align-top my-4">
                        <ul class="nav nav-pills justify-content-start" role="tablist">
                            <!-- Previous Month Button -->
                            <li class="nav-item me-1">
                                <a class="nav-link px-3" href="#" id="prevMonthBtn">
                                    <div class="text-center">
                                        <span class="mdi mdi-arrow-left-circle-outline fs-2"></span>
                                    </div>
                                </a>
                            </li>

                            <!-- Current Month Display -->
                            <li class="nav-item me-1">
                                <a class="nav-link active px-3 border border-dashed border-info" href="#">
                                    <div class="text-center">
                                        <span class="fs-6 fw-semibold text-capitalize" id="selectedMonth">
                                            {{ \Carbon\Carbon::now()->format('F') }}
                                        </span>
                                        <div class="d-block">
                                            <span class="fw-semibold fs-8" id="selectedYear">
                                                ({{ \Carbon\Carbon::now()->year }})
                                            </span>
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <!-- Next Month Button -->
                            <li class="nav-item me-1">
                                <a class="nav-link px-3" href="#" id="nextMonthBtn">
                                    <div class="text-center">
                                        <span class="mdi mdi-arrow-right-circle-outline fs-2"></span>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-5">
                    <!-- Accordion Container -->
                    <div class="accordion" id="goalAccordion">
                        <!-- Accordion Item -->
                        <div class="accordion-item">
                            <!-- Accordion Header -->
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-lg-12 mt-2">
                <div class="table-responsive">
                    <table
                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 indiv_date_scroll_table"
                        style="display: none">

                    </table>
                </div>
            </div>

            <div class="d-flex justify-content-end align-items-center mt-4">
                <button type="button" class="btn btn-primary" id="updateGoalButton">
                    <span class="spinner-border spinner-border-sm d-none" id="updateGoalLoader" role="status"
                        aria-hidden="true"></span>
                    Update
                </button>

            </div>
        </div>

    </div>



    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        .table-container {
            overflow-x: auto;
            overflow-y: auto;
            max-height: 600px;
            position: relative;
        }

        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
        }

        .table thead th,
        .table tbody td {
            position: relative;
            z-index: 1;
            padding: 8px;
        }

        .table thead th {
            position: sticky;
            top: 0;
            /*background: #1da1f2;*/
            color: #fff;
            z-index: 3;
        }

        .table tbody td {
            background: #fff;
            color: #000;
        }

        .table thead th:first-child,
        .table thead th:last-child {
            position: sticky;
            /*background: #1da1f2;*/
            z-index: 4;
        }



        .table tbody td:first-child,
        .table tbody td:last-child {
            position: sticky;
            background: #fff;
            z-index: 4;
        }

        .table thead th:first-child,
        .table tbody td:first-child {
            left: 0;
        }

        .table thead th:last-child,
        .table tbody td:last-child {
            right: 0;
        }

        .table tbody td {
            z-index: 2;
        }

        .goal-label-box {
            background-color: #f8f9fa;
            /* Light gray */
            padding: 6px 12px;
            border-radius: 4px;
            border: 1px solid #cccccc;
            display: inline-block;
            min-width: 100px;
            text-align: center;
        }

        .goal-actual-field {
            background-color: #e4c30a;
            /* Light gray */
            border: 1px solid #e4c30a;
            cursor: not-allowed;
        }

        .select2-container {
            margin-right: 0.22rem !important;
            /* Equivalent to Bootstrap's me-1 */
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .goal-label {
            min-width: 200px;
            /* Ensures all labels are of equal width */
            text-align: left;
            /* Aligns text to the left for consistency */
        }

        .goal-label-staff {
            font-size: 10px;
            font-weight: bold;
            color: #555;
            text-align: center;
        }

        .goal-inline-group {
            display: flex;
            align-items: center;
            gap: 6px;
            /* Space between fields */
        }

        .goal-input-wrap {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .goal-label {
            font-size: 10px;
            font-weight: bold;
            color: #555;
            text-align: center;
        }

        .goal-input-staff {
            width: 80px;
            padding: 4px;
            font-size: 15px;
            font-weight: bold;
            text-align: center;
            border-radius: 4px;
            background-color: #ddb723;
            border: 1px solid #1b1a14;
            color: #1b1a14;
        }

        .goal-actual-field-staff {
            background-color: #e4c30a;
            border: 1px solid #e4c30a;
            width: 80px;
            /* Smaller input field */
            color: #1b1a14;
            text-align: center;
            cursor: not-allowed;
            font-size: 15px;
            font-weight: bold;
        }



        .accordion-body {
            overflow-x: auto;
            /* Allow scrolling instead of breaking layout */
            white-space: normal;
            /* Prevent long text from expanding container */
            max-width: 100%;
            /* Keep it within parent */
        }

        .accordion-body span {
            display: block;
            word-wrap: break-word;
            /* Ensures text wraps */
            overflow-wrap: break-word;
        }


        .tenx-badge {
            position: absolute;
            top: -12px;
            right: 165px;
            background: linear-gradient(to right, #28a745, #ffd700);
            color: white;
            font-weight: bold;
            padding: 4px 8px;
            border-radius: 10px;
            font-size: 0.75rem;
            box-shadow: 0 0 6px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        .mini-check:checked~#badge_undefined,
        .mini-check:checked+.tenx-badge,
        input[type="checkbox"].mini-check:checked~.tenx-badge {
            display: inline-block;
        }
    </style>
    <script>
        var currentMonth = new Date().getMonth() + 1; // Get current month (1-12)
        var currentYear = new Date().getFullYear();
        var updateGoalButton = document.getElementById("updateGoalButton");

        function updateMonthDisplay() {
            let monthNames = [
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            ];
            $("#monthLabel").text(monthNames[currentMonth - 1] + " " + currentYear);
            document.getElementById("selectedMonth").textContent = monthNames[currentMonth - 1];
            document.getElementById("selectedYear").textContent = "(" + currentYear + ")";

            document.getElementById("prevMonthBtn").classList.toggle("disabled", false);
            document.getElementById("nextMonthBtn").classList.toggle("disabled", false);

            // Ensure update button visibility is correct
            toggleButtonVisibility();

            // Fetch updated team goals for the selected month
            fetchTeamGoals();
        }

        function fetchDepartments() {
            $.ajax({
                url: "{{ route('departments_setgoal') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $("#department_filter");
                        selectDropdown.empty().append('<option value="">Select Department</option>');

                        // Filter departments with sno 1, 2, or 3
                        let filteredData = response.data.filter(dept => [1, 2, 6, 14, 15,7].includes(dept.sno));

                        filteredData.forEach(function(dept) {
                            selectDropdown.append($('<option></option>')
                                .attr('value', dept.sno)
                                .text(dept.department_name));
                        });

                        selectDropdown.off("change").on("change", function() {
                            let selectedDeptText = $(this).find("option:selected").text();
                            console.log("Department selected:", selectedDeptText); // Debugging
                            $("#departmentLabel").text(selectedDeptText);
                            fetchTeamGoals();
                        });

                    }
                },
                error: function(error) {
                    console.error('Error fetching departments:', error);
                }
            });
        }

        function toggleButtonVisibility() {
            let today = new Date();
            let selectedDate = new Date(currentYear, currentMonth - 1, 1);

            if (selectedDate >= new Date(today.getFullYear(), today.getMonth(), 1)) {
                updateGoalButton.classList.remove('d-none');
            } else {
                updateGoalButton.classList.add('d-none');
            }
        }

        document.getElementById("prevMonthBtn").addEventListener("click", function(e) {
            e.preventDefault();
            if (currentMonth === 1) {
                currentMonth = 12;
                currentYear--;
            } else {
                currentMonth--;
            }
            updateMonthDisplay();
        });

        document.getElementById("nextMonthBtn").addEventListener("click", function(e) {
            e.preventDefault();
            if (currentMonth === 12) {
                currentMonth = 1;
                currentYear++;
            } else {
                currentMonth++;
            }
            updateMonthDisplay();
        });

        function fetchTeamGoals() {
            $('.input_field_team').attr('readonly', false);
            let departmentId = $("#department_filter").val();
            let month = $("#selectedMonth").text().trim();
            let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
            let branchId = $("#branchSelectsgoal").val();
            console.log("fetchTeamGoals called with:", {
                departmentId,
                month,
                year
            });

            if (!departmentId) return;

            $.ajax({
                url: "{{ route('team_setgoals') }}",
                type: "GET",
                data: {
                    month_id: month,
                    branch_id: branchId,
                    year: year,
                    department_id: departmentId
                },
                success: function(response) {
                    console.log("Goals fetched:", response);

                    if (response.status === 200 && response.data) {
                        let goal = response.data;
                        console.log(goal.no_of_papers)
                        let isGoalSet = goal.status;
                        let messagedefault = goal.team_id; //empty ""
                        let teamId = goal.team_id || 0;
                        if (!goal.team_id) {
                            // Hide the entire button if no default goal is set
                            document.getElementById('updateGoalButton').classList.add('d-none');
                        }
                        $("#teamIdInput").val(teamId);

                        // Define department-specific goal labels
                        const goalLabels = {
                            "Pre Sales Department": [{
                                    label: "Conversion",
                                    type: "conversion",
                                    cal: "count"
                                },
                                {
                                    label: "Conversion Rate",
                                    type: "cr",
                                    cal: "percentage"
                                },
                                {
                                    label: "Average Business Value",
                                    type: "abv",
                                    cal: "rupee"
                                },
                                {
                                    label: "Average Collection Value",
                                    type: "acv",
                                    cal: "rupee"
                                },
                                {
                                    label: "Average Call Outgoing",
                                    type: "avg_call_out",
                                    cal: "count"
                                },
                                {
                                    label: "Average Walk-ins",
                                    type: "no_of_walk",
                                    cal: "count"
                                },
                                {
                                    label: "Average Followup",
                                    type: "no_of_followup",
                                    cal: "count"
                                }

                            ],
                            "Post Sales Department": [{
                                    label: "Post Conversion",
                                    type: "conversion",
                                    cal: "count"
                                },
                                {
                                    label: "Post Average Business Value",
                                    type: "abv",
                                    cal: "rupee"
                                },
                                {
                                    label: "Post Average Collection Value",
                                    type: "acv",
                                    cal: "rupee"
                                }

                            ],
                            "Production Department": [{
                                    label: "Working Hours",
                                    type: "working_hours",
                                    cal: "count"
                                },
                                {
                                    label: "Rework",
                                    type: "rework",
                                    cal: "count"
                                },
                            ],
                            "Journal Department": [{
                                label: "No Of Papers",
                                type: "no_of_papers",
                                cal: "count"
                            }],
                            "PC": [{
                                    label: "Productions",
                                    type: "productions",
                                    cal: "rupee"
                                },
                                {
                                    label: "Reference Sales",
                                    type: "reference_sales",
                                    cal: "count"
                                }
                            ],
                            "CRE Department": [{
                                    label: "No Of Reviews",
                                    type: "no_of_reviews",
                                    cal: "count"
                                },
                            ]
                            "Collection": [{
                                    label: "Harvesting (%)",
                                    type: "harvesting_percentage",
                                    cal: "percentage"
                                },
                            ]
                        };

                        let selectedDeptText = $("#department_filter option:selected").text().trim();
                        let selectedGoals = goalLabels[selectedDeptText] || [];

                        const buttonHtml = messagedefault ?
                            (`<div id="collapseGoals" class="accordion-collapse collapse show" aria-labelledby="headingGoals" data-bs-parent="#goalAccordion">
                            <div class="accordion-body">
                                ${selectedGoals.map(goalItem => generateGoalRow(goalItem.label, goalItem.type, goalItem.cal, goal, isGoalSet)).join('')}
                                <div class="mt-3 text-end">
                                  ${isGoalSet 
                                    ? `<button class="btn btn-danger undo-btn">Undo Goal</button>` 
                                    : `<button class="btn btn-primary goal-set-btn">Set Goal</button>`}
                                </div>
                            </div>
                          </div>`) :
                            `<a href="/settings_default_setgoal"
                           style="display: block; background-color: #ffe6e6; color: #b30000; font-weight: 600; padding: 10px 14px; border-radius: 4px; text-align: center; text-decoration: none; cursor: pointer;"
                           class="mb-2 blinking-message">
                           ⚠️ <u>Click here to set your Default Goal Value</u> →
                        </a>`;


                        let goalsHtml = `
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingGoals">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseGoals" aria-expanded="true" aria-controls="collapseGoals">
                                    <span class="badge bg-primary rounded fs-5 me-2">${selectedDeptText} - Team Goals</span>
                                </button>
                            </h2>
                             ${buttonHtml}
                        </div>`;

                        $("#goalAccordion").html(goalsHtml);
                        $(".select3").select2(); // Reinitialize Select2
                        if (goal.ten_x) {
                            const tenX = goal.ten_x;
                            for (const key in tenX) {
                                const isChecked = tenX[key] === "1";
                                const type = key.replace("_10x", "");

                                const tenXCheckbox = $(`input[name="${type}_10x"]`);
                                const badge = $(`#badge_${type}`);

                                if (tenXCheckbox.length) {
                                    tenXCheckbox.prop("checked", isChecked);
                                    if (isChecked) {
                                        badge.show();
                                    } else {
                                        badge.hide();
                                    }
                                }
                            }
                        }

                        // Toggle visibility on checkbox change
                        $(".goal-checkbox").on("change", function() {
                            let type = $(this).data("type");
                            let select = $(`select[name="${type}_type"]`);
                            let input_over_all = $(`input[name="${type}_over_all"]`);
                            let input_actual = $(`input[name="${type}_actual"]`);
                            let input_10x = $(`input[name="${type}_10x"]`);
                            let badge = $(`#badge_${type}`); // <-- add this line
                            if ($(this).is(":checked")) {
                                select.css({
                                    "visibility": "visible",
                                    "opacity": "1",
                                    "display": "inline-block"
                                });
                                input_over_all.show();
                                input_actual.show();
                                input_10x.show();
                            } else {
                                select.css({
                                    "visibility": "hidden",
                                    "opacity": "0",
                                    "display": "none"
                                });
                                input_over_all.hide();
                                input_actual.hide();
                                input_10x.hide().val('');
                                badge.hide(); // <-- hide the 10X badge here
                                $(`input[name="${type}_10x"]`).prop("checked", false);
                            }
                        }).trigger("change"); // Apply on page load


                        let departmentId = $("#department_filter").val();
                        let month = $("#selectedMonth").text().trim();
                        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');

                        if (isGoalSet) {
                            fetchStaff(month, year, departmentId = null);
                        } else {
                            $(".indiv_date_scroll_table").hide();
                        }


                    } else {
                        $("#goalAccordion").html(
                            '<p class="text-muted">No goals found for this selection.</p>');
                    }
                },
                error: function(error) {
                    console.error("Error fetching team goals:", error);
                }
            });
        }

        function generateGoalRow(label, type, cal, goal, isGoalSet) {
            // Map `cal` values to display labels and assign corresponding values
            const calMapping = {
                "percentage": {
                    label: "%",
                    value: 1
                },
                "rupee": {
                    label: "₹",
                    value: 3
                },
                "rupee": {
                    label: "X",
                    value: 4
                },
                "count": {
                    label: "Count",
                    value: 2
                }
            };

            // Get the appropriate label based on `calType`
            const {
                label: selectedLabel,
                value: selectedValue
            } = calMapping[cal] || {
                label: "Unknown",
                value: ""
            };

            // Get background color dynamically
            const backgroundColor = getCalColor(cal);

            return `
            <div class="d-flex align-items-center mt-2" style="width: 100%;">
                <input type="checkbox" class="form-check-input me-3 fs-5 goal-checkbox check-disabled" data-type="${type}"
                    ${goal[type + "_check"] ? 'checked' : ''}  ${!isGoalSet ? '' : 'disabled'} disabled>

                <!-- Fixed width for label column -->
                <label class="fw-semibold fs-6 goal-label me-2 goal-label-box text-truncate"
                    style="width: 200px; flex-shrink: 0;">${label}</label>

                <!-- Fixed width for the span (ensures alignment) -->
                <span class="fw-bold border fs-6 px-2 py-1 me-2 rounded text-center d-inline-block"
                    style="width: 70px; min-width: 70px; flex-shrink: 0; text-align: center; background-color: ${backgroundColor};">
                    ${selectedLabel}
                </span>

                <input type="hidden" name="${type}_type" value="${selectedValue}">

                <!-- Input field takes remaining space -->
                    <div class="position-relative" style="flex-grow: 1; min-width: 100px;">
                        <input class="form-control input_field_team pe-5" type="text"
                            name="${type}_over_all" id="${type}_over_all"
                            value="${goal[type + "_over_all"] || ''}"
                            ${!isGoalSet ? '' : 'readonly'}
                            oninput="this.value = this.value.replace(/\\D/g,'')">

                        <!-- Mini checkbox inside input -->
                        <div class="form-check position-absolute"
                            style="top: 50%; right: 0px; transform: translateY(-50%);">
                            <input type="checkbox" name="${type}_10x" class="form-check-input mini-check" onchange="toggleTenXBadge('${type}', this.checked)">
                        </div>

                        <!-- 10X badge -->
                        <span id="badge_${type}"  class="tenx-badge badge_${type}" style="display: none;">10X</span>
                    </div>
            </div>`;
        }

        // Function to get color mapping
        function getCalColor(cal) {
            const calColors = {
                "percentage": "#87CEEB", // Sky blue
                "rupee": "#FFCF40", // Gold
                "count": "#FFA500" // Orange
            };
            return calColors[cal] || "#D3D3D3"; // Default color if not found
        }

        function toggleTenXBadge(type, isChecked) {
            const badge = document.getElementById(`badge_${type}`);
            if (badge) {
                badge.style.display = isChecked ? 'inline-block' : 'none';
            }
        }
        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('mini-check')) {
                const type = e.target.dataset.type;
                const badge = document.getElementById(`badge_${type}`);
                if (badge) {
                    badge.style.display = e.target.checked ? 'inline-block' : 'none';
                }
            }
        });

        $(document).on("click", ".undo-btn", function() {
            let $button = $(this);
            $('.input_field_team').removeAttr('readonly');
            //   $('.check-disabled').removeAttr('disabled');
            // Change Undo Goal button to Set Goal button
            $button.removeClass("btn-danger undo-btn")
                .addClass("btn-primary goal-set-btn")
                .text("Set Goal");
        });



        // Initial function calls on page load
        updateMonthDisplay();
        fetchDepartments();




        $(document).on('click', '#updateGoalButton', function() {
            let button = $(this);
            let loader = $("#updateGoalLoader");

            // Show loader and disable button
            button.prop("disabled", true);
            loader.removeClass("d-none");

            let branchId = $("#branchSelectsgoal").val();
            let month = $("#selectedMonth").text().trim();
            let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
            let departmentId = $("#department_filter").val();
            let teamId = $("#teamIdInput").val() || 0; // Get stored team_id, default to 0
            let staffGoals = [];

            $("#goal_set_container tr").each(function() {
                let staffId = $(this).find("td:first").data("staff-id");
                let staffData = {
                    staff_id: staffId
                };

                //   $(this).find("input").each(function () {
                //       let fieldName = $(this).attr("name");
                //       let fieldValue = $(this).val() || 0;
                //       staffData[fieldName] = parseInt(fieldValue);
                //   });

                $(this).find("input").each(function() {
                    let fieldName = $(this).attr("name");

                    if ($(this).attr("type") === "checkbox") {
                        // Send 1 if checked, 0 if not
                        staffData[fieldName] = $(this).is(":checked") ? 1 : 0;
                    } else {
                        let fieldValue = $(this).val() || 0;
                        staffData[fieldName] = parseInt(fieldValue);
                    }
                });

                staffGoals.push(staffData);
            });

            $.ajax({
                url: "{{ route('staff_setgoal_update') }}",
                type: "POST",
                data: {
                    month_id: month,
                    year: year,
                    department_id: departmentId,
                    branch_id: branchId,
                    team_id: teamId,
                    staff_goals: staffGoals,
                    _token: "{{ csrf_token() }}"
                },
                success: function(response) {
                    if (response.status === 200) {
                        fetchStaff(month, year, departmentId);
                        toastr.success('Individual Updated Successfully!');
                    } else {
                        alert("Failed to update goals.");
                    }
                },
                error: function(error) {
                    console.error("Error updating goals:", error);
                },
                complete: function() {
                    // Hide loader and enable button after request completes
                    loader.addClass("d-none");
                    button.prop("disabled", false);
                }
            });
        });




        function fetchStaff(month, year, departmentId = null) {
            console.log("NEW Fetching Data for:", month, year, departmentId || $("#department_filter").val());
            let branchId = $("#branchSelectsgoal").val();
            $.ajax({
                url: "{{ route('staff_setgoal') }}",
                type: "GET",
                data: {
                    month_id: month,
                    year: year,
                    branch_id: branchId,
                    department_id: departmentId ?? $("#department_filter").val()
                },
                success: function(response) {
                    console.log("nEW API Response:", response);

                    if (response.status === 200 && Array.isArray(response.data) && response.data.length > 0) {
                        let tableHtml = `<thead><tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">`;
                        let goalsetHtml = '';

                        // Get the first staff member's check values to determine columns
                        let firstStaff = response.data[0];
                        console.log("Test First Staff:", firstStaff);

                        tableHtml += `<th class="min-w-100px">Staff's</th>`;
                        if (firstStaff.conversion_check == 1) tableHtml +=
                            `<th class="min-w-100px">Conversion</th>`;
                        if (firstStaff.cr_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">CR</th>`;
                        if (firstStaff.abv_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">ABV</th>`;
                        if (firstStaff.acv_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">ACV</th>`;
                        if (firstStaff.avg_call_out_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">Avg Call Out</th>`;
                        if (firstStaff.no_of_walk_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">Avg Walk-Ins</th>`;
                        if (firstStaff.no_of_followup_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">Avg Followup</th>`;
                        if (firstStaff.no_of_reviews_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">No. of Reviews</th>`;
                        if (firstStaff.working_hours_check == 1) tableHtml +=
                            `<th class="min-w-100px">Working Hours</th>`;
                        if (firstStaff.no_of_papers_check == 1) tableHtml +=
                            `<th class="min-w-100px">No Of Papers</th>`;
                        if (firstStaff.no_of_post_sale_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">No. of Post Sale</th>`;
                        if (firstStaff.harvesting_percentage_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">Harvesting (%)</th>`;
                        if (firstStaff.min_no_of_students_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">Min No. of Students</th>`;
                        if (firstStaff.no_of_placements_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">No. of Placements</th>`;
                        if (firstStaff.mou_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">MOU</th>`;
                        if (firstStaff.rework_check == 1) tableHtml += `<th class="min-w-100px">Rework</th>`;
                        if (firstStaff.productions_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">Productions</th>`;
                        if (firstStaff.reference_sales_check == 1) tableHtml +=
                            `<th class="min-w-100px text-center">Reference Sales</th>`;
                        tableHtml +=
                            `<th class="min-w-50px">Status</th></tr></thead><tbody id="goal_set_container">`;

                        const fields = Object.keys(firstStaff).filter(key => key.endsWith('_check'));

                        response.data.forEach(function(staff) {
                            let isPastMonth = staff.month < new Date().getMonth() + 1;

                            goalsetHtml += `<tr>
                              <td data-staff-id="${staff.sno}">
                                    <div class="d-flex align-items-center">
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle" data-kt-image-input="true">
                                                <img src="${staff.staff_image ? '{{ asset('staff_images/') }}/' + staff.staff_image : '{{ asset('assets/eapl_images/user_1.png') }}'}" class="w-px-40 h-auto rounded">
                                            </div>
                                        </div>
                                        <div class="ms-2">
                                            <div class="mb-0">
                                                <span class="fs-6 fw-bold">${staff.staff_name}</span>
                                            </div>
                                            <div class="d-block">
                                                <label class="text-dark fs-7 d-block">${staff.department_name}</label>
                                            </div>
                                        <div class="d-block">
                                            <label class="text-black fs-8 badge ${getRoleColor(staff.role_name)}">${staff.role_name}</label>
                                            ${
                                                staff.role_name && staff.role_name.toLowerCase().includes("team lead")
                                                ? `
                                                                        <div class="d-flex align-items-center mt-1">
                                                                            <input type="checkbox" name="sales_lead_check" class="form-check-input staff-mini-check me-2"
                                                                                ${staff.sales_lead_checks == 1 ? 'checked' : ''}
                                                                            >
                                                                            <span class="self-badge badge rounded-pill px-2 py-1"
                                                                                style="font-size: 0.65rem; background: linear-gradient(to right, #00a9ff, #ff00ea); color: white; ${staff.sales_lead_checks == 1 ? '' : 'display:none;'}">
                                                                                Self
                                                                            </span>
                                                                        </div>
                                                                    `
                                                : ''
                                            }
                                        </div>


                                        </div>
                                    </div>
                                </td>`;

                            fields.forEach(field => {
                                const fieldName = field.replace('_check', '');
                                if (staff[field] == 1) {
                                    const overAllValue = staff[fieldName] ?? ''; // Target value
                                    const actualValue = staff[`${fieldName}_actual`] ??
                                        ''; // Actual value

                                    goalsetHtml += `<td>
                                    <div class="goal-inline-group">
                                        <div class="goal-input-wrap">
                                            <label class="goal-label-staff">Target</label>
                                            ${isPastMonth
                                                ? `<span class="goal-value">${overAllValue}</span>`
                                                : `<input class="form-control goal-input-staff" type="text" name="${fieldName}" id="${fieldName}" value="${overAllValue}" oninput="this.value = this.value.replace(/[^0-9]/g, '')">`
                                            }
                                        </div>
                                    </div>
                                </td>`;
                                }
                            });

                            goalsetHtml +=
                                `<td><span class="badge ${getStatusClassView(staff.status)} fs-5">${staff.status || 'Pending'}</span></td></tr>`;
                        });


                        tableHtml += goalsetHtml + `</tbody>`;

                        // Update the table dynamically
                        $(".indiv_date_scroll_table").html(tableHtml).show();
                    }
                },
                error: function(error) {
                    console.error('Error fetching staff:', error);
                }
            });
        }


        $(document).on('change', '.staff-mini-check', function() {
            const badge = $(this).siblings('.self-badge');
            if ($(this).is(':checked')) {
                badge.show();
            } else {
                badge.hide();
            }
        });

        function getRoleColor(role) {
            if (!role) return "bg-secondary text-white"; // Default gray if role is empty

            role = role.toLowerCase(); // Normalize case for comparison

            if (role.includes("team lead")) {
                return "bg-danger text-white";
            } else if (role.includes("head")) {
                return "bg-success text-white";
            } else {
                return "bg-info text-white";
            }
        }

        function getStatusClassView(status) {
            switch (status) {
                case "Pending":
                    return "bg-danger";
                case "Goal Set":
                    return "bg-success";
                case "Cancelled":
                    return "bg-warning";
                default:
                    return "bg-secondary";
            }
        }

        // Initial load
        updateMonthDisplay();
        fetchStaff(currentMonth, currentYear);




        $(document).on("click", ".goal-set-btn", function() {
            let branchId = $("#branchSelectsgoal").val();
            let departmentId = $("#department_filter").val();
            let monthId = $("#selectedMonth").text().trim();
            let yearId = $("#selectedYear").text().trim().replace(/[()]/g, '');

            if (!departmentId) {
                alert("Please select a department.");
                return;
            }

            let data = {
                department_id: departmentId,
                branch_id: branchId,
                month_id: monthId,
                year_id: yearId,
            };

            $(".goal-checkbox").each(function() {
                let type = $(this).data("type");

                data[`${type}_over_all`] = $(`input[name='${type}_over_all']`).val() || "";
                data[`${type}_check`] = $(this).is(":checked") ? 1 : 0;
                // data[`${type}_type`] = $(`select[name='${type}_type']`).val() || "";
                data[`${type}_10x`] = $(`input[name='${type}_10x']`).is(":checked") ? 1 : 0;
                data[`${type}_type`] = $(`input[name='${type}_type']`).val() || "";

            });

            console.log("Payload Data:", data); // Debugging

            $.ajax({
                url: "{{ route('save_team_setgoals') }}",
                type: "POST",
                data: data,
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
                },
                success: function(response) {
                    if (response.status === 200) {
                        //   playSuccessSound(); // Play success sound
                        toastr.success('Team Goal Updated Successfully!');
                        console.log("Calling fetchStaff:", monthId, yearId, null); // Debugging
                        fetchTeamGoals();
                        console.log("Calling fetchStaff:", monthId, yearId, null); // Debugging
                        fetchStaff(monthId, yearId, null);
                    } else {
                        playErrorSound(); // Play error sound
                        toastr.error('Error saving team goal.');
                    }
                },
                error: function(error) {
                    new Audio("{{ asset('assets/audiofolder/just-saying-593.mp3') }}").play();
                    console.error('Error fetching staff:', error);
                }
            });

            $('.input_field_team').attr('readonly', true);
        });




        function playSuccessSound() {
            let audio = new Audio("{{ asset('assets/audiofolder/mixkit-cartoon-door-melodic-bell-110.wav') }}");
            audio.play();
        }

        function playErrorSound() {
            let audio = new Audio("{{ asset('assets/audiofolder/just-saying-593.mp3') }}");
            audio.play();
        }

        function branch_change() {
            const select = document.getElementById('branchSelectsgoal');
            const selectedText = select.options[select.selectedIndex].text;
            // alert("Selected: " + selectedText);
            $('#branch_name_lab').html(selectedText);
            fetchTeamGoals();
        }
    </script>
@endsection
