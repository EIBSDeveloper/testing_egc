@extends('layouts/layoutMaster')

@section('title', 'Manage Company')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>

@php
    $module_name = 'Branch Management';
    $menu_name   = 'Manage Company';
@endphp

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Company</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Branch Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    @if(auth()->user()->hasPermission($module_name, 'Add', $menu_name))
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_create_company">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Company
                    </a>
                    @endif
                </div>
            </div>
        </div>
        <div class="card-body">
            @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-150px">Company</th>
                                    <th class="min-w-100px">Address</th>
                                    <th class="min-w-100px">Email ID</th>
                                    <th class="min-w-100px">Contact Person / Mobile</th>
                                    <th class="min-w-50px">Status</th>
                                    <th class="min-w-100px text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7">
                                @if (isset($ListTable))
                                    @foreach ($ListTable as $list)
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="text-truncate max-w-175px" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="{{ $list->company_name }}">
                                                        {{ $list->company_name }}</div>
                                                    <a href="{{ $list->company_website }}" target="_blank" class="ms-1"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="Website URL">
                                                        <i class="mdi mdi-web fs-4 text-dark"></i>
                                                    </a>
                                                </div>
                                                <div class="d-block">
                                                    <label
                                                        class="badge bg-warning fs-8 text-black fw-bold">{{ $list->company_type_name }}
                                                        {{ $list->slug_name }}</label>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-wrap max-w-250px" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="{{ $list->company_door_no }} {{ $list->company_area }}
                                                        {{ $list->citiesname }} {{ $list->statename }}
                                                        {{ $list->name }}">
                                                    <label>{{ $list->company_door_no }} {{ $list->company_area }}
                                                        {{ $list->citiesname }} {{ $list->statename }}
                                                        {{ $list->name }}</label>
                                                </div>
                                            </td>
                                            <td>
                                                <label>{{ $list->company_mail }}</label>
                                            </td>
                                            <td>
                                                <label>{{ $list->company_ct_person }} </label>
                                                <div class="d-block">
                                                    <label
                                                        class="fs-8 text-black fw-semibold">{{ $list->company_ct_number }}</label>
                                                </div>
                                            </td>
                                            <td>
                                                <label class="switch switch-square">
                                                    <input type="checkbox" class="switch-input"
                                                        {{ $list->status == 0 ? 'checked' : '' }}
                                                        onchange="updateDepartmentStatus('{{ $list->sno }}', this.checked)" />
                                                    <span class="switch-toggle-slider">
                                                        <span class="switch-on"></span>
                                                        <span class="switch-off"></span>
                                                    </span>
                                                </label>
                                            </td>
                                            <td class="text-end">
                                                @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                                <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2"
                                                    data-bs-toggle="modal" data-bs-target="#kt_modal_view_company"
                                                    onclick="viewmodel('{{ $list->sno }}')">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i
                                                            class="mdi mdi-eye-outline fs-3 text-black"></i></span>
                                                </a>
                                                @endif
                                                @if(auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                                                <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2"
                                                    data-bs-toggle="modal" data-bs-target="#kt_modal_update_company"
                                                    onclick="editmodel('{{ $list->sno }}')">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i
                                                            class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                                </a>
                                                @endif
                                                @if(auth()->user()->hasPermission($module_name, 'Delete', $menu_name))
                                                <a href="#"
                                                    onclick="confirmDelete('{{ $list->sno }}','{{ $list->company_name }}','{{ $list->company_id }}')"data-bs-toggle="modal"
                                                    data-bs-target="#kt_modal_delete_company">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i
                                                            class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                                </a>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            @endif
        </div>
    </div>



    <!--begin::Modal - Create Company-->
    <div class="modal fade" id="kt_modal_create_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Create Company</h3>
                    </div>
                    <form method="POST" action="{{ route('add_company') }}" id="add_form" autocomplete="off">
                        @csrf
                        <div class="row mb-6">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="company_name" id="company_name" class="form-control"
                                    placeholder="Enter Company Name"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"maxlength="50" />
                                <div class="error_msg text-danger" id="company_name_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Type<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" name="company_type" id="company_type">
                                    <option value="">Select Company Type</option>
                                    @if (isset($Company_type_list))
                                        @foreach ($Company_type_list as $type_list)
                                            <option value="{{ $type_list->sno }}">{{ $type_list->company_type_name }}
                                                ({{ $type_list->slug_name }})
                                            </option>
                                        @endforeach
                                    @endif
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Email ID"
                                    id="company_mail" name="company_mail"
                                    oninput=" this.value = this.value.toLowerCase();"maxlength="50" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Website URL"
                                    id="website_url" name="website_url" maxlength="80"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Contact Person Name"
                                    id="ct_person" name="ct_person"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No"
                                    maxlength="10"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="ct_per_mobile_no" name="ct_per_mobile_no" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Country<span
                                        class="text-danger">*</span></label>
                                <select id="countryId" name="country" class="select3 form-select ">
                                    <option value="">Select Country</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">State<span
                                        class="text-danger">*</span></label>
                                <select id="stateId" name="state" class="select3 form-select">
                                    <option value="">Select State</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">City<span
                                        class="text-danger">*</span></label>
                                <select id="cityId" name="city" class="select3 form-select">
                                    <option value="">Select City</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Area / Street"
                                    id="area_street" name="area_street" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Door/Flat No"
                                    id="door_flat_no" name="door_flat_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Pincode"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="pincode" name="pincode" maxlength="20"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">GST No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter GST No" id="gst_no"
                                    name="gst_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">CIN No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter CIN No" id="cin_no"
                                    name="cin_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pan No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Pan No" id="pan_no"
                                    name="pan_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-8 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control h-auto" placeholder="Enter Description" id="company_desc" name="company_desc" maxlength="100"></textarea>
                            </div>
                        </div>
                        <div class="divider">
                            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                        </div>
                        <div class="row mb-6">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Bank Name"
                                    id="comapny_bank_name" name="comapny_bank_name" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Bank Branch Name"
                                    id="comapny_bank_branch" name="comapny_bank_branch" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account Holder"
                                    id="comapny_acc_holder" name="comapny_acc_holder" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account No"
                                    id="comapny_acc_no" name="comapny_acc_no" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter IFSC Code"
                                    id="comapny_bank_ifsc" name="comapny_bank_ifsc" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="company_create_btn" onclick="AddvalidateForm()">Create
                                Company</button>
                        </div>
                    </form>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal - Create Company-->


    <!--begin::Modal - Update Company-->
    <div class="modal fade" id="kt_modal_update_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Update Company</h3>
                    </div>
                    <form method="POST" action="{{ route('update_company') }}" id="edit_form" autocomplete="off">
                        @csrf
                        <div class="row mb-6">
                            <input type="hidden" id="edit_id" name="edit_id" />
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="company_name" id="edit_company_name" class="form-control"
                                    placeholder="Enter Company Name"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                                <div class="error_msg text-danger" id="edit_company_name_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Type<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" name="company_type" id="edit_company_type">
                                    <option value="">Select Company Type</option>
                                    @if (isset($Company_type_list))
                                        @foreach ($Company_type_list as $type_list)
                                            <option value="{{ $type_list->sno }}">{{ $type_list->company_type_name }}
                                                ({{ $type_list->slug_name }})
                                            </option>
                                        @endforeach
                                    @endif
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Email ID"
                                    id="edit_company_mail" name="company_mail"
                                    oninput=" this.value = this.value.toLowerCase();" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Website URL"
                                    id="edit_website_url" name="website_url"maxlength="80" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Contact Person Name"
                                    id="edit_ct_person" name="ct_person"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No"
                                    maxlength="10"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="edit_ct_per_mobile_no" name="ct_per_mobile_no" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Country<span
                                        class="text-danger">*</span></label>
                                <select id="edit_countryId" name="country" class="select3 form-select ">
                                    <option value="">Select Country</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">State<span
                                        class="text-danger">*</span></label>
                                <select id="edit_stateId" name="state" class="select3 form-select">
                                    <option value="">Select State</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">City<span
                                        class="text-danger">*</span></label>
                                <select id="edit_cityId" name="city" class="select3 form-select">
                                    <option value="">Select City</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Area / Street"
                                    id="edit_area_street" name="area_street" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Door/Flat No"
                                    id="edit_door_flat_no" name="door_flat_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Pincode"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="edit_pincode" name="pincode" maxlength="20"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">GST No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter GST No" id="edit_gst_no"
                                    name="gst_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">CIN No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter CIN No" id="edit_cin_no"
                                    name="cin_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pan No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Pan No" id="edit_pan_no"
                                    name="pan_no"maxlength="50" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-8 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control h-auto" placeholder="Enter Description" id="edit_company_desc" name="company_desc" maxlength="100"></textarea>
                            </div>
                        </div>
                        <div class="divider">
                            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                        </div>
                        <div class="row mb-6">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Bank Name"
                                    id="edit_comapny_bank_name" name="comapny_bank_name" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Bank Branch Name"
                                    id="edit_comapny_bank_branch" name="comapny_bank_branch" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account Holder"
                                    id="edit_comapny_acc_holder" name="comapny_acc_holder" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account No"
                                    id="edit_comapny_acc_no" name="comapny_acc_no" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter IFSC Code"
                                    id="edit_comapny_bank_ifsc" name="comapny_bank_ifsc" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="update_company_btn" onclick="EditvalidateForm()">Update Company</button>
                        </div>
                    </form>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal - Update Company-->


    <!--begin::Modal - View Company-->
    <div class="modal fade" id="kt_modal_view_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="mb-8">
                        <h3 class="mb-4 text-black text-center">View Company</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Company</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_companyname"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Company Type</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_companytype"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_emailid"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Website URL</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <a href="javascript:;" target="_blank" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"id="view_websitelink">
                                        <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_website">
                                        </div>
                                    </a>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Contact Person</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_contactperson"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">C.P. Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_cp_mobileno"></label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_address"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">GST No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_gstno"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="27AABCU9603R1ZV">
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">CIN No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_cinno"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                        title="U12345MH2005PTC123456">
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Pan No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_panno"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="AABCU9603R"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Description</label>
                        <label class="col-12 text-black fs-6 fw-bold" id="view_description">&emsp;&emsp;&emsp; </label>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Bank</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_bank"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Branch</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_branch"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">IFSC Code</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_ifsccode"></label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Account Holder</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_accountholder"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Account No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold text-truncate max-w-75" id="view_accountno"></label>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Company-->


    <!--begin::Modal - Delete Company-->
    <div class=" modal fade" id="kt_modal_delete_company" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                    <span id="delete_message"></span>
                    <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="submit" class="btn btn-danger me-3" 
                        onclick="deleteDepartmentCategory()">Yes, delete!</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Company-->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
    <script>
  document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
    el.addEventListener('click', function () {
      // Small delay to allow modal animation to finish
      setTimeout(() => {
        location.reload();
      }, 150);
    });
  });
</script>


    <script>
        function AddvalidateForm() {
            let isValid = 0;

            // Clear all previous errors
            document.querySelectorAll('.error_msg').forEach(div => {
                div.innerText = '';
            });

            // Helper to set error
            function setError(id, message) {
                document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
                isValid = 1;
            }

            // Required fields validation
            const requiredFields = [{
                    id: 'company_name',
                    name: 'Company Name'
                },
                {
                    id: 'company_type',
                    name: 'Company Type'
                },
                {
                    id: 'company_mail',
                    name: 'Email ID'
                },
                {
                    id: 'website_url',
                    name: 'Website URL'
                },
                {
                    id: 'ct_person',
                    name: 'Contact Person Name'
                },
                {
                    id: 'ct_per_mobile_no',
                    name: 'Contact Person Mobile No'
                },
                {
                    id: 'countryId',
                    name: 'Country'
                },
                {
                    id: 'stateId',
                    name: 'State'
                },
                {
                    id: 'cityId',
                    name: 'City'
                },
                {
                    id: 'area_street',
                    name: 'Area / Street'
                },
                {
                    id: 'door_flat_no',
                    name: 'Door/Flat No'
                },
                {
                    id: 'pincode',
                    name: 'Pincode'
                },
                {
                    id: 'gst_no',
                    name: 'GST No'
                },
                {
                    id: 'cin_no',
                    name: 'CIN No'
                },
                {
                    id: 'pan_no',
                    name: 'PAN No'
                },
                
                {
                    id: 'comapny_bank_name',
                    name: 'Bank Name'
                },
                {
                    id: 'comapny_bank_branch',
                    name: 'Bank Branch Name'
                },
                {
                    id: 'comapny_acc_holder',
                    name: 'Account Holder'
                },
                {
                    id: 'comapny_acc_no',
                    name: 'Account No'
                },
                {
                    id: 'comapny_bank_ifsc',
                    name: 'IFSC Code'
                }
            ];

            requiredFields.forEach(field => {
                const value = document.getElementById(field.id).value.trim();
                if (value === '') {
                    setError(field.id, `${field.name} is required.`);
                }
            });

            // Email format validation
            const email = document.getElementById('company_mail').value.trim();
            const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (email !== '' && !emailPattern.test(email)) {
                setError('company_mail', 'Enter a valid Email ID.');
            }

            // Mobile number format validation
            const mobile = document.getElementById('ct_per_mobile_no').value.trim();
            const mobilePattern = /^[6-9]\d{9}$/;
            if (mobile !== '' && !mobilePattern.test(mobile)) {
                setError('ct_per_mobile_no', 'Enter a valid 10-digit Mobile Number.');
            }

            const websiteUrl = document.getElementById('website_url').value.trim();
            const urlPattern = /^(https?:\/\/)?(www\.)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/[^\s]*)?$/i;

            if (websiteUrl !== '' && !urlPattern.test(websiteUrl)) {
                setError('website_url', 'Enter a valid Website URL (e.g., https://example.com or www.example.com)');
            }

            if (isValid == 0) {
                $('#add_form').submit();
            }
        }
    </script>

    <script>
        $(document).ready(function() {
            // Fetch and populate countries
            $.ajax({
                url: "{{ route('country') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('#countryId');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Country</option>');
                        response.data.forEach(function(country) {
                            countryDropdown.append($('<option></option>').attr('value', country
                                .id).text(country.name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });
            // Event listener for country change
            $('#countryId').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#stateId');
                var cityDropdown = $('#cityId');

                stateDropdown.empty().append('<option value="">Select State</option>');
                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('state') }}",
                        type: "GET",
                        data: {
                            country_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.id).text(state.name));
                                });
                            }
                            stateDropdown.val("").change();
                            cityDropdown.val("").change();
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });
            // Event listener for state change
            $('#stateId').on('change', function() {
                var stateId = $(this).val();
                var countryId = $('#countryId').val();
                var cityDropdown = $('#cityId');

                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId && stateId) {
                    // Fetch and populate cities based on selected state and country
                    $.ajax({
                        url: "{{ route('city') }}",
                        type: "GET",
                        data: {
                            country_id: countryId,
                            state_id: stateId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(city) {
                                    cityDropdown.append($('<option></option>').attr(
                                        'value', city.id).text(city.name));
                                });
                            }
                            cityDropdown.val("").change();
                        },
                        error: function(error) {
                            console.error('Error fetching cities:', error);
                        }
                    });
                }
            });
        });
    </script>
    <script>
        function updateDepartmentStatus(UniversityId, isChecked) {
            const status = isChecked ? 0 : 1; // Set status based on checkbox state

            fetch(`/company_status/${UniversityId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        console.log('Company status updated successfully:', data.message);
                        toastr.success('Company status Updated successfully!');
                    } else {
                        console.error('Error updating Company status:', data.message);
                        toastr.error('Error updating Company status');
                    }
                })
                .catch(error => {
                    console.error('Error updating Company status:', error);
                });
        }
    </script>
    <script>
        function confirmDelete(sno, name, id) {
            document.querySelector('#kt_modal_delete_company .btn-danger').setAttribute(
                'data-id', sno);
            $('#delete_message').html('Are you sure you want to delete <br> <b class="text-danger"> ' + name +
                '</b> Company ?');
        }

        function deleteDepartmentCategory() {

            var universityId = document.querySelector('#kt_modal_delete_company .btn-danger').getAttribute('data-id');

            fetch('/company_delete/' + universityId, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Company Deleted successfully!');
                        location.reload();

                    } else if(data.status === 302) {
                        toastr.error(data.message);
                        location.reload();
                        console.error(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        function viewmodel(id) {
            fetch('/company_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        console.error(data.data);
                        var com = data.data;
                        $('#view_companyname').html(com.company_name).attr('title', com.company_name);
                        $('#view_companytype').html(com.company_type_name + '(' + com.slug_name + ')'); //company_mail
                        $('#view_emailid').html(com.company_mail).attr('title', com.company_mail);
                        $('#view_website').html(com.company_website).attr('title', com.company_website).attr('href', com
                            .company_website);
                        $('#view_websitelink').attr('href', com.company_website); //company_ct_person//company_ct_number
                        $('#view_contactperson').html(com.company_ct_person).attr('title', com.company_ct_person);
                        $('#view_cp_mobileno').html(com.company_ct_number);
                        $('#view_address').html(
                                              (com.company_door_no || '') +', '+
                                              (com.company_area || '') +', '+
                                              (com.citiesname || '') +', '+
                                              (com.statename || '') +', '+
                                              (com.name || '')
                                            );
                        $('#view_description').html(com.company_desc);
                        $('#view_gstno').html(com.company_gst);
                        $('#view_cinno').html(com.company_cin);
                        $('#view_panno').html(com.company_pan);
                        $('#view_bank').html(com.company_bank_name);
                        $('#view_branch').html(com.company_bank_branch);
                        $('#view_accountholder').html(com.company_acc_holder);
                        $('#view_accountno').html(com.company_acc_no).attr('title', com.company_acc_no);
                        $('#view_ifsccode').html(com.company_ifsc);
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    </script>
    <script>
        function editmodel(id) {
            fetch('/company_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        console.error(data.data);
                        var com = data.data;
                        $('#edit_id').val(id);
                        $('#edit_company_name').val(com.company_name);
                        $('#edit_company_type').val(com.company_type).change();
                        $('#edit_company_mail').val(com.company_mail);
                        $('#edit_website_url').val(com.company_website);
                        $('#edit_ct_person').val(com.company_ct_person).attr('title', com.company_ct_person);
                        $('#edit_ct_per_mobile_no').val(com.company_ct_number);
                        // Fetch and populate countries
                        $.ajax({
                            url: "{{ route('country_ed_list') }}",
                            type: "GET",
                            success: function(response) {
                                if (response.status === 200 && response.data) {
                                    var countryDropdown = $('#edit_countryId');
                                    countryDropdown.empty();
                                    countryDropdown.append(
                                        '<option value="">Select Country</option>');
                                    response.data.forEach(function(country) {
                                        countryDropdown.append($('<option></option>')
                                            .attr('value', country.id).text(country
                                                .name));
                                    });
                                    countryDropdown.val(com.company_country).change();
                                }
                            },
                            error: function(error) {
                                console.error('Error fetching countries:', error);
                            }
                        });
                        // Event listener for country change
                        $('#edit_countryId').on('change', function() {
                            var countryId = $(this).val();
                            var stateDropdown = $('#edit_stateId');
                            var cityDropdown = $('#edit_cityId');

                            stateDropdown.empty().append('<option value="">Select State</option>');
                            cityDropdown.empty().append('<option value="">Select City</option>');

                            if (countryId) {
                                // Fetch and populate states based on selected country
                                $.ajax({
                                    url: "{{ route('state_ed_list') }}",
                                    type: "GET",
                                    data: {
                                        country_id: countryId
                                    },
                                    success: function(response) {
                                        if (response.status === 200 && response.data) {
                                            response.data.forEach(function(state) {
                                                stateDropdown.append($(
                                                        '<option></option>')
                                                    .attr(
                                                        'value', state.id)
                                                    .text(state.name));
                                            });
                                            stateDropdown.val(com.company_state).change();
                                        }
                                        
                                    },
                                    error: function(error) {
                                        console.error('Error fetching states:', error);
                                    }
                                });
                            }
                        });
                        // Event listener for state change
                        $('#edit_stateId').on('change', function() {
                            var stateId = $(this).val();
                            var countryId = $('#edit_countryId').val();
                            var cityDropdown = $('#edit_cityId');

                            cityDropdown.empty().append('<option value="">Select City</option>');

                            if (countryId && stateId) {
                                // Fetch and populate cities based on selected state and country
                                $.ajax({
                                    url: "{{ route('city_ed_list') }}",
                                    type: "GET",
                                    data: {
                                        country_id: countryId,
                                        state_id: stateId
                                    },
                                    success: function(response) {
                                        if (response.status === 200 && response.data) {
                                            response.data.forEach(function(city) {
                                                cityDropdown.append($(
                                                        '<option></option>')
                                                    .attr(
                                                        'value', city.id)
                                                    .text(city.name));
                                                cityDropdown.val(com
                                                        .company_city)
                                                    .change();
                                            });
                                        }
                                    },
                                    error: function(error) {
                                        console.error('Error fetching cities:', error);
                                    }
                                });
                            }
                        });
                        $('#edit_area_street').val(com.company_area);
                        $('#edit_door_flat_no').val(com.company_door_no);
                        $('#edit_pincode').val(com.company_pincode);
                        $('#edit_company_desc').val(com.company_desc);
                        $('#edit_gst_no').val(com.company_gst);
                        $('#edit_cin_no').val(com.company_cin);
                        $('#edit_pan_no').val(com.company_pan);
                        $('#edit_comapny_bank_name').val(com.company_bank_name);
                        $('#edit_comapny_bank_branch').val(com.company_bank_branch);
                        $('#edit_comapny_acc_holder').val(com.company_acc_holder);
                        $('#edit_comapny_acc_no').val(com.company_acc_no);
                        $('#edit_comapny_bank_ifsc').val(com.company_ifsc);
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    </script>
    <script>
        function EditvalidateForm() {
            let isValid = 0;

            // Clear all previous errors
            document.querySelectorAll('.error_msg').forEach(div => {
                div.innerText = '';
            });

            // Helper to set error
            function setError(id, message) {
                document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
                isValid = 1;
            }

            // Required fields validation
            const requiredFields = [{
                    id: 'edit_company_name',
                    name: 'Company Name'
                },
                {
                    id: 'edit_company_type',
                    name: 'Company Type'
                },
                {
                    id: 'edit_company_mail',
                    name: 'Email ID'
                },
                {
                    id: 'edit_website_url',
                    name: 'Website URL'
                },
                {
                    id: 'edit_ct_person',
                    name: 'Contact Person Name'
                },
                {
                    id: 'edit_ct_per_mobile_no',
                    name: 'Contact Person Mobile No'
                },
                {
                    id: 'edit_countryId',
                    name: 'Country'
                },
                {
                    id: 'edit_stateId',
                    name: 'State'
                },
                {
                    id: 'edit_cityId',
                    name: 'City'
                },
                {
                    id: 'edit_area_street',
                    name: 'Area / Street'
                },
                {
                    id: 'edit_door_flat_no',
                    name: 'Door/Flat No'
                },
                {
                    id: 'edit_pincode',
                    name: 'Pincode'
                },
                {
                    id: 'edit_gst_no',
                    name: 'GST No'
                },
                {
                    id: 'edit_cin_no',
                    name: 'CIN No'
                },
                {
                    id: 'edit_pan_no',
                    name: 'PAN No'
                },
                {
                    id: 'edit_comapny_bank_name',
                    name: 'Bank Name'
                },
                {
                    id: 'edit_comapny_bank_branch',
                    name: 'Bank Branch Name'
                },
                {
                    id: 'edit_comapny_acc_holder',
                    name: 'Account Holder'
                },
                {
                    id: 'edit_comapny_acc_no',
                    name: 'Account No'
                },
                {
                    id: 'edit_comapny_bank_ifsc',
                    name: 'IFSC Code'
                }
            ];

            requiredFields.forEach(field => {
                const value = document.getElementById(field.id).value.trim();
                if (value === '') {
                    setError(field.id, `${field.name} is required.`);
                }
            });

            // Email format validation
            const email = document.getElementById('company_mail').value.trim();
            if (email !== '' && !/^\S+@\S+\.\S+$/.test(email)) {
                setError('company_mail', 'Enter a valid Email ID.');
            }

            // Mobile number format validation
            const mobile = document.getElementById('ct_per_mobile_no').value.trim();
            const mobilePattern = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;

            if (mobile !== '' && !mobilePattern.test(mobile)) {
                setError('ct_per_mobile_no', 'Enter a valid 10-digit Mobile Number.');
            }

            if (isValid == 0) {
                $('#edit_form').submit();
            }
        }
    </script>


    <script>
        $(".list_page").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>

    <script>
        let debounceTimer;

        function debounce(func, delay) {
            return function() {
                const context = this;
                const args = arguments;
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => func.apply(context, args), delay);
            };
        }

        function checkUniqueField(field, value, errorElementId, submitButtonId) {
            if (value === '') {
                $('#' + errorElementId).text('');
                return;
            }

            let sno = $('#edit_id').val() || null;

            $.ajax({
                url: '/check_duplicates_company',
                method: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    field: field,
                    value: value,
                    sno: sno
                },
                success: function(response) {
                    if (response.exists) {
                        $('#' + errorElementId).text(response.message);
                        $('#' + submitButtonId).prop('disabled', true);
                    } else {
                        $('#' + errorElementId).text('');
                        $('#' + submitButtonId).prop('disabled', false);
                    }
                }
            });
        }

        // Bind with debounce
        $('#company_name').on('input', debounce(function() {
            checkUniqueField('company_name', $(this).val(), 'company_name_err', 'company_create_btn');
        }, 600));

        $('#edit_company_name').on('input', debounce(function() {
            checkUniqueField('company_name', $(this).val(), 'edit_company_name_err', 'update_company_btn');
        }, 600));

    </script>
@endsection
