@extends('layouts/layoutMaster')

@section('title', 'Manage Training')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')
<style>
    .dataTables_scroll {
        position: relative;
        overflow: auto;
        min-height: 250px;
        max-height: 250px;
        /*the maximum height you want to achieve*/
        width: 100%;
    }

    .dataTables_scroll thead {
        position: -webkit-sticky;
        position: sticky;
        top: 0;
        background-color: #fff;
        z-index: 2;
    }
</style>

<!-- Lead List Table -->
<div class="card">
    @php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    @endphp
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Training</h5>
        <div class="row">
            <div class="col-xl-6">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:void(0);" class="d-flex align-items-center">Branch Management</a>
                    </li>
                </ol>
            </nav>
            </div>
            <div class="col-xl-6">
                <div class="d-flex justify-content-end align-items-center flex-wrap">
                     <a href="javascript:;" class="btn btn-primary btn-sm py-1 px-3 mb-2" title="" id="lead_slow_mo">
                        <i class="mdi mdi-arrow-expand-vertical fs-5"></i>
                    </a>
                </div>
            </div>
       </div>
    </div>
    <div class="card-body">
        <div class="col-xl-12">
            <div class="card-body pt-0">
                <div class="lead_tbox" style="display:none;">
                    <div class="row">
                        <div class="col-lg-6 d-flex flex-wrap align-items-center mb-2 gap-2">
                            <!-- <div class="row"> -->
                            <a href="#" class="text-center border border-2 p-2 mb-2" style="height: 150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Number of Leads">
                                <div class="fw-semibold fs-6 text-black text-center">Total Training</div>
                                <div class="fw-semibold fs-6 text-black text-center">
                                    <label class="fs-8">Upto</label>
                                    <label>(<?php echo date("M"); ?>)</label>
                                </div>
                                <div>
                                    <svg height="50px" width="50px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
                                    viewBox="0 0 502.665 502.665" xml:space="preserve">
                                        <g>
                                            <g>
                                                <g>
                                                    <path style="fill:#010002;" d="M466.965,41.006H275.783c2.092-3.926,3.581-8.197,3.581-12.964C279.364,12.554,266.81,0,251.322,0
                                                        S223.28,12.554,223.28,28.042c0,4.767,1.488,9.017,3.581,12.964H35.744c-14.237,0-25.799,11.605-25.799,25.799v284.389
                                                        c0,14.194,11.562,25.82,25.777,25.82h156.28l-30.35,107.056c-2.114,7.42,2.351,14.668,9.944,16.049l12.08,2.308
                                                        c7.593,1.402,15.509-3.516,17.602-10.893l32.486-114.541h35.16l32.507,114.519c2.071,7.399,10.03,12.317,17.602,10.893
                                                        l12.015-2.308c7.593-1.381,12.058-8.628,9.944-16.049l-30.35-107.034h156.323c14.15,0,25.755-11.627,25.755-25.82V66.805
                                                        C492.721,52.633,481.137,41.006,466.965,41.006z M443.647,326.711H58.975V85.981h384.672V326.711z"/>
                                                    <path style="fill:#010002;" d="M104.317,286.309c11.044,0,19.996-8.952,19.996-19.996c0-2.006-0.582-3.818-1.143-5.63
                                                        c25.54-20.6,70.687-56.925,91.244-72.758c3.257,2.286,7.01,3.926,11.282,3.926c3.538,0,6.687-1.165,9.577-2.783
                                                        c13.223,11.238,35.7,30.35,51.684,43.918c-0.216,1.143-0.69,2.2-0.69,3.408c0,11.066,8.973,20.018,20.018,20.018
                                                        c11.087,0,20.039-8.952,20.039-20.018c0-1.963-0.582-3.732-1.122-5.522l51.662-46.614c2.783,1.445,5.803,2.481,9.146,2.481
                                                        c11.044,0,19.975-8.952,19.975-19.996c0-11.023-8.93-19.975-19.975-19.975c-11.044,0-19.975,8.952-19.975,19.975
                                                        c0,2.632,0.561,5.112,1.488,7.42c-14.431,13.029-36.713,33.133-50.605,45.687c-3.128-2.006-6.644-3.494-10.634-3.494
                                                        c-4.702,0-8.844,1.877-12.252,4.595c-13.201-11.217-34.535-29.336-49.721-42.236c0.798-2.157,1.381-4.422,1.381-6.838
                                                        c0-11.044-8.952-19.975-19.975-19.975s-19.996,8.952-19.996,19.996c0,2.438,0.582,4.702,1.381,6.838l-91.719,71.356
                                                        c-3.192-2.2-6.881-3.775-11.066-3.775c-11.044,0-19.996,8.952-19.996,19.996C84.321,277.357,93.273,286.309,104.317,286.309z"/>
                                                </g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                            <g>
                                            </g>
                                        </g>
                                    </svg>
                                </div>
                                <div class="d-block mt-2">
                                    <div class="badge bg-primary rounded fw-bold fs-6">{{ sprintf('%02d', $totalTraining) }} </div>
                                </div>
                            </a>
                            <a href="#" class="text-center border border-2 p-2 mb-2" style="height: 150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Current Month Leads">
                                <div class="fw-semibold fs-6 text-black text-center">No of Training</div>
                                <div class="fw-semibold fs-6 text-black text-center">(<?php echo date("M"); ?>)</div>
                                <div>
                                    <svg width="50px" height="50px" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M5 4H4V5V30V31H5H30V29H6V6H35V10H37V5V4H36H5ZM36 17C37.6569 17 39 15.6569 39 14C39 12.3431 37.6569 11 36 11C34.3431 11 33 12.3431 33 14C33 15.6569 34.3431 17 36 17ZM33.9133 19.0088C33.8767 19.0088 33.8404 19.0094 33.8043 19.0107H32C31.5443 19.0107 31.1134 19.2179 30.8287 19.5737L27.2791 24.0107H22C21.1716 24.0107 20.5 24.6823 20.5 25.5107C20.5 26.3392 21.1716 27.0107 22 27.0107H28C28.4557 27.0107 28.8866 26.8036 29.1713 26.4478L31.0831 24.058V41.8928C31.0831 42.7918 31.8187 43.5274 32.7177 43.5274C33.6167 43.5274 34.3523 42.7918 34.3523 41.8928V33.72H37.6214V41.8928C37.6214 42.7918 38.357 43.5274 39.256 43.5274C40.155 43.5274 40.8906 42.7918 40.8906 41.8928V29.7442C41.7896 29.7442 44.5656 28.033 44.5656 23.8193C44.5656 20.6434 41.7896 19.0088 40.8906 19.0088H33.9133Z" fill="#333333"/>
                                    </svg>
                                </div>
                                <div class="d-block mt-2">
                                    <div class="badge bg-primary rounded fw-bold fs-6">{{ sprintf('%02d', $totalTrainingMonth) }}</div>
                                </div>
                            </a>
                            <!-- </div> -->
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-12 d-flex justify-content-end align-items-center flex-wrap gap-2 mb-2">
                <!--************FilterButton*****************-->
                <!--@ if(auth()->user()->hasPermission('Branch Management', 'Add Training', 'Manage Training'))-->
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                    data-bs-target="#kt_modal_add_training_planner">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Training
                </a>
                <!--@ endif-->
            </div>
            {{-- <div class="col-lg-12 training_filter mb-4" style="display: none;">
                <form id="filter_form" method="POST" action="{{ route('training_filter') }}">
                    @csrf
                    <div class="row py-1">
                        <div class="col-lg-3 mb-1">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Training Planner</label>
                            <input type="text" class="form-control" id="training_name_fill" name="training_name_fill"
                                placeholder="Enter Training Planner Name" value="{{ $training_name_fill ?? '' }}" />
                        </div>
                        < ?php
                            // Ensure $training_mode_fill is an array
                            if (!is_array($training_mode_fill)) {
                                $training_mode_fill = explode(',', $training_mode_fill);
                            }
                            ?>
                        <div class="col-lg-3 mb-1">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Training Mode</label>
                            <select id="training_mode_fill" name="training_mode_fill[]" class="select3 form-select" multiple>
                                <option value="">Select Training Mode</option>
                                <option value="0" @if(in_array(0, $training_mode_fill)) selected @endif>All</option>
                                <option value="1" @if(in_array(1, $training_mode_fill)) selected @endif>Online</option>
                                <option value="2" @if(in_array(2, $training_mode_fill)) selected @endif>Offline</option>
                                <option value="3" @if(in_array(3, $training_mode_fill)) selected @endif>Video</option>
                            </select>
                        </div>
                        <div class="col-lg-3 mb-1">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Trainer</label>
                            @php
                            $branchId = $trainer_branch_id;
                            $get_staff_list = $helper->get_branch_staff_list($branchId);
                            // echo $get_staff_list
                            @endphp
                            <select id="trainer_fill" name="trainer_fill" class="select3 form-select">
                                <option value="">Select Trainer</option>
                                @foreach ($get_staff_list as $dp_list)
                                <option value="{{ $dp_list->sno }}" @if($dp_list->sno== $trainer_fill) selected @endif>{{
                                    $dp_list->staff_name }}</option>
                                @endforeach
                                <option value="0">Others</option>
                            </select>
                        </div>
                        <div class="col-lg-3 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                            <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                                <option value="all" @if($date_filter =="all") selected @endif>All</option>
                                <option value="today"  @if($date_filter =="today")selected @endif>Today</option>
                                <option value="week"  @if($date_filter =="week") selected @endif>This Week</option>
                                <option value="monthly"  @if($date_filter =="monthly") selected @endif>This Month</option>
                                <option value="custom_date"  @if($date_filter =="custom_date") selected @endif>Custom Date</option>
                            </select>
                        </div>
                        <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="acc_daily_acc_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="acc_daily_acc_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="acc_daily_acc_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="acc_daily_acc_month_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("M-Y"); ?>" />
                            </div>
                        </div>
                        <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="acc_daily_from_dt_fill" readonly name="from_date_fillter_textbox" placeholder="Select Date" class="form-control common_date_class" value="<?php echo date("d-M-Y"); ?>" />
                            </div>
                        </div>
                        <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="acc_daily_to_dt_fill" readonly name="to_date_fillter_textbox" placeholder="Select Date" class="form-control common_date_class" value="<?php echo date("d-M-Y"); ?>" />
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end">
                        <a href="{{ url('/training_planner') }}" type="button"
                            class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6">Go</button>
                    </div>
                </form>
            </div> --}}
            <div class="d-flex align-items-center justify-content-between">
                <div class="mb-4">
                    @php $perpage_count = $perpage ? $perpage : 25; @endphp
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                            <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                            @php echo $option; @endphp
                            </option>
                        @php endforeach; @endphp
                        </select>
                    </div>
                </div>
                <div class="mb-4">
                    <form id="search_form" method="POST" action="/training_filter">
                    @csrf
                    <div class="d-flex align-items-center gap-2">
                    <div class="mb-1">
                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                        <input type="hidden" name="filter_on" value="1">
                        <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                        <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                        <input
                        type="text"
                        class="form-control"
                        id="training_pl_fill" name="training_pl_fill" value="{{ $training_pl_fill ?? "" }}"
                        placeholder="Enter Plannner - Name/ Date/ Trainer"
                        />
                    </div>
                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" onclick="search_filter_func()">Search</button>
                    </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-12">
                
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-100px">
                                <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Schedule Date">Date</span> / <span>Duration</span>
                            </th>
                            <th class="min-w-100px">Training Planner</th>
                            <th class="min-w-100px">Trainer / Mode</th>
                            <th class="min-w-100px">Staff</th>
                            <th class="min-w-150px">Branch / Franchise</th>
                            <th class="min-w-50px">Status</th>
                            <th class="min-w-50px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        @if (isset($t_list))
                        @foreach ($t_list as $list)
                        <tr>
                            <td>
                                <label>
                                    {{ date('d-M-Y', strtotime($list['schedule_date'])) }}

                                </label>
                                <label>
                                    {{ date('H:i:A', strtotime($list['schedule_time'])) }}

                                </label>
                                <div class="d-block">
                                    <label class="badge bg-primary fw-semibold fs-8">{{ $list['training_duration'] }}
                                        Hrs</label>
                                </div>
                            </td>
                            <td>
                                <label class="text-truncate max-w-150px" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="{{ $list['training_planner_name'] }}">{{
                                    $list['training_planner_name'] }}</label>
                                    <label class="d-block">
                                        @if($list['attendance_status'] != null)
                                        <span class="badge bg-success fs-8">Completed</span>
                                        @endif
                                        @if($list['attendance_status'] == null)
                                        <span class="badge bg-warning fs-8 text-black">Not yet Started</span>
                                        @endif
                                    </label>
                            </td>
                            <td>
                                @php
                                $get_staff_list = $helper->get_staff_data($list['trainer']);
                                @endphp
                                @if($list['trainer'] > 0)
                                @php
                                $tra_staff_name = $get_staff_list->staff_name ?? '-';
                                @endphp
                                <label class="text-truncate max-w-150px" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="{{ $get_staff_list->staff_name ?? '-'}}">
                                    {{ $get_staff_list->staff_name ?? '-'}}
                                </label>
                                @elseif($list['trainer'] == 0)
                                @php
                                $tra_staff_name = $list['trainer_name'] ?? '-';
                                @endphp
                                <label class="text-truncate max-w-150px" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="{{ $list['trainer_name']}}">
                                    {{ $list['trainer_name']}}
                                </label>
                                @endif
                                @if($list['training_mode'] == 1)
                                <div class="d-block">
                                    <label class="badge bg-warning fs-8 rounded text-black fw-bold">Online</label>
                                </div>
                                @elseif($list['training_mode'] == 2)
                                <div class="d-block">
                                    <label class="badge bg-warning fs-8 rounded text-black fw-bold">Offline</label>
                                </div>
                                @elseif($list['training_mode'] == 3)
                                <div class="d-block">
                                    <label class="badge bg-warning fs-8 rounded text-black fw-bold">Video</label>
                                </div>
                                @endif
                            </td>
                            <td>
                                <label class="badge bg-info fw-semibold fs-6" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Total">
                                    @php
                                    $staffCheckArray = json_decode($list->staff_check, true);
                                    if (is_array($staffCheckArray)) {
                                    echo count($staffCheckArray);
                                    }else{
                                    echo '-';
                                    }
                                    @endphp
                                </label>
                                @if($list->attendance_status != null)
                                <label class="badge bg-success fw-semibold fs-6 pre_abs_view" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Present">
                                    @php
                                    $attendanceArray = json_decode($list->attendance_status, true);
                                    $presentCount = 0;
                                    $absentCount = 0;
                                    if (is_array($attendanceArray)) {
                                    foreach ($attendanceArray as $attendance) {
                                    if (isset($attendance['attendance'])) {
                                    if ($attendance['attendance'] == 0) {
                                    $presentCount++;
                                    } elseif ($attendance['attendance'] == 1) {
                                    $absentCount++;
                                    }}}
                                    }
                                    echo $presentCount;
                                    @endphp
                                </label>
                                <label class="badge bg-danger fw-semibold fs-6" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Absent">
                                    @php
                                    echo $absentCount;
                                    @endphp
                                </label>
                                @endif
                            </td>
                            <td>
                                @php
                                // Get the branch_id from the list and decode it (assuming it's stored as JSON)
                                $branch_id = $list['branch_id'] ?? '[]';
                                $branch_ids = json_decode($branch_id);
                                
                                // Call the helper function to get branch names or franchise names
                                $branch_names = [];
                                foreach ($branch_ids as $id) {
                                    $branch_name = $helper->branch_franchise($id);
                                    
                                    // If branch_name is available, use it; otherwise, use franchise_name
                                    if ($branch_name) {
                                        $branch_names[] = $branch_name;
                                    } else {
                                        $franchise_name = $helper->branch_franchise($id); // Assuming you have a function to get the franchise name
                                        $branch_names[] = $franchise_name;
                                    }
                                }
                            
                                // Combine all branch names (or franchise names) into a string
                                $branch_name_display = implode(', ', $branch_names);
                                @endphp
                            
                                <div class="d-flex align-items-center">
                                    <label class="text-truncate max-w-80px me-1">{{ $branch_name_display }}</label>
                                    <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $branch_name_display }}">
                                        <span class="mdi mdi-information-slab-circle"></span>
                                    </a>
                                </div>
                            </td>                                                                                                                                                                                                                                                                                                                   
                            <td>
                                
                                @if($list['attendance_status'] != null)
                               <button type="button" class="btn btn-icon me-2 btn-outline-success">
                                  <span class="mdi mdi-check-circle fs-4"></span>
                                </button>
                                @else
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" {{ $list['status']==0 ? 'checked' : ''
                                        }} onchange="updatelevelStatus('{{ $list['sno'] }}', this.checked)" />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                                @endif
                            </td>
                            <td>
                                <span class="text-end">
                                    <!--@ if(auth()->user()->hasPermission('Branch Management', 'Attendance', 'Manage Training'))-->
                                        @if(date('Y-m-d', strtotime($list['schedule_date'])) == date('Y-m-d'))
                                            @if($list['attendance_status'] == null)
                                                <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal"
                                                   data-bs-target="#kt_modal_complete_training_planner"
                                                   onclick="completeTraining('{{ $list['sno'] }}', '{{ $list['training_planner_name'] }}', '{{ $list['training_mode'] }}', '{{ $list['trainer'] }}', '{{ $list['trainer_name'] }}', '{{ $list['training_duration'] }}', '{{ $list['schedule_date'] }}', '{{ $list['training_desc'] }}', '{{ $tra_staff_name }}', '{{ $list['branch_id'] }}')">
                                                    <i class="mdi mdi-clipboard-account-outline fs-3 text-black"
                                                       data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                       title="Complete the Training"></i>
                                                </a>
                                            @endif
                                        @endif
                                    <!--@ endif-->
                                    <!--@ if(auth()->user()->hasPermission('Branch Management', 'View', 'Manage Training'))-->
                                    <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_view_training_planner"
                                        onclick="openViewModal('{{ $list['sno'] }}', '{{ $list['training_planner_name'] }}', '{{ $list['training_mode'] }}', '{{ $list['trainer'] }}', '{{ $list['trainer_name'] }}', '{{ $list['training_duration'] }}', '{{ $list['schedule_date'] }}', '{{ $list['training_desc'] }}', '{{ $tra_staff_name  }}', '{{ $list['attendance_status'] }}', '{{ $list['branch_id'] }}')">
                                        <i class="mdi mdi-eye-outline fs-3 text-black" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="View"></i>
                                    </a>
                                    <!--@ endif-->

                                    @if(date('Y-m-d', strtotime($list['schedule_date'])) >= date('Y-m-d'))
                                        @if($list['attendance_status'] == null)
                                        <!--@ if(auth()->user()->hasPermission('Branch Management', 'Edit', 'Manage Training'))-->
                                        <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_edit_training_planner"
                                            onclick="openEditModal('{{ $list['sno'] }}')">
                                            <i class="mdi mdi-square-edit-outline fs-3 text-black" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Edit"></i>
                                        </a>
                                        <!--@ endif-->
                                        <!--@ if(auth()->user()->hasPermission('Branch Management', 'Delete', 'Manage Training'))-->
                                        <a href="javascript:;"
                                            onclick="confirmDelete('{{ $list['sno'] }}', '{{ $list['training_planner_name'] }}', '{{ $list['training_planner_id'] }}')"
                                            class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_delete_training_planner">
                                            <i class="mdi mdi-delete-outline fs-3 text-black" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Delete"></i>
                                        </a>
                                        <!--@ endif-->
                                        @endif
                                    @endif
                                </span>
                            </td>
                        </tr>
                        @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $t_list->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Create Training Planner-->
<div class="modal fade" id="kt_modal_add_training_planner" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class="mb-4 text-black text-center">Create Training</h3>
                </div>
                <form id="addTrainingForm" action="{{ route('add_training') }}" method="POST" novalidate>
                    @csrf
                    <div class="row">
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                            <select id="branch_name" name="branch_name[]" class="select3 form-select" multiple data-placeholder="Select Branch" data-parent-dropdown="#kt_modal_add_training_planner" onchange="updateTrainerOptions()">
                                @if($branch)
                                    @foreach($branch as $b_list)
                                        <option value="{{ $b_list->sno }}" @if(auth()->user()->branch_id == $b_list->sno) selected @endif >
                                            @if($b_list->branch_type == 1)
                                                {{ $b_list->branch_name }} <!-- Display branch_name if branch_type == 1 -->
                                            @elseif($b_list->branch_type == 2)
                                                {{ $b_list->franchise_name }} <!-- Display franchise_name if branch_type == 2 -->
                                            @endif
                                        </option>
                                    @endforeach
                                @endif
                            </select>
                            <div class="text-danger" id="branch_name_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Training Planner Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="training_planner_name"
                                name="training_planner_name" placeholder="Enter Training Planner Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"/>
                            <div class="text-danger" id="training_planner_name_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                            <select class="select3 form-select" name="department_add" id="department_add" onchange="updateTrainerOptions()">
                                <option value="">Select Department</option>
                            </select>
                            <div class="text-danger" id="department_add_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Training Mode<span
                                    class="text-danger">*</span></label>
                            <select id="training_mode" name="training_mode" class="select3 form-select">
                                <option value="">Select Training Mode </option>
                                <option value="1">Online</option>
                                <option value="2">Offline</option>
                                <option value="3">Video</option>
                            </select>
                            <div class="text-danger" id="training_mode_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Trainer<span class="text-danger">*</span></label>
                            <select class="select3 form-select" name="trainer" id="trainer" data-parent-dropdown="kt_modal_add_training_planner" onchange="trainer_func()">
                                <option value="">Select Trainer</option>
                            </select>
                            <div class="text-danger" id="trainer_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2" id="tra_others" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Trainer Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="trainer_name" name="trainer_name" placeholder="Enter Trainer Name" />
                            <div class="text-danger" id="trainer_name_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Duration (In Hours)<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="duration" name="duration"
                                placeholder="Enter Duration (In Hours)" maxlength="2" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                            <div class="text-danger" id="duration_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Schedule Date<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="training_planner_sch_dt_add" name="training_planner_sch_dt_add"
                                    placeholder="Select Date" class="form-control" value="" />
                            </div>
                            <div class="text-danger" id="training_planner_sch_dt_add_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Schedule Time<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="training_planner_sch_time_add" name="training_planner_sch_time_add"
                                    placeholder="Select Time" class="form-control" value="" />
                            </div>
                            <div class="text-danger" id="training_planner_sch_time_add_err"></div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" id="training_desc" name="training_desc"
                                placeholder="Enter Description"></textarea>
                            {{-- <div class="text-danger" id="training_desc_err"></div> --}}
                        </div>
                        <div class="col-lg-12 mb-2 scroll-y max-h-150px">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2"
                                id="staffTable">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-25px">
                                            <div class="d-block">
                                                <input class="form-check-input fs-6 border-white" type="checkbox"
                                                    id="staff_list_add" name="staff_list_add" />
                                                <label class="fw-semibold">All</label>
                                            </div>
                                        </th>
                                        <th class="min-w-100px">Staff</th>
                                        <th class="min-w-100px">Department</th>
                                        <th class="min-w-100px">Job Role</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7" id="staffTableBody">

                                </tbody>
                            </table>
                            <div class="text-danger" id="check_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mb-2 mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="add_training_submit" class="btn btn-primary"
                            onclick="AddvalidateForm_training()">Create Training</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Training Planner-->


<!--begin::Modal - Update Training Planner-->
<div class="modal fade" id="kt_modal_edit_training_planner" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">Update Training</h3>
                </div>
                <form id="editTrainingForm" action="{{ route('update_training') }}" method="POST" novalidate>
                    @csrf
                    <div class="row">
                        <input type="hidden" id="training_planner_id_edit" name="training_planner_id_edit" />
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                            <select id="branch_name_edit" name="branch_name_edit[]" class="select3 form-select" multiple data-placeholder="Select Branch" data-parent-dropdown="#kt_modal_edit_training_planner" onchange="updateTrainerOptionsEdit()">
                                @if($branch)
                                    @foreach($branch as $b_list)
                                        <option value="{{ $b_list->sno }}">
                                            @if($b_list->branch_type == 1)
                                                {{ $b_list->branch_name }} <!-- Display branch_name if branch_type == 1 -->
                                            @elseif($b_list->branch_type == 2)
                                                {{ $b_list->franchise_name }} <!-- Display franchise_name if branch_type == 2 -->
                                            @endif
                                        </option>
                                    @endforeach
                                @endif
                            </select>
                            <div class="text-danger" id="branch_name_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Training Planner Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="training_planner_name_edit"
                                name="training_planner_name" placeholder="Enter Training Planner Name" />
                            <div class="text-danger" id="training_planner_name_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                            <select class="select3 form-select" name="department_edit" id="department_edit" onchange="updateTrainerOptionsEdit()">
                                <option value="">Select Department</option>
                            </select>
                            <div class="text-danger" id="department_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Training Mode<span
                                    class="text-danger">*</span></label>
                            <select id="training_mode_edit" name="training_mode_edit" class="select3 form-select">
                                <option value="">Select Training Mode </option>
                                <option value="1">Online</option>
                                <option value="2">Offline</option>
                                <option value="3">Video</option>
                            </select>
                            <div class="text-danger" id="training_mode_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Trainer<span
                                    class="text-danger">*</span></label>
                           
                            <select class="select3 form-select" name="trainer" id="trainer_edit"
                                data-parent-dropdown="kt_modal_edit_training_planner" onchange="TableGet()">
                                <option value="">Select Trainer</option>
                            </select>
                            <div class="text-danger" id="trainer_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2" id="tra_others_edit" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Trainer Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="trainer_name_edit" name="trainer_name"
                                placeholder="Enter Trainer Name" />
                            <div class="text-danger" id="trainer_name_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Duration (In Hours)<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="duration_edit" name="duration"
                                placeholder="Enter Duration (In Hours)" maxlength="2"
                                oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                            <div id="duration_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Schedule Date<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="training_planner_sch_dt_edit" name="training_planner_sch_dt_edit"
                                    placeholder="Select Date" class="form-control" value="" />
                            </div>
                            <div class="text-danger" id="training_planner_sch_dt_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Schedule Time<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="training_planner_sch_time_edit" name="training_planner_sch_time_edit"
                                    placeholder="Select Time" class="form-control" value="" />
                            </div>
                            <div class="text-danger" id="training_planner_sch_time_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1" id="training_desc_edit" name="training_desc"
                                placeholder="Enter Description"></textarea>
                            {{-- <div class="text-danger" id="training_desc_err"></div> --}}
                        </div>
                        <div class="col-lg-12 mb-2 scroll-y max-h-150px">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2"
                                id="staffTableEdit">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-25px">
                                            <div class="d-block">
                                                <input class="form-check-input fs-6 border-white" type="checkbox"
                                                    id="staff_list_edit" name="staff_list_edit" />
                                                <label class="fw-semibold">All</label>
                                            </div>
                                        </th>
                                        <th class="min-w-100px">Staff</th>
                                        <th class="min-w-100px">Department</th>
                                        <th class="min-w-100px">Job Role</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7" id="staffTableBodyEdit">

                                </tbody>
                            </table>
                            <div class="text-danger" id="check_edit_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mb-2 mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="edit_training_submit" class="btn btn-primary"
                            onclick=" EditvalidateForm_training()">Update
                            Training</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Training Planner-->


<!--begin::Modal - Complete Training Planner-->
<div class="modal fade" id="kt_modal_complete_training_planner" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">Training Planner</h3>
                </div>
                {{-- <form id="completeTrainingForm"> --}}
                    <div class="row">
                        <div class="col-lg-6">
                            <input type="hidden" id="training_complete_id" name="training_complete_id" />
                            <div class="row mb-4">
                                <label class="col-3 text-dark fs-7 fw-semibold">Training Planner</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-8 text-dark fs-6 fw-bold" id="training_complete"
                                    name="training_complete"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-3 text-dark fs-7 fw-semibold">Training Mode</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-8 text-dark fs-6 fw-bold" id="training_mode_complete"
                                    name="training_mode_complete"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-3 text-dark fs-7 fw-semibold">Branch Name</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-8 text-dark fs-6 fw-bold" id="branch_name_complete"
                                    name="branch_name_complete"></label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-3 text-dark fs-7 fw-semibold">Trainer</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-8 text-dark fs-6 fw-bold" id="trainer_complete"
                                    name="trainer_complete"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-3 text-dark fs-7 fw-semibold">Duration</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-8 text-dark fs-6 fw-bold" id="duration_complete"
                                    name="duration_complete"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-3 text-dark fs-7 fw-semibold">Schedule Date</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-8 text-dark fs-6 fw-bold" id="date_complete"
                                    name="date_complete"></label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <label class="text-dark fs-7 fw-semibold">Description</label>
                            <div class="d-block text-dark fs-6 fw-bold" id="training_desc_complete"
                                name="training_desc_complete">&emsp;&emsp;-</div>
                        </div>
                        <div class="col-lg-12 mb-2">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page_empty">
                                <thead>
                                    <tr class="text-white align-top fw-bold fs-6 gs-0 bg-danger">
                                        <th class="text-center" colspan="4">*Select Only Absent Staffs (All Remaining
                                            Staffs
                                            are Present)</th>
                                    </tr>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-25px">
                                            <div class="d-block">
                                                <input class="form-check-input fs-6 border-white" type="checkbox"
                                                    id="staff_list_complete" />
                                                <label class="fw-semibold">All</label>
                                            </div>
                                        </th>
                                        <th class="min-w-100px">Staff</th>
                                        <th class="min-w-100px">Department</th>
                                        <th class="min-w-100px">Job Role</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7" id="attendanceTableBody">

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mb-2 mt-2">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="submit_complete">Completed Training</button>
                    </div>
                    {{--
                </form> --}}
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Complete Training Planner-->


<!--begin::Modal - View Training Planner-->
<div class="modal fade" id="kt_modal_view_training_planner" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">View Training Planner</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <input type="hidden" id="training_planner_id" name="training_planner_id" />
                        <div class="row mb-4">
                            <label class="col-3 text-dark fs-7 fw-semibold">Training Planner</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-8 text-dark fs-6 fw-bold" id="training_planner_view"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-3 text-dark fs-7 fw-semibold">Training Mode</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-8 text-dark fs-6 fw-bold" id="training_mode_view"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-3 text-dark fs-7 fw-semibold">Branch Name</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-8 text-dark fs-6 fw-bold" id="branch_name_view"
                                name="branch_name_view"></label>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row mb-4">
                            <label class="col-3 text-dark fs-7 fw-semibold">Trainer</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-8 text-dark fs-6 fw-bold" id="trainer_view"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-3 text-dark fs-7 fw-semibold">Duration</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-8 text-dark fs-6 fw-bold" id="duration_view"> Hrs</label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-3 text-dark fs-7 fw-semibold">Schedule Date</label>
                            <label class="col-1 text-dark fs-6 fw-bold">:</label>
                            <label class="col-8 text-dark fs-6 fw-bold" id="schedule_date_view"></label>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <label class="text-dark fs-7 fw-semibold">Description</label>
                        <div class="d-block text-dark fs-6 fw-bold" id="training_desc_view">&emsp;&emsp;-</div>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <table
                            class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page_empty">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-100px">Staff</th>
                                    <th class="min-w-100px">Department</th>
                                    <th class="min-w-100px">Job Role</th>
                                    <th class="min-w-100px">Attendance</th>
                                </tr>
                            </thead>
                            <tbody class="text-gray-600 fw-semibold fs-7" id="viewTableBody">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Training Planner-->


<!--begin::Modal - Delete Training Planner-->
<div class=" modal fade" id="kt_modal_delete_training_planner" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                <label id="delete_message"></label>

            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="button" class="btn btn-danger me-3" onclick="deleteTraining()">Yes,
                    delete!</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, cancel</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Training Planner-->




<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
</style>


<script>
    // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Date picker only
        flatpickr("#training_planner_sch_dt_add", {
            dateFormat: "d-M-Y", // e.g., 12-Jul-2025
            enableTime: false
        });

        // Time picker only
        flatpickr("#training_planner_sch_time_add", {
            enableTime: true,
            noCalendar: true,
            dateFormat: "h:i K", // e.g., 04:30 PM
            time_24hr: false
        });
        
        flatpickr("#training_planner_sch_dt_edit", {
            dateFormat: "d-M-Y", // e.g., 12-Jul-2025
            enableTime: false
        });

        // Time picker only
        flatpickr("#training_planner_sch_time_edit", {
            enableTime: true,
            noCalendar: true,
            dateFormat: "h:i K", // e.g., 04:30 PM
            time_24hr: false
        });
    });
</script>


{{-- status --}}
<script>
    function updatelevelStatus(TypeId, isChecked) {
                const status = isChecked ? 0 : 1;
                fetch(`/training_status/${TypeId}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                        },
                        body: JSON.stringify({
                            status: status
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 200) {
                            toastr.success('Training Palnner status Updated successfully!');
                        }
                    })
                    .catch(error => {});
            }
</script>
{{-- status --}}


{{-- delete --}}
<script>
    function confirmDelete(id, name, ids) {
                document.querySelector('#kt_modal_delete_training_planner .btn-danger').setAttribute('data-id', id);
                $('#delete_message').html(
                    'Are you sure you want to delete Training Planner<br> <b class="text-danger fw-bold fs-4">' +
                    name +
                    '</b> ?');
            }

            function deleteTraining() {
                var categoryId = document.querySelector('#kt_modal_delete_training_planner .btn-danger').getAttribute('data-id');

                fetch('/training_delete/' + categoryId, {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 200) {
                            toastr.success(data.message);
                            location.reload();
                        } else {
                            toastr.error(data.error_msg);
                        }
                    })
                    .catch(error => {

                    });
            }
</script>
{{-- delete --}}


{{-- add --}}
<script>
updateTrainerOptions()
    // Combined function to update trainer options and handle trainer selection
    function updateTrainerOptions() {
        var selectedBranchIds = $("#branch_name").val();  // Get the selected branch IDs
        var selectedDepartment = $("#department_add").val(); // Get selected department
        
        if (selectedBranchIds && selectedBranchIds.length > 0 && selectedDepartment) {
            // Make an AJAX call to fetch the staff list based on the selected branch IDs
            $.ajax({
                url: '{{ route("get_branch_staff") }}',  // Adjust the route to match your backend endpoint
                method: 'GET',
                data: {
                    branch_ids: selectedBranchIds ,
                    department_id: selectedDepartment
                },
                success: function(response) {
                    // Empty the current trainer dropdown
                    $('#trainer').empty().append('<option value="">Select Trainer</option><option value="0">Others</option>');
                    console.log(response);
                    // Populate the trainer dropdown with the response data
                    response.staff_list.forEach(function(staff) {
                        if(staff.sno > 1){
                            $('#trainer').append('<option value="' + staff.sno + '">' + staff.staff_name + '</option>');
                        }
                    });
                    
                },
                error: function(error) {
                    console.log("Error fetching trainer data:", error);
                }
            });
        } else {
            // If no branches are selected, clear the trainer dropdown
            $('#trainer').empty().append('<option value="">Select Trainer</option><option value="0">Others</option>');
        }
    }
    
    function trainer_func() {
        const selectedTrainer = document.getElementById('trainer').value;
        // alert(selectedTrainer);
        const staffTableBody = document.getElementById('staffTableBody');
        const tra_others = document.getElementById("tra_others");
    
        const selectedBranchIds = $("#branch_name").val();  // Get selected branch IDs
        
    
        // Display 'Others' section if "Others" (value 0) is selected
        if (selectedTrainer === "0") {
            tra_others.style.display = "block";  // Show the 'Others' section
        } else {
            tra_others.style.display = "none";  // Hide the 'Others' section
        }
    
        // Clear the staff table
        staffTableBody.innerHTML = '';
    
        // Determine URL based on trainer selection
        let url;
        if (selectedTrainer === "0") {
            url = '/get-all-staff';  // Endpoint to get all staff if "Others" is selected
        } else {
            url = `/get-staff-excluding/${selectedTrainer}`;  // Endpoint to get staff excluding the selected trainer
        }
    
       // Fetch department, job position, and staff data
        Promise.all([
            fetch('/department')
                .then(response => response.json())
                .then(result => result.data),  // Assuming departments have a 'data' key
            fetch('/jobPosition')
                .then(response => response.json())
                .then(result => result),  // Directly return the result, no .data needed
            fetch(url + `?branch_ids=${selectedBranchIds.join(',')}`, {  // Pass branch IDs in the URL
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            })
                .then(response => response.json())
                .then(result => result)
        ])
        .then(([departments, jobPosition, staffData]) => {
            const departmentMap = Object.fromEntries(departments.map(department => [department.sno, department.department_name]));
            const jobPositionMap = Object.fromEntries(jobPosition.map(position => [position.sno, position.job_position_name]));

            // Find the sno of the 'Management' department
            const managementDeptId = departments.find(dept => dept.department_name === "Management")?.sno;

            // Filter out staff whose department is 'Management'
            if (managementDeptId !== undefined) {
                staffData = staffData.filter(staff => staff.department_id !== managementDeptId);
            }

            console.log('Filtered Staff Data:', staffData);

            if (!Array.isArray(staffData)) {
                staffData = [];
            }

            if (staffData.length === 0) {
                staffTableBody.innerHTML = '<tr><td colspan="4" class="text-danger">No staff found.</td></tr>';
                return;
            }
            const selectedDepartment = $("#department_add").val(); // Get selected department
            staffData.forEach(staff => {
                    if(staff.sno > 1){
                        if(selectedDepartment==staff.department_id){
                            const row = document.createElement('tr');
                            row.innerHTML = ` 
                                <td>
                                    <input class="form-check-input bulk_chk" type="checkbox" value="${staff.sno}" id="staff_check" name="staff_check[]" />
                                </td>
                                <td>${staff.staff_name}</td>
                                <td>${departmentMap[staff.department_id] || '-'} </td>
                                <td>${jobPositionMap[staff.position_role] || '-'}</td>
                            `;
                            staffTableBody.appendChild(row);
                        }
                    }
            });

        })
        .catch(error => {
            console.error('Error fetching data:', error);
            staffTableBody.innerHTML = '<tr><td colspan="4" class="text-danger">Error loading staff list.</td></tr>';
        });
    }
    
    // Add the event listener for branch name change and trainer change
    $('#branch_name').on('change', updateTrainerOptions);  // For branch selection change
    document.getElementById('trainer').addEventListener('change', trainer_func);  // For trainer selection change
</script>
    
<script>
    function AddvalidateForm_training() {
            var err = 0;

            var branch_name = document.getElementById("branch_name").value.trim();
            if (branch_name === "") {
                document.getElementById('branch_name_err').innerHTML = 'Branch Name is required...!';
                err++;
            } else {
                document.getElementById('branch_name_err').innerHTML = '';
            }

            var training_planner_name = document.getElementById("training_planner_name").value.trim();
            if (training_planner_name === "") {
                document.getElementById('training_planner_name_err').innerHTML = 'Training Planner Name is required...!';
                err++;
            } else {
                document.getElementById('training_planner_name_err').innerHTML = '';
            }
            
            var department_add = document.getElementById("department_add").value.trim();
            if (department_add === "") {
                document.getElementById('department_add_err').innerHTML = 'Select Department is required...!';
                err++;
            } else {
                document.getElementById('department_add_err').innerHTML = '';
            }

            var training_mode = document.getElementById("training_mode").value.trim();
            if (training_mode === "") {
                document.getElementById('training_mode_err').innerHTML = 'Training Mode is required...!';
                err++;
            } else {
                document.getElementById('training_mode_err').innerHTML = '';
            }
            var trainer = document.getElementById("trainer").value.trim();
            if (trainer === "") {
                document.getElementById('trainer_err').innerHTML = 'Trainer is required...!';
                err++;
            } else {
                document.getElementById('trainer_err').innerHTML = '';
            }
            if(trainer == 0){
            var trainer_name = document.getElementById("trainer_name").value.trim();
            if (trainer_name === "") {
                document.getElementById('trainer_name_err').innerHTML = 'Trainer Name is required...!';
                err++;
            } else {
                document.getElementById('trainer_name_err').innerHTML = '';
            }
            }

            var duration = document.getElementById("duration").value.trim();
            if (duration === "") {
                document.getElementById('duration_err').innerHTML = 'Training Duration is required...!';
                err++;
            } else {
                document.getElementById('duration_err').innerHTML = '';
            }

            var training_planner_sch_dt_add = document.getElementById("training_planner_sch_dt_add").value.trim();
            if (training_planner_sch_dt_add === "") {
                document.getElementById('training_planner_sch_dt_add_err').innerHTML = 'Schedule Date is required...!';
                err++;
            } else {
                document.getElementById('training_planner_sch_dt_add_err').innerHTML = '';
            }

            var training_planner_sch_time_add = document.getElementById("training_planner_sch_time_add").value.trim();
            if (training_planner_sch_time_add === "") {
                document.getElementById('training_planner_sch_time_add_err').innerHTML = 'Schedule Time is required...!';
                err++;
            } else {
                document.getElementById('training_planner_sch_time_add_err').innerHTML = '';
            }

            if ($('.bulk_chk:checked').length > 0){
                $('#check_err').innerHTML = '';
            }else{
                $('#check_err').innerHTML = 'Atleast one staff should be checked!';
                err++;
            }

            if(err == 0){
                $('#addTrainingForm').submit();
                $('#add_training_submit').prop('disabled', true);
                }else{
                $('#add_training_submit').prop('disabled', false);
                }
        }

</script>

{{-- <script>
    function trainer_func() {
        const selectedTrainer = document.getElementById('trainer').value;
        alert(selectedTrainer);
        const staffTableBody = document.getElementById('staffTableBody');
        const tra_others = document.getElementById("tra_others");

        const selectedBranchIds = $("#branch_name").val();  // Get selected branch IDs (same as in updateTrainerOptions)

        if (selectedTrainer === "others") {
            tra_others.style.display = "block";  // Show the 'Others' section
        } else {
            tra_others.style.display = "none";  // Hide the 'Others' section
        }

        // Clear the staff table
        staffTableBody.innerHTML = '';

        // Determine URL based on trainer selection
        let url;
        if (selectedTrainer == 0) {
            url = '/get-all-staff';
        } else {
            url = `/get-staff-excluding/${selectedTrainer}`;
        }

        // Fetch department, job position, and staff data
        Promise.all([
            fetch('/department')
                .then(response => response.json())
                .then(result => result.data),
            fetch('/job_position')
                .then(response => response.json())
                .then(result => result.data),
            fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
                // Pass branch IDs in the request query string
                body: JSON.stringify({ branch_ids: selectedBranchIds })
            })
                .then(response => response.json())
                .then(result => result)
        ])
        .then(([departments, jobPositions, staffData]) => {
            // Create maps for department and job position
            const departmentMap = Object.fromEntries(departments.map(department => [department.sno, department.department_name]));
            const jobPositionMap = Object.fromEntries(jobPositions.map(position => [position.sno, position.job_position_name]));

            if (!Array.isArray(staffData)) {
                console.error('Expected staffData to be an array:', staffData);
                staffData = [];
            }

            if (staffData.length === 0) {
                staffTableBody.innerHTML = '<tr><td colspan="4" class="text-danger">No staff found.</td></tr>';
                return;
            }

            staffData.forEach(staff => {
                if(staff.sno > 1){
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>
                            <input class="form-check-input bulk_chk" type="checkbox" value="${staff.sno}" id="staff_check" name="staff_check[]" />
                        </td>
                        <td>${staff.staff_name}</td>
                        <td>${departmentMap[staff.department_id] || '-'}</td>
                        <td>${jobPositionMap[staff.position_role] || '-'}</td>
                    `;
                    staffTableBody.appendChild(row);
                }
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            staffTableBody.innerHTML = '<tr><td colspan="4" class="text-danger">Error loading staff list.</td></tr>';
        });
    }

    // Trigger the function when the trainer dropdown changes
    document.getElementById('trainer').addEventListener('change', trainer_func);
</script> --}}
{{-- add --}}


{{-- edit --}}
<script>
    function EditvalidateForm_training() {
        var err = 0;

        var training_planner_name = document.getElementById("training_planner_name_edit").value.trim();
        var training_planner_name_err = document.getElementById('training_planner_name_edit_err');
        if (training_planner_name === "") {
            training_planner_name_err.innerHTML = 'Training Planner Name is required...!';
            err++;
        } else {
            training_planner_name_err.innerHTML = '';
        }
        
        var department = document.getElementById("department_edit").value.trim();
        var department_err = document.getElementById('department_edit_err');
        if (department === "") {
            department_err.innerHTML = 'Select Department is required...!';
            err++;
        } else {
            department_err.innerHTML = '';
        }


        var training_mode = document.getElementById("training_mode_edit").value.trim();
        var training_mode_err = document.getElementById('training_mode_edit_err');
        if (training_mode === "") {
            training_mode_err.innerHTML = 'Training Mode is required...!';
            err++;
        } else {
            training_mode_err.innerHTML = '';
        }

        var trainer = document.getElementById("trainer_edit").value.trim();
        var trainer_err = document.getElementById('trainer_edit_err');
        if (trainer === "") {
            trainer_err.innerHTML = 'Trainer is required...!';
            err++;
        } else {
            trainer_err.innerHTML = '';
        }

        if (trainer == 0) {
            var trainer_name = document.getElementById("trainer_name_edit").value.trim();
            var trainer_name_err = document.getElementById('trainer_name_edit_err');
            if (trainer_name === "") {
                trainer_name_err.innerHTML = 'Trainer Name is required...!';
                err++;
            } else {
                trainer_name_err.innerHTML = '';
            }
        }

    
        var duration = document.getElementById("duration_edit").value;
        var duration_err = document.getElementById('duration_edit_err');
        if (duration === "" ) {
            duration_err.innerHTML = 'Training Duration must be a positive integer...!';
            err++;
        } else {
            duration_err.innerHTML = '';
        }

        var training_planner_sch_dt_add = document.getElementById("training_planner_sch_dt_edit").value.trim();
        var schedule_date_err = document.getElementById('training_planner_sch_dt_edit_err');
        if (training_planner_sch_dt_add === "") {
            schedule_date_err.innerHTML = 'Schedule Date is required...!';
            err++;
        } else {
            schedule_date_err.innerHTML = '';
        }

        var training_planner_sch_time_edit = document.getElementById("training_planner_sch_time_edit").value.trim();
        if (training_planner_sch_time_edit === "") {
            document.getElementById('training_planner_sch_time_edit_err').innerHTML = 'Schedule Time is required...!';
            err++;
        } else {
            document.getElementById('training_planner_sch_time_edit_err').innerHTML = '';
        }

        var check_edit_err = document.getElementById('check_edit_err');
        if ($('.bulk_chk_edit:checked').length > 0) {
            check_edit_err.innerHTML = '';
        } else {
            check_edit_err.innerHTML = 'At least one staff should be checked!';
            err++;
        }

        if (err === 0) {
            $('#editTrainingForm').submit();
            $('#edit_training_submit').prop('disabled', true);
        } else {
            $('#edit_training_submit').prop('disabled', false);
        }
    }

</script>

<script>
    function TableGet() {
        const course_id = $('#training_planner_id_edit').val();
        const selectedTrainer = $('#trainer_edit').val();

        if (selectedTrainer == 0) {
            $('#trainer_edit').val('0');  
        } else {
            $('#trainer_edit').val(selectedTrainer);  
        }
        const selectedBranchId = $('#branch_name_edit').val();
        const tra_others = document.getElementById("tra_others_edit");
        tra_others.style.display = selectedTrainer == 0 ? "block" : "none";
        const staffTableBody = document.getElementById('staffTableBodyEdit');
        staffTableBody.innerHTML = '';
        const departmentId = $('#department_edit').val(); // Get selected department

        const queryParams = new URLSearchParams({
            trainer_id: selectedTrainer,
            id: course_id,
            branch_id: selectedBranchId,
            departmentId :departmentId
        }).toString();

        fetch(`/tableGet?${queryParams}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.text(); 
        })
        .then(data => {
            console.log(data);
            staffTableBody.innerHTML = data;
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            staffTableBody.innerHTML = '<tr><td colspan="4" class="text-danger">Error loading staff list.</td></tr>';
        });
    }

    function openEditModal(course_id) {
        fetch(`/training_edit/${course_id}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then(text => {
                let data;

                try {
                    data = JSON.parse(text);
                } catch (error) {
                    console.error('Error parsing JSON:', error.message);
                    return;
                }

                const editTrainer = data.data;
                // console.log(editTrainer);

                // Fill in the form fields
                $('#training_planner_id_edit').val(editTrainer.sno);
                const branchIds = JSON.parse(editTrainer.branch_id);
                $('#branch_name_edit').val(branchIds).change();  // Set selected branch IDs

                // Initialize trainer dropdown with the selected trainer
                $('#trainer_edit').empty().append('<option value="">Select Trainer</option><option value="0">Others</option>');
                if (editTrainer.trainer != '0') {
                    $('#trainer_edit').append('<option value="' + editTrainer.trainer + '">' + editTrainer.trainer_name + '</option>');
                }
                $('#trainer_edit').val(editTrainer.trainer); // Set the selected trainer
                $('#trainer_edit').change();  // Trigger the change event to update the UI

                $('#training_planner_name_edit').val(editTrainer.training_planner_name);
                $('#training_mode_edit').val(editTrainer.training_mode).change();
                $('#department_edit').val(editTrainer.department).trigger('change');
                $('#duration_edit').val(editTrainer.training_duration);
                $('#training_desc_edit').val(editTrainer.training_desc);
                $('#training_planner_sch_dt_edit').val(editTrainer.schedule_date);
                $('#training_planner_sch_time_edit').val(editTrainer.schedule_time);
                $('#trainer_name_edit').val(editTrainer.trainer_name);  // Display trainer name, not ID
                // alert(editTrainer.trainer);

                // Call the updateTrainerOptionsEdit function to populate trainers based on the selected branches
                updateTrainerOptionsEdit(branchIds, editTrainer.trainer);

                const rawData = editTrainer.staff_check ? `[${editTrainer.staff_check}]` : '[]';
                TableGet(); // This seems to be a custom function to load more data
            })
            .catch(error => {
                console.error('Error fetching training data:', error);
            });
        }

    // Handle change in branch_name_edit and make AJAX call for staff (trainer)
    $('#branch_name_edit').on('change', function() {
        const selectedBranchIds = $(this).val();
        const selectedTrainer = $('#trainer_edit').val(); // Get the currently selected trainer ID
        alert(selectedBranchIds); // This should now show the correct trainer ID

        if (selectedBranchIds && selectedBranchIds.length > 0) {
            updateTrainerOptionsEdit(selectedBranchIds, selectedTrainer); // Update trainer options based on selected branches
        } else {
            // If no branch is selected, clear the trainer dropdown
            $('#trainer_edit').empty().append('<option value="">Select Trainer</option><option value="0">Others</option>');
        }
    });
    
    

    // Function to update trainer options based on branch selection
    function updateTrainerOptionsEdit(branchIds, selectedTrainer) {
         const departmentId = $('#department_edit').val(); // Get selected department
        $.ajax({
            url: '{{ route("get_branch_staff") }}',  // Adjust the route to match your backend endpoint
            method: 'GET',
            data: {
                branch_ids: branchIds,
                department_id: departmentId
            },
            success: function(response) {
                console.log('Response from server:', response); // Log the server response

                $('#trainer_edit').empty().append('<option value="">Select Trainer</option><option value="0">Others</option>');

                response.staff_list.forEach(function(staff) {
                    if(staff.sno > 1){
                    $('#trainer_edit').append('<option value="' + staff.sno + '">' + staff.staff_name + '</option>');
                    }
                });

                // Check if there's an existing selected trainer and set it
                if (selectedTrainer === '0') {
                    $('#trainer_edit').val('0');  // If 'Others' is selected
                } else if (selectedTrainer) {
                    $('#trainer_edit').val(selectedTrainer);  // Set the actual trainer ID
                }

                $('#trainer_edit').change();  // Trigger change event to reflect the selection
            },
            error: function(error) {
                console.log("Error fetching trainer data:", error);
            }
        });
    }

</script>
{{-- edit --}}


{{-- filter --}}

<script>
    $(document).ready(function() {
        @if($filter_on ?? '')
        $('.training_filter').slideToggle('fast');
        // });
        @endif
    });

    // Toggle branch filter section
    $('#training_filter').click(function() {
        $('.training_filter').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#acc_daily_acc_week_st_dt_fill').val(firstday);
            $('#acc_daily_acc_week_ed_dt_fill').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
  </script>
{{-- filter --}}


{{-- checkbox --}}
<script>
    $('#staff_list_add').change(function() {
            $('.bulk_chk').prop('checked', this.checked);

        });

        $('.bulk_chk').change(function() {
            if ($('.bulk_chk:checked').length == $('.bulk_chk').length) {
                $('#staff_list_add').prop('checked', true);

            } else {
                $('#staff_list_add').prop('checked', false);
            }

        });
</script>

<script>
    $('#staff_list_edit').change(function() {
            $('.bulk_chk_edit').prop('checked', this.checked);

        });

        $('.bulk_chk_edit').change(function() {
            if ($('.bulk_chk_edit:checked').length == $(
                    '.bulk_chk_edit').length) {
                $('#staff_list_edit').prop('checked', true);

            } else {
                $('#staff_list_edit').prop('checked', false);
            }

        });
</script>

<script>
    $('#staff_list_complete').change(function() {
            $('.bulk_chk_complete').prop('checked', this.checked);

        });

        $('.bulk_chk_complete').change(function() {
            if ($('.bulk_chk_complete:checked').length == $(
                    '.bulk_chk_complete').length) {
                $('#staff_list_complete').prop('checked', true);

            } else {
                $('#staff_list_complete').prop('checked', false);
            }

        });
</script>
{{-- checkbox --}}


{{-- datatable --}}
<script>
    $(".list_page").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
</script>

<script>
    $(".list_page_empty").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-12 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
        $('.list_page_empty').wrap('<div class="dataTables_scroll" />');
</script>
{{-- datatable --}}


{{-- view --}}
<script>
    function formatDate(dateString) 
    {
        const date = new Date(dateString);
        const day = date.getDate().toString().padStart(2, '0');
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        const month = monthNames[date.getMonth()];
        const year = date.getFullYear();

        let hours = date.getHours();
        const minutes = date.getMinutes().toString().padStart(2, '0');
        const amPm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12 || 12; 

        return `${day}-${month}-${year} ${hours}:${minutes} ${amPm}`;
    }


    function openViewModal(id, name, mode, trainer, trainer_name, duration, date, desc, tra_staff, attendanceList,  branch_id) {
      
        document.getElementById('training_planner_id').value = id;
        document.getElementById('training_planner_view').innerText = name;
        getBranchNamesView(branch_id).then(branchNames => {
            console.log(branchNames);
            document.getElementById('branch_name_view').innerText = branchNames;
        });


        const training_mode = document.querySelector('#training_mode_view');
        training_mode.innerHTML = mode === '1' ? "online" : mode === '2' ? "offline" : "Video";

        document.getElementById('trainer_view').innerText = tra_staff;
        document.getElementById('duration_view').innerText = duration + ' hrs';
        $('#schedule_date_view').html(formatDate(date));
        document.getElementById('training_desc_view').innerText = desc;
        
        if(attendanceList!=''){
            let attendance;

            try {
                attendance = JSON.parse(attendanceList);
            } catch (e) {
                console.error("Invalid attendanceList format", e);
                return; 
            }
            const viewTableBody = document.getElementById('viewTableBody');
            viewTableBody.innerHTML = ''; 

            const attendanceMap = {};

                attendance.forEach(item => {
                    attendanceMap[Number(item.staff_id)] = item.attendance; 
                    console.log(`Staff ID: ${item.staff_id}, Attendance: ${item.attendance}`); 
                });
                Promise.all([
                fetch('/department'),
                fetch('/jobPosition'),
                fetch('/get-all-staff'),
                fetch(`/training_attendance/${id}`)
            ])
            .then(async (responses) => {
                const [departmentResponse, jobPositionResponse, staffResponse, attendanceResponse] = responses;

                const departments = await departmentResponse.json();
                const jobPositions = await jobPositionResponse.json();
                const staffData = await staffResponse.json();
                const attendanceData = await attendanceResponse.json();

                const departmentMap = Object.fromEntries(departments.data.map(department => [department.sno, department.department_name]));
                const jobPositionMap = Object.fromEntries(jobPositions.map(position => [position.sno, position.job_position_name]));

                const staffCheckIds = attendanceData.data.staff_check || [];
                const staffList = staffData;

                    staffList.forEach(staff => {
                        if (staffCheckIds.includes(String(staff.sno))) {
                            const row = document.createElement('tr');
                            let attendanceStatus;

                            if (attendanceMap[staff.sno] === 1) {
                                attendanceStatus = 'Absent'; 
                            } else if (attendanceMap[staff.sno] === 0) {
                                attendanceStatus = 'Present'; 
                            } else {
                                attendanceStatus = 'Unknown'; 
                            }

                            row.innerHTML = `
                                <td>
                                    <input type="hidden" id="staff_id" name="staff_id" value="${staff.sno}"/>
                                    ${staff.staff_name}
                                </td>
                                <td>${departmentMap[staff.department_id] || 'Unknown Department'}</td>
                                <td>${jobPositionMap[staff.position_role] || 'Unknown Position'}</td>
                                <td>
                                    ${(() => {
                                        if (attendanceStatus === 'Present') {
                                            return '<label class="fs-7 text-black" style="background-color: green!important; color:white !important; border-radius: 25px; padding: 4px 4px;">Present</label>';
                                        } else if (attendanceStatus === 'Absent') {
                                            return '<label class="fs-7 text-white" style="background-color: red!important; border-radius: 25px; padding: 4px 4px;">Absent</label>';
                                        } else {
                                            return '<label class="fs-7 text-white">Unknown Status</label>'; 
                                        }
                                    })()}
                                </td> 
                            `;
                            viewTableBody.appendChild(row);
                        }
                    });
            })
            .catch(error => {
                console.error('Error fetching training data:', error);
            }); 
        }else{
                viewTableBody.innerHTML = '<tr><td></td><td>No data Available</td></td><td></td><td></td></tr>'; 
            }
    }

    function getBranchNamesView(branchIds) {
        // Fetch branch data from the server
        return fetch('/branchList')
            .then(response => response.json())  // Parse the response as JSON
            .then(branchData => {
                console.log(branchData); 

                const ids = Array.isArray(branchIds) ? branchIds : JSON.parse(branchIds);

                console.log('Parsed IDs:', ids); // Log the parsed IDs

                return ids.map(id => {
                    console.log('Looking for branch with sno:', id);
                    const branch = branchData.find(branch => branch.sno === Number(id)); // Cast id to a number
                    console.log('Found branch:', branch); // Log the found branch or undefined
                    return branch ? (branch.branch_name || branch.franchise_name || '-') : '-';
                }).join(', ');

            })
            .catch(error => {
                console.error('Error fetching branch data:', error);
                return 'Error fetching branch names';
            });
        }
</script>
{{-- view --}


{{-- Complete Training --}}
<script>
    function formatDate(dateString) {
                const date = new Date(dateString);
                const day = date.getDate().toString().padStart(2, '0');
                const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                const month = monthNames[date.getMonth()];
                const year = date.getFullYear();

                let hours = date.getHours();
                const minutes = date.getMinutes().toString().padStart(2, '0');
                const amPm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12 || 12; // Convert to 12-hour format

                return `${day}-${month}-${year} ${hours}:${minutes} ${amPm}`;
            }

            function completeTraining(id, name, mode, trainer, trainer_name, duration, date, desc, tra_staff, branch_id) {
                document.getElementById('training_complete_id').value = id;
                document.getElementById('training_complete').innerText = name;
                // alert(id);
                // Handle branch name mapping
                getBranchNames(branch_id).then(branchNames => {
                    console.log(branchNames);
                    document.getElementById('branch_name_complete').innerText = branchNames;
                });

                const trainingMode = document.querySelector('#training_mode_complete');
                const modes = {
                    '1': 'online',
                    '2': 'offline',
                    '3': 'Video'
                };
                trainingMode.innerHTML = modes[mode] || 'Unknown Mode';

                document.getElementById('trainer_complete').innerText = tra_staff;
                document.getElementById('duration_complete').innerText = duration + ' hrs';
                $('#date_complete').html(formatDate(date));
                document.getElementById('training_desc_complete').innerText = desc;

                const attendanceTableBody = document.getElementById('attendanceTableBody');
                attendanceTableBody.innerHTML = '';

                Promise.all([
                    fetch('/department'),
                    fetch('/jobPosition'),
                    fetch('/get-all-staff'),
                    fetch(`/training_attendance/${id}`),
                ])
                .then(async (responses) => {
                    const [departmentResponse, jobPositionResponse, staffResponse, attendanceResponse] = responses;

                    // Parse the responses to JSON
                    const departments = await departmentResponse.json();
                    const jobPositions = await jobPositionResponse.json();
                    const staffData = await staffResponse.json();
                    const attendanceData = await attendanceResponse.json();

                    // console.log('Departments:', departments);
                    // console.log('Job Position:', jobPositions);
                    // console.log('Staff Data:', staffData);
                    // console.log('Attendance:', attendanceData);

                    const departmentMap = Array.isArray(departments.data) ? 
                        Object.fromEntries(departments.data.map(department => [department.sno, department.department_name])) : {};
                    
                    const jobPositionMap = Array.isArray(jobPositions) ? 
                        Object.fromEntries(jobPositions.map(position => [position.sno, position.job_position_name])) : {};
                    // console.log(jobPositionMap)
                    const staffCheckIds = Array.isArray(attendanceData.data?.staff_check) ? attendanceData.data.staff_check : [];
                    
                    const staffList = Array.isArray(staffData) ? staffData : [];
                    // console.log('Checked Staffs:', staffCheckIds);

                    staffList.forEach(staff => {
                        if (staffCheckIds.includes(String(staff.sno))) {
                            const row = document.createElement('tr');
                            const isChecked = true;

                            row.innerHTML = ` 
                                <td>
                                    <input type="hidden" id="staff_id" name="staff_id" value="${staff.sno}"/>
                                    <input class="form-check-input bulk_chk_complete" type="checkbox" value="${staff.sno}" id="staff_check_edit_${staff.sno}" name="staff_check[]" />
                                </td>
                                <td>${staff.staff_name}</td>
                                <td>${departmentMap[staff.department_id] || 'Unknown Department'}</td>
                                <td>${jobPositionMap[staff.position_role] || 'Unknown Position'}</td>
                            `;
                            attendanceTableBody.appendChild(row);
                        }
                    });
                })
                .catch(error => {
                    console.error('Error fetching training data:', error);
                });
            }

            function getBranchNames(branchIds) {
                // Fetch branch data from the server
                return fetch('/branchList')
                    .then(response => response.json())  // Parse the response as JSON
                    .then(branchData => {
                        console.log(branchData); 

                        const ids = Array.isArray(branchIds) ? branchIds : JSON.parse(branchIds);

                        console.log('Parsed IDs:', ids); // Log the parsed IDs

                        return ids.map(id => {
                            console.log('Looking for branch with sno:', id);
                            const branch = branchData.find(branch => branch.sno === Number(id)); // Cast id to a number
                            console.log('Found branch:', branch); // Log the found branch or undefined
                            return branch ? (branch.branch_name || branch.franchise_name || '-') : '-';
                        }).join(', ');

                    })
                    .catch(error => {
                        console.error('Error fetching branch data:', error);
                        return 'Error fetching branch names';
                    });
                }


            function updateAttendanceStatus() {
                const attendanceData = [];
                const trainingPlannerId = document.getElementById('training_complete_id').value; // Fetch the training_planner_id

                document.querySelectorAll('input[name="staff_check[]"]').forEach((checkbox) => {
                    const staffId = checkbox.value;
                    const attendanceStatus = checkbox.checked ? 1 : 0;

                    attendanceData.push({
                        staff_id: staffId,
                        attendance: attendanceStatus
                    });
                });

                fetch('/complete_training', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify({
                        training_planner_id: trainingPlannerId,
                        attendance: attendanceData
                    })
                })
                .then(response => {
                    console.log(response);
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Return data:', data);
                    if (data.status === 200) {
                        toastr.success(data.message);
                        location.reload();

                    
                    } else {
                        toastr.error('Failed to update attendance. Status: ' + data.status);
                    }
                })
                .catch(error => {
                    console.error('Error updating attendance:', error);
                });

            }

            document.getElementById('submit_complete').addEventListener('click', updateAttendanceStatus);

</script>
{{-- Complete Training --}}
<script>
    $('#lead_slow_mo').click(function() {
        $('.lead_tbox').slideToggle('slow');
    });
 

function sort_filter(val) {
    if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#search_form').submit();
    } else {
      $('.sorting_filter_class').val(10);
      $('#search_form').submit();
    }
  }
</script>  
<script>
        $(document).ready(function() {
    
    $.ajax({
        url: "{{ route('department') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                // Populate the select dropdown with fetched course categories
                var selectDropdown = $('select[name="department_add"]');
                selectDropdown.empty();
                selectDropdown.append($(
                    '<option value="">Select Department</option>'));
                response.data.forEach(function(category) {
                    selectDropdown.append($('<option></option>').attr('value', category.sno)
                        .text(category.department_name));
                });
            }
        },
        error: function(error) {
            console.error('Error fetching course categories:', error);
        }
    });
});

 $(document).ready(function() {
    
    $.ajax({
        url: "{{ route('department') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                // Populate the select dropdown with fetched course categories
                var selectDropdown = $('select[name="department_edit"]');
                selectDropdown.empty();
                selectDropdown.append($(
                    '<option value="">Select Department</option>'));
                response.data.forEach(function(category) {
                    selectDropdown.append($('<option></option>').attr('value', category.sno)
                        .text(category.department_name));
                });
            }
        },
        error: function(error) {
            console.error('Error fetching course categories:', error);
        }
    });
});
</script>

@endsection