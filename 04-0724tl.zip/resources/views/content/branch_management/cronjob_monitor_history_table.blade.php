<div class="table-responsive">
    <div class="mb-4 text-center">
        <h3 class="text-center mb-4 text-black">{{$crons->cronjob_name ?? ''}}</h3>
    </div>
    <table class="table table-striped table-hover align-middle">
        <thead class="bg-primary text-white">
            <tr>
                <th>Sno</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Duration</th>
                <th>Response</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($logs as $i => $log)
                @php
                    $responseData = json_decode($log->response, true);
                @endphp
                <tr>
                    <td>{{ $logs->firstItem() + $i }}</td>
                    <td>{{ \Carbon\Carbon::parse($log->sync_start_date_time)->format('d-M-Y h:i A') }}</td>
                    <td>{{ \Carbon\Carbon::parse($log->sync_end_date_time)->format('d-M-Y h:i A') }}</td>
                    <td>
                        @php
                            [$hours, $minutes, $seconds] = explode(':', $log->sync_duration);
                        @endphp
                        {{ (int) $hours > 0 ? $hours . ' hr ' : '' }}
                        {{ (int) $minutes > 0 ? $minutes . ' min ' : '' }}
                        {{ (int) $seconds }} sec
                     </td>
                    <td>
                        @if($responseData)
                            <div class="response-container" style="max-height: 400px; overflow-y: auto; background: #f8f9fa; border-radius: 5px; padding: 10px; font-size: 13px;">
                                
                                {{-- Check for success/status --}}
                                @if(isset($responseData['success']))
                                    <div class="alert alert-{{ $responseData['success'] ? 'success' : 'danger' }} mb-2 p-2">
                                        <strong>Status:</strong> {{ $responseData['success'] ? 'Success' : 'Failed' }}
                                        @if(isset($responseData['message']))
                                            <br><strong>Message:</strong> {{ $responseData['message'] }}
                                        @endif
                                    </div>
                                @endif

                                {{-- Check for simple processed_records format --}}
                                @if(isset($responseData['processed_records']) && !isset($responseData['branch_wise_summary']))
                                    <div class="mb-2">
                                        <strong>Summary:</strong>
                                        <ul class="mb-0">
                                            <li><strong>Processed Records:</strong> {{ $responseData['processed_records'] ?? 0 }}</li>
                                            @if(isset($responseData['execution_time']))
                                                <li><strong>Execution Time:</strong> {{ $responseData['execution_time'] }}</li>
                                            @endif
                                            @if(isset($responseData['processed_branches']))
                                                <li><strong>Processed Branches:</strong> {{ $responseData['processed_branches'] }}</li>
                                            @endif
                                            @if(isset($responseData['total_branches']))
                                                <li><strong>Total Branches:</strong> {{ $responseData['total_branches'] }}</li>
                                            @endif
                                        </ul>
                                    </div>
                                @endif

                                {{-- Check for branch_details array --}}
                                @if(isset($responseData['branch_details']) && is_array($responseData['branch_details']))
                                    <div class="mb-2">
                                        <strong>Branch Details:</strong>
                                        <ul class="mb-0">
                                            @foreach($responseData['branch_details'] as $detail)
                                                <li class="small">{{ $detail }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif

                                {{-- Check for full branch_wise_summary (from your call logs function) --}}
                                @if(isset($responseData['branch_wise_summary']) && is_array($responseData['branch_wise_summary']))
                                    <div class="mb-2">
                                        <strong class="text-primary">Branch Wise Summary:</strong>
                                        <div style="max-height: 250px; overflow-y: auto; margin-top: 5px;">
                                            @foreach($responseData['branch_wise_summary'] as $branchName => $branchData)
                                                <div class="border-bottom pb-2 mb-2">
                                                    <strong class="text-dark">{{ $branchName }}:</strong>
                                                    <ul class="mb-0 ps-3 small">
                                                        <li>Status: 
                                                            <span class="{{ ($branchData['status'] ?? '') == 'success' ? 'text-success' : 'text-warning' }}">
                                                                {{ ucfirst($branchData['status'] ?? 'N/A') }}
                                                            </span>
                                                        </li>
                                                        @if(isset($branchData['calls_found']))
                                                            <li>Calls Found: {{ $branchData['calls_found'] }}</li>
                                                        @endif
                                                        @if(isset($branchData['inserted']))
                                                            <li>Inserted: {{ $branchData['inserted'] }}</li>
                                                        @endif
                                                        @if(isset($branchData['updated']))
                                                            <li>Updated: {{ $branchData['updated'] }}</li>
                                                        @endif
                                                        @if(isset($branchData['message']))
                                                            <li class="text-info">{{ $branchData['message'] }}</li>
                                                        @endif
                                                        @if(isset($branchData['error']))
                                                            <li class="text-danger">Error: {{ $branchData['error'] }}</li>
                                                        @endif
                                                    </ul>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                @endif

                                {{-- Display summary metrics if they exist --}}
                                @if(isset($responseData['inserted_records']) || isset($responseData['updated_records']) || isset($responseData['total_records_processed']))
                                    <div class="mb-2">
                                        <strong>Metrics:</strong>
                                        <ul class="mb-0">
                                            @if(isset($responseData['inserted_records']))
                                                <li><strong>Inserted Records:</strong> {{ $responseData['inserted_records'] }}</li>
                                            @endif
                                            @if(isset($responseData['updated_records']))
                                                <li><strong>Updated Records:</strong> {{ $responseData['updated_records'] }}</li>
                                            @endif
                                            @if(isset($responseData['total_records_processed']))
                                                <li><strong>Total Processed:</strong> {{ $responseData['total_records_processed'] }}</li>
                                            @endif
                                            @if(isset($responseData['execution_time']))
                                                <li><strong>Execution Time:</strong> {{ $responseData['execution_time'] }}</li>
                                            @endif
                                            @if(isset($responseData['branches_processed']))
                                                <li><strong>Branches Processed:</strong> {{ $responseData['branches_processed'] }}</li>
                                            @endif
                                            @if(isset($responseData['branches_with_errors']))
                                                <li><strong>Branches with Errors:</strong> {{ $responseData['branches_with_errors'] }}</li>
                                            @endif
                                        </ul>
                                    </div>
                                @endif

                                {{-- Display errors if any --}}
                                @if(isset($responseData['errors']) && !empty($responseData['errors']))
                                    <div class="mb-2">
                                        <strong class="text-danger">Errors:</strong>
                                        <div style="max-height: 150px; overflow-y: auto;">
                                            @foreach($responseData['errors'] as $error)
                                                <div class="border border-danger rounded p-1 mb-1 small">
                                                    @if(is_array($error))
                                                        @foreach($error as $errKey => $errVal)
                                                            @if(!is_array($errVal))
                                                                <strong>{{ ucfirst($errKey) }}:</strong> {{ $errVal }}<br>
                                                            @endif
                                                        @endforeach
                                                    @else
                                                        {{ $error }}
                                                    @endif
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                @endif

                                {{-- Display any other simple key-value pairs that haven't been shown --}}
                                @php
                                    $shownKeys = ['success', 'message', 'processed_records', 'execution_time', 'processed_branches', 'total_branches', 'branch_details', 'branch_wise_summary', 'inserted_records', 'updated_records', 'total_records_processed', 'branches_processed', 'branches_with_errors', 'errors'];
                                @endphp
                                @foreach($responseData as $key => $val)
                                    @if(!in_array($key, $shownKeys) && !is_array($val) && !is_null($val))
                                        <div class="mb-1 small">
                                            <strong>{{ ucfirst(str_replace('_', ' ', $key)) }}:</strong> {{ $val }}
                                        </div>
                                    @endif
                                @endforeach

                                {{-- If response is empty or just has a message --}}
                                @if(count($responseData) == 1 && isset($responseData['message']))
                                    <div class="text-muted">{{ $responseData['message'] }}</div>
                                @endif
                            </div>
                        @else
                            <span class="text-muted">-</span>
                        @endif
                     </td>
                 </tr>
            @empty
                <tr>
                    <td colspan="5" class="text-center text-muted">No history found</td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-3">
    {{ $logs->links() }}
</div>

<style>
    .response-container ul {
        padding-left: 20px;
    }
    .response-container li {
        margin-bottom: 2px;
    }
    .response-container .alert {
        padding: 8px;
        margin-bottom: 10px;
    }
</style>