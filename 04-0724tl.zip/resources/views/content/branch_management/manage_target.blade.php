@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Manage Target')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('content')

<!-- Users List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Target</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i
                            class="mdi mdi-home text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Branch Management</a>
                </li>
            </ol>
        </nav>
    </div>



    <div class="card">
    <div class="card-header">
        <div class="row">
            <!-- Branch Selection -->
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                @php
                    $helper = new \App\Helpers\Helpers();
                    $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id;
                @endphp

                @if(isset($role_permission->manage_branch))
                    @if($role_permission->manage_branch == 2)
                        @php
                            $user_id = auth()->user()->user_id;
                            $branch_data = $helper->get_branch_control_list($user_id);
                            $branches = $branch_data['branches'];
                            $franchises = $branch_data['franchises'];
                        @endphp
                        <select name="branch_id" class="select3 form-select" id="branchSelectsgoal">
                            @if($user_id == 0)
                                <option value="0" selected>All Branches</option>
                            @endif
                            @if ($branches->isNotEmpty())
                                <optgroup label="Branches">
                                    @foreach ($branches as $branch)
                                        <option value="{{ $branch->sno }}" {{ $selectedBranch == $branch->sno ? 'selected' : '' }}>
                                            {{ $branch->branch_name }}
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                            @if ($franchises->isNotEmpty())
                                <optgroup label="Franchises">
                                    @foreach ($franchises as $franchise)
                                        <option value="{{ $franchise->sno }}" {{ $selectedBranch == $franchise->sno ? 'selected' : '' }}>
                                            {{ $franchise->franchise_name }}
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                        </select>
                    @elseif($role_permission->manage_branch == 1)
                        @if($branch_common)
                            <div class="d-flex align-items-center mt-2">
                                <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                                <div>
                                    <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                                    <small class="text-muted" title="{{ $branch_common->branch_name }}">{{ $branch_common->branch_name }}</small>
                                </div>
                            </div>
                        @endif
                    @endif
                @endif
            </div>

            <!-- Current Month Display -->
            <div class="col-lg-3 mb-3">
              <div class="nav-align-top my-4">
                  <ul class="nav nav-pills justify-content-start" role="tablist">
                      <!-- Previous Month Button -->
                      <li class="nav-item me-1">
                          <a class="nav-link px-3" href="#" id="prevMonthBtn">
                              <div class="text-center">
                                  <span class="mdi mdi-arrow-left-circle-outline fs-2"></span>
                              </div>
                          </a>
                      </li>
    
                      <!-- Current Month Display -->
                      <li class="nav-item me-1">
                          <a class="nav-link active px-3 border border-dashed border-info" href="#">
                              <div class="text-center">
                                  <span class="fs-6 fw-semibold text-capitalize" id="selectedMonth">
                                      {{ \Carbon\Carbon::now()->format('F') }}
                                  </span>
                                  <div class="d-block">
                                      <span class="fw-semibold fs-8" id="selectedYear">
                                          ({{ \Carbon\Carbon::now()->year }})
                                      </span>
                                  </div>
                              </div>
                          </a>
                      </li>
    
                      <!-- Next Month Button -->
                      <li class="nav-item me-1">
                          <a class="nav-link px-3" href="#" id="nextMonthBtn">
                              <div class="text-center">
                                  <span class="mdi mdi-arrow-right-circle-outline fs-2"></span>
                              </div>
                          </a>
                      </li>
                  </ul>
              </div>
            </div>
        </div>
    </div>

    <div class="card-body">
        <form id="targetForm">
            <div id="divsdefault">
                <!-- Big Field: No. of Registrations -->
                <div class="row mb-4">
                    <!-- No. of Registrations -->
                    <div class="col-md-4 mb-3 mb-md-0">
                        <label class="text-dark fs-6 fw-semibold">Pre Sale</label>
                        <input type="text" name="no_of_registrations" id="no_of_registrations" class="form-control form-control-lg" placeholder="Enter Pre Sale" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                    </div>
                     <div class="col-md-4 mb-3 mb-md-0">
                        <label class="text-dark fs-6 fw-semibold">Post Sale</label>
                        <input type="text" name="post_sale" id="post_sale" class="form-control form-control-lg" placeholder="Enter Post Sale" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                    </div>
                
                    <!-- Monthly Target -->
                    <div class="col-md-4">
                        <label class="text-dark fs-6 fw-semibold">Monthly Target</label>
                        <input type="text" name="monthly_target" id="monthly_target" class="form-control form-control-lg" placeholder="Enter Monthly Target" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                    </div>
                </div>

            </div>

            <div class="d-flex justify-content-end mt-4">
                <button type="button" class="btn btn-primary" id="updateTargetButton">Set Target</button>
            </div>
        </form>
        <!-- Target List Table -->
        <div class="mt-5">
            <h5 class="text-dark fw-bold mb-3">Target List</h5>
            <div class="table-responsive">
                <table class="table table-bordered align-middle text-center" id="targetTable">
                    <thead class="table bg-primary">
                        <tr>
                            <th>Month</th>
                            <th>Branch</th>
                            <th>Monthly Target</th>
                            <th>Post Sale</th>
                            <th>Pre Sale</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Data rows will be appended here dynamically -->
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>


</div>



<!-- jQuery from CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Toastr CSS from CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<!-- Toastr JavaScript from CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>

.goal-label-box {
    background-color: #f8f9fa; /* Light gray */
    padding: 6px 12px;
    border-radius: 4px;
    border: 1px solid #cccccc;
    display: inline-block;
    min-width: 100px;
    text-align: center;
}
.goal-actual-field {
    background-color: #e4c30a; /* Light gray */
    border: 1px solid #e4c30a;
    cursor: not-allowed;
}
.select2-container {
    margin-right: 0.22rem !important; /* Equivalent to Bootstrap's me-1 */
}

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }
    .goal-label {
        min-width: 200px; /* Ensures all labels are of equal width */
        text-align: left; /* Aligns text to the left for consistency */
    }
      .goal-label-staff {
          font-size: 10px;
          font-weight: bold;
          color: #555;
          text-align: center;
      }

        .goal-inline-group {
            display: flex;
            align-items: center;
            gap: 6px; /* Space between fields */
        }

        .goal-input-wrap {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

          .goal-label {
              font-weight: bold;
              color: #0a0a0a;
          }



        .goal-input-field-box {
              background-color: #ffffff;
              border: 1px solid #1b1a14;
              width: 150px;  /* Smaller input field */
              color: #1b1a14;
              /* font-size: 14px; */
              font-weight: bold;

          }

          .goal-checkbox {
              appearance: none;
              width: 20px;
              height: 20px;

              background-color: white;
              cursor: pointer;
              display: inline-block;
              position: relative;
              transform: scale(1.2);
          }

          .goal-checkbox:checked {
            border: 2px solid green;
              background-color: green;
          }




</style>
<script>

    var currentMonth = new Date().getMonth() + 1; // Get current month (1-12)
    var currentYear = new Date().getFullYear();
    function updateMonthDisplay() {
        let monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        $("#monthLabel").text(monthNames[currentMonth - 1] + " " + currentYear);
        document.getElementById("selectedMonth").textContent = monthNames[currentMonth - 1];
        document.getElementById("selectedYear").textContent = "(" + currentYear + ")";

        document.getElementById("prevMonthBtn").classList.toggle("disabled", false);
        document.getElementById("nextMonthBtn").classList.toggle("disabled", false);

        // Fetch updated team goals for the selected month
       fetchTargets();
    }
    
     document.getElementById("prevMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();
        if (currentMonth === 1) {
            currentMonth = 12;
            currentYear--;
        } else {
            currentMonth--;
        }
        updateMonthDisplay();
    });

    document.getElementById("nextMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();
        if (currentMonth === 12) {
            currentMonth = 1;
            currentYear++;
        } else {
            currentMonth++;
        }
        updateMonthDisplay();
    });
   $(document).ready(function () {
    // Trigger fetch when branch changes
    $("#branchSelectsgoal").change(function () {
        fetchTargets();
    });

    // Initial fetch on page loa
    fetchTargets();

    // Set target button action
    $("#updateTargetButton").click(function () {
        let branch_id = $("#branchSelectsgoal").val();
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
         let formData = $("#targetForm").serialize() +
                   `&branch_id=${branch_id}` +
                   `&month=${month}` +
                   `&year=${year}`;

        $.ajax({
            url: "{{ route('update_target_goals') }}",
            type: "POST",
            data: formData,
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
            },
            success: function (response) {
                toastr.success(response.message);
                fetchTargets();
            },
            error: function (xhr) {
                toastr.error('Update Failed!');
                console.error(xhr.responseText);
            }
        });
    });
});

   // Fetch existing targets if needed
   function fetchTargets() {
    let branch_id = $("#branchSelectsgoal").val();
    let month = $("#selectedMonth").text().trim();
    let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
    $.ajax({
        url: "{{ route('get_target_goals') }}",
        type: "GET",
        data: { branch_id: branch_id ,month: month ,year: year },
        success: function (response) {
            if (response.status === 200 && response.data) {
                $("input[name='no_of_registrations']").val(response.data.no_of_registrations);
                $("input[name='post_sale']").val(response.data.post_sale);
                $("input[name='monthly_target']").val(response.data.monthly_target);
        
                // Optional: Show single record in table too
                let tableRow = `
                    <tr>
                        <td class="fs-6 fw-bold">${month} ${year}</td>
                        <td class="fs-6 fw-bold">${$("#branchSelectsgoal option:selected").text()}</td>
                        <td class="fs-4 fw-semibold">₹${Number(response.data.monthly_target).toLocaleString('en-IN')}</td>
                        <td class="fs-4 fw-semibold">${response.data.post_sale}</td>
                        <td class="fs-4  fw-semibold">${response.data.no_of_registrations}</td>
                    </tr>
                `;
                $('#targetTable tbody').append(tableRow);


                $("#targetTable tbody").html(tableRow); // Replace old data
            } else {
                $("input[name='no_of_registrations']").val(0);
                $("input[name='post_sale']").val(0);
                $("input[name='monthly_target']").val(0);
                $("#targetTable tbody").html(""); // Clear table
            }
        },
        error: function (error) {
            console.error("Error fetching targets:", error);
        }
    });
}
</script>

@endsection
