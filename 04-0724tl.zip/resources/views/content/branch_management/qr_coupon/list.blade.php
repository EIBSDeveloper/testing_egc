@extends('layouts/layoutMaster')

@section('title', 'QR Coupon')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1 ">
        @php
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        @endphp
        
         <div class="row">
            <div class="col-lg-6">
              <h5 class="card-title mb-1">Branch Management</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">QR Coupon</a>
                        </li>
                    </ol>
                </nav>
            </div>
            {{-- <div class="col-lg-6">
              <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <!--<a href="javascript:;" class="btn btn-sm fw-bold btn-primary" id="filter_page" data-bs-toggle="tooltip"-->
                    <!--    data-bs-placement="bottom" title="Filter">-->
                    <!--    <span><i class="mdi mdi-filter-outline"></i></span>-->
                    <!--</a>-->
                    <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_qr_promotion" class="btn btn-sm fw-bold btn-primary">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add QR Coupon
                    </a>
                </div>
            </div> --}}
        </div>
    </div>
    <div class="card-body">
        <div class="filter_page mb-4" style="display: none;">
        </div>
        <div class="row">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
                @php $perpage_count = $perpage ? $perpage : 25; @endphp
                <div>
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div>
                    <form id="search_form" method="POST" action="/branch_management/qr_coupon">
                        @csrf
                        <div class="d-flex align-items-end gap-2">
                            <div>
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="1">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="{{ $perpage ?? 10 }}" />
                                <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                                <input type="text" class="form-control form-control-sm" id="search_fill" name="search_fill" value="{{ $search_fill ?? '' }}" placeholder="Search Discount Name "/>
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6">Search</button>
                        </div>
                    </form>
                </div>
            </div>
            
        </div>
        <div class="col-lg-12">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                        <th class="min-w-100px">Lead Name</th>
                        <th class="min-w-200px">Discount Name</th>
                        <th class="min-w-80px">Coupon Type</th>
                        <th class="min-w-80px">Discount Value</th>
                        <th class="min-w-100px">Expiry Date</th>
                        <th class="min-w-80px">Action</th>
                    </tr>
                </thead>
                <tbody class="text-gray-600 fw-semibold fs-7">

                    @if (isset($List_table) > 0)
                    @foreach ($List_table as $i => $list)
                    @csrf
                    <tr>
                         <td> 
                            <label class="text-truncate max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->discount_lead_name ??'-' }}">{{ $list->discount_lead_name ??'-' }}</label>
                            <div class="d-block">
                                <label class="text-primary fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Mobile No">{{ $list->discount_lead_phone ??'-' }}</label>
                            </div>
                        </td>
                        <td> 
                            <label class="text-truncate max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->discount_name ??'-' }}">{{ $list->discount_name ??'-' }}</label>
                            <div class="d-block">
                                @php
                                    $branch_name = $helper->branch_franchise($list->branch_id);
                                @endphp
                                <label class="text-primary fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Branch / Franchise">{{ $branch_name ??'-' }}</label>
                            </div>
                            <div class="d-block">
                                <label class="text-info fs-8 fw-bold me-1" id="coup_code_val_td_{{ $i }}">{{ $list->discount_code }}</label>
                                <a href="javascript:;" class="cpy-btn btn btn-sm btn-label-primary px-2 py-1" data-clipboard-action="copy" data-clipboard-target="#coup_code_val_td_{{ $i }}" onclick="copyToClipboard({{ $i }});">
                                    <i class="mdi mdi-content-copy fs-6 text-black"></i>
                                </a>
                            </div>
                        </td>
                       
                        <td>
                            @if($list->discount_type==0)
                            <label class="text-truncate max-w-200px">
                                Disount In Percentage ( % )
                            </label>
                            <label class="d-block">
                                <span class="badge bg-success text-white px-2 py-1 rounded fs-6 fs-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Minimum Value">
                                {{str_pad($list->min_value??0, 2, '0', STR_PAD_LEFT)}}%
                                </span>
                                <span class="badge bg-warning text-black px-2 py-1 rounded fs-6 fs-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Maximum Value">
                                {{str_pad($list->max_value??0, 2, '0', STR_PAD_LEFT)}}%
                                </span>
                            </label> 
                            @elseif($list->discount_type==1)
                            <label class="text-truncate max-w-200px">
                                Disount In Amount ( &#8377; )
                            </label>
                            <label class="d-block">
                                <span class="badge bg-success text-white px-2 py-1 rounded fs-6 fs-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Minimum Value">
                                &#8377; {{str_pad($list->min_value??0, 2, '0', STR_PAD_LEFT)}}
                                </span>
                                <span class="badge bg-warning text-black px-2 py-1 rounded fs-6 fs-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Maximum Value">
                                &#8377; {{str_pad($list->max_value??0, 2, '0', STR_PAD_LEFT)}}
                                </span>
                            </label>
                            @endif
                        </td>
                        <td>
                            @if($list->discount_type==0)
                            <label class="badge text-white fw-semibold fs-6" style="background-color: #2b92e7;">{{ $list->discount_value ??'-' }} %</label>
                             @elseif($list->discount_type==1)
                            <label class="badge text-white fw-semibold fs-6" style="background-color: #2b92e7;">&#8377; {{ $list->discount_value ??'-' }}</label>
                            @endif
                        </td>
                        <td>
                            @php
                                $expiryClass = '';
                                if (isset($list->expiry_date)) {
                                    $expiryClass = (strtotime($list->expiry_date) < strtotime(date('Y-m-d')))
                                        ? 'bg-label-danger'
                                        : 'bg-label-success';
                                }
                            @endphp
                            
                            <label class="fs-6 fw-bold {{ $expiryClass }} px-2 py-1 rounded" title="Expiry date">
                                {{ isset($list->expiry_date) ? date($common_date_format, strtotime($list->expiry_date)) : '' }}
                            </label>
                        </td>
                        <td>
                            <span class="text-end">
                                @if($list->status == 0)
                                <label
                                    data-bs-toggle="modal" 
                                    data-bs-target="#kt_modal_redeem_coupon" 
                                    class="badge bg-info fs-7 me-2 cursor-pointer" 
                                    onclick="redeemCoupon('{{ $list->sno }}','{{ $list->discount_lead_name }}', '{{ $list->discount_lead_phone }}','{{ $list->discount_code }}')">
                                    <span>Redeem</span>
                                </label>
                                @elseif($list->status == 1)
                                <label class="badge bg-danger text-white fs-7 me-2">
                                    <span>Redeemed</span>
                                </label>
                                @elseif($list->coupon_used)
                                <label class="badge bg-secondary text-white fs-7 me-2">
                                    <span>Coupon Used</span>
                                </label>
                                @endif
                            </span>
                        </td>
                    </tr>
                    @endforeach
                    @endif
                </tbody>
            </table>
        </div>
        <div class="mt-4">
            {{ $List_table->appends(request()->except(['page', '_token']))->links() }}
        </div>
    </div>
</div>

<!--begin::Modal - Delete QR Promotion-->
<div class="modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <div class="modal-dialog modal-m">
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="delete_message" style="display: block;">Are you sure you want to
                delete Qr Promotion ?</div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="button" class="btn btn-danger me-3" data-bs-dismiss="modal" onclick="deleteStaff()">Yes,
                    delete!</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, cancel</button>
            </div>
        </div>
    </div>
</div>
<!--begin::Modal - Delete QR Promotion-->

<!--begin::Modal - Download QR Code-->
<div class="modal fade" id="kt_modal_qr_download" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg" id="addModal">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                    <!--begin::Svg Icon-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </button>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->

            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-black mb-4">Download <span id="download_qr_name" class="text-success"></span> QR Code</h3>

                    <div id="qrcode" class="d-flex justify-content-center align-items-center"></div>
                    <div id="download_qr_code_name" class="fs-8 fw-semibold text-secondary mt-3"></div>
                </div>
                <!--end::Heading-->
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Download QR Code-->


<!--begin::Modal - Redeem Coupon-->
<div class="modal fade" id="kt_modal_redeem_coupon" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;"><span id="redeem_msg"></span></div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="submit" class="btn btn-danger me-3"onclick="redeemfunc()">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Redeem Coupon-->



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<style>
  /* Customize Toastr container */
  .toast {
      background-color: #39484f;
  }

  /* Customize Toastr notification */
  .toast-success {
      background-color: green;
  }

  /* Customize Toastr notification */
  .toast-error {
      background-color: red;
  }

  .error_msg {
      border: solid 2px red !important;
      border-color: red !important;
  }
</style>
<script>
  // Display Toastr messages
      @if (Session::has('toastr'))
          var type = "{{ Session::get('toastr')['type'] }}";
          var message = "{{ Session::get('toastr')['message'] }}";
          toastr[type](message);
      @endif
</script>
<script>
    // Check if 'filter_on' session variable is set and trigger click event
    $(document).ready(function() {
        @if ($filter_on ?? '')
            $('.filter_page').slideToggle('fast');
            // });
        @endif
    });

    // Toggle branch filter section
    $('#filter_page').click(function() {
        $('.filter_page').slideToggle('slow');
    });
</script>

<script>
    function redeemCoupon(id, name, phone, coupon_code) {
        document.querySelector('#kt_modal_redeem_coupon .btn-danger')
            .setAttribute('data-id', id);

        $('#redeem_msg').html(
            'Are you sure you want to redeem <br><b>' +
            '<span class="text-danger mt-2">' + coupon_code + '</span>' +
            '</b> this Coupon to lead <br><b>' +
            '<span class="text-danger mt-2">' + name + '</span>' + ' - ' +
            '<span class="text-danger mt-2">' + phone + '</span>' +
            '</b>?'
        );
    }

    function redeemfunc() {

        var categoryId = document.querySelector('#kt_modal_redeem_coupon .btn-danger').getAttribute('data-id');

        fetch('/redeem_coupon/' + categoryId, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                }
            })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                if (data.status === 200) {
                    toastr.success('Coupon Redeem successfully!');
                    location.reload();

                } else {

                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#acc_daily_acc_week_st_dt_fill').val(firstday);
            $('#acc_daily_acc_week_ed_dt_fill').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
  </script>
<script>
    function generateQRCode(val,name) {
        $('#download_qr_name').html(name);
        $('#download_qr_code_name').html(val);
      const qrText = val;
      const qrcodeContainer = document.getElementById("qrcode");
      qrcodeContainer.innerHTML = ""; // Clear previous QR

      const qr = new QRCode(qrcodeContainer, {
        text: qrText,
        width: 256,
        height: 256,
        correctLevel: QRCode.CorrectLevel.H
      });

      // Wait for QR to render, then convert to image and download
      setTimeout(() => {
        const img = qrcodeContainer.querySelector("img") || qrcodeContainer.querySelector("canvas");
        if (img) {
          const dataUrl = img.src || img.toDataURL();
          const link = document.createElement("a");
          link.href = dataUrl;
          link.download = name+"-qr-code.png";
          link.click();
        }
      }, 500); // Give it a moment to render
    }
  </script>
<script>
    function confirmDelete(id, name, ids) {
            document.querySelector('#kt_modal_delete_staff .btn-danger').setAttribute('data-id', id);
            $('#delete_message').html(
                'Are you sure you want to delete Staff <br> <b class="text-danger fw-bold fs-4">' +
                name +
                '</b> ?');
        }

        function deleteStaff() {
            var categoryId = document.querySelector('#kt_modal_delete_staff .btn-danger').getAttribute('data-id');

            fetch('/staff_delete/' + categoryId, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success(data.message);
                        location.reload();
                    } else {
                        toastr.error(data.error_msg);
                    }
                })
                .catch(error => {

                });
        }
</script>
<script>
    function updatelevelStatus(TypeId, isChecked) {
            const status = isChecked ? 0 : 1;
            fetch(`/staff_status/${TypeId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Staff status Updated successfully!');
                    }
                })
                .catch(error => {});
        }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
     $.ajax({
        url: "{{ route('bran_drop_down') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                // console.log(response.data);
                var BranchDropdown = $('#branchId');
                BranchDropdown.empty();

                // Create default option
                BranchDropdown.append('<option value="">Select Branch / Franchise</option>');

                // Create optgroups
                var branchGroup = $('<optgroup label="Branch"></optgroup>');
                var franchiseGroup = $('<optgroup label="Franchise"></optgroup>');

                // Append options to the appropriate group
                response.data.forEach(function(branch) {
                    if (branch.branch_type == 1) {
                        branchGroup.append($('<option></option>').attr('value', branch.sno).text(branch.branch_name));
                    } else if (branch.branch_type == 2) {
                        franchiseGroup.append($('<option></option>').attr('value', branch.sno).text(branch.franchise_name));
                    }
                });

                // Append the groups to the dropdown
                BranchDropdown.append(branchGroup);
                BranchDropdown.append(franchiseGroup);
            }
        },
        error: function(error) {
            console.error('Error fetching branches:', error);
        }
    });
    function add_branch_change(id) {
        fetch('/branch_sales_staff_list/' + id, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200 && data.data) {
                var selectDropdown = $('#qr_staff_id');
                selectDropdown.empty();
                selectDropdown.append('<option value="">Select Sales Staff</option>');
                data.data.forEach(function(staff) {
                    selectDropdown.append(
                        $('<option></option>').attr('value', staff.sno).text(staff.staff_name + ' (' + staff.nick_name + ')')
                    );
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
     function add_branch_change_edit(id) {
        fetch('/branch_sales_staff_list/' + id, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200 && data.data) {
                var selectDropdown = $('#qr_staff_id_edit');
                selectDropdown.empty();
                selectDropdown.append('<option value="">Select Sales Staff</option>');
                data.data.forEach(function(staff) {
                    selectDropdown.append(
                        $('<option></option>').attr('value', staff.sno).text(staff.staff_name + ' (' + staff.nick_name + ')')
                    );
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }

</script>
<script>
    function AddvalidateForm(){
        var err =0;
        
        var qr_promotion_name = $("#qr_promotion_name").val().trim();
        if (qr_promotion_name === "") {
            if(err==0){
            $('#qr_promotion_name_err').html('Enter Qr Promotion Name  is required...!');
            err++;
            }
        } else {
            $('#qr_promotion_name_err').html('');
        }
        var branchId = $("#branchId").val().trim();
        if (branchId === "") {
            if(err==0){
            $('#branchId_err').html('Select Branch / Franchise is required...!');
            err++;
            }
        } else {
            $('#branchId_err').html('');
        }

        var expiry_date = $("#expiry_date").val().trim();
        if (expiry_date === "") {
            if(err==0){
            $('#expiry_date_err').html('Select Expiry Date is required...!');
            err++;
            }
        } else {
            $('#expiry_date_err').html('');
        }

        var promotion_type = $("#promotion_type").val();
        if (promotion_type === "") {
            if(err==0){
            $('#promotion_type_err').html('Select Promotion Type is required...!');
            err++;
            }
        } else {
            $('#promotion_type_err').html('');
        }

        if(promotion_type==0 || promotion_type == 1){

            var min_value = $("#min_value").val().trim();
            if (min_value < 1 ) {
                if(err==0){
                $('#min_value_err').html('Enter Minimum value is required...!');
                err++;
                }
            } else {
                $('#min_value_err').html('');
            }
            var max_value = $("#max_value").val().trim();
            if (max_value <1) {
                if(err==0){
                $('#max_value_err').html('Enter Maximum value is required...!');
                err++;
                }
            } else {
                $('#max_value_err').html('');
            }
            
            if (parseFloat(min_value) >= parseFloat(max_value)) {
                $('#min_value_err').html('Min value cannot be greater than Max value.');
                err++;
            }

        }else{
            $('#min_value_err').html('');
            $('#max_value_err').html('');
        }
        if(promotion_type==2){
            var course_id = $("#course_id").val().trim();
            if (course_id === "") {
                if(err==0){
                $('#course_id_err').html('Select Course is required...!');
                err++;
                }
            } else {
                $('#course_id_err').html('');
            }
        }else{
            $('#course_id_err').html('');
        }
        
        var qr_staff_id = $("#qr_staff_id").val();
        if (qr_staff_id === "") {
            if(err==0){
                $('#qr_staff_id_err').html('Select Sales Staff is required...!');
                err++;
            }
        } else {
            $('#qr_staff_id_err').html('');
        }

        if(err==0){
            $('#AddForm').submit();
        }
    }
</script>
<script>
    type_change(0);
    function type_change(val){
        $('#min_value').val(0);
        $('#max_value').val(0);
        $('#course_id').val('').change();
        if(val==0){
            $('.min_max_div').show();
            $('.course_div').hide();
        }else if(val==1){
            $('.min_max_div').show();
            $('.course_div').hide();
        }else if(val==2){
            $('.min_max_div').hide();
            $('.course_div').show();
        }else{
            $('.min_max_div').hide();
            $('.course_div').hide();
        }
    }
</script>
<script>
    function sort_filter(val) {
      if (val != " ") {
        $('.sorting_filter_class').val(val);
        $('#filter_form').submit();
      } else {
        $('.sorting_filter_class').val(10);
        $('#filter_form').submit();
      }
    }
  </script>
  <script>
    function editModel(id) {
            fetch('/edit_qr_promotion/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        console.error(data.data);
                        var com = data.data;
                        $('#edit_id').val(id);
                        $('#qr_promotion_name_edit').val(com.discount_name);
                        $.ajax({
                            url: "{{ route('bran_drop_down') }}",
                            type: "GET",
                            success: function(response) {
                                if (response.status === 200 && response.data) {
                                    // console.log(response.data);
                                    var BranchDropdown = $('#branchId_edit');
                                    BranchDropdown.empty();
                    
                                    // Create default option
                                    BranchDropdown.append('<option value="">Select Branch / Franchise</option>');
                    
                                    // Create optgroups
                                    var branchGroup = $('<optgroup label="Branch"></optgroup>');
                                    var franchiseGroup = $('<optgroup label="Franchise"></optgroup>');
                    
                                    // Append options to the appropriate group
                                    response.data.forEach(function(branch) {
                                        if (branch.branch_type == 1) {
                                            branchGroup.append($('<option></option>').attr('value', branch.sno).text(branch.branch_name));
                                        } else if (branch.branch_type == 2) {
                                            franchiseGroup.append($('<option></option>').attr('value', branch.sno).text(branch.franchise_name));
                                        }
                                    });
                    
                                    // Append the groups to the dropdown
                                    BranchDropdown.append(branchGroup);
                                    BranchDropdown.append(franchiseGroup);
                                    
                                    $('#branchId_edit').val(com.branch_id).change();
                                    setTimeout(() => {
                                    $('#qr_staff_id_edit').val(com.qr_staff_id).change();
                                    }, 2000); // 2-second delay
                                }
                            },
                            error: function(error) {
                                console.error('Error fetching branches:', error);
                            }
                        });
                        
                        $('#promotion_type_edit').val(com.discount_type).change();
                        $('#expiry_date_edit').val(com.expiry_date);
                        
                        $('#desc_edit').val(com.qr_desc);
                        $('#min_value_edit').val(com.min_value);
                        $('#max_value_edit').val(com.max_value);
                        $('#course_id_edit').val(com.course_id).change();
                        
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
  </script>

  <script>
    function EditvalidateForm(){
        var err =0;
        
        var qr_promotion_name_edit = $("#qr_promotion_name_edit").val().trim();
        if (qr_promotion_name_edit === "") {
            if(err==0){
            $('#qr_promotion_name_edit_err').html('Enter Qr Promotion Name  is required...!');
            err++;
            }
        } else {
            $('#qr_promotion_name_edit_err').html('');
        }
        var branchId_edit = $("#branchId_edit").val().trim();
        if (branchId_edit === "") {
            if(err==0){
            $('#branchId_edit_err').html('Select Branch / Franchise is required...!');
            err++;
            }
        } else {
            $('#branchId_edit_err').html('');
        }

        var expiry_date_edit = $("#expiry_date_edit").val().trim();
        if (expiry_date_edit === "") {
            if(err==0){
            $('#expiry_date_edit_err').html('Select Expiry Date is required...!');
            err++;
            }
        } else {
            $('#expiry_date_edit_err').html('');
        }

        var promotion_type_edit = $("#promotion_type_edit").val();
        if (promotion_type_edit === "") {
            if(err==0){
            $('#promotion_type_edit_err').html('Select Promotion Type is required...!');
            err++;
            }
        } else {
            $('#promotion_type_edit_err').html('');
        }

        if(promotion_type_edit==0 || promotion_type_edit == 1){

            var min_value_edit = $("#min_value_edit").val().trim();
            if (min_value_edit < 1 ) {
                if(err==0){
                $('#min_value_edit_err').html('Enter Minimum value is required...!');
                err++;
                }
            } else {
                $('#min_value_edit_err').html('');
            }
            var max_value_edit = $("#max_value_edit").val().trim();
            if (max_value_edit <1) {
                if(err==0){
                $('#max_value_edit_err').html('Enter Maximum value is required...!');
                err++;
                }
            } else {
                $('#max_value_edit_err').html('');
            }
            
            if (parseFloat(min_value) >= parseFloat(max_value)) {
                $('#min_value_edit_err').html('Min value cannot be greater than Max value.');
                err++;
            }

        }else{
            $('#min_value_edit_err').html('');
            $('#max_value_edit_err').html('');
        }
        if(promotion_type_edit==2){
            var course_id_edit = $("#course_id_edit").val().trim();
            if (course_id_edit === "") {
                if(err==0){
                $('#course_id_edit_err').html('Select Course is required...!');
                err++;
                }
            } else {
                $('#course_id_edit_err').html('');
            }
        }else{
            $('#course_id_edit_err').html('');
        }
        
        var qr_staff_id_edit = $("#qr_staff_id_edit").val();
        if (qr_staff_id_edit === "") {
            if(err==0){
                $('#qr_staff_id_edit_err').html('Select Sales Staff is required...!');
                err++;
            }
        } else {
            $('#qr_staff_id_edit_err').html('');
        }

        if(err==0){
            $('#EditForm').submit();
        }
    }
</script>
<script>
    function type_change_edit(val){
        // $('#min_value_edit').val(0);
        // $('#max_value_edit').val(0);
        // $('#course_id_edit').val('').change();
        if(val==0){
            $('.min_max_div_edit').show();
            $('.course_div_edit').hide();
        }else if(val==1){
            $('.min_max_div_edit').show();
            $('.course_div_edit').hide();
        }else if(val==2){
            $('.min_max_div_edit').hide();
            $('.course_div_edit').show();
        }else{
            $('.min_max_div_edit').hide();
            $('.course_div_edit').hide();
        }
    }
</script>
<script>
    // Function to copy coupon code to clipboard dynamically by index
    function copyToClipboard(index) {
        const couponCodeElement = document.getElementById('coup_code_val_td_' + index);
        const couponCodeText = couponCodeElement ? couponCodeElement.innerText : '';

        if (couponCodeText) {
            navigator.clipboard.writeText(couponCodeText).then(function() {
                toastr.success('Coupon code copied to clipboard!');
            }).catch(function(err) {
                toastr.error('Failed to copy coupon code.');
            });
        }
    }
</script>
@endsection
