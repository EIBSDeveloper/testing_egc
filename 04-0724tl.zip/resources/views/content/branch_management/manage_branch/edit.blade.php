@extends('layouts/layoutMaster')

@section('title', 'Update Branch')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

<div class="card mb-2">
    @php
    $helper = new \App\Helpers\Helpers();
    @endphp
    <div class="card-header border-bottom pb-1">
        <h5 class="mb-1 text-black" id="brch_fran_tle">Update Branch</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Branch Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Branch</a>
                </li>
            </ol>
        </nav>
    </div>
</div>
<div class="card">
    <form method="POST" action="{{ route('update_branch_franchise') }}" enctype="multipart/form-data" autocomplete="off" id="branch_form">
    @csrf
    <div class="card-body mb-2 px-4 pb-2">
        <div class="row mb-6">
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Company<span class="text-danger">*</span></label>
                <select class="select3 form-select" name="company_id" id="company_id">
                    <option value="">Select Company</option>
                </select>
                <div class="text-danger" id="company_id_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Entity<span class="text-danger">*</span></label>
                <select class="select3 form-select" name="entity_id" id="entity_id">
                    <option value="">Select Entity</option>
                </select>
                <div class="text-danger" id="entity_id_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <div class="form-check form-check-inline mt-4">
                    <input class="form-check-input" type="radio" name="brch_fran_chk" id="branch_chk" @if ($edit->branch_type == 1) checked @endif value="option1"
                    onchange="branch_franchise_func(1);" />
                    <label class="form-check-label fs-5 fw-bold" for="branch_chk">Branch</label>
                </div>
                <div class="form-check form-check-inline mt-4">
                    <input class="form-check-input" type="radio" name="brch_fran_chk" id="franchise_chk" @if ($edit->branch_type == 2) checked @endif
                    onchange="branch_franchise_func(2);" />
                    <label class="form-check-label fs-5 fw-bold" for="franchise_chk">Franchise</label>
                </div>
                <input type="hidden" name="branch_franc" id="branch_franc">
                <input type="hidden" name="edit_sno" id="edit_sno" value="{{ $edit->sno }}">
            </div>
            <div class="col-lg-4 mb-3" id="branch_tbox">
                <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="70" placeholder="Enter Branch Name" id="branch_name" name="branch_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" value="{{ $edit->branch_name ?? '' }}" />
                <div class="text-danger" id="branch_name_err"></div>
            </div>
            <div class="col-lg-4 mb-3" id="bussiness_tbox" style="display: none;">
                <label class="text-black mb-1 fs-6 fw-semibold">Business Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="70" placeholder="Enter Business Name" id="business_name" name="business_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"  value="{{ $edit->business_name ?? '' }}" />
                <div class="text-danger" id="business_name_err"></div>
            </div>
            <div class="col-lg-4 mb-3" id="fran_tbox" style="display: none;">
                <label class="text-black mb-1 fs-6 fw-semibold">Franchise Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="70" placeholder="Enter Franchise Name" id="franchise_name" name="franchise_name"  oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" value="{{ $edit->franchise_name ?? '' }}" />
                <div class="text-danger" id="franchise_name_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Branch Category<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="branch_category" name="branch_category">
                    <option value="">Select Branch Category</option>
                    @php
                    $get_branch_category_list = $helper->get_branch_category_list();
                    @endphp
                    @foreach ($get_branch_category_list as $br_list)
                    <option value="{{ $br_list->sno }}" @if ($br_list->sno == $edit->branch_category) selected
                        @endif>
                        {{ $br_list->branchtype_name }}</option>
                    @endforeach
                </select>
                <div class="text-danger" id="branch_category_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="countryId" name="country">
                    <option value="">Select Country</option>
                </select>
                <div class="text-danger" id="countryId_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="stateId" name="state">
                    <option value="">Select State</option>
                </select>
                <div class="text-danger" id="stateId_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="cityId" name="city">
                    <option value="">Select City</option>
                </select>
                <div class="text-danger" id="cityId_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Area / Street" id="area_street" name="area_street" value="{{ $edit->area_street ?? '' }}" maxlength="70"/>
                <div class="text-danger" id="area_street_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Door/Flat No" id="door_flat_no" name="door_flat_no"  value="{{ $edit->door_no ?? '' }}" maxlength="70"/>
                <div class="text-danger" id="door_flat_no_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Pincode"
                    maxlength="7" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                    id="pincode" name="pincode" value="{{ $edit->pincode ?? '' }}" />
                <div class="text-danger" id="pincode_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">City Short Code<span class="text-danger">*</span></label>
                    @php
                    $variable = $edit->city_short_code;
                    $letters_only = preg_replace('/[^a-zA-Z]/', '', $variable);
                    @endphp
                <input type="text" class="form-control" placeholder="Enter City Short Code"  maxlength="3" id="city_short_code"  name="city_short_code" oninput="this.value = this.value.toUpperCase().replace(/[^a-zA-Z]/g, '');" value="{{ $letters_only ?? '' }}" readonly />
                <div class="text-danger" id="city_short_code_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Call Tracker Company ID</label>
                <input type="text" class="form-control" placeholder="Enter Call Tracker Company ID" maxlength="2" id="call_tracker_id" name="call_tracker_id" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" value="{{ $edit->call_tracker_branch_id }}" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Business Mobile No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Business Mobile No" id="business_mobile_no" name="business_mobile_no" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" value="{{ $edit->mobile ?? '' }}" />
                <div class="text-danger" id="business_mobile_no_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Business Email ID<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Business Email ID" id="business_email_id" name="business_email_id" oninput=" this.value = this.value.toLowerCase();" value="{{ $edit->mail ?? '' }}" />
                <div class="text-danger" id="business_email_id_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Communication Email ID<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Communication Email ID" id="comm_email_id" name="comm_email_id"  oninput=" this.value = this.value.toLowerCase();" value="{{ $edit->comm_email_id ?? '' }}"/>
                <div class="text-danger" id="comm_email_id_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Location URL<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Location URL" id="location_url" name="location_url" value="{{ $edit->location ?? '' }}" maxlength="150"/>
                <div class="text-danger" id="location_url_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Website URL"  id="website_url" name="website_url" value="{{ $edit->website ?? '' }}" maxlength="100"/>
                <div class="text-danger" id="website_url_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Facebook Link</label>
                <input type="text" class="form-control" placeholder="Enter Facebook Link" id="fb_link" name="fb_link" value="{{ $edit->fb_link ?? '' }}" maxlength="70"/>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Instagram Link</label>
                <input type="text" class="form-control" placeholder="Enter Instagram Link" id="insta_link" name="insta_link" value="{{ $edit->insta_link ?? '' }}" maxlength="70"/>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Just Dial Branch Code</label>
                <input type="text" class="form-control" placeholder="Enter Just Dial Branch Code"  id="just_dial_id" name="just_dial_id" value="{{ $edit->just_dial_id ?? '' }}" maxlength="50"/>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Other Source Lead Staff</label> 
                <select class="select3 form-select" id="other_src_staff_id" name="other_src_staff_id">
                    <option value="">Select Other Source Lead Staff</option>
                    @php
                    $get_branch_staff_list = $helper->get_branch_sales_staff_list(auth()->user()->branch_id);
                    @endphp
                    @foreach ($get_branch_staff_list as $st_list)
                    <option value="{{ $st_list->sno }}" @if($edit->other_src_staff_id == $st_list->sno) selected @endif>
                        {{ $st_list->staff_name }} - {{ $st_list->job_position_name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                <input type="text" class="form-control" placeholder="Enter CIN No"  id="tax_no" name="tax_no"   value="{{ $edit->tax_no ?? '' }}" maxlength="20"/>
            </div>
             <div class="col-lg-4 mb-2">
                <div class="form-check form-check-inline mt-4">
                    <input class="form-check-input me-0" type="checkbox" id="gst_check" name="gst_check"
                        value="1" @if($edit->gst_check == 1 ) checked @endif/>
                    <label class="text-dark mb-1 fs-6 fw-semibold">GST Inclusive</label>
                </div>
            </div>
            <div class="col-lg-4 mb-2">
                <label class="text-dark mb-1 fs-6 fw-semibold">GST Percentage<span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control" id="gst_percentage" name="gst_percentage"
                    placeholder="Enter GST No" oninput="validateInterest(this)" value="{{ $edit->gst_percentage ?? 0 }}" />
                    <div class="text-danger" id="gst_percentage_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                <input type="text" class="form-control" placeholder="Enter GST No" id="gst_no" name="gst_no" value="{{ $edit->gst_no ?? '' }}" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Pan No</label>
                <input type="text" class="form-control" placeholder="Enter Pan No" id="pan_no" name="pan_no" value="{{ $edit->pan_no ?? '' }}" />
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Share (as %)<span class="text-danger">*</span></label>
                <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Share For Brand In Percentage"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                <input type="text" class="form-control" placeholder="Enter Share (as %)"  id="share_percentage" name="share_percentage"
                    maxlength="2" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" value="{{ $edit->share_percentage ?? '' }}" />
                <div class="text-danger" id="share_percentage_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Agreement Start Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="agree_stdt" name="share_start_date" placeholder="Select Date" class="form-control common_date_class" value="{{ $edit->share_start_date ? date('d-M-Y', strtotime($edit->share_start_date)) : '' }}">
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Agreement End Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="agree_eddt" name="share_end_date" placeholder="Select Date" class="form-control common_date_class" value="{{ $edit->opening_date ? date('d-m-Y', strtotime($edit->opening_date ?? date('d-m-Y'))) :'' }}"  >
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Opening Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="open_dt" name="opening_date" placeholder="Select Date" class="form-control common_date_class" value="{{ $edit->opening_date ? date('d-m-Y', strtotime($edit->opening_date ?? date('d-m-Y'))) :'' }}">
                </div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Latitude<span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="latitude" name="latitude" placeholder="Enter Latitude" value="{{ $edit->latitude ?? '' }}" maxlength="30"/>
                <div class="text-danger" id="latitude_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Longitude<span class="text-danger">*</span></label>
                <input type="text" class="form-control"  id="longitude" name="longitude" placeholder="Enter Longitude" value="{{ $edit->longitude ?? '' }}" maxlength="30"/>
                <div class="text-danger" id="longitude_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Time Zone<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="time_zone" name="time_zone">
                    <option value="">Select Time Zone</option>
                </select>
                <div class="text-danger" id="time_zone_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Currency Format<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="currency_format" name="currency_format">
                    <option value="">Select Currency Format</option>
                </select>
                <div class="text-danger" id="currency_format_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Task Working Hours</label>
                <input type="text" class="form-control" id="task_working_hours" name="task_working_hours" value="{{ $edit->task_working_hours ?? '' }}"
                    placeholder="Enter Task Working Hours" 
                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="2" />
            </div>

        </div>
        <div class="divider">
            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Collection Info</div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Collection Closing Date<span class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="cllt_cl_dt" name="collection_close" placeholder="Select Date" class="form-control common_date_class" value="{{ $edit->collection_close ? date('d-m-Y', strtotime($edit->collection_close ?? date('d-m-Y'))) :''}}">
                </div>
                <div class="text-danger" id="cllt_cl_dt_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Registeration Closing Date<span class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="reg_cl_dt" name="registeration_close" placeholder="Select Date" class="form-control common_date_class" value="{{$edit->registeration_close ? date('d-m-Y', strtotime($edit->registeration_close ?? date('d-m-Y'))) :'' }}" >
                </div>
                <div class="text-danger" id="reg_cl_dt_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Minimum Product Cost (MPC) Value<span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="10" placeholder="Enter Minimum Product cost" id="min_product_cost" value={{ $edit->min_prd_cost }}
                    name="min_product_cost" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                <div class="text-danger" id="min_product_cost_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">MPC Validity (In Days)<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="2" placeholder="Enter Minimum Product Cost Validity" id="mpc_validity" value="{{ $edit->min_prd_days }}"
                    name="mpc_validity" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                <div class="text-danger" id="mpc_validity_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Last Payment (In %)<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="10" placeholder="Enter Last Payment" id="last_payment" name="last_payment" value="{{ $edit->last_payment }}"
                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                <div class="text-danger" id="last_payment_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount Receive<span class="text-danger">*</span></label>
                <input type="text" class="form-control" maxlength="10" placeholder="Enter Minimum Amount Receive" id="min_amnt_receive" name="min_amnt_receive" value="{{ $edit->min_amnt_receive }}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                <div class="text-danger" id="min_amnt_receive_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <input class="form-check-input" type="checkbox" id="bus_cls_dt" name="bus_closing_chk_month" value="1" @if ($edit->bus_closing_month_end == 1) checked @endif  onclick="bus_cls_dt_func();">
                <label class="text-black mb-1 fs-6 fw-semibold" id="bus_cls_dt_txt">Business Closing Date (In Count) <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="bus_cls_dt_tbox" maxlength="2" name="bus_closing_day_count" placeholder="Enter Business Closing Date(In Count)" value="{{$edit->bus_closing_day_count??''}}" style="display: block !important;" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                <div class="text-danger" id="bus_cls_dt_tbox_err"></div>
            </div>
        </div>
        <div class="divider">
            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Bank Name" id="bank_name" name="bank_name" value="{{ $edit->bank_name ?? '' }}" maxlength="70"/>
                <div class="text-danger" id="bank_name_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Bank Branch Name" id="bank_branch" name="bank_branch" value="{{ $edit->bank_branch ?? '' }}" maxlength="70"/>
                <div class="text-danger" id="bank_branch_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Account Holder" id="bank_holder" name="bank_holder" value="{{ $edit->bank_holder ?? '' }}" maxlength="70"/>
                <div class="text-danger" id="bank_holder_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Account No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Account No" maxlength="18" id="bank_account_no" name="bank_account_no" value="{{ $edit->bank_account_no ?? '' }}" maxlength="20"/>
                <div class="text-danger" id="bank_account_no_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter IFSC Code" id="bank_ifsc" name="bank_ifsc" value="{{ $edit->bank_ifsc ?? '' }}" maxlength="50"/>
                <div class="text-danger" id="bank_ifsc_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Swift Code<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Swift Code" id="swift_code" name="swift_code" value="{{ $edit->bank_swift_code }}"
                    maxlength="70" />
                <div class="text-danger" id="swift_code_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">UPI ID<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter UPI ID" id="upi_id" name="upi_id" maxlength="70" value="{{ $edit->bank_upi_id }}" />
                <div class="text-danger" id="upi_id_err"></div>
            </div>
            
        </div>
        <div class="divider">
            <div class="text-black mb-4 fs-5 fw-semibold divider-text">API Details</div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-8 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Cloud Call API Key</label>
                <textarea class="form-control" rows="1" placeholder="Enter Cloud Call API Key" id="cloud_call_api_key" name="cloud_call_api_key" maxlength="150">{{ $edit->cloud_call_api_key ?? '' }}</textarea>
            </div>
        </div>
        <div class="row mb-6">
            <div class="col-lg-8 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                <textarea class="form-control h-auto" placeholder="Enter Description" id="api_desc" name="api_desc" maxlength="180">{{ $edit->branch_desc ?? '' }}</textarea>
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2">
            <a href="{{url('/branch')}}" class="btn fw-bold btn-secondary me-3">Cancel</a>
            <button type="button" class="btn fw-bold btn-primary"  id="brch_fran_butt" onclick="branch_validate()">
                Update Branch
            </button>
        </div>
    </div>
    </form>
</div>




<!--begin::Modal - Update Branch-->
<div class="modal fade" id="kt_modal_update_branch" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                <span id="create_label"> Update Branch </span> ?
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <a href="{{url('/branch')}}" class="btn fw-bold btn-primary me-3">Yes</a>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Branch-->



<script>

    function previewQrImage(input) {
        const file = input.files[0];
        if (!file) return;

        const allowedTypes = ['image/jpeg', 'image/png'];
        if (!allowedTypes.includes(file.type)) {
            $('#qr_code_image_err').text('Only JPG and PNG files are allowed.');
            return;
        }

        if (file.size > 800 * 1024) {
            $('#qr_code_image_err').text('File size should not exceed 800KB.');
            return;
        }

        $('#qr_code_image_err').text('');
        const reader = new FileReader();
        reader.onload = function (e) {
            $('#qr_code_preview').attr('src', e.target.result);
            $('#qr_code_name').text(file.name);
        };
        reader.readAsDataURL(file);
    }

    function resetQrImage() {
        $('#qr_code_image').val('');
        $('#qr_code_preview').attr('src', "{{ asset('assets/phdizone_images/def_img.png') }}");
        $('#qr_code_name').text('');
        $('#qr_code_image_err').text('');
    }

    function submit_form() {
        $('#branch_form').submit();
    }

    function branch_validate() {
        // Get input values
        var company_id = $('#company_id').val();
        var entity_id = $('#entity_id').val();
        var branch_name = $('#branch_name').val();
        var business_name = $('#business_name').val();
        var franchise_name = $('#franchise_name').val();
        var branch_category = $('#branch_category').val();
        var country = $('#countryId').val();
        var state = $('#stateId').val();
        var city = $('#cityId').val();
        var area_street = $('#area_street').val();
        var door_flat_no = $('#door_flat_no').val();
        var pincode = $('#pincode').val();
        var city_short_code = $('#city_short_code').val();
        var business_mobile_no = $('#business_mobile_no').val();
        var business_email_id = $('#business_email_id').val();
        var comm_email_id = $('#comm_email_id').val();
        var location_url = $('#location_url').val();
        var website_url = $('#website_url').val();
        var share_percentage = $('#share_percentage').val();
        var latitude = $('#latitude').val();
        var longitude = $('#longitude').val();
        var time_zone = $('#time_zone').val();
        var currency_format = $('#currency_format').val();
        var cllt_cl_dt = $('#cllt_cl_dt').val();
        var reg_cl_dt = $('#reg_cl_dt').val();
        var min_amnt_receive = $('#min_amnt_receive').val();
        var bus_cls_dt_tbox = $('#bus_cls_dt_tbox').val();
        var bank_name = $('#bank_name').val();
        var bank_branch = $('#bank_branch').val();
        var bank_holder = $('#bank_holder').val();
        var bank_account_no = $('#bank_account_no').val();
        var bank_ifsc = $('#bank_ifsc').val();
        var minimumProductCost = $('#min_product_cost').val();
        var mpcValidity = $('#mpc_validity').val();
        var lastPayment = $('#last_payment').val();



        // Clear previous error messages
        $('#company_id_err').text('');
        $('#entity_id_err').text('');
        $('#branch_name_err').text('');
        $('#business_name_err').text('');
        $('#franchise_name_err').text('');
        $('#branch_category_err').text('');
        $('#countryId_err').text('');
        $('#stateId_err').text('');
        $('#cityId_err').text('');
        $('#area_street_err').text('');
        $('#door_flat_no_err').text('');
        $('#pincode_err').text('');
        $('#city_short_code_err').text('');
        $('#min_product_cost_err').text('');
        $('#mpc_validity_err').text('');
        $('#last_payment_err').text('');
       
        

        let err = false;

            if (company_id === '') {
                $('#company_id_err').text('Company Name is required.');
                err = true;
            }
            if (entity_id === '') {
                $('#entity_id_err').text('Entity Name is required.');
                err = true;
            }

        
        var branch_chk = document.getElementById("branch_chk");
        if (branch_chk.checked) {
            if (branch_name === '') {
                $('#branch_name_err').text('Branch Name is required.');
                err = true;
            }
            
        } else {
            if (business_name === '') {
                $('#business_name_err').text('Business Name is required.');
                err = true;
            }
            if (franchise_name === '') {
                $('#franchise_name_err').text('Franchise Name is required.');
                err = true;
            }
        }
        // Validate required fields
       
        if (branch_category === '') {
            $('#branch_category_err').text('Branch Category is required.');
            err = true;
        }
        if (country === '') {
            $('#countryId_err').text('Country is required.');
            err = true;
        }
        if (state === '') {
            $('#stateId_err').text('State is required.');
            err = true;
        }
        if (city === '') {
            $('#cityId_err').text('City is required.');
            err = true;
        }
        if (area_street === '') {
            $('#area_street_err').text('Area Street is required.');
            err = true;
        }
        if (door_flat_no === '') {
            $('#door_flat_no_err').text('Door Flat No is required.');
            err = true;
        }
        if (pincode === '') {
            $('#pincode_err').text('Pincode is required.');
            err = true;
        }

        if (city_short_code === '') {
            $('#city_short_code_err').text('City Short code is required.');
            err = true;
        }

        if (business_mobile_no === '') {
            $('#business_mobile_no_err').text('Business Mobile Number is required.');
            err = true;
        }else{
            $('#business_mobile_no_err').text('');
        }

        if (business_email_id === '') {
            $('#business_email_id_err').text('Business Email is required.');
            err = true;
        }else{
            if (business_email_id !== '' && !/^\S+@\S+\.\S+$/.test(business_email_id)) {
                err = true;
                 $('#business_email_id_err').text('Enter a valid Email ID.');
            }else{
                $('#business_email_id_err').text('');
            }
        }

        if (comm_email_id === '') {
            $('#comm_email_id_err').text('Communication Email is required.');
            err = true;
        }else{
            if (comm_email_id !== '' && !/^\S+@\S+\.\S+$/.test(comm_email_id)) {
                err = true;
                 $('#comm_email_id_err').text('Enter a valid Email ID.');
            }else{
                $('#comm_email_id_err').text('');
            }
            
        }

        if (location_url === '') {
            $('#location_url_err').text('Location Url is required.');
            err = true;
        }else{
            $('#location_url_err').text('');
        }

        if (website_url === '') {
            $('#website_url_err').text('Website Url is required.');
            err = true;
        }else{
            $('#website_url_err').text('');
        }
        var gst_percentage = $("#gst_percentage").val().trim();
        if (gst_percentage === '' || gst_percentage <= 0) {
            $('#gst_percentage_err').text('GST Percentage is required.');
            err = true;
        }else{
            $('#gst_percentage_err').text('');
        }

        if (share_percentage === '') {
            $('#share_percentage_err').text('Share Percentage is required.');
            err = true;
        }else{
            $('#share_percentage_err').text('');
        }

        if (latitude === '') {
            $('#latitude_err').text('latitude is required.');
            err = true;
        }else{
            $('#latitude_err').text('');
        }

        if (longitude === '') {
            $('#longitude_err').text('Longitude is required.');
            err = true;
        }else{
            $('#longitude_err').text('');
        }

        if (time_zone === '') {
            $('#time_zone_err').text('Time Zone is required.');
            err = true;
        }else{
            $('#time_zone_err').text('');
        }
        if (currency_format === '') {
            $('#currency_format_err').text('Currency Format is required.');
            err = true;
        }else{
            $('#currency_format_err').text('');
        }
        if (cllt_cl_dt === '') {
            $('#cllt_cl_dt_err').text('Collection Closing Date is required.');
            err = true;
        }else{
            $('#cllt_cl_dt_err').text('');
        }
        if (reg_cl_dt === '') {
            $('#reg_cl_dt_err').text('Registeration Closing Date is required.');
            err = true;
        }else{
            $('#reg_cl_dt_err').text('');
        }
        if (min_amnt_receive === '') {
            $('#min_amnt_receive_err').text('Minimum Amount Receive is required.');
            err = true;
        }else{
            $('#min_amnt_receive_err').text('');
        }
        var bus_cls_dt = document.getElementById("bus_cls_dt");
        if(!bus_cls_dt.checked){
            if (bus_cls_dt_tbox === '') {
                $('#bus_cls_dt_tbox_err').text('Business Closing Date Count is required.');
                err = true;
            }else{
                $('#bus_cls_dt_tbox_err').text('');
            }
        }else{
            $('#bus_cls_dt_tbox_err').text('');
        }

        if(minimumProductCost === '') {
                $('#min_product_cost_err').text('Minimum Product Cost is required.');
                err = true;
            } else {
                $('#min_product_cost_err').text('');
            }

            if(lastPayment === '') {
                $('#last_payment_err').text('Last Payment is required.');
                err = true;
            } else {
                $('#last_payment_err').text('');
            }

            if(mpcValidity === '') {
                $('#mpc_validity_err').text('MPC Validity is required.');
                err = true;
            } else {
                $('#mpc_validity_err').text('');
            }
        
        if (bank_name === '') {
            $('#bank_name_err').text('Bank Name is required.');
            err = true;
        }else{
            $('#bank_name_err').text('');
        }
        if (bank_branch === '') {
            $('#bank_branch_err').text('Bank Branch Name is required.');
            err = true;
        }else{
            $('#bank_branch_err').text('');
        }
        if (bank_holder === '') {
            $('#bank_holder_err').text('Account Holder is required.');
            err = true;
        }else{
            $('#bank_holder_err').text('');
        }
        if (bank_account_no === '') {
            $('#bank_account_no_err').text('Account No is required.');
            err = true;
        }else{
            $('#bank_account_no_err').text('');
        }
        if (bank_ifsc === '') {
            $('#bank_ifsc_err').text('IFSC Code is required.');
            err = true;
        }else{
            $('#bank_ifsc_err').text('');
        }

          var swiftCode = $('#swift_code').val().trim();
            var upiId = $('#upi_id').val().trim();
            if(!swiftCode) {
                $('#swift_code_err').text('Swift Code is required.');
                err = true;
            }

            if(!upiId) {
                $('#upi_id_err').text('UPI ID is required.');
                err = true;
            }
            
        
        if (!err) {
            var val = $('#branch_franc').val();
            if (val == 1) {
                var types = 'Branch';
                var name = $('#branch_name').val();
            } else if (val == 2) {
                var types = 'Franchise';
                var name = $('#franchise_name').val();
            }
            
        $('#branch_form').submit()
        } else {
        return false;
        }
  
    }

 </script>

<script>
    bus_cls_dt_func()
    function bus_cls_dt_func() {
        var bus_cls_dt = document.getElementById("bus_cls_dt");
        var bus_cls_dt_txt = document.getElementById("bus_cls_dt_txt");
        var bus_cls_dt_tbox = document.getElementById("bus_cls_dt_tbox");

        if (bus_cls_dt.checked) {
            bus_cls_dt_txt.innerHTML = "Business Closing Date is Month End";
            bus_cls_dt_tbox.style.setProperty("display", "none", "important");
        } else {
            bus_cls_dt_txt.innerHTML = "Business Closing Date (In Count) <span class='text-danger'>*</span>";
            bus_cls_dt_tbox.style.setProperty("display", "block", "important");
        }
    }
</script>

<script>
      $(document).ready(function() {

        var company_id_edit ={{$edit->company_id ?? '0'}};
        var entity_id_edit ={{$edit->entity_id ?? '0'}};
        var country_id_edit ={{$edit->country_id ?? '0'}};
        var state_id_edit ={{$edit->state_id ?? '0'}};
        var city_id_edit ={{$edit->city_id ?? '0'}};
        var time_zone_id_edit ={{$edit->time_zone_id ?? '0'}};
        var currency_id_edit ={{$edit->currency_id ?? '0'}};
        var branch_type_edit ={{$edit->branch_type ?? '1'}};

            $.ajax({
                url: "{{ route('company_list') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('#company_id');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Company</option>');
                        response.data.forEach(function(country) {
                            countryDropdown.append($('<option></option>').attr('value', country.sno).text(country.company_name));
                        });
                        if(company_id_edit){
                            countryDropdown.val(company_id_edit).trigger('change');
                        }
                        // countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });

            $('#company_id').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#entity_id');

                stateDropdown.empty().append('<option value="">Select Entity</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: { company_id: countryId },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr('value', state.sno).text(state.entity_name));
                                });
                                if(entity_id_edit){
                                    stateDropdown.val(entity_id_edit).trigger('change'); 
                                }
                                // stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });

            // Fetch and populate countries
            $.ajax({
                url: "{{ route('country') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('#countryId');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Country</option>');
                        response.data.forEach(function(country) {
                            countryDropdown.append($('<option></option>').attr('value', country.id).text(country.name));
                        });
                        if(country_id_edit){
                            countryDropdown.val(country_id_edit).trigger('change');
                        }
                        // countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });
            // Event listener for country change
            $('#countryId').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#stateId');

                stateDropdown.empty().append('<option value="">Select State</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('state') }}",
                        type: "GET",
                        data: { country_id: countryId },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                                });
                                if(state_id_edit){
                                    stateDropdown.val(state_id_edit).trigger('change');
                                }
                                // stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });

            // state change
            $('#stateId').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#cityId');

                stateDropdown.empty().append('<option value="">Select City</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('city') }}",
                        type: "GET",
                        data: { state_id: countryId },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                                });
                                if(city_id_edit){
                                    stateDropdown.val(city_id_edit).trigger('change');
                                }
                                // stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });

            $.ajax({
                url: "{{ route('time_zone') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched time zones
                        var selectDropdown = $('select[name="time_zone"]');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="" >Select Time Zone</option>'));
                        response.data.forEach(function(t) {
                            var optionText = t.country_name + " (UTC " + t.utc_offset + ")";
                            var optionElement = $('<option></option>').attr('value', t.sno)
                                .text(optionText);
                            selectDropdown.append(optionElement);
                        });
                        if(time_zone_id_edit){
                            selectDropdown.val(time_zone_id_edit).trigger('change');
                        }
                    }
                },
                error: function(error) {
                    console.error('Error fetching time zones:', error);
                }
            });

            $.ajax({
                url: "{{ route('currency_format') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched time zones
                        var selectDropdown = $('select[name="currency_format"]');
                        selectDropdown.empty();
                        selectDropdown.append($('<option value="">Select Currency Format</option>'));
                        response.data.forEach(function(t) {
                            var optionText = t.currency_code + " - " + t.currency_symbol;
                            var optionElement = $('<option></option>').attr('value', t.sno)
                                .text(optionText);
                            selectDropdown.append(optionElement);
                        });
                        if(currency_id_edit){
                            selectDropdown.val(currency_id_edit).trigger('change');
                        }
                
                    }
                },
                error: function(error) {
                    console.error('Error fetching time zones:', error);
                }
            });
      });
 </script>

<script>

branch_franchise_func({{ $edit->branch_type ?? 1 }})

    function branch_franchise_func(val) {
        if (val == '2') {
            var name = $('#branch_name').val();
            document.getElementById("branch_tbox").style.display = "none";
            document.getElementById("bussiness_tbox").style.display = "block";
            document.getElementById("fran_tbox").style.display = "block";
            document.getElementById("brch_fran_tle").innerHTML = "Update  Franchise";
            document.getElementById("brch_fran_butt").innerHTML = "Update Franchise";
            document.getElementById("create_label").innerHTML = "Update ("+name+") Franchise";
              $('#branch_franc').val(val);

        } else {
            var name = $('#franchise_name').val();
            document.getElementById("branch_tbox").style.display = "block";
            document.getElementById("bussiness_tbox").style.display = "none";
            document.getElementById("fran_tbox").style.display = "none";
            document.getElementById("brch_fran_tle").innerHTML = "Update Branch";
            document.getElementById("brch_fran_butt").innerHTML = "Update Branch";
            document.getElementById("create_label").innerHTML = "Update ("+name+") Branch";
              $('#branch_franc').val(val);
        }
    }
</script>
<script>
    function validateInterest(input) {
      // Remove non-numeric characters except decimal points
      input.value = input.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');

      // Convert input value to a number
      const value = parseFloat(input.value);

      // Check if value is greater than or equal to 100
      if (value >= 100) {
        input.value = 100; // Set the value to the maximum allowed
      }
    }
  </script>

  <script>
        let debounceTimer;

        function debounce(func, delay) {
            return function() {
                const context = this;
                const args = arguments;
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => func.apply(context, args), delay);
            };
        }

        function checkUniqueField(field, value, errorElementId, submitButtonId) {
            if (value === '') {
                $('#' + errorElementId).text('');
                return;
            }

            let sno = $('#edit_sno').val();

            $.ajax({
                url: '/check-branch-duplicates',
                method: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    field: field,
                    value: value,
                    sno: sno
                },
                success: function(response) {
                    if (response.exists) {
                        $('#' + errorElementId).text(response.message);
                        $('#' + submitButtonId).prop('disabled', true);
                    } else {
                        $('#' + errorElementId).text('');
                        $('#' + submitButtonId).prop('disabled', false);
                    }
                }
            });
        }

        // Bind with debounce
        $('#branch_name').on('input', debounce(function() {
            checkUniqueField('branch_name', $(this).val(), 'branch_name_err', 'brch_fran_butt');
        }, 600));

        $('#franchise_name').on('input', debounce(function() {
            checkUniqueField('franchise_name', $(this).val(), 'franchise_name_err', 'brch_fran_butt');
        }, 600));

    </script>
@endsection