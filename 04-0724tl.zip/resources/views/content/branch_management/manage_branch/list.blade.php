    @extends('layouts/layoutMaster')

@section('title', 'Manage Branch')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')
<style>
    .dataTables_scroll {
        max-height: 300px;
    }

    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }
</style>
            @php
            $helper = new \App\Helpers\Helpers();
            @endphp
@php
    $module_name = 'Branch Management';
    $menu_name   = 'Manage Branch';
@endphp

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Branch</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Branch Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter">
                    <span><i class="mdi mdi-filter-outline"></i></span>
                </a> -->
                @if(auth()->user()->hasPermission($module_name, 'Add', $menu_name))
                <a href="{{ url('/branch/create') }}" class="btn btn-sm fw-bold btn-primary text-white">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Branch
                </a>
                @endif
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="branch_filter mb-4" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Branch Type</label>
                    <select class="select3 form-select">
                        <option value="1">All</option>
                        <option value="2">Branch</option>
                        <option value="3">Franchise</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">City</label>
                    <select class="select3 form-select" multiple>
                        <option value="" selected>All</option>
                        <option value="1">Madurai</option>
                        <option value="2">Virudhunagar</option>
                        <option value="3">Thirunelveli</option>
                        <option value="4">Coimbatore</option>
                        <option value="5">Chennai</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">City Short Code</label>
                    <input type="text" class="form-control" placeholder="Enter City Short Code" maxlength="3" />
                </div>
            </div>
            <div class="d-flex justify-content-end">
                <button class="btn btn-sm btn-primary fw-semibold fs-6">Go</button>
            </div>
        </div>
        <div class="row">
            @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
            <div class="col-lg-12">
                <div class="d-flex justify-content-between align-items-center ">
                    <div class="">
                        @php $perpage_count = $perpage ? $perpage : 10; @endphp
                        <div>
                            <span>Show</span>
                            <br>
                            <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                @php
                                $options = [10, 25, 100, 500]; // Define available options
                                @endphp
                                @php foreach ($options as $option): @endphp
                                <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                    @php echo $option; @endphp
                                </option>
                                @php endforeach; @endphp
                            </select>
                        </div>
                    </div>
                    <div class="">
                        <form id="filter_form" method="POST" action="/branch">
                            @csrf
                            <div class="d-flex align-items-center gap-2">
                                <div class="">
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="1">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <input
                                    type="text"
                                    class="form-control"
                                    id="search_filter" name="search_filter" value="{{ $search_filter ?? "" }}"
                                    placeholder="Enter Branch - Name/Type/Mob.No"
                                />
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" >Search</button>
                            </div>
                        </form>
                    </div>
                </div>
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Branch / Franchise</th>
                            <th class="min-w-100px">Company / Entity</th>
                            <th class="min-w-100px">Address</th>
                            <th class="min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Business Mobile No / Email">Bus. Mob No / Email</th>
                            <th class="min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Center Head Mobile No / Email">C.H. Mob No / Email</th>
                            <th class="min-w-50px">Status</th>
                            <th class="min-w-50px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        @if (isset($Branch_list))
                        @foreach ($Branch_list as $i=> $list)
                        @csrf
                        <tr>
                            <td>
                            @if ($list->branch_type == 1)
                                @php
                                    $branch_name = $list->branch_name;
                                    $branch_type = 'Branch';
                                @endphp
                            @else
                                @php
                                    $branch_name = $list->franchise_name;
                                    $branch_type = 'Franchise';
                                @endphp
                            @endif
                                <div class="text-truncate fs-7 fw-semibold max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $branch_name ?? '' }}">{{ $branch_name ?? '' }}</div>
                                <div class="d-block">
                                    <label class="badge {{ $list->branch_type == '1' ? 'bg-warning text-black' : 'bg-info text-white' }} fs-8  fw-bold">{{$branch_type ??''}}</label>
                                </div>
                            </td>
                            <td>
                                <div class="text-truncate fs-7 fw-semibold max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->company_name ?? 'Elysium Technologies' }}">{{ $list->company_name ?? 'Elysium Technologies' }}</div>
                                <div class="d-block">
                                    <div class="text-dark fs-8 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->entity_name ?? 'PhDiZone' }}">{{ $list->entity_name ?? 'PhDiZone' }}</div>
                                </div>
                            </td>
                            <td>
                            @php
                            $address = [];
                            $address[] = $list->door_no;
                            $address[] = $list->area_street;
                            $address[] =
                            $helper->get_city_data($list->city_id)->name ?? '-';
                            $address[] =
                            $helper->get_state_data($list->state_id)->name ??
                            '-';
                            $address[] =
                            $helper->get_country_data($list->country_id)
                            ->name ?? '-';
                            $address[] = $list->pincode;

                            // Filter out empty values from $address array
                            $address = array_filter($address);

                            // Implode the address components with ', ' separator
                            $address_final = implode(', ', $address);

                            // Trim leading/trailing spaces and commas
                            $address_final = trim($address_final, ', ');

                            // Calculate tooltip length
                            $tooltip_length = 20; // Adjust the length as per your tooltip

                            // Create shortened version of address for tooltip
                            if (strlen($address_final) > $tooltip_length) {
                            $address_hide =
                            substr($address_final, 0, $tooltip_length) .
                            '...';
                            } else {
                            $address_hide = $address_final; // If not longer, show full text
                            }
                            @endphp
                                <div class="fs-7 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $address_final? $address_final : '-'}}">{{ $address_final? $address_final : '-'}}</div>
                                <!-- <div class="text-wrap fs-7 fw-semibold max-w-300px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $address_final? ucwords(strtolower($address_final)) : '-'}}">{{ $address_final? ucwords(strtolower($address_final)) : '-'}}</div> -->
                            </td>
                            <td>
                                <label class="fs-7 fw-semibold text-black">{{ $list->mobile ?? '-' }}</label>
                                <div class="d-block">
                                    <div class="text-dark fs-8 fw-semibold text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->mail ?? '-' }}">{{ $list->mail ?? '-' }}</div>
                                </div>
                            </td>
                            <td>
                                @if($list->mobile != '0')
                                <div class="d-flex align-items-center">
                                    <div class="text-truncate fs-7 fw-semibold max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->centerHead_name ?? '-' }}">{{ $list->centerHead_name ?? '-' }}</div>
                                    <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->centerHead_email ?? '-' }}" class="ms-2"><i class="mdi mdi-email-outline text-dark fs-4"></i></a>
                                </div>
                                <div class="d-block">
                                    <div class="text-dark fs-8 fw-semibold">{{ $list->centerHead_mobile ?? '-' }}</div>
                                </div>
                                @else
                                <div>-</div>
                                @endif
                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input"
                                     {{ $list->status == 0 ?'checked' : '' }} 
                                     onchange="updatelevelStatus('{{ $list->sno }}', this.checked,'{{$branch_type}}')"/>
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                @php
                                  
                                    $encryptedValue = $helper->encrypt_decrypt($list->sno,'encrypt');
                                    $url = url('/hr_management/staff/staff_view/' .$encryptedValue);
                                     $edit_url = url('/edit_branch_franchise/' . $encryptedValue);
                                @endphp
                                <span class="text-end">
                                    @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                    <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_branch" onclick="viewbranch('{{ $list->sno }}')">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="mdi mdi-eye-outline fs-3 text-black"></i></span>
                                    </a>
                                    @endif
                                    <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2" onclick="add_staff_branch('{{ $list->sno }}','{{ $list->branch_type }}')">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Add"><i class="mdi mdi-account-plus-outline fs-3 text-black"></i></span>
                                    </a>
                                    <a class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        @if(auth()->user()->hasPermission($module_name, 'Center Head Assign', $menu_name))
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_center_head_assign"  onclick="assign_centerHead_add('{{ $list->sno }}','{{ $list->authority_id }}')">
                                            <span><i class="mdi mdi-account-group-outline fs-3 text-black me-1"></i></span>
                                            <span>Center Head Assign</span>
                                        </a>
                                        @endif
                                        @if(auth()->user()->hasPermission($module_name, 'Assign CUG', $menu_name))
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_assign_cug_mail" onclick="assign_Cug_func_staff('{{ $list->sno }}')">
                                            <span><i class="mdi mdi-cellphone-message fs-3 text-black me-1"></i></span>
                                            <span>Assign CUG & Mail</span>
                                        </a>
                                        @endif
                                        @if(auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                                        <a href="{{ $edit_url }}" target="_blank" class="dropdown-item">
                                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                            <span>Edit</span>
                                        </a>
                                        @endif
                                        @if(auth()->user()->hasPermission($module_name, 'Delete', $menu_name))
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_branch" onclick="confirmDelete('{{ $list->sno }}', '{{ $branch_name }}', '{{ $branch_type }}')">
                                            <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i></span>
                                            <span>Delete</span>
                                        </a>
                                        @endif
                                    </div>
                                </span>
                            </td>
                        </tr>
                        @endforeach
                        @else
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>No data available</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        @endif
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $Branch_list->appends(request()->except(['page', '_token']))->links() }}
            </div>
            @endif
        </div>
    </div>
</div>



 <!--begin::Modal - View Branch-->
    <div class="modal fade" id="kt_modal_view_branch" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4">
                        <h3 class=" mb-4 text-black text-center" id="view_name">View Branch</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-8 mt-4">
                            <div class="row mb-2">
                                <div class="col-12">
                                    <h3 class="mb-1 text-black fw-semibold" id="view_branchname">-</h3>
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-1 flex-wrap mb-2">

                                <label class="badge bg-secondary text-white fs-6 fw-semibold"  id="view_branchshortcut" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="City Short Code"></label>
                                <label class="text-dark fs-6 fw-semibold ms-1 me-1">|</label>
                                <label class="badge bg-info text-white fs-6 fw-semibold" id="view_openingdate" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Opening Date"></label>
                                <label class="text-dark fs-6 fw-semibold ms-1 me-1">|</label>
                                <a href="javascript:;" target="_blank"
                                    class="bg-label-primary rounded px-2 py-1 me-1" id="view_facebooklink" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Facebook Link">
                                    <i class="mdi mdi-facebook mdi-24px"></i>
                                </a>
                                <a href="javascript:;" target="_blank"
                                    class="bg-label-primary rounded px-2 py-1 me-1" id="view_instalink" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Instagram Link">
                                    <i class="mdi mdi-instagram mdi-24px"></i>
                                </a>
                                <a href="javascript:;" target="_blank"
                                    class="bg-label-primary rounded px-2 py-1 me-1" id="view_websitelink" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Website Link">
                                    <i class="mdi mdi-web mdi-24px"></i>
                                </a>
                            </div>
                            <div class="d-flex align-items-center gap-1 mb-1">
                                <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Location URL">
                                    <a href="javascript:;" target="_blank" id="view_location_href">
                                        <div >
                                            <span class="me-1"><i
                                                    class="mdi mdi-map-marker-outline fs-3 text-dark"></i></span>
                                            <span id="view_location" class="text-truncate w-99 text-primary fs-6 fw-bold"></span>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-1 mb-2">
                                <div class="text-truncate max-w-650px text-dark fs-6 fw-bold" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Latitude">
                                    <span class="me-1"><i class="mdi mdi-latitude fs-3 text-dark"></i></span>
                                    <span id="view_latitude"></span>
                                </div>
                                <label class="text-dark fs-6 fw-semibold ms-1 me-1">|</label>
                                <div class="text-truncate max-w-650px text-dark fs-6 fw-bold" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Longitude">
                                    <span class="me-1"><i class="mdi mdi-longitude fs-3 text-dark"></i></span>
                                    <span id="view_longitude"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 mt-2">
                            <div class="divider mb-0">
                                <div class="text-black mb-1 fs-4 fw-semibold divider-text">Center Head Details</div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-12">
                                    <div class="d-flex align-items-center justify-content-start">
                                        <div class="align-items-center me-2">
                                            <img src="{{ asset('assets/phdizone_images/user_2.png') }}" alt="user"
                                                class="w-80px h-80px rounded">
                                        </div>
                                        <div class="mb-0">
                                            <label class="fs-4 fw-semibold text-black">-</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-6 fw-semibold" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Mobile No">-</label>
                                            </div>
                                            <div class="d-block">
                                                <label class="text-primary fs-7 fw-semibold" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Position">Center Head</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr class="mt-2 mb-2">
                    <div class="row">
                        <div class="col-lg-6 mt-4">
                            <!-- <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Franchise</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Phdizone Virudhunagar">Phdizone Virudhunagar</div>
                                </div>
                            </div> -->
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Company</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_company" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"  ></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Entity</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_entity" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" ></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold"  data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Call Tracker Company ID">Call Tracker C.ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_calltrackercid"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Business Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_businessmobile"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Business Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_businessemailid" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Communication Email ID">Comm. Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_commemailid" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-4">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Share (as %)<span
                                            class="text-danger">*</span></label>
                                    <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                        title="Share For Brand In Percentage"><i
                                            class="mdi mdi mdi-help-circle text-dark"></i></a>
                                </div>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_shareasperc"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Agreement Start Date">Agreement St. Date</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_agreementstdate"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Agreement End Date</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold"id="view_agreementenddate"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Time Zone</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_timezone" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_address" style="word-wrap: break-word;"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Just Dial Branch Code">Just Dial B.Code</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_justdialbcode" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom">
                                       </div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">CIN No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_cinno" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom">
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">GST Type - (%)</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_gsttype">Inclusive &nbsp;-&nbsp; </label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">GST No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_gstno" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Pan No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_panno" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Tax No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_taxno" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Currency Format</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_currencyformat">INR  &#8377;</label>
                            </div>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-4 fw-semibold divider-text">Collection Info</div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Collection Closing Date">Collection Closing
                                    Dt</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_collectionclosing"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Registeration Closing Date">Registeration
                                    Cl.Date</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_registrationcldate"></label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Min. Amount Receive</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_minamountreceive">&#8377; </label>
                            </div>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Bank</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_bank"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Branch</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_branch"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">IFSC Code</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_ifsccode"></label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Account Holder</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_accountholder"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Account No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_accountno"></label>
                            </div>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">API Details</div>
                    </div>
                    <div class="row mb-6">
                        <label class="col-2 text-dark fs-6 fw-semibold">Cloud Call API Key</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-9 text-black fs-6 fw-bold" id="view_cloudcallapikey"></label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Description</label>
                        <label class="col-12 text-black fs-6 fw-bold" id="view_description">&emsp;&emsp;&emsp; </label>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Communication Details</div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 comm_table">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communication Staff</th>
                                        <th class="min-w-150px">Position</th>
                                        <th class="min-w-100px">Mobile No</th>
                                        <th class="min-w-100px">Email ID</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <!--<tr>-->
                                    <!--    <td>-->
                                    <!--        <div class="d-flex align-items-center justify-content-start">-->
                                    <!--            <div class="border border-gray-400i rounded me-2">-->
                                    <!--                <img src="{{ asset('assets/phdizone_images/staff_1.png') }}"-->
                                    <!--                    alt="user" class="w-50px h-50px rounded">-->
                                    <!--            </div>-->
                                    <!--            <div class="mb-0">-->
                                    <!--                <div class="text-truncate max-w-175px fs-7 fw-semibold text-black"-->
                                    <!--                    data-bs-toggle="tooltip" data-bs-placement="bottom"-->
                                    <!--                    title="Anusha E">Anusha E</div>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--    </td>-->
                                    <!--    <td>Process Co-Ordinator (PC)</td>-->
                                    <!--    <td>8870200389</td>-->
                                    <!--    <td>presale@phdizone.com</td>-->
                                    <!--</tr>-->
                                    <!--<tr>-->
                                    <!--    <td>-->
                                    <!--        <div class="d-flex align-items-center justify-content-start">-->
                                    <!--            <div class="border border-gray-400i rounded me-2">-->
                                    <!--                <img src="{{ asset('assets/phdizone_images/staff_3.png') }}"-->
                                    <!--                    alt="user" class="w-50px h-50px rounded">-->
                                    <!--            </div>-->
                                    <!--            <div class="mb-0">-->
                                    <!--                <div class="text-truncate max-w-175px fs-7 fw-semibold text-black"-->
                                    <!--                    data-bs-toggle="tooltip" data-bs-placement="bottom"-->
                                    <!--                    title="Monisha K">Monisha K</div>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--    </td>-->
                                    <!--    <td>Sales Executive (SE)</td>-->
                                    <!--    <td>9677722623</td>-->
                                    <!--    <td>presale@phdizone.com</td>-->
                                    <!--</tr>-->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Branch-->

<!--begin::Modal - Delete Branch-->
<div class=" modal fade" id="kt_modal_delete_branch" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                <span id="delete_message"></span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" onclick="deletebranch()">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Branch-->

<!--begin::Modal - Center Head Assignee-->
<div class="modal fade" id="kt_modal_center_head_assign" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form id="addheadForm" action="{{ route('assign_center_head') }}" method="POST" onsubmit="return AssignCenterHeadForm()">
            @csrf
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Center Head Assignee</h3>
                </div>
                <input type="hidden" name="assign_head_old" id="assign_head_old">
                <input type="hidden" name="center_head_branch_id" id="center_head_branch_id">
                <div class="row mb-6">
                    <div class="col-lg-6 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Person Name<span class="text-danger">*</span></label>
                        <select class="select3 form-select" name="center_head_staff_assign" id="center_head_staff_assign" onchange="staff_data_func()">
                            <option value="">Person Name </option>
                        </select>
                        <div class="text-danger fs-7" id="center_head_staff_assign_err"></div>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Mobile No</label>
                        <input type="text" class="form-control" placeholder="Enter Mobile Number" id="center_head_mobile" value="" readonly />
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mb-2">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" >Assign</button>
                </div>
            </div>
            </form>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
</div>
<!--end::Modal - Center Head Assignee-->

<!--begin::Modal - Assign CUG & Mail-->
<div class="modal fade" id="kt_modal_assign_cug_mail" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form id="assignCugForm" action="{{ route('assign_cug_Detail') }}" method="POST" >
            @csrf
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Communication</h3>
                </div>
                <input type="hidden" name="add_sno_cug" id="add_sno_cug" >
                <div class="row mb-6">
                    <div class="col-lg-8 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Communication Staff<span class="text-danger">*</span></label>
                        <select class="select3 form-select" id="cre_cug_add" name="cre_cug_add" data-placeholder="Select Communication Staff">
                            <option value="">Select Communication Staff</option>
                        </select>
                        <div class="text-danger fs-7 cre_cug_add_err" id="cre_cug_add_err"></div>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Mobile No</label>
                        <input type="text" class="form-control" placeholder="Enter Mobile Number" id="cre_mobile_no_cug_add" name="cre_mobile_no_cug_add" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                        <div class="text-danger fs-7 cre_mobile_no_cug_add_err" id="cre_mobile_no_cug_add_err" ></div>
                    </div>
                </div>
                <input type="hidden" name="cug_assign_status" id="cug_assign_status">
                <div class="form-repeater_cug_mob_mail" >
                    <div data-repeater-list="group-a_led_question" id="default_repeater">
                        <div data-repeater-item>
                            <div class="row mt-4" >
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-5 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                                            <select id="staff_cug_add_1" name="staff_cug_add[]" class="cug_staff_drop select3 form-select">
                                                <option value="">Select Staff</option>
                                            </select>
                                            <div class="text-danger fs-7 staff_cug_add_err" id="staff_cug_add_err_1" ></div>
                                        </div>
                                        <div class="col-lg-2 mb-3">
                                            <div class="mb-1">
                                                <!-- <input class="form-check-input" type="checkbox" id="mobile_no_chk_1" onclick="mobile_no_func(1);" /> -->
                                                <label class="text-black fs-6 fw-semibold">Mobile No<span class="text-danger" id="mob_req_1">*</span></label>
                                            </div>
                                            <input type="text" class="form-control mobile_no_cug_add" id="mobile_no_cug_add_1" name="mobile_no_cug_add[]" placeholder="Enter Mobile No" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                                            <div class="text-danger fs-7 mobile_no_cug_add_err" id="mobile_no_cug_add_err_1" ></div>   
                                        </div>
                                        <div class="col-lg-3 mb-3">
                                            <div class="mb-1">
                                                <input class="form-check-input" type="checkbox" id="email_chk" onchange="email_func_2(1)" />
                                                <label class="text-black fs-6 fw-semibold">Email ID<span class="text-danger" style="display: none ;" id="email_req">*</span></label>
                                            </div>
                                            <input type="text" class="form-control email_cug_add" id="email_cug_add" name="email_cug_add[]" placeholder="Enter Email ID" style="display: none ;"   oninput="this.value = this.value.toLowerCase();"/>
                                             <div class="text-danger fs-7 email_cug_add_err" id="email_cug_add_err" ></div>  
                                        </div>
                                        <div class="col-lg-1">
                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 cug_mail_mail_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="cug_mail_mail_del_1" style="display: none !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                  
                                </div>
                            </div>
                        </div>
                    </div>
                     <div id="repeater_req"></div>
                </div>
                <div class="mb-1 mt-1">
                    <button type="button" class="btn btn-primary cug_mob_mail_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="cug_mob_mail_add">
                        <i class="mdi mdi-plus me-1"></i>
                    </button>
                </div>
                <div class="d-flex justify-content-end align-items-center mb-2">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="assignCugBtn" class="btn btn-primary" >Assign</button>
                </div>
            </div>
            </form>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
</div>
<!--end::Modal - Assign CUG & Mail-->




<!-- toaster  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .toast-info {
        background-color: #7239ea;
    }

</style>
<script>
    // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
</script>

<!-- view function -->
 <script>
    function viewbranch(id) {
        fetch('/branch_view/' + id, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    console.error(data.data);
                    var com = data.data;
                    if(com.branch_type==1){
                      var branch_name=com.branch_name;
                      var viewname='View Branch';
                    }
                    else
                    {
                      var branch_name=com.franchise_name;
                      var viewname='View Franchise';
                    }
                    
                    let addressParts = [];
                    if (com.door_no) addressParts.push(com.door_no);
                    if (com.area_street) addressParts.push(com.area_street);
                    if (com.citiesname) addressParts.push(com.citiesname);
                    if (com.statename) addressParts.push(com.statename);
                    if (com.name) addressParts.push(com.name);
                    if (com.pincode) addressParts.push(com.pincode);
                    let addressFinal = addressParts.join(', ');
                    
                    $('#view_name').html(viewname);
                    $('#view_branchname').html(branch_name);
                    $('#view_entityname').html(com.entity_name).attr('title', com.entity_name).tooltip('dispose').tooltip();
                    $('#view_calltrackcid').html(com.mobile).attr('title', com.mobile);
                    $('#view_calltrackcid').html(com.company_type_name + '(' + com.slug_name + ')'); //company_mail
                    $('#view_businessmobile').html(com.mobile).attr('title', com.mobile);
                    $('#view_website').html(com.entity_website).attr('title', com.entity_website).attr('href', com.company_website).tooltip('dispose').tooltip();
                    $('#view_websitelink').attr('href', com.entity_website); //company_ct_person//company_ct_number
                    $('#view_contactperson').html(com.entity_ct_person).attr('title', com.entity_ct_person).tooltip('dispose').tooltip();
                    $('#view_cpmobileno').html(com.entity_ct_number);
                    // Create a variable to hold the address string
                    $('#view_address').html(addressFinal);
                    $('#view_description').html(com.branch_desc);
                    $('#view_gstno').html(com.gst_no);
                    $('#view_gsttype').html(com.gst_percentage);
                    $('#view_cinno').html(com.entity_cin);
                    $('#view_panno').html(com.pan_no);
                    $('#view_taxno').html(com.tax_no);
                    $('#view_bank').html(com.bank_name);
                    $('#view_branch').html(com.bank_branch);
                    $('#view_accountholder').html(com.bank_holder);
                    $('#view_accountno').html(com.bank_account_no);
                    $('#view_ifsccode').html(com.bank_ifsc);
                    $('#view_minamountreceive').html(com.min_amnt_receive);
                    $('#view_collectionclosing').html(com.collection_close);
                    $('#view_registrationcldate').html(com.registeration_close);
                    $('#view_currencyformat').html(com.registeration_close);
                    $('#view_cloudcallapikey').html(com.cloud_call_api_key);
                    $('#view_company').html(com.company_name).attr('title', com.company_name).tooltip('dispose').tooltip();
                    $('#view_entity').html(com.entity_name).attr('title', com.entity_name).tooltip('dispose').tooltip();
                    $('#view_businessemailid').html(com.mail);
                    $('#view_commemailid').html(com.comm_email_id);
                    $('#view_shareasperc').html(com.share_percentage);
                    $('#view_agreementstdate').html(com.share_start_date || '-');
                    $('#view_agreementenddate').html(com.share_end_date || '-');
                    $('#view_justdialbcode').html(com.just_dial_id)
                    $('#view_calltrackercid').html(com.call_tracker_branch_id);
                    $('#view_timezone').html(com.time_zone_country + '(' + com.time_zone + ')'+com.utc_offset);
                    $('#view_currencyformat').html(com.currency_code + '' + com.currency_symbol);
                    $('#view_cinno').html(com.tax_no);
                    $('#view_branchshortcut').html(com.city_short_code);
                    $('#view_openingdate').html(com.opening_date);
                    $('#view_facebooklink').attr('href',com.fb_link);
                    $('#view_instalink').attr('href',com.insta_link);
                    $('#view_websitelink').attr('href',com.website);
                    $('#view_latitude').html(com.latitude);
                    $('#view_longitude').html(com.longitude);
                    $('#view_location').html(com.location.slice(0, 35)+'...');

                    $('#view_location_href').attr('href',com.location);

                    //view_cinno===================
                    $('[data-bs-toggle="tooltip"]').tooltip();
                } else {
                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
 </script>

 <!-- status Change -->
 <script>
    function updatelevelStatus(branchId, isChecked,type) {
        const status = isChecked ? 0 : 1;
        fetch(`/branch_status/${branchId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success(type+' Status Updated successfully!');
                }
            })
            .catch(error => {});
    }
</script>

<!-- assign center head start -->
<script>
    function assign_centerHead_add(id, assign) {
        $('#center_head_branch_id').val(id);
        $('#assign_head_old').val(assign);
        
        $('#center_head_mobile').val('');
        $('#center_head_staff_assign').val('');

        $(document).ready(function() {
            var selectedstaffId = $('#assign_head_old').val();
            $.ajax({
                url: "/staff_list_by_branch_id/" + id,
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('select[name="center_head_staff_assign"]');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Person Name </option>'));
                        response.data.forEach(function(category) {
                            selectDropdown.append($('<option></option>').attr('value',
                                    category
                                    .sno)
                                .text(category.staff_name + ' - '+category.job_position_name));
                        });
                        selectDropdown.val(selectedstaffId).trigger(
                            'change');
                    }
                },
                error: function(error) {
                    // console.error('Error fetching course categories:', error);
                }
            });
        });
    }

    function staff_data_func() {
        var staff_id = $('#center_head_staff_assign').val();
        if (staff_id != "") {
            $.ajax({
                url: "/staff_data_get/" + staff_id,
                type: "GET",
                success: function(response) {
                    // console.log(response)
                    if (response.status === 200) {
                        $('#center_head_mobile').val(response.mobile);
                    }
                },
                error: function(error) {
                    console.error('Error fetching staff data:', error);
                }
            });
        } else {
            $('#center_head_mobile').val('');
          
        }
    }
</script>
<script>
    function AssignCenterHeadForm() {
            var center_head_staff_assign = $('#center_head_staff_assign').val();
            if (center_head_staff_assign == "") {
                $('#center_head_staff_assign_err').html('Select Person Name is Required..!');
                return false;
            } else {
                $('#center_head_staff_assign_err').html('');
                return true;
            }
        }
</script>
<!-- assign center head end -->

<!-- Assign Cug Details Start-->
<script>
    function assign_Cug_func_staffold(sno) {    
        $('#add_sno_cug').val(sno);
        var branchId = $('#add_sno_cug').val(); 

        $(document).ready(function (){
            $.ajax({
                url: "{{ route('job_position_branch') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('select[name="job_position_cug_add[]"]');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Job Position</option>');
                        response.data.forEach(function(position) {
                            countryDropdown.append($('<option></option>').attr('value', position
                                .sno).text(position.job_position_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });
        })

        $(document).ready(function (){
            $.ajax({
                url: "/cre_dropdown_for_branch/" +"?branchId=" + branchId,              // Fixed: changed BranchId to branchId
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('select[name="cre_cug_add"]');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Communication </option>');
                        response.data.forEach(function(position) {
                            var staffNameWithRole = position.staff_name + " - " + position.role_name;
                            countryDropdown.append($('<option></option>')
                                .attr('value', position.sno)
                                .text(staffNameWithRole)); 
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });
        })
    }
</script>

<script>
     function Cug_AddvalidateForm() {
        var err = 0;

        // Validate the static fields first
        var cre_dropdown = $(".cre_cug_add").val();
        if (cre_dropdown == "") {
            $('.cre_cug_add_err').html('Select Communication  is required...!');
            err++;
        } else {
            $('.cre_cug_add_err').html('');
        }

        var cre_mobile_no = $(".cre_mobile_no_cug_add").val();
        if (cre_mobile_no == "") {
            $('.cre_mobile_no_cug_add_err').html('Enter Mobile No is required...!');
            err++;
        } else {
            var filter = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
            if (filter.test(cre_mobile_no)) {
                $('.cre_mobile_no_cug_add_err').html('');
            } else {
                $('.cre_mobile_no_cug_add_err').html('Enter a valid Mobile number (e.g., 6311111111)...!');
                err++;
            }
        }

        var job_position = $("#job_position_cug_add_0").val();
        if (job_position == "") {
            $('.job_position_cug_add_err').html('Select Job Position is required...!');
            err++;
        } else {
            $('.job_position_cug_add_err').html('');
        }

        var staff_id = $(".staff_cug_add").val();
        if (staff_id == "") {
            $('.staff_cug_add_err').html('Select Staff is required...!');
            err++;
        } else {
            $('.staff_cug_add_err').html('');
        }

        // Validate mobile number for the static field
        var mobile_no = $(".mobile_no_cug_add").val();
        if (mobile_no == "") {
            $('.mobile_no_cug_add_err').html('Enter Mobile No is required...!');
            err++;
        } else {
            var filter = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
            if (filter.test(mobile_no)) {
                $('.mobile_no_cug_add_err').html('');
            } else {
                $('.mobile_no_cug_add_err').html('Enter a valid Mobile number (e.g., 6311111111)...!');
                err++;
            }
        }

        // Loop through each dynamically added row (using the .cug_repeater class)
        $(".cug_repeater").each(function() {
            var row = $(this); // Reference to the current row

            // Validate job position for the current row
            var row_job_position = row.find(".job_position_cug_add").val();
            if (row_job_position == "") {
                row.find('.job_position_cug_add_err').html('Select Job Position is required...!');
                err++;
            } else {
                row.find('.job_position_cug_add_err').html('');
            }

            // Validate staff for the current row
            var row_staff_id = row.find(".staff_cug_add").val();
            if (row_staff_id == "") {
                row.find('.staff_cug_add_err').html('Select Staff is required...!');
                err++;
            } else {
                row.find('.staff_cug_add_err').html('');
            }

            // Validate mobile number for the current row
            var row_mobile_no = row.find(".mobile_no_cug_add").val();
            if (row_mobile_no == "") {
                row.find('.mobile_no_cug_add_err').html('Enter Mobile No is required...!');
                err++;
            } else {
                var filter = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
                if (filter.test(row_mobile_no)) {
                    row.find('.mobile_no_cug_add_err').html('');
                } else {
                    row.find('.mobile_no_cug_add_err').html('Enter a valid Mobile number (e.g., 6311111111)...!');
                    err++;
                }
            }
        });

        // If no errors, return true; otherwise, return false
        if (err === 0) {
            return true;
        } else {
            return false;
        }
    }
</script>

<!-- Assign Cug Details End-->

<!-- Delete branch -->
<script>
        function confirmDelete(id, name, type) {
            console.log(id , name ,type)
    
            document.querySelector('#kt_modal_delete_branch .btn-danger').setAttribute('data-id', id);
            $('#delete_message').html(
                'Are you sure you want to delete '+type+' ?<br> <b class="text-black fw-bold fs-4">' +
                name +
                '</b>');
        }

        function deletebranch() {
            var categoryId = document.querySelector('#kt_modal_delete_branch .btn-danger').getAttribute('data-id');

            fetch('/branch_delete/' + categoryId, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success(data.message);
                        location.reload();
                    } else {
                        toastr.error(data.error_msg);
                    }
                })
                .catch(error => {

                });
        }
</script>

<script>
    function mobile_no_func(val) {
        var mobile_no_chk = document.getElementById("mobile_no_chk_"+val);
        var mob_no = document.getElementById("mobile_no_cug_add_"+val);
        var mob_req = document.getElementById("mob_req_"+val);
        if (mobile_no_chk.checked) {
            mob_no.style.display = "block";
            mob_req.style.display = "inline";
        } else {
            mob_no.style.display = "none";
            mob_req.style.display = "none";
        }
    }

    function email_func_2(val) {

        if (document.getElementById('email_chk').checked) {
            document.getElementById('email_cug_add').style.display = "block";
            document.getElementById('email_req').style.display = "inline";
        } else {
                document.getElementById('email_cug_add').style.display = "none";
            document.getElementById('email_req').style.display = "none";
        }
    }

    function email_func(val) {

         const emailChk = document.getElementById(`email_chk_${val}`);
        const emailTbox = document.getElementById(`email_cug_add_${val}`);
        const emailReq = document.getElementById(`email_req_${val}`);

        if (!emailChk || !emailTbox || !emailReq) {
            console.error("One or more elements not found for value:", val);
            return;
        }

        if (emailChk.checked) {
            console.log('checked');
            emailTbox.style.display = "block";
            emailReq.style.display = "inline";
        } else {
            console.log('not checked');
            emailTbox.style.display = "none";
            emailReq.style.display = "none";
        }
    }


</script>

<script>
    $('#branch_filter').click(function() {
        $('.branch_filter').slideToggle('slow');
    });
</script>
<script>
  function sort_filter(val) {
    if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#filter_form').submit();
    } else {
      $('.sorting_filter_class').val(10);
      $('#filter_form').submit();
    }
  }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
    $(".comm_table").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-12 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
    $('.comm_table').wrap('<div class="dataTables_scroll" />');
</script>
<script>
    var staffListCache = [];
    function populateStaffDropdowns(val) {
        // First, collect all currently selected values (excluding the one currently being populated)
        console.log(val)
        var selectedValues = $('select[name="staff_cug_add[]"]').map(function () {
            return $(this).val();
        }).get();

        $('.cug_staff_drop:visible:enabled').each(function () {
            var $dropdown = $(this);
            var currentValue = $dropdown.val(); // Store current value
            $dropdown.empty();
            $dropdown.append('<option value="">Select Staff</option>');

            staffListCache.forEach(function (staff) {
                // Only add option if it's not already selected OR it's the current value of this dropdown
                if (!selectedValues.includes(staff.sno.toString()) || staff.sno.toString() === currentValue) {
                    $dropdown.append($('<option></option>')
                        .attr('value', staff.sno)
                        .text(staff.staff_name + ' - ' + staff.job_position_name));
                          if( val == staff.sno){
                                $dropdown.val(val).trigger('change');
                            }
                }
               
               
            });


            // Re-select the current value (if it's still available)
            if (currentValue) {
                $dropdown.val(currentValue);
            } 
        });
    }


    var cugAssignCounter = 1; 
    function assign_Cug_func_staff(sno) {    
        cugAssignCounter = 1; 
        $('#add_sno_cug').val(sno);
        var branchId = $('#add_sno_cug').val(); 

           var dropdownPromise = $.ajax({
                url: "/cre_dropdown_for_branch/?branchId=" + branchId,
                type: "GET"
            });
        
            var staffListPromise = $.ajax({
                url: "/staff_list_by_branch_id/" + sno,
                type: "GET"
            });
            
            
             $.when(dropdownPromise, staffListPromise).done(function(dropdownRes, staffListRes) {
                    // Handle dropdown response
                    if (dropdownRes[0].status === 200 && dropdownRes[0].data) {
                        var countryDropdown = $('select[name="cre_cug_add"]');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Communication </option>');
                        dropdownRes[0].data.forEach(function(position) {
                            var staffNameWithRole = position.staff_name + " - " + position.role_name;
                            countryDropdown.append($('<option></option>')
                                .attr('value', position.sno)
                                .text(staffNameWithRole)); 
                        });
                    }
            
                    // Handle staff list response
                    if (staffListRes[0].status === 200 && staffListRes[0].data) {
                        staffListCache = staffListRes[0].data; // Store it for reuse
                        populateStaffDropdowns(0); 
                    }
        
            $('.form-repeater_cug_mob_mail').not(':first').remove();
    
            $.ajax({
                url: "/cug_details/",            
                type: "GET",
                data: {branch_id :branchId },
                success: function(response) {
                    
                    if (response.data.length > 0) {
    // Disable and hide inputs and selects in default repeater
    $('#default_repeater input').hide().prop('disabled', true);
    $('#default_repeater select').hide().prop('disabled', true);
    $('#cug_assign_status').val('update');

    response.data.forEach(function(cug, index) {
        let currentIndex = index + 1;
        $('#default_repeater').hide();

        var newRequirementHtml = `
            <div class="form-repeater_cug_mob_mail" id="assign_cug_row_${cugAssignCounter}">
                <input type="hidden" name="cug_edit_sno[]" value="${cug.sno}" />
                <div data-repeater-list="group-a_led_question">
                    <div data-repeater-item>
                        <div class="row mt-4">
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col-lg-5 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold" id="cug_staff_label_${cugAssignCounter}">Staff<span class="text-danger">*</span></label>
                                        <select id="staff_cug_add_${cugAssignCounter}" name="staff_cug_add_${cug.sno}[]" class="cug_staff_drop select3 form-select">
                                            <option value="">Select Staff</option>
                                        </select>
                                        <div class="text-danger err_mssg fs-7 staff_cug_add_err" id="staff_cug_add_err_${cugAssignCounter}" ></div>
                                    </div>
                                    <div class="col-lg-2 mb-3">
                                        <div class="mb-1">
                                            <label class="text-black fs-6 fw-semibold">Mobile No<span class="text-danger" id="mob_req_${cugAssignCounter}">*</span></label>
                                        </div>
                                        <input type="text" class="form-control mobile_no_cug_add" id="mobile_no_cug_add_${cugAssignCounter}" value="${cug.staff_mobile || ''}" name="mobile_no_cug_add_${cug.sno}[]" placeholder="Enter Mobile No" oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);" maxlength="10" />
                                        <div class="text-danger fs-7 mobile_no_cug_add_err" id="mobile_no_cug_add_err_${cugAssignCounter}" ></div>   
                                    </div>
                                    <div class="col-lg-3 mb-3">
                                        <div class="mb-1">
                                            <input class="form-check-input" type="checkbox" ${cug.staff_email ? 'checked' : ''} id="email_chk_${cugAssignCounter}" onclick="email_func(${cugAssignCounter});" />
                                            <label class="text-black fs-6 fw-semibold">Email ID<span class="text-danger" style="display: ${cug.staff_email ? '' : 'none'};" id="email_req_${cugAssignCounter}">*</span></label>
                                        </div>
                                        <input type="text" class="form-control email_cug_add" id="email_cug_add_${cugAssignCounter}" name="email_cug_add_${cug.sno}[]" value="${cug.staff_email || ''}" placeholder="Enter Email ID" style="display: ${cug.staff_email ? '' : 'none'}" oninput="this.value = this.value.toLowerCase();" />
                                        <div class="text-danger fs-7 email_cug_add_err" id="email_cug_add_err_${cugAssignCounter}" ></div>   
                                    </div>
                                    <div class="col-lg-1" id="delete_cug_btn_${cugAssignCounter}">
                                        <button type="button" class="btn btn-outline-danger mt-6 px-1 py-2 cug_mail_mail_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="cug_mail_mail_del_${cugAssignCounter}">
                                            <i class="mdi mdi-delete fs-4"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#repeater_req').first().parent().append(newRequirementHtml);

        // Show the delete button only if counter > 1
        if (cugAssignCounter === 1) {
            $('#delete_cug_btn_1').hide();
        } else {
            $('#delete_cug_btn_' + cugAssignCounter).show();
        }

        populateStaffDropdowns(cug.staff_id);
        cugAssignCounter++;
    });

} else {
    $('#cug_assign_status').val('add');
    $('#default_repeater').show();
    $('#default_repeater input').show().prop('disabled', false);
    email_func(cugAssignCounter);
    cugAssignCounter = 2;
}

    
                    if(response.branch){
                        $('select[name="cre_cug_add"]').val(response.branch.cre_id).change();
                        $('#cre_mobile_no_cug_add').val(response.branch.cre_mobile).change();
                    }
                    
                },
                error: function(error) {
                    console.error('Error fetching CUG data:', error);
                    cugAssignCounter = 2; 
                }
            });

             }).fail(function() {
                console.error('One of the first two AJAX calls failed.');
            });
      

   
    }
</script>

<script>
    $(document).ready(function() {
        

        $('.cug_mob_mail_add').on('click', function() {
            // Increment the counter
            // Create the new requirement row dynamically
            var newRequirementHtml = `
                <div class="form-repeater_cug_mob_mail" id="assign_cug_row_${cugAssignCounter}">
                        <div data-repeater-list="group-a_led_question">
                            <div data-repeater-item>
                                <div class="row mt-4">
                                    <div class="col-lg-12">
                                        <div class="row">
                                            <div class="col-lg-5 mb-3">
                                                <label class="text-black mb-1 fs-6 fw-semibold" id="cug_staff_label_${cugAssignCounter}">Staff<span class="text-danger">*</span></label>
                                                <select id="staff_cug_add_${cugAssignCounter}" name="staff_cug_add[]" class="cug_staff_drop select3 form-select">
                                                    <option value="">Select Staff</option>
                                                </select>
                                                <div class="text-danger err_mssg fs-7 staff_cug_add_err" id="staff_cug_add_err_${cugAssignCounter}" ></div>
                                            </div>
                                            <div class="col-lg-2 mb-3">
                                                <div class="mb-1">
                                                   
                                                    <label class="text-black fs-6 fw-semibold">Mobile No<span class="text-danger"  id="mob_req_${cugAssignCounter}">*</span></label>
                                                </div>
                                                <input type="text" class="form-control mobile_no_cug_add" id="mobile_no_cug_add_${cugAssignCounter}" name="mobile_no_cug_add[]" placeholder="Enter Mobile No"  oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);" maxlength="10" />
                                                <div class="text-danger fs-7 mobile_no_cug_add_err " id="mobile_no_cug_add_err_${cugAssignCounter}" ></div>   
                                            </div>
                                            <div class="col-lg-3 mb-3">
                                                <div class="mb-1">
                                                    <input class="form-check-input" type="checkbox" id="email_chk_${cugAssignCounter}" onclick="email_func(${cugAssignCounter});" />
                                                    <label class="text-black fs-6 fw-semibold">Email ID<span class="text-danger" style="display: none;" id="email_req_${cugAssignCounter}">*</span></label>
                                                </div>
                                                <input type="text" class="form-control email_cug_add" id="email_cug_add_${cugAssignCounter}" name="email_cug_add[]" placeholder="Enter Email ID" style="display: none "  oninput="this.value = this.value.toLowerCase();" />
                                                <div class="text-danger fs-7 email_cug_add_err" id="email_cug_add_err_${cugAssignCounter}" ></div>   
                                            </div>
                                            <div class="col-lg-1">
                                                <button type="button" class="btn btn-outline-danger mt-6 px-1 py-2 cug_mail_mail_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="cug_mail_mail_del_${cugAssignCounter}" style="display: none;">
                                                    <i class="mdi mdi-delete fs-4"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            `;

            // Append the new requirement row
            $('#repeater_req').first().parent().append(newRequirementHtml);
            populateStaffDropdowns(0);
            cugAssignCounter++;
          
          
            
            // Show the delete button for the new row
            $('#cug_mail_mail_del_' + cugAssignCounter).show();

            // Hide delete button for the first requirement
        
        });

        // Delete a requirement row
        $(document).on('click', '.cug_mail_mail_del', function(e) {
            var deleteId = $(this).attr('id');  // Get the id of the clicked delete button
            var index = deleteId.split('_')[4];  
            // Remove the row
            $('#assign_cug_row_' + index).slideUp(400, function() {
                $(this).remove(); // Remove the row
                cugAssignCounter--; // Decrement counter
                // Hide the delete button for the first row if there is only one remaining row
                if (cugAssignCounter === 1) {
                    $('#cug_mail_mail_del_1').hide();
                }
            });
        });

        $('#assignCugBtn').on('click', function () {
            var valid = true;

            var cre_dropdown = $("#cre_cug_add").val();
            if (cre_dropdown == "") {
                $('#cre_cug_add_err').html('Select Communication  is required...!');
                valid = false;
            } else {
                $('#cre_cug_add_err').html('');
            }

            var cre_mobile_no = $("#cre_mobile_no_cug_add").val();
            if (cre_mobile_no == "") {
                $('#cre_mobile_no_cug_add_err').html('Enter Mobile No is required...!');
            valid = false;
            } else {
                var filter = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
                if (filter.test(cre_mobile_no)) {
                    $('#cre_mobile_no_cug_add_err').html('');
                } else {
                    $('#cre_mobile_no_cug_add_err').html('Enter a valid Mobile number (e.g., 6311111111)...!');
                valid = false;
                }
            }

            $('.cug_staff_drop:visible:enabled').each(function () {
                let staff_cug_add = $(this).val();
                let errDiv = $(this).closest('.mb-3').find('.staff_cug_add_err');

                if (!staff_cug_add || staff_cug_add.trim() === '') {
                    valid = false;
                    errDiv.text('Staff is required');
                } else {
                    errDiv.text('');
                }
            });

             $('.mobile_no_cug_add:visible:enabled').each(function () {
                let staff_cug_add = $(this).val();
                let errDiv = $(this).closest('.mb-3').find('.mobile_no_cug_add_err');

                if (!staff_cug_add || staff_cug_add.trim() === '') {
                    valid = false;
                    errDiv.text('Mobile Number is required');
                } else {
                    errDiv.text('');
                }
            });

            $('.email_cug_add:visible:enabled').each(function () {
                let staff_cug_add = $(this).val();
                let errDiv = $(this).closest('.mb-3').find('.email_cug_add_err');

                if (!staff_cug_add || staff_cug_add.trim() === '') {
                    valid = false;
                    errDiv.text('Email is required');
                } else {
                    errDiv.text('');
                }
            });


            if (valid) {
                $('#assignCugForm').submit();
                $('#assignCugBtn').prop('disabled', true);
            } else {
                $('#assignCugBtn').prop('disabled', false);
            }
        });

    });
</script>

<script>
    function add_staff_branch(id, type) {
        $.ajax({
            url: "/branch/Add_staff_branch",
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            data: JSON.stringify({
                id: id,
                type: type
            }),
            success: function(response) {
                // Handle success response here if needed
                console.log(response);
                if (response.id != "") {
                    window.location.href = '/manage_staff/staff_add';
                }
            },
            error: function(xhr, status, error) {
                // Handle error
                console.error(xhr.responseText);
            }
        });
    }
</script>

 <script>
  document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
    el.addEventListener('click', function () {
      setTimeout(() => {
        location.reload();
      }, 150);
    });
  });
</script>

@endsection