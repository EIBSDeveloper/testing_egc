@extends('layouts/layoutMaster')

@section('title', 'Verify Campaign Checklist')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms_file_upload.js')
@endsection

@section('content')
<!-- Users List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="mb-4 text-black">Verify Campaign Checklist</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Marketing Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Campaign</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row mb-2">
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-domain fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Campaign"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->campaign_name ??''}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-format-list-group fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Category"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->marketing_category_name??''}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-format-list-text fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Type"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->marketing_type_name??''}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-text-box-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Description"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->description??''}}</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-counter fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Count"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->count??''}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-cash fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment"></i>
                        </label>
                        <div class="text-info fw-bold fs-6">
                            <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-info fw-bold"></i></label>
                            <label class="fs-6" id='initial_amount'>{{$verify_activity_edit->payment??""}}</label>
                        </div>
                    </div>
                    @if($verify_activity_edit->start_date && $verify_activity_edit->end_date)
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-calendar-range fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->start_date ?? '-'}} to {{$verify_activity_edit->end_date ?? '-'}}
                        </label>
                    </div>
                    @endif
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-map-marker-radius fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Zone"></i>
                        </label>
                        <label class="fw-semibold fs-6 zone_name">{{$verify_activity_edit->zone_name??'-'}}</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-office-building fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Vendor"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->marketing_vendor_name??'-'}}</label>
                        <div class="d-block fw-semibold fs-7"></div>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-account-supervisor fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Contact Person"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->vendor_contact_person_name??'-'}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-cellphone fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Contact Person Mobile No"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->vendor_contact_person_mobile??'-'}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-office-building-marker fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Address"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->marketing_vendor_address??'-'}}</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-2">
            <div class="mb-2 d-flex align-items-center">
                <label class="fw-semibold fs-6 me-1">
                    <i class="mdi mdi-text-box-check-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Campaign Checklist"></i>
                </label>
                <label class="text-black my-4 fs-5 fw-semibold">Campaign Checklist</label>
            </div>
            @php
                // print_r($verify_activity_edit->camp_checklist);
                $zone_area_name = json_decode($verify_activity_edit->zone_schedule);
                $champ_name = $verify_activity_edit->camp_checklist;

                if (is_string($champ_name)) {
                    $champ_name = json_decode($champ_name, true); // Decode into an associative array
                }

                $counter = 0; 
                $totalCount = is_array($champ_name) ? count($champ_name) : 0;

                // print_r($champ_name); 
                // print_r($zone_area_name); 

                // echo "Total count: $totalCount";
            @endphp 

            <form id="mar_verify_activity_edit" action="{{ route('marketing_verifiy_activity') }}" method="POST">
                @csrf
                @php
                    // Decode the checklist JSON string
                    $checklistData = json_decode($verify_activity_edit->checklist, true);
                    // print_r($checklistData);
                    // Initialize array for storing total amounts per area
                    $areaTotalAmounts = [];
                    // Check if checklistData exists and is an array
                    if ($checklistData) {
                        foreach ($checklistData as $check) {
                            // Only consider checklist entries where checked == 1
                            if ($check['checked'] == 1) {
                                // Add the amount for this area to the total
                                if (!isset($areaTotalAmounts[$check['area']])) {
                                    $areaTotalAmounts[$check['area']] = 0;
                                }
                                $areaTotalAmounts[$check['area']] += $check['amount'];
                            }
                        }
                    }
                @endphp

                @if(isset($verify_activity_edit->payment) && isset($verify_activity_edit->zone_schedule))
                    @if(isset($zone_area_name) && is_array($zone_area_name))
                        @foreach($zone_area_name as $key => $value)
                            <div class="col-lg-12 mb-4">
                                <div class="card-action">
                                    <div class="card-header collapse_{{$key}} bg-label-success">
                                        <div class="card-action-title">
                                            <div class="row">
                                                <div class="col-lg-4 d-flex align-items-center">
                                                    <div class="form-check form-check-inline">
                                                        {{-- Check if the area exists in checklistData and has checklist == 1 --}}
                                                        @php
                                                            $isChecked = false;
                                                            // Loop through checklistData to see if any item for this area has checked == 1
                                                            foreach ($checklistData as $check) {
                                                                if ($check['area'] == $value->area && $check['checked'] == 1) {
                                                                    $isChecked = true;
                                                                    break; // Exit loop after finding first match
                                                                }
                                                            }
                                                        @endphp
                                                        <input class="form-check-input outer_checkbox" 
                                                            type="checkbox" 
                                                            name="area_name[]" 
                                                            id="area_{{$value->id}}" 
                                                            data-index="{{ $key }}" 
                                                            value="{{ $value->area }}" 
                                                            {{ $isChecked ? 'checked' : '' }} />
                                                        <label class="text-black fs-6 fw-bold" 
                                                            for="area_{{$value->id}}">
                                                            {{ $value->area }}
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-1 mb-3">
                                                    <div class="d-flex align-items-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Count">
                                                        <label class="text-dark fs-5 fw-bold">{{$totalCount}}</label>
                                                        <label class="text-dark fs-5 fw-bold">/</label>
                                                        <label class="text-dark fs-5 fw-bold">{{ $totalCount }}</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <div class="badge bg-info fw-bold rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Actual Amount">
                                                        <label class="fs-5"><i class="mdi mdi-currency-rupee fs-5 text-white fw-bold"></i></label>
                                                        {{-- Show the total amount for the area --}}
                                                        <label class="fs-5 amount_display" id="amount_display_{{ $key }}" name="amount_display[]">
                                                            {{ isset($areaTotalAmounts[$value->area]) ? number_format($areaTotalAmounts[$value->area], 2) : '0.00' }}
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-action-element">
                                            <ul class="list-inline mb-0">
                                                <li class="list-inline-item">
                                                    <a href="javascript:;" class="first_zone_add_{{ $key }}" onclick="up_down_branch({{ $key }})"><i class="mdi mdi-chevron-up fs-3 text-black"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                        </div>
                    </div>
                    <div class="collapse first_zone_body_add_{{ $key }} border">
                        <div class="card-body">
                            <div class="row">
                                <input type="hidden" name="marketing_sno_edit" id="marketing_sno_edit" value="{{$verify_activity_edit->mark_sno}}">
                                <div class="col-lg-12">
                                    <div class="row bg-label-danger rounded">
                                        <div class="col-lg-6 mt-2 mb-1 text-black fs-6 fw-semibold">Checklist</div>
                                        <div class="col-lg-3 mt-2 mb-1 text-black fs-6 fw-semibold">Amount</div>
                                        <div class="col-lg-3 mt-2 mb-1 text-black fs-6 fw-semibold">Reason</div>
                                    </div>
                                    @if(isset($champ_name))
                                        @foreach($champ_name as $chk_key => $activity)
                                            @php
                                                $amount = ''; // Initialize amount
                                                $reason = ''; // Initialize reason
                                                $isChecked = false; // Default unchecked

                                                // Loop through the checklistData to find the corresponding checklist entry for this activity
                                                foreach ($checklistData as $check) {
                                                    // Match the activity to the 'checklist' field in checklistData
                                                    if ($check['checklist'] == $activity && $check['checked'] == 1) {
                                                        $amount = $check['amount'];  // Get the corresponding amount
                                                        $reason = $check['reason'];  // Get the corresponding reason
                                                        $isChecked = true;  // Set the checkbox to checked if the condition is met
                                                        break; // Exit the loop after finding the match
                                                    }
                                                }
                                            @endphp

                                            <div class="row mt-2">
                                                <div class="col-lg-6 mb-2 d-flex align-items-center">
                                                    <div class="form-check form-check-inline">
                                                        <!-- Checkbox: Check if checklist == 1 and if the 'checked' field is 1 -->

                                                        <input class="form-check-input activity_chk" type="checkbox" 
                                                            id="activity_{{ $chk_key }}{{ $value->area }}" 
                                                            name="activity_{{ $value->area }}[{{ $chk_key }}][checked]" 
                                                            data-index="{{ $key }}" 
                                                            value="1"
                                                            {{ $isChecked ? 'checked' : '' }} 
                                                            onchange="toggleAmountField({{ $chk_key }}, '{{ $value->area }}')" />

                                                        <label class="text-dark fs-6 fw-semibold" for="activity_{{ $chk_key }}_{{ $value->area }}">
                                                            {{ $activity }}
                                                        </label>

                                                        <input type="hidden" name="activity_{{ $value->area }}[{{ $chk_key }}][activity]" value="{{ $activity }}" />
                                                    </div>
                                                </div>

                                                {{-- <div class="col-lg-3 mb-2">
                                                    <!-- Amount Input Field -->
                                                    <input type="text" class="form-control amount-input checklist_amount" 
                                                        name="checklist_amount_{{ $activity }}{{ $chk_key }}" 
                                                        id="checklist_amount_{{ $chk_key }}{{ $activity }}" 
                                                        data-index="{{ $key }}" 
                                                        placeholder="Enter Amount" 
                                                        value="{{ $amount }}"
                                                        oninput="calculateTotal({{ $key }})" />
                                                </div> --}}
                                                <div class="col-lg-3 mb-2">
                                                    <input type="text" class="form-control amount-input checklist_amount" name="checklist_amount_{{ $value->area }}[{{ $chk_key }}]" id="checklist_amount_{{ $chk_key }}{{ $value->area }}" data-index="{{ $key }}" placeholder="Enter Amount" value="{{ $amount }}"
                                                    oninput="calculateTotal({{ $key }})" />
                                                </div>
                                                <div class="col-lg-3">
                                                    <textarea class="form-control" rows="1"
                                                            id="checklist_reason_{{ $chk_key }}_{{ $value->area }}" 
                                                            name="checklist_reason_{{ $value->area }}[{{ $chk_key }}]"
                                                            placeholder="Enter Reason">
                                                        {{ $reason ?? '-' }}
                                                    </textarea>
                                                </div>

                                                

                                                {{-- <div class="col-lg-3">
                                                    <textarea class="form-control" rows="1" id="checklist_reason_{{ $chk_key }}_{{ $value['area'] }}" name="checklist_reason_{{ $value['area'] }}[{{ $chk_key }}]" placeholder="Enter Reason"></textarea>
                                                </div> --}}
                                            </div>
                                        @endforeach
                                        @else
                                            <div class="text-danger">There is No checklist avaiable</div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
                @endif
                @endif
                <div class="d-flex justify-content-end align-items-center gap-2 mt-4">
                    <a href="{{url('/marketing')}}" class="btn fw-bold btn-secondary">Cancel</a>
                    <button type='button' id='submitbtn' class="btn fw-bold btn-primary" onclick="validateForm()">Verify Campaign Checklist</button>
                </div>
            </form>
        </div>
    </div>


    <script>
        function calculateTotal(zoneIndex) {
            const zone = document.querySelector(`.first_zone_body_add_${zoneIndex}`);

            if (zone) {
                const amountInputs = zone.querySelectorAll(`input[id^="checklist_amount_"]`);
                let total = 0;
                let checkedCount = 0;

                amountInputs.forEach(input => {
                    const checkboxId = input.id.replace("checklist_amount_", "activity_");
                    const checkbox = document.getElementById(checkboxId);
                   console.log('checkbox is not checked', checkbox);
                    if (checkbox) {
                        // alert('checkbox alert');
                        const activityIndex = checkbox.getAttribute('data-index');

                        if (checkbox.checked) {
                            const value = parseFloat(input.value) || 0;
                            if (!isNaN(value)) {
                                total += value; // Add the valid input value to total
                                checkedCount++; // Increment checked count
                                // alert('total :', total);
                                // alert(checkedCount);
                            }
                        }
                    }
                });

                // Update the count and the total amount display
                const amountDisplay = document.querySelector(`#amount_display_${zoneIndex}`);
                if (amountDisplay) {
                    amountDisplay.innerText = total.toFixed(2);
                }
            }
        }

        function toggleAmountField(checkKey, activity) {
            const checkbox = document.getElementById(`activity_${checkKey}_${activity}`);
            const amountInput = document.getElementById(`checklist_amount_${checkKey}${activity}`);

            // If checkbox is unchecked, reset the amount field
            if (!checkbox.checked) {
                amountInput.value = '';
            }

            // Call the function to re-calculate the total after every checkbox change
            calculateTotal(checkKey); 
        }
    </script>

    
    <script>
        $(document).ready(function() {
            $('.outer_checkbox').change(function() {
                // Check or uncheck all activity checkboxes based on the outer checkbox
                $('.activity_chk').prop('checked', this.checked);
                // Clear all amount inputs if the outer checkbox is unchecked
                if (!this.checked) {
                    $('input[id^="checklist_amount_"]').val('');
                }
            });

            $('.activity_chk').change(function() {
                // Get the corresponding amount input field
                const amountInputId = `checklist_amount_${this.id.split('_')[1]}`;
                const amountInput = document.getElementById(amountInputId);

                // If the checkbox is unchecked, clear the corresponding amount input
                if (!this.checked) {
                    if (amountInput) {
                        amountInput.value = ''; // Clear the amount
                    }
                }

                // Count how many inner checkboxes are checked
                const checkedCount = $('.activity_chk:checked').length;
               console.log('checkedCount',checkedCount);
                const totalCount = $('.activity_chk').length;

                // If all inner checkboxes are checked, check the outer checkbox
                if (checkedCount === totalCount) {
                    $('.outer_checkbox').prop('checked', true);
                } else {
                    // Only uncheck the outer checkbox if no inner checkboxes are checked
                    if (checkedCount === 0) {
                        $('.outer_checkbox').prop('checked', false);
                    }
                }
            });
        });

    </script>



    <!--Create Zone Accordion Start-->
    <script>
        function up_down_branch(id) {
            // Get all chevron elements with the specific class for each card
            const chevronElement = document.querySelector('.first_zone_add_' + id);
            
            if (chevronElement) {
                // Add click event listener to that specific chevron
                chevronElement.addEventListener('click', function(event) {
                    event.preventDefault();
                    
                    // Get the specific card header containing the chevron
                    const cardHeader = chevronElement.closest('.card-header');
                    
                    // Find the corresponding collapse body within the same card
                    const collapseElement = cardHeader.closest('.card').querySelector('.collapse.first_zone_body_add_' + id);
                    
                    if (collapseElement) {
                        // Collapse the target element
                        const collapseInstance = new bootstrap.Collapse(collapseElement);
                        
                        // Toggle the collapse state
                        collapseInstance.toggle();
    
                        // Toggle the collapsed class for the card header (now scoped to the correct header)
                        cardHeader.classList.toggle('collapsed');
                        
                        // Toggle chevron icon between up and down
                        const icon = chevronElement.querySelector('i');
                        icon.classList.toggle('mdi-chevron-down');
                        icon.classList.toggle('mdi-chevron-up');
                    }
                });
            }
        }
    </script>
    <!--Create Zone Accordion End-->




    <script>
        $(document).ready(function() {
            // Handle changes in outer checkbox (select all checkboxes for the zone)
            $('.outer_checkbox').change(function() {
                const zoneIndex = $(this).data('index'); // Get the zone index

                // Set all activity checkboxes in this zone to match the outer checkbox state
                $(`.first_zone_body_add_${zoneIndex} .activity_chk`).prop('checked', this.checked);

                // If unchecked, clear all the amount fields
                if (!this.checked) {
                    $(`.first_zone_body_add_${zoneIndex} input[id^="checklist_amount_"]`).val('');
                }

                // Recalculate the total for this zone
                calculateTotal(zoneIndex);
            });

            // Handle changes in activity checkboxes
            $('.activity_chk').change(function() {
                const zoneIndex = $(this).data('index'); // Get the zone index
                const amountInputId = `checklist_amount_${this.id.split('_')[1]}`;
                const amountInput = document.getElementById(amountInputId);

                // If checkbox is unchecked, clear the corresponding amount input
                if (!this.checked) {
                    if (amountInput) {
                        amountInput.value = ''; // Clear amount input field if checkbox is unchecked
                    }
                }

                // Recalculate the total for this zone
                calculateTotal(zoneIndex);
            });

            // Handle input in amount fields
            $('input[id^="checklist_amount_"]').on('input', function() {
                const zoneIndex = $(this).data('index'); // Get the zone index from the input data
                calculateTotal(zoneIndex); // Recalculate the total when the amount is changed
            });

            // Ensure that when the form is submitted, unchecked checkboxes don't send empty values
            $('#mar_verify_activity_edit').on('submit', function(e) {
                $('.activity_chk').each(function() {
                    const amountInputId = `checklist_amount_${this.id.split('_')[1]}`;
                    const amountInput = document.getElementById(amountInputId);
    
                    // If the checkbox is unchecked, set the amount field's name to empty to prevent submission
                    if (!this.checked) {
                        if (amountInput) {
                            amountInput.name = ''; // Prevent the empty amount from being sent in the form submission
                        }
                    }
                });
            });
        });
    </script>    


    <script>
        function validateForm() {

                document.getElementById('mar_verify_activity_edit').submit();
            
        }

    </script>




    @endsection
