@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Branch Metrics')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('content')

<!-- Users List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center flex-wrap">
        <div>
            <h5 class="card-title mb-1">Branch Target</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard/crm') }}" class="d-flex align-items-center">
                            <i class="mdi mdi-home text-body fs-4"></i>
                        </a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:void(0);" class="d-flex align-items-center">Branch Management</a>
                    </li>
                </ol>
            </nav>
        </div>
    
        <!-- Month Navigation - pushed to end -->
        <div class="nav-align-top mt-2 mt-md-0">
            <ul class="nav nav-pills" role="tablist">
                <!-- Previous Month -->
                <li class="nav-item me-1">
                    <a class="nav-link px-3" href="#" id="prevMonthBtn">
                        <div class="text-center">
                            <span class="mdi mdi-arrow-left-circle-outline fs-2"></span>
                        </div>
                    </a>
                </li>
    
                <!-- Current Month -->
                <li class="nav-item me-1">
                    <a class="nav-link active px-3 border border-dashed border-info" href="#">
                        <div class="text-center">
                            <span class="fs-6 fw-semibold text-capitalize" id="selectedMonth">
                                {{ \Carbon\Carbon::now()->format('F') }}
                            </span>
                            <div class="d-block">
                                <span class="fw-semibold fs-8" id="selectedYear">
                                    ({{ \Carbon\Carbon::now()->year }})
                                </span>
                            </div>
                        </div>
                    </a>
                </li>
    
                <!-- Next Month -->
                <li class="nav-item me-1">
                    <a class="nav-link px-3" href="#" id="nextMonthBtn">
                        <div class="text-center">
                            <span class="mdi mdi-arrow-right-circle-outline fs-2"></span>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>

               



    <div class="card">
        <div class="card-body">
            <!-- Target List Table -->
            <div class="mt-5">
                <h5 class="text-dark fw-bold mb-3">Metrics List</h5>
                <div class="table-responsive">
                    <table class="table table-bordered align-middle text-center" id="targetTable">
                        <thead class="table bg-primary">
                            <tr>
                                <th>Branch</th>
                                <th>Month</th>
                                <th>Lead</th>
                                <th>Target</th>
                                <th>Actual</th>
                                <th>Pre Sale</th>
                                <th>Actual</th>
                                <th>Post Sale</th>
                                <th>Actual</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Data rows will be appended here dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
    
        </div>
    </div>


</div>



<!-- jQuery from CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Toastr CSS from CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<!-- Toastr JavaScript from CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>

.goal-label-box {
    background-color: #f8f9fa; /* Light gray */
    padding: 6px 12px;
    border-radius: 4px;
    border: 1px solid #cccccc;
    display: inline-block;
    min-width: 100px;
    text-align: center;
}
.goal-actual-field {
    background-color: #e4c30a; /* Light gray */
    border: 1px solid #e4c30a;
    cursor: not-allowed;
}
.select2-container {
    margin-right: 0.22rem !important; /* Equivalent to Bootstrap's me-1 */
}

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }
    .goal-label {
        min-width: 200px; /* Ensures all labels are of equal width */
        text-align: left; /* Aligns text to the left for consistency */
    }
      .goal-label-staff {
          font-size: 10px;
          font-weight: bold;
          color: #555;
          text-align: center;
      }

        .goal-inline-group {
            display: flex;
            align-items: center;
            gap: 6px; /* Space between fields */
        }

        .goal-input-wrap {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

          .goal-label {
              font-weight: bold;
              color: #0a0a0a;
          }



        .goal-input-field-box {
              background-color: #ffffff;
              border: 1px solid #1b1a14;
              width: 150px;  /* Smaller input field */
              color: #1b1a14;
              /* font-size: 14px; */
              font-weight: bold;

          }

          .goal-checkbox {
              appearance: none;
              width: 20px;
              height: 20px;

              background-color: white;
              cursor: pointer;
              display: inline-block;
              position: relative;
              transform: scale(1.2);
          }

          .goal-checkbox:checked {
            border: 2px solid green;
              background-color: green;
          }




</style>
<style>
      table thead tr th{
        padding: 5px !important;
    }
    table tbody tr td{
        padding: 5px !important;
    }
</style>
<script>

    var currentMonth = new Date().getMonth() + 1; // Get current month (1-12)
    var currentYear = new Date().getFullYear();
    function updateMonthDisplay() {
        let monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        $("#monthLabel").text(monthNames[currentMonth - 1] + " " + currentYear);
        document.getElementById("selectedMonth").textContent = monthNames[currentMonth - 1];
        document.getElementById("selectedYear").textContent = "(" + currentYear + ")";

        document.getElementById("prevMonthBtn").classList.toggle("disabled", false);
        document.getElementById("nextMonthBtn").classList.toggle("disabled", false);

        // Fetch updated team goals for the selected month
       fetchTargets();
    }
    
     document.getElementById("prevMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();
        if (currentMonth === 1) {
            currentMonth = 12;
            currentYear--;
        } else {
            currentMonth--;
        }
        updateMonthDisplay();
    });

    document.getElementById("nextMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();
        if (currentMonth === 12) {
            currentMonth = 1;
            currentYear++;
        } else {
            currentMonth++;
        }
        updateMonthDisplay();
    });
   $(document).ready(function () {
    // Trigger fetch when branch changes
    $("#branchSelectsgoal").change(function () {
        fetchTargets();
    });

    // Initial fetch on page loa
    fetchTargets();


   
});

   // Fetch existing targets if needed
   function fetchTargets() {
    let month = $("#selectedMonth").text().trim();
    let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
    $.ajax({
        url: "{{ route('branch-management-branch_target') }}",
        type: "GET",
        data: {month: month ,year: year },
        success: function(response) {
            if (response.status === 200 && response.data.length > 0) {
                let rows = '';
        
                response.data.forEach(item => {
                    let monthName = new Date(item.date).toLocaleString('default', { month: 'long' });
        
                    // Parse currency strings to numbers
                    let targetAmount = parseFloat(item.target.replace(/[₹,]/g, '')) || 0;
                    let actualAmount = parseFloat(item.target_actual.replace(/[₹,]/g, '')) || 0;
                    let postTarget = parseInt(item.post_sale_target) || 0;
                    let postActual = parseInt(item.post_sale_actual) || 0;
                    let preTarget = parseInt(item.pre_sale_target) || 0;
                    let preActual = parseInt(item.pre_sale_actual) || 0;
        
                    // Dynamic Badge Classes
                    let actualClass = 'fw-bold fs-2 badge ' + ((targetAmount > 0 && actualAmount >= targetAmount) ? 'bg-success' : 'bg-danger');
                    let postClass   = 'fw-bold fs-2 badge ' + ((postTarget > 0 && postActual >= postTarget) ? 'bg-success' : 'bg-danger');
                    let preClass    = 'fw-bold fs-2 badge ' + ((preTarget > 0 && preActual >= preTarget) ? 'bg-success' : 'bg-danger');

        
                    // Branch Type Color
                    let branchClass = item.branch_type == 1 ? 'badge bg-warning fw-bold text-dark' : 'badge bg-info text-white';
        
                   rows += `
                        <tr>
                            <td>
                                <span class="${branchClass} fs-4">${item.branch_name}</span>
                                <div class="text-danger fw-bold"> ${item.last_login}</div>
                                <div class="text-danger fw-bold">${item.last_login_ago}</div>
                            </td>
                            <td>${monthName}</td>
                            <td><span class="fw-bold fs-5 badge bg-label-secondary">${item.lead_total}</span></td>
                    
                            <td><span class="fw-bold fs-2 badge bg-label-secondary">${item.target}</span></td>
                            <td><span class="${actualClass}">${item.target_actual}</span></td>
                    
                            <td><span class="fw-bold fs-2 badge bg-label-secondary">${item.pre_sale_target ?? '-'}</span></td>
                            <td><span class="${preClass}">${item.pre_sale_actual}</span></td>
                            
                            <td><span class="fw-bold fs-2 badge bg-label-secondary">${item.post_sale_target ?? '-'}</span></td>
                            <td><span class="${postClass}">${item.post_sale_actual}</span></td>
                            
                        </tr>
                    `;
                });
        
                $('#targetTable tbody').html(rows);
            } else {
                $('#targetTable tbody').html(`<tr><td colspan="9" class="text-center text-muted">No data found</td></tr>`);
            }
        },
        error: function (error) {
            console.error("Error fetching targets:", error);
        }
    });
}
</script>

@endsection
