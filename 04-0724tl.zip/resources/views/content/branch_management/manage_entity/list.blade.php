@extends('layouts/layoutMaster')

@section('title', 'Manage Entity')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/nouislider/nouislider.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/nouislider/nouislider.js', 'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>
@php
    $module_name = 'Branch Management';
    $menu_name   = 'Manage Entity';
@endphp
    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Entity</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Branch Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter">
                                                                                        <span><i class="mdi mdi-filter-outline"></i></span>
                                                                                    </a> -->
                    @if(auth()->user()->hasPermission($module_name, 'Add', $menu_name))
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_create_entity">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Entity
                    </a>
                    @endif
                </div>
            </div>
        </div>
        <div class="card-body">
            @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
            <div class="row">
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Entity</th>
                                <th class="min-w-100px">Company</th>
                                <th class="min-w-100px">Address</th>
                                <th class="min-w-100px">Contact Person / Mobile</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-100px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                            @if (isset($ListTable))
                                @foreach ($ListTable as $list)
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="text-truncate max-w-175px" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="{{ $list->entity_name }}">
                                                    {{ $list->entity_name }}</div>
                                                <a href="{{ $list->entity_website }}" target="_blank" class="ms-1"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Website URL">
                                                    <i class="mdi mdi-web fs-4 text-dark"></i>
                                                </a>
                                                <a href="javascript:;" class="ms-1" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="{{ $list->entity_mail }}">
                                                    <i class="mdi mdi-email-outline fs-4 text-dark"></i>
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <label>{{ $list->company_name }}</label>
                                        </td>
                                        <td>
                                            <div class="text-wrap max-w-250px" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom"
                                                title="{{ $list->entity_door_no }} {{ $list->entity_area }}
                                                {{ $list->citiesname }} {{ $list->statename }}
                                                {{ $list->name }}">
                                                {{ $list->entity_door_no }} {{ $list->entity_area }}
                                                {{ $list->citiesname }} {{ $list->statename }}
                                                {{ $list->name }}</div>
                                        </td>
                                        <td>
                                            <label>{{ $list->entity_ct_person }}</label>
                                            <div class="d-block">
                                                <label
                                                    class="fs-8 text-black fw-semibold">{{ $list->entity_ct_number }}</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="switch switch-square">
                                                <input type="checkbox" class="switch-input"
                                                    {{ $list->status == 0 ? 'checked' : '' }}
                                                    onchange="updateEntityStatus('{{ $list->sno }}', this.checked)" />
                                                <span class="switch-toggle-slider">
                                                    <span class="switch-on"></span>
                                                    <span class="switch-off"></span>
                                                </span>
                                            </label>
                                        </td>
                                        <td class="text-end">
                                            @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                            <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2"
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_view_company"
                                                onclick="viewmodel('{{ $list->sno }}')">
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i
                                                        class="mdi mdi-eye-outline fs-3 text-black"></i></span>
                                            </a>
                                            @endif
                                            @if(auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                                            <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2"
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_update_company"
                                                onclick="editmodel('{{ $list->sno }}')">
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i
                                                        class="mdi mdi-square-edit-outline fs-3 text-black"></i></span>
                                            </a>
                                            @endif
                                            @if(auth()->user()->hasPermission($module_name, 'Delete', $menu_name))
                                            <a href="#"
                                                onclick="confirmDelete('{{ $list->sno }}','{{ $list->entity_name }}','{{ $list->company_id }}')"
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_delete_company">
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i
                                                        class="mdi mdi-delete-outline fs-3 text-black"></i></span>
                                            </a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
            @endif
        </div>
    </div>



    <!--begin::Modal - Create Entity-->
    <div class="modal fade" id="kt_modal_create_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Create Entity</h3>
                    </div>
                    <form method="POST" action="{{ route('add_entity') }}" id="add_form" autocomplete="off">
                        @csrf
                        <div class="row mb-6">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" name="company_id" id="company_id">
                                    <option value="">Select Company</option>
                                    @if (isset($Company))
                                        @foreach ($Company as $type_list)
                                            <option value="{{ $type_list->sno }}">{{ $type_list->company_name }}</option>
                                        @endforeach
                                    @endif
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="entity_name" id="entity_name" class="form-control"
                                    placeholder="Enter Entity Name"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                                <div class="error_msg text-danger" id="entity_name_err"></div>
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Email ID" id="entity_mail"
                                    name="entity_mail" oninput=" this.value = this.value.toLowerCase();" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Website URL"
                                    id="website_url" name="website_url" maxlength="80"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Contact Person Name"
                                    id="ct_person" name="ct_person"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No"
                                    maxlength="10"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="ct_per_mobile_no" name="ct_per_mobile_no" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Country<span
                                        class="text-danger">*</span></label>
                                <select id="countryId" name="country" class="select3 form-select ">
                                    <option value="">Select Country</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">State<span
                                        class="text-danger">*</span></label>
                                <select id="stateId" name="state" class="select3 form-select">
                                    <option value="">Select State</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">City<span
                                        class="text-danger">*</span></label>
                                <select id="cityId" name="city" class="select3 form-select">
                                    <option value="">Select City</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Area / Street"
                                    id="area_street" name="area_street" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Door/Flat No"
                                    id="door_flat_no" name="door_flat_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Pincode"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="pincode" name="pincode" maxlength="10" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                                <input type="text" class="form-control" placeholder="Enter GST No" id="gst_no"
                                    name="gst_no" maxlength="30" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                                <input type="text" class="form-control" placeholder="Enter CIN No" id="cin_no"
                                    name="cin_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pan No</label>
                                <input type="text" class="form-control" placeholder="Enter Pan No" id="pan_no"
                                    name="pan_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-8 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control h-auto" placeholder="Enter Description" id="entity_desc" name="entity_desc" maxlength="80"></textarea>
                            </div>
                        </div>
                        <div class="divider">
                            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                        </div>
                        <div class="row mb-6">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Bank Name"
                                    id="comapny_bank_name" name="comapny_bank_name" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Bank Branch Name"
                                    id="comapny_bank_branch" name="comapny_bank_branch" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account Holder"
                                    id="comapny_acc_holder" name="comapny_acc_holder" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account No"
                                    id="comapny_acc_no" name="comapny_acc_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter IFSC Code"
                                    id="comapny_bank_ifsc" name="comapny_bank_ifsc" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal"  onclick="location.reload()">Cancel</button>
                            <button type="button" class="btn btn-primary" onclick="AddvalidateForm()" id="complete_entity_btn">Create
                                Entity</button>
                        </div>
                    </form>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal - Create Entity-->


    <!--begin::Modal - Update Entity-->
    <div class="modal fade" id="kt_modal_update_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Update Entity</h3>
                    </div>
                    <form method="POST" action="{{ route('update_entity') }}" id="edit_form" autocomplete="off">
                        @csrf
                        <div class="row mb-6">
                            <input type="hidden" id="edit_id" name="edit_id" />
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" name="company_id" id="edit_company_id">
                                    <option value="">Select Company</option>
                                    @if (isset($Company))
                                        @foreach ($Company as $type_list)
                                            <option value="{{ $type_list->sno }}">{{ $type_list->company_name }}
                                            </option>
                                        @endforeach
                                    @endif
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="entity_name" id="edit_entity_name" class="form-control"
                                    placeholder="Enter Entity Name"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                                <div class="error_msg text-danger" id="edit_entity_name_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Email ID"
                                    id="edit_entity_mail" name="entity_mail"
                                    oninput=" this.value = this.value.toLowerCase();" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Website URL"
                                    id="edit_website_url" name="website_url" maxlength="80"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Contact Person Name"
                                    id="edit_ct_person" name="ct_person"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No"
                                    maxlength="10"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="edit_ct_per_mobile_no" name="ct_per_mobile_no" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Country<span
                                        class="text-danger">*</span></label>
                                <select id="edit_countryId" name="country" class="select3 form-select ">
                                    <option value="">Select Country</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">State<span
                                        class="text-danger">*</span></label>
                                <select id="edit_stateId" name="state" class="select3 form-select">
                                    <option value="">Select State</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">City<span
                                        class="text-danger">*</span></label>
                                <select id="edit_cityId" name="city" class="select3 form-select">
                                    <option value="">Select City</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Area / Street"
                                    id="edit_area_street" name="area_street" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Door/Flat No"
                                    id="edit_door_flat_no" name="door_flat_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Pincode"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="edit_pincode" name="pincode" maxlength="20"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                                <input type="text" class="form-control" placeholder="Enter GST No" id="edit_gst_no"
                                    name="gst_no" maxlength="20"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                                <input type="text" class="form-control" placeholder="Enter CIN No" id="edit_cin_no"
                                    name="cin_no" maxlength="20"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pan No</label>
                                <input type="text" class="form-control" placeholder="Enter Pan No" id="edit_pan_no"
                                    name="pan_no" maxlength="20"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-8 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control h-auto" placeholder="Enter Description" id="edit_entity_desc" name="entity_desc" maxlength="80"></textarea>
                            </div>
                        </div>
                        <div class="divider">
                            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                        </div>
                        <div class="row mb-6">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Bank Name"
                                    id="edit_comapny_bank_name" name="comapny_bank_name" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Bank Branch Name"
                                    id="edit_comapny_bank_branch" name="comapny_bank_branch" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account Holder"
                                    id="edit_comapny_acc_holder" name="comapny_acc_holder" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account No"
                                    id="edit_comapny_acc_no" name="comapny_acc_no"maxlength="50" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter IFSC Code"
                                    id="edit_comapny_bank_ifsc" name="comapny_bank_ifsc" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal" >Cancel</button>
                            <button type="button" class="btn btn-primary" onclick="EditvalidateForm()" id="update_entity_btn">Update
                                Entity</button>
                        </div>
                    </form>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal - Update Entity-->


    <!--begin::Modal - View Entity-->
    <div class="modal fade" id="kt_modal_view_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8">
                        <h3 class="mb-4 text-black text-center">View Entity</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Entity</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_entityname"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Company</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_company"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_emailid"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="">
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Website URL</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <a href="https://phdizone.com/" target="_blank" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" id="view_websitelink">
                                        <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_website">
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Contact Person</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="view_contactperson"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title=""></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">C.P. Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_cpmobileno"></label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_address"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">GST No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="" id="view_gstno"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">CIN No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="" id="view_cinno">
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Pan No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="" id="view_panno"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Description</label>
                        <label class="col-12 text-black fs-6 fw-bold" id="view_description">&emsp;&emsp;&emsp; </label>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Bank</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_bank"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Branch</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_branch"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">IFSC Code</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_ifsccode"></label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Account Holder</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_accountholder"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Account No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="view_accountno"></label>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Entity-->


    <!--begin::Modal - Delete Entity-->
    <div class=" modal fade" id="kt_modal_delete_company" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;"><span
                        id="delete_message"></span>
                    <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">

                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="submit" class="btn btn-danger me-3" 
                        onclick="deleteEntityCategory()">Yes, delete!</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Entity-->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
    <script>
  document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
    el.addEventListener('click', function () {
      // Small delay to allow modal animation to finish
      setTimeout(() => {
        location.reload();
      }, 150);
    });
  });
</script>


    
    <script>
        $(document).ready(function() {
            // Fetch and populate countries
            $.ajax({
                url: "{{ route('country') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('#countryId');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Country</option>');
                        response.data.forEach(function(country) {
                            countryDropdown.append($('<option></option>').attr('value', country
                                .id).text(country.name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });
            // Event listener for country change
            $('#countryId').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#stateId');
                var cityDropdown = $('#cityId');

                stateDropdown.empty().append('<option value="">Select State</option>');
                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('state') }}",
                        type: "GET",
                        data: {
                            country_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.id).text(state.name));
                                });
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });
            // Event listener for state change
            $('#stateId').on('change', function() {
                var stateId = $(this).val();
                var countryId = $('#countryId').val();
                var cityDropdown = $('#cityId');

                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId && stateId) {
                    // Fetch and populate cities based on selected state and country
                    $.ajax({
                        url: "{{ route('city') }}",
                        type: "GET",
                        data: {
                            country_id: countryId,
                            state_id: stateId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(city) {
                                    cityDropdown.append($('<option></option>').attr(
                                        'value', city.id).text(city.name));
                                });
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching cities:', error);
                        }
                    });
                }
            });
        });
    </script>
    <script>
        function AddvalidateForm() {
            let isValid = 0;

            // Clear all previous errors
            document.querySelectorAll('.error_msg').forEach(div => {
                div.innerText = '';
            });

            // Helper to set error
            function setError(id, message) {
                document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
                isValid = 1;
            }

            // Required fields validation
            const requiredFields = [{
                    id: 'entity_name',
                    name: 'Entity Name'
                },
                {
                    id: 'company_id',
                    name: 'Company'
                },
                {
                    id: 'entity_mail',
                    name: 'Email ID'
                },
                {
                    id: 'website_url',
                    name: 'Website URL'
                },
                {
                    id: 'ct_person',
                    name: 'Contact Person Name'
                },
                {
                    id: 'ct_per_mobile_no',
                    name: 'Contact Person Mobile No'
                },
                {
                    id: 'countryId',
                    name: 'Country'
                },
                {
                    id: 'stateId',
                    name: 'State'
                },
                {
                    id: 'cityId',
                    name: 'City'
                },
                {
                    id: 'area_street',
                    name: 'Area / Street'
                },
                {
                    id: 'door_flat_no',
                    name: 'Door/Flat No'
                },
                {
                    id: 'pincode',
                    name: 'Pincode'
                },
                {
                    id: 'comapny_bank_name',
                    name: 'Bank Name'
                },
                {
                    id: 'comapny_bank_branch',
                    name: 'Bank Branch Name'
                },
                {
                    id: 'comapny_acc_holder',
                    name: 'Account Holder'
                },
                {
                    id: 'comapny_acc_no',
                    name: 'Account No'
                },
                {
                    id: 'comapny_bank_ifsc',
                    name: 'IFSC Code'
                }
            ];

            requiredFields.forEach(field => {
                const value = document.getElementById(field.id).value.trim();
                if (value === '') {
                    setError(field.id, `${field.name} is required.`);
                }
            });

            // Email format validation
            const email = document.getElementById('entity_mail').value.trim();
            if (email !== '' && !/^\S+@\S+\.\S+$/.test(email)) {
                setError('entity_mail', 'Enter a valid Email ID.');
            }

            // Mobile number format validation
            const mobile = document.getElementById('ct_per_mobile_no').value.trim();
            const mobilePattern = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;

            if (mobile !== '' && !mobilePattern.test(mobile)) {
                setError('ct_per_mobile_no', 'Enter a valid 10-digit Mobile Number.');
            }

            if (isValid == 0) {
                $('#add_form').submit();
            }
        }
    </script>

    <script>
        $(".list_page").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    <script>
        function updateEntityStatus(EntityId, isChecked) {
            const status = isChecked ? 0 : 1; // Set status based on checkbox state

            fetch(`/entity_status/${EntityId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        console.log('Entity status updated successfully:', data.message);
                        toastr.success('Entity status Updated successfully!');
                    } else {
                        console.error('Error updating Entity status:', data.message);
                        toastr.error('Error updating Entity status');
                    }
                })
                .catch(error => {
                    console.error('Error updating Entity status:', error);
                });
        }
    </script>

    <script>
        function confirmDelete(sno, name, id) {
            document.querySelector('#kt_modal_delete_company .btn-danger').setAttribute(
                'data-id', sno);
            $('#delete_message').html('Are you sure you want to delete <br> <b class="text-danger"> ' + name +
                '</b> Entity ?');
        }

        function deleteEntityCategory() {

            var universityId = document.querySelector('#kt_modal_delete_company .btn-danger').getAttribute('data-id');

            fetch('/entity_delete/' + universityId, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Entity Deleted successfully!');
                        location.reload();

                    } else {

                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        function viewmodel(id) {
            fetch('/entity_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;
                        $('#view_entityname').html(com.entity_name).attr('title', com.entity_name).tooltip('dispose').tooltip();
                        $('#view_company').html(com.company_name).attr('title', com.company_name).tooltip('dispose').tooltip();
                        $('#view_companytype').html(com.company_type_name + '(' + com.slug_name + ')'); //company_mail
                        $('#view_emailid').html(com.entity_mail).attr('title', com.company_mail).tooltip('dispose').tooltip();
                        $('#view_website').html(com.entity_website).attr('title', com.entity_website).attr('href', com.company_website).tooltip('dispose').tooltip();
                        $('#view_websitelink').attr('href', com.entity_website); //company_ct_person//company_ct_number
                        $('#view_contactperson').html(com.entity_ct_person).attr('title', com.entity_ct_person).tooltip('dispose').tooltip();
                        $('#view_cpmobileno').html(com.entity_ct_number);
                        let addressParts = [];
                        if (com.entity_door_no) addressParts.push(com.entity_door_no);
                        if (com.entity_area) addressParts.push(com.entity_area);
                        if (com.citiesname) addressParts.push(com.citiesname);
                        if (com.statename) addressParts.push(com.statename);
                        if (com.name) addressParts.push(com.name);
                        if (com.pincode) addressParts.push(com.pincode);
                        let addressFinal = addressParts.join(', ');
                        $('#view_address').html(addressFinal);
                        $('#view_description').html(com.entity_desc);
                        $('#view_gstno').html(com.entity_gst);
                        $('#view_cinno').html(com.entity_cin).attr('title', com.entity_cin).tooltip('dispose').tooltip();
                        $('#view_panno').html(com.entity_pan).attr('title', com.entity_pan);
                        $('#view_panno').tooltip('dispose').tooltip();
                        $('#view_taxno').html(com.entity_tax);
                        $('#view_bank').html(com.entity_bank_name);
                        $('#view_branch').html(com.entity_bank_branch);
                        $('#view_accountholder').html(com.entity_acc_holder);
                        $('#view_accountno').html(com.entity_acc_no);
                        $('#view_ifsccode').html(com.entity_ifsc);
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.log(data.error_msg);
                    }
                })
                .catch(error => {
                    console.log('Error:', error);
                });
        }
    </script>
    <script>
        function editmodel(id) {
            fetch('/entity_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        console.error(data.data);
                        var com = data.data;
                        $('#edit_id').val(id);
                        $('#edit_entity_name').val(com.entity_name);
                        $('#edit_company_id').val(com.company_id).change();
                        $('#edit_entity_mail').val(com.entity_mail);
                        $('#edit_website_url').val(com.entity_website);
                        $('#edit_ct_person').val(com.entity_ct_person).attr('title', com.entity_ct_person);
                        $('#edit_ct_per_mobile_no').val(com.entity_ct_number);
                        // Fetch and populate countries
                        $.ajax({
                            url: "{{ route('country_ed_list') }}",
                            type: "GET",
                            success: function(response) {
                                if (response.status === 200 && response.data) {
                                    var countryDropdown = $('#edit_countryId');
                                    countryDropdown.empty();
                                    countryDropdown.append(
                                        '<option value="">Select Country</option>');
                                    response.data.forEach(function(country) {
                                        countryDropdown.append($('<option></option>')
                                            .attr('value', country.id).text(country
                                                .name));
                                    });
                                    countryDropdown.val(com.entity_country).change();
                                }
                            },
                            error: function(error) {
                                console.error('Error fetching countries:', error);
                            }
                        });
                        // Event listener for country change
                        $('#edit_countryId').on('change', function() {
                            var countryId = $(this).val();
                            var stateDropdown = $('#edit_stateId');
                            var cityDropdown = $('#edit_cityId');

                            stateDropdown.empty().append('<option value="">Select State</option>');
                            cityDropdown.empty().append('<option value="">Select City</option>');

                            if (countryId) {
                                // Fetch and populate states based on selected country
                                $.ajax({
                                    url: "{{ route('state_ed_list') }}",
                                    type: "GET",
                                    data: {
                                        country_id: countryId
                                    },
                                    success: function(response) {
                                        if (response.status === 200 && response.data) {
                                            response.data.forEach(function(state) {
                                                stateDropdown.append($(
                                                        '<option></option>')
                                                    .attr(
                                                        'value', state.id)
                                                    .text(state.name));
                                            });
                                            stateDropdown.val(com.entity_state)
                                                .change();
                                        }
                                    },
                                    error: function(error) {
                                        console.error('Error fetching states:', error);
                                    }
                                });
                            }
                        });
                        // Event listener for state change
                        $('#edit_stateId').on('change', function() {
                            var stateId = $(this).val();
                            var countryId = $('#edit_countryId').val();
                            var cityDropdown = $('#edit_cityId');

                            cityDropdown.empty().append('<option value="">Select City</option>');

                            if (countryId && stateId) {
                                // Fetch and populate cities based on selected state and country
                                $.ajax({
                                    url: "{{ route('city_ed_list') }}",
                                    type: "GET",
                                    data: {
                                        country_id: countryId,
                                        state_id: stateId
                                    },
                                    success: function(response) {
                                        if (response.status === 200 && response.data) {
                                            response.data.forEach(function(city) {
                                                cityDropdown.append($(
                                                        '<option></option>')
                                                    .attr(
                                                        'value', city.id)
                                                    .text(city.name));
                                                cityDropdown.val(com
                                                        .entity_city)
                                                    .change();
                                            });
                                        }
                                    },
                                    error: function(error) {
                                        console.error('Error fetching cities:', error);
                                    }
                                });
                            }
                        });
                        $('#edit_area_street').val(com.entity_area);
                        $('#edit_door_flat_no').val(com.entity_door_no);
                        $('#edit_pincode').val(com.entity_pincode);
                        $('#edit_entity_desc').val(com.entity_desc);
                        $('#edit_gst_no').val(com.entity_gst);
                        $('#edit_cin_no').val(com.entity_cin);
                        $('#edit_pan_no').val(com.entity_pan);
                        $('#edit_comapny_bank_name').val(com.entity_bank_name);
                        $('#edit_comapny_bank_branch').val(com.entity_bank_branch);
                        $('#edit_comapny_acc_holder').val(com.entity_acc_holder);
                        $('#edit_comapny_acc_no').val(com.entity_acc_no);
                        $('#edit_comapny_bank_ifsc').val(com.entity_ifsc);
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    </script>
    <script>
        function EditvalidateForm() {
            let isValid = 0;

            // Clear all previous errors
            document.querySelectorAll('.error_msg').forEach(div => {
                div.innerText = '';
            });

            // Helper to set error
            function setError(id, message) {
                document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
                isValid = 1;
            }

            // Required fields validation
            const requiredFields = [{
                    id: 'edit_entity_name',
                    name: 'Entity Name'
                },
                {
                    id: 'edit_company_id',
                    name: 'Company'
                },
                {
                    id: 'edit_entity_mail',
                    name: 'Email ID'
                },
                {
                    id: 'edit_website_url',
                    name: 'Website URL'
                },
                {
                    id: 'edit_ct_person',
                    name: 'Contact Person Name'
                },
                {
                    id: 'edit_ct_per_mobile_no',
                    name: 'Contact Person Mobile No'
                },
                {
                    id: 'edit_countryId',
                    name: 'Country'
                },
                {
                    id: 'edit_stateId',
                    name: 'State'
                },
                {
                    id: 'edit_cityId',
                    name: 'City'
                },
                {
                    id: 'edit_area_street',
                    name: 'Area / Street'
                },
                {
                    id: 'edit_door_flat_no',
                    name: 'Door/Flat No'
                },
                {
                    id: 'edit_pincode',
                    name: 'Pincode'
                },
                {
                    id: 'edit_comapny_bank_name',
                    name: 'Bank Name'
                },
                {
                    id: 'edit_comapny_bank_branch',
                    name: 'Bank Branch Name'
                },
                {
                    id: 'edit_comapny_acc_holder',
                    name: 'Account Holder'
                },
                {
                    id: 'edit_comapny_acc_no',
                    name: 'Account No'
                },
                {
                    id: 'edit_comapny_bank_ifsc',
                    name: 'IFSC Code'
                }
            ];

            requiredFields.forEach(field => {
                const value = document.getElementById(field.id).value.trim();
                if (value === '') {
                    setError(field.id, `${field.name} is required.`);
                }
            });

            // Email format validation
            const email = document.getElementById('entity_mail').value.trim();
            if (email !== '' && !/^\S+@\S+\.\S+$/.test(email)) {
                setError('entity_mail', 'Enter a valid Email ID.');
            }

            // Mobile number format validation
            const mobile = document.getElementById('ct_per_mobile_no').value.trim();
            const mobilePattern = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;

            if (mobile !== '' && !mobilePattern.test(mobile)) {
                setError('ct_per_mobile_no', 'Enter a valid 10-digit Mobile Number.');
            }

            if (isValid == 0) {
                $('#edit_form').submit();
            }
        }
    </script>

    <script>
        let debounceTimer;

        function debounce(func, delay) {
            return function() {
                const context = this;
                const args = arguments;
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => func.apply(context, args), delay);
            };
        }

        function checkUniqueField(field, value, errorElementId, submitButtonId) {
            if (value === '') {
                $('#' + errorElementId).text('');
                return;
            }

            let sno = $('#edit_id').val() || null;

            $.ajax({
                url: '/check_duplicate_entities',
                method: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    field: field,
                    value: value,
                    sno: sno
                },
                success: function(response) {
                    if (response.exists) {
                        $('#' + errorElementId).text(response.message);
                        $('#' + submitButtonId).prop('disabled', true);
                    } else {
                        $('#' + errorElementId).text('');
                        $('#' + submitButtonId).prop('disabled', false);
                    }
                }
            });
        }

        // Bind with debounce
        $('#entity_name').on('input', debounce(function() {
            checkUniqueField('entity_name', $(this).val(), 'entity_name_err', 'complete_entity_btn');
        }, 600));

        $('#edit_entity_name').on('input', debounce(function() {
            checkUniqueField('entity_name', $(this).val(), 'edit_entity_name_err', 'update_entity_btn');
        }, 600));

    </script>

@endsection
